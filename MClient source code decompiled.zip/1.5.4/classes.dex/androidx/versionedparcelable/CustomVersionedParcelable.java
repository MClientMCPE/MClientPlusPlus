package androidx.versionedparcelable;

public abstract class CustomVersionedParcelable implements C0535df {
}
