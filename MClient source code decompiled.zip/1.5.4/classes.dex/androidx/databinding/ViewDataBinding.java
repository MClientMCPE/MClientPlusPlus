package androidx.databinding;

import android.annotation.TargetApi;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.SparseIntArray;
import android.view.Choreographer;
import android.view.View;
import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;
import p000.C0919i9;
import p000.C1234lb;

public abstract class ViewDataBinding extends C2407z8 {

    /* renamed from: l0 */
    public static int f1103l0 = Build.VERSION.SDK_INT;

    /* renamed from: m0 */
    public static final int f1104m0 = 8;

    /* renamed from: n0 */
    public static final boolean f1105n0 = (f1103l0 >= 16);

    /* renamed from: o0 */
    public static final C0190d f1106o0 = new C0187a();

    /* renamed from: p0 */
    public static final ReferenceQueue<ViewDataBinding> f1107p0 = new ReferenceQueue<>();

    /* renamed from: q0 */
    public static final View.OnAttachStateChangeListener f1108q0 = new C0188b();

    /* renamed from: Y */
    public final Runnable f1109Y = new C0189c();

    /* renamed from: Z */
    public boolean f1110Z = false;

    /* renamed from: a0 */
    public boolean f1111a0 = false;

    /* renamed from: b0 */
    public C0192f[] f1112b0;

    /* renamed from: c0 */
    public final View f1113c0;

    /* renamed from: d0 */
    public C0288b9<Object, ViewDataBinding, Void> f1114d0;

    /* renamed from: e0 */
    public boolean f1115e0;

    /* renamed from: f0 */
    public Choreographer f1116f0;

    /* renamed from: g0 */
    public final Choreographer.FrameCallback f1117g0;

    /* renamed from: h0 */
    public Handler f1118h0;

    /* renamed from: i0 */
    public ViewDataBinding f1119i0;

    /* renamed from: j0 */
    public C1509ob f1120j0;

    /* renamed from: k0 */
    public boolean f1121k0;

    public static class OnStartListener implements C1417nb {

        /* renamed from: a */
        public final WeakReference<ViewDataBinding> f1122a;

        @C2107vb(C1234lb.C1235a.ON_START)
        public void onStart() {
            ViewDataBinding viewDataBinding = (ViewDataBinding) this.f1122a.get();
            if (viewDataBinding != null) {
                viewDataBinding.mo1392v();
            }
        }
    }

    /* renamed from: androidx.databinding.ViewDataBinding$a */
    public static class C0187a implements C0190d {
        /* renamed from: a */
        public C0192f mo1396a(ViewDataBinding viewDataBinding, int i) {
            return new C0193g(viewDataBinding, i).f1127a;
        }
    }

    /* renamed from: androidx.databinding.ViewDataBinding$b */
    public static class C0188b implements View.OnAttachStateChangeListener {
        @TargetApi(19)
        public void onViewAttachedToWindow(View view) {
            ViewDataBinding.m920a(view).f1109Y.run();
            view.removeOnAttachStateChangeListener(this);
        }

        public void onViewDetachedFromWindow(View view) {
        }
    }

    /* renamed from: androidx.databinding.ViewDataBinding$c */
    public class C0189c implements Runnable {
        public C0189c() {
        }

        public void run() {
            synchronized (this) {
                ViewDataBinding.this.f1110Z = false;
            }
            while (true) {
                Reference<? extends ViewDataBinding> poll = ViewDataBinding.f1107p0.poll();
                if (poll == null) {
                    break;
                } else if (poll instanceof C0192f) {
                    ((C0192f) poll).mo1404b();
                }
            }
            int i = Build.VERSION.SDK_INT;
            if (!ViewDataBinding.this.f1113c0.isAttachedToWindow()) {
                ViewDataBinding.this.f1113c0.removeOnAttachStateChangeListener(ViewDataBinding.f1108q0);
                ViewDataBinding.this.f1113c0.addOnAttachStateChangeListener(ViewDataBinding.f1108q0);
                return;
            }
            ViewDataBinding.this.mo1392v();
        }
    }

    /* renamed from: androidx.databinding.ViewDataBinding$d */
    public interface C0190d {
        /* renamed from: a */
        C0192f mo1396a(ViewDataBinding viewDataBinding, int i);
    }

    /* renamed from: androidx.databinding.ViewDataBinding$e */
    public interface C0191e<T> {
        /* renamed from: a */
        void mo1400a(T t);

        /* renamed from: a */
        void mo1401a(C1509ob obVar);

        /* renamed from: b */
        void mo1402b(T t);
    }

    /* renamed from: androidx.databinding.ViewDataBinding$f */
    public static class C0192f<T> extends WeakReference<ViewDataBinding> {

        /* renamed from: a */
        public final C0191e<T> f1124a;

        /* renamed from: b */
        public final int f1125b;

        /* renamed from: c */
        public T f1126c;

        public C0192f(ViewDataBinding viewDataBinding, int i, C0191e<T> eVar) {
            super(viewDataBinding, ViewDataBinding.f1107p0);
            this.f1125b = i;
            this.f1124a = eVar;
        }

        /* renamed from: a */
        public ViewDataBinding mo1403a() {
            ViewDataBinding viewDataBinding = (ViewDataBinding) get();
            if (viewDataBinding == null) {
                mo1404b();
            }
            return viewDataBinding;
        }

        /* renamed from: b */
        public boolean mo1404b() {
            boolean z;
            T t = this.f1126c;
            if (t != null) {
                this.f1124a.mo1400a(t);
                z = true;
            } else {
                z = false;
            }
            this.f1126c = null;
            return z;
        }
    }

    static {
        int i = Build.VERSION.SDK_INT;
    }

    public ViewDataBinding(Object obj, View view, int i) {
        m921a(obj);
        this.f1112b0 = new C0192f[i];
        this.f1113c0 = view;
        if (Looper.myLooper() == null) {
            throw new IllegalStateException("DataBinding must be created in view's UI Thread");
        } else if (f1105n0) {
            this.f1116f0 = Choreographer.getInstance();
            this.f1117g0 = new C1688q9(this);
        } else {
            this.f1117g0 = null;
            this.f1118h0 = new Handler(Looper.myLooper());
        }
    }

    /* renamed from: a */
    public static Drawable m919a(View view, int i) {
        return Build.VERSION.SDK_INT >= 21 ? view.getContext().getDrawable(i) : view.getResources().getDrawable(i);
    }

    /* renamed from: a */
    public static ViewDataBinding m920a(View view) {
        if (view != null) {
            return (ViewDataBinding) view.getTag(C2262x9.dataBinding);
        }
        return null;
    }

    /* renamed from: a */
    public static C0593e9 m921a(Object obj) {
        if (obj == null) {
            return null;
        }
        if (obj instanceof C0593e9) {
            return (C0593e9) obj;
        }
        throw new IllegalArgumentException("The provided bindingComponent parameter must be an instance of DataBindingComponent. See  https://issuetracker.google.com/issues/116541301 for details of why this parameter is not defined as DataBindingComponent");
    }

    /* renamed from: a */
    public static /* synthetic */ void m922a(ViewDataBinding viewDataBinding, int i, Object obj, int i2) {
        if (!viewDataBinding.f1121k0 && viewDataBinding.mo1389a(i, obj, i2)) {
            viewDataBinding.mo1394x();
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:37:0x006e  */
    /* JADX WARNING: Removed duplicated region for block: B:41:? A[ORIG_RETURN, RETURN, SYNTHETIC] */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void m923a(p000.C0593e9 r4, android.view.View r5, java.lang.Object[] r6, android.util.SparseIntArray r7, boolean r8) {
        /*
            androidx.databinding.ViewDataBinding r0 = m920a((android.view.View) r5)
            if (r0 == 0) goto L_0x0007
            return
        L_0x0007:
            java.lang.Object r0 = r5.getTag()
            boolean r1 = r0 instanceof java.lang.String
            if (r1 == 0) goto L_0x0012
            java.lang.String r0 = (java.lang.String) r0
            goto L_0x0013
        L_0x0012:
            r0 = 0
        L_0x0013:
            r1 = 0
            r2 = 1
            if (r8 == 0) goto L_0x003b
            if (r0 == 0) goto L_0x003b
            java.lang.String r8 = "layout"
            boolean r8 = r0.startsWith(r8)
            if (r8 == 0) goto L_0x003b
            r8 = 95
            int r8 = r0.lastIndexOf(r8)
            if (r8 <= 0) goto L_0x0052
            int r8 = r8 + r2
            boolean r3 = m924a((java.lang.String) r0, (int) r8)
            if (r3 == 0) goto L_0x0052
            int r8 = m926b(r0, r8)
            r0 = r6[r8]
            if (r0 != 0) goto L_0x0053
            r6[r8] = r5
            goto L_0x0053
        L_0x003b:
            if (r0 == 0) goto L_0x0052
            java.lang.String r8 = "binding_"
            boolean r8 = r0.startsWith(r8)
            if (r8 == 0) goto L_0x0052
            int r8 = f1104m0
            int r8 = m926b(r0, r8)
            r0 = r6[r8]
            if (r0 != 0) goto L_0x0053
            r6[r8] = r5
            goto L_0x0053
        L_0x0052:
            r2 = 0
        L_0x0053:
            if (r2 != 0) goto L_0x006a
            int r8 = r5.getId()
            if (r8 <= 0) goto L_0x006a
            if (r7 == 0) goto L_0x006a
            r0 = -1
            int r8 = r7.get(r8, r0)
            if (r8 < 0) goto L_0x006a
            r0 = r6[r8]
            if (r0 != 0) goto L_0x006a
            r6[r8] = r5
        L_0x006a:
            boolean r8 = r5 instanceof android.view.ViewGroup
            if (r8 == 0) goto L_0x0081
            android.view.ViewGroup r5 = (android.view.ViewGroup) r5
            int r8 = r5.getChildCount()
            r0 = 0
        L_0x0075:
            if (r0 >= r8) goto L_0x0081
            android.view.View r2 = r5.getChildAt(r0)
            m923a(r4, r2, r6, r7, r1)
            int r0 = r0 + 1
            goto L_0x0075
        L_0x0081:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.databinding.ViewDataBinding.m923a(e9, android.view.View, java.lang.Object[], android.util.SparseIntArray, boolean):void");
    }

    /* renamed from: a */
    public static boolean m924a(String str, int i) {
        int length = str.length();
        if (length == i) {
            return false;
        }
        while (i < length) {
            if (!Character.isDigit(str.charAt(i))) {
                return false;
            }
            i++;
        }
        return true;
    }

    /* renamed from: a */
    public static Object[] m925a(C0593e9 e9Var, View view, int i, SparseIntArray sparseIntArray) {
        Object[] objArr = new Object[i];
        m923a(e9Var, view, objArr, sparseIntArray, true);
        return objArr;
    }

    /* renamed from: b */
    public static int m926b(String str, int i) {
        int length = str.length();
        int i2 = 0;
        while (i < length) {
            i2 = (i2 * 10) + (str.charAt(i) - '0');
            i++;
        }
        return i2;
    }

    /* renamed from: a */
    public abstract boolean mo1388a(int i, Object obj);

    /* renamed from: a */
    public abstract boolean mo1389a(int i, Object obj, int i2);

    /* renamed from: d */
    public boolean mo1390d(int i) {
        C0192f fVar = this.f1112b0[i];
        if (fVar != null) {
            return fVar.mo1404b();
        }
        return false;
    }

    /* renamed from: u */
    public abstract void mo1391u();

    /* renamed from: v */
    public void mo1392v() {
        ViewDataBinding viewDataBinding = this.f1119i0;
        if (viewDataBinding != null) {
            viewDataBinding.mo1392v();
        } else if (this.f1115e0) {
            mo1394x();
        } else if (mo1393w()) {
            this.f1115e0 = true;
            this.f1111a0 = false;
            C0288b9<Object, ViewDataBinding, Void> b9Var = this.f1114d0;
            if (b9Var != null) {
                b9Var.mo2367a(this, 1, null);
                if (this.f1111a0) {
                    this.f1114d0.mo2367a(this, 2, null);
                }
            }
            if (!this.f1111a0) {
                mo1391u();
                C0288b9<Object, ViewDataBinding, Void> b9Var2 = this.f1114d0;
                if (b9Var2 != null) {
                    b9Var2.mo2367a(this, 3, null);
                }
            }
            this.f1115e0 = false;
        }
    }

    /* renamed from: w */
    public abstract boolean mo1393w();

    /* JADX WARNING: Code restructure failed: missing block: B:17:0x002a, code lost:
        if (f1105n0 == false) goto L_0x0034;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x002c, code lost:
        r2.f1116f0.postFrameCallback(r2.f1117g0);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:19:0x0034, code lost:
        r2.f1118h0.post(r2.f1109Y);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:27:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:29:?, code lost:
        return;
     */
    /* renamed from: x */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo1394x() {
        /*
            r2 = this;
            androidx.databinding.ViewDataBinding r0 = r2.f1119i0
            if (r0 == 0) goto L_0x0008
            r0.mo1394x()
            goto L_0x003b
        L_0x0008:
            ob r0 = r2.f1120j0
            if (r0 == 0) goto L_0x001d
            lb r0 = r0.mo635a()
            pb r0 = (p000.C1607pb) r0
            lb$b r0 = r0.f12333b
            lb$b r1 = p000.C1234lb.C1236b.STARTED
            boolean r0 = r0.mo8348a(r1)
            if (r0 != 0) goto L_0x001d
            return
        L_0x001d:
            monitor-enter(r2)
            boolean r0 = r2.f1110Z     // Catch:{ all -> 0x003c }
            if (r0 == 0) goto L_0x0024
            monitor-exit(r2)     // Catch:{ all -> 0x003c }
            return
        L_0x0024:
            r0 = 1
            r2.f1110Z = r0     // Catch:{ all -> 0x003c }
            monitor-exit(r2)     // Catch:{ all -> 0x003c }
            boolean r0 = f1105n0
            if (r0 == 0) goto L_0x0034
            android.view.Choreographer r0 = r2.f1116f0
            android.view.Choreographer$FrameCallback r1 = r2.f1117g0
            r0.postFrameCallback(r1)
            goto L_0x003b
        L_0x0034:
            android.os.Handler r0 = r2.f1118h0
            java.lang.Runnable r1 = r2.f1109Y
            r0.post(r1)
        L_0x003b:
            return
        L_0x003c:
            r0 = move-exception
            monitor-exit(r2)     // Catch:{ all -> 0x003c }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.databinding.ViewDataBinding.mo1394x():void");
    }

    /* renamed from: androidx.databinding.ViewDataBinding$g */
    public static class C0193g extends C0919i9.C0920a implements C0191e<C0919i9> {

        /* renamed from: a */
        public final C0192f<C0919i9> f1127a;

        public C0193g(ViewDataBinding viewDataBinding, int i) {
            this.f1127a = new C0192f<>(viewDataBinding, i, this);
        }

        /* renamed from: a */
        public void mo1405a(C0919i9 i9Var, int i) {
            ViewDataBinding a = this.f1127a.mo1403a();
            if (a != null) {
                C0192f<C0919i9> fVar = this.f1127a;
                if (((C0919i9) fVar.f1126c) == i9Var) {
                    ViewDataBinding.m922a(a, fVar.f1125b, (Object) i9Var, i);
                }
            }
        }

        /* renamed from: a */
        public void mo1401a(C1509ob obVar) {
        }

        /* renamed from: b */
        public void mo1402b(Object obj) {
            ((C2407z8) obj).mo13097a(this);
        }

        /* renamed from: a */
        public void mo1400a(Object obj) {
            ((C2407z8) obj).mo13098b(this);
        }
    }

    /* renamed from: a */
    public void mo1386a(int i, Object obj, C0190d dVar) {
        if (obj != null) {
            C0192f fVar = this.f1112b0[i];
            if (fVar == null) {
                fVar = dVar.mo1396a(this, i);
                this.f1112b0[i] = fVar;
                C1509ob obVar = this.f1120j0;
                if (obVar != null) {
                    fVar.f1124a.mo1401a(obVar);
                }
            }
            fVar.mo1404b();
            fVar.f1126c = obj;
            T t = fVar.f1126c;
            if (t != null) {
                fVar.f1124a.mo1402b(t);
            }
        }
    }

    /* renamed from: a */
    public boolean mo1387a(int i, C0919i9 i9Var) {
        C0190d dVar = f1106o0;
        if (i9Var == null) {
            return mo1390d(i);
        }
        C0192f fVar = this.f1112b0[i];
        if (fVar != null) {
            if (fVar.f1126c == i9Var) {
                return false;
            }
            mo1390d(i);
        }
        mo1386a(i, (Object) i9Var, dVar);
        return true;
    }
}
