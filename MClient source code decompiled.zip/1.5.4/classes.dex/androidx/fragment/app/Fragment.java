package androidx.fragment.app;

import android.animation.Animator;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.FragmentActivity;
import java.lang.reflect.InvocationTargetException;
import java.util.UUID;
import p000.C1002ja;
import p000.C1234lb;

public class Fragment implements ComponentCallbacks, View.OnCreateContextMenuListener, C1509ob, C0296bc, C0857hd {

    /* renamed from: T0 */
    public static final Object f1128T0 = new Object();

    /* renamed from: A0 */
    public boolean f1129A0 = true;

    /* renamed from: B0 */
    public boolean f1130B0;

    /* renamed from: C0 */
    public ViewGroup f1131C0;

    /* renamed from: D0 */
    public View f1132D0;

    /* renamed from: E0 */
    public View f1133E0;

    /* renamed from: F0 */
    public boolean f1134F0;

    /* renamed from: G0 */
    public boolean f1135G0 = true;

    /* renamed from: H0 */
    public C0197c f1136H0;

    /* renamed from: I0 */
    public boolean f1137I0;

    /* renamed from: J0 */
    public boolean f1138J0;

    /* renamed from: K0 */
    public float f1139K0;

    /* renamed from: L0 */
    public LayoutInflater f1140L0;

    /* renamed from: M0 */
    public boolean f1141M0;

    /* renamed from: N0 */
    public C1234lb.C1236b f1142N0;

    /* renamed from: O0 */
    public C1607pb f1143O0;

    /* renamed from: P0 */
    public C0294bb f1144P0;

    /* renamed from: Q0 */
    public C1910tb<C1509ob> f1145Q0;

    /* renamed from: R0 */
    public C0768gd f1146R0;

    /* renamed from: S0 */
    public int f1147S0;

    /* renamed from: X */
    public int f1148X = 0;

    /* renamed from: Y */
    public Bundle f1149Y;

    /* renamed from: Z */
    public SparseArray<Parcelable> f1150Z;

    /* renamed from: a0 */
    public Boolean f1151a0;

    /* renamed from: b0 */
    public String f1152b0 = UUID.randomUUID().toString();

    /* renamed from: c0 */
    public Bundle f1153c0;

    /* renamed from: d0 */
    public Fragment f1154d0;

    /* renamed from: e0 */
    public String f1155e0 = null;

    /* renamed from: f0 */
    public int f1156f0;

    /* renamed from: g0 */
    public Boolean f1157g0 = null;

    /* renamed from: h0 */
    public boolean f1158h0;

    /* renamed from: i0 */
    public boolean f1159i0;

    /* renamed from: j0 */
    public boolean f1160j0;

    /* renamed from: k0 */
    public boolean f1161k0;

    /* renamed from: l0 */
    public boolean f1162l0;

    /* renamed from: m0 */
    public boolean f1163m0;

    /* renamed from: n0 */
    public int f1164n0;

    /* renamed from: o0 */
    public C1002ja f1165o0;

    /* renamed from: p0 */
    public C0848ha f1166p0;

    /* renamed from: q0 */
    public C1002ja f1167q0 = new C1002ja();

    /* renamed from: r0 */
    public Fragment f1168r0;

    /* renamed from: s0 */
    public int f1169s0;

    /* renamed from: t0 */
    public int f1170t0;

    /* renamed from: u0 */
    public String f1171u0;

    /* renamed from: v0 */
    public boolean f1172v0;

    /* renamed from: w0 */
    public boolean f1173w0;

    /* renamed from: x0 */
    public boolean f1174x0;

    /* renamed from: y0 */
    public boolean f1175y0;

    /* renamed from: z0 */
    public boolean f1176z0;

    /* renamed from: androidx.fragment.app.Fragment$a */
    public class C0195a implements Runnable {
        public C0195a() {
        }

        public void run() {
            Fragment.this.mo1450z();
        }
    }

    /* renamed from: androidx.fragment.app.Fragment$b */
    public class C0196b implements Runnable {
        public C0196b() {
        }

        public void run() {
            Fragment.this.mo1423e();
        }
    }

    /* renamed from: androidx.fragment.app.Fragment$c */
    public static class C0197c {

        /* renamed from: a */
        public View f1180a;

        /* renamed from: b */
        public Animator f1181b;

        /* renamed from: c */
        public int f1182c;

        /* renamed from: d */
        public int f1183d;

        /* renamed from: e */
        public int f1184e;

        /* renamed from: f */
        public int f1185f;

        /* renamed from: g */
        public Object f1186g = null;

        /* renamed from: h */
        public Object f1187h;

        /* renamed from: i */
        public Object f1188i;

        /* renamed from: j */
        public Object f1189j;

        /* renamed from: k */
        public Object f1190k;

        /* renamed from: l */
        public Object f1191l;

        /* renamed from: m */
        public Boolean f1192m;

        /* renamed from: n */
        public Boolean f1193n;

        /* renamed from: o */
        public C1900t5 f1194o;

        /* renamed from: p */
        public C1900t5 f1195p;

        /* renamed from: q */
        public boolean f1196q;

        /* renamed from: r */
        public C0199e f1197r;

        /* renamed from: s */
        public boolean f1198s;

        public C0197c() {
            Object obj = Fragment.f1128T0;
            this.f1187h = obj;
            this.f1188i = null;
            this.f1189j = obj;
            this.f1190k = null;
            this.f1191l = obj;
        }
    }

    /* renamed from: androidx.fragment.app.Fragment$d */
    public static class C0198d extends RuntimeException {
        public C0198d(String str, Exception exc) {
            super(str, exc);
        }
    }

    /* renamed from: androidx.fragment.app.Fragment$e */
    public interface C0199e {
    }

    public Fragment() {
        new C0195a();
        this.f1142N0 = C1234lb.C1236b.RESUMED;
        this.f1145Q0 = new C1910tb<>();
        mo1443t();
    }

    @Deprecated
    /* renamed from: a */
    public static Fragment m947a(Context context, String str, Bundle bundle) {
        try {
            Fragment fragment = (Fragment) C0764ga.m5415d(context.getClassLoader(), str).getConstructor(new Class[0]).newInstance(new Object[0]);
            if (bundle != null) {
                bundle.setClassLoader(fragment.getClass().getClassLoader());
                fragment.mo1422d(bundle);
            }
            return fragment;
        } catch (InstantiationException e) {
            throw new C0198d(C0789gk.m5558a("Unable to instantiate fragment ", str, ": make sure class name exists, is public, and has an empty constructor that is public"), e);
        } catch (IllegalAccessException e2) {
            throw new C0198d(C0789gk.m5558a("Unable to instantiate fragment ", str, ": make sure class name exists, is public, and has an empty constructor that is public"), e2);
        } catch (NoSuchMethodException e3) {
            throw new C0198d(C0789gk.m5558a("Unable to instantiate fragment ", str, ": could not find Fragment constructor"), e3);
        } catch (InvocationTargetException e4) {
            throw new C0198d(C0789gk.m5558a("Unable to instantiate fragment ", str, ": calling Fragment constructor caused an exception"), e4);
        }
    }

    /* renamed from: a */
    public View mo1406a(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        int i = this.f1147S0;
        if (i != 0) {
            return layoutInflater.inflate(i, viewGroup, false);
        }
        return null;
    }

    /* renamed from: a */
    public Fragment mo1407a(String str) {
        return str.equals(this.f1152b0) ? this : this.f1167q0.mo7488a(str);
    }

    /* renamed from: a */
    public C1234lb mo635a() {
        return this.f1143O0;
    }

    /* renamed from: a */
    public void mo1408a(int i) {
        if (this.f1136H0 != null || i != 0) {
            mo1425f().f1183d = i;
        }
    }

    /* renamed from: a */
    public void mo1409a(Animator animator) {
        mo1425f().f1181b = animator;
    }

    /* renamed from: a */
    public void mo1410a(Bundle bundle) {
        Parcelable parcelable;
        boolean z = true;
        this.f1130B0 = true;
        if (!(bundle == null || (parcelable = bundle.getParcelable("android:support:fragments")) == null)) {
            this.f1167q0.mo7495a(parcelable);
            this.f1167q0.mo7528d();
        }
        if (this.f1167q0.f8222m0 < 1) {
            z = false;
        }
        if (!z) {
            this.f1167q0.mo7528d();
        }
    }

    /* renamed from: a */
    public void mo1412a(View view) {
        mo1425f().f1180a = view;
    }

    /* renamed from: a */
    public void mo1414a(boolean z) {
        this.f1167q0.mo7509a(z);
    }

    /* renamed from: a */
    public boolean mo1415a(Menu menu) {
        boolean z = false;
        if (this.f1172v0) {
            return false;
        }
        if (this.f1176z0 && this.f1129A0) {
            z = true;
        }
        return z | this.f1167q0.mo7518b(menu);
    }

    /* renamed from: a */
    public boolean mo1416a(Menu menu, MenuInflater menuInflater) {
        boolean z = false;
        if (this.f1172v0) {
            return false;
        }
        if (this.f1176z0 && this.f1129A0) {
            z = true;
        }
        return z | this.f1167q0.mo7510a(menu, menuInflater);
    }

    /* renamed from: b */
    public void mo1417b(Bundle bundle) {
    }

    /* renamed from: b */
    public void mo1418b(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f1167q0.mo7552m();
        boolean z = true;
        this.f1163m0 = true;
        this.f1144P0 = new C0294bb();
        this.f1132D0 = mo1406a(layoutInflater, viewGroup, bundle);
        if (this.f1132D0 != null) {
            C0294bb bbVar = this.f1144P0;
            if (bbVar.f1793X == null) {
                bbVar.f1793X = new C1607pb(bbVar);
            }
            this.f1145Q0.mo1480a(this.f1144P0);
            return;
        }
        if (this.f1144P0.f1793X == null) {
            z = false;
        }
        if (!z) {
            this.f1144P0 = null;
            return;
        }
        throw new IllegalStateException("Called getViewLifecycleOwner() but onCreateView() returned null");
    }

    /* renamed from: b */
    public void mo1419b(boolean z) {
        this.f1167q0.mo7517b(z);
    }

    /* renamed from: c */
    public final C0677fd mo637c() {
        return this.f1146R0.f6093b;
    }

    /* renamed from: c */
    public void mo1421c(boolean z) {
        mo1425f().f1198s = z;
    }

    /* renamed from: d */
    public C0091ac mo638d() {
        C1002ja jaVar = this.f1165o0;
        if (jaVar != null) {
            return jaVar.f8207C0.mo9582d(this);
        }
        throw new IllegalStateException("Can't access ViewModels from detached fragment");
    }

    /* renamed from: e */
    public void mo1423e() {
        C0197c cVar = this.f1136H0;
        Object obj = null;
        if (cVar != null) {
            cVar.f1196q = false;
            Object obj2 = cVar.f1197r;
            cVar.f1197r = null;
            obj = obj2;
        }
        if (obj != null) {
            C1002ja.C1011i iVar = (C1002ja.C1011i) obj;
            iVar.f8251c--;
            if (iVar.f8251c == 0) {
                iVar.f8250b.f280r.mo7554o();
            }
        }
    }

    public final boolean equals(Object obj) {
        return super.equals(obj);
    }

    /* renamed from: f */
    public final C0197c mo1425f() {
        if (this.f1136H0 == null) {
            this.f1136H0 = new C0197c();
        }
        return this.f1136H0;
    }

    /* renamed from: g */
    public View mo1426g() {
        C0197c cVar = this.f1136H0;
        if (cVar == null) {
            return null;
        }
        return cVar.f1180a;
    }

    /* renamed from: h */
    public Animator mo1427h() {
        C0197c cVar = this.f1136H0;
        if (cVar == null) {
            return null;
        }
        return cVar.f1181b;
    }

    public final int hashCode() {
        return super.hashCode();
    }

    /* renamed from: i */
    public final C0921ia mo1429i() {
        if (this.f1166p0 != null) {
            return this.f1167q0;
        }
        throw new IllegalStateException(C0789gk.m5555a("Fragment ", this, " has not been attached yet."));
    }

    /* renamed from: j */
    public Context mo1430j() {
        C0848ha haVar = this.f1166p0;
        if (haVar == null) {
            return null;
        }
        return haVar.f6669Y;
    }

    /* renamed from: k */
    public Object mo1431k() {
        C0197c cVar = this.f1136H0;
        if (cVar == null) {
            return null;
        }
        return cVar.f1186g;
    }

    /* renamed from: l */
    public void mo1432l() {
        C0197c cVar = this.f1136H0;
        if (cVar != null) {
            C1900t5 t5Var = cVar.f1194o;
        }
    }

    /* renamed from: m */
    public Object mo1433m() {
        C0197c cVar = this.f1136H0;
        if (cVar == null) {
            return null;
        }
        return cVar.f1188i;
    }

    /* renamed from: n */
    public int mo1434n() {
        C0197c cVar = this.f1136H0;
        if (cVar == null) {
            return 0;
        }
        return cVar.f1183d;
    }

    /* renamed from: o */
    public int mo1435o() {
        C0197c cVar = this.f1136H0;
        if (cVar == null) {
            return 0;
        }
        return cVar.f1184e;
    }

    public void onConfigurationChanged(Configuration configuration) {
        this.f1130B0 = true;
    }

    public void onCreateContextMenu(ContextMenu contextMenu, View view, ContextMenu.ContextMenuInfo contextMenuInfo) {
        FragmentActivity fragmentActivity;
        C0848ha haVar = this.f1166p0;
        if (haVar == null) {
            fragmentActivity = null;
        } else {
            fragmentActivity = (FragmentActivity) haVar.f6668X;
        }
        if (fragmentActivity != null) {
            fragmentActivity.onCreateContextMenu(contextMenu, view, contextMenuInfo);
            return;
        }
        throw new IllegalStateException(C0789gk.m5555a("Fragment ", this, " not attached to an activity."));
    }

    public void onLowMemory() {
        this.f1130B0 = true;
    }

    /* renamed from: p */
    public int mo1439p() {
        C0197c cVar = this.f1136H0;
        if (cVar == null) {
            return 0;
        }
        return cVar.f1185f;
    }

    /* renamed from: q */
    public final Resources mo1440q() {
        Context j = mo1430j();
        if (j != null) {
            return j.getResources();
        }
        throw new IllegalStateException(C0789gk.m5555a("Fragment ", this, " not attached to a context."));
    }

    /* renamed from: r */
    public Object mo1441r() {
        C0197c cVar = this.f1136H0;
        if (cVar == null) {
            return null;
        }
        return cVar.f1190k;
    }

    /* renamed from: s */
    public int mo1442s() {
        C0197c cVar = this.f1136H0;
        if (cVar == null) {
            return 0;
        }
        return cVar.f1182c;
    }

    /* renamed from: t */
    public final void mo1443t() {
        this.f1143O0 = new C1607pb(this);
        this.f1146R0 = new C0768gd(this);
        int i = Build.VERSION.SDK_INT;
        this.f1143O0.mo8347a((C1417nb) new C1321mb() {
            /* renamed from: a */
            public void mo644a(C1509ob obVar, C1234lb.C1235a aVar) {
                View view;
                if (aVar == C1234lb.C1235a.ON_STOP && (view = Fragment.this.f1132D0) != null) {
                    view.cancelPendingInputEvents();
                }
            }
        });
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        C0815h0.m5819a((Object) this, sb);
        sb.append(" (");
        sb.append(this.f1152b0);
        sb.append(")");
        if (this.f1169s0 != 0) {
            sb.append(" id=0x");
            sb.append(Integer.toHexString(this.f1169s0));
        }
        if (this.f1171u0 != null) {
            sb.append(" ");
            sb.append(this.f1171u0);
        }
        sb.append('}');
        return sb.toString();
    }

    /* renamed from: u */
    public boolean mo1445u() {
        C0197c cVar = this.f1136H0;
        if (cVar == null) {
            return false;
        }
        return cVar.f1198s;
    }

    /* renamed from: v */
    public final boolean mo1446v() {
        return this.f1164n0 > 0;
    }

    /* renamed from: w */
    public void mo1447w() {
    }

    /* renamed from: x */
    public void mo1448x() {
        this.f1130B0 = true;
        this.f1167q0.mo7535f();
    }

    /* renamed from: y */
    public final View mo1449y() {
        View view = this.f1132D0;
        if (view != null) {
            return view;
        }
        throw new IllegalStateException(C0789gk.m5555a("Fragment ", this, " did not return a View from onCreateView() or this was called before onCreateView()."));
    }

    /* renamed from: z */
    public void mo1450z() {
        C1002ja jaVar = this.f1165o0;
        if (jaVar == null || jaVar.f8223n0 == null) {
            mo1425f().f1196q = false;
        } else if (Looper.myLooper() != this.f1165o0.f8223n0.f6670Z.getLooper()) {
            this.f1165o0.f8223n0.f6670Z.postAtFrontOfQueue(new C0196b());
        } else {
            mo1423e();
        }
    }

    /* renamed from: c */
    public LayoutInflater mo1420c(Bundle bundle) {
        C0848ha haVar = this.f1166p0;
        if (haVar != null) {
            FragmentActivity.C0200a aVar = (FragmentActivity.C0200a) haVar;
            LayoutInflater cloneInContext = FragmentActivity.this.getLayoutInflater().cloneInContext(FragmentActivity.this);
            C1002ja jaVar = this.f1167q0;
            jaVar.mo7548k();
            C0815h0.m5846b(cloneInContext, (LayoutInflater.Factory2) jaVar);
            this.f1140L0 = cloneInContext;
            return this.f1140L0;
        }
        throw new IllegalStateException("onGetLayoutInflater() cannot be executed until the Fragment is attached to the FragmentManager.");
    }

    /* renamed from: d */
    public void mo1422d(Bundle bundle) {
        C1002ja jaVar = this.f1165o0;
        if (jaVar != null) {
            if (jaVar == null ? false : jaVar.mo7551l()) {
                throw new IllegalStateException("Fragment already added and state has been saved");
            }
        }
        this.f1153c0 = bundle;
    }

    /* renamed from: a */
    public void mo1411a(AttributeSet attributeSet, Bundle bundle) {
        this.f1130B0 = true;
        C0848ha haVar = this.f1166p0;
        if ((haVar == null ? null : haVar.f6668X) != null) {
            this.f1130B0 = false;
            this.f1130B0 = true;
        }
    }

    /* renamed from: a */
    public void mo1413a(C0199e eVar) {
        mo1425f();
        C0199e eVar2 = this.f1136H0.f1197r;
        if (eVar != eVar2) {
            if (eVar == null || eVar2 == null) {
                C0197c cVar = this.f1136H0;
                if (cVar.f1196q) {
                    cVar.f1197r = eVar;
                }
                if (eVar != null) {
                    ((C1002ja.C1011i) eVar).f8251c++;
                    return;
                }
                return;
            }
            throw new IllegalStateException("Trying to set a replacement startPostponedEnterTransition on " + this);
        }
    }
}
