package androidx.fragment.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import androidx.activity.ComponentActivity;
import androidx.activity.OnBackPressedDispatcher;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import p000.C1234lb;
import p000.C1669q5;

public class FragmentActivity extends ComponentActivity implements C1669q5.C1670a, C1669q5.C1671b {

    /* renamed from: d0 */
    public final C0673fa f1199d0;

    /* renamed from: e0 */
    public final C1607pb f1200e0 = new C1607pb(this);

    /* renamed from: f0 */
    public boolean f1201f0;

    /* renamed from: g0 */
    public boolean f1202g0;

    /* renamed from: h0 */
    public boolean f1203h0 = true;

    /* renamed from: i0 */
    public boolean f1204i0;

    /* renamed from: j0 */
    public boolean f1205j0;

    /* renamed from: k0 */
    public int f1206k0;

    /* renamed from: l0 */
    public C0829h5<String> f1207l0;

    /* renamed from: androidx.fragment.app.FragmentActivity$a */
    public class C0200a extends C0848ha<FragmentActivity> implements C0296bc, C0331c {
        public C0200a() {
            super(FragmentActivity.this);
        }

        /* renamed from: a */
        public View mo1476a(int i) {
            return FragmentActivity.this.findViewById(i);
        }

        /* renamed from: a */
        public C1234lb mo635a() {
            return FragmentActivity.this.f1200e0;
        }

        /* renamed from: b */
        public OnBackPressedDispatcher mo636b() {
            return FragmentActivity.this.mo636b();
        }

        /* renamed from: c */
        public boolean mo1477c() {
            Window window = FragmentActivity.this.getWindow();
            return (window == null || window.peekDecorView() == null) ? false : true;
        }

        /* renamed from: d */
        public C0091ac mo638d() {
            return FragmentActivity.this.mo638d();
        }
    }

    public FragmentActivity() {
        C0200a aVar = new C0200a();
        C0815h0.m5790a(aVar, (Object) "callbacks == null");
        this.f1199d0 = new C0673fa(aVar);
    }

    /* renamed from: a */
    public static void m991a(int i) {
        if ((i & -65536) != 0) {
            throw new IllegalArgumentException("Can only use lower 16 bits for requestCode");
        }
    }

    /* renamed from: a */
    public final View mo1453a(View view, String str, Context context, AttributeSet attributeSet) {
        return this.f1199d0.f5200a.f6672b0.onCreateView(view, str, context, attributeSet);
    }

    @Deprecated
    /* renamed from: a */
    public boolean mo1454a(View view, Menu menu) {
        return super.onPreparePanel(0, view, menu);
    }

    public void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        super.dump(str, fileDescriptor, printWriter, strArr);
        printWriter.print(str);
        printWriter.print("Local FragmentActivity ");
        printWriter.print(Integer.toHexString(System.identityHashCode(this)));
        printWriter.println(" State:");
        String str2 = str + "  ";
        printWriter.print(str2);
        printWriter.print("mCreated=");
        printWriter.print(this.f1201f0);
        printWriter.print(" mResumed=");
        printWriter.print(this.f1202g0);
        printWriter.print(" mStopped=");
        printWriter.print(this.f1203h0);
        if (getApplication() != null) {
            ((C0527dc) C0367cc.m2419a(this)).f3793b.mo4722a(str2, fileDescriptor, printWriter, strArr);
        }
        this.f1199d0.f5200a.f6672b0.mo6883a(str, fileDescriptor, printWriter, strArr);
    }

    /* renamed from: h */
    public C0921ia mo1456h() {
        return this.f1199d0.f5200a.f6672b0;
    }

    /* renamed from: i */
    public void mo1457i() {
    }

    /* renamed from: j */
    public void mo1458j() {
        this.f1200e0.mo9940a(C1234lb.C1235a.ON_RESUME);
        this.f1199d0.f5200a.f6672b0.mo7541h();
    }

    @Deprecated
    /* renamed from: k */
    public void mo675k() {
        invalidateOptionsMenu();
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        this.f1199d0.mo5532a();
        int i3 = i >> 16;
        if (i3 != 0) {
            int i4 = i3 - 1;
            String a = this.f1207l0.mo6415a(i4);
            this.f1207l0.mo6421c(i4);
            if (a == null) {
                Log.w("FragmentActivity", "Activity result delivered for unknown Fragment.");
            } else if (this.f1199d0.f5200a.f6672b0.mo7488a(a) == null) {
                Log.w("FragmentActivity", "Activity result no fragment exists for who: " + a);
            }
        } else {
            C1669q5.m11513a();
            super.onActivityResult(i, i2, intent);
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f1199d0.mo5532a();
        this.f1199d0.f5200a.f6672b0.mo7494a(configuration);
    }

    public void onCreate(Bundle bundle) {
        C0848ha<?> haVar = this.f1199d0.f5200a;
        haVar.f6672b0.mo7505a((C0848ha) haVar, (C0594ea) haVar, (Fragment) null);
        if (bundle != null) {
            Parcelable parcelable = bundle.getParcelable("android:support:fragments");
            C0848ha<?> haVar2 = this.f1199d0.f5200a;
            if (haVar2 instanceof C0296bc) {
                haVar2.f6672b0.mo7495a(parcelable);
                if (bundle.containsKey("android:support:next_request_index")) {
                    this.f1206k0 = bundle.getInt("android:support:next_request_index");
                    int[] intArray = bundle.getIntArray("android:support:request_indicies");
                    String[] stringArray = bundle.getStringArray("android:support:request_fragment_who");
                    if (intArray == null || stringArray == null || intArray.length != stringArray.length) {
                        Log.w("FragmentActivity", "Invalid requestCode mapping in savedInstanceState.");
                    } else {
                        this.f1207l0 = new C0829h5<>(intArray.length);
                        for (int i = 0; i < intArray.length; i++) {
                            this.f1207l0.mo6422c(intArray[i], stringArray[i]);
                        }
                    }
                }
            } else {
                throw new IllegalStateException("Your FragmentHostCallback must implement ViewModelStoreOwner to call restoreSaveState(). Call restoreAllState()  if you're still using retainNestedNonConfig().");
            }
        }
        if (this.f1207l0 == null) {
            this.f1207l0 = new C0829h5<>(10);
            this.f1206k0 = 0;
        }
        super.onCreate(bundle);
        this.f1200e0.mo9940a(C1234lb.C1235a.ON_CREATE);
        this.f1199d0.f5200a.f6672b0.mo7528d();
    }

    public boolean onCreatePanelMenu(int i, Menu menu) {
        if (i != 0) {
            return super.onCreatePanelMenu(i, menu);
        }
        boolean onCreatePanelMenu = super.onCreatePanelMenu(i, menu);
        C0673fa faVar = this.f1199d0;
        return onCreatePanelMenu | faVar.f5200a.f6672b0.mo7510a(menu, getMenuInflater());
    }

    public View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        View a = mo1453a(view, str, context, attributeSet);
        return a == null ? super.onCreateView(view, str, context, attributeSet) : a;
    }

    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        View a = mo1453a((View) null, str, context, attributeSet);
        return a == null ? super.onCreateView(str, context, attributeSet) : a;
    }

    public void onDestroy() {
        super.onDestroy();
        this.f1199d0.f5200a.f6672b0.mo7532e();
        this.f1200e0.mo9940a(C1234lb.C1235a.ON_DESTROY);
    }

    public void onLowMemory() {
        super.onLowMemory();
        this.f1199d0.f5200a.f6672b0.mo7535f();
    }

    public boolean onMenuItemSelected(int i, MenuItem menuItem) {
        if (super.onMenuItemSelected(i, menuItem)) {
            return true;
        }
        if (i == 0) {
            return this.f1199d0.f5200a.f6672b0.mo7519b(menuItem);
        }
        if (i != 6) {
            return false;
        }
        return this.f1199d0.f5200a.f6672b0.mo7511a(menuItem);
    }

    public void onMultiWindowModeChanged(boolean z) {
        this.f1199d0.f5200a.f6672b0.mo7509a(z);
    }

    public void onNewIntent(@SuppressLint({"UnknownNullness"}) Intent intent) {
        super.onNewIntent(intent);
        this.f1199d0.mo5532a();
    }

    public void onPanelClosed(int i, Menu menu) {
        if (i == 0) {
            this.f1199d0.f5200a.f6672b0.mo7496a(menu);
        }
        super.onPanelClosed(i, menu);
    }

    public void onPause() {
        super.onPause();
        this.f1202g0 = false;
        this.f1199d0.f5200a.f6672b0.mo7538g();
        this.f1200e0.mo9940a(C1234lb.C1235a.ON_PAUSE);
    }

    public void onPictureInPictureModeChanged(boolean z) {
        this.f1199d0.f5200a.f6672b0.mo7517b(z);
    }

    public void onPostResume() {
        super.onPostResume();
        mo1458j();
    }

    public boolean onPreparePanel(int i, View view, Menu menu) {
        if (i == 0) {
            return mo1454a(view, menu) | this.f1199d0.f5200a.f6672b0.mo7518b(menu);
        }
        return super.onPreparePanel(i, view, menu);
    }

    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        this.f1199d0.mo5532a();
        int i2 = (i >> 16) & 65535;
        if (i2 != 0) {
            int i3 = i2 - 1;
            String a = this.f1207l0.mo6415a(i3);
            this.f1207l0.mo6421c(i3);
            if (a == null) {
                Log.w("FragmentActivity", "Activity result delivered for unknown Fragment.");
            } else if (this.f1199d0.f5200a.f6672b0.mo7488a(a) == null) {
                Log.w("FragmentActivity", "Activity result no fragment exists for who: " + a);
            }
        }
    }

    public void onResume() {
        super.onResume();
        this.f1202g0 = true;
        this.f1199d0.mo5532a();
        this.f1199d0.f5200a.f6672b0.mo7545i();
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        do {
        } while (m992a(mo1456h(), C1234lb.C1236b.CREATED));
        this.f1200e0.mo9940a(C1234lb.C1235a.ON_STOP);
        Parcelable n = this.f1199d0.f5200a.f6672b0.mo7553n();
        if (n != null) {
            bundle.putParcelable("android:support:fragments", n);
        }
        if (this.f1207l0.mo6418b() > 0) {
            bundle.putInt("android:support:next_request_index", this.f1206k0);
            int[] iArr = new int[this.f1207l0.mo6418b()];
            String[] strArr = new String[this.f1207l0.mo6418b()];
            for (int i = 0; i < this.f1207l0.mo6418b(); i++) {
                iArr[i] = this.f1207l0.mo6419b(i);
                strArr[i] = this.f1207l0.mo6424d(i);
            }
            bundle.putIntArray("android:support:request_indicies", iArr);
            bundle.putStringArray("android:support:request_fragment_who", strArr);
        }
    }

    public void onStart() {
        super.onStart();
        this.f1203h0 = false;
        if (!this.f1201f0) {
            this.f1201f0 = true;
            C1002ja jaVar = this.f1199d0.f5200a.f6672b0;
            jaVar.f8228s0 = false;
            jaVar.f8229t0 = false;
            jaVar.mo7490a(2);
        }
        this.f1199d0.mo5532a();
        this.f1199d0.f5200a.f6672b0.mo7545i();
        this.f1200e0.mo9940a(C1234lb.C1235a.ON_START);
        C1002ja jaVar2 = this.f1199d0.f5200a.f6672b0;
        jaVar2.f8228s0 = false;
        jaVar2.f8229t0 = false;
        jaVar2.mo7490a(3);
    }

    public void onStateNotSaved() {
        this.f1199d0.mo5532a();
    }

    public void onStop() {
        super.onStop();
        this.f1203h0 = true;
        do {
        } while (m992a(mo1456h(), C1234lb.C1236b.CREATED));
        C1002ja jaVar = this.f1199d0.f5200a.f6672b0;
        jaVar.f8229t0 = true;
        jaVar.mo7490a(2);
        this.f1200e0.mo9940a(C1234lb.C1235a.ON_STOP);
    }

    public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent intent, int i) {
        if (!this.f1205j0 && i != -1) {
            m991a(i);
        }
        super.startActivityForResult(intent, i);
    }

    public void startActivityForResult(@SuppressLint({"UnknownNullness"}) Intent intent, int i, Bundle bundle) {
        if (!this.f1205j0 && i != -1) {
            m991a(i);
        }
        super.startActivityForResult(intent, i, bundle);
    }

    public void startIntentSenderForResult(@SuppressLint({"UnknownNullness"}) IntentSender intentSender, int i, Intent intent, int i2, int i3, int i4) {
        if (!this.f1204i0 && i != -1) {
            m991a(i);
        }
        super.startIntentSenderForResult(intentSender, i, intent, i2, i3, i4);
    }

    public void startIntentSenderForResult(@SuppressLint({"UnknownNullness"}) IntentSender intentSender, int i, Intent intent, int i2, int i3, int i4, Bundle bundle) {
        if (!this.f1204i0 && i != -1) {
            m991a(i);
        }
        super.startIntentSenderForResult(intentSender, i, intent, i2, i3, i4, bundle);
    }

    /* renamed from: a */
    public static boolean m992a(C0921ia iaVar, C1234lb.C1236b bVar) {
        FragmentActivity fragmentActivity;
        boolean z = false;
        for (Fragment next : iaVar.mo6882a()) {
            if (next != null) {
                if (next.f1143O0.f12333b.mo8348a(C1234lb.C1236b.STARTED)) {
                    next.f1143O0.mo9941a(bVar);
                    z = true;
                }
                C0848ha haVar = next.f1166p0;
                if (haVar == null) {
                    fragmentActivity = null;
                } else {
                    fragmentActivity = FragmentActivity.this;
                }
                if (fragmentActivity != null) {
                    z |= m992a(next.mo1429i(), bVar);
                }
            }
        }
        return z;
    }
}
