package androidx.browser.browseractions;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;

public class BrowserActionsFallbackMenuView extends LinearLayout {

    /* renamed from: a0 */
    public final int f998a0 = getResources().getDimensionPixelOffset(C1219l4.browser_actions_context_menu_min_padding);

    /* renamed from: b0 */
    public final int f999b0 = getResources().getDimensionPixelOffset(C1219l4.browser_actions_context_menu_max_width);

    public BrowserActionsFallbackMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public void onMeasure(int i, int i2) {
        super.onMeasure(View.MeasureSpec.makeMeasureSpec(Math.min(getResources().getDisplayMetrics().widthPixels - (this.f998a0 * 2), this.f999b0), 1073741824), i2);
    }
}
