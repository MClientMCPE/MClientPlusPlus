package androidx.lifecycle;

import p000.C1234lb;

public class CompositeGeneratedAdaptersObserver implements C1321mb {

    /* renamed from: a */
    public final C1013jb[] f1209a;

    public CompositeGeneratedAdaptersObserver(C1013jb[] jbVarArr) {
        this.f1209a = jbVarArr;
    }

    /* renamed from: a */
    public void mo644a(C1509ob obVar, C1234lb.C1235a aVar) {
        C1845sb sbVar = new C1845sb();
        for (C1013jb a : this.f1209a) {
            a.mo7577a(obVar, aVar, false, sbVar);
        }
        for (C1013jb a2 : this.f1209a) {
            a2.mo7577a(obVar, aVar, true, sbVar);
        }
    }
}
