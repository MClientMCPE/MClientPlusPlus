package androidx.lifecycle;

import java.util.Map;
import p000.C1234lb;

public abstract class LiveData<T> {

    /* renamed from: i */
    public static final Object f1213i = new Object();

    /* renamed from: a */
    public final Object f1214a = new Object();

    /* renamed from: b */
    public C1121k4<C2006ub<? super T>, LiveData<T>.C0275b> f1215b = new C1121k4<>();

    /* renamed from: c */
    public int f1216c = 0;

    /* renamed from: d */
    public volatile Object f1217d;

    /* renamed from: e */
    public volatile Object f1218e;

    /* renamed from: f */
    public int f1219f;

    /* renamed from: g */
    public boolean f1220g;

    /* renamed from: h */
    public boolean f1221h;

    public class LifecycleBoundObserver extends LiveData<T>.C0275b implements C1138kb {

        /* renamed from: e */
        public final C1509ob f1222e;

        /* renamed from: f */
        public final /* synthetic */ LiveData f1223f;

        /* renamed from: a */
        public void mo1484a() {
            ((C1607pb) this.f1222e.mo635a()).f12332a.remove(this);
        }

        /* renamed from: b */
        public boolean mo1485b() {
            return ((C1607pb) this.f1222e.mo635a()).f12333b.mo8348a(C1234lb.C1236b.STARTED);
        }

        /* renamed from: a */
        public void mo644a(C1509ob obVar, C1234lb.C1235a aVar) {
            if (((C1607pb) this.f1222e.mo635a()).f12333b == C1234lb.C1236b.DESTROYED) {
                this.f1223f.mo1481a(this.f1225a);
            } else {
                mo1487a(mo1485b());
            }
        }
    }

    /* renamed from: androidx.lifecycle.LiveData$a */
    public class C0201a implements Runnable {
        public C0201a() {
        }

        public void run() {
            Object obj;
            synchronized (LiveData.this.f1214a) {
                obj = LiveData.this.f1218e;
                LiveData.this.f1218e = LiveData.f1213i;
            }
            LiveData.this.mo1480a(obj);
        }
    }

    /* renamed from: androidx.lifecycle.LiveData$b */
    public abstract class C0202b {

        /* renamed from: a */
        public final C2006ub<? super T> f1225a;

        /* renamed from: b */
        public boolean f1226b;

        /* renamed from: c */
        public int f1227c;

        /* renamed from: d */
        public final /* synthetic */ LiveData f1228d;

        /* renamed from: a */
        public void mo1484a() {
        }

        /* renamed from: a */
        public void mo1487a(boolean z) {
            if (z != this.f1226b) {
                this.f1226b = z;
                int i = 1;
                boolean z2 = this.f1228d.f1216c == 0;
                LiveData liveData = this.f1228d;
                int i2 = liveData.f1216c;
                if (!this.f1226b) {
                    i = -1;
                }
                liveData.f1216c = i2 + i;
                if (z2 && this.f1226b) {
                    this.f1228d.mo1478a();
                }
                LiveData liveData2 = this.f1228d;
                if (liveData2.f1216c == 0 && !this.f1226b) {
                    liveData2.mo1482b();
                }
                if (this.f1226b) {
                    this.f1228d.mo1483b(this);
                }
            }
        }

        /* renamed from: b */
        public abstract boolean mo1485b();
    }

    public LiveData() {
        Object obj = f1213i;
        this.f1217d = obj;
        this.f1218e = obj;
        this.f1219f = -1;
        new C0201a();
    }

    /* renamed from: a */
    public static void m1007a(String str) {
        if (!C0749g4.m5256b().mo5883a()) {
            throw new IllegalStateException("Cannot invoke " + str + " on a background" + " thread");
        }
    }

    /* renamed from: a */
    public void mo1478a() {
    }

    /* renamed from: a */
    public final void mo1479a(LiveData<T>.C0275b bVar) {
        if (bVar.f1226b) {
            if (!bVar.mo1485b()) {
                bVar.mo1487a(false);
                return;
            }
            int i = bVar.f1227c;
            int i2 = this.f1219f;
            if (i < i2) {
                bVar.f1227c = i2;
                bVar.f1225a.mo11566a(this.f1217d);
            }
        }
    }

    /* renamed from: a */
    public void mo1480a(T t) {
        m1007a("setValue");
        this.f1219f++;
        this.f1217d = t;
        mo1483b((LiveData<T>.C0275b) null);
    }

    /* renamed from: a */
    public void mo1481a(C2006ub<? super T> ubVar) {
        m1007a("removeObserver");
        C0202b remove = this.f1215b.remove(ubVar);
        if (remove != null) {
            remove.mo1484a();
            remove.mo1487a(false);
        }
    }

    /* renamed from: b */
    public void mo1482b() {
    }

    /* renamed from: b */
    public void mo1483b(LiveData<T>.C0275b bVar) {
        if (this.f1220g) {
            this.f1221h = true;
            return;
        }
        this.f1220g = true;
        do {
            this.f1221h = false;
            if (bVar == null) {
                C1121k4<K, V>.C0502d c = this.f1215b.mo7862c();
                while (c.hasNext()) {
                    mo1479a((LiveData<T>.C0275b) (C0202b) ((Map.Entry) c.next()).getValue());
                    if (this.f1221h) {
                        break;
                    }
                }
            } else {
                mo1479a(bVar);
                bVar = null;
            }
        } while (this.f1221h);
        this.f1220g = false;
    }
}
