package androidx.lifecycle;

import p000.C0849hb;
import p000.C1234lb;

public class ReflectiveGenericLifecycleObserver implements C1321mb {

    /* renamed from: a */
    public final Object f1229a;

    /* renamed from: b */
    public final C0849hb.C0850a f1230b = C0849hb.f6678c.mo6477b(this.f1229a.getClass());

    public ReflectiveGenericLifecycleObserver(Object obj) {
        this.f1229a = obj;
    }

    /* renamed from: a */
    public void mo644a(C1509ob obVar, C1234lb.C1235a aVar) {
        C0849hb.C0850a aVar2 = this.f1230b;
        Object obj = this.f1229a;
        C0849hb.C0850a.m6123a(aVar2.f6681a.get(aVar), obVar, aVar, obj);
        C0849hb.C0850a.m6123a(aVar2.f6681a.get(C1234lb.C1235a.ON_ANY), obVar, aVar, obj);
    }
}
