package androidx.lifecycle;

import p000.C1234lb;

public class FullLifecycleObserverAdapter implements C1321mb {

    /* renamed from: a */
    public final C0925ib f1210a;

    /* renamed from: b */
    public final C1321mb f1211b;

    public FullLifecycleObserverAdapter(C0925ib ibVar, C1321mb mbVar) {
        this.f1210a = ibVar;
        this.f1211b = mbVar;
    }

    /* renamed from: a */
    public void mo644a(C1509ob obVar, C1234lb.C1235a aVar) {
        switch (aVar.ordinal()) {
            case 0:
                this.f1210a.mo6890c(obVar);
                break;
            case 1:
                this.f1210a.mo6892e(obVar);
                break;
            case 2:
                this.f1210a.mo6888a(obVar);
                break;
            case 3:
                this.f1210a.mo6891d(obVar);
                break;
            case 4:
                this.f1210a.mo6893f(obVar);
                break;
            case 5:
                this.f1210a.mo6889b(obVar);
                break;
            case 6:
                throw new IllegalArgumentException("ON_ANY must not been send by anybody");
        }
        C1321mb mbVar = this.f1211b;
        if (mbVar != null) {
            mbVar.mo644a(obVar, aVar);
        }
    }
}
