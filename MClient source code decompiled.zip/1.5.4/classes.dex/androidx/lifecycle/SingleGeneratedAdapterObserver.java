package androidx.lifecycle;

import p000.C1234lb;

public class SingleGeneratedAdapterObserver implements C1321mb {

    /* renamed from: a */
    public final C1013jb f1231a;

    public SingleGeneratedAdapterObserver(C1013jb jbVar) {
        this.f1231a = jbVar;
    }

    /* renamed from: a */
    public void mo644a(C1509ob obVar, C1234lb.C1235a aVar) {
        this.f1231a.mo7577a(obVar, aVar, false, (C1845sb) null);
        this.f1231a.mo7577a(obVar, aVar, true, (C1845sb) null);
    }
}
