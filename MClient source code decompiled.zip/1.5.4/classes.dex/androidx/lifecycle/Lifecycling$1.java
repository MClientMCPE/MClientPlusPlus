package androidx.lifecycle;

import p000.C1234lb;

public final class Lifecycling$1 implements C1138kb {

    /* renamed from: a */
    public final /* synthetic */ C1321mb f1212a;

    /* renamed from: a */
    public void mo644a(C1509ob obVar, C1234lb.C1235a aVar) {
        this.f1212a.mo644a(obVar, aVar);
    }
}
