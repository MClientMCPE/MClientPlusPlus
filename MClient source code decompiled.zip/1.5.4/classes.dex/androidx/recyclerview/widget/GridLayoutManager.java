package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import p000.C0759g8;
import p000.C1692qc;

public class GridLayoutManager extends LinearLayoutManager {

    /* renamed from: F0 */
    public boolean f1232F0 = false;

    /* renamed from: G0 */
    public int f1233G0 = -1;

    /* renamed from: H0 */
    public int[] f1234H0;

    /* renamed from: I0 */
    public View[] f1235I0;

    /* renamed from: J0 */
    public final SparseIntArray f1236J0 = new SparseIntArray();

    /* renamed from: K0 */
    public final SparseIntArray f1237K0 = new SparseIntArray();

    /* renamed from: L0 */
    public C0205c f1238L0 = new C0203a();

    /* renamed from: M0 */
    public final Rect f1239M0 = new Rect();

    /* renamed from: N0 */
    public boolean f1240N0;

    /* renamed from: androidx.recyclerview.widget.GridLayoutManager$a */
    public static final class C0203a extends C0205c {
        /* renamed from: a */
        public int mo1529a(int i) {
            return 1;
        }
    }

    /* renamed from: androidx.recyclerview.widget.GridLayoutManager$b */
    public static class C0204b extends RecyclerView.C0237p {

        /* renamed from: b0 */
        public int f1241b0 = -1;

        /* renamed from: c0 */
        public int f1242c0 = 0;

        public C0204b(int i, int i2) {
            super(i, i2);
        }

        public C0204b(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public C0204b(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public C0204b(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }
    }

    /* renamed from: androidx.recyclerview.widget.GridLayoutManager$c */
    public static abstract class C0205c {

        /* renamed from: a */
        public final SparseIntArray f1243a = new SparseIntArray();

        /* renamed from: b */
        public final SparseIntArray f1244b = new SparseIntArray();

        /* renamed from: c */
        public boolean f1245c = false;

        /* renamed from: d */
        public boolean f1246d = false;

        /* renamed from: a */
        public abstract int mo1529a(int i);

        /* renamed from: a */
        public int mo1530a(int i, int i2) {
            if (!this.f1246d) {
                return mo1532c(i, i2);
            }
            int i3 = this.f1244b.get(i, -1);
            if (i3 != -1) {
                return i3;
            }
            int c = mo1532c(i, i2);
            this.f1244b.put(i, c);
            return c;
        }

        /* renamed from: b */
        public int mo1531b(int i, int i2) {
            if (!this.f1245c) {
                C0203a aVar = (C0203a) this;
                return i % i2;
            }
            int i3 = this.f1243a.get(i, -1);
            if (i3 != -1) {
                return i3;
            }
            C0203a aVar2 = (C0203a) this;
            int i4 = i % i2;
            this.f1243a.put(i, i4);
            return i4;
        }

        /* JADX WARNING: Removed duplicated region for block: B:21:0x0051  */
        /* JADX WARNING: Removed duplicated region for block: B:29:0x0064  */
        /* JADX WARNING: Removed duplicated region for block: B:39:? A[RETURN, SYNTHETIC] */
        /* renamed from: c */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public int mo1532c(int r9, int r10) {
            /*
                r8 = this;
                boolean r0 = r8.f1246d
                r1 = 0
                r2 = 1
                if (r0 == 0) goto L_0x0049
                android.util.SparseIntArray r0 = r8.f1244b
                int r3 = r0.size()
                r4 = -1
                int r3 = r3 + r4
                r5 = r3
                r3 = 0
            L_0x0010:
                if (r3 > r5) goto L_0x0021
                int r6 = r3 + r5
                int r6 = r6 >>> r2
                int r7 = r0.keyAt(r6)
                if (r7 >= r9) goto L_0x001e
                int r3 = r6 + 1
                goto L_0x0010
            L_0x001e:
                int r5 = r6 + -1
                goto L_0x0010
            L_0x0021:
                int r3 = r3 + r4
                if (r3 < 0) goto L_0x002f
                int r5 = r0.size()
                if (r3 >= r5) goto L_0x002f
                int r0 = r0.keyAt(r3)
                goto L_0x0030
            L_0x002f:
                r0 = -1
            L_0x0030:
                if (r0 == r4) goto L_0x0049
                android.util.SparseIntArray r3 = r8.f1244b
                int r3 = r3.get(r0)
                int r4 = r0 + 1
                int r0 = r8.mo1531b(r0, r10)
                r5 = r8
                androidx.recyclerview.widget.GridLayoutManager$a r5 = (androidx.recyclerview.widget.GridLayoutManager.C0203a) r5
                int r0 = r0 + r2
                if (r0 != r10) goto L_0x004c
                int r0 = r3 + 1
                r3 = r0
                r0 = 0
                goto L_0x004c
            L_0x0049:
                r0 = 0
                r3 = 0
                r4 = 0
            L_0x004c:
                r5 = r8
                androidx.recyclerview.widget.GridLayoutManager$a r5 = (androidx.recyclerview.widget.GridLayoutManager.C0203a) r5
            L_0x004f:
                if (r4 >= r9) goto L_0x0061
                int r0 = r0 + 1
                if (r0 != r10) goto L_0x0059
                int r3 = r3 + 1
                r0 = 0
                goto L_0x005e
            L_0x0059:
                if (r0 <= r10) goto L_0x005e
                int r3 = r3 + 1
                r0 = 1
            L_0x005e:
                int r4 = r4 + 1
                goto L_0x004f
            L_0x0061:
                int r0 = r0 + r2
                if (r0 <= r10) goto L_0x0066
                int r3 = r3 + 1
            L_0x0066:
                return r3
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.GridLayoutManager.C0205c.mo1532c(int, int):int");
        }
    }

    public GridLayoutManager(Context context, int i) {
        super(1, false);
        mo1528q(i);
    }

    public GridLayoutManager(Context context, int i, int i2, boolean z) {
        super(i2, z);
        mo1528q(i);
    }

    public GridLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        mo1528q(RecyclerView.C0232o.m1222a(context, attributeSet, i, i2).f1368b);
    }

    /* renamed from: I */
    public boolean mo1488I() {
        return this.f1247A0 == null && !this.f1232F0;
    }

    /* renamed from: W */
    public final void mo1489W() {
        View[] viewArr = this.f1235I0;
        if (viewArr == null || viewArr.length != this.f1233G0) {
            this.f1235I0 = new View[this.f1233G0];
        }
    }

    /* renamed from: X */
    public int mo1490X() {
        return this.f1233G0;
    }

    /* renamed from: Y */
    public final void mo1491Y() {
        int i;
        int i2;
        if (mo1543R() == 1) {
            i2 = mo1954p() - getPaddingRight();
            i = getPaddingLeft();
        } else {
            i2 = mo1936i() - getPaddingBottom();
            i = getPaddingTop();
        }
        mo1527p(i2 - i);
    }

    /* renamed from: a */
    public int mo1492a(int i, RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var) {
        mo1491Y();
        mo1489W();
        return super.mo1492a(i, vVar, a0Var);
    }

    /* renamed from: a */
    public int mo1493a(RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var) {
        if (this.f1252p0 == 1) {
            return this.f1233G0;
        }
        if (a0Var.mo1790a() < 1) {
            return 0;
        }
        return mo1494a(vVar, a0Var, a0Var.mo1790a() - 1) + 1;
    }

    /* renamed from: a */
    public final int mo1494a(RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var, int i) {
        if (!a0Var.f1296h) {
            return this.f1238L0.mo1530a(i, this.f1233G0);
        }
        int a = vVar.mo1983a(i);
        if (a != -1) {
            return this.f1238L0.mo1530a(a, this.f1233G0);
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. " + i);
        return 0;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:55:0x00cf, code lost:
        if (r13 == (r2 > r8)) goto L_0x00c5;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:64:0x00e7, code lost:
        if (r13 == (r2 > r12)) goto L_0x00af;
     */
    /* JADX WARNING: Removed duplicated region for block: B:68:0x00f0  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.View mo1495a(android.view.View r23, int r24, androidx.recyclerview.widget.RecyclerView.C0244v r25, androidx.recyclerview.widget.RecyclerView.C0212a0 r26) {
        /*
            r22 = this;
            r0 = r22
            r1 = r25
            r2 = r26
            android.view.View r3 = r22.mo1912d((android.view.View) r23)
            r4 = 0
            if (r3 != 0) goto L_0x000e
            return r4
        L_0x000e:
            android.view.ViewGroup$LayoutParams r5 = r3.getLayoutParams()
            androidx.recyclerview.widget.GridLayoutManager$b r5 = (androidx.recyclerview.widget.GridLayoutManager.C0204b) r5
            int r6 = r5.f1241b0
            int r5 = r5.f1242c0
            int r5 = r5 + r6
            android.view.View r7 = super.mo1495a((android.view.View) r23, (int) r24, (androidx.recyclerview.widget.RecyclerView.C0244v) r25, (androidx.recyclerview.widget.RecyclerView.C0212a0) r26)
            if (r7 != 0) goto L_0x0020
            return r4
        L_0x0020:
            r7 = r24
            int r7 = r0.mo1583n(r7)
            r9 = 1
            if (r7 != r9) goto L_0x002b
            r7 = 1
            goto L_0x002c
        L_0x002b:
            r7 = 0
        L_0x002c:
            boolean r10 = r0.f1257u0
            if (r7 == r10) goto L_0x0032
            r7 = 1
            goto L_0x0033
        L_0x0032:
            r7 = 0
        L_0x0033:
            r10 = -1
            if (r7 == 0) goto L_0x003e
            int r7 = r22.mo1921f()
            int r7 = r7 - r9
            r11 = -1
            r12 = -1
            goto L_0x0045
        L_0x003e:
            int r7 = r22.mo1921f()
            r11 = r7
            r7 = 0
            r12 = 1
        L_0x0045:
            int r13 = r0.f1252p0
            if (r13 != r9) goto L_0x0051
            boolean r13 = r22.mo1544S()
            if (r13 == 0) goto L_0x0051
            r13 = 1
            goto L_0x0052
        L_0x0051:
            r13 = 0
        L_0x0052:
            int r14 = r0.mo1494a((androidx.recyclerview.widget.RecyclerView.C0244v) r1, (androidx.recyclerview.widget.RecyclerView.C0212a0) r2, (int) r7)
            r10 = r4
            r16 = r12
            r8 = -1
            r9 = 0
            r12 = -1
            r15 = 0
        L_0x005d:
            if (r7 == r11) goto L_0x0127
            r17 = r11
            int r11 = r0.mo1494a((androidx.recyclerview.widget.RecyclerView.C0244v) r1, (androidx.recyclerview.widget.RecyclerView.C0212a0) r2, (int) r7)
            android.view.View r1 = r0.mo1925g((int) r7)
            if (r1 != r3) goto L_0x006d
            goto L_0x0127
        L_0x006d:
            boolean r18 = r1.hasFocusable()
            if (r18 == 0) goto L_0x0082
            if (r11 == r14) goto L_0x0082
            if (r4 == 0) goto L_0x0079
            goto L_0x0127
        L_0x0079:
            r18 = r3
            r19 = r8
            r21 = r10
            r8 = 0
            goto L_0x0117
        L_0x0082:
            android.view.ViewGroup$LayoutParams r11 = r1.getLayoutParams()
            androidx.recyclerview.widget.GridLayoutManager$b r11 = (androidx.recyclerview.widget.GridLayoutManager.C0204b) r11
            int r2 = r11.f1241b0
            r18 = r3
            int r3 = r11.f1242c0
            int r3 = r3 + r2
            boolean r19 = r1.hasFocusable()
            if (r19 == 0) goto L_0x009a
            if (r2 != r6) goto L_0x009a
            if (r3 != r5) goto L_0x009a
            return r1
        L_0x009a:
            boolean r19 = r1.hasFocusable()
            if (r19 == 0) goto L_0x00a2
            if (r4 == 0) goto L_0x00aa
        L_0x00a2:
            boolean r19 = r1.hasFocusable()
            if (r19 != 0) goto L_0x00b1
            if (r10 != 0) goto L_0x00b1
        L_0x00aa:
            r19 = r8
            r21 = r10
        L_0x00ae:
            r8 = 0
        L_0x00af:
            r10 = 1
            goto L_0x00ee
        L_0x00b1:
            int r19 = java.lang.Math.max(r2, r6)
            int r20 = java.lang.Math.min(r3, r5)
            r21 = r10
            int r10 = r20 - r19
            boolean r19 = r1.hasFocusable()
            if (r19 == 0) goto L_0x00d2
            if (r10 <= r15) goto L_0x00c8
        L_0x00c5:
            r19 = r8
            goto L_0x00ae
        L_0x00c8:
            if (r10 != r15) goto L_0x00ea
            if (r2 <= r8) goto L_0x00ce
            r10 = 1
            goto L_0x00cf
        L_0x00ce:
            r10 = 0
        L_0x00cf:
            if (r13 != r10) goto L_0x00ea
            goto L_0x00c5
        L_0x00d2:
            if (r4 != 0) goto L_0x00ea
            r19 = r8
            r8 = 0
            boolean r20 = r0.mo1892a((android.view.View) r1, (boolean) r8)
            if (r20 == 0) goto L_0x00ed
            if (r10 <= r9) goto L_0x00e0
        L_0x00df:
            goto L_0x00af
        L_0x00e0:
            if (r10 != r9) goto L_0x00ed
            if (r2 <= r12) goto L_0x00e6
            r10 = 1
            goto L_0x00e7
        L_0x00e6:
            r10 = 0
        L_0x00e7:
            if (r13 != r10) goto L_0x00ed
            goto L_0x00df
        L_0x00ea:
            r19 = r8
            r8 = 0
        L_0x00ed:
            r10 = 0
        L_0x00ee:
            if (r10 == 0) goto L_0x0117
            boolean r10 = r1.hasFocusable()
            if (r10 == 0) goto L_0x0108
            int r4 = r11.f1241b0
            int r3 = java.lang.Math.min(r3, r5)
            int r2 = java.lang.Math.max(r2, r6)
            int r3 = r3 - r2
            r15 = r3
            r19 = r4
            r10 = r21
            r4 = r1
            goto L_0x0119
        L_0x0108:
            int r9 = r11.f1241b0
            int r3 = java.lang.Math.min(r3, r5)
            int r2 = java.lang.Math.max(r2, r6)
            int r3 = r3 - r2
            r10 = r1
            r12 = r9
            r9 = r3
            goto L_0x0119
        L_0x0117:
            r10 = r21
        L_0x0119:
            int r7 = r7 + r16
            r1 = r25
            r2 = r26
            r11 = r17
            r3 = r18
            r8 = r19
            goto L_0x005d
        L_0x0127:
            r21 = r10
            if (r4 == 0) goto L_0x012c
            goto L_0x012e
        L_0x012c:
            r4 = r21
        L_0x012e:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.GridLayoutManager.mo1495a(android.view.View, int, androidx.recyclerview.widget.RecyclerView$v, androidx.recyclerview.widget.RecyclerView$a0):android.view.View");
    }

    /* renamed from: a */
    public View mo1496a(RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var, int i, int i2, int i3) {
        mo1536K();
        int f = this.f1254r0.mo12243f();
        int b = this.f1254r0.mo12235b();
        int i4 = i2 > i ? 1 : -1;
        View view = null;
        View view2 = null;
        while (i != i2) {
            View g = mo1925g(i);
            int m = mo1949m(g);
            if (m >= 0 && m < i3 && mo1512b(vVar, a0Var, m) == 0) {
                if (((RecyclerView.C0237p) g.getLayoutParams()).mo1972p()) {
                    if (view2 == null) {
                        view2 = g;
                    }
                } else if (this.f1254r0.mo12240d(g) < b && this.f1254r0.mo12233a(g) >= f) {
                    return g;
                } else {
                    if (view == null) {
                        view = g;
                    }
                }
            }
            i += i4;
        }
        return view != null ? view : view2;
    }

    /* renamed from: a */
    public RecyclerView.C0237p mo1497a(Context context, AttributeSet attributeSet) {
        return new C0204b(context, attributeSet);
    }

    /* renamed from: a */
    public RecyclerView.C0237p mo1498a(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new C0204b((ViewGroup.MarginLayoutParams) layoutParams) : new C0204b(layoutParams);
    }

    /* renamed from: a */
    public void mo1499a(Rect rect, int i, int i2) {
        int i3;
        int i4;
        if (this.f1234H0 == null) {
            super.mo1499a(rect, i, i2);
        }
        int paddingRight = getPaddingRight() + getPaddingLeft();
        int paddingBottom = getPaddingBottom() + getPaddingTop();
        if (this.f1252p0 == 1) {
            i4 = RecyclerView.C0232o.m1223c(i2, rect.height() + paddingBottom, mo1948m());
            int[] iArr = this.f1234H0;
            i3 = RecyclerView.C0232o.m1223c(i, iArr[iArr.length - 1] + paddingRight, mo1950n());
        } else {
            i3 = RecyclerView.C0232o.m1223c(i, rect.width() + paddingRight, mo1950n());
            int[] iArr2 = this.f1234H0;
            i4 = RecyclerView.C0232o.m1223c(i2, iArr2[iArr2.length - 1] + paddingBottom, mo1948m());
        }
        mo1914d(i3, i4);
    }

    /* renamed from: a */
    public final void mo1500a(View view, int i, int i2, boolean z) {
        RecyclerView.C0237p pVar = (RecyclerView.C0237p) view.getLayoutParams();
        if (z ? mo1906b(view, i, i2, pVar) : mo1890a(view, i, i2, pVar)) {
            view.measure(i, i2);
        }
    }

    /* renamed from: a */
    public void mo1501a(RecyclerView.C0212a0 a0Var, LinearLayoutManager.C0208c cVar, RecyclerView.C0232o.C0235c cVar2) {
        int i = this.f1233G0;
        for (int i2 = 0; i2 < this.f1233G0 && cVar.mo1594a(a0Var) && i > 0; i2++) {
            int i3 = cVar.f1275d;
            ((C1692qc.C1694b) cVar2).mo10309a(i3, Math.max(0, cVar.f1278g));
            this.f1238L0.mo1529a(i3);
            i--;
            cVar.f1275d += cVar.f1276e;
        }
    }

    /* renamed from: a */
    public boolean mo1508a(RecyclerView.C0237p pVar) {
        return pVar instanceof C0204b;
    }

    /* renamed from: b */
    public int mo1509b(int i, RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var) {
        mo1491Y();
        mo1489W();
        return super.mo1509b(i, vVar, a0Var);
    }

    /* renamed from: b */
    public int mo1510b(RecyclerView.C0212a0 a0Var) {
        return this.f1240N0 ? mo1525l(a0Var) : super.mo1510b(a0Var);
    }

    /* renamed from: b */
    public int mo1511b(RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var) {
        if (this.f1252p0 == 0) {
            return this.f1233G0;
        }
        if (a0Var.mo1790a() < 1) {
            return 0;
        }
        return mo1494a(vVar, a0Var, a0Var.mo1790a() - 1) + 1;
    }

    /* renamed from: b */
    public final int mo1512b(RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var, int i) {
        if (!a0Var.f1296h) {
            return this.f1238L0.mo1531b(i, this.f1233G0);
        }
        int i2 = this.f1237K0.get(i, -1);
        if (i2 != -1) {
            return i2;
        }
        int a = vVar.mo1983a(i);
        if (a != -1) {
            return this.f1238L0.mo1531b(a, this.f1233G0);
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:" + i);
        return 0;
    }

    /* renamed from: b */
    public final void mo1513b(View view, int i, boolean z) {
        int i2;
        int i3;
        C0204b bVar = (C0204b) view.getLayoutParams();
        Rect rect = bVar.f1372Y;
        int i4 = rect.top + rect.bottom + bVar.topMargin + bVar.bottomMargin;
        int i5 = rect.left + rect.right + bVar.leftMargin + bVar.rightMargin;
        int i6 = mo1524i(bVar.f1241b0, bVar.f1242c0);
        if (this.f1252p0 == 1) {
            i2 = RecyclerView.C0232o.m1221a(i6, i, i5, bVar.width, false);
            i3 = RecyclerView.C0232o.m1221a(this.f1254r0.mo12245g(), mo1939j(), i4, bVar.height, true);
        } else {
            int a = RecyclerView.C0232o.m1221a(i6, i, i4, bVar.height, false);
            int a2 = RecyclerView.C0232o.m1221a(this.f1254r0.mo12245g(), mo1956q(), i5, bVar.width, true);
            i3 = a;
            i2 = a2;
        }
        mo1500a(view, i2, i3, z);
    }

    /* renamed from: c */
    public int mo1515c(RecyclerView.C0212a0 a0Var) {
        return this.f1240N0 ? mo1526m(a0Var) : super.mo1515c(a0Var);
    }

    /* renamed from: c */
    public final int mo1516c(RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var, int i) {
        if (!a0Var.f1296h) {
            this.f1238L0.mo1529a(i);
            return 1;
        }
        int i2 = this.f1236J0.get(i, -1);
        if (i2 != -1) {
            return i2;
        }
        int a = vVar.mo1983a(i);
        if (a == -1) {
            Log.w("GridLayoutManager", "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:" + i);
            return 1;
        }
        this.f1238L0.mo1529a(a);
        return 1;
    }

    /* renamed from: c */
    public void mo1519c(boolean z) {
        if (!z) {
            super.mo1519c(false);
            return;
        }
        throw new UnsupportedOperationException("GridLayoutManager does not support stack from end. Consider using reverse layout");
    }

    /* renamed from: d */
    public RecyclerView.C0237p mo1520d() {
        return this.f1252p0 == 0 ? new C0204b(-2, -1) : new C0204b(-1, -2);
    }

    /* renamed from: e */
    public int mo1521e(RecyclerView.C0212a0 a0Var) {
        return this.f1240N0 ? mo1525l(a0Var) : super.mo1521e(a0Var);
    }

    /* renamed from: f */
    public int mo1522f(RecyclerView.C0212a0 a0Var) {
        return this.f1240N0 ? mo1526m(a0Var) : super.mo1522f(a0Var);
    }

    /* renamed from: g */
    public void mo1523g(RecyclerView.C0212a0 a0Var) {
        super.mo1523g(a0Var);
        this.f1232F0 = false;
    }

    /* renamed from: i */
    public int mo1524i(int i, int i2) {
        if (this.f1252p0 != 1 || !mo1544S()) {
            int[] iArr = this.f1234H0;
            return iArr[i2 + i] - iArr[i];
        }
        int[] iArr2 = this.f1234H0;
        int i3 = this.f1233G0;
        return iArr2[i3 - i] - iArr2[(i3 - i) - i2];
    }

    /* renamed from: l */
    public final int mo1525l(RecyclerView.C0212a0 a0Var) {
        if (!(mo1921f() == 0 || a0Var.mo1790a() == 0)) {
            mo1536K();
            boolean T = mo1545T();
            View b = mo1564b(!T, true);
            View a = mo1552a(!T, true);
            if (!(b == null || a == null)) {
                int a2 = this.f1238L0.mo1530a(mo1949m(b), this.f1233G0);
                int a3 = this.f1238L0.mo1530a(mo1949m(a), this.f1233G0);
                int min = Math.min(a2, a3);
                int max = this.f1257u0 ? Math.max(0, ((this.f1238L0.mo1530a(a0Var.mo1790a() - 1, this.f1233G0) + 1) - Math.max(a2, a3)) - 1) : Math.max(0, min);
                if (!T) {
                    return max;
                }
                return Math.round((((float) max) * (((float) Math.abs(this.f1254r0.mo12233a(a) - this.f1254r0.mo12240d(b))) / ((float) ((this.f1238L0.mo1530a(mo1949m(a), this.f1233G0) - this.f1238L0.mo1530a(mo1949m(b), this.f1233G0)) + 1)))) + ((float) (this.f1254r0.mo12243f() - this.f1254r0.mo12240d(b))));
            }
        }
        return 0;
    }

    /* renamed from: m */
    public final int mo1526m(RecyclerView.C0212a0 a0Var) {
        if (!(mo1921f() == 0 || a0Var.mo1790a() == 0)) {
            mo1536K();
            View b = mo1564b(!mo1545T(), true);
            View a = mo1552a(!mo1545T(), true);
            if (!(b == null || a == null)) {
                if (!mo1545T()) {
                    return this.f1238L0.mo1530a(a0Var.mo1790a() - 1, this.f1233G0) + 1;
                }
                int a2 = this.f1254r0.mo12233a(a) - this.f1254r0.mo12240d(b);
                int a3 = this.f1238L0.mo1530a(mo1949m(b), this.f1233G0);
                return (int) ((((float) a2) / ((float) ((this.f1238L0.mo1530a(mo1949m(a), this.f1233G0) - a3) + 1))) * ((float) (this.f1238L0.mo1530a(a0Var.mo1790a() - 1, this.f1233G0) + 1)));
            }
        }
        return 0;
    }

    /* renamed from: p */
    public final void mo1527p(int i) {
        int i2;
        int[] iArr = this.f1234H0;
        int i3 = this.f1233G0;
        if (!(iArr != null && iArr.length == i3 + 1 && iArr[iArr.length - 1] == i)) {
            iArr = new int[(i3 + 1)];
        }
        int i4 = 0;
        iArr[0] = 0;
        int i5 = i / i3;
        int i6 = i % i3;
        int i7 = 0;
        for (int i8 = 1; i8 <= i3; i8++) {
            i4 += i6;
            if (i4 <= 0 || i3 - i4 >= i6) {
                i2 = i5;
            } else {
                i2 = i5 + 1;
                i4 -= i3;
            }
            i7 += i2;
            iArr[i8] = i7;
        }
        this.f1234H0 = iArr;
    }

    /* renamed from: q */
    public void mo1528q(int i) {
        if (i != this.f1233G0) {
            this.f1232F0 = true;
            if (i >= 1) {
                this.f1233G0 = i;
                this.f1238L0.f1243a.clear();
                mo1868E();
                return;
            }
            throw new IllegalArgumentException(C0789gk.m5568b("Span count should be at least 1. Provided ", i));
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:100:0x0253  */
    /* JADX WARNING: Removed duplicated region for block: B:101:0x0255  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo1504a(androidx.recyclerview.widget.RecyclerView.C0244v r21, androidx.recyclerview.widget.RecyclerView.C0212a0 r22, androidx.recyclerview.widget.LinearLayoutManager.C0208c r23, androidx.recyclerview.widget.LinearLayoutManager.C0207b r24) {
        /*
            r20 = this;
            r6 = r20
            r0 = r21
            r1 = r22
            r2 = r23
            r7 = r24
            yc r3 = r6.f1254r0
            int r3 = r3.mo12241e()
            r4 = 1073741824(0x40000000, float:2.0)
            r8 = 1
            r5 = 0
            if (r3 == r4) goto L_0x0018
            r9 = 1
            goto L_0x0019
        L_0x0018:
            r9 = 0
        L_0x0019:
            int r10 = r20.mo1921f()
            if (r10 <= 0) goto L_0x0026
            int[] r10 = r6.f1234H0
            int r11 = r6.f1233G0
            r10 = r10[r11]
            goto L_0x0027
        L_0x0026:
            r10 = 0
        L_0x0027:
            if (r9 == 0) goto L_0x002c
            r20.mo1491Y()
        L_0x002c:
            int r11 = r2.f1276e
            if (r11 != r8) goto L_0x0032
            r11 = 1
            goto L_0x0033
        L_0x0032:
            r11 = 0
        L_0x0033:
            int r12 = r6.f1233G0
            if (r11 != 0) goto L_0x0044
            int r12 = r2.f1275d
            int r12 = r6.mo1512b((androidx.recyclerview.widget.RecyclerView.C0244v) r0, (androidx.recyclerview.widget.RecyclerView.C0212a0) r1, (int) r12)
            int r13 = r2.f1275d
            int r13 = r6.mo1516c(r0, r1, r13)
            int r12 = r12 + r13
        L_0x0044:
            r13 = r12
            r12 = 0
        L_0x0046:
            int r14 = r6.f1233G0
            if (r12 >= r14) goto L_0x009e
            boolean r14 = r2.mo1594a((androidx.recyclerview.widget.RecyclerView.C0212a0) r1)
            if (r14 == 0) goto L_0x009e
            if (r13 <= 0) goto L_0x009e
            int r14 = r2.f1275d
            int r15 = r6.mo1516c(r0, r1, r14)
            int r4 = r6.f1233G0
            if (r15 > r4) goto L_0x0070
            int r13 = r13 - r15
            if (r13 >= 0) goto L_0x0060
            goto L_0x009e
        L_0x0060:
            android.view.View r4 = r2.mo1592a((androidx.recyclerview.widget.RecyclerView.C0244v) r0)
            if (r4 != 0) goto L_0x0067
            goto L_0x009e
        L_0x0067:
            android.view.View[] r14 = r6.f1235I0
            r14[r12] = r4
            int r12 = r12 + 1
            r4 = 1073741824(0x40000000, float:2.0)
            goto L_0x0046
        L_0x0070:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "Item at position "
            r1.append(r2)
            r1.append(r14)
            java.lang.String r2 = " requires "
            r1.append(r2)
            r1.append(r15)
            java.lang.String r2 = " spans but GridLayoutManager has only "
            r1.append(r2)
            int r2 = r6.f1233G0
            r1.append(r2)
            java.lang.String r2 = " spans."
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x009e:
            if (r12 != 0) goto L_0x00a3
            r7.f1269b = r8
            return
        L_0x00a3:
            if (r11 == 0) goto L_0x00ab
            r15 = r12
            r4 = 0
            r14 = 0
            r17 = 1
            goto L_0x00b1
        L_0x00ab:
            int r14 = r12 + -1
            r4 = 0
            r15 = -1
            r17 = -1
        L_0x00b1:
            if (r14 == r15) goto L_0x00d2
            android.view.View[] r13 = r6.f1235I0
            r13 = r13[r14]
            android.view.ViewGroup$LayoutParams r18 = r13.getLayoutParams()
            r8 = r18
            androidx.recyclerview.widget.GridLayoutManager$b r8 = (androidx.recyclerview.widget.GridLayoutManager.C0204b) r8
            int r13 = r6.mo1949m((android.view.View) r13)
            int r13 = r6.mo1516c(r0, r1, r13)
            r8.f1242c0 = r13
            r8.f1241b0 = r4
            int r8 = r8.f1242c0
            int r4 = r4 + r8
            int r14 = r14 + r17
            r8 = 1
            goto L_0x00b1
        L_0x00d2:
            r0 = 0
            r1 = 0
            r16 = 0
        L_0x00d6:
            if (r0 >= r12) goto L_0x0122
            android.view.View[] r4 = r6.f1235I0
            r4 = r4[r0]
            java.util.List<androidx.recyclerview.widget.RecyclerView$d0> r8 = r2.f1283l
            if (r8 != 0) goto L_0x00ea
            if (r11 == 0) goto L_0x00e6
            r6.mo1908c((android.view.View) r4)
            goto L_0x00f3
        L_0x00e6:
            r6.mo1899b((android.view.View) r4, (int) r5)
            goto L_0x00f3
        L_0x00ea:
            if (r11 == 0) goto L_0x00f0
            r6.mo1898b((android.view.View) r4)
            goto L_0x00f3
        L_0x00f0:
            r6.mo1873a((android.view.View) r4, (int) r5)
        L_0x00f3:
            android.graphics.Rect r8 = r6.f1239M0
            r6.mo1877a((android.view.View) r4, (android.graphics.Rect) r8)
            r6.mo1513b((android.view.View) r4, (int) r3, (boolean) r5)
            yc r8 = r6.f1254r0
            int r8 = r8.mo12236b(r4)
            if (r8 <= r1) goto L_0x0104
            r1 = r8
        L_0x0104:
            android.view.ViewGroup$LayoutParams r8 = r4.getLayoutParams()
            androidx.recyclerview.widget.GridLayoutManager$b r8 = (androidx.recyclerview.widget.GridLayoutManager.C0204b) r8
            r13 = 1065353216(0x3f800000, float:1.0)
            yc r14 = r6.f1254r0
            int r4 = r14.mo12238c(r4)
            float r4 = (float) r4
            float r4 = r4 * r13
            int r8 = r8.f1242c0
            float r8 = (float) r8
            float r4 = r4 / r8
            int r8 = (r4 > r16 ? 1 : (r4 == r16 ? 0 : -1))
            if (r8 <= 0) goto L_0x011f
            r16 = r4
        L_0x011f:
            int r0 = r0 + 1
            goto L_0x00d6
        L_0x0122:
            if (r9 == 0) goto L_0x014e
            int r0 = r6.f1233G0
            float r0 = (float) r0
            float r16 = r16 * r0
            int r0 = java.lang.Math.round(r16)
            int r0 = java.lang.Math.max(r0, r10)
            r6.mo1527p(r0)
            r0 = 0
            r1 = 0
        L_0x0136:
            if (r0 >= r12) goto L_0x014e
            android.view.View[] r3 = r6.f1235I0
            r3 = r3[r0]
            r4 = 1073741824(0x40000000, float:2.0)
            r8 = 1
            r6.mo1513b((android.view.View) r3, (int) r4, (boolean) r8)
            yc r4 = r6.f1254r0
            int r3 = r4.mo12236b(r3)
            if (r3 <= r1) goto L_0x014b
            r1 = r3
        L_0x014b:
            int r0 = r0 + 1
            goto L_0x0136
        L_0x014e:
            r0 = 0
        L_0x014f:
            if (r0 >= r12) goto L_0x01b0
            android.view.View[] r3 = r6.f1235I0
            r3 = r3[r0]
            yc r4 = r6.f1254r0
            int r4 = r4.mo12236b(r3)
            if (r4 == r1) goto L_0x01aa
            android.view.ViewGroup$LayoutParams r4 = r3.getLayoutParams()
            androidx.recyclerview.widget.GridLayoutManager$b r4 = (androidx.recyclerview.widget.GridLayoutManager.C0204b) r4
            android.graphics.Rect r8 = r4.f1372Y
            int r9 = r8.top
            int r10 = r8.bottom
            int r9 = r9 + r10
            int r10 = r4.topMargin
            int r9 = r9 + r10
            int r10 = r4.bottomMargin
            int r9 = r9 + r10
            int r10 = r8.left
            int r8 = r8.right
            int r10 = r10 + r8
            int r8 = r4.leftMargin
            int r10 = r10 + r8
            int r8 = r4.rightMargin
            int r10 = r10 + r8
            int r8 = r4.f1241b0
            int r11 = r4.f1242c0
            int r8 = r6.mo1524i(r8, r11)
            int r11 = r6.f1252p0
            r13 = 1
            if (r11 != r13) goto L_0x0197
            int r4 = r4.width
            r11 = 1073741824(0x40000000, float:2.0)
            int r4 = androidx.recyclerview.widget.RecyclerView.C0232o.m1221a((int) r8, (int) r11, (int) r10, (int) r4, (boolean) r5)
            int r8 = r1 - r9
            int r8 = android.view.View.MeasureSpec.makeMeasureSpec(r8, r11)
            goto L_0x01a6
        L_0x0197:
            r11 = 1073741824(0x40000000, float:2.0)
            int r10 = r1 - r10
            int r10 = android.view.View.MeasureSpec.makeMeasureSpec(r10, r11)
            int r4 = r4.height
            int r8 = androidx.recyclerview.widget.RecyclerView.C0232o.m1221a((int) r8, (int) r11, (int) r9, (int) r4, (boolean) r5)
            r4 = r10
        L_0x01a6:
            r6.mo1500a((android.view.View) r3, (int) r4, (int) r8, (boolean) r13)
            goto L_0x01ad
        L_0x01aa:
            r11 = 1073741824(0x40000000, float:2.0)
            r13 = 1
        L_0x01ad:
            int r0 = r0 + 1
            goto L_0x014f
        L_0x01b0:
            r13 = 1
            r7.f1268a = r1
            int r0 = r6.f1252p0
            if (r0 != r13) goto L_0x01cb
            int r0 = r2.f1277f
            r3 = -1
            if (r0 != r3) goto L_0x01c3
            int r0 = r2.f1273b
            int r1 = r0 - r1
            r3 = r0
            r2 = r1
            goto L_0x01c8
        L_0x01c3:
            int r0 = r2.f1273b
            int r1 = r1 + r0
            r2 = r0
            r3 = r1
        L_0x01c8:
            r0 = 0
            r1 = 0
            goto L_0x01e1
        L_0x01cb:
            r3 = -1
            int r0 = r2.f1277f
            if (r0 != r3) goto L_0x01dc
            int r0 = r2.f1273b
            int r1 = r0 - r1
            r2 = 0
            r3 = 0
            r19 = r1
            r1 = r0
            r0 = r19
            goto L_0x01e1
        L_0x01dc:
            int r0 = r2.f1273b
            int r1 = r1 + r0
            r2 = 0
            r3 = 0
        L_0x01e1:
            r8 = 0
        L_0x01e2:
            if (r8 >= r12) goto L_0x0269
            android.view.View[] r4 = r6.f1235I0
            r9 = r4[r8]
            android.view.ViewGroup$LayoutParams r4 = r9.getLayoutParams()
            r10 = r4
            androidx.recyclerview.widget.GridLayoutManager$b r10 = (androidx.recyclerview.widget.GridLayoutManager.C0204b) r10
            int r4 = r6.f1252p0
            r5 = 1
            if (r4 != r5) goto L_0x0226
            boolean r0 = r20.mo1544S()
            if (r0 == 0) goto L_0x0213
            int r0 = r20.getPaddingLeft()
            int[] r1 = r6.f1234H0
            int r4 = r6.f1233G0
            int r5 = r10.f1241b0
            int r4 = r4 - r5
            r1 = r1[r4]
            int r0 = r0 + r1
            yc r1 = r6.f1254r0
            int r1 = r1.mo12238c(r9)
            int r1 = r0 - r1
            r14 = r0
            r11 = r1
            goto L_0x023a
        L_0x0213:
            int r0 = r20.getPaddingLeft()
            int[] r1 = r6.f1234H0
            int r4 = r10.f1241b0
            r1 = r1[r4]
            int r0 = r0 + r1
            yc r1 = r6.f1254r0
            int r1 = r1.mo12238c(r9)
            int r1 = r1 + r0
            goto L_0x0238
        L_0x0226:
            int r2 = r20.getPaddingTop()
            int[] r3 = r6.f1234H0
            int r4 = r10.f1241b0
            r3 = r3[r4]
            int r2 = r2 + r3
            yc r3 = r6.f1254r0
            int r3 = r3.mo12238c(r9)
            int r3 = r3 + r2
        L_0x0238:
            r11 = r0
            r14 = r1
        L_0x023a:
            r13 = r2
            r15 = r3
            r0 = r20
            r1 = r9
            r2 = r11
            r3 = r13
            r4 = r14
            r5 = r15
            r0.mo1874a((android.view.View) r1, (int) r2, (int) r3, (int) r4, (int) r5)
            boolean r0 = r10.mo1972p()
            if (r0 != 0) goto L_0x0255
            boolean r0 = r10.mo1971o()
            if (r0 == 0) goto L_0x0253
            goto L_0x0255
        L_0x0253:
            r0 = 1
            goto L_0x0258
        L_0x0255:
            r0 = 1
            r7.f1270c = r0
        L_0x0258:
            boolean r1 = r7.f1271d
            boolean r2 = r9.hasFocusable()
            r1 = r1 | r2
            r7.f1271d = r1
            int r8 = r8 + 1
            r0 = r11
            r2 = r13
            r1 = r14
            r3 = r15
            goto L_0x01e2
        L_0x0269:
            android.view.View[] r0 = r6.f1235I0
            r1 = 0
            java.util.Arrays.fill(r0, r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.GridLayoutManager.mo1504a(androidx.recyclerview.widget.RecyclerView$v, androidx.recyclerview.widget.RecyclerView$a0, androidx.recyclerview.widget.LinearLayoutManager$c, androidx.recyclerview.widget.LinearLayoutManager$b):void");
    }

    /* renamed from: b */
    public void mo1514b(RecyclerView recyclerView, int i, int i2) {
        this.f1238L0.f1243a.clear();
        this.f1238L0.f1244b.clear();
    }

    /* renamed from: c */
    public void mo1518c(RecyclerView recyclerView) {
        this.f1238L0.f1243a.clear();
        this.f1238L0.f1244b.clear();
    }

    /* renamed from: c */
    public void mo1517c(RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var) {
        if (a0Var.f1296h) {
            int f = mo1921f();
            for (int i = 0; i < f; i++) {
                C0204b bVar = (C0204b) mo1925g(i).getLayoutParams();
                int n = bVar.mo1970n();
                this.f1236J0.put(n, bVar.f1242c0);
                this.f1237K0.put(n, bVar.f1241b0);
            }
        }
        super.mo1517c(vVar, a0Var);
        this.f1236J0.clear();
        this.f1237K0.clear();
    }

    /* renamed from: a */
    public void mo1503a(RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var, LinearLayoutManager.C0206a aVar, int i) {
        super.mo1503a(vVar, a0Var, aVar, i);
        mo1491Y();
        if (a0Var.mo1790a() > 0 && !a0Var.f1296h) {
            boolean z = i == 1;
            int b = mo1512b(vVar, a0Var, aVar.f1264b);
            if (z) {
                while (b > 0) {
                    int i2 = aVar.f1264b;
                    if (i2 <= 0) {
                        break;
                    }
                    aVar.f1264b = i2 - 1;
                    b = mo1512b(vVar, a0Var, aVar.f1264b);
                }
            } else {
                int a = a0Var.mo1790a() - 1;
                int i3 = aVar.f1264b;
                while (i3 < a) {
                    int i4 = i3 + 1;
                    int b2 = mo1512b(vVar, a0Var, i4);
                    if (b2 <= b) {
                        break;
                    }
                    i3 = i4;
                    b = b2;
                }
                aVar.f1264b = i3;
            }
        }
        mo1489W();
    }

    /* renamed from: a */
    public void mo1502a(RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var, View view, C0759g8 g8Var) {
        boolean z;
        boolean z2;
        int i;
        int i2;
        int i3;
        int i4;
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (!(layoutParams instanceof C0204b)) {
            super.mo1879a(view, g8Var);
            return;
        }
        C0204b bVar = (C0204b) layoutParams;
        int a = mo1494a(vVar, a0Var, bVar.mo1970n());
        if (this.f1252p0 == 0) {
            i4 = bVar.f1241b0;
            i3 = bVar.f1242c0;
            i = 1;
            z2 = false;
            z = false;
            i2 = a;
        } else {
            i3 = 1;
            i2 = bVar.f1241b0;
            i = bVar.f1242c0;
            z2 = false;
            z = false;
            i4 = a;
        }
        g8Var.mo6041b((Object) C0759g8.C0762c.m5406a(i4, i3, i2, i, z2, z));
    }

    /* renamed from: a */
    public void mo1505a(RecyclerView recyclerView, int i, int i2) {
        this.f1238L0.f1243a.clear();
        this.f1238L0.f1244b.clear();
    }

    /* renamed from: a */
    public void mo1506a(RecyclerView recyclerView, int i, int i2, int i3) {
        this.f1238L0.f1243a.clear();
        this.f1238L0.f1244b.clear();
    }

    /* renamed from: a */
    public void mo1507a(RecyclerView recyclerView, int i, int i2, Object obj) {
        this.f1238L0.f1243a.clear();
        this.f1238L0.f1244b.clear();
    }
}
