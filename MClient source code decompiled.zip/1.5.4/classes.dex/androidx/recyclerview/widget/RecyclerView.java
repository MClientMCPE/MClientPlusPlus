package androidx.recyclerview.widget;

import android.animation.LayoutTransition;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.Observable;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.os.Trace;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.FocusFinder;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewPropertyAnimator;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.OverScroller;
import java.lang.ref.WeakReference;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import p000.C0531dd;
import p000.C0599ed;
import p000.C0759g8;
import p000.C0926ic;
import p000.C1050jc;
import p000.C1510oc;
import p000.C1692qc;
import p000.C2435zc;

public class RecyclerView extends ViewGroup implements C1984u7, C0991j7, C1131k7 {
    public static final boolean ALLOW_SIZE_IN_UNSPECIFIED_SPEC = (Build.VERSION.SDK_INT >= 23);
    public static final boolean ALLOW_THREAD_GAP_WORK;
    public static final boolean DEBUG = false;
    public static final int DEFAULT_ORIENTATION = 1;
    public static final boolean DISPATCH_TEMP_DETACH = false;
    public static final boolean FORCE_ABS_FOCUS_SEARCH_DIRECTION = false;
    public static final boolean FORCE_INVALIDATE_DISPLAY_LIST;
    public static final long FOREVER_NS = Long.MAX_VALUE;
    public static final int HORIZONTAL = 0;
    public static final boolean IGNORE_DETACHED_FOCUSED_CHILD = false;
    public static final int INVALID_POINTER = -1;
    public static final int INVALID_TYPE = -1;
    public static final Class<?>[] LAYOUT_MANAGER_CONSTRUCTOR_SIGNATURE;
    public static final int MAX_SCROLL_DURATION = 2000;
    public static final int[] NESTED_SCROLLING_ATTRS = {16843830};
    public static final long NO_ID = -1;
    public static final int NO_POSITION = -1;
    public static final boolean POST_UPDATES_ON_ANIMATION = true;
    public static final int SCROLL_STATE_DRAGGING = 1;
    public static final int SCROLL_STATE_IDLE = 0;
    public static final int SCROLL_STATE_SETTLING = 2;
    public static final String TAG = "RecyclerView";
    public static final int TOUCH_SLOP_DEFAULT = 0;
    public static final int TOUCH_SLOP_PAGING = 1;
    public static final String TRACE_BIND_VIEW_TAG = "RV OnBindView";
    public static final String TRACE_CREATE_VIEW_TAG = "RV CreateView";
    public static final String TRACE_HANDLE_ADAPTER_UPDATES_TAG = "RV PartialInvalidate";
    public static final String TRACE_NESTED_PREFETCH_TAG = "RV Nested Prefetch";
    public static final String TRACE_ON_DATA_SET_CHANGE_LAYOUT_TAG = "RV FullInvalidate";
    public static final String TRACE_ON_LAYOUT_TAG = "RV OnLayout";
    public static final String TRACE_PREFETCH_TAG = "RV Prefetch";
    public static final String TRACE_SCROLL_TAG = "RV Scroll";
    public static final int UNDEFINED_DURATION = Integer.MIN_VALUE;
    public static final boolean VERBOSE_TRACING = false;
    public static final int VERTICAL = 1;
    public static final Interpolator sQuinticInterpolator = new C0215c();
    public C2435zc mAccessibilityDelegate;
    public final AccessibilityManager mAccessibilityManager;
    public C0221g mAdapter;
    public C0926ic mAdapterHelper;
    public boolean mAdapterUpdateDuringMeasure;
    public EdgeEffect mBottomGlow;
    public C0224j mChildDrawingOrderCallback;
    public C1050jc mChildHelper;
    public boolean mClipToPadding;
    public boolean mDataSetHasChangedAfterLayout;
    public boolean mDispatchItemsChangedEvent;
    public int mDispatchScrollCounter;
    public int mEatenAccessibilityChangeFlags;
    public C0225k mEdgeEffectFactory;
    public boolean mEnableFastScroller;
    public boolean mFirstLayoutComplete;
    public C1692qc mGapWorker;
    public boolean mHasFixedSize;
    public boolean mIgnoreMotionEventTillDown;
    public int mInitialTouchX;
    public int mInitialTouchY;
    public int mInterceptRequestLayoutDepth;
    public C0240s mInterceptingOnItemTouchListener;
    public boolean mIsAttached;
    public C0226l mItemAnimator;
    public C0226l.C0228b mItemAnimatorListener;
    public Runnable mItemAnimatorRunner;
    public final ArrayList<C0231n> mItemDecorations;
    public boolean mItemsAddedOrRemoved;
    public boolean mItemsChanged;
    public int mLastTouchX;
    public int mLastTouchY;
    public C0232o mLayout;
    public int mLayoutOrScrollCounter;
    public boolean mLayoutSuppressed;
    public boolean mLayoutWasDefered;
    public EdgeEffect mLeftGlow;
    public final int mMaxFlingVelocity;
    public final int mMinFlingVelocity;
    public final int[] mMinMaxLayoutPositions;
    public final int[] mNestedOffsets;
    public final C0246x mObserver;
    public List<C0238q> mOnChildAttachStateListeners;
    public C0239r mOnFlingListener;
    public final ArrayList<C0240s> mOnItemTouchListeners;
    public final List<C0218d0> mPendingAccessibilityImportanceChange;
    public C0247y mPendingSavedState;
    public boolean mPostedAnimatorRunner;
    public C1692qc.C1694b mPrefetchRegistry;
    public boolean mPreserveFocusAfterLayout;
    public final C0244v mRecycler;
    public C0245w mRecyclerListener;
    public final int[] mReusableIntPair;
    public EdgeEffect mRightGlow;
    public float mScaledHorizontalScrollFactor;
    public float mScaledVerticalScrollFactor;
    public C0241t mScrollListener;
    public List<C0241t> mScrollListeners;
    public final int[] mScrollOffset;
    public int mScrollPointerId;
    public int mScrollState;
    public C1313m7 mScrollingChildHelper;
    public final C0212a0 mState;
    public final Rect mTempRect;
    public final Rect mTempRect2;
    public final RectF mTempRectF;
    public EdgeEffect mTopGlow;
    public int mTouchSlop;
    public final Runnable mUpdateChildViewsRunnable;
    public VelocityTracker mVelocityTracker;
    public final C0216c0 mViewFlinger;
    public final C0599ed.C0601b mViewInfoProcessCallback;
    public final C0599ed mViewInfoStore;

    /* renamed from: androidx.recyclerview.widget.RecyclerView$a */
    public class C0211a implements Runnable {
        public C0211a() {
        }

        public void run() {
            RecyclerView recyclerView = RecyclerView.this;
            if (recyclerView.mFirstLayoutComplete && !recyclerView.isLayoutRequested()) {
                RecyclerView recyclerView2 = RecyclerView.this;
                if (!recyclerView2.mIsAttached) {
                    recyclerView2.requestLayout();
                } else if (recyclerView2.mLayoutSuppressed) {
                    recyclerView2.mLayoutWasDefered = true;
                } else {
                    recyclerView2.consumePendingUpdateOperations();
                }
            }
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$a0 */
    public static class C0212a0 {

        /* renamed from: a */
        public int f1289a = -1;

        /* renamed from: b */
        public SparseArray<Object> f1290b;

        /* renamed from: c */
        public int f1291c = 0;

        /* renamed from: d */
        public int f1292d = 0;

        /* renamed from: e */
        public int f1293e = 1;

        /* renamed from: f */
        public int f1294f = 0;

        /* renamed from: g */
        public boolean f1295g = false;

        /* renamed from: h */
        public boolean f1296h = false;

        /* renamed from: i */
        public boolean f1297i = false;

        /* renamed from: j */
        public boolean f1298j = false;

        /* renamed from: k */
        public boolean f1299k = false;

        /* renamed from: l */
        public boolean f1300l = false;

        /* renamed from: m */
        public int f1301m;

        /* renamed from: n */
        public long f1302n;

        /* renamed from: o */
        public int f1303o;

        /* renamed from: p */
        public int f1304p;

        /* renamed from: q */
        public int f1305q;

        /* renamed from: a */
        public int mo1790a() {
            return this.f1296h ? this.f1291c - this.f1292d : this.f1294f;
        }

        /* renamed from: a */
        public void mo1791a(int i) {
            if ((this.f1293e & i) == 0) {
                StringBuilder a = C0789gk.m5562a("Layout state should be one of ");
                a.append(Integer.toBinaryString(i));
                a.append(" but it is ");
                a.append(Integer.toBinaryString(this.f1293e));
                throw new IllegalStateException(a.toString());
            }
        }

        public String toString() {
            StringBuilder a = C0789gk.m5562a("State{mTargetPosition=");
            a.append(this.f1289a);
            a.append(", mData=");
            a.append(this.f1290b);
            a.append(", mItemCount=");
            a.append(this.f1294f);
            a.append(", mIsMeasuring=");
            a.append(this.f1298j);
            a.append(", mPreviousLayoutItemCount=");
            a.append(this.f1291c);
            a.append(", mDeletedInvisibleItemCountSincePreviousLayout=");
            a.append(this.f1292d);
            a.append(", mStructureChanged=");
            a.append(this.f1295g);
            a.append(", mInPreLayout=");
            a.append(this.f1296h);
            a.append(", mRunSimpleAnimations=");
            a.append(this.f1299k);
            a.append(", mRunPredictiveAnimations=");
            a.append(this.f1300l);
            a.append('}');
            return a.toString();
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$b */
    public class C0213b implements Runnable {
        public C0213b() {
        }

        public void run() {
            C0226l lVar = RecyclerView.this.mItemAnimator;
            if (lVar != null) {
                C1510oc ocVar = (C1510oc) lVar;
                boolean z = !ocVar.f11784h.isEmpty();
                boolean z2 = !ocVar.f11786j.isEmpty();
                boolean z3 = !ocVar.f11787k.isEmpty();
                boolean z4 = !ocVar.f11785i.isEmpty();
                if (z || z2 || z4 || z3) {
                    Iterator<C0218d0> it = ocVar.f11784h.iterator();
                    while (it.hasNext()) {
                        C0218d0 next = it.next();
                        View view = next.f1316X;
                        ViewPropertyAnimator animate = view.animate();
                        ocVar.f11793q.add(next);
                        animate.setDuration(ocVar.f1341d).alpha(0.0f).setListener(new C1418nc(ocVar, next, animate, view)).start();
                    }
                    ocVar.f11784h.clear();
                    if (z2) {
                        ArrayList arrayList = new ArrayList();
                        arrayList.addAll(ocVar.f11786j);
                        ocVar.f11789m.add(arrayList);
                        ocVar.f11786j.clear();
                        C1139kc kcVar = new C1139kc(ocVar, arrayList);
                        if (z) {
                            C2189w7.m14992a(((C1510oc.C1516f) arrayList.get(0)).f11819a.f1316X, (Runnable) kcVar, ocVar.f1341d);
                        } else {
                            kcVar.run();
                        }
                    }
                    if (z3) {
                        ArrayList arrayList2 = new ArrayList();
                        arrayList2.addAll(ocVar.f11787k);
                        ocVar.f11790n.add(arrayList2);
                        ocVar.f11787k.clear();
                        C1237lc lcVar = new C1237lc(ocVar, arrayList2);
                        if (z) {
                            C2189w7.m14992a(((C1510oc.C1515e) arrayList2.get(0)).f11813a.f1316X, (Runnable) lcVar, ocVar.f1341d);
                        } else {
                            lcVar.run();
                        }
                    }
                    if (z4) {
                        ArrayList arrayList3 = new ArrayList();
                        arrayList3.addAll(ocVar.f11785i);
                        ocVar.f11788l.add(arrayList3);
                        ocVar.f11785i.clear();
                        C1322mc mcVar = new C1322mc(ocVar, arrayList3);
                        if (z || z2 || z3) {
                            long j = 0;
                            long j2 = z ? ocVar.f1341d : 0;
                            long c = z2 ? ocVar.mo1857c() : 0;
                            if (z3) {
                                j = ocVar.f1343f;
                            }
                            C2189w7.m14992a(((C0218d0) arrayList3.get(0)).f1316X, (Runnable) mcVar, Math.max(c, j) + j2);
                        } else {
                            mcVar.run();
                        }
                    }
                }
            }
            RecyclerView.this.mPostedAnimatorRunner = false;
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$b0 */
    public static abstract class C0214b0 {
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$c */
    public static class C0215c implements Interpolator {
        public float getInterpolation(float f) {
            float f2 = f - 1.0f;
            return (f2 * f2 * f2 * f2 * f2) + 1.0f;
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$c0 */
    public class C0216c0 implements Runnable {

        /* renamed from: X */
        public int f1307X;

        /* renamed from: Y */
        public int f1308Y;

        /* renamed from: Z */
        public OverScroller f1309Z;

        /* renamed from: a0 */
        public Interpolator f1310a0 = RecyclerView.sQuinticInterpolator;

        /* renamed from: b0 */
        public boolean f1311b0 = false;

        /* renamed from: c0 */
        public boolean f1312c0 = false;

        public C0216c0() {
            this.f1309Z = new OverScroller(RecyclerView.this.getContext(), RecyclerView.sQuinticInterpolator);
        }

        /* renamed from: a */
        public void mo1795a() {
            if (this.f1311b0) {
                this.f1312c0 = true;
                return;
            }
            RecyclerView.this.removeCallbacks(this);
            C2189w7.m14991a((View) RecyclerView.this, (Runnable) this);
        }

        /* renamed from: b */
        public void mo1797b() {
            RecyclerView.this.removeCallbacks(this);
            this.f1309Z.abortAnimation();
        }

        public void run() {
            int i;
            int i2;
            RecyclerView recyclerView = RecyclerView.this;
            if (recyclerView.mLayout == null) {
                mo1797b();
                return;
            }
            this.f1312c0 = false;
            this.f1311b0 = true;
            recyclerView.consumePendingUpdateOperations();
            OverScroller overScroller = this.f1309Z;
            if (overScroller.computeScrollOffset()) {
                int currX = overScroller.getCurrX();
                int currY = overScroller.getCurrY();
                int i3 = currX - this.f1307X;
                int i4 = currY - this.f1308Y;
                this.f1307X = currX;
                this.f1308Y = currY;
                RecyclerView recyclerView2 = RecyclerView.this;
                int[] iArr = recyclerView2.mReusableIntPair;
                iArr[0] = 0;
                iArr[1] = 0;
                if (recyclerView2.dispatchNestedPreScroll(i3, i4, iArr, (int[]) null, 1)) {
                    int[] iArr2 = RecyclerView.this.mReusableIntPair;
                    i3 -= iArr2[0];
                    i4 -= iArr2[1];
                }
                if (RecyclerView.this.getOverScrollMode() != 2) {
                    RecyclerView.this.considerReleasingGlowsOnScroll(i3, i4);
                }
                RecyclerView recyclerView3 = RecyclerView.this;
                if (recyclerView3.mAdapter != null) {
                    int[] iArr3 = recyclerView3.mReusableIntPair;
                    iArr3[0] = 0;
                    iArr3[1] = 0;
                    recyclerView3.scrollStep(i3, i4, iArr3);
                    RecyclerView recyclerView4 = RecyclerView.this;
                    int[] iArr4 = recyclerView4.mReusableIntPair;
                    i = iArr4[0];
                    i2 = iArr4[1];
                    i3 -= i;
                    i4 -= i2;
                    C0249z zVar = recyclerView4.mLayout.f1353d0;
                    if (zVar != null && !zVar.f1394d && zVar.f1395e) {
                        int a = recyclerView4.mState.mo1790a();
                        if (a == 0) {
                            zVar.mo2005a();
                        } else {
                            if (zVar.f1391a >= a) {
                                zVar.f1391a = a - 1;
                            }
                            zVar.mo2006a(i, i2);
                        }
                    }
                } else {
                    i2 = 0;
                    i = 0;
                }
                if (!RecyclerView.this.mItemDecorations.isEmpty()) {
                    RecyclerView.this.invalidate();
                }
                RecyclerView recyclerView5 = RecyclerView.this;
                int[] iArr5 = recyclerView5.mReusableIntPair;
                iArr5[0] = 0;
                iArr5[1] = 0;
                recyclerView5.dispatchNestedScroll(i, i2, i3, i4, (int[]) null, 1, iArr5);
                int[] iArr6 = RecyclerView.this.mReusableIntPair;
                int i5 = i3 - iArr6[0];
                int i6 = i4 - iArr6[1];
                if (!(i == 0 && i2 == 0)) {
                    RecyclerView.this.dispatchOnScrolled(i, i2);
                }
                if (!RecyclerView.this.awakenScrollBars()) {
                    RecyclerView.this.invalidate();
                }
                boolean z = overScroller.isFinished() || (((overScroller.getCurrX() == overScroller.getFinalX()) || i5 != 0) && ((overScroller.getCurrY() == overScroller.getFinalY()) || i6 != 0));
                C0249z zVar2 = RecyclerView.this.mLayout.f1353d0;
                if ((zVar2 != null && zVar2.f1394d) || !z) {
                    mo1795a();
                    RecyclerView recyclerView6 = RecyclerView.this;
                    C1692qc qcVar = recyclerView6.mGapWorker;
                    if (qcVar != null) {
                        qcVar.mo10306a(recyclerView6, i, i2);
                    }
                } else {
                    if (RecyclerView.this.getOverScrollMode() != 2) {
                        int currVelocity = (int) overScroller.getCurrVelocity();
                        int i7 = i5 < 0 ? -currVelocity : i5 > 0 ? currVelocity : 0;
                        if (i6 < 0) {
                            currVelocity = -currVelocity;
                        } else if (i6 <= 0) {
                            currVelocity = 0;
                        }
                        RecyclerView.this.absorbGlows(i7, currVelocity);
                    }
                    if (RecyclerView.ALLOW_THREAD_GAP_WORK) {
                        C1692qc.C1694b bVar = RecyclerView.this.mPrefetchRegistry;
                        int[] iArr7 = bVar.f12992c;
                        if (iArr7 != null) {
                            Arrays.fill(iArr7, -1);
                        }
                        bVar.f12993d = 0;
                    }
                }
            }
            C0249z zVar3 = RecyclerView.this.mLayout.f1353d0;
            if (zVar3 != null && zVar3.f1394d) {
                zVar3.mo2006a(0, 0);
            }
            this.f1311b0 = false;
            if (this.f1312c0) {
                RecyclerView.this.removeCallbacks(this);
                C2189w7.m14991a((View) RecyclerView.this, (Runnable) this);
                return;
            }
            RecyclerView.this.setScrollState(0);
            RecyclerView.this.stopNestedScroll(1);
        }

        /* renamed from: a */
        public void mo1796a(int i, int i2, int i3, Interpolator interpolator) {
            int i4;
            if (i3 == Integer.MIN_VALUE) {
                int abs = Math.abs(i);
                int abs2 = Math.abs(i2);
                boolean z = abs > abs2;
                int sqrt = (int) Math.sqrt((double) 0);
                int sqrt2 = (int) Math.sqrt((double) ((i2 * i2) + (i * i)));
                RecyclerView recyclerView = RecyclerView.this;
                int width = z ? recyclerView.getWidth() : recyclerView.getHeight();
                int i5 = width / 2;
                float f = (float) width;
                float f2 = (float) i5;
                float sin = (((float) Math.sin((double) ((Math.min(1.0f, (((float) sqrt2) * 1.0f) / f) - 0.5f) * 0.47123894f))) * f2) + f2;
                if (sqrt > 0) {
                    i4 = Math.round(Math.abs(sin / ((float) sqrt)) * 1000.0f) * 4;
                } else {
                    if (!z) {
                        abs = abs2;
                    }
                    i4 = (int) (((((float) abs) / f) + 1.0f) * 300.0f);
                }
                i3 = Math.min(i4, RecyclerView.MAX_SCROLL_DURATION);
            }
            int i6 = i3;
            if (interpolator == null) {
                interpolator = RecyclerView.sQuinticInterpolator;
            }
            if (this.f1310a0 != interpolator) {
                this.f1310a0 = interpolator;
                this.f1309Z = new OverScroller(RecyclerView.this.getContext(), interpolator);
            }
            this.f1308Y = 0;
            this.f1307X = 0;
            RecyclerView.this.setScrollState(2);
            this.f1309Z.startScroll(0, 0, i, i2, i6);
            if (Build.VERSION.SDK_INT < 23) {
                this.f1309Z.computeScrollOffset();
            }
            mo1795a();
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$d */
    public class C0217d implements C0599ed.C0601b {
        public C0217d() {
        }

        /* renamed from: a */
        public void mo1799a(C0218d0 d0Var, C0226l.C0229c cVar, C0226l.C0229c cVar2) {
            d0Var.mo1804a(false);
            RecyclerView recyclerView = RecyclerView.this;
            boolean z = recyclerView.mDataSetHasChangedAfterLayout;
            C0226l lVar = recyclerView.mItemAnimator;
            if (z) {
                if (!lVar.mo383a(d0Var, d0Var, cVar, cVar2)) {
                    return;
                }
            } else if (!lVar.mo388c(d0Var, cVar, cVar2)) {
                return;
            }
            RecyclerView.this.postAnimationRunner();
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$d0 */
    public static abstract class C0218d0 {

        /* renamed from: p0 */
        public static final List<Object> f1315p0 = Collections.emptyList();

        /* renamed from: X */
        public final View f1316X;

        /* renamed from: Y */
        public WeakReference<RecyclerView> f1317Y;

        /* renamed from: Z */
        public int f1318Z = -1;

        /* renamed from: a0 */
        public int f1319a0 = -1;

        /* renamed from: b0 */
        public long f1320b0 = -1;

        /* renamed from: c0 */
        public int f1321c0 = -1;

        /* renamed from: d0 */
        public int f1322d0 = -1;

        /* renamed from: e0 */
        public C0218d0 f1323e0 = null;

        /* renamed from: f0 */
        public C0218d0 f1324f0 = null;

        /* renamed from: g0 */
        public int f1325g0;

        /* renamed from: h0 */
        public List<Object> f1326h0 = null;

        /* renamed from: i0 */
        public List<Object> f1327i0 = null;

        /* renamed from: j0 */
        public int f1328j0 = 0;

        /* renamed from: k0 */
        public C0244v f1329k0 = null;

        /* renamed from: l0 */
        public boolean f1330l0 = false;

        /* renamed from: m0 */
        public int f1331m0 = 0;

        /* renamed from: n0 */
        public int f1332n0 = -1;

        /* renamed from: o0 */
        public RecyclerView f1333o0;

        public C0218d0(View view) {
            if (view != null) {
                this.f1316X = view;
                return;
            }
            throw new IllegalArgumentException("itemView may not be null");
        }

        /* renamed from: a */
        public void mo1800a(int i) {
            this.f1325g0 = i | this.f1325g0;
        }

        /* renamed from: a */
        public void mo1801a(int i, int i2) {
            this.f1325g0 = (i & i2) | (this.f1325g0 & (i2 ^ -1));
        }

        /* renamed from: a */
        public void mo1802a(int i, boolean z) {
            if (this.f1319a0 == -1) {
                this.f1319a0 = this.f1318Z;
            }
            if (this.f1322d0 == -1) {
                this.f1322d0 = this.f1318Z;
            }
            if (z) {
                this.f1322d0 += i;
            }
            this.f1318Z += i;
            if (this.f1316X.getLayoutParams() != null) {
                ((C0237p) this.f1316X.getLayoutParams()).f1373Z = true;
            }
        }

        /* renamed from: a */
        public void mo1803a(Object obj) {
            if (obj == null) {
                mo1800a(1024);
            } else if ((1024 & this.f1325g0) == 0) {
                if (this.f1326h0 == null) {
                    this.f1326h0 = new ArrayList();
                    this.f1327i0 = Collections.unmodifiableList(this.f1326h0);
                }
                this.f1326h0.add(obj);
            }
        }

        /* renamed from: a */
        public final void mo1804a(boolean z) {
            int i;
            int i2 = this.f1328j0;
            this.f1328j0 = z ? i2 - 1 : i2 + 1;
            int i3 = this.f1328j0;
            if (i3 < 0) {
                this.f1328j0 = 0;
                Log.e("View", "isRecyclable decremented below 0: unmatched pair of setIsRecyable() calls for " + this);
                return;
            }
            if (!z && i3 == 1) {
                i = this.f1325g0 | 16;
            } else if (z && this.f1328j0 == 0) {
                i = this.f1325g0 & -17;
            } else {
                return;
            }
            this.f1325g0 = i;
        }

        /* renamed from: b */
        public boolean mo1805b(int i) {
            return (i & this.f1325g0) != 0;
        }

        /* renamed from: i */
        public void mo1806i() {
            this.f1319a0 = -1;
            this.f1322d0 = -1;
        }

        /* renamed from: j */
        public void mo1807j() {
            this.f1325g0 &= -33;
        }

        /* renamed from: k */
        public final int mo1808k() {
            RecyclerView recyclerView = this.f1333o0;
            if (recyclerView == null) {
                return -1;
            }
            return recyclerView.getAdapterPositionFor(this);
        }

        /* renamed from: l */
        public final int mo1809l() {
            int i = this.f1322d0;
            return i == -1 ? this.f1318Z : i;
        }

        /* renamed from: m */
        public List<Object> mo1810m() {
            if ((this.f1325g0 & 1024) != 0) {
                return f1315p0;
            }
            List<Object> list = this.f1326h0;
            return (list == null || list.size() == 0) ? f1315p0 : this.f1327i0;
        }

        /* renamed from: n */
        public boolean mo1811n() {
            return (this.f1316X.getParent() == null || this.f1316X.getParent() == this.f1333o0) ? false : true;
        }

        /* renamed from: o */
        public boolean mo1812o() {
            return (this.f1325g0 & 1) != 0;
        }

        /* renamed from: p */
        public boolean mo1813p() {
            return (this.f1325g0 & 4) != 0;
        }

        /* renamed from: q */
        public final boolean mo1814q() {
            return (this.f1325g0 & 16) == 0 && !C2189w7.m15029x(this.f1316X);
        }

        /* renamed from: r */
        public boolean mo1815r() {
            return (this.f1325g0 & 8) != 0;
        }

        /* renamed from: s */
        public boolean mo1816s() {
            return this.f1329k0 != null;
        }

        /* renamed from: t */
        public boolean mo1817t() {
            return (this.f1325g0 & 256) != 0;
        }

        public String toString() {
            StringBuilder b = C0789gk.m5569b(getClass().isAnonymousClass() ? "ViewHolder" : getClass().getSimpleName(), "{");
            b.append(Integer.toHexString(hashCode()));
            b.append(" position=");
            b.append(this.f1318Z);
            b.append(" id=");
            b.append(this.f1320b0);
            b.append(", oldPos=");
            b.append(this.f1319a0);
            b.append(", pLpos:");
            b.append(this.f1322d0);
            StringBuilder sb = new StringBuilder(b.toString());
            if (mo1816s()) {
                sb.append(" scrap ");
                sb.append(this.f1330l0 ? "[changeScrap]" : "[attachedScrap]");
            }
            if (mo1813p()) {
                sb.append(" invalid");
            }
            if (!mo1812o()) {
                sb.append(" unbound");
            }
            boolean z = true;
            if ((this.f1325g0 & 2) != 0) {
                sb.append(" update");
            }
            if (mo1815r()) {
                sb.append(" removed");
            }
            if (mo1821w()) {
                sb.append(" ignored");
            }
            if (mo1817t()) {
                sb.append(" tmpDetached");
            }
            if (!mo1814q()) {
                StringBuilder a = C0789gk.m5562a(" not recyclable(");
                a.append(this.f1328j0);
                a.append(")");
                sb.append(a.toString());
            }
            if ((this.f1325g0 & 512) == 0 && !mo1813p()) {
                z = false;
            }
            if (z) {
                sb.append(" undefined adapter position");
            }
            if (this.f1316X.getParent() == null) {
                sb.append(" no parent");
            }
            sb.append("}");
            return sb.toString();
        }

        /* renamed from: u */
        public boolean mo1819u() {
            return (this.f1325g0 & 2) != 0;
        }

        /* renamed from: v */
        public void mo1820v() {
            this.f1325g0 = 0;
            this.f1318Z = -1;
            this.f1319a0 = -1;
            this.f1320b0 = -1;
            this.f1322d0 = -1;
            this.f1328j0 = 0;
            this.f1323e0 = null;
            this.f1324f0 = null;
            List<Object> list = this.f1326h0;
            if (list != null) {
                list.clear();
            }
            this.f1325g0 &= -1025;
            this.f1331m0 = 0;
            this.f1332n0 = -1;
            RecyclerView.clearNestedRecyclerViewIfNotNested(this);
        }

        /* renamed from: w */
        public boolean mo1821w() {
            return (this.f1325g0 & 128) != 0;
        }

        /* renamed from: x */
        public boolean mo1822x() {
            return (this.f1325g0 & 32) != 0;
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$e */
    public class C0219e implements C1050jc.C1052b {
        public C0219e() {
        }

        /* renamed from: a */
        public int mo1823a() {
            return RecyclerView.this.getChildCount();
        }

        /* renamed from: a */
        public View mo1824a(int i) {
            return RecyclerView.this.getChildAt(i);
        }

        /* renamed from: a */
        public C0218d0 mo1825a(View view) {
            return RecyclerView.getChildViewHolderInt(view);
        }

        /* renamed from: a */
        public void mo1826a(View view, int i, ViewGroup.LayoutParams layoutParams) {
            C0218d0 childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
            if (childViewHolderInt != null) {
                if (childViewHolderInt.mo1817t() || childViewHolderInt.mo1821w()) {
                    childViewHolderInt.f1325g0 &= -257;
                } else {
                    StringBuilder sb = new StringBuilder();
                    sb.append("Called attach on a child which is not detached: ");
                    sb.append(childViewHolderInt);
                    throw new IllegalArgumentException(C0789gk.m5554a(RecyclerView.this, sb));
                }
            }
            RecyclerView.this.attachViewToParent(view, i, layoutParams);
        }

        /* renamed from: b */
        public void mo1827b(int i) {
            View childAt = RecyclerView.this.getChildAt(i);
            if (childAt != null) {
                RecyclerView.this.dispatchChildDetached(childAt);
                childAt.clearAnimation();
            }
            RecyclerView.this.removeViewAt(i);
        }

        /* renamed from: b */
        public void mo1828b(View view) {
            C0218d0 childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
            if (childViewHolderInt != null) {
                RecyclerView recyclerView = RecyclerView.this;
                int i = childViewHolderInt.f1332n0;
                if (i == -1) {
                    i = C2189w7.m15016k(childViewHolderInt.f1316X);
                }
                childViewHolderInt.f1331m0 = i;
                recyclerView.setChildImportantForAccessibilityInternal(childViewHolderInt, 4);
            }
        }

        /* renamed from: c */
        public void mo1829c(View view) {
            C0218d0 childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
            if (childViewHolderInt != null) {
                RecyclerView.this.setChildImportantForAccessibilityInternal(childViewHolderInt, childViewHolderInt.f1331m0);
                childViewHolderInt.f1331m0 = 0;
            }
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$f */
    public class C0220f implements C0926ic.C0927a {
        public C0220f() {
        }

        /* renamed from: a */
        public C0218d0 mo1830a(int i) {
            C0218d0 findViewHolderForPosition = RecyclerView.this.findViewHolderForPosition(i, true);
            if (findViewHolderForPosition != null && !RecyclerView.this.mChildHelper.mo7591b(findViewHolderForPosition.f1316X)) {
                return findViewHolderForPosition;
            }
            return null;
        }

        /* renamed from: a */
        public void mo1831a(int i, int i2, Object obj) {
            RecyclerView.this.viewRangeUpdate(i, i2, obj);
            RecyclerView.this.mItemsChanged = true;
        }

        /* renamed from: a */
        public void mo1832a(C0926ic.C0928b bVar) {
            int i = bVar.f7373a;
            if (i == 1) {
                RecyclerView recyclerView = RecyclerView.this;
                recyclerView.mLayout.mo1505a(recyclerView, bVar.f7374b, bVar.f7376d);
            } else if (i == 2) {
                RecyclerView recyclerView2 = RecyclerView.this;
                recyclerView2.mLayout.mo1514b(recyclerView2, bVar.f7374b, bVar.f7376d);
            } else if (i == 4) {
                RecyclerView recyclerView3 = RecyclerView.this;
                recyclerView3.mLayout.mo1507a(recyclerView3, bVar.f7374b, bVar.f7376d, bVar.f7375c);
            } else if (i == 8) {
                RecyclerView recyclerView4 = RecyclerView.this;
                recyclerView4.mLayout.mo1506a(recyclerView4, bVar.f7374b, bVar.f7376d, 1);
            }
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$h */
    public static class C0222h extends Observable<C0223i> {
        /* renamed from: a */
        public void mo1846a(int i, int i2) {
            for (int size = this.mObservers.size() - 1; size >= 0; size--) {
                C0246x xVar = (C0246x) this.mObservers.get(size);
                RecyclerView.this.assertNotInLayoutOrScroll((String) null);
                if (RecyclerView.this.mAdapterHelper.mo6906a(i, i2, 1)) {
                    xVar.mo1999a();
                }
            }
        }

        /* renamed from: a */
        public boolean mo1847a() {
            return !this.mObservers.isEmpty();
        }

        /* renamed from: b */
        public void mo1848b() {
            for (int size = this.mObservers.size() - 1; size >= 0; size--) {
                C0246x xVar = (C0246x) this.mObservers.get(size);
                RecyclerView.this.assertNotInLayoutOrScroll((String) null);
                RecyclerView recyclerView = RecyclerView.this;
                recyclerView.mState.f1295g = true;
                recyclerView.processDataSetCompletelyChanged(true);
                if (!RecyclerView.this.mAdapterHelper.mo6912c()) {
                    RecyclerView.this.requestLayout();
                }
            }
        }

        /* renamed from: c */
        public void mo1850c(int i, int i2) {
            for (int size = this.mObservers.size() - 1; size >= 0; size--) {
                C0246x xVar = (C0246x) this.mObservers.get(size);
                RecyclerView.this.assertNotInLayoutOrScroll((String) null);
                if (RecyclerView.this.mAdapterHelper.mo6910b(i, i2)) {
                    xVar.mo1999a();
                }
            }
        }

        /* renamed from: d */
        public void mo1851d(int i, int i2) {
            for (int size = this.mObservers.size() - 1; size >= 0; size--) {
                C0246x xVar = (C0246x) this.mObservers.get(size);
                RecyclerView.this.assertNotInLayoutOrScroll((String) null);
                if (RecyclerView.this.mAdapterHelper.mo6913c(i, i2)) {
                    xVar.mo1999a();
                }
            }
        }

        /* renamed from: b */
        public void mo1849b(int i, int i2) {
            int size = this.mObservers.size();
            while (true) {
                size--;
                if (size >= 0) {
                    C0246x xVar = (C0246x) this.mObservers.get(size);
                    RecyclerView.this.assertNotInLayoutOrScroll((String) null);
                    if (RecyclerView.this.mAdapterHelper.mo6907a(i, i2, (Object) null)) {
                        xVar.mo1999a();
                    }
                } else {
                    return;
                }
            }
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$i */
    public static abstract class C0223i {
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$j */
    public interface C0224j {
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$k */
    public static class C0225k {
        /* renamed from: a */
        public EdgeEffect mo1852a(RecyclerView recyclerView) {
            return new EdgeEffect(recyclerView.getContext());
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$l */
    public static abstract class C0226l {

        /* renamed from: a */
        public C0228b f1338a = null;

        /* renamed from: b */
        public ArrayList<C0227a> f1339b = new ArrayList<>();

        /* renamed from: c */
        public long f1340c = 120;

        /* renamed from: d */
        public long f1341d = 120;

        /* renamed from: e */
        public long f1342e = 250;

        /* renamed from: f */
        public long f1343f = 250;

        /* renamed from: androidx.recyclerview.widget.RecyclerView$l$a */
        public interface C0227a {
            /* renamed from: a */
            void mo1860a();
        }

        /* renamed from: androidx.recyclerview.widget.RecyclerView$l$b */
        public interface C0228b {
        }

        /* renamed from: androidx.recyclerview.widget.RecyclerView$l$c */
        public static class C0229c {

            /* renamed from: a */
            public int f1344a;

            /* renamed from: b */
            public int f1345b;
        }

        /* renamed from: b */
        public static int m1204b(C0218d0 d0Var) {
            int i = d0Var.f1325g0 & 14;
            if (d0Var.mo1813p()) {
                return 4;
            }
            if ((i & 4) != 0) {
                return i;
            }
            int i2 = d0Var.f1319a0;
            int k = d0Var.mo1808k();
            return (i2 == -1 || k == -1 || i2 == k) ? i : i | 2048;
        }

        /* renamed from: a */
        public final void mo1853a() {
            int size = this.f1339b.size();
            for (int i = 0; i < size; i++) {
                this.f1339b.get(i).mo1860a();
            }
            this.f1339b.clear();
        }

        /* renamed from: a */
        public abstract void mo1854a(C0218d0 d0Var);

        /* renamed from: a */
        public abstract boolean mo383a(C0218d0 d0Var, C0218d0 d0Var2, C0229c cVar, C0229c cVar2);

        /* renamed from: a */
        public abstract boolean mo384a(C0218d0 d0Var, C0229c cVar, C0229c cVar2);

        /* renamed from: a */
        public boolean mo1855a(C0218d0 d0Var, List<Object> list) {
            return !((C0092ad) this).f360g || d0Var.mo1813p();
        }

        /* renamed from: b */
        public abstract void mo1856b();

        /* renamed from: b */
        public abstract boolean mo386b(C0218d0 d0Var, C0229c cVar, C0229c cVar2);

        /* renamed from: c */
        public long mo1857c() {
            return this.f1342e;
        }

        /* renamed from: c */
        public abstract boolean mo388c(C0218d0 d0Var, C0229c cVar, C0229c cVar2);

        /* renamed from: d */
        public abstract boolean mo1858d();

        /* renamed from: e */
        public C0229c mo1859e() {
            return new C0229c();
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$m */
    public class C0230m implements C0226l.C0228b {
        public C0230m() {
        }

        /* renamed from: a */
        public void mo1861a(C0218d0 d0Var) {
            boolean z = true;
            d0Var.mo1804a(true);
            if (d0Var.f1323e0 != null && d0Var.f1324f0 == null) {
                d0Var.f1323e0 = null;
            }
            d0Var.f1324f0 = null;
            if ((d0Var.f1325g0 & 16) == 0) {
                z = false;
            }
            if (!z && !RecyclerView.this.removeAnimatingView(d0Var.f1316X) && d0Var.mo1817t()) {
                RecyclerView.this.removeDetachedView(d0Var.f1316X, false);
            }
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$n */
    public static abstract class C0231n {
        /* renamed from: a */
        public void mo1862a(Canvas canvas, RecyclerView recyclerView, C0212a0 a0Var) {
        }

        /* renamed from: a */
        public void mo1863a(Rect rect, View view, RecyclerView recyclerView) {
            ((C0237p) view.getLayoutParams()).mo1970n();
            rect.set(0, 0, 0, 0);
        }

        /* renamed from: b */
        public void mo1864b(Canvas canvas, RecyclerView recyclerView, C0212a0 a0Var) {
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$p */
    public static class C0237p extends ViewGroup.MarginLayoutParams {

        /* renamed from: X */
        public C0218d0 f1371X;

        /* renamed from: Y */
        public final Rect f1372Y = new Rect();

        /* renamed from: Z */
        public boolean f1373Z = true;

        /* renamed from: a0 */
        public boolean f1374a0 = false;

        public C0237p(int i, int i2) {
            super(i, i2);
        }

        public C0237p(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public C0237p(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public C0237p(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        public C0237p(C0237p pVar) {
            super(pVar);
        }

        /* renamed from: n */
        public int mo1970n() {
            return this.f1371X.mo1809l();
        }

        /* renamed from: o */
        public boolean mo1971o() {
            return this.f1371X.mo1819u();
        }

        /* renamed from: p */
        public boolean mo1972p() {
            return this.f1371X.mo1815r();
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$q */
    public interface C0238q {
        /* renamed from: a */
        void mo1973a(View view);

        /* renamed from: b */
        void mo1974b(View view);
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$r */
    public static abstract class C0239r {
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$s */
    public interface C0240s {
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$t */
    public static abstract class C0241t {
        /* renamed from: a */
        public void mo1975a(RecyclerView recyclerView, int i) {
        }

        /* renamed from: a */
        public void mo1976a(RecyclerView recyclerView, int i, int i2) {
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$v */
    public final class C0244v {

        /* renamed from: a */
        public final ArrayList<C0218d0> f1381a = new ArrayList<>();

        /* renamed from: b */
        public ArrayList<C0218d0> f1382b = null;

        /* renamed from: c */
        public final ArrayList<C0218d0> f1383c = new ArrayList<>();

        /* renamed from: d */
        public final List<C0218d0> f1384d = Collections.unmodifiableList(this.f1381a);

        /* renamed from: e */
        public int f1385e = 2;

        /* renamed from: f */
        public int f1386f = 2;

        /* renamed from: g */
        public C0242u f1387g;

        public C0244v() {
        }

        /* renamed from: a */
        public void mo1985a() {
            this.f1381a.clear();
            mo1995c();
        }

        /* renamed from: a */
        public final void mo1987a(ViewGroup viewGroup, boolean z) {
            for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                View childAt = viewGroup.getChildAt(childCount);
                if (childAt instanceof ViewGroup) {
                    mo1987a((ViewGroup) childAt, true);
                }
            }
            if (z) {
                if (viewGroup.getVisibility() == 4) {
                    viewGroup.setVisibility(0);
                    viewGroup.setVisibility(4);
                    return;
                }
                int visibility = viewGroup.getVisibility();
                viewGroup.setVisibility(4);
                viewGroup.setVisibility(visibility);
            }
        }

        /* renamed from: a */
        public void mo1988a(C0214b0 b0Var) {
        }

        /* renamed from: a */
        public void mo1990a(C0218d0 d0Var, boolean z) {
            RecyclerView.clearNestedRecyclerViewIfNotNested(d0Var);
            View view = d0Var.f1316X;
            C2435zc zcVar = RecyclerView.this.mAccessibilityDelegate;
            if (zcVar != null) {
                C2435zc.C2436a aVar = zcVar.f18284e;
                C2189w7.m14988a(view, aVar instanceof C2435zc.C2436a ? aVar.f18286e.remove(view) : null);
            }
            if (z) {
                C0245w wVar = RecyclerView.this.mRecyclerListener;
                if (wVar != null) {
                    wVar.mo1998a(d0Var);
                }
                C0221g gVar = RecyclerView.this.mAdapter;
                if (gVar != null) {
                    gVar.mo1836a(d0Var);
                }
                RecyclerView recyclerView = RecyclerView.this;
                if (recyclerView.mState != null) {
                    recyclerView.mViewInfoStore.mo5098d(d0Var);
                }
            }
            d0Var.f1333o0 = null;
            mo1992b().mo1980a(d0Var);
        }

        /* renamed from: b */
        public View mo1991b(int i) {
            return mo1984a(i, false, RecyclerView.FOREVER_NS).f1316X;
        }

        /* renamed from: b */
        public C0242u mo1992b() {
            if (this.f1387g == null) {
                this.f1387g = new C0242u();
            }
            return this.f1387g;
        }

        /* renamed from: b */
        public void mo1994b(C0218d0 d0Var) {
            (d0Var.f1330l0 ? this.f1382b : this.f1381a).remove(d0Var);
            d0Var.f1329k0 = null;
            d0Var.f1330l0 = false;
            d0Var.mo1807j();
        }

        /* renamed from: c */
        public void mo1995c() {
            for (int size = this.f1383c.size() - 1; size >= 0; size--) {
                mo1996c(size);
            }
            this.f1383c.clear();
            if (RecyclerView.ALLOW_THREAD_GAP_WORK) {
                C1692qc.C1694b bVar = RecyclerView.this.mPrefetchRegistry;
                int[] iArr = bVar.f12992c;
                if (iArr != null) {
                    Arrays.fill(iArr, -1);
                }
                bVar.f12993d = 0;
            }
        }

        /* renamed from: c */
        public void mo1996c(int i) {
            mo1990a(this.f1383c.get(i), true);
            this.f1383c.remove(i);
        }

        /* renamed from: d */
        public void mo1997d() {
            C0232o oVar = RecyclerView.this.mLayout;
            this.f1386f = this.f1385e + (oVar != null ? oVar.f1359j0 : 0);
            for (int size = this.f1383c.size() - 1; size >= 0 && this.f1383c.size() > this.f1386f; size--) {
                mo1996c(size);
            }
        }

        /* renamed from: b */
        public void mo1993b(View view) {
            ArrayList<C0218d0> arrayList;
            C0218d0 childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
            if (!childViewHolderInt.mo1805b(12) && childViewHolderInt.mo1819u() && !RecyclerView.this.canReuseUpdatedViewHolder(childViewHolderInt)) {
                if (this.f1382b == null) {
                    this.f1382b = new ArrayList<>();
                }
                childViewHolderInt.f1329k0 = this;
                childViewHolderInt.f1330l0 = true;
                arrayList = this.f1382b;
            } else if (!childViewHolderInt.mo1813p() || childViewHolderInt.mo1815r() || RecyclerView.this.mAdapter.f1337b) {
                childViewHolderInt.f1329k0 = this;
                childViewHolderInt.f1330l0 = false;
                arrayList = this.f1381a;
            } else {
                throw new IllegalArgumentException(C0789gk.m5554a(RecyclerView.this, C0789gk.m5562a("Called scrap view with an invalid view. Invalid views cannot be reused from scrap, they should rebound from recycler pool.")));
            }
            arrayList.add(childViewHolderInt);
        }

        /* renamed from: a */
        public int mo1983a(int i) {
            if (i < 0 || i >= RecyclerView.this.mState.mo1790a()) {
                StringBuilder sb = new StringBuilder();
                sb.append("invalid position ");
                sb.append(i);
                sb.append(". State item count is ");
                sb.append(RecyclerView.this.mState.mo1790a());
                throw new IndexOutOfBoundsException(C0789gk.m5554a(RecyclerView.this, sb));
            }
            RecyclerView recyclerView = RecyclerView.this;
            if (!recyclerView.mState.f1296h) {
                return i;
            }
            return recyclerView.mAdapterHelper.mo6899a(i, 0);
        }

        /* renamed from: a */
        public void mo1986a(View view) {
            C0218d0 childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
            if (childViewHolderInt.mo1817t()) {
                RecyclerView.this.removeDetachedView(view, false);
            }
            if (childViewHolderInt.mo1816s()) {
                childViewHolderInt.f1329k0.mo1994b(childViewHolderInt);
            } else if (childViewHolderInt.mo1822x()) {
                childViewHolderInt.mo1807j();
            }
            mo1989a(childViewHolderInt);
            if (RecyclerView.this.mItemAnimator != null && !childViewHolderInt.mo1814q()) {
                RecyclerView.this.mItemAnimator.mo1854a(childViewHolderInt);
            }
        }

        /* renamed from: a */
        public void mo1989a(C0218d0 d0Var) {
            boolean z;
            boolean z2 = false;
            if (d0Var.mo1816s() || d0Var.f1316X.getParent() != null) {
                StringBuilder a = C0789gk.m5562a("Scrapped or attached views may not be recycled. isScrap:");
                a.append(d0Var.mo1816s());
                a.append(" isAttached:");
                if (d0Var.f1316X.getParent() != null) {
                    z2 = true;
                }
                a.append(z2);
                throw new IllegalArgumentException(C0789gk.m5554a(RecyclerView.this, a));
            } else if (d0Var.mo1817t()) {
                StringBuilder sb = new StringBuilder();
                sb.append("Tmp detached view should be removed from RecyclerView before it can be recycled: ");
                sb.append(d0Var);
                throw new IllegalArgumentException(C0789gk.m5554a(RecyclerView.this, sb));
            } else if (!d0Var.mo1821w()) {
                boolean z3 = (d0Var.f1325g0 & 16) == 0 && C2189w7.m15029x(d0Var.f1316X);
                C0221g gVar = RecyclerView.this.mAdapter;
                if (gVar != null && z3) {
                    gVar.mo1843b();
                }
                if (d0Var.mo1814q()) {
                    if (this.f1386f <= 0 || d0Var.mo1805b(526)) {
                        z = false;
                    } else {
                        int size = this.f1383c.size();
                        if (size >= this.f1386f && size > 0) {
                            mo1996c(0);
                            size--;
                        }
                        if (RecyclerView.ALLOW_THREAD_GAP_WORK && size > 0 && !RecyclerView.this.mPrefetchRegistry.mo10311a(d0Var.f1318Z)) {
                            do {
                                size--;
                                if (size < 0) {
                                    break;
                                }
                            } while (RecyclerView.this.mPrefetchRegistry.mo10311a(this.f1383c.get(size).f1318Z));
                            size++;
                        }
                        this.f1383c.add(size, d0Var);
                        z = true;
                    }
                    if (!z) {
                        mo1990a(d0Var, true);
                        z2 = true;
                    }
                } else {
                    z = false;
                }
                RecyclerView.this.mViewInfoStore.mo5098d(d0Var);
                if (!z && !z2 && z3) {
                    d0Var.f1333o0 = null;
                }
            } else {
                throw new IllegalArgumentException(C0789gk.m5554a(RecyclerView.this, C0789gk.m5562a("Trying to recycle an ignored view holder. You should first call stopIgnoringView(view) before calling recycle.")));
            }
        }

        /* JADX WARNING: Code restructure failed: missing block: B:160:0x02fd, code lost:
            r9 = null;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:222:0x0449, code lost:
            if (r9.mo1813p() == false) goto L_0x047f;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:231:0x047d, code lost:
            if ((r10 == 0 || r10 + r7 < r20) == false) goto L_0x047f;
         */
        /* JADX WARNING: Removed duplicated region for block: B:121:0x0245  */
        /* JADX WARNING: Removed duplicated region for block: B:124:0x0249  */
        /* JADX WARNING: Removed duplicated region for block: B:176:0x033d  */
        /* JADX WARNING: Removed duplicated region for block: B:208:0x03fb  */
        /* JADX WARNING: Removed duplicated region for block: B:213:0x0432  */
        /* JADX WARNING: Removed duplicated region for block: B:214:0x0435  */
        /* JADX WARNING: Removed duplicated region for block: B:250:0x04db  */
        /* JADX WARNING: Removed duplicated region for block: B:251:0x04e2  */
        /* JADX WARNING: Removed duplicated region for block: B:34:0x0089  */
        /* JADX WARNING: Removed duplicated region for block: B:39:0x0090  */
        /* renamed from: a */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public androidx.recyclerview.widget.RecyclerView.C0218d0 mo1984a(int r18, boolean r19, long r20) {
            /*
                r17 = this;
                r0 = r17
                r1 = r18
                if (r1 < 0) goto L_0x0504
                androidx.recyclerview.widget.RecyclerView r2 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$a0 r2 = r2.mState
                int r2 = r2.mo1790a()
                if (r1 >= r2) goto L_0x0504
                androidx.recyclerview.widget.RecyclerView r2 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$a0 r2 = r2.mState
                boolean r2 = r2.f1296h
                r3 = 32
                r4 = 0
                r5 = 0
                if (r2 == 0) goto L_0x008b
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$d0> r2 = r0.f1382b
                if (r2 == 0) goto L_0x0086
                int r2 = r2.size()
                if (r2 != 0) goto L_0x0027
                goto L_0x0086
            L_0x0027:
                r6 = 0
            L_0x0028:
                if (r6 >= r2) goto L_0x0045
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$d0> r7 = r0.f1382b
                java.lang.Object r7 = r7.get(r6)
                androidx.recyclerview.widget.RecyclerView$d0 r7 = (androidx.recyclerview.widget.RecyclerView.C0218d0) r7
                boolean r8 = r7.mo1822x()
                if (r8 != 0) goto L_0x0042
                int r8 = r7.mo1809l()
                if (r8 != r1) goto L_0x0042
                r7.mo1800a((int) r3)
                goto L_0x0087
            L_0x0042:
                int r6 = r6 + 1
                goto L_0x0028
            L_0x0045:
                androidx.recyclerview.widget.RecyclerView r6 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$g r7 = r6.mAdapter
                boolean r7 = r7.f1337b
                if (r7 == 0) goto L_0x0086
                ic r6 = r6.mAdapterHelper
                int r6 = r6.mo6899a((int) r1, (int) r5)
                if (r6 <= 0) goto L_0x0086
                androidx.recyclerview.widget.RecyclerView r7 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$g r7 = r7.mAdapter
                int r7 = r7.mo1833a()
                if (r6 >= r7) goto L_0x0086
                androidx.recyclerview.widget.RecyclerView r7 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$g r7 = r7.mAdapter
                long r6 = r7.mo1834a((int) r6)
                r8 = 0
            L_0x0068:
                if (r8 >= r2) goto L_0x0086
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$d0> r9 = r0.f1382b
                java.lang.Object r9 = r9.get(r8)
                androidx.recyclerview.widget.RecyclerView$d0 r9 = (androidx.recyclerview.widget.RecyclerView.C0218d0) r9
                boolean r10 = r9.mo1822x()
                if (r10 != 0) goto L_0x0083
                long r10 = r9.f1320b0
                int r12 = (r10 > r6 ? 1 : (r10 == r6 ? 0 : -1))
                if (r12 != 0) goto L_0x0083
                r9.mo1800a((int) r3)
                r7 = r9
                goto L_0x0087
            L_0x0083:
                int r8 = r8 + 1
                goto L_0x0068
            L_0x0086:
                r7 = r4
            L_0x0087:
                if (r7 == 0) goto L_0x008c
                r2 = 1
                goto L_0x008d
            L_0x008b:
                r7 = r4
            L_0x008c:
                r2 = 0
            L_0x008d:
                r6 = -1
                if (r7 != 0) goto L_0x0245
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$d0> r7 = r0.f1381a
                int r7 = r7.size()
                r8 = 0
            L_0x0097:
                if (r8 >= r7) goto L_0x00c9
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$d0> r9 = r0.f1381a
                java.lang.Object r9 = r9.get(r8)
                androidx.recyclerview.widget.RecyclerView$d0 r9 = (androidx.recyclerview.widget.RecyclerView.C0218d0) r9
                boolean r10 = r9.mo1822x()
                if (r10 != 0) goto L_0x00c6
                int r10 = r9.mo1809l()
                if (r10 != r1) goto L_0x00c6
                boolean r10 = r9.mo1813p()
                if (r10 != 0) goto L_0x00c6
                androidx.recyclerview.widget.RecyclerView r10 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$a0 r10 = r10.mState
                boolean r10 = r10.f1296h
                if (r10 != 0) goto L_0x00c1
                boolean r10 = r9.mo1815r()
                if (r10 != 0) goto L_0x00c6
            L_0x00c1:
                r9.mo1800a((int) r3)
                goto L_0x01b7
            L_0x00c6:
                int r8 = r8 + 1
                goto L_0x0097
            L_0x00c9:
                if (r19 != 0) goto L_0x0188
                androidx.recyclerview.widget.RecyclerView r7 = androidx.recyclerview.widget.RecyclerView.this
                jc r7 = r7.mChildHelper
                java.util.List<android.view.View> r8 = r7.f8345c
                int r8 = r8.size()
                r9 = 0
            L_0x00d6:
                if (r9 >= r8) goto L_0x00fe
                java.util.List<android.view.View> r10 = r7.f8345c
                java.lang.Object r10 = r10.get(r9)
                android.view.View r10 = (android.view.View) r10
                jc$b r11 = r7.f8343a
                androidx.recyclerview.widget.RecyclerView$e r11 = (androidx.recyclerview.widget.RecyclerView.C0219e) r11
                androidx.recyclerview.widget.RecyclerView$d0 r11 = r11.mo1825a((android.view.View) r10)
                int r12 = r11.mo1809l()
                if (r12 != r1) goto L_0x00fb
                boolean r12 = r11.mo1813p()
                if (r12 != 0) goto L_0x00fb
                boolean r11 = r11.mo1815r()
                if (r11 != 0) goto L_0x00fb
                goto L_0x00ff
            L_0x00fb:
                int r9 = r9 + 1
                goto L_0x00d6
            L_0x00fe:
                r10 = r4
            L_0x00ff:
                if (r10 == 0) goto L_0x0188
                androidx.recyclerview.widget.RecyclerView$d0 r7 = androidx.recyclerview.widget.RecyclerView.getChildViewHolderInt(r10)
                androidx.recyclerview.widget.RecyclerView r8 = androidx.recyclerview.widget.RecyclerView.this
                jc r8 = r8.mChildHelper
                jc$b r9 = r8.f8343a
                androidx.recyclerview.widget.RecyclerView$e r9 = (androidx.recyclerview.widget.RecyclerView.C0219e) r9
                androidx.recyclerview.widget.RecyclerView r9 = androidx.recyclerview.widget.RecyclerView.this
                int r9 = r9.indexOfChild(r10)
                if (r9 < 0) goto L_0x0171
                jc$a r11 = r8.f8344b
                boolean r11 = r11.mo7602c(r9)
                if (r11 == 0) goto L_0x015a
                jc$a r11 = r8.f8344b
                r11.mo7598a(r9)
                r8.mo7593c((android.view.View) r10)
                androidx.recyclerview.widget.RecyclerView r8 = androidx.recyclerview.widget.RecyclerView.this
                jc r8 = r8.mChildHelper
                int r8 = r8.mo7585a((android.view.View) r10)
                if (r8 == r6) goto L_0x0141
                androidx.recyclerview.widget.RecyclerView r9 = androidx.recyclerview.widget.RecyclerView.this
                jc r9 = r9.mChildHelper
                r9.mo7586a((int) r8)
                r0.mo1993b((android.view.View) r10)
                r8 = 8224(0x2020, float:1.1524E-41)
                r7.mo1800a((int) r8)
                r9 = r7
                goto L_0x01b7
            L_0x0141:
                java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
                java.lang.StringBuilder r2 = new java.lang.StringBuilder
                r2.<init>()
                java.lang.String r3 = "layout index should not be -1 after unhiding a view:"
                r2.append(r3)
                r2.append(r7)
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                java.lang.String r2 = p000.C0789gk.m5554a((androidx.recyclerview.widget.RecyclerView) r3, (java.lang.StringBuilder) r2)
                r1.<init>(r2)
                throw r1
            L_0x015a:
                java.lang.RuntimeException r1 = new java.lang.RuntimeException
                java.lang.StringBuilder r2 = new java.lang.StringBuilder
                r2.<init>()
                java.lang.String r3 = "trying to unhide a view that was not hidden"
                r2.append(r3)
                r2.append(r10)
                java.lang.String r2 = r2.toString()
                r1.<init>(r2)
                throw r1
            L_0x0171:
                java.lang.IllegalArgumentException r1 = new java.lang.IllegalArgumentException
                java.lang.StringBuilder r2 = new java.lang.StringBuilder
                r2.<init>()
                java.lang.String r3 = "view is not a child, cannot hide "
                r2.append(r3)
                r2.append(r10)
                java.lang.String r2 = r2.toString()
                r1.<init>(r2)
                throw r1
            L_0x0188:
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$d0> r7 = r0.f1383c
                int r7 = r7.size()
                r8 = 0
            L_0x018f:
                if (r8 >= r7) goto L_0x01b6
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$d0> r9 = r0.f1383c
                java.lang.Object r9 = r9.get(r8)
                androidx.recyclerview.widget.RecyclerView$d0 r9 = (androidx.recyclerview.widget.RecyclerView.C0218d0) r9
                boolean r10 = r9.mo1813p()
                if (r10 != 0) goto L_0x01b3
                int r10 = r9.mo1809l()
                if (r10 != r1) goto L_0x01b3
                boolean r10 = r9.mo1811n()
                if (r10 != 0) goto L_0x01b3
                if (r19 != 0) goto L_0x01b7
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$d0> r7 = r0.f1383c
                r7.remove(r8)
                goto L_0x01b7
            L_0x01b3:
                int r8 = r8 + 1
                goto L_0x018f
            L_0x01b6:
                r9 = r4
            L_0x01b7:
                if (r9 == 0) goto L_0x0246
                boolean r7 = r9.mo1815r()
                if (r7 == 0) goto L_0x01c6
                androidx.recyclerview.widget.RecyclerView r7 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$a0 r7 = r7.mState
                boolean r7 = r7.f1296h
                goto L_0x0201
            L_0x01c6:
                int r7 = r9.f1318Z
                if (r7 < 0) goto L_0x022c
                androidx.recyclerview.widget.RecyclerView r8 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$g r8 = r8.mAdapter
                int r8 = r8.mo1833a()
                if (r7 >= r8) goto L_0x022c
                androidx.recyclerview.widget.RecyclerView r7 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$a0 r8 = r7.mState
                boolean r8 = r8.f1296h
                if (r8 != 0) goto L_0x01e9
                androidx.recyclerview.widget.RecyclerView$g r7 = r7.mAdapter
                int r8 = r9.f1318Z
                int r7 = r7.mo1839b((int) r8)
                int r8 = r9.f1321c0
                if (r7 == r8) goto L_0x01e9
                goto L_0x01fe
            L_0x01e9:
                androidx.recyclerview.widget.RecyclerView r7 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$g r7 = r7.mAdapter
                boolean r8 = r7.f1337b
                if (r8 == 0) goto L_0x0200
                long r10 = r9.f1320b0
                int r8 = r9.f1318Z
                long r7 = r7.mo1834a((int) r8)
                int r12 = (r10 > r7 ? 1 : (r10 == r7 ? 0 : -1))
                if (r12 != 0) goto L_0x01fe
                goto L_0x0200
            L_0x01fe:
                r7 = 0
                goto L_0x0201
            L_0x0200:
                r7 = 1
            L_0x0201:
                if (r7 != 0) goto L_0x022a
                if (r19 != 0) goto L_0x0228
                r7 = 4
                r9.mo1800a((int) r7)
                boolean r7 = r9.mo1816s()
                if (r7 == 0) goto L_0x021c
                androidx.recyclerview.widget.RecyclerView r7 = androidx.recyclerview.widget.RecyclerView.this
                android.view.View r8 = r9.f1316X
                r7.removeDetachedView(r8, r5)
                androidx.recyclerview.widget.RecyclerView$v r7 = r9.f1329k0
                r7.mo1994b((androidx.recyclerview.widget.RecyclerView.C0218d0) r9)
                goto L_0x0225
            L_0x021c:
                boolean r7 = r9.mo1822x()
                if (r7 == 0) goto L_0x0225
                r9.mo1807j()
            L_0x0225:
                r0.mo1989a((androidx.recyclerview.widget.RecyclerView.C0218d0) r9)
            L_0x0228:
                r9 = r4
                goto L_0x0246
            L_0x022a:
                r2 = 1
                goto L_0x0246
            L_0x022c:
                java.lang.IndexOutOfBoundsException r1 = new java.lang.IndexOutOfBoundsException
                java.lang.StringBuilder r2 = new java.lang.StringBuilder
                r2.<init>()
                java.lang.String r3 = "Inconsistency detected. Invalid view holder adapter position"
                r2.append(r3)
                r2.append(r9)
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                java.lang.String r2 = p000.C0789gk.m5554a((androidx.recyclerview.widget.RecyclerView) r3, (java.lang.StringBuilder) r2)
                r1.<init>(r2)
                throw r1
            L_0x0245:
                r9 = r7
            L_0x0246:
                r7 = 2
                if (r9 != 0) goto L_0x03de
                androidx.recyclerview.widget.RecyclerView r8 = androidx.recyclerview.widget.RecyclerView.this
                ic r8 = r8.mAdapterHelper
                int r8 = r8.mo6899a((int) r1, (int) r5)
                if (r8 < 0) goto L_0x03ad
                androidx.recyclerview.widget.RecyclerView r10 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$g r10 = r10.mAdapter
                int r10 = r10.mo1833a()
                if (r8 >= r10) goto L_0x03ad
                androidx.recyclerview.widget.RecyclerView r10 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$g r10 = r10.mAdapter
                int r10 = r10.mo1839b((int) r8)
                androidx.recyclerview.widget.RecyclerView r11 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$g r11 = r11.mAdapter
                boolean r12 = r11.f1337b
                if (r12 == 0) goto L_0x0303
                long r11 = r11.mo1834a((int) r8)
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$d0> r9 = r0.f1381a
                int r9 = r9.size()
                int r9 = r9 + r6
            L_0x0278:
                if (r9 < 0) goto L_0x02cb
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$d0> r13 = r0.f1381a
                java.lang.Object r13 = r13.get(r9)
                androidx.recyclerview.widget.RecyclerView$d0 r13 = (androidx.recyclerview.widget.RecyclerView.C0218d0) r13
                long r14 = r13.f1320b0
                int r16 = (r14 > r11 ? 1 : (r14 == r11 ? 0 : -1))
                if (r16 != 0) goto L_0x02c8
                boolean r14 = r13.mo1822x()
                if (r14 != 0) goto L_0x02c8
                int r14 = r13.f1321c0
                if (r10 != r14) goto L_0x02aa
                r13.mo1800a((int) r3)
                boolean r3 = r13.mo1815r()
                if (r3 == 0) goto L_0x02a8
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$a0 r3 = r3.mState
                boolean r3 = r3.f1296h
                if (r3 != 0) goto L_0x02a8
                r3 = 14
                r13.mo1801a((int) r7, (int) r3)
            L_0x02a8:
                r9 = r13
                goto L_0x02fe
            L_0x02aa:
                if (r19 != 0) goto L_0x02c8
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$d0> r14 = r0.f1381a
                r14.remove(r9)
                androidx.recyclerview.widget.RecyclerView r14 = androidx.recyclerview.widget.RecyclerView.this
                android.view.View r15 = r13.f1316X
                r14.removeDetachedView(r15, r5)
                android.view.View r13 = r13.f1316X
                androidx.recyclerview.widget.RecyclerView$d0 r13 = androidx.recyclerview.widget.RecyclerView.getChildViewHolderInt(r13)
                r13.f1329k0 = r4
                r13.f1330l0 = r5
                r13.mo1807j()
                r0.mo1989a((androidx.recyclerview.widget.RecyclerView.C0218d0) r13)
            L_0x02c8:
                int r9 = r9 + -1
                goto L_0x0278
            L_0x02cb:
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$d0> r3 = r0.f1383c
                int r3 = r3.size()
                int r3 = r3 + r6
            L_0x02d2:
                if (r3 < 0) goto L_0x02fd
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$d0> r9 = r0.f1383c
                java.lang.Object r9 = r9.get(r3)
                androidx.recyclerview.widget.RecyclerView$d0 r9 = (androidx.recyclerview.widget.RecyclerView.C0218d0) r9
                long r13 = r9.f1320b0
                int r15 = (r13 > r11 ? 1 : (r13 == r11 ? 0 : -1))
                if (r15 != 0) goto L_0x02fa
                boolean r13 = r9.mo1811n()
                if (r13 != 0) goto L_0x02fa
                int r13 = r9.f1321c0
                if (r10 != r13) goto L_0x02f4
                if (r19 != 0) goto L_0x02fe
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$d0> r11 = r0.f1383c
                r11.remove(r3)
                goto L_0x02fe
            L_0x02f4:
                if (r19 != 0) goto L_0x02fa
                r0.mo1996c(r3)
                goto L_0x02fd
            L_0x02fa:
                int r3 = r3 + -1
                goto L_0x02d2
            L_0x02fd:
                r9 = r4
            L_0x02fe:
                if (r9 == 0) goto L_0x0303
                r9.f1318Z = r8
                r2 = 1
            L_0x0303:
                if (r9 != 0) goto L_0x0350
                androidx.recyclerview.widget.RecyclerView$u r3 = r17.mo1992b()
                android.util.SparseArray<androidx.recyclerview.widget.RecyclerView$u$a> r3 = r3.f1375a
                java.lang.Object r3 = r3.get(r10)
                androidx.recyclerview.widget.RecyclerView$u$a r3 = (androidx.recyclerview.widget.RecyclerView.C0242u.C0243a) r3
                if (r3 == 0) goto L_0x033a
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$d0> r8 = r3.f1377a
                boolean r8 = r8.isEmpty()
                if (r8 != 0) goto L_0x033a
                java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$d0> r3 = r3.f1377a
                int r8 = r3.size()
                int r8 = r8 + r6
            L_0x0322:
                if (r8 < 0) goto L_0x033a
                java.lang.Object r6 = r3.get(r8)
                androidx.recyclerview.widget.RecyclerView$d0 r6 = (androidx.recyclerview.widget.RecyclerView.C0218d0) r6
                boolean r6 = r6.mo1811n()
                if (r6 != 0) goto L_0x0337
                java.lang.Object r3 = r3.remove(r8)
                androidx.recyclerview.widget.RecyclerView$d0 r3 = (androidx.recyclerview.widget.RecyclerView.C0218d0) r3
                goto L_0x033b
            L_0x0337:
                int r8 = r8 + -1
                goto L_0x0322
            L_0x033a:
                r3 = r4
            L_0x033b:
                if (r3 == 0) goto L_0x034f
                r3.mo1820v()
                boolean r6 = androidx.recyclerview.widget.RecyclerView.FORCE_INVALIDATE_DISPLAY_LIST
                if (r6 == 0) goto L_0x034f
                android.view.View r6 = r3.f1316X
                boolean r8 = r6 instanceof android.view.ViewGroup
                if (r8 == 0) goto L_0x034f
                android.view.ViewGroup r6 = (android.view.ViewGroup) r6
                r0.mo1987a((android.view.ViewGroup) r6, (boolean) r5)
            L_0x034f:
                r9 = r3
            L_0x0350:
                if (r9 != 0) goto L_0x03de
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                long r8 = r3.getNanoTime()
                r11 = 9223372036854775807(0x7fffffffffffffff, double:NaN)
                int r3 = (r20 > r11 ? 1 : (r20 == r11 ? 0 : -1))
                if (r3 == 0) goto L_0x037b
                androidx.recyclerview.widget.RecyclerView$u r3 = r0.f1387g
                androidx.recyclerview.widget.RecyclerView$u$a r3 = r3.mo1978a((int) r10)
                long r11 = r3.f1379c
                r13 = 0
                int r3 = (r11 > r13 ? 1 : (r11 == r13 ? 0 : -1))
                if (r3 == 0) goto L_0x0377
                long r11 = r11 + r8
                int r3 = (r11 > r20 ? 1 : (r11 == r20 ? 0 : -1))
                if (r3 >= 0) goto L_0x0375
                goto L_0x0377
            L_0x0375:
                r3 = 0
                goto L_0x0378
            L_0x0377:
                r3 = 1
            L_0x0378:
                if (r3 != 0) goto L_0x037b
                return r4
            L_0x037b:
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$g r4 = r3.mAdapter
                androidx.recyclerview.widget.RecyclerView$d0 r3 = r4.mo1835a((android.view.ViewGroup) r3, (int) r10)
                boolean r4 = androidx.recyclerview.widget.RecyclerView.ALLOW_THREAD_GAP_WORK
                if (r4 == 0) goto L_0x0396
                android.view.View r4 = r3.f1316X
                androidx.recyclerview.widget.RecyclerView r4 = androidx.recyclerview.widget.RecyclerView.findNestedRecyclerView(r4)
                if (r4 == 0) goto L_0x0396
                java.lang.ref.WeakReference r6 = new java.lang.ref.WeakReference
                r6.<init>(r4)
                r3.f1317Y = r6
            L_0x0396:
                androidx.recyclerview.widget.RecyclerView r4 = androidx.recyclerview.widget.RecyclerView.this
                long r11 = r4.getNanoTime()
                androidx.recyclerview.widget.RecyclerView$u r4 = r0.f1387g
                long r11 = r11 - r8
                androidx.recyclerview.widget.RecyclerView$u$a r6 = r4.mo1978a((int) r10)
                long r8 = r6.f1379c
                long r8 = r4.mo1977a(r8, r11)
                r6.f1379c = r8
                r9 = r3
                goto L_0x03de
            L_0x03ad:
                java.lang.IndexOutOfBoundsException r2 = new java.lang.IndexOutOfBoundsException
                java.lang.StringBuilder r3 = new java.lang.StringBuilder
                r3.<init>()
                java.lang.String r4 = "Inconsistency detected. Invalid item position "
                r3.append(r4)
                r3.append(r1)
                java.lang.String r1 = "(offset:"
                r3.append(r1)
                r3.append(r8)
                java.lang.String r1 = ").state:"
                r3.append(r1)
                androidx.recyclerview.widget.RecyclerView r1 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$a0 r1 = r1.mState
                int r1 = r1.mo1790a()
                r3.append(r1)
                androidx.recyclerview.widget.RecyclerView r1 = androidx.recyclerview.widget.RecyclerView.this
                java.lang.String r1 = p000.C0789gk.m5554a((androidx.recyclerview.widget.RecyclerView) r1, (java.lang.StringBuilder) r3)
                r2.<init>(r1)
                throw r2
            L_0x03de:
                if (r2 == 0) goto L_0x0424
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$a0 r3 = r3.mState
                boolean r3 = r3.f1296h
                if (r3 != 0) goto L_0x0424
                r3 = 8192(0x2000, float:1.14794E-41)
                boolean r4 = r9.mo1805b(r3)
                if (r4 == 0) goto L_0x0424
                r9.mo1801a((int) r5, (int) r3)
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$a0 r3 = r3.mState
                boolean r3 = r3.f1299k
                if (r3 == 0) goto L_0x0424
                androidx.recyclerview.widget.RecyclerView.C0226l.m1204b(r9)
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$l r4 = r3.mItemAnimator
                androidx.recyclerview.widget.RecyclerView$a0 r3 = r3.mState
                r9.mo1810m()
                androidx.recyclerview.widget.RecyclerView$l$c r3 = r4.mo1859e()
                android.view.View r4 = r9.f1316X
                int r6 = r4.getLeft()
                r3.f1344a = r6
                int r6 = r4.getTop()
                r3.f1345b = r6
                r4.getRight()
                r4.getBottom()
                androidx.recyclerview.widget.RecyclerView r4 = androidx.recyclerview.widget.RecyclerView.this
                r4.recordAnimationInfoIfBouncedHiddenView(r9, r3)
            L_0x0424:
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$a0 r3 = r3.mState
                boolean r3 = r3.f1296h
                if (r3 == 0) goto L_0x0435
                boolean r3 = r9.mo1812o()
                if (r3 == 0) goto L_0x0435
                r9.f1322d0 = r1
                goto L_0x047f
            L_0x0435:
                boolean r3 = r9.mo1812o()
                if (r3 == 0) goto L_0x044b
                int r3 = r9.f1325g0
                r3 = r3 & r7
                if (r3 == 0) goto L_0x0442
                r3 = 1
                goto L_0x0443
            L_0x0442:
                r3 = 0
            L_0x0443:
                if (r3 != 0) goto L_0x044b
                boolean r3 = r9.mo1813p()
                if (r3 == 0) goto L_0x047f
            L_0x044b:
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                ic r3 = r3.mAdapterHelper
                int r3 = r3.mo6899a((int) r1, (int) r5)
                androidx.recyclerview.widget.RecyclerView r4 = androidx.recyclerview.widget.RecyclerView.this
                r9.f1333o0 = r4
                int r6 = r9.f1321c0
                long r7 = r4.getNanoTime()
                r10 = 9223372036854775807(0x7fffffffffffffff, double:NaN)
                int r4 = (r20 > r10 ? 1 : (r20 == r10 ? 0 : -1))
                if (r4 == 0) goto L_0x0481
                androidx.recyclerview.widget.RecyclerView$u r4 = r0.f1387g
                androidx.recyclerview.widget.RecyclerView$u$a r4 = r4.mo1978a((int) r6)
                long r10 = r4.f1380d
                r12 = 0
                int r4 = (r10 > r12 ? 1 : (r10 == r12 ? 0 : -1))
                if (r4 == 0) goto L_0x047c
                long r10 = r10 + r7
                int r4 = (r10 > r20 ? 1 : (r10 == r20 ? 0 : -1))
                if (r4 >= 0) goto L_0x047a
                goto L_0x047c
            L_0x047a:
                r4 = 0
                goto L_0x047d
            L_0x047c:
                r4 = 1
            L_0x047d:
                if (r4 != 0) goto L_0x0481
            L_0x047f:
                r1 = 0
                goto L_0x04d3
            L_0x0481:
                androidx.recyclerview.widget.RecyclerView r4 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$g r4 = r4.mAdapter
                r4.mo1837a(r9, (int) r3)
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                long r3 = r3.getNanoTime()
                androidx.recyclerview.widget.RecyclerView$u r6 = r0.f1387g
                int r10 = r9.f1321c0
                long r3 = r3 - r7
                androidx.recyclerview.widget.RecyclerView$u$a r7 = r6.mo1978a((int) r10)
                long r10 = r7.f1380d
                long r3 = r6.mo1977a(r10, r3)
                r7.f1380d = r3
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                boolean r3 = r3.isAccessibilityEnabled()
                if (r3 == 0) goto L_0x04c8
                android.view.View r3 = r9.f1316X
                int r4 = p000.C2189w7.m15016k(r3)
                if (r4 != 0) goto L_0x04b5
                int r4 = android.os.Build.VERSION.SDK_INT
                r4 = 1
                r3.setImportantForAccessibility(r4)
            L_0x04b5:
                androidx.recyclerview.widget.RecyclerView r4 = androidx.recyclerview.widget.RecyclerView.this
                zc r4 = r4.mAccessibilityDelegate
                if (r4 != 0) goto L_0x04bc
                goto L_0x04c8
            L_0x04bc:
                zc$a r4 = r4.f18284e
                boolean r6 = r4 instanceof p000.C2435zc.C2436a
                if (r6 == 0) goto L_0x04c5
                r4.mo13126b(r3)
            L_0x04c5:
                p000.C2189w7.m14988a((android.view.View) r3, (p000.C0757g7) r4)
            L_0x04c8:
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$a0 r3 = r3.mState
                boolean r3 = r3.f1296h
                if (r3 == 0) goto L_0x04d2
                r9.f1322d0 = r1
            L_0x04d2:
                r1 = 1
            L_0x04d3:
                android.view.View r3 = r9.f1316X
                android.view.ViewGroup$LayoutParams r3 = r3.getLayoutParams()
                if (r3 != 0) goto L_0x04e2
                androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
                android.view.ViewGroup$LayoutParams r3 = r3.generateDefaultLayoutParams()
                goto L_0x04f0
            L_0x04e2:
                androidx.recyclerview.widget.RecyclerView r4 = androidx.recyclerview.widget.RecyclerView.this
                boolean r4 = r4.checkLayoutParams(r3)
                if (r4 != 0) goto L_0x04f8
                androidx.recyclerview.widget.RecyclerView r4 = androidx.recyclerview.widget.RecyclerView.this
                android.view.ViewGroup$LayoutParams r3 = r4.generateLayoutParams((android.view.ViewGroup.LayoutParams) r3)
            L_0x04f0:
                androidx.recyclerview.widget.RecyclerView$p r3 = (androidx.recyclerview.widget.RecyclerView.C0237p) r3
                android.view.View r4 = r9.f1316X
                r4.setLayoutParams(r3)
                goto L_0x04fa
            L_0x04f8:
                androidx.recyclerview.widget.RecyclerView$p r3 = (androidx.recyclerview.widget.RecyclerView.C0237p) r3
            L_0x04fa:
                r3.f1371X = r9
                if (r2 == 0) goto L_0x0501
                if (r1 == 0) goto L_0x0501
                r5 = 1
            L_0x0501:
                r3.f1374a0 = r5
                return r9
            L_0x0504:
                java.lang.IndexOutOfBoundsException r2 = new java.lang.IndexOutOfBoundsException
                java.lang.StringBuilder r3 = new java.lang.StringBuilder
                r3.<init>()
                java.lang.String r4 = "Invalid item position "
                r3.append(r4)
                r3.append(r1)
                java.lang.String r4 = "("
                r3.append(r4)
                r3.append(r1)
                java.lang.String r1 = "). Item count:"
                r3.append(r1)
                androidx.recyclerview.widget.RecyclerView r1 = androidx.recyclerview.widget.RecyclerView.this
                androidx.recyclerview.widget.RecyclerView$a0 r1 = r1.mState
                int r1 = r1.mo1790a()
                r3.append(r1)
                androidx.recyclerview.widget.RecyclerView r1 = androidx.recyclerview.widget.RecyclerView.this
                java.lang.String r1 = p000.C0789gk.m5554a((androidx.recyclerview.widget.RecyclerView) r1, (java.lang.StringBuilder) r3)
                r2.<init>(r1)
                goto L_0x0536
            L_0x0535:
                throw r2
            L_0x0536:
                goto L_0x0535
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.C0244v.mo1984a(int, boolean, long):androidx.recyclerview.widget.RecyclerView$d0");
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$w */
    public interface C0245w {
        /* renamed from: a */
        void mo1998a(C0218d0 d0Var);
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$x */
    public class C0246x extends C0223i {
        public C0246x() {
        }

        /* renamed from: a */
        public void mo1999a() {
            if (RecyclerView.POST_UPDATES_ON_ANIMATION) {
                RecyclerView recyclerView = RecyclerView.this;
                if (recyclerView.mHasFixedSize && recyclerView.mIsAttached) {
                    C2189w7.m14991a((View) recyclerView, recyclerView.mUpdateChildViewsRunnable);
                    return;
                }
            }
            RecyclerView recyclerView2 = RecyclerView.this;
            recyclerView2.mAdapterUpdateDuringMeasure = true;
            recyclerView2.requestLayout();
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$y */
    public static class C0247y extends C1904t8 {
        public static final Parcelable.Creator<C0247y> CREATOR = new C0248a();

        /* renamed from: Z */
        public Parcelable f1390Z;

        /* renamed from: androidx.recyclerview.widget.RecyclerView$y$a */
        public static class C0248a implements Parcelable.ClassLoaderCreator<C0247y> {
            public Object createFromParcel(Parcel parcel) {
                return new C0247y(parcel, (ClassLoader) null);
            }

            public Object[] newArray(int i) {
                return new C0247y[i];
            }

            public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new C0247y(parcel, classLoader);
            }
        }

        public C0247y(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f1390Z = parcel.readParcelable(classLoader == null ? C0232o.class.getClassLoader() : classLoader);
        }

        public C0247y(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeParcelable(this.f14707X, i);
            parcel.writeParcelable(this.f1390Z, 0);
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v9, resolved type: java.lang.Class<?>[]} */
    /* JADX WARNING: Multi-variable type inference failed */
    static {
        /*
            r0 = 1
            int[] r1 = new int[r0]
            r2 = 0
            r3 = 16843830(0x1010436, float:2.369658E-38)
            r1[r2] = r3
            NESTED_SCROLLING_ATTRS = r1
            int r1 = android.os.Build.VERSION.SDK_INT
            r3 = 19
            if (r1 == r3) goto L_0x0018
            r3 = 20
            if (r1 != r3) goto L_0x0016
            goto L_0x0018
        L_0x0016:
            r1 = 0
            goto L_0x0019
        L_0x0018:
            r1 = 1
        L_0x0019:
            FORCE_INVALIDATE_DISPLAY_LIST = r1
            int r1 = android.os.Build.VERSION.SDK_INT
            r3 = 23
            if (r1 < r3) goto L_0x0023
            r1 = 1
            goto L_0x0024
        L_0x0023:
            r1 = 0
        L_0x0024:
            ALLOW_SIZE_IN_UNSPECIFIED_SPEC = r1
            int r1 = android.os.Build.VERSION.SDK_INT
            POST_UPDATES_ON_ANIMATION = r0
            r3 = 21
            if (r1 < r3) goto L_0x0030
            r1 = 1
            goto L_0x0031
        L_0x0030:
            r1 = 0
        L_0x0031:
            ALLOW_THREAD_GAP_WORK = r1
            int r1 = android.os.Build.VERSION.SDK_INT
            FORCE_ABS_FOCUS_SEARCH_DIRECTION = r2
            IGNORE_DETACHED_FOCUSED_CHILD = r2
            r1 = 4
            java.lang.Class[] r1 = new java.lang.Class[r1]
            java.lang.Class<android.content.Context> r3 = android.content.Context.class
            r1[r2] = r3
            java.lang.Class<android.util.AttributeSet> r2 = android.util.AttributeSet.class
            r1[r0] = r2
            r0 = 2
            java.lang.Class r2 = java.lang.Integer.TYPE
            r1[r0] = r2
            r0 = 3
            r1[r0] = r2
            LAYOUT_MANAGER_CONSTRUCTOR_SIGNATURE = r1
            androidx.recyclerview.widget.RecyclerView$c r0 = new androidx.recyclerview.widget.RecyclerView$c
            r0.<init>()
            sQuinticInterpolator = r0
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.<clinit>():void");
    }

    public RecyclerView(Context context) {
        this(context, (AttributeSet) null);
    }

    public RecyclerView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0676fc.recyclerViewStyle);
    }

    public RecyclerView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.mObserver = new C0246x();
        this.mRecycler = new C0244v();
        this.mViewInfoStore = new C0599ed();
        this.mUpdateChildViewsRunnable = new C0211a();
        this.mTempRect = new Rect();
        this.mTempRect2 = new Rect();
        this.mTempRectF = new RectF();
        this.mItemDecorations = new ArrayList<>();
        this.mOnItemTouchListeners = new ArrayList<>();
        this.mInterceptRequestLayoutDepth = 0;
        this.mDataSetHasChangedAfterLayout = false;
        this.mDispatchItemsChangedEvent = false;
        this.mLayoutOrScrollCounter = 0;
        this.mDispatchScrollCounter = 0;
        this.mEdgeEffectFactory = new C0225k();
        this.mItemAnimator = new C1510oc();
        this.mScrollState = 0;
        this.mScrollPointerId = -1;
        this.mScaledHorizontalScrollFactor = Float.MIN_VALUE;
        this.mScaledVerticalScrollFactor = Float.MIN_VALUE;
        boolean z = true;
        this.mPreserveFocusAfterLayout = true;
        this.mViewFlinger = new C0216c0();
        this.mPrefetchRegistry = ALLOW_THREAD_GAP_WORK ? new C1692qc.C1694b() : null;
        this.mState = new C0212a0();
        this.mItemsAddedOrRemoved = false;
        this.mItemsChanged = false;
        this.mItemAnimatorListener = new C0230m();
        this.mPostedAnimatorRunner = false;
        this.mMinMaxLayoutPositions = new int[2];
        this.mScrollOffset = new int[2];
        this.mNestedOffsets = new int[2];
        this.mReusableIntPair = new int[2];
        this.mPendingAccessibilityImportanceChange = new ArrayList();
        this.mItemAnimatorRunner = new C0213b();
        this.mViewInfoProcessCallback = new C0217d();
        setScrollContainer(true);
        setFocusableInTouchMode(true);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
        this.mTouchSlop = viewConfiguration.getScaledTouchSlop();
        this.mScaledHorizontalScrollFactor = C2406z7.m16906b(viewConfiguration, context);
        this.mScaledVerticalScrollFactor = Build.VERSION.SDK_INT >= 26 ? viewConfiguration.getScaledVerticalScrollFactor() : C2406z7.m16904a(viewConfiguration, context);
        this.mMinFlingVelocity = viewConfiguration.getScaledMinimumFlingVelocity();
        this.mMaxFlingVelocity = viewConfiguration.getScaledMaximumFlingVelocity();
        setWillNotDraw(getOverScrollMode() == 2);
        this.mItemAnimator.f1338a = this.mItemAnimatorListener;
        initAdapterManager();
        initChildrenHelper();
        initAutofill();
        if (C2189w7.m15016k(this) == 0) {
            int i2 = Build.VERSION.SDK_INT;
            setImportantForAccessibility(1);
        }
        this.mAccessibilityManager = (AccessibilityManager) getContext().getSystemService("accessibility");
        setAccessibilityDelegateCompat(new C2435zc(this));
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0856hc.RecyclerView, i, 0);
        if (Build.VERSION.SDK_INT >= 29) {
            saveAttributeDataForStyleable(context, C0856hc.RecyclerView, attributeSet, obtainStyledAttributes, i, 0);
        }
        String string = obtainStyledAttributes.getString(C0856hc.RecyclerView_layoutManager);
        if (obtainStyledAttributes.getInt(C0856hc.RecyclerView_android_descendantFocusability, -1) == -1) {
            setDescendantFocusability(262144);
        }
        this.mClipToPadding = obtainStyledAttributes.getBoolean(C0856hc.RecyclerView_android_clipToPadding, true);
        this.mEnableFastScroller = obtainStyledAttributes.getBoolean(C0856hc.RecyclerView_fastScrollEnabled, false);
        if (this.mEnableFastScroller) {
            initFastScroller((StateListDrawable) obtainStyledAttributes.getDrawable(C0856hc.RecyclerView_fastScrollVerticalThumbDrawable), obtainStyledAttributes.getDrawable(C0856hc.RecyclerView_fastScrollVerticalTrackDrawable), (StateListDrawable) obtainStyledAttributes.getDrawable(C0856hc.RecyclerView_fastScrollHorizontalThumbDrawable), obtainStyledAttributes.getDrawable(C0856hc.RecyclerView_fastScrollHorizontalTrackDrawable));
        }
        obtainStyledAttributes.recycle();
        createLayoutManager(context, string, attributeSet, i, 0);
        if (Build.VERSION.SDK_INT >= 21) {
            TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(attributeSet, NESTED_SCROLLING_ATTRS, i, 0);
            if (Build.VERSION.SDK_INT >= 29) {
                saveAttributeDataForStyleable(context, NESTED_SCROLLING_ATTRS, attributeSet, obtainStyledAttributes2, i, 0);
            }
            z = obtainStyledAttributes2.getBoolean(0, true);
            obtainStyledAttributes2.recycle();
        }
        setNestedScrollingEnabled(z);
    }

    private void addAnimatingView(C0218d0 d0Var) {
        View view = d0Var.f1316X;
        boolean z = view.getParent() == this;
        this.mRecycler.mo1994b(getChildViewHolder(view));
        if (d0Var.mo1817t()) {
            this.mChildHelper.mo7587a(view, -1, view.getLayoutParams(), true);
            return;
        }
        C1050jc jcVar = this.mChildHelper;
        if (!z) {
            jcVar.mo7588a(view, -1, true);
            return;
        }
        int indexOfChild = RecyclerView.this.indexOfChild(view);
        if (indexOfChild >= 0) {
            jcVar.f8344b.mo7604e(indexOfChild);
            jcVar.f8345c.add(view);
            ((C0219e) jcVar.f8343a).mo1828b(view);
            return;
        }
        throw new IllegalArgumentException("view is not a child, cannot hide " + view);
    }

    private void animateChange(C0218d0 d0Var, C0218d0 d0Var2, C0226l.C0229c cVar, C0226l.C0229c cVar2, boolean z, boolean z2) {
        d0Var.mo1804a(false);
        if (z) {
            addAnimatingView(d0Var);
        }
        if (d0Var != d0Var2) {
            if (z2) {
                addAnimatingView(d0Var2);
            }
            d0Var.f1323e0 = d0Var2;
            addAnimatingView(d0Var);
            this.mRecycler.mo1994b(d0Var);
            d0Var2.mo1804a(false);
            d0Var2.f1324f0 = d0Var;
        }
        if (this.mItemAnimator.mo383a(d0Var, d0Var2, cVar, cVar2)) {
            postAnimationRunner();
        }
    }

    private void cancelScroll() {
        resetScroll();
        setScrollState(0);
    }

    public static void clearNestedRecyclerViewIfNotNested(C0218d0 d0Var) {
        WeakReference<RecyclerView> weakReference = d0Var.f1317Y;
        if (weakReference != null) {
            Object obj = weakReference.get();
            while (true) {
                View view = (View) obj;
                while (true) {
                    if (view == null) {
                        d0Var.f1317Y = null;
                        return;
                    } else if (view != d0Var.f1316X) {
                        obj = view.getParent();
                        if (!(obj instanceof View)) {
                            view = null;
                        }
                    } else {
                        return;
                    }
                }
            }
        }
    }

    private void createLayoutManager(Context context, String str, AttributeSet attributeSet, int i, int i2) {
        Constructor<? extends U> constructor;
        if (str != null) {
            String trim = str.trim();
            if (!trim.isEmpty()) {
                String fullClassName = getFullClassName(context, trim);
                try {
                    Class<? extends U> asSubclass = Class.forName(fullClassName, false, isInEditMode() ? getClass().getClassLoader() : context.getClassLoader()).asSubclass(C0232o.class);
                    Object[] objArr = null;
                    try {
                        constructor = asSubclass.getConstructor(LAYOUT_MANAGER_CONSTRUCTOR_SIGNATURE);
                        objArr = new Object[]{context, attributeSet, Integer.valueOf(i), Integer.valueOf(i2)};
                    } catch (NoSuchMethodException e) {
                        constructor = asSubclass.getConstructor(new Class[0]);
                    }
                    constructor.setAccessible(true);
                    setLayoutManager((C0232o) constructor.newInstance(objArr));
                } catch (NoSuchMethodException e2) {
                    e2.initCause(e);
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Error creating LayoutManager " + fullClassName, e2);
                } catch (ClassNotFoundException e3) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Unable to find LayoutManager " + fullClassName, e3);
                } catch (InvocationTargetException e4) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Could not instantiate the LayoutManager: " + fullClassName, e4);
                } catch (InstantiationException e5) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Could not instantiate the LayoutManager: " + fullClassName, e5);
                } catch (IllegalAccessException e6) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Cannot access non-public constructor " + fullClassName, e6);
                } catch (ClassCastException e7) {
                    throw new IllegalStateException(attributeSet.getPositionDescription() + ": Class is not a LayoutManager " + fullClassName, e7);
                }
            }
        }
    }

    private boolean didChildRangeChange(int i, int i2) {
        findMinMaxChildLayoutPositions(this.mMinMaxLayoutPositions);
        int[] iArr = this.mMinMaxLayoutPositions;
        return (iArr[0] == i && iArr[1] == i2) ? false : true;
    }

    private void dispatchContentChangedIfNecessary() {
        int i = this.mEatenAccessibilityChangeFlags;
        this.mEatenAccessibilityChangeFlags = 0;
        if (i != 0 && isAccessibilityEnabled()) {
            AccessibilityEvent obtain = AccessibilityEvent.obtain();
            obtain.setEventType(2048);
            int i2 = Build.VERSION.SDK_INT;
            obtain.setContentChangeTypes(i);
            sendAccessibilityEventUnchecked(obtain);
        }
    }

    private void dispatchLayoutStep1() {
        this.mState.mo1791a(1);
        fillRemainingScrollValues(this.mState);
        this.mState.f1298j = false;
        startInterceptRequestLayout();
        C0599ed edVar = this.mViewInfoStore;
        edVar.f4405a.clear();
        edVar.f4406b.mo4662a();
        onEnterLayoutOrScroll();
        processAdapterUpdatesAndSetAnimationFlags();
        saveFocusInfo();
        C0212a0 a0Var = this.mState;
        a0Var.f1297i = a0Var.f1299k && this.mItemsChanged;
        this.mItemsChanged = false;
        this.mItemsAddedOrRemoved = false;
        C0212a0 a0Var2 = this.mState;
        a0Var2.f1296h = a0Var2.f1300l;
        a0Var2.f1294f = this.mAdapter.mo1833a();
        findMinMaxChildLayoutPositions(this.mMinMaxLayoutPositions);
        if (this.mState.f1299k) {
            int a = this.mChildHelper.mo7584a();
            for (int i = 0; i < a; i++) {
                C0218d0 childViewHolderInt = getChildViewHolderInt(this.mChildHelper.mo7590b(i));
                if (!childViewHolderInt.mo1821w() && (!childViewHolderInt.mo1813p() || this.mAdapter.f1337b)) {
                    C0226l lVar = this.mItemAnimator;
                    C0226l.m1204b(childViewHolderInt);
                    childViewHolderInt.mo1810m();
                    C0226l.C0229c e = lVar.mo1859e();
                    View view = childViewHolderInt.f1316X;
                    e.f1344a = view.getLeft();
                    e.f1345b = view.getTop();
                    view.getRight();
                    view.getBottom();
                    this.mViewInfoStore.mo5095b(childViewHolderInt, e);
                    if (this.mState.f1297i && childViewHolderInt.mo1819u() && !childViewHolderInt.mo1815r() && !childViewHolderInt.mo1821w() && !childViewHolderInt.mo1813p()) {
                        this.mViewInfoStore.f4406b.mo4668c(getChangedHolderKey(childViewHolderInt), childViewHolderInt);
                    }
                }
            }
        }
        if (this.mState.f1300l) {
            saveOldPositions();
            C0212a0 a0Var3 = this.mState;
            boolean z = a0Var3.f1295g;
            a0Var3.f1295g = false;
            this.mLayout.mo1517c(this.mRecycler, a0Var3);
            this.mState.f1295g = z;
            for (int i2 = 0; i2 < this.mChildHelper.mo7584a(); i2++) {
                C0218d0 childViewHolderInt2 = getChildViewHolderInt(this.mChildHelper.mo7590b(i2));
                if (!childViewHolderInt2.mo1821w()) {
                    C0599ed.C0600a orDefault = this.mViewInfoStore.f4405a.getOrDefault(childViewHolderInt2, null);
                    if (!((orDefault == null || (orDefault.f4408a & 4) == 0) ? false : true)) {
                        C0226l.m1204b(childViewHolderInt2);
                        boolean b = childViewHolderInt2.mo1805b(8192);
                        C0226l lVar2 = this.mItemAnimator;
                        childViewHolderInt2.mo1810m();
                        C0226l.C0229c e2 = lVar2.mo1859e();
                        View view2 = childViewHolderInt2.f1316X;
                        e2.f1344a = view2.getLeft();
                        e2.f1345b = view2.getTop();
                        view2.getRight();
                        view2.getBottom();
                        if (b) {
                            recordAnimationInfoIfBouncedHiddenView(childViewHolderInt2, e2);
                        } else {
                            C0599ed edVar2 = this.mViewInfoStore;
                            C0599ed.C0600a orDefault2 = edVar2.f4405a.getOrDefault(childViewHolderInt2, null);
                            if (orDefault2 == null) {
                                orDefault2 = C0599ed.C0600a.m4027a();
                                edVar2.f4405a.put(childViewHolderInt2, orDefault2);
                            }
                            orDefault2.f4408a |= 2;
                            orDefault2.f4409b = e2;
                        }
                    }
                }
            }
        }
        clearOldPositions();
        onExitLayoutOrScroll();
        stopInterceptRequestLayout(false);
        this.mState.f1293e = 2;
    }

    private void dispatchLayoutStep2() {
        startInterceptRequestLayout();
        onEnterLayoutOrScroll();
        this.mState.mo1791a(6);
        this.mAdapterHelper.mo6908b();
        this.mState.f1294f = this.mAdapter.mo1833a();
        C0212a0 a0Var = this.mState;
        a0Var.f1292d = 0;
        a0Var.f1296h = false;
        this.mLayout.mo1517c(this.mRecycler, a0Var);
        C0212a0 a0Var2 = this.mState;
        a0Var2.f1295g = false;
        this.mPendingSavedState = null;
        a0Var2.f1299k = a0Var2.f1299k && this.mItemAnimator != null;
        this.mState.f1293e = 4;
        onExitLayoutOrScroll();
        stopInterceptRequestLayout(false);
    }

    private void dispatchLayoutStep3() {
        C0226l.C0229c cVar;
        C0226l.C0229c cVar2;
        this.mState.mo1791a(4);
        startInterceptRequestLayout();
        onEnterLayoutOrScroll();
        C0212a0 a0Var = this.mState;
        a0Var.f1293e = 1;
        if (a0Var.f1299k) {
            for (int a = this.mChildHelper.mo7584a() - 1; a >= 0; a--) {
                C0218d0 childViewHolderInt = getChildViewHolderInt(this.mChildHelper.mo7590b(a));
                if (!childViewHolderInt.mo1821w()) {
                    long changedHolderKey = getChangedHolderKey(childViewHolderInt);
                    C0226l.C0229c e = this.mItemAnimator.mo1859e();
                    View view = childViewHolderInt.f1316X;
                    e.f1344a = view.getLeft();
                    e.f1345b = view.getTop();
                    view.getRight();
                    view.getBottom();
                    C0218d0 b = this.mViewInfoStore.f4406b.mo4665b(changedHolderKey, null);
                    if (b != null && !b.mo1821w()) {
                        boolean b2 = this.mViewInfoStore.mo5096b(b);
                        boolean b3 = this.mViewInfoStore.mo5096b(childViewHolderInt);
                        if (!b2 || b != childViewHolderInt) {
                            C0226l.C0229c a2 = this.mViewInfoStore.mo5091a(b, 4);
                            this.mViewInfoStore.mo5094a(childViewHolderInt, e);
                            C0226l.C0229c a3 = this.mViewInfoStore.mo5091a(childViewHolderInt, 8);
                            if (a2 == null) {
                                handleMissingPreInfoForChangeError(changedHolderKey, childViewHolderInt, b);
                            } else {
                                animateChange(b, childViewHolderInt, a2, a3, b2, b3);
                            }
                        }
                    }
                    this.mViewInfoStore.mo5094a(childViewHolderInt, e);
                }
            }
            C0599ed edVar = this.mViewInfoStore;
            C0599ed.C0601b bVar = this.mViewInfoProcessCallback;
            int i = edVar.f4405a.f5965Z;
            while (true) {
                i--;
                if (i < 0) {
                    break;
                }
                C0218d0 c = edVar.f4405a.mo5977c(i);
                C0599ed.C0600a d = edVar.f4405a.mo5981d(i);
                int i2 = d.f4408a;
                if ((i2 & 3) != 3) {
                    if ((i2 & 1) != 0) {
                        cVar2 = d.f4409b;
                        if (cVar2 != null) {
                            cVar = d.f4410c;
                        }
                    } else {
                        if ((i2 & 14) != 14) {
                            if ((i2 & 12) == 12) {
                                ((C0217d) bVar).mo1799a(c, d.f4409b, d.f4410c);
                            } else if ((i2 & 4) != 0) {
                                cVar2 = d.f4409b;
                                cVar = null;
                            } else if ((i2 & 8) == 0) {
                            }
                            C0599ed.C0600a.m4028a(d);
                        }
                        RecyclerView.this.animateAppearance(c, d.f4409b, d.f4410c);
                        C0599ed.C0600a.m4028a(d);
                    }
                    C0217d dVar = (C0217d) bVar;
                    RecyclerView.this.mRecycler.mo1994b(c);
                    RecyclerView.this.animateDisappearance(c, cVar2, cVar);
                    C0599ed.C0600a.m4028a(d);
                }
                RecyclerView recyclerView = RecyclerView.this;
                recyclerView.mLayout.mo1878a(c.f1316X, recyclerView.mRecycler);
                C0599ed.C0600a.m4028a(d);
            }
        }
        this.mLayout.mo1910c(this.mRecycler);
        C0212a0 a0Var2 = this.mState;
        a0Var2.f1291c = a0Var2.f1294f;
        this.mDataSetHasChangedAfterLayout = false;
        this.mDispatchItemsChangedEvent = false;
        a0Var2.f1299k = false;
        a0Var2.f1300l = false;
        this.mLayout.f1354e0 = false;
        ArrayList<C0218d0> arrayList = this.mRecycler.f1382b;
        if (arrayList != null) {
            arrayList.clear();
        }
        C0232o oVar = this.mLayout;
        if (oVar.f1360k0) {
            oVar.f1359j0 = 0;
            oVar.f1360k0 = false;
            this.mRecycler.mo1997d();
        }
        this.mLayout.mo1523g(this.mState);
        onExitLayoutOrScroll();
        stopInterceptRequestLayout(false);
        C0599ed edVar2 = this.mViewInfoStore;
        edVar2.f4405a.clear();
        edVar2.f4406b.mo4662a();
        int[] iArr = this.mMinMaxLayoutPositions;
        if (didChildRangeChange(iArr[0], iArr[1])) {
            dispatchOnScrolled(0, 0);
        }
        recoverFocusFromState();
        resetFocusInfo();
    }

    private boolean dispatchToOnItemTouchListeners(MotionEvent motionEvent) {
        C0240s sVar = this.mInterceptingOnItemTouchListener;
        if (sVar != null) {
            C1609pc pcVar = (C1609pc) sVar;
            if (pcVar.f12375v != 0) {
                if (motionEvent.getAction() == 0) {
                    boolean b = pcVar.mo9953b(motionEvent.getX(), motionEvent.getY());
                    boolean a = pcVar.mo9951a(motionEvent.getX(), motionEvent.getY());
                    if (b || a) {
                        if (a) {
                            pcVar.f12376w = 1;
                            pcVar.f12369p = (float) ((int) motionEvent.getX());
                        } else if (b) {
                            pcVar.f12376w = 2;
                            pcVar.f12366m = (float) ((int) motionEvent.getY());
                        }
                        pcVar.mo9949a(2);
                    }
                } else if (motionEvent.getAction() == 1 && pcVar.f12375v == 2) {
                    pcVar.f12366m = 0.0f;
                    pcVar.f12369p = 0.0f;
                    pcVar.mo9949a(1);
                    pcVar.f12376w = 0;
                } else if (motionEvent.getAction() == 2 && pcVar.f12375v == 2) {
                    pcVar.mo9954c();
                    if (pcVar.f12376w == 1) {
                        float x = motionEvent.getX();
                        int[] iArr = pcVar.f12378y;
                        int i = pcVar.f12355b;
                        iArr[0] = i;
                        iArr[1] = pcVar.f12370q - i;
                        float max = Math.max((float) iArr[0], Math.min((float) iArr[1], x));
                        if (Math.abs(((float) pcVar.f12368o) - max) >= 2.0f) {
                            int a2 = pcVar.mo9947a(pcVar.f12369p, max, iArr, pcVar.f12372s.computeHorizontalScrollRange(), pcVar.f12372s.computeHorizontalScrollOffset(), pcVar.f12370q);
                            if (a2 != 0) {
                                pcVar.f12372s.scrollBy(a2, 0);
                            }
                            pcVar.f12369p = max;
                        }
                    }
                    if (pcVar.f12376w == 2) {
                        float y = motionEvent.getY();
                        int[] iArr2 = pcVar.f12377x;
                        int i2 = pcVar.f12355b;
                        iArr2[0] = i2;
                        iArr2[1] = pcVar.f12371r - i2;
                        float max2 = Math.max((float) iArr2[0], Math.min((float) iArr2[1], y));
                        if (Math.abs(((float) pcVar.f12365l) - max2) >= 2.0f) {
                            int a3 = pcVar.mo9947a(pcVar.f12366m, max2, iArr2, pcVar.f12372s.computeVerticalScrollRange(), pcVar.f12372s.computeVerticalScrollOffset(), pcVar.f12371r);
                            if (a3 != 0) {
                                pcVar.f12372s.scrollBy(0, a3);
                            }
                            pcVar.f12366m = max2;
                        }
                    }
                }
            }
            int action = motionEvent.getAction();
            if (action == 3 || action == 1) {
                this.mInterceptingOnItemTouchListener = null;
            }
            return true;
        } else if (motionEvent.getAction() == 0) {
            return false;
        } else {
            return findInterceptingOnItemTouchListener(motionEvent);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:13:0x005e, code lost:
        if (r6 == 2) goto L_0x0060;
     */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x006b A[LOOP:0: B:1:0x000c->B:21:0x006b, LOOP_END] */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x0068 A[SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private boolean findInterceptingOnItemTouchListener(android.view.MotionEvent r12) {
        /*
            r11 = this;
            int r0 = r12.getAction()
            java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$s> r1 = r11.mOnItemTouchListeners
            int r1 = r1.size()
            r2 = 0
            r3 = 0
        L_0x000c:
            if (r3 >= r1) goto L_0x006e
            java.util.ArrayList<androidx.recyclerview.widget.RecyclerView$s> r4 = r11.mOnItemTouchListeners
            java.lang.Object r4 = r4.get(r3)
            androidx.recyclerview.widget.RecyclerView$s r4 = (androidx.recyclerview.widget.RecyclerView.C0240s) r4
            r5 = r4
            pc r5 = (p000.C1609pc) r5
            int r6 = r5.f12375v
            r7 = 2
            r8 = 1
            if (r6 != r8) goto L_0x005e
            float r6 = r12.getX()
            float r9 = r12.getY()
            boolean r6 = r5.mo9953b(r6, r9)
            float r9 = r12.getX()
            float r10 = r12.getY()
            boolean r9 = r5.mo9951a(r9, r10)
            int r10 = r12.getAction()
            if (r10 != 0) goto L_0x0062
            if (r6 != 0) goto L_0x0041
            if (r9 == 0) goto L_0x0062
        L_0x0041:
            if (r9 == 0) goto L_0x004e
            r5.f12376w = r8
            float r6 = r12.getX()
            int r6 = (int) r6
            float r6 = (float) r6
            r5.f12369p = r6
            goto L_0x005a
        L_0x004e:
            if (r6 == 0) goto L_0x005a
            r5.f12376w = r7
            float r6 = r12.getY()
            int r6 = (int) r6
            float r6 = (float) r6
            r5.f12366m = r6
        L_0x005a:
            r5.mo9949a((int) r7)
            goto L_0x0060
        L_0x005e:
            if (r6 != r7) goto L_0x0062
        L_0x0060:
            r5 = 1
            goto L_0x0063
        L_0x0062:
            r5 = 0
        L_0x0063:
            if (r5 == 0) goto L_0x006b
            r5 = 3
            if (r0 == r5) goto L_0x006b
            r11.mInterceptingOnItemTouchListener = r4
            return r8
        L_0x006b:
            int r3 = r3 + 1
            goto L_0x000c
        L_0x006e:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.findInterceptingOnItemTouchListener(android.view.MotionEvent):boolean");
    }

    private void findMinMaxChildLayoutPositions(int[] iArr) {
        int a = this.mChildHelper.mo7584a();
        if (a == 0) {
            iArr[0] = -1;
            iArr[1] = -1;
            return;
        }
        int i = Integer.MAX_VALUE;
        int i2 = UNDEFINED_DURATION;
        for (int i3 = 0; i3 < a; i3++) {
            C0218d0 childViewHolderInt = getChildViewHolderInt(this.mChildHelper.mo7590b(i3));
            if (!childViewHolderInt.mo1821w()) {
                int l = childViewHolderInt.mo1809l();
                if (l < i) {
                    i = l;
                }
                if (l > i2) {
                    i2 = l;
                }
            }
        }
        iArr[0] = i;
        iArr[1] = i2;
    }

    public static RecyclerView findNestedRecyclerView(View view) {
        if (!(view instanceof ViewGroup)) {
            return null;
        }
        if (view instanceof RecyclerView) {
            return (RecyclerView) view;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        for (int i = 0; i < childCount; i++) {
            RecyclerView findNestedRecyclerView = findNestedRecyclerView(viewGroup.getChildAt(i));
            if (findNestedRecyclerView != null) {
                return findNestedRecyclerView;
            }
        }
        return null;
    }

    private View findNextViewToFocus() {
        C0218d0 findViewHolderForAdapterPosition;
        int i = this.mState.f1301m;
        if (i == -1) {
            i = 0;
        }
        int a = this.mState.mo1790a();
        int i2 = i;
        while (i2 < a) {
            C0218d0 findViewHolderForAdapterPosition2 = findViewHolderForAdapterPosition(i2);
            if (findViewHolderForAdapterPosition2 == null) {
                break;
            } else if (findViewHolderForAdapterPosition2.f1316X.hasFocusable()) {
                return findViewHolderForAdapterPosition2.f1316X;
            } else {
                i2++;
            }
        }
        int min = Math.min(a, i);
        while (true) {
            min--;
            if (min < 0 || (findViewHolderForAdapterPosition = findViewHolderForAdapterPosition(min)) == null) {
                return null;
            }
            if (findViewHolderForAdapterPosition.f1316X.hasFocusable()) {
                return findViewHolderForAdapterPosition.f1316X;
            }
        }
    }

    public static C0218d0 getChildViewHolderInt(View view) {
        if (view == null) {
            return null;
        }
        return ((C0237p) view.getLayoutParams()).f1371X;
    }

    public static void getDecoratedBoundsWithMarginsInt(View view, Rect rect) {
        C0237p pVar = (C0237p) view.getLayoutParams();
        Rect rect2 = pVar.f1372Y;
        rect.set((view.getLeft() - rect2.left) - pVar.leftMargin, (view.getTop() - rect2.top) - pVar.topMargin, view.getRight() + rect2.right + pVar.rightMargin, view.getBottom() + rect2.bottom + pVar.bottomMargin);
    }

    private int getDeepestFocusedViewWithId(View view) {
        int id;
        loop0:
        while (true) {
            id = view.getId();
            while (true) {
                if (view.isFocused() || !(view instanceof ViewGroup) || !view.hasFocus()) {
                    return id;
                }
                view = ((ViewGroup) view).getFocusedChild();
                if (view.getId() != -1) {
                }
            }
        }
        return id;
    }

    private String getFullClassName(Context context, String str) {
        if (str.charAt(0) == '.') {
            return context.getPackageName() + str;
        } else if (str.contains(".")) {
            return str;
        } else {
            return RecyclerView.class.getPackage().getName() + '.' + str;
        }
    }

    private C1313m7 getScrollingChildHelper() {
        if (this.mScrollingChildHelper == null) {
            this.mScrollingChildHelper = new C1313m7(this);
        }
        return this.mScrollingChildHelper;
    }

    private void handleMissingPreInfoForChangeError(long j, C0218d0 d0Var, C0218d0 d0Var2) {
        int a = this.mChildHelper.mo7584a();
        for (int i = 0; i < a; i++) {
            C0218d0 childViewHolderInt = getChildViewHolderInt(this.mChildHelper.mo7590b(i));
            if (childViewHolderInt != d0Var && getChangedHolderKey(childViewHolderInt) == j) {
                C0221g gVar = this.mAdapter;
                if (gVar == null || !gVar.f1337b) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("Two different ViewHolders have the same change ID. This might happen due to inconsistent Adapter update events or if the LayoutManager lays out the same View multiple times.\n ViewHolder 1:");
                    sb.append(childViewHolderInt);
                    sb.append(" \n View Holder 2:");
                    sb.append(d0Var);
                    throw new IllegalStateException(C0789gk.m5554a(this, sb));
                }
                StringBuilder sb2 = new StringBuilder();
                sb2.append("Two different ViewHolders have the same stable ID. Stable IDs in your adapter MUST BE unique and SHOULD NOT change.\n ViewHolder 1:");
                sb2.append(childViewHolderInt);
                sb2.append(" \n View Holder 2:");
                sb2.append(d0Var);
                throw new IllegalStateException(C0789gk.m5554a(this, sb2));
            }
        }
        Log.e(TAG, "Problem while matching changed view holders with the newones. The pre-layout information for the change holder " + d0Var2 + " cannot be found but it is necessary for " + d0Var + exceptionLabel());
    }

    private boolean hasUpdatedView() {
        int a = this.mChildHelper.mo7584a();
        for (int i = 0; i < a; i++) {
            C0218d0 childViewHolderInt = getChildViewHolderInt(this.mChildHelper.mo7590b(i));
            if (childViewHolderInt != null && !childViewHolderInt.mo1821w() && childViewHolderInt.mo1819u()) {
                return true;
            }
        }
        return false;
    }

    @SuppressLint({"InlinedApi"})
    private void initAutofill() {
        if (C2189w7.m15017l(this) == 0 && Build.VERSION.SDK_INT >= 26) {
            setImportantForAutofill(8);
        }
    }

    private void initChildrenHelper() {
        this.mChildHelper = new C1050jc(new C0219e());
    }

    private boolean isPreferredNextFocus(View view, View view2, int i) {
        int i2;
        if (view2 == null || view2 == this || findContainingItemView(view2) == null) {
            return false;
        }
        if (view == null || findContainingItemView(view) == null) {
            return true;
        }
        this.mTempRect.set(0, 0, view.getWidth(), view.getHeight());
        this.mTempRect2.set(0, 0, view2.getWidth(), view2.getHeight());
        offsetDescendantRectToMyCoords(view, this.mTempRect);
        offsetDescendantRectToMyCoords(view2, this.mTempRect2);
        char c = 65535;
        int i3 = this.mLayout.mo1945l() == 1 ? -1 : 1;
        Rect rect = this.mTempRect;
        int i4 = rect.left;
        int i5 = this.mTempRect2.left;
        if ((i4 < i5 || rect.right <= i5) && this.mTempRect.right < this.mTempRect2.right) {
            i2 = 1;
        } else {
            Rect rect2 = this.mTempRect;
            int i6 = rect2.right;
            int i7 = this.mTempRect2.right;
            i2 = ((i6 > i7 || rect2.left >= i7) && this.mTempRect.left > this.mTempRect2.left) ? -1 : 0;
        }
        Rect rect3 = this.mTempRect;
        int i8 = rect3.top;
        int i9 = this.mTempRect2.top;
        if ((i8 < i9 || rect3.bottom <= i9) && this.mTempRect.bottom < this.mTempRect2.bottom) {
            c = 1;
        } else {
            Rect rect4 = this.mTempRect;
            int i10 = rect4.bottom;
            int i11 = this.mTempRect2.bottom;
            if ((i10 <= i11 && rect4.top < i11) || this.mTempRect.top <= this.mTempRect2.top) {
                c = 0;
            }
        }
        if (i == 1) {
            return c < 0 || (c == 0 && i2 * i3 <= 0);
        }
        if (i == 2) {
            return c > 0 || (c == 0 && i2 * i3 >= 0);
        }
        if (i == 17) {
            return i2 < 0;
        }
        if (i == 33) {
            return c < 0;
        }
        if (i == 66) {
            return i2 > 0;
        }
        if (i == 130) {
            return c > 0;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Invalid direction: ");
        sb.append(i);
        throw new IllegalArgumentException(C0789gk.m5554a(this, sb));
    }

    private void onPointerUp(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.mScrollPointerId) {
            int i = actionIndex == 0 ? 1 : 0;
            this.mScrollPointerId = motionEvent.getPointerId(i);
            int x = (int) (motionEvent.getX(i) + 0.5f);
            this.mLastTouchX = x;
            this.mInitialTouchX = x;
            int y = (int) (motionEvent.getY(i) + 0.5f);
            this.mLastTouchY = y;
            this.mInitialTouchY = y;
        }
    }

    private boolean predictiveItemAnimationsEnabled() {
        return this.mItemAnimator != null && this.mLayout.mo1488I();
    }

    private void processAdapterUpdatesAndSetAnimationFlags() {
        boolean z = false;
        if (this.mDataSetHasChangedAfterLayout) {
            C0926ic icVar = this.mAdapterHelper;
            icVar.mo6904a((List<C0926ic.C0928b>) icVar.f7366b);
            icVar.mo6904a((List<C0926ic.C0928b>) icVar.f7367c);
            icVar.f7372h = 0;
            if (this.mDispatchItemsChangedEvent) {
                this.mLayout.mo1518c(this);
            }
        }
        if (predictiveItemAnimationsEnabled()) {
            this.mAdapterHelper.mo6915d();
        } else {
            this.mAdapterHelper.mo6908b();
        }
        boolean z2 = this.mItemsAddedOrRemoved || this.mItemsChanged;
        this.mState.f1299k = this.mFirstLayoutComplete && this.mItemAnimator != null && (this.mDataSetHasChangedAfterLayout || z2 || this.mLayout.f1354e0) && (!this.mDataSetHasChangedAfterLayout || this.mAdapter.f1337b);
        C0212a0 a0Var = this.mState;
        if (a0Var.f1299k && z2 && !this.mDataSetHasChangedAfterLayout && predictiveItemAnimationsEnabled()) {
            z = true;
        }
        a0Var.f1300l = z;
    }

    /* JADX WARNING: Removed duplicated region for block: B:10:0x003d  */
    /* JADX WARNING: Removed duplicated region for block: B:11:0x0053  */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x0079  */
    /* JADX WARNING: Removed duplicated region for block: B:22:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void pullGlows(float r7, float r8, float r9, float r10) {
        /*
            r6 = this;
            r0 = 1065353216(0x3f800000, float:1.0)
            r1 = 1
            r2 = 0
            int r3 = (r8 > r2 ? 1 : (r8 == r2 ? 0 : -1))
            if (r3 >= 0) goto L_0x0021
            r6.ensureLeftGlow()
            android.widget.EdgeEffect r3 = r6.mLeftGlow
            float r4 = -r8
            int r5 = r6.getWidth()
            float r5 = (float) r5
            float r4 = r4 / r5
            int r5 = r6.getHeight()
            float r5 = (float) r5
            float r9 = r9 / r5
            float r9 = r0 - r9
        L_0x001c:
            p000.C0815h0.m5810a((android.widget.EdgeEffect) r3, (float) r4, (float) r9)
            r9 = 1
            goto L_0x0039
        L_0x0021:
            int r3 = (r8 > r2 ? 1 : (r8 == r2 ? 0 : -1))
            if (r3 <= 0) goto L_0x0038
            r6.ensureRightGlow()
            android.widget.EdgeEffect r3 = r6.mRightGlow
            int r4 = r6.getWidth()
            float r4 = (float) r4
            float r4 = r8 / r4
            int r5 = r6.getHeight()
            float r5 = (float) r5
            float r9 = r9 / r5
            goto L_0x001c
        L_0x0038:
            r9 = 0
        L_0x0039:
            int r3 = (r10 > r2 ? 1 : (r10 == r2 ? 0 : -1))
            if (r3 >= 0) goto L_0x0053
            r6.ensureTopGlow()
            android.widget.EdgeEffect r9 = r6.mTopGlow
            float r0 = -r10
            int r3 = r6.getHeight()
            float r3 = (float) r3
            float r0 = r0 / r3
            int r3 = r6.getWidth()
            float r3 = (float) r3
            float r7 = r7 / r3
            p000.C0815h0.m5810a((android.widget.EdgeEffect) r9, (float) r0, (float) r7)
            goto L_0x006f
        L_0x0053:
            int r3 = (r10 > r2 ? 1 : (r10 == r2 ? 0 : -1))
            if (r3 <= 0) goto L_0x006e
            r6.ensureBottomGlow()
            android.widget.EdgeEffect r9 = r6.mBottomGlow
            int r3 = r6.getHeight()
            float r3 = (float) r3
            float r3 = r10 / r3
            int r4 = r6.getWidth()
            float r4 = (float) r4
            float r7 = r7 / r4
            float r0 = r0 - r7
            p000.C0815h0.m5810a((android.widget.EdgeEffect) r9, (float) r3, (float) r0)
            goto L_0x006f
        L_0x006e:
            r1 = r9
        L_0x006f:
            if (r1 != 0) goto L_0x0079
            int r7 = (r8 > r2 ? 1 : (r8 == r2 ? 0 : -1))
            if (r7 != 0) goto L_0x0079
            int r7 = (r10 > r2 ? 1 : (r10 == r2 ? 0 : -1))
            if (r7 == 0) goto L_0x007c
        L_0x0079:
            p000.C2189w7.m14972D(r6)
        L_0x007c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.pullGlows(float, float, float, float):void");
    }

    private void recoverFocusFromState() {
        View view;
        if (this.mPreserveFocusAfterLayout && this.mAdapter != null && hasFocus() && getDescendantFocusability() != 393216) {
            if (getDescendantFocusability() != 131072 || !isFocused()) {
                if (!isFocused()) {
                    View focusedChild = getFocusedChild();
                    if (!IGNORE_DETACHED_FOCUSED_CHILD || (focusedChild.getParent() != null && focusedChild.hasFocus())) {
                        if (!this.mChildHelper.mo7591b(focusedChild)) {
                            return;
                        }
                    } else if (this.mChildHelper.mo7584a() == 0) {
                        requestFocus();
                        return;
                    }
                }
                long j = this.mState.f1302n;
                View view2 = null;
                C0218d0 findViewHolderForItemId = (j == -1 || !this.mAdapter.f1337b) ? null : findViewHolderForItemId(j);
                if (findViewHolderForItemId != null && !this.mChildHelper.mo7591b(findViewHolderForItemId.f1316X) && findViewHolderForItemId.f1316X.hasFocusable()) {
                    view2 = findViewHolderForItemId.f1316X;
                } else if (this.mChildHelper.mo7584a() > 0) {
                    view2 = findNextViewToFocus();
                }
                if (view2 != null) {
                    int i = this.mState.f1303o;
                    if (((long) i) == -1 || (view = view2.findViewById(i)) == null || !view.isFocusable()) {
                        view = view2;
                    }
                    view.requestFocus();
                }
            }
        }
    }

    private void releaseGlows() {
        boolean z;
        EdgeEffect edgeEffect = this.mLeftGlow;
        if (edgeEffect != null) {
            edgeEffect.onRelease();
            z = this.mLeftGlow.isFinished();
        } else {
            z = false;
        }
        EdgeEffect edgeEffect2 = this.mTopGlow;
        if (edgeEffect2 != null) {
            edgeEffect2.onRelease();
            z |= this.mTopGlow.isFinished();
        }
        EdgeEffect edgeEffect3 = this.mRightGlow;
        if (edgeEffect3 != null) {
            edgeEffect3.onRelease();
            z |= this.mRightGlow.isFinished();
        }
        EdgeEffect edgeEffect4 = this.mBottomGlow;
        if (edgeEffect4 != null) {
            edgeEffect4.onRelease();
            z |= this.mBottomGlow.isFinished();
        }
        if (z) {
            C2189w7.m14972D(this);
        }
    }

    private void requestChildOnScreen(View view, View view2) {
        View view3 = view2 != null ? view2 : view;
        this.mTempRect.set(0, 0, view3.getWidth(), view3.getHeight());
        ViewGroup.LayoutParams layoutParams = view3.getLayoutParams();
        if (layoutParams instanceof C0237p) {
            C0237p pVar = (C0237p) layoutParams;
            if (!pVar.f1373Z) {
                Rect rect = pVar.f1372Y;
                Rect rect2 = this.mTempRect;
                rect2.left -= rect.left;
                rect2.right += rect.right;
                rect2.top -= rect.top;
                rect2.bottom += rect.bottom;
            }
        }
        if (view2 != null) {
            offsetDescendantRectToMyCoords(view2, this.mTempRect);
            offsetRectIntoDescendantCoords(view, this.mTempRect);
        }
        this.mLayout.mo1894a(this, view, this.mTempRect, !this.mFirstLayoutComplete, view2 == null);
    }

    private void resetFocusInfo() {
        C0212a0 a0Var = this.mState;
        a0Var.f1302n = -1;
        a0Var.f1301m = -1;
        a0Var.f1303o = -1;
    }

    private void resetScroll() {
        VelocityTracker velocityTracker = this.mVelocityTracker;
        if (velocityTracker != null) {
            velocityTracker.clear();
        }
        stopNestedScroll(0);
        releaseGlows();
    }

    private void saveFocusInfo() {
        C0218d0 d0Var = null;
        View focusedChild = (!this.mPreserveFocusAfterLayout || !hasFocus() || this.mAdapter == null) ? null : getFocusedChild();
        if (focusedChild != null) {
            d0Var = findContainingViewHolder(focusedChild);
        }
        if (d0Var == null) {
            resetFocusInfo();
            return;
        }
        this.mState.f1302n = this.mAdapter.f1337b ? d0Var.f1320b0 : -1;
        this.mState.f1301m = this.mDataSetHasChangedAfterLayout ? -1 : d0Var.mo1815r() ? d0Var.f1319a0 : d0Var.mo1808k();
        this.mState.f1303o = getDeepestFocusedViewWithId(d0Var.f1316X);
    }

    private void setAdapterInternal(C0221g gVar, boolean z, boolean z2) {
        C0221g gVar2 = this.mAdapter;
        if (gVar2 != null) {
            gVar2.f1336a.unregisterObserver(this.mObserver);
            this.mAdapter.mo1842b(this);
        }
        if (!z || z2) {
            removeAndRecycleViews();
        }
        C0926ic icVar = this.mAdapterHelper;
        icVar.mo6904a((List<C0926ic.C0928b>) icVar.f7366b);
        icVar.mo6904a((List<C0926ic.C0928b>) icVar.f7367c);
        icVar.f7372h = 0;
        C0221g gVar3 = this.mAdapter;
        this.mAdapter = gVar;
        if (gVar != null) {
            gVar.f1336a.registerObserver(this.mObserver);
            gVar.mo1838a(this);
        }
        C0232o oVar = this.mLayout;
        if (oVar != null) {
            oVar.mo1881a(gVar3, this.mAdapter);
        }
        C0244v vVar = this.mRecycler;
        C0221g gVar4 = this.mAdapter;
        vVar.mo1985a();
        vVar.mo1992b().mo1981a(gVar3, gVar4, z);
        this.mState.f1295g = true;
    }

    private void stopScrollersInternal() {
        this.mViewFlinger.mo1797b();
        C0232o oVar = this.mLayout;
        if (oVar != null) {
            oVar.mo1870H();
        }
    }

    public void absorbGlows(int i, int i2) {
        if (i < 0) {
            ensureLeftGlow();
            if (this.mLeftGlow.isFinished()) {
                this.mLeftGlow.onAbsorb(-i);
            }
        } else if (i > 0) {
            ensureRightGlow();
            if (this.mRightGlow.isFinished()) {
                this.mRightGlow.onAbsorb(i);
            }
        }
        if (i2 < 0) {
            ensureTopGlow();
            if (this.mTopGlow.isFinished()) {
                this.mTopGlow.onAbsorb(-i2);
            }
        } else if (i2 > 0) {
            ensureBottomGlow();
            if (this.mBottomGlow.isFinished()) {
                this.mBottomGlow.onAbsorb(i2);
            }
        }
        if (i != 0 || i2 != 0) {
            C2189w7.m14972D(this);
        }
    }

    public void addFocusables(ArrayList<View> arrayList, int i, int i2) {
        C0232o oVar = this.mLayout;
        if (oVar == null || !oVar.mo1963y()) {
            super.addFocusables(arrayList, i, i2);
        }
    }

    public void addItemDecoration(C0231n nVar) {
        addItemDecoration(nVar, -1);
    }

    public void addItemDecoration(C0231n nVar, int i) {
        C0232o oVar = this.mLayout;
        if (oVar != null) {
            oVar.mo1562a("Cannot add item decoration during a scroll  or layout");
        }
        if (this.mItemDecorations.isEmpty()) {
            setWillNotDraw(false);
        }
        if (i < 0) {
            this.mItemDecorations.add(nVar);
        } else {
            this.mItemDecorations.add(i, nVar);
        }
        markItemDecorInsetsDirty();
        requestLayout();
    }

    public void addOnChildAttachStateChangeListener(C0238q qVar) {
        if (this.mOnChildAttachStateListeners == null) {
            this.mOnChildAttachStateListeners = new ArrayList();
        }
        this.mOnChildAttachStateListeners.add(qVar);
    }

    public void addOnItemTouchListener(C0240s sVar) {
        this.mOnItemTouchListeners.add(sVar);
    }

    public void addOnScrollListener(C0241t tVar) {
        if (this.mScrollListeners == null) {
            this.mScrollListeners = new ArrayList();
        }
        this.mScrollListeners.add(tVar);
    }

    public void animateAppearance(C0218d0 d0Var, C0226l.C0229c cVar, C0226l.C0229c cVar2) {
        d0Var.mo1804a(false);
        if (this.mItemAnimator.mo384a(d0Var, cVar, cVar2)) {
            postAnimationRunner();
        }
    }

    public void animateDisappearance(C0218d0 d0Var, C0226l.C0229c cVar, C0226l.C0229c cVar2) {
        addAnimatingView(d0Var);
        d0Var.mo1804a(false);
        if (this.mItemAnimator.mo386b(d0Var, cVar, cVar2)) {
            postAnimationRunner();
        }
    }

    public void assertInLayoutOrScroll(String str) {
        if (isComputingLayout()) {
            return;
        }
        if (str == null) {
            throw new IllegalStateException(C0789gk.m5554a(this, C0789gk.m5562a("Cannot call this method unless RecyclerView is computing a layout or scrolling")));
        }
        throw new IllegalStateException(C0789gk.m5554a(this, C0789gk.m5562a(str)));
    }

    public void assertNotInLayoutOrScroll(String str) {
        if (isComputingLayout()) {
            if (str == null) {
                throw new IllegalStateException(C0789gk.m5554a(this, C0789gk.m5562a("Cannot call this method while RecyclerView is computing a layout or scrolling")));
            }
            throw new IllegalStateException(str);
        } else if (this.mDispatchScrollCounter > 0) {
            Log.w(TAG, "Cannot call this method in a scroll callback. Scroll callbacks mightbe run during a measure & layout pass where you cannot change theRecyclerView data. Any method call that might change the structureof the RecyclerView or the adapter contents should be postponed tothe next frame.", new IllegalStateException(C0789gk.m5554a(this, C0789gk.m5562a(""))));
        }
    }

    public boolean canReuseUpdatedViewHolder(C0218d0 d0Var) {
        C0226l lVar = this.mItemAnimator;
        return lVar == null || lVar.mo1855a(d0Var, d0Var.mo1810m());
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof C0237p) && this.mLayout.mo1508a((C0237p) layoutParams);
    }

    public void clearOldPositions() {
        int b = this.mChildHelper.mo7589b();
        for (int i = 0; i < b; i++) {
            C0218d0 childViewHolderInt = getChildViewHolderInt(this.mChildHelper.mo7594d(i));
            if (!childViewHolderInt.mo1821w()) {
                childViewHolderInt.mo1806i();
            }
        }
        C0244v vVar = this.mRecycler;
        int size = vVar.f1383c.size();
        for (int i2 = 0; i2 < size; i2++) {
            vVar.f1383c.get(i2).mo1806i();
        }
        int size2 = vVar.f1381a.size();
        for (int i3 = 0; i3 < size2; i3++) {
            vVar.f1381a.get(i3).mo1806i();
        }
        ArrayList<C0218d0> arrayList = vVar.f1382b;
        if (arrayList != null) {
            int size3 = arrayList.size();
            for (int i4 = 0; i4 < size3; i4++) {
                vVar.f1382b.get(i4).mo1806i();
            }
        }
    }

    public void clearOnChildAttachStateChangeListeners() {
        List<C0238q> list = this.mOnChildAttachStateListeners;
        if (list != null) {
            list.clear();
        }
    }

    public void clearOnScrollListeners() {
        List<C0241t> list = this.mScrollListeners;
        if (list != null) {
            list.clear();
        }
    }

    public int computeHorizontalScrollExtent() {
        C0232o oVar = this.mLayout;
        if (oVar != null && oVar.mo1567b()) {
            return this.mLayout.mo1549a(this.mState);
        }
        return 0;
    }

    public int computeHorizontalScrollOffset() {
        C0232o oVar = this.mLayout;
        if (oVar != null && oVar.mo1567b()) {
            return this.mLayout.mo1510b(this.mState);
        }
        return 0;
    }

    public int computeHorizontalScrollRange() {
        C0232o oVar = this.mLayout;
        if (oVar != null && oVar.mo1567b()) {
            return this.mLayout.mo1515c(this.mState);
        }
        return 0;
    }

    public int computeVerticalScrollExtent() {
        C0232o oVar = this.mLayout;
        if (oVar != null && oVar.mo1570c()) {
            return this.mLayout.mo1571d(this.mState);
        }
        return 0;
    }

    public int computeVerticalScrollOffset() {
        C0232o oVar = this.mLayout;
        if (oVar != null && oVar.mo1570c()) {
            return this.mLayout.mo1521e(this.mState);
        }
        return 0;
    }

    public int computeVerticalScrollRange() {
        C0232o oVar = this.mLayout;
        if (oVar != null && oVar.mo1570c()) {
            return this.mLayout.mo1522f(this.mState);
        }
        return 0;
    }

    public void considerReleasingGlowsOnScroll(int i, int i2) {
        boolean z;
        EdgeEffect edgeEffect = this.mLeftGlow;
        if (edgeEffect == null || edgeEffect.isFinished() || i <= 0) {
            z = false;
        } else {
            this.mLeftGlow.onRelease();
            z = this.mLeftGlow.isFinished();
        }
        EdgeEffect edgeEffect2 = this.mRightGlow;
        if (edgeEffect2 != null && !edgeEffect2.isFinished() && i < 0) {
            this.mRightGlow.onRelease();
            z |= this.mRightGlow.isFinished();
        }
        EdgeEffect edgeEffect3 = this.mTopGlow;
        if (edgeEffect3 != null && !edgeEffect3.isFinished() && i2 > 0) {
            this.mTopGlow.onRelease();
            z |= this.mTopGlow.isFinished();
        }
        EdgeEffect edgeEffect4 = this.mBottomGlow;
        if (edgeEffect4 != null && !edgeEffect4.isFinished() && i2 < 0) {
            this.mBottomGlow.onRelease();
            z |= this.mBottomGlow.isFinished();
        }
        if (z) {
            C2189w7.m14972D(this);
        }
    }

    public void consumePendingUpdateOperations() {
        if (!this.mFirstLayoutComplete || this.mDataSetHasChangedAfterLayout) {
            int i = Build.VERSION.SDK_INT;
            Trace.beginSection(TRACE_ON_DATA_SET_CHANGE_LAYOUT_TAG);
            dispatchLayout();
            int i2 = Build.VERSION.SDK_INT;
            Trace.endSection();
        } else if (this.mAdapterHelper.mo6912c()) {
            boolean z = false;
            if ((this.mAdapterHelper.f7372h & 4) != 0) {
                if ((this.mAdapterHelper.f7372h & 11) != 0) {
                    z = true;
                }
                if (!z) {
                    int i3 = Build.VERSION.SDK_INT;
                    Trace.beginSection(TRACE_HANDLE_ADAPTER_UPDATES_TAG);
                    startInterceptRequestLayout();
                    onEnterLayoutOrScroll();
                    this.mAdapterHelper.mo6915d();
                    if (!this.mLayoutWasDefered) {
                        if (hasUpdatedView()) {
                            dispatchLayout();
                        } else {
                            this.mAdapterHelper.mo6901a();
                        }
                    }
                    stopInterceptRequestLayout(true);
                    onExitLayoutOrScroll();
                    int i4 = Build.VERSION.SDK_INT;
                    Trace.endSection();
                }
            }
            if (this.mAdapterHelper.mo6912c()) {
                int i5 = Build.VERSION.SDK_INT;
                Trace.beginSection(TRACE_ON_DATA_SET_CHANGE_LAYOUT_TAG);
                dispatchLayout();
                int i42 = Build.VERSION.SDK_INT;
                Trace.endSection();
            }
        }
    }

    public void defaultOnMeasure(int i, int i2) {
        setMeasuredDimension(C0232o.m1223c(i, getPaddingRight() + getPaddingLeft(), C2189w7.m15020o(this)), C0232o.m1223c(i2, getPaddingBottom() + getPaddingTop(), C2189w7.m15019n(this)));
    }

    public void dispatchChildAttached(View view) {
        C0218d0 childViewHolderInt = getChildViewHolderInt(view);
        onChildAttachedToWindow(view);
        C0221g gVar = this.mAdapter;
        if (!(gVar == null || childViewHolderInt == null)) {
            gVar.mo1844c();
        }
        List<C0238q> list = this.mOnChildAttachStateListeners;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                this.mOnChildAttachStateListeners.get(size).mo1973a(view);
            }
        }
    }

    public void dispatchChildDetached(View view) {
        C0218d0 childViewHolderInt = getChildViewHolderInt(view);
        onChildDetachedFromWindow(view);
        C0221g gVar = this.mAdapter;
        if (!(gVar == null || childViewHolderInt == null)) {
            gVar.mo1845d();
        }
        List<C0238q> list = this.mOnChildAttachStateListeners;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                this.mOnChildAttachStateListeners.get(size).mo1974b(view);
            }
        }
    }

    public void dispatchLayout() {
        String str;
        if (this.mAdapter == null) {
            str = "No adapter attached; skipping layout";
        } else if (this.mLayout == null) {
            str = "No layout manager attached; skipping layout";
        } else {
            C0212a0 a0Var = this.mState;
            boolean z = false;
            a0Var.f1298j = false;
            if (a0Var.f1293e == 1) {
                dispatchLayoutStep1();
            } else {
                C0926ic icVar = this.mAdapterHelper;
                if (!icVar.f7367c.isEmpty() && !icVar.f7366b.isEmpty()) {
                    z = true;
                }
                if (!z && this.mLayout.mo1954p() == getWidth() && this.mLayout.mo1936i() == getHeight()) {
                    this.mLayout.mo1920e(this);
                    dispatchLayoutStep3();
                    return;
                }
            }
            this.mLayout.mo1920e(this);
            dispatchLayoutStep2();
            dispatchLayoutStep3();
            return;
        }
        Log.e(TAG, str);
    }

    public boolean dispatchNestedFling(float f, float f2, boolean z) {
        return getScrollingChildHelper().mo8621a(f, f2, z);
    }

    public boolean dispatchNestedPreFling(float f, float f2) {
        return getScrollingChildHelper().mo8620a(f, f2);
    }

    public boolean dispatchNestedPreScroll(int i, int i2, int[] iArr, int[] iArr2) {
        return getScrollingChildHelper().mo8624a(i, i2, iArr, iArr2, 0);
    }

    public boolean dispatchNestedPreScroll(int i, int i2, int[] iArr, int[] iArr2, int i3) {
        return getScrollingChildHelper().mo8624a(i, i2, iArr, iArr2, i3);
    }

    public final void dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr, int i5, int[] iArr2) {
        getScrollingChildHelper().mo8626b(i, i2, i3, i4, iArr, i5, iArr2);
    }

    public boolean dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr) {
        return getScrollingChildHelper().mo8623a(i, i2, i3, i4, iArr);
    }

    public void dispatchOnScrollStateChanged(int i) {
        C0232o oVar = this.mLayout;
        if (oVar != null) {
            oVar.mo1941j(i);
        }
        onScrollStateChanged(i);
        C0241t tVar = this.mScrollListener;
        if (tVar != null) {
            tVar.mo1975a(this, i);
        }
        List<C0241t> list = this.mScrollListeners;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                this.mScrollListeners.get(size).mo1975a(this, i);
            }
        }
    }

    public void dispatchOnScrolled(int i, int i2) {
        this.mDispatchScrollCounter++;
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        onScrollChanged(scrollX, scrollY, scrollX - i, scrollY - i2);
        onScrolled(i, i2);
        C0241t tVar = this.mScrollListener;
        if (tVar != null) {
            tVar.mo1976a(this, i, i2);
        }
        List<C0241t> list = this.mScrollListeners;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                this.mScrollListeners.get(size).mo1976a(this, i, i2);
            }
        }
        this.mDispatchScrollCounter--;
    }

    public void dispatchPendingImportantForAccessibilityChanges() {
        int i;
        for (int size = this.mPendingAccessibilityImportanceChange.size() - 1; size >= 0; size--) {
            C0218d0 d0Var = this.mPendingAccessibilityImportanceChange.get(size);
            if (d0Var.f1316X.getParent() == this && !d0Var.mo1821w() && (i = d0Var.f1332n0) != -1) {
                C2189w7.m15013h(d0Var.f1316X, i);
                d0Var.f1332n0 = -1;
            }
        }
        this.mPendingAccessibilityImportanceChange.clear();
    }

    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        onPopulateAccessibilityEvent(accessibilityEvent);
        return true;
    }

    public void dispatchRestoreInstanceState(SparseArray<Parcelable> sparseArray) {
        dispatchThawSelfOnly(sparseArray);
    }

    public void dispatchSaveInstanceState(SparseArray<Parcelable> sparseArray) {
        dispatchFreezeSelfOnly(sparseArray);
    }

    public void draw(Canvas canvas) {
        boolean z;
        boolean z2;
        float f;
        float f2;
        super.draw(canvas);
        int size = this.mItemDecorations.size();
        boolean z3 = false;
        for (int i = 0; i < size; i++) {
            this.mItemDecorations.get(i).mo1864b(canvas, this, this.mState);
        }
        EdgeEffect edgeEffect = this.mLeftGlow;
        if (edgeEffect == null || edgeEffect.isFinished()) {
            z = false;
        } else {
            int save = canvas.save();
            int paddingBottom = this.mClipToPadding ? getPaddingBottom() : 0;
            canvas.rotate(270.0f);
            canvas.translate((float) ((-getHeight()) + paddingBottom), 0.0f);
            EdgeEffect edgeEffect2 = this.mLeftGlow;
            z = edgeEffect2 != null && edgeEffect2.draw(canvas);
            canvas.restoreToCount(save);
        }
        EdgeEffect edgeEffect3 = this.mTopGlow;
        if (edgeEffect3 != null && !edgeEffect3.isFinished()) {
            int save2 = canvas.save();
            if (this.mClipToPadding) {
                canvas.translate((float) getPaddingLeft(), (float) getPaddingTop());
            }
            EdgeEffect edgeEffect4 = this.mTopGlow;
            z |= edgeEffect4 != null && edgeEffect4.draw(canvas);
            canvas.restoreToCount(save2);
        }
        EdgeEffect edgeEffect5 = this.mRightGlow;
        if (edgeEffect5 != null && !edgeEffect5.isFinished()) {
            int save3 = canvas.save();
            int width = getWidth();
            int paddingTop = this.mClipToPadding ? getPaddingTop() : 0;
            canvas.rotate(90.0f);
            canvas.translate((float) (-paddingTop), (float) (-width));
            EdgeEffect edgeEffect6 = this.mRightGlow;
            z |= edgeEffect6 != null && edgeEffect6.draw(canvas);
            canvas.restoreToCount(save3);
        }
        EdgeEffect edgeEffect7 = this.mBottomGlow;
        if (edgeEffect7 == null || edgeEffect7.isFinished()) {
            z2 = z;
        } else {
            int save4 = canvas.save();
            canvas.rotate(180.0f);
            if (this.mClipToPadding) {
                f2 = (float) (getPaddingRight() + (-getWidth()));
                f = (float) (getPaddingBottom() + (-getHeight()));
            } else {
                f2 = (float) (-getWidth());
                f = (float) (-getHeight());
            }
            canvas.translate(f2, f);
            EdgeEffect edgeEffect8 = this.mBottomGlow;
            if (edgeEffect8 != null && edgeEffect8.draw(canvas)) {
                z3 = true;
            }
            z2 = z3 | z;
            canvas.restoreToCount(save4);
        }
        if (!z2 && this.mItemAnimator != null && this.mItemDecorations.size() > 0 && this.mItemAnimator.mo1858d()) {
            z2 = true;
        }
        if (z2) {
            C2189w7.m14972D(this);
        }
    }

    public boolean drawChild(Canvas canvas, View view, long j) {
        return super.drawChild(canvas, view, j);
    }

    public void ensureBottomGlow() {
        int i;
        int i2;
        EdgeEffect edgeEffect;
        if (this.mBottomGlow == null) {
            this.mBottomGlow = this.mEdgeEffectFactory.mo1852a(this);
            if (this.mClipToPadding) {
                edgeEffect = this.mBottomGlow;
                i2 = (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
                i = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
            } else {
                edgeEffect = this.mBottomGlow;
                i2 = getMeasuredWidth();
                i = getMeasuredHeight();
            }
            edgeEffect.setSize(i2, i);
        }
    }

    public void ensureLeftGlow() {
        int i;
        int i2;
        EdgeEffect edgeEffect;
        if (this.mLeftGlow == null) {
            this.mLeftGlow = this.mEdgeEffectFactory.mo1852a(this);
            if (this.mClipToPadding) {
                edgeEffect = this.mLeftGlow;
                i2 = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
                i = (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
            } else {
                edgeEffect = this.mLeftGlow;
                i2 = getMeasuredHeight();
                i = getMeasuredWidth();
            }
            edgeEffect.setSize(i2, i);
        }
    }

    public void ensureRightGlow() {
        int i;
        int i2;
        EdgeEffect edgeEffect;
        if (this.mRightGlow == null) {
            this.mRightGlow = this.mEdgeEffectFactory.mo1852a(this);
            if (this.mClipToPadding) {
                edgeEffect = this.mRightGlow;
                i2 = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
                i = (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
            } else {
                edgeEffect = this.mRightGlow;
                i2 = getMeasuredHeight();
                i = getMeasuredWidth();
            }
            edgeEffect.setSize(i2, i);
        }
    }

    public void ensureTopGlow() {
        int i;
        int i2;
        EdgeEffect edgeEffect;
        if (this.mTopGlow == null) {
            this.mTopGlow = this.mEdgeEffectFactory.mo1852a(this);
            if (this.mClipToPadding) {
                edgeEffect = this.mTopGlow;
                i2 = (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
                i = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
            } else {
                edgeEffect = this.mTopGlow;
                i2 = getMeasuredWidth();
                i = getMeasuredHeight();
            }
            edgeEffect.setSize(i2, i);
        }
    }

    public String exceptionLabel() {
        StringBuilder a = C0789gk.m5562a(" ");
        a.append(super.toString());
        a.append(", adapter:");
        a.append(this.mAdapter);
        a.append(", layout:");
        a.append(this.mLayout);
        a.append(", context:");
        a.append(getContext());
        return a.toString();
    }

    public final void fillRemainingScrollValues(C0212a0 a0Var) {
        if (getScrollState() == 2) {
            OverScroller overScroller = this.mViewFlinger.f1309Z;
            a0Var.f1304p = overScroller.getFinalX() - overScroller.getCurrX();
            a0Var.f1305q = overScroller.getFinalY() - overScroller.getCurrY();
            return;
        }
        a0Var.f1304p = 0;
        a0Var.f1305q = 0;
    }

    public View findChildViewUnder(float f, float f2) {
        for (int a = this.mChildHelper.mo7584a() - 1; a >= 0; a--) {
            View b = this.mChildHelper.mo7590b(a);
            float translationX = b.getTranslationX();
            float translationY = b.getTranslationY();
            if (f >= ((float) b.getLeft()) + translationX && f <= ((float) b.getRight()) + translationX && f2 >= ((float) b.getTop()) + translationY && f2 <= ((float) b.getBottom()) + translationY) {
                return b;
            }
        }
        return null;
    }

    /* JADX WARNING: Removed duplicated region for block: B:11:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:7:0x0013 A[ORIG_RETURN, RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.View findContainingItemView(android.view.View r3) {
        /*
            r2 = this;
        L_0x0000:
            android.view.ViewParent r0 = r3.getParent()
            if (r0 == 0) goto L_0x0010
            if (r0 == r2) goto L_0x0010
            boolean r1 = r0 instanceof android.view.View
            if (r1 == 0) goto L_0x0010
            r3 = r0
            android.view.View r3 = (android.view.View) r3
            goto L_0x0000
        L_0x0010:
            if (r0 != r2) goto L_0x0013
            goto L_0x0014
        L_0x0013:
            r3 = 0
        L_0x0014:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.findContainingItemView(android.view.View):android.view.View");
    }

    public C0218d0 findContainingViewHolder(View view) {
        View findContainingItemView = findContainingItemView(view);
        if (findContainingItemView == null) {
            return null;
        }
        return getChildViewHolder(findContainingItemView);
    }

    public C0218d0 findViewHolderForAdapterPosition(int i) {
        C0218d0 d0Var = null;
        if (this.mDataSetHasChangedAfterLayout) {
            return null;
        }
        int b = this.mChildHelper.mo7589b();
        for (int i2 = 0; i2 < b; i2++) {
            C0218d0 childViewHolderInt = getChildViewHolderInt(this.mChildHelper.mo7594d(i2));
            if (childViewHolderInt != null && !childViewHolderInt.mo1815r() && getAdapterPositionFor(childViewHolderInt) == i) {
                if (!this.mChildHelper.mo7591b(childViewHolderInt.f1316X)) {
                    return childViewHolderInt;
                }
                d0Var = childViewHolderInt;
            }
        }
        return d0Var;
    }

    public C0218d0 findViewHolderForItemId(long j) {
        C0221g gVar = this.mAdapter;
        C0218d0 d0Var = null;
        if (gVar != null && gVar.f1337b) {
            int b = this.mChildHelper.mo7589b();
            for (int i = 0; i < b; i++) {
                C0218d0 childViewHolderInt = getChildViewHolderInt(this.mChildHelper.mo7594d(i));
                if (childViewHolderInt != null && !childViewHolderInt.mo1815r() && childViewHolderInt.f1320b0 == j) {
                    if (!this.mChildHelper.mo7591b(childViewHolderInt.f1316X)) {
                        return childViewHolderInt;
                    }
                    d0Var = childViewHolderInt;
                }
            }
        }
        return d0Var;
    }

    public C0218d0 findViewHolderForLayoutPosition(int i) {
        return findViewHolderForPosition(i, false);
    }

    @Deprecated
    public C0218d0 findViewHolderForPosition(int i) {
        return findViewHolderForPosition(i, false);
    }

    public C0218d0 findViewHolderForPosition(int i, boolean z) {
        int b = this.mChildHelper.mo7589b();
        C0218d0 d0Var = null;
        for (int i2 = 0; i2 < b; i2++) {
            C0218d0 childViewHolderInt = getChildViewHolderInt(this.mChildHelper.mo7594d(i2));
            if (childViewHolderInt != null && !childViewHolderInt.mo1815r()) {
                if (z) {
                    if (childViewHolderInt.f1318Z != i) {
                        continue;
                    }
                } else if (childViewHolderInt.mo1809l() != i) {
                    continue;
                }
                if (!this.mChildHelper.mo7591b(childViewHolderInt.f1316X)) {
                    return childViewHolderInt;
                }
                d0Var = childViewHolderInt;
            }
        }
        return d0Var;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:51:0x00b4, code lost:
        r15 = r10 - 1;
     */
    /* JADX WARNING: Removed duplicated region for block: B:79:0x010c  */
    /* JADX WARNING: Removed duplicated region for block: B:81:0x0114  */
    /* JADX WARNING: Removed duplicated region for block: B:84:0x0119 A[RETURN] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean fling(int r19, int r20) {
        /*
            r18 = this;
            r0 = r18
            androidx.recyclerview.widget.RecyclerView$o r1 = r0.mLayout
            r2 = 0
            if (r1 != 0) goto L_0x000f
            java.lang.String r1 = "RecyclerView"
            java.lang.String r3 = "Cannot fling without a LayoutManager set. Call setLayoutManager with a non-null argument."
            android.util.Log.e(r1, r3)
            return r2
        L_0x000f:
            boolean r3 = r0.mLayoutSuppressed
            if (r3 == 0) goto L_0x0014
            return r2
        L_0x0014:
            boolean r1 = r1.mo1567b()
            androidx.recyclerview.widget.RecyclerView$o r3 = r0.mLayout
            boolean r3 = r3.mo1570c()
            if (r1 == 0) goto L_0x002c
            int r4 = java.lang.Math.abs(r19)
            int r5 = r0.mMinFlingVelocity
            if (r4 >= r5) goto L_0x0029
            goto L_0x002c
        L_0x0029:
            r4 = r19
            goto L_0x002d
        L_0x002c:
            r4 = 0
        L_0x002d:
            if (r3 == 0) goto L_0x003b
            int r5 = java.lang.Math.abs(r20)
            int r6 = r0.mMinFlingVelocity
            if (r5 >= r6) goto L_0x0038
            goto L_0x003b
        L_0x0038:
            r5 = r20
            goto L_0x003c
        L_0x003b:
            r5 = 0
        L_0x003c:
            if (r4 != 0) goto L_0x0041
            if (r5 != 0) goto L_0x0041
            return r2
        L_0x0041:
            float r6 = (float) r4
            float r7 = (float) r5
            boolean r8 = r0.dispatchNestedPreFling(r6, r7)
            if (r8 != 0) goto L_0x0179
            if (r1 != 0) goto L_0x0050
            if (r3 == 0) goto L_0x004e
            goto L_0x0050
        L_0x004e:
            r9 = 0
            goto L_0x0051
        L_0x0050:
            r9 = 1
        L_0x0051:
            r0.dispatchNestedFling(r6, r7, r9)
            androidx.recyclerview.widget.RecyclerView$r r6 = r0.mOnFlingListener
            if (r6 == 0) goto L_0x011b
            bd r6 = (p000.C0297bd) r6
            androidx.recyclerview.widget.RecyclerView r7 = r6.f1816a
            androidx.recyclerview.widget.RecyclerView$o r7 = r7.getLayoutManager()
            if (r7 != 0) goto L_0x0064
            goto L_0x0116
        L_0x0064:
            androidx.recyclerview.widget.RecyclerView r10 = r6.f1816a
            androidx.recyclerview.widget.RecyclerView$g r10 = r10.getAdapter()
            if (r10 != 0) goto L_0x006e
            goto L_0x0116
        L_0x006e:
            androidx.recyclerview.widget.RecyclerView r10 = r6.f1816a
            int r10 = r10.getMinFlingVelocity()
            int r11 = java.lang.Math.abs(r5)
            if (r11 > r10) goto L_0x0080
            int r11 = java.lang.Math.abs(r4)
            if (r11 <= r10) goto L_0x0116
        L_0x0080:
            boolean r10 = r7 instanceof androidx.recyclerview.widget.RecyclerView.C0249z.C0251b
            if (r10 != 0) goto L_0x0086
            goto L_0x010a
        L_0x0086:
            if (r10 != 0) goto L_0x008a
            r11 = 0
            goto L_0x0095
        L_0x008a:
            cd r11 = new cd
            androidx.recyclerview.widget.RecyclerView r12 = r6.f1816a
            android.content.Context r12 = r12.getContext()
            r11.<init>(r6, r12)
        L_0x0095:
            if (r11 != 0) goto L_0x0099
            goto L_0x010a
        L_0x0099:
            uc r6 = (p000.C2011uc) r6
            r12 = -1
            if (r10 != 0) goto L_0x009f
            goto L_0x00fa
        L_0x009f:
            int r10 = r7.mo1942k()
            if (r10 != 0) goto L_0x00a6
            goto L_0x00fa
        L_0x00a6:
            android.view.View r13 = r6.mo2445a(r7)
            if (r13 != 0) goto L_0x00ad
            goto L_0x00fa
        L_0x00ad:
            int r13 = r7.mo1949m((android.view.View) r13)
            if (r13 != r12) goto L_0x00b4
            goto L_0x00fa
        L_0x00b4:
            r14 = r7
            androidx.recyclerview.widget.RecyclerView$z$b r14 = (androidx.recyclerview.widget.RecyclerView.C0249z.C0251b) r14
            int r15 = r10 + -1
            android.graphics.PointF r14 = r14.mo1569c(r15)
            if (r14 != 0) goto L_0x00c0
            goto L_0x00fa
        L_0x00c0:
            boolean r16 = r7.mo1567b()
            r17 = 0
            if (r16 == 0) goto L_0x00d8
            yc r8 = r6.mo11610b(r7)
            int r8 = r6.mo11608a(r7, r8, r4, r2)
            float r12 = r14.x
            int r12 = (r12 > r17 ? 1 : (r12 == r17 ? 0 : -1))
            if (r12 >= 0) goto L_0x00d9
            int r8 = -r8
            goto L_0x00d9
        L_0x00d8:
            r8 = 0
        L_0x00d9:
            boolean r12 = r7.mo1570c()
            if (r12 == 0) goto L_0x00ef
            yc r12 = r6.mo11611c(r7)
            int r6 = r6.mo11608a(r7, r12, r2, r5)
            float r12 = r14.y
            int r12 = (r12 > r17 ? 1 : (r12 == r17 ? 0 : -1))
            if (r12 >= 0) goto L_0x00f0
            int r6 = -r6
            goto L_0x00f0
        L_0x00ef:
            r6 = 0
        L_0x00f0:
            boolean r12 = r7.mo1570c()
            if (r12 == 0) goto L_0x00f7
            goto L_0x00f8
        L_0x00f7:
            r6 = r8
        L_0x00f8:
            if (r6 != 0) goto L_0x00fd
        L_0x00fa:
            r6 = -1
            r15 = -1
            goto L_0x0108
        L_0x00fd:
            int r6 = r6 + r13
            if (r6 >= 0) goto L_0x0102
            r12 = 0
            goto L_0x0103
        L_0x0102:
            r12 = r6
        L_0x0103:
            if (r12 < r10) goto L_0x0106
            goto L_0x0107
        L_0x0106:
            r15 = r12
        L_0x0107:
            r6 = -1
        L_0x0108:
            if (r15 != r6) goto L_0x010c
        L_0x010a:
            r6 = 0
            goto L_0x0112
        L_0x010c:
            r11.f1391a = r15
            r7.mo1904b((androidx.recyclerview.widget.RecyclerView.C0249z) r11)
            r6 = 1
        L_0x0112:
            if (r6 == 0) goto L_0x0116
            r6 = 1
            goto L_0x0117
        L_0x0116:
            r6 = 0
        L_0x0117:
            if (r6 == 0) goto L_0x011b
            r6 = 1
            return r6
        L_0x011b:
            if (r9 == 0) goto L_0x0179
            if (r1 == 0) goto L_0x0121
            r1 = 1
            goto L_0x0122
        L_0x0121:
            r1 = 0
        L_0x0122:
            if (r3 == 0) goto L_0x0126
            r1 = r1 | 2
        L_0x0126:
            r3 = 1
            r0.startNestedScroll(r1, r3)
            int r1 = r0.mMaxFlingVelocity
            int r3 = -r1
            int r1 = java.lang.Math.min(r4, r1)
            int r9 = java.lang.Math.max(r3, r1)
            int r1 = r0.mMaxFlingVelocity
            int r3 = -r1
            int r1 = java.lang.Math.min(r5, r1)
            int r10 = java.lang.Math.max(r3, r1)
            androidx.recyclerview.widget.RecyclerView$c0 r1 = r0.mViewFlinger
            androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
            r4 = 2
            r3.setScrollState(r4)
            r1.f1308Y = r2
            r1.f1307X = r2
            android.view.animation.Interpolator r2 = r1.f1310a0
            android.view.animation.Interpolator r3 = sQuinticInterpolator
            if (r2 == r3) goto L_0x0163
            r1.f1310a0 = r3
            android.widget.OverScroller r2 = new android.widget.OverScroller
            androidx.recyclerview.widget.RecyclerView r3 = androidx.recyclerview.widget.RecyclerView.this
            android.content.Context r3 = r3.getContext()
            android.view.animation.Interpolator r4 = sQuinticInterpolator
            r2.<init>(r3, r4)
            r1.f1309Z = r2
        L_0x0163:
            android.widget.OverScroller r6 = r1.f1309Z
            r7 = 0
            r8 = 0
            r11 = -2147483648(0xffffffff80000000, float:-0.0)
            r12 = 2147483647(0x7fffffff, float:NaN)
            r13 = -2147483648(0xffffffff80000000, float:-0.0)
            r14 = 2147483647(0x7fffffff, float:NaN)
            r6.fling(r7, r8, r9, r10, r11, r12, r13, r14)
            r1.mo1795a()
            r1 = 1
            return r1
        L_0x0179:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.fling(int, int):boolean");
    }

    public View focusSearch(View view, int i) {
        View view2;
        boolean z;
        View A = this.mLayout.mo1865A();
        if (A != null) {
            return A;
        }
        boolean z2 = this.mAdapter != null && this.mLayout != null && !isComputingLayout() && !this.mLayoutSuppressed;
        FocusFinder instance = FocusFinder.getInstance();
        if (!z2 || !(i == 2 || i == 1)) {
            View findNextFocus = instance.findNextFocus(this, view, i);
            if (findNextFocus != null || !z2) {
                view2 = findNextFocus;
            } else {
                consumePendingUpdateOperations();
                if (findContainingItemView(view) == null) {
                    return null;
                }
                startInterceptRequestLayout();
                view2 = this.mLayout.mo1495a(view, i, this.mRecycler, this.mState);
                stopInterceptRequestLayout(false);
            }
        } else {
            if (this.mLayout.mo1570c()) {
                int i2 = i == 2 ? 130 : 33;
                z = instance.findNextFocus(this, view, i2) == null;
                if (FORCE_ABS_FOCUS_SEARCH_DIRECTION) {
                    i = i2;
                }
            } else {
                z = false;
            }
            if (!z && this.mLayout.mo1567b()) {
                int i3 = (this.mLayout.mo1945l() == 1) ^ (i == 2) ? 66 : 17;
                z = instance.findNextFocus(this, view, i3) == null;
                if (FORCE_ABS_FOCUS_SEARCH_DIRECTION) {
                    i = i3;
                }
            }
            if (z) {
                consumePendingUpdateOperations();
                if (findContainingItemView(view) == null) {
                    return null;
                }
                startInterceptRequestLayout();
                this.mLayout.mo1495a(view, i, this.mRecycler, this.mState);
                stopInterceptRequestLayout(false);
            }
            view2 = instance.findNextFocus(this, view, i);
        }
        if (view2 == null || view2.hasFocusable()) {
            return isPreferredNextFocus(view, view2, i) ? view2 : super.focusSearch(view, i);
        }
        if (getFocusedChild() == null) {
            return super.focusSearch(view, i);
        }
        requestChildOnScreen(view2, (View) null);
        return view;
    }

    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        C0232o oVar = this.mLayout;
        if (oVar != null) {
            return oVar.mo1520d();
        }
        throw new IllegalStateException(C0789gk.m5554a(this, C0789gk.m5562a("RecyclerView has no LayoutManager")));
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        C0232o oVar = this.mLayout;
        if (oVar != null) {
            return oVar.mo1497a(getContext(), attributeSet);
        }
        throw new IllegalStateException(C0789gk.m5554a(this, C0789gk.m5562a("RecyclerView has no LayoutManager")));
    }

    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        C0232o oVar = this.mLayout;
        if (oVar != null) {
            return oVar.mo1498a(layoutParams);
        }
        throw new IllegalStateException(C0789gk.m5554a(this, C0789gk.m5562a("RecyclerView has no LayoutManager")));
    }

    public CharSequence getAccessibilityClassName() {
        return "androidx.recyclerview.widget.RecyclerView";
    }

    public C0221g getAdapter() {
        return this.mAdapter;
    }

    public int getAdapterPositionFor(C0218d0 d0Var) {
        if (d0Var.mo1805b(524) || !d0Var.mo1812o()) {
            return -1;
        }
        C0926ic icVar = this.mAdapterHelper;
        int i = d0Var.f1318Z;
        int size = icVar.f7366b.size();
        for (int i2 = 0; i2 < size; i2++) {
            C0926ic.C0928b bVar = icVar.f7366b.get(i2);
            int i3 = bVar.f7373a;
            if (i3 != 1) {
                if (i3 == 2) {
                    int i4 = bVar.f7374b;
                    if (i4 <= i) {
                        int i5 = bVar.f7376d;
                        if (i4 + i5 > i) {
                            return -1;
                        }
                        i -= i5;
                    } else {
                        continue;
                    }
                } else if (i3 == 8) {
                    int i6 = bVar.f7374b;
                    if (i6 == i) {
                        i = bVar.f7376d;
                    } else {
                        if (i6 < i) {
                            i--;
                        }
                        if (bVar.f7376d <= i) {
                            i++;
                        }
                    }
                }
            } else if (bVar.f7374b <= i) {
                i += bVar.f7376d;
            }
        }
        return i;
    }

    public int getBaseline() {
        C0232o oVar = this.mLayout;
        return oVar != null ? oVar.mo1916e() : super.getBaseline();
    }

    public long getChangedHolderKey(C0218d0 d0Var) {
        if (this.mAdapter.f1337b) {
            return d0Var.f1320b0;
        }
        return (long) d0Var.f1318Z;
    }

    public int getChildAdapterPosition(View view) {
        C0218d0 childViewHolderInt = getChildViewHolderInt(view);
        if (childViewHolderInt != null) {
            return childViewHolderInt.mo1808k();
        }
        return -1;
    }

    public int getChildDrawingOrder(int i, int i2) {
        return super.getChildDrawingOrder(i, i2);
    }

    public long getChildItemId(View view) {
        C0218d0 childViewHolderInt;
        C0221g gVar = this.mAdapter;
        if (gVar == null || !gVar.f1337b || (childViewHolderInt = getChildViewHolderInt(view)) == null) {
            return -1;
        }
        return childViewHolderInt.f1320b0;
    }

    public int getChildLayoutPosition(View view) {
        C0218d0 childViewHolderInt = getChildViewHolderInt(view);
        if (childViewHolderInt != null) {
            return childViewHolderInt.mo1809l();
        }
        return -1;
    }

    @Deprecated
    public int getChildPosition(View view) {
        return getChildAdapterPosition(view);
    }

    public C0218d0 getChildViewHolder(View view) {
        ViewParent parent = view.getParent();
        if (parent == null || parent == this) {
            return getChildViewHolderInt(view);
        }
        throw new IllegalArgumentException("View " + view + " is not a direct child of " + this);
    }

    public boolean getClipToPadding() {
        return this.mClipToPadding;
    }

    public C2435zc getCompatAccessibilityDelegate() {
        return this.mAccessibilityDelegate;
    }

    public void getDecoratedBoundsWithMargins(View view, Rect rect) {
        getDecoratedBoundsWithMarginsInt(view, rect);
    }

    public C0225k getEdgeEffectFactory() {
        return this.mEdgeEffectFactory;
    }

    public C0226l getItemAnimator() {
        return this.mItemAnimator;
    }

    public Rect getItemDecorInsetsForChild(View view) {
        C0237p pVar = (C0237p) view.getLayoutParams();
        if (!pVar.f1373Z) {
            return pVar.f1372Y;
        }
        if (this.mState.f1296h && (pVar.mo1971o() || pVar.f1371X.mo1813p())) {
            return pVar.f1372Y;
        }
        Rect rect = pVar.f1372Y;
        rect.set(0, 0, 0, 0);
        int size = this.mItemDecorations.size();
        for (int i = 0; i < size; i++) {
            this.mTempRect.set(0, 0, 0, 0);
            this.mItemDecorations.get(i).mo1863a(this.mTempRect, view, this);
            int i2 = rect.left;
            Rect rect2 = this.mTempRect;
            rect.left = i2 + rect2.left;
            rect.top += rect2.top;
            rect.right += rect2.right;
            rect.bottom += rect2.bottom;
        }
        pVar.f1373Z = false;
        return rect;
    }

    public C0231n getItemDecorationAt(int i) {
        int itemDecorationCount = getItemDecorationCount();
        if (i >= 0 && i < itemDecorationCount) {
            return this.mItemDecorations.get(i);
        }
        throw new IndexOutOfBoundsException(i + " is an invalid index for size " + itemDecorationCount);
    }

    public int getItemDecorationCount() {
        return this.mItemDecorations.size();
    }

    public C0232o getLayoutManager() {
        return this.mLayout;
    }

    public int getMaxFlingVelocity() {
        return this.mMaxFlingVelocity;
    }

    public int getMinFlingVelocity() {
        return this.mMinFlingVelocity;
    }

    public long getNanoTime() {
        if (ALLOW_THREAD_GAP_WORK) {
            return System.nanoTime();
        }
        return 0;
    }

    public C0239r getOnFlingListener() {
        return this.mOnFlingListener;
    }

    public boolean getPreserveFocusAfterLayout() {
        return this.mPreserveFocusAfterLayout;
    }

    public C0242u getRecycledViewPool() {
        return this.mRecycler.mo1992b();
    }

    public int getScrollState() {
        return this.mScrollState;
    }

    public boolean hasFixedSize() {
        return this.mHasFixedSize;
    }

    public boolean hasNestedScrollingParent() {
        return getScrollingChildHelper().mo8625b(0);
    }

    public boolean hasPendingAdapterUpdates() {
        return !this.mFirstLayoutComplete || this.mDataSetHasChangedAfterLayout || this.mAdapterHelper.mo6912c();
    }

    public void initAdapterManager() {
        this.mAdapterHelper = new C0926ic(new C0220f());
    }

    public void initFastScroller(StateListDrawable stateListDrawable, Drawable drawable, StateListDrawable stateListDrawable2, Drawable drawable2) {
        if (stateListDrawable == null || drawable == null || stateListDrawable2 == null || drawable2 == null) {
            throw new IllegalArgumentException(C0789gk.m5554a(this, C0789gk.m5562a("Trying to set fast scroller without both required drawables.")));
        }
        Resources resources = getContext().getResources();
        new C1609pc(this, stateListDrawable, drawable, stateListDrawable2, drawable2, resources.getDimensionPixelSize(C0767gc.fastscroll_default_thickness), resources.getDimensionPixelSize(C0767gc.fastscroll_minimum_range), resources.getDimensionPixelOffset(C0767gc.fastscroll_margin));
    }

    public void invalidateGlows() {
        this.mBottomGlow = null;
        this.mTopGlow = null;
        this.mRightGlow = null;
        this.mLeftGlow = null;
    }

    public void invalidateItemDecorations() {
        if (this.mItemDecorations.size() != 0) {
            C0232o oVar = this.mLayout;
            if (oVar != null) {
                oVar.mo1562a("Cannot invalidate item decorations during a scroll or layout");
            }
            markItemDecorInsetsDirty();
            requestLayout();
        }
    }

    public boolean isAccessibilityEnabled() {
        AccessibilityManager accessibilityManager = this.mAccessibilityManager;
        return accessibilityManager != null && accessibilityManager.isEnabled();
    }

    public boolean isAnimating() {
        C0226l lVar = this.mItemAnimator;
        return lVar != null && lVar.mo1858d();
    }

    public boolean isAttachedToWindow() {
        return this.mIsAttached;
    }

    public boolean isComputingLayout() {
        return this.mLayoutOrScrollCounter > 0;
    }

    @Deprecated
    public boolean isLayoutFrozen() {
        return isLayoutSuppressed();
    }

    public final boolean isLayoutSuppressed() {
        return this.mLayoutSuppressed;
    }

    public boolean isNestedScrollingEnabled() {
        return getScrollingChildHelper().f10039d;
    }

    public void jumpToPositionForSmoothScroller(int i) {
        if (this.mLayout != null) {
            setScrollState(2);
            this.mLayout.mo1582m(i);
            awakenScrollBars();
        }
    }

    public void markItemDecorInsetsDirty() {
        int b = this.mChildHelper.mo7589b();
        for (int i = 0; i < b; i++) {
            ((C0237p) this.mChildHelper.mo7594d(i).getLayoutParams()).f1373Z = true;
        }
        C0244v vVar = this.mRecycler;
        int size = vVar.f1383c.size();
        for (int i2 = 0; i2 < size; i2++) {
            C0237p pVar = (C0237p) vVar.f1383c.get(i2).f1316X.getLayoutParams();
            if (pVar != null) {
                pVar.f1373Z = true;
            }
        }
    }

    public void markKnownViewsInvalid() {
        int b = this.mChildHelper.mo7589b();
        for (int i = 0; i < b; i++) {
            C0218d0 childViewHolderInt = getChildViewHolderInt(this.mChildHelper.mo7594d(i));
            if (childViewHolderInt != null && !childViewHolderInt.mo1821w()) {
                childViewHolderInt.mo1800a(6);
            }
        }
        markItemDecorInsetsDirty();
        C0244v vVar = this.mRecycler;
        int size = vVar.f1383c.size();
        for (int i2 = 0; i2 < size; i2++) {
            C0218d0 d0Var = vVar.f1383c.get(i2);
            if (d0Var != null) {
                d0Var.mo1800a(6);
                d0Var.mo1803a((Object) null);
            }
        }
        C0221g gVar = RecyclerView.this.mAdapter;
        if (gVar == null || !gVar.f1337b) {
            vVar.mo1995c();
        }
    }

    public void offsetChildrenHorizontal(int i) {
        int a = this.mChildHelper.mo7584a();
        for (int i2 = 0; i2 < a; i2++) {
            this.mChildHelper.mo7590b(i2).offsetLeftAndRight(i);
        }
    }

    public void offsetChildrenVertical(int i) {
        int a = this.mChildHelper.mo7584a();
        for (int i2 = 0; i2 < a; i2++) {
            this.mChildHelper.mo7590b(i2).offsetTopAndBottom(i);
        }
    }

    public void offsetPositionRecordsForInsert(int i, int i2) {
        int b = this.mChildHelper.mo7589b();
        for (int i3 = 0; i3 < b; i3++) {
            C0218d0 childViewHolderInt = getChildViewHolderInt(this.mChildHelper.mo7594d(i3));
            if (childViewHolderInt != null && !childViewHolderInt.mo1821w() && childViewHolderInt.f1318Z >= i) {
                childViewHolderInt.mo1802a(i2, false);
                this.mState.f1295g = true;
            }
        }
        C0244v vVar = this.mRecycler;
        int size = vVar.f1383c.size();
        for (int i4 = 0; i4 < size; i4++) {
            C0218d0 d0Var = vVar.f1383c.get(i4);
            if (d0Var != null && d0Var.f1318Z >= i) {
                d0Var.mo1802a(i2, true);
            }
        }
        requestLayout();
    }

    public void offsetPositionRecordsForMove(int i, int i2) {
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int b = this.mChildHelper.mo7589b();
        if (i < i2) {
            i5 = i;
            i4 = i2;
            i3 = -1;
        } else {
            i4 = i;
            i5 = i2;
            i3 = 1;
        }
        for (int i11 = 0; i11 < b; i11++) {
            C0218d0 childViewHolderInt = getChildViewHolderInt(this.mChildHelper.mo7594d(i11));
            if (childViewHolderInt != null && (i10 = childViewHolderInt.f1318Z) >= i5 && i10 <= i4) {
                if (i10 == i) {
                    childViewHolderInt.mo1802a(i2 - i, false);
                } else {
                    childViewHolderInt.mo1802a(i3, false);
                }
                this.mState.f1295g = true;
            }
        }
        C0244v vVar = this.mRecycler;
        if (i < i2) {
            i8 = i;
            i7 = i2;
            i6 = -1;
        } else {
            i7 = i;
            i8 = i2;
            i6 = 1;
        }
        int size = vVar.f1383c.size();
        for (int i12 = 0; i12 < size; i12++) {
            C0218d0 d0Var = vVar.f1383c.get(i12);
            if (d0Var != null && (i9 = d0Var.f1318Z) >= i8 && i9 <= i7) {
                if (i9 == i) {
                    d0Var.mo1802a(i2 - i, false);
                } else {
                    d0Var.mo1802a(i6, false);
                }
            }
        }
        requestLayout();
    }

    public void offsetPositionRecordsForRemove(int i, int i2, boolean z) {
        int i3 = i + i2;
        int b = this.mChildHelper.mo7589b();
        for (int i4 = 0; i4 < b; i4++) {
            C0218d0 childViewHolderInt = getChildViewHolderInt(this.mChildHelper.mo7594d(i4));
            if (childViewHolderInt != null && !childViewHolderInt.mo1821w()) {
                int i5 = childViewHolderInt.f1318Z;
                if (i5 >= i3) {
                    childViewHolderInt.mo1802a(-i2, z);
                } else if (i5 >= i) {
                    childViewHolderInt.mo1800a(8);
                    childViewHolderInt.mo1802a(-i2, z);
                    childViewHolderInt.f1318Z = i - 1;
                }
                this.mState.f1295g = true;
            }
        }
        C0244v vVar = this.mRecycler;
        int size = vVar.f1383c.size();
        while (true) {
            size--;
            if (size >= 0) {
                C0218d0 d0Var = vVar.f1383c.get(size);
                if (d0Var != null) {
                    int i6 = d0Var.f1318Z;
                    if (i6 >= i3) {
                        d0Var.mo1802a(-i2, z);
                    } else if (i6 >= i) {
                        d0Var.mo1800a(8);
                        vVar.mo1996c(size);
                    }
                }
            } else {
                requestLayout();
                return;
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:16:0x004f, code lost:
        if (r0 >= 30.0f) goto L_0x0054;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onAttachedToWindow() {
        /*
            r4 = this;
            super.onAttachedToWindow()
            r0 = 0
            r4.mLayoutOrScrollCounter = r0
            r1 = 1
            r4.mIsAttached = r1
            boolean r2 = r4.mFirstLayoutComplete
            if (r2 == 0) goto L_0x0014
            boolean r2 = r4.isLayoutRequested()
            if (r2 != 0) goto L_0x0014
            goto L_0x0015
        L_0x0014:
            r1 = 0
        L_0x0015:
            r4.mFirstLayoutComplete = r1
            androidx.recyclerview.widget.RecyclerView$o r1 = r4.mLayout
            if (r1 == 0) goto L_0x001e
            r1.mo1885a((androidx.recyclerview.widget.RecyclerView) r4)
        L_0x001e:
            r4.mPostedAnimatorRunner = r0
            boolean r0 = ALLOW_THREAD_GAP_WORK
            if (r0 == 0) goto L_0x0069
            java.lang.ThreadLocal<qc> r0 = p000.C1692qc.f12984b0
            java.lang.Object r0 = r0.get()
            qc r0 = (p000.C1692qc) r0
            r4.mGapWorker = r0
            qc r0 = r4.mGapWorker
            if (r0 != 0) goto L_0x0062
            qc r0 = new qc
            r0.<init>()
            r4.mGapWorker = r0
            android.view.Display r0 = p000.C2189w7.m15012h(r4)
            r1 = 1114636288(0x42700000, float:60.0)
            boolean r2 = r4.isInEditMode()
            if (r2 != 0) goto L_0x0052
            if (r0 == 0) goto L_0x0052
            float r0 = r0.getRefreshRate()
            r2 = 1106247680(0x41f00000, float:30.0)
            int r2 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r2 < 0) goto L_0x0052
            goto L_0x0054
        L_0x0052:
            r0 = 1114636288(0x42700000, float:60.0)
        L_0x0054:
            qc r1 = r4.mGapWorker
            r2 = 1315859240(0x4e6e6b28, float:1.0E9)
            float r2 = r2 / r0
            long r2 = (long) r2
            r1.f12988Z = r2
            java.lang.ThreadLocal<qc> r0 = p000.C1692qc.f12984b0
            r0.set(r1)
        L_0x0062:
            qc r0 = r4.mGapWorker
            java.util.ArrayList<androidx.recyclerview.widget.RecyclerView> r0 = r0.f12986X
            r0.add(r4)
        L_0x0069:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.onAttachedToWindow():void");
    }

    public void onChildAttachedToWindow(View view) {
    }

    public void onChildDetachedFromWindow(View view) {
    }

    public void onDetachedFromWindow() {
        C1692qc qcVar;
        super.onDetachedFromWindow();
        C0226l lVar = this.mItemAnimator;
        if (lVar != null) {
            lVar.mo1856b();
        }
        stopScroll();
        this.mIsAttached = false;
        C0232o oVar = this.mLayout;
        if (oVar != null) {
            oVar.mo1886a(this, this.mRecycler);
        }
        this.mPendingAccessibilityImportanceChange.clear();
        removeCallbacks(this.mItemAnimatorRunner);
        this.mViewInfoStore.mo5092a();
        if (ALLOW_THREAD_GAP_WORK && (qcVar = this.mGapWorker) != null) {
            qcVar.f12986X.remove(this);
            this.mGapWorker = null;
        }
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int size = this.mItemDecorations.size();
        for (int i = 0; i < size; i++) {
            this.mItemDecorations.get(i).mo1862a(canvas, this, this.mState);
        }
    }

    public void onEnterLayoutOrScroll() {
        this.mLayoutOrScrollCounter++;
    }

    public void onExitLayoutOrScroll() {
        onExitLayoutOrScroll(true);
    }

    public void onExitLayoutOrScroll(boolean z) {
        this.mLayoutOrScrollCounter--;
        if (this.mLayoutOrScrollCounter < 1) {
            this.mLayoutOrScrollCounter = 0;
            if (z) {
                dispatchContentChangedIfNecessary();
                dispatchPendingImportantForAccessibilityChanges();
            }
        }
    }

    public boolean onGenericMotionEvent(MotionEvent motionEvent) {
        float f;
        float f2;
        if (this.mLayout != null && !this.mLayoutSuppressed && motionEvent.getAction() == 8) {
            if ((motionEvent.getSource() & 2) != 0) {
                f2 = this.mLayout.mo1570c() ? -motionEvent.getAxisValue(9) : 0.0f;
                if (this.mLayout.mo1567b()) {
                    f = motionEvent.getAxisValue(10);
                    if (!(f2 == 0.0f && f == 0.0f)) {
                        scrollByInternal((int) (f * this.mScaledHorizontalScrollFactor), (int) (f2 * this.mScaledVerticalScrollFactor), motionEvent);
                    }
                }
            } else {
                if ((motionEvent.getSource() & 4194304) != 0) {
                    float axisValue = motionEvent.getAxisValue(26);
                    if (this.mLayout.mo1570c()) {
                        f2 = -axisValue;
                    } else if (this.mLayout.mo1567b()) {
                        f = axisValue;
                        f2 = 0.0f;
                        scrollByInternal((int) (f * this.mScaledHorizontalScrollFactor), (int) (f2 * this.mScaledVerticalScrollFactor), motionEvent);
                    }
                }
                f2 = 0.0f;
            }
            f = 0.0f;
            scrollByInternal((int) (f * this.mScaledHorizontalScrollFactor), (int) (f2 * this.mScaledVerticalScrollFactor), motionEvent);
        }
        return false;
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z;
        if (this.mLayoutSuppressed) {
            return false;
        }
        this.mInterceptingOnItemTouchListener = null;
        if (findInterceptingOnItemTouchListener(motionEvent)) {
            cancelScroll();
            return true;
        }
        C0232o oVar = this.mLayout;
        if (oVar == null) {
            return false;
        }
        boolean b = oVar.mo1567b();
        boolean c = this.mLayout.mo1570c();
        if (this.mVelocityTracker == null) {
            this.mVelocityTracker = VelocityTracker.obtain();
        }
        this.mVelocityTracker.addMovement(motionEvent);
        int actionMasked = motionEvent.getActionMasked();
        int actionIndex = motionEvent.getActionIndex();
        if (actionMasked == 0) {
            if (this.mIgnoreMotionEventTillDown) {
                this.mIgnoreMotionEventTillDown = false;
            }
            this.mScrollPointerId = motionEvent.getPointerId(0);
            int x = (int) (motionEvent.getX() + 0.5f);
            this.mLastTouchX = x;
            this.mInitialTouchX = x;
            int y = (int) (motionEvent.getY() + 0.5f);
            this.mLastTouchY = y;
            this.mInitialTouchY = y;
            if (this.mScrollState == 2) {
                getParent().requestDisallowInterceptTouchEvent(true);
                setScrollState(1);
                stopNestedScroll(1);
            }
            int[] iArr = this.mNestedOffsets;
            iArr[1] = 0;
            iArr[0] = 0;
            int i = b ? 1 : 0;
            if (c) {
                i |= 2;
            }
            startNestedScroll(i, 0);
        } else if (actionMasked == 1) {
            this.mVelocityTracker.clear();
            stopNestedScroll(0);
        } else if (actionMasked == 2) {
            int findPointerIndex = motionEvent.findPointerIndex(this.mScrollPointerId);
            if (findPointerIndex < 0) {
                StringBuilder a = C0789gk.m5562a("Error processing scroll; pointer index for id ");
                a.append(this.mScrollPointerId);
                a.append(" not found. Did any MotionEvents get skipped?");
                Log.e(TAG, a.toString());
                return false;
            }
            int x2 = (int) (motionEvent.getX(findPointerIndex) + 0.5f);
            int y2 = (int) (motionEvent.getY(findPointerIndex) + 0.5f);
            if (this.mScrollState != 1) {
                int i2 = x2 - this.mInitialTouchX;
                int i3 = y2 - this.mInitialTouchY;
                if (!b || Math.abs(i2) <= this.mTouchSlop) {
                    z = false;
                } else {
                    this.mLastTouchX = x2;
                    z = true;
                }
                if (c && Math.abs(i3) > this.mTouchSlop) {
                    this.mLastTouchY = y2;
                    z = true;
                }
                if (z) {
                    setScrollState(1);
                }
            }
        } else if (actionMasked == 3) {
            cancelScroll();
        } else if (actionMasked == 5) {
            this.mScrollPointerId = motionEvent.getPointerId(actionIndex);
            int x3 = (int) (motionEvent.getX(actionIndex) + 0.5f);
            this.mLastTouchX = x3;
            this.mInitialTouchX = x3;
            int y3 = (int) (motionEvent.getY(actionIndex) + 0.5f);
            this.mLastTouchY = y3;
            this.mInitialTouchY = y3;
        } else if (actionMasked == 6) {
            onPointerUp(motionEvent);
        }
        return this.mScrollState == 1;
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5 = Build.VERSION.SDK_INT;
        Trace.beginSection(TRACE_ON_LAYOUT_TAG);
        dispatchLayout();
        int i6 = Build.VERSION.SDK_INT;
        Trace.endSection();
        this.mFirstLayoutComplete = true;
    }

    public void onMeasure(int i, int i2) {
        C0232o oVar = this.mLayout;
        if (oVar == null) {
            defaultOnMeasure(i, i2);
            return;
        }
        boolean z = false;
        if (oVar.mo1585t()) {
            int mode = View.MeasureSpec.getMode(i);
            int mode2 = View.MeasureSpec.getMode(i2);
            this.mLayout.mo1897b(i, i2);
            if (mode == 1073741824 && mode2 == 1073741824) {
                z = true;
            }
            if (!z && this.mAdapter != null) {
                if (this.mState.f1293e == 1) {
                    dispatchLayoutStep1();
                }
                this.mLayout.mo1907c(i, i2);
                this.mState.f1298j = true;
                dispatchLayoutStep2();
                this.mLayout.mo1919e(i, i2);
                if (this.mLayout.mo1534G()) {
                    this.mLayout.mo1907c(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824));
                    this.mState.f1298j = true;
                    dispatchLayoutStep2();
                    this.mLayout.mo1919e(i, i2);
                }
            }
        } else if (this.mHasFixedSize) {
            this.mLayout.mo1897b(i, i2);
        } else {
            if (this.mAdapterUpdateDuringMeasure) {
                startInterceptRequestLayout();
                onEnterLayoutOrScroll();
                processAdapterUpdatesAndSetAnimationFlags();
                onExitLayoutOrScroll();
                C0212a0 a0Var = this.mState;
                if (a0Var.f1300l) {
                    a0Var.f1296h = true;
                } else {
                    this.mAdapterHelper.mo6908b();
                    this.mState.f1296h = false;
                }
                this.mAdapterUpdateDuringMeasure = false;
                stopInterceptRequestLayout(false);
            } else if (this.mState.f1300l) {
                setMeasuredDimension(getMeasuredWidth(), getMeasuredHeight());
                return;
            }
            C0221g gVar = this.mAdapter;
            if (gVar != null) {
                this.mState.f1294f = gVar.mo1833a();
            } else {
                this.mState.f1294f = 0;
            }
            startInterceptRequestLayout();
            this.mLayout.mo1897b(i, i2);
            stopInterceptRequestLayout(false);
            this.mState.f1296h = false;
        }
    }

    public boolean onRequestFocusInDescendants(int i, Rect rect) {
        if (isComputingLayout()) {
            return false;
        }
        return super.onRequestFocusInDescendants(i, rect);
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        Parcelable parcelable2;
        if (!(parcelable instanceof C0247y)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        this.mPendingSavedState = (C0247y) parcelable;
        super.onRestoreInstanceState(this.mPendingSavedState.f14707X);
        C0232o oVar = this.mLayout;
        if (oVar != null && (parcelable2 = this.mPendingSavedState.f1390Z) != null) {
            oVar.mo1556a(parcelable2);
        }
    }

    public Parcelable onSaveInstanceState() {
        C0247y yVar = new C0247y(super.onSaveInstanceState());
        C0247y yVar2 = this.mPendingSavedState;
        if (yVar2 != null) {
            yVar.f1390Z = yVar2.f1390Z;
        } else {
            C0232o oVar = this.mLayout;
            yVar.f1390Z = oVar != null ? oVar.mo1533B() : null;
        }
        return yVar;
    }

    public void onScrollStateChanged(int i) {
    }

    public void onScrolled(int i, int i2) {
    }

    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        if (i != i3 || i2 != i4) {
            invalidateGlows();
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:46:0x00dc  */
    /* JADX WARNING: Removed duplicated region for block: B:53:0x00f0  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r18) {
        /*
            r17 = this;
            r6 = r17
            r7 = r18
            boolean r0 = r6.mLayoutSuppressed
            r8 = 0
            if (r0 != 0) goto L_0x01e2
            boolean r0 = r6.mIgnoreMotionEventTillDown
            if (r0 == 0) goto L_0x000f
            goto L_0x01e2
        L_0x000f:
            boolean r0 = r17.dispatchToOnItemTouchListeners(r18)
            r9 = 1
            if (r0 == 0) goto L_0x001a
            r17.cancelScroll()
            return r9
        L_0x001a:
            androidx.recyclerview.widget.RecyclerView$o r0 = r6.mLayout
            if (r0 != 0) goto L_0x001f
            return r8
        L_0x001f:
            boolean r10 = r0.mo1567b()
            androidx.recyclerview.widget.RecyclerView$o r0 = r6.mLayout
            boolean r11 = r0.mo1570c()
            android.view.VelocityTracker r0 = r6.mVelocityTracker
            if (r0 != 0) goto L_0x0033
            android.view.VelocityTracker r0 = android.view.VelocityTracker.obtain()
            r6.mVelocityTracker = r0
        L_0x0033:
            int r0 = r18.getActionMasked()
            int r1 = r18.getActionIndex()
            if (r0 != 0) goto L_0x0043
            int[] r2 = r6.mNestedOffsets
            r2[r9] = r8
            r2[r8] = r8
        L_0x0043:
            android.view.MotionEvent r12 = android.view.MotionEvent.obtain(r18)
            int[] r2 = r6.mNestedOffsets
            r3 = r2[r8]
            float r3 = (float) r3
            r2 = r2[r9]
            float r2 = (float) r2
            r12.offsetLocation(r3, r2)
            r2 = 1056964608(0x3f000000, float:0.5)
            if (r0 == 0) goto L_0x01b1
            if (r0 == r9) goto L_0x016f
            r3 = 2
            if (r0 == r3) goto L_0x008c
            r3 = 3
            if (r0 == r3) goto L_0x0087
            r3 = 5
            if (r0 == r3) goto L_0x006b
            r1 = 6
            if (r0 == r1) goto L_0x0066
            goto L_0x01d7
        L_0x0066:
            r17.onPointerUp(r18)
            goto L_0x01d7
        L_0x006b:
            int r0 = r7.getPointerId(r1)
            r6.mScrollPointerId = r0
            float r0 = r7.getX(r1)
            float r0 = r0 + r2
            int r0 = (int) r0
            r6.mLastTouchX = r0
            r6.mInitialTouchX = r0
            float r0 = r7.getY(r1)
            float r0 = r0 + r2
            int r0 = (int) r0
            r6.mLastTouchY = r0
            r6.mInitialTouchY = r0
            goto L_0x01d7
        L_0x0087:
            r17.cancelScroll()
            goto L_0x01d7
        L_0x008c:
            int r0 = r6.mScrollPointerId
            int r0 = r7.findPointerIndex(r0)
            if (r0 >= 0) goto L_0x00ae
            java.lang.String r0 = "Error processing scroll; pointer index for id "
            java.lang.StringBuilder r0 = p000.C0789gk.m5562a((java.lang.String) r0)
            int r1 = r6.mScrollPointerId
            r0.append(r1)
            java.lang.String r1 = " not found. Did any MotionEvents get skipped?"
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            java.lang.String r1 = "RecyclerView"
            android.util.Log.e(r1, r0)
            return r8
        L_0x00ae:
            float r1 = r7.getX(r0)
            float r1 = r1 + r2
            int r13 = (int) r1
            float r0 = r7.getY(r0)
            float r0 = r0 + r2
            int r14 = (int) r0
            int r0 = r6.mLastTouchX
            int r0 = r0 - r13
            int r1 = r6.mLastTouchY
            int r1 = r1 - r14
            int r2 = r6.mScrollState
            if (r2 == r9) goto L_0x00f3
            if (r10 == 0) goto L_0x00d9
            int r2 = r6.mTouchSlop
            if (r0 <= 0) goto L_0x00d0
            int r0 = r0 - r2
            int r0 = java.lang.Math.max(r8, r0)
            goto L_0x00d5
        L_0x00d0:
            int r0 = r0 + r2
            int r0 = java.lang.Math.min(r8, r0)
        L_0x00d5:
            if (r0 == 0) goto L_0x00d9
            r2 = 1
            goto L_0x00da
        L_0x00d9:
            r2 = 0
        L_0x00da:
            if (r11 == 0) goto L_0x00ee
            int r3 = r6.mTouchSlop
            if (r1 <= 0) goto L_0x00e6
            int r1 = r1 - r3
            int r1 = java.lang.Math.max(r8, r1)
            goto L_0x00eb
        L_0x00e6:
            int r1 = r1 + r3
            int r1 = java.lang.Math.min(r8, r1)
        L_0x00eb:
            if (r1 == 0) goto L_0x00ee
            r2 = 1
        L_0x00ee:
            if (r2 == 0) goto L_0x00f3
            r6.setScrollState(r9)
        L_0x00f3:
            r15 = r0
            r16 = r1
            int r0 = r6.mScrollState
            if (r0 != r9) goto L_0x01d7
            int[] r0 = r6.mReusableIntPair
            r0[r8] = r8
            r0[r9] = r8
            if (r10 == 0) goto L_0x0104
            r1 = r15
            goto L_0x0106
        L_0x0104:
            r0 = 0
            r1 = 0
        L_0x0106:
            if (r11 == 0) goto L_0x010b
            r2 = r16
            goto L_0x010d
        L_0x010b:
            r0 = 0
            r2 = 0
        L_0x010d:
            int[] r3 = r6.mReusableIntPair
            int[] r4 = r6.mScrollOffset
            r5 = 0
            r0 = r17
            boolean r0 = r0.dispatchNestedPreScroll(r1, r2, r3, r4, r5)
            if (r0 == 0) goto L_0x013c
            int[] r0 = r6.mReusableIntPair
            r1 = r0[r8]
            int r15 = r15 - r1
            r0 = r0[r9]
            int r16 = r16 - r0
            int[] r0 = r6.mNestedOffsets
            r1 = r0[r8]
            int[] r2 = r6.mScrollOffset
            r3 = r2[r8]
            int r1 = r1 + r3
            r0[r8] = r1
            r1 = r0[r9]
            r2 = r2[r9]
            int r1 = r1 + r2
            r0[r9] = r1
            android.view.ViewParent r0 = r17.getParent()
            r0.requestDisallowInterceptTouchEvent(r9)
        L_0x013c:
            r0 = r16
            int[] r1 = r6.mScrollOffset
            r2 = r1[r8]
            int r13 = r13 - r2
            r6.mLastTouchX = r13
            r1 = r1[r9]
            int r14 = r14 - r1
            r6.mLastTouchY = r14
            if (r10 == 0) goto L_0x014e
            r1 = r15
            goto L_0x014f
        L_0x014e:
            r1 = 0
        L_0x014f:
            if (r11 == 0) goto L_0x0153
            r2 = r0
            goto L_0x0154
        L_0x0153:
            r2 = 0
        L_0x0154:
            boolean r1 = r6.scrollByInternal(r1, r2, r7)
            if (r1 == 0) goto L_0x0161
            android.view.ViewParent r1 = r17.getParent()
            r1.requestDisallowInterceptTouchEvent(r9)
        L_0x0161:
            qc r1 = r6.mGapWorker
            if (r1 == 0) goto L_0x01d7
            if (r15 != 0) goto L_0x0169
            if (r0 == 0) goto L_0x01d7
        L_0x0169:
            qc r1 = r6.mGapWorker
            r1.mo10306a((androidx.recyclerview.widget.RecyclerView) r6, (int) r15, (int) r0)
            goto L_0x01d7
        L_0x016f:
            android.view.VelocityTracker r0 = r6.mVelocityTracker
            r0.addMovement(r12)
            android.view.VelocityTracker r0 = r6.mVelocityTracker
            r1 = 1000(0x3e8, float:1.401E-42)
            int r2 = r6.mMaxFlingVelocity
            float r2 = (float) r2
            r0.computeCurrentVelocity(r1, r2)
            r0 = 0
            if (r10 == 0) goto L_0x018b
            android.view.VelocityTracker r1 = r6.mVelocityTracker
            int r2 = r6.mScrollPointerId
            float r1 = r1.getXVelocity(r2)
            float r1 = -r1
            goto L_0x018c
        L_0x018b:
            r1 = 0
        L_0x018c:
            if (r11 == 0) goto L_0x0198
            android.view.VelocityTracker r2 = r6.mVelocityTracker
            int r3 = r6.mScrollPointerId
            float r2 = r2.getYVelocity(r3)
            float r2 = -r2
            goto L_0x0199
        L_0x0198:
            r2 = 0
        L_0x0199:
            int r3 = (r1 > r0 ? 1 : (r1 == r0 ? 0 : -1))
            if (r3 != 0) goto L_0x01a1
            int r0 = (r2 > r0 ? 1 : (r2 == r0 ? 0 : -1))
            if (r0 == 0) goto L_0x01a9
        L_0x01a1:
            int r0 = (int) r1
            int r1 = (int) r2
            boolean r0 = r6.fling(r0, r1)
            if (r0 != 0) goto L_0x01ac
        L_0x01a9:
            r6.setScrollState(r8)
        L_0x01ac:
            r17.resetScroll()
            r8 = 1
            goto L_0x01d7
        L_0x01b1:
            int r0 = r7.getPointerId(r8)
            r6.mScrollPointerId = r0
            float r0 = r18.getX()
            float r0 = r0 + r2
            int r0 = (int) r0
            r6.mLastTouchX = r0
            r6.mInitialTouchX = r0
            float r0 = r18.getY()
            float r0 = r0 + r2
            int r0 = (int) r0
            r6.mLastTouchY = r0
            r6.mInitialTouchY = r0
            if (r10 == 0) goto L_0x01cf
            r0 = 1
            goto L_0x01d0
        L_0x01cf:
            r0 = 0
        L_0x01d0:
            if (r11 == 0) goto L_0x01d4
            r0 = r0 | 2
        L_0x01d4:
            r6.startNestedScroll(r0, r8)
        L_0x01d7:
            if (r8 != 0) goto L_0x01de
            android.view.VelocityTracker r0 = r6.mVelocityTracker
            r0.addMovement(r12)
        L_0x01de:
            r12.recycle()
            return r9
        L_0x01e2:
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.onTouchEvent(android.view.MotionEvent):boolean");
    }

    public void postAnimationRunner() {
        if (!this.mPostedAnimatorRunner && this.mIsAttached) {
            C2189w7.m14991a((View) this, this.mItemAnimatorRunner);
            this.mPostedAnimatorRunner = true;
        }
    }

    public void processDataSetCompletelyChanged(boolean z) {
        this.mDispatchItemsChangedEvent = z | this.mDispatchItemsChangedEvent;
        this.mDataSetHasChangedAfterLayout = true;
        markKnownViewsInvalid();
    }

    public void recordAnimationInfoIfBouncedHiddenView(C0218d0 d0Var, C0226l.C0229c cVar) {
        d0Var.mo1801a(0, 8192);
        if (this.mState.f1297i && d0Var.mo1819u() && !d0Var.mo1815r() && !d0Var.mo1821w()) {
            this.mViewInfoStore.f4406b.mo4668c(getChangedHolderKey(d0Var), d0Var);
        }
        this.mViewInfoStore.mo5095b(d0Var, cVar);
    }

    public void removeAndRecycleViews() {
        C0226l lVar = this.mItemAnimator;
        if (lVar != null) {
            lVar.mo1856b();
        }
        C0232o oVar = this.mLayout;
        if (oVar != null) {
            oVar.mo1903b(this.mRecycler);
            this.mLayout.mo1910c(this.mRecycler);
        }
        this.mRecycler.mo1985a();
    }

    public boolean removeAnimatingView(View view) {
        startInterceptRequestLayout();
        C1050jc jcVar = this.mChildHelper;
        int indexOfChild = RecyclerView.this.indexOfChild(view);
        boolean z = true;
        if (indexOfChild == -1) {
            jcVar.mo7593c(view);
        } else if (jcVar.f8344b.mo7602c(indexOfChild)) {
            jcVar.f8344b.mo7603d(indexOfChild);
            jcVar.mo7593c(view);
            ((C0219e) jcVar.f8343a).mo1827b(indexOfChild);
        } else {
            z = false;
        }
        if (z) {
            C0218d0 childViewHolderInt = getChildViewHolderInt(view);
            this.mRecycler.mo1994b(childViewHolderInt);
            this.mRecycler.mo1989a(childViewHolderInt);
        }
        stopInterceptRequestLayout(!z);
        return z;
    }

    public void removeDetachedView(View view, boolean z) {
        C0218d0 childViewHolderInt = getChildViewHolderInt(view);
        if (childViewHolderInt != null) {
            if (childViewHolderInt.mo1817t()) {
                childViewHolderInt.f1325g0 &= -257;
            } else if (!childViewHolderInt.mo1821w()) {
                StringBuilder sb = new StringBuilder();
                sb.append("Called removeDetachedView with a view which is not flagged as tmp detached.");
                sb.append(childViewHolderInt);
                throw new IllegalArgumentException(C0789gk.m5554a(this, sb));
            }
        }
        view.clearAnimation();
        dispatchChildDetached(view);
        super.removeDetachedView(view, z);
    }

    public void removeItemDecoration(C0231n nVar) {
        C0232o oVar = this.mLayout;
        if (oVar != null) {
            oVar.mo1562a("Cannot remove item decoration during a scroll  or layout");
        }
        this.mItemDecorations.remove(nVar);
        if (this.mItemDecorations.isEmpty()) {
            setWillNotDraw(getOverScrollMode() == 2);
        }
        markItemDecorInsetsDirty();
        requestLayout();
    }

    public void removeItemDecorationAt(int i) {
        int itemDecorationCount = getItemDecorationCount();
        if (i < 0 || i >= itemDecorationCount) {
            throw new IndexOutOfBoundsException(i + " is an invalid index for size " + itemDecorationCount);
        }
        removeItemDecoration(getItemDecorationAt(i));
    }

    public void removeOnChildAttachStateChangeListener(C0238q qVar) {
        List<C0238q> list = this.mOnChildAttachStateListeners;
        if (list != null) {
            list.remove(qVar);
        }
    }

    public void removeOnItemTouchListener(C0240s sVar) {
        this.mOnItemTouchListeners.remove(sVar);
        if (this.mInterceptingOnItemTouchListener == sVar) {
            this.mInterceptingOnItemTouchListener = null;
        }
    }

    public void removeOnScrollListener(C0241t tVar) {
        List<C0241t> list = this.mScrollListeners;
        if (list != null) {
            list.remove(tVar);
        }
    }

    public void repositionShadowingViews() {
        C0218d0 d0Var;
        int a = this.mChildHelper.mo7584a();
        for (int i = 0; i < a; i++) {
            View b = this.mChildHelper.mo7590b(i);
            C0218d0 childViewHolder = getChildViewHolder(b);
            if (!(childViewHolder == null || (d0Var = childViewHolder.f1324f0) == null)) {
                View view = d0Var.f1316X;
                int left = b.getLeft();
                int top = b.getTop();
                if (left != view.getLeft() || top != view.getTop()) {
                    view.layout(left, top, view.getWidth() + left, view.getHeight() + top);
                }
            }
        }
    }

    public void requestChildFocus(View view, View view2) {
        if (!this.mLayout.mo1895a(this, view, view2) && view2 != null) {
            requestChildOnScreen(view, view2);
        }
        super.requestChildFocus(view, view2);
    }

    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        return this.mLayout.mo1893a(this, view, rect, z);
    }

    public void requestDisallowInterceptTouchEvent(boolean z) {
        int size = this.mOnItemTouchListeners.size();
        for (int i = 0; i < size; i++) {
            ((C1609pc) this.mOnItemTouchListeners.get(i)).mo9950a(z);
        }
        super.requestDisallowInterceptTouchEvent(z);
    }

    public void requestLayout() {
        if (this.mInterceptRequestLayoutDepth != 0 || this.mLayoutSuppressed) {
            this.mLayoutWasDefered = true;
        } else {
            super.requestLayout();
        }
    }

    public void saveOldPositions() {
        int b = this.mChildHelper.mo7589b();
        for (int i = 0; i < b; i++) {
            C0218d0 childViewHolderInt = getChildViewHolderInt(this.mChildHelper.mo7594d(i));
            if (!childViewHolderInt.mo1821w() && childViewHolderInt.f1319a0 == -1) {
                childViewHolderInt.f1319a0 = childViewHolderInt.f1318Z;
            }
        }
    }

    public void scrollBy(int i, int i2) {
        C0232o oVar = this.mLayout;
        if (oVar == null) {
            Log.e(TAG, "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
        } else if (!this.mLayoutSuppressed) {
            boolean b = oVar.mo1567b();
            boolean c = this.mLayout.mo1570c();
            if (b || c) {
                if (!b) {
                    i = 0;
                }
                if (!c) {
                    i2 = 0;
                }
                scrollByInternal(i, i2, (MotionEvent) null);
            }
        }
    }

    public boolean scrollByInternal(int i, int i2, MotionEvent motionEvent) {
        int i3;
        int i4;
        int i5;
        int i6;
        int i7 = i;
        int i8 = i2;
        consumePendingUpdateOperations();
        if (this.mAdapter != null) {
            int[] iArr = this.mReusableIntPair;
            iArr[0] = 0;
            iArr[1] = 0;
            scrollStep(i7, i8, iArr);
            int[] iArr2 = this.mReusableIntPair;
            int i9 = iArr2[0];
            int i10 = iArr2[1];
            i5 = i10;
            i6 = i9;
            i4 = i7 - i9;
            i3 = i8 - i10;
        } else {
            i6 = 0;
            i5 = 0;
            i4 = 0;
            i3 = 0;
        }
        if (!this.mItemDecorations.isEmpty()) {
            invalidate();
        }
        int[] iArr3 = this.mReusableIntPair;
        iArr3[0] = 0;
        iArr3[1] = 0;
        int i11 = i6;
        dispatchNestedScroll(i6, i5, i4, i3, this.mScrollOffset, 0, iArr3);
        int[] iArr4 = this.mReusableIntPair;
        int i12 = i4 - iArr4[0];
        int i13 = i3 - iArr4[1];
        boolean z = (iArr4[0] == 0 && iArr4[1] == 0) ? false : true;
        int i14 = this.mLastTouchX;
        int[] iArr5 = this.mScrollOffset;
        this.mLastTouchX = i14 - iArr5[0];
        this.mLastTouchY -= iArr5[1];
        int[] iArr6 = this.mNestedOffsets;
        iArr6[0] = iArr6[0] + iArr5[0];
        iArr6[1] = iArr6[1] + iArr5[1];
        if (getOverScrollMode() != 2) {
            if (motionEvent != null) {
                if (!((motionEvent.getSource() & 8194) == 8194)) {
                    pullGlows(motionEvent.getX(), (float) i12, motionEvent.getY(), (float) i13);
                }
            }
            considerReleasingGlowsOnScroll(i, i2);
        }
        int i15 = i11;
        if (!(i15 == 0 && i5 == 0)) {
            dispatchOnScrolled(i15, i5);
        }
        if (!awakenScrollBars()) {
            invalidate();
        }
        if (!z && i15 == 0 && i5 == 0) {
            return false;
        }
        return true;
    }

    public void scrollStep(int i, int i2, int[] iArr) {
        startInterceptRequestLayout();
        onEnterLayoutOrScroll();
        int i3 = Build.VERSION.SDK_INT;
        Trace.beginSection(TRACE_SCROLL_TAG);
        fillRemainingScrollValues(this.mState);
        int a = i != 0 ? this.mLayout.mo1492a(i, this.mRecycler, this.mState) : 0;
        int b = i2 != 0 ? this.mLayout.mo1509b(i2, this.mRecycler, this.mState) : 0;
        int i4 = Build.VERSION.SDK_INT;
        Trace.endSection();
        repositionShadowingViews();
        onExitLayoutOrScroll();
        stopInterceptRequestLayout(false);
        if (iArr != null) {
            iArr[0] = a;
            iArr[1] = b;
        }
    }

    public void scrollTo(int i, int i2) {
        Log.w(TAG, "RecyclerView does not support scrolling to an absolute position. Use scrollToPosition instead");
    }

    public void scrollToPosition(int i) {
        if (!this.mLayoutSuppressed) {
            stopScroll();
            C0232o oVar = this.mLayout;
            if (oVar == null) {
                Log.e(TAG, "Cannot scroll to position a LayoutManager set. Call setLayoutManager with a non-null argument.");
                return;
            }
            oVar.mo1582m(i);
            awakenScrollBars();
        }
    }

    public void sendAccessibilityEventUnchecked(AccessibilityEvent accessibilityEvent) {
        if (!shouldDeferAccessibilityEvent(accessibilityEvent)) {
            super.sendAccessibilityEventUnchecked(accessibilityEvent);
        }
    }

    public void setAccessibilityDelegateCompat(C2435zc zcVar) {
        this.mAccessibilityDelegate = zcVar;
        C2189w7.m14988a((View) this, (C0757g7) this.mAccessibilityDelegate);
    }

    public void setAdapter(C0221g gVar) {
        setLayoutFrozen(false);
        setAdapterInternal(gVar, false, true);
        processDataSetCompletelyChanged(false);
        requestLayout();
    }

    public void setChildDrawingOrderCallback(C0224j jVar) {
        if (jVar != null) {
            setChildrenDrawingOrderEnabled(false);
        }
    }

    public boolean setChildImportantForAccessibilityInternal(C0218d0 d0Var, int i) {
        if (isComputingLayout()) {
            d0Var.f1332n0 = i;
            this.mPendingAccessibilityImportanceChange.add(d0Var);
            return false;
        }
        C2189w7.m15013h(d0Var.f1316X, i);
        return true;
    }

    public void setClipToPadding(boolean z) {
        if (z != this.mClipToPadding) {
            invalidateGlows();
        }
        this.mClipToPadding = z;
        super.setClipToPadding(z);
        if (this.mFirstLayoutComplete) {
            requestLayout();
        }
    }

    public void setEdgeEffectFactory(C0225k kVar) {
        if (kVar != null) {
            this.mEdgeEffectFactory = kVar;
            invalidateGlows();
            return;
        }
        throw new NullPointerException();
    }

    public void setHasFixedSize(boolean z) {
        this.mHasFixedSize = z;
    }

    public void setItemAnimator(C0226l lVar) {
        C0226l lVar2 = this.mItemAnimator;
        if (lVar2 != null) {
            lVar2.mo1856b();
            this.mItemAnimator.f1338a = null;
        }
        this.mItemAnimator = lVar;
        C0226l lVar3 = this.mItemAnimator;
        if (lVar3 != null) {
            lVar3.f1338a = this.mItemAnimatorListener;
        }
    }

    public void setItemViewCacheSize(int i) {
        C0244v vVar = this.mRecycler;
        vVar.f1385e = i;
        vVar.mo1997d();
    }

    @Deprecated
    public void setLayoutFrozen(boolean z) {
        suppressLayout(z);
    }

    public void setLayoutManager(C0232o oVar) {
        if (oVar != this.mLayout) {
            stopScroll();
            if (this.mLayout != null) {
                C0226l lVar = this.mItemAnimator;
                if (lVar != null) {
                    lVar.mo1856b();
                }
                this.mLayout.mo1903b(this.mRecycler);
                this.mLayout.mo1910c(this.mRecycler);
                this.mRecycler.mo1985a();
                if (this.mIsAttached) {
                    this.mLayout.mo1886a(this, this.mRecycler);
                }
                this.mLayout.mo1923f((RecyclerView) null);
                this.mLayout = null;
            } else {
                this.mRecycler.mo1985a();
            }
            C1050jc jcVar = this.mChildHelper;
            jcVar.f8344b.mo7601b();
            int size = jcVar.f8345c.size();
            while (true) {
                size--;
                if (size < 0) {
                    break;
                }
                ((C0219e) jcVar.f8343a).mo1829c(jcVar.f8345c.get(size));
                jcVar.f8345c.remove(size);
            }
            C0219e eVar = (C0219e) jcVar.f8343a;
            int a = eVar.mo1823a();
            for (int i = 0; i < a; i++) {
                View a2 = eVar.mo1824a(i);
                RecyclerView.this.dispatchChildDetached(a2);
                a2.clearAnimation();
            }
            RecyclerView.this.removeAllViews();
            this.mLayout = oVar;
            if (oVar != null) {
                if (oVar.f1348Y == null) {
                    this.mLayout.mo1923f(this);
                    if (this.mIsAttached) {
                        this.mLayout.mo1885a(this);
                    }
                } else {
                    StringBuilder sb = new StringBuilder();
                    sb.append("LayoutManager ");
                    sb.append(oVar);
                    sb.append(" is already attached to a RecyclerView:");
                    throw new IllegalArgumentException(C0789gk.m5554a(oVar.f1348Y, sb));
                }
            }
            this.mRecycler.mo1997d();
            requestLayout();
        }
    }

    @Deprecated
    public void setLayoutTransition(LayoutTransition layoutTransition) {
        int i = Build.VERSION.SDK_INT;
        if (layoutTransition == null) {
            super.setLayoutTransition((LayoutTransition) null);
            return;
        }
        throw new IllegalArgumentException("Providing a LayoutTransition into RecyclerView is not supported. Please use setItemAnimator() instead for animating changes to the items in this RecyclerView");
    }

    public void setNestedScrollingEnabled(boolean z) {
        C1313m7 scrollingChildHelper = getScrollingChildHelper();
        if (scrollingChildHelper.f10039d) {
            C2189w7.m14974F(scrollingChildHelper.f10038c);
        }
        scrollingChildHelper.f10039d = z;
    }

    public void setOnFlingListener(C0239r rVar) {
        this.mOnFlingListener = rVar;
    }

    @Deprecated
    public void setOnScrollListener(C0241t tVar) {
        this.mScrollListener = tVar;
    }

    public void setPreserveFocusAfterLayout(boolean z) {
        this.mPreserveFocusAfterLayout = z;
    }

    public void setRecycledViewPool(C0242u uVar) {
        C0244v vVar = this.mRecycler;
        C0242u uVar2 = vVar.f1387g;
        if (uVar2 != null) {
            uVar2.mo1982b();
        }
        vVar.f1387g = uVar;
        if (vVar.f1387g != null && RecyclerView.this.getAdapter() != null) {
            vVar.f1387g.mo1979a();
        }
    }

    public void setRecyclerListener(C0245w wVar) {
    }

    public void setScrollState(int i) {
        if (i != this.mScrollState) {
            this.mScrollState = i;
            if (i != 2) {
                stopScrollersInternal();
            }
            dispatchOnScrollStateChanged(i);
        }
    }

    public void setScrollingTouchSlop(int i) {
        int i2;
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        if (i != 0) {
            if (i != 1) {
                Log.w(TAG, "setScrollingTouchSlop(): bad argument constant " + i + "; using default value");
            } else {
                i2 = viewConfiguration.getScaledPagingTouchSlop();
                this.mTouchSlop = i2;
            }
        }
        i2 = viewConfiguration.getScaledTouchSlop();
        this.mTouchSlop = i2;
    }

    public void setViewCacheExtension(C0214b0 b0Var) {
        this.mRecycler.mo1988a(b0Var);
    }

    public boolean shouldDeferAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        int i;
        if (!isComputingLayout()) {
            return false;
        }
        if (accessibilityEvent != null) {
            int i2 = Build.VERSION.SDK_INT;
            i = accessibilityEvent.getContentChangeTypes();
        } else {
            i = 0;
        }
        if (i == 0) {
            i = 0;
        }
        this.mEatenAccessibilityChangeFlags = i | this.mEatenAccessibilityChangeFlags;
        return true;
    }

    public void smoothScrollBy(int i, int i2) {
        smoothScrollBy(i, i2, (Interpolator) null);
    }

    public void smoothScrollBy(int i, int i2, Interpolator interpolator) {
        smoothScrollBy(i, i2, interpolator, UNDEFINED_DURATION);
    }

    public void smoothScrollBy(int i, int i2, Interpolator interpolator, int i3) {
        smoothScrollBy(i, i2, interpolator, i3, false);
    }

    public void smoothScrollBy(int i, int i2, Interpolator interpolator, int i3, boolean z) {
        C0232o oVar = this.mLayout;
        if (oVar == null) {
            Log.e(TAG, "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
        } else if (!this.mLayoutSuppressed) {
            int i4 = 0;
            if (!oVar.mo1567b()) {
                i = 0;
            }
            if (!this.mLayout.mo1570c()) {
                i2 = 0;
            }
            if (i != 0 || i2 != 0) {
                if (i3 == Integer.MIN_VALUE || i3 > 0) {
                    if (z) {
                        if (i != 0) {
                            i4 = 1;
                        }
                        if (i2 != 0) {
                            i4 |= 2;
                        }
                        startNestedScroll(i4, 1);
                    }
                    this.mViewFlinger.mo1796a(i, i2, i3, interpolator);
                    return;
                }
                scrollBy(i, i2);
            }
        }
    }

    public void smoothScrollToPosition(int i) {
        if (!this.mLayoutSuppressed) {
            C0232o oVar = this.mLayout;
            if (oVar == null) {
                Log.e(TAG, "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            } else {
                oVar.mo1561a(this, this.mState, i);
            }
        }
    }

    public void startInterceptRequestLayout() {
        this.mInterceptRequestLayoutDepth++;
        if (this.mInterceptRequestLayoutDepth == 1 && !this.mLayoutSuppressed) {
            this.mLayoutWasDefered = false;
        }
    }

    public boolean startNestedScroll(int i) {
        return getScrollingChildHelper().mo8622a(i, 0);
    }

    public boolean startNestedScroll(int i, int i2) {
        return getScrollingChildHelper().mo8622a(i, i2);
    }

    public void stopInterceptRequestLayout(boolean z) {
        if (this.mInterceptRequestLayoutDepth < 1) {
            this.mInterceptRequestLayoutDepth = 1;
        }
        if (!z && !this.mLayoutSuppressed) {
            this.mLayoutWasDefered = false;
        }
        if (this.mInterceptRequestLayoutDepth == 1) {
            if (z && this.mLayoutWasDefered && !this.mLayoutSuppressed && this.mLayout != null && this.mAdapter != null) {
                dispatchLayout();
            }
            if (!this.mLayoutSuppressed) {
                this.mLayoutWasDefered = false;
            }
        }
        this.mInterceptRequestLayoutDepth--;
    }

    public void stopNestedScroll() {
        getScrollingChildHelper().mo8627c(0);
    }

    public void stopNestedScroll(int i) {
        getScrollingChildHelper().mo8627c(i);
    }

    public void stopScroll() {
        setScrollState(0);
        stopScrollersInternal();
    }

    public final void suppressLayout(boolean z) {
        if (z != this.mLayoutSuppressed) {
            assertNotInLayoutOrScroll("Do not suppressLayout in layout or scroll");
            if (!z) {
                this.mLayoutSuppressed = false;
                if (!(!this.mLayoutWasDefered || this.mLayout == null || this.mAdapter == null)) {
                    requestLayout();
                }
                this.mLayoutWasDefered = false;
                return;
            }
            long uptimeMillis = SystemClock.uptimeMillis();
            onTouchEvent(MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0));
            this.mLayoutSuppressed = true;
            this.mIgnoreMotionEventTillDown = true;
            stopScroll();
        }
    }

    public void swapAdapter(C0221g gVar, boolean z) {
        setLayoutFrozen(false);
        setAdapterInternal(gVar, true, z);
        processDataSetCompletelyChanged(true);
        requestLayout();
    }

    public void viewRangeUpdate(int i, int i2, Object obj) {
        int i3;
        int i4;
        int b = this.mChildHelper.mo7589b();
        int i5 = i2 + i;
        for (int i6 = 0; i6 < b; i6++) {
            View d = this.mChildHelper.mo7594d(i6);
            C0218d0 childViewHolderInt = getChildViewHolderInt(d);
            if (childViewHolderInt != null && !childViewHolderInt.mo1821w() && (i4 = childViewHolderInt.f1318Z) >= i && i4 < i5) {
                childViewHolderInt.mo1800a(2);
                childViewHolderInt.mo1803a(obj);
                ((C0237p) d.getLayoutParams()).f1373Z = true;
            }
        }
        C0244v vVar = this.mRecycler;
        int size = vVar.f1383c.size();
        while (true) {
            size--;
            if (size >= 0) {
                C0218d0 d0Var = vVar.f1383c.get(size);
                if (d0Var != null && (i3 = d0Var.f1318Z) >= i && i3 < i5) {
                    d0Var.mo1800a(2);
                    vVar.mo1996c(size);
                }
            } else {
                return;
            }
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$z */
    public static abstract class C0249z {

        /* renamed from: a */
        public int f1391a = -1;

        /* renamed from: b */
        public RecyclerView f1392b;

        /* renamed from: c */
        public C0232o f1393c;

        /* renamed from: d */
        public boolean f1394d;

        /* renamed from: e */
        public boolean f1395e;

        /* renamed from: f */
        public View f1396f;

        /* renamed from: g */
        public final C0250a f1397g = new C0250a(0, 0);

        /* renamed from: h */
        public boolean f1398h;

        /* renamed from: androidx.recyclerview.widget.RecyclerView$z$a */
        public static class C0250a {

            /* renamed from: a */
            public int f1399a;

            /* renamed from: b */
            public int f1400b;

            /* renamed from: c */
            public int f1401c;

            /* renamed from: d */
            public int f1402d = -1;

            /* renamed from: e */
            public Interpolator f1403e;

            /* renamed from: f */
            public boolean f1404f = false;

            /* renamed from: g */
            public int f1405g = 0;

            public C0250a(int i, int i2) {
                this.f1399a = i;
                this.f1400b = i2;
                this.f1401c = RecyclerView.UNDEFINED_DURATION;
                this.f1403e = null;
            }

            /* renamed from: a */
            public void mo2009a(int i, int i2, int i3, Interpolator interpolator) {
                this.f1399a = i;
                this.f1400b = i2;
                this.f1401c = i3;
                this.f1403e = interpolator;
                this.f1404f = true;
            }

            /* renamed from: a */
            public void mo2010a(RecyclerView recyclerView) {
                int i = this.f1402d;
                if (i >= 0) {
                    this.f1402d = -1;
                    recyclerView.jumpToPositionForSmoothScroller(i);
                    this.f1404f = false;
                } else if (!this.f1404f) {
                    this.f1405g = 0;
                } else if (this.f1403e == null || this.f1401c >= 1) {
                    int i2 = this.f1401c;
                    if (i2 >= 1) {
                        recyclerView.mViewFlinger.mo1796a(this.f1399a, this.f1400b, i2, this.f1403e);
                        this.f1405g++;
                        if (this.f1405g > 10) {
                            Log.e(RecyclerView.TAG, "Smooth Scroll action is being updated too frequently. Make sure you are not changing it unless necessary");
                        }
                        this.f1404f = false;
                        return;
                    }
                    throw new IllegalStateException("Scroll duration must be a positive number");
                } else {
                    throw new IllegalStateException("If you provide an interpolator, you must set a positive duration");
                }
            }
        }

        /* renamed from: androidx.recyclerview.widget.RecyclerView$z$b */
        public interface C0251b {
            /* renamed from: c */
            PointF mo1569c(int i);
        }

        /* renamed from: a */
        public int mo2003a(View view) {
            return this.f1392b.getChildLayoutPosition(view);
        }

        /* renamed from: a */
        public PointF mo2004a(int i) {
            C0232o oVar = this.f1393c;
            if (oVar instanceof C0251b) {
                return ((C0251b) oVar).mo1569c(i);
            }
            StringBuilder a = C0789gk.m5562a("You should override computeScrollVectorForPosition when the LayoutManager does not implement ");
            a.append(C0251b.class.getCanonicalName());
            Log.w(RecyclerView.TAG, a.toString());
            return null;
        }

        /* renamed from: a */
        public abstract void mo2007a(View view, C0212a0 a0Var, C0250a aVar);

        /* renamed from: a */
        public void mo2006a(int i, int i2) {
            PointF a;
            RecyclerView recyclerView = this.f1392b;
            if (this.f1391a == -1 || recyclerView == null) {
                mo2005a();
            }
            if (!(!this.f1394d || this.f1396f != null || this.f1393c == null || (a = mo2004a(this.f1391a)) == null || (a.x == 0.0f && a.y == 0.0f))) {
                recyclerView.scrollStep((int) Math.signum(a.x), (int) Math.signum(a.y), (int[]) null);
            }
            boolean z = false;
            this.f1394d = false;
            View view = this.f1396f;
            if (view != null) {
                if (this.f1392b.getChildLayoutPosition(view) == this.f1391a) {
                    mo2007a(this.f1396f, recyclerView.mState, this.f1397g);
                    this.f1397g.mo2010a(recyclerView);
                    mo2005a();
                } else {
                    Log.e(RecyclerView.TAG, "Passed over target position while smooth scrolling.");
                    this.f1396f = null;
                }
            }
            if (this.f1395e) {
                C0212a0 a0Var = recyclerView.mState;
                C0250a aVar = this.f1397g;
                C1913tc tcVar = (C1913tc) this;
                if (tcVar.f1392b.mLayout.mo1921f() == 0) {
                    tcVar.mo2005a();
                } else {
                    int i3 = tcVar.f14818o;
                    int i4 = i3 - i;
                    if (i3 * i4 <= 0) {
                        i4 = 0;
                    }
                    tcVar.f14818o = i4;
                    int i5 = tcVar.f14819p;
                    int i6 = i5 - i2;
                    if (i5 * i6 <= 0) {
                        i6 = 0;
                    }
                    tcVar.f14819p = i6;
                    if (tcVar.f14818o == 0 && tcVar.f14819p == 0) {
                        PointF a2 = tcVar.mo2004a(tcVar.f1391a);
                        if (a2 == null || (a2.x == 0.0f && a2.y == 0.0f)) {
                            aVar.f1402d = tcVar.f1391a;
                            tcVar.mo2005a();
                        } else {
                            float f = a2.x;
                            float f2 = a2.y;
                            float sqrt = (float) Math.sqrt((double) ((f2 * f2) + (f * f)));
                            a2.x /= sqrt;
                            a2.y /= sqrt;
                            tcVar.f14814k = a2;
                            tcVar.f14818o = (int) (a2.x * 10000.0f);
                            tcVar.f14819p = (int) (a2.y * 10000.0f);
                            aVar.mo2009a((int) (((float) tcVar.f14818o) * 1.2f), (int) (((float) tcVar.f14819p) * 1.2f), (int) (((float) tcVar.mo11240b(10000)) * 1.2f), tcVar.f14812i);
                        }
                    }
                }
                if (this.f1397g.f1402d >= 0) {
                    z = true;
                }
                this.f1397g.mo2010a(recyclerView);
                if (z && this.f1395e) {
                    this.f1394d = true;
                    recyclerView.mViewFlinger.mo1795a();
                }
            }
        }

        /* renamed from: a */
        public void mo2008a(RecyclerView recyclerView, C0232o oVar) {
            recyclerView.mViewFlinger.mo1797b();
            if (this.f1398h) {
                StringBuilder a = C0789gk.m5562a("An instance of ");
                a.append(getClass().getSimpleName());
                a.append(" was started more than once. Each instance of");
                a.append(getClass().getSimpleName());
                a.append(" is intended to only be used once. You should create a new instance for each use.");
                Log.w(RecyclerView.TAG, a.toString());
            }
            this.f1392b = recyclerView;
            this.f1393c = oVar;
            int i = this.f1391a;
            if (i != -1) {
                RecyclerView recyclerView2 = this.f1392b;
                recyclerView2.mState.f1289a = i;
                this.f1395e = true;
                this.f1394d = true;
                this.f1396f = recyclerView2.mLayout.mo1574f(i);
                C1913tc tcVar = (C1913tc) this;
                this.f1392b.mViewFlinger.mo1795a();
                this.f1398h = true;
                return;
            }
            throw new IllegalArgumentException("Invalid target position");
        }

        /* renamed from: a */
        public final void mo2005a() {
            if (this.f1395e) {
                this.f1395e = false;
                C1913tc tcVar = (C1913tc) this;
                tcVar.f14819p = 0;
                tcVar.f14818o = 0;
                tcVar.f14814k = null;
                this.f1392b.mState.f1289a = -1;
                this.f1396f = null;
                this.f1391a = -1;
                this.f1394d = false;
                this.f1393c.mo1884a(this);
                this.f1393c = null;
                this.f1392b = null;
            }
        }
    }

    public boolean dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr, int i5) {
        return getScrollingChildHelper().mo8626b(i, i2, i3, i4, iArr, i5, (int[]) null);
    }

    public boolean hasNestedScrollingParent(int i) {
        return getScrollingChildHelper().mo8618a(i) != null;
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$u */
    public static class C0242u {

        /* renamed from: a */
        public SparseArray<C0243a> f1375a = new SparseArray<>();

        /* renamed from: b */
        public int f1376b = 0;

        /* renamed from: androidx.recyclerview.widget.RecyclerView$u$a */
        public static class C0243a {

            /* renamed from: a */
            public final ArrayList<C0218d0> f1377a = new ArrayList<>();

            /* renamed from: b */
            public int f1378b = 5;

            /* renamed from: c */
            public long f1379c = 0;

            /* renamed from: d */
            public long f1380d = 0;
        }

        /* renamed from: a */
        public long mo1977a(long j, long j2) {
            if (j == 0) {
                return j2;
            }
            return (j2 / 4) + ((j / 4) * 3);
        }

        /* renamed from: a */
        public final C0243a mo1978a(int i) {
            C0243a aVar = this.f1375a.get(i);
            if (aVar != null) {
                return aVar;
            }
            C0243a aVar2 = new C0243a();
            this.f1375a.put(i, aVar2);
            return aVar2;
        }

        /* renamed from: a */
        public void mo1979a() {
            this.f1376b++;
        }

        /* renamed from: a */
        public void mo1981a(C0221g gVar, C0221g gVar2, boolean z) {
            if (gVar != null) {
                this.f1376b--;
            }
            if (!z && this.f1376b == 0) {
                for (int i = 0; i < this.f1375a.size(); i++) {
                    this.f1375a.valueAt(i).f1377a.clear();
                }
            }
            if (gVar2 != null) {
                this.f1376b++;
            }
        }

        /* renamed from: b */
        public void mo1982b() {
            this.f1376b--;
        }

        /* renamed from: a */
        public void mo1980a(C0218d0 d0Var) {
            int i = d0Var.f1321c0;
            ArrayList<C0218d0> arrayList = mo1978a(i).f1377a;
            if (this.f1375a.get(i).f1378b > arrayList.size()) {
                d0Var.mo1820v();
                arrayList.add(d0Var);
            }
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$o */
    public static abstract class C0232o {

        /* renamed from: X */
        public C1050jc f1347X;

        /* renamed from: Y */
        public RecyclerView f1348Y;

        /* renamed from: Z */
        public final C0531dd.C0533b f1349Z = new C0233a();

        /* renamed from: a0 */
        public final C0531dd.C0533b f1350a0 = new C0234b();

        /* renamed from: b0 */
        public C0531dd f1351b0 = new C0531dd(this.f1349Z);

        /* renamed from: c0 */
        public C0531dd f1352c0 = new C0531dd(this.f1350a0);

        /* renamed from: d0 */
        public C0249z f1353d0;

        /* renamed from: e0 */
        public boolean f1354e0 = false;

        /* renamed from: f0 */
        public boolean f1355f0 = false;

        /* renamed from: g0 */
        public boolean f1356g0 = false;

        /* renamed from: h0 */
        public boolean f1357h0 = true;

        /* renamed from: i0 */
        public boolean f1358i0 = true;

        /* renamed from: j0 */
        public int f1359j0;

        /* renamed from: k0 */
        public boolean f1360k0;

        /* renamed from: l0 */
        public int f1361l0;

        /* renamed from: m0 */
        public int f1362m0;

        /* renamed from: n0 */
        public int f1363n0;

        /* renamed from: o0 */
        public int f1364o0;

        /* renamed from: androidx.recyclerview.widget.RecyclerView$o$a */
        public class C0233a implements C0531dd.C0533b {
            public C0233a() {
            }

            /* renamed from: a */
            public int mo1965a() {
                return C0232o.this.mo1954p() - C0232o.this.getPaddingRight();
            }

            /* renamed from: a */
            public int mo1966a(View view) {
                return C0232o.this.mo1924g(view) - ((C0237p) view.getLayoutParams()).leftMargin;
            }

            /* renamed from: a */
            public View mo1967a(int i) {
                return C0232o.this.mo1925g(i);
            }

            /* renamed from: b */
            public int mo1968b() {
                return C0232o.this.getPaddingLeft();
            }

            /* renamed from: b */
            public int mo1969b(View view) {
                return C0232o.this.mo1940j(view) + ((C0237p) view.getLayoutParams()).rightMargin;
            }
        }

        /* renamed from: androidx.recyclerview.widget.RecyclerView$o$b */
        public class C0234b implements C0531dd.C0533b {
            public C0234b() {
            }

            /* renamed from: a */
            public int mo1965a() {
                return C0232o.this.mo1936i() - C0232o.this.getPaddingBottom();
            }

            /* renamed from: a */
            public int mo1966a(View view) {
                return C0232o.this.mo1943k(view) - ((C0237p) view.getLayoutParams()).topMargin;
            }

            /* renamed from: a */
            public View mo1967a(int i) {
                return C0232o.this.mo1925g(i);
            }

            /* renamed from: b */
            public int mo1968b() {
                return C0232o.this.getPaddingTop();
            }

            /* renamed from: b */
            public int mo1969b(View view) {
                return C0232o.this.mo1922f(view) + ((C0237p) view.getLayoutParams()).bottomMargin;
            }
        }

        /* renamed from: androidx.recyclerview.widget.RecyclerView$o$c */
        public interface C0235c {
        }

        /* renamed from: androidx.recyclerview.widget.RecyclerView$o$d */
        public static class C0236d {

            /* renamed from: a */
            public int f1367a;

            /* renamed from: b */
            public int f1368b;

            /* renamed from: c */
            public boolean f1369c;

            /* renamed from: d */
            public boolean f1370d;
        }

        /* renamed from: a */
        public static int m1221a(int i, int i2, int i3, int i4, boolean z) {
            int i5;
            int i6 = i - i3;
            int i7 = 0;
            int max = Math.max(0, i6);
            if (z) {
                if (i4 < 0) {
                    if (i4 == -1) {
                        if (i2 == Integer.MIN_VALUE || (i2 != 0 && i2 == 1073741824)) {
                            i5 = max;
                        } else {
                            i2 = 0;
                            i5 = 0;
                        }
                        i7 = i2;
                        max = i5;
                        return View.MeasureSpec.makeMeasureSpec(max, i7);
                    }
                    max = 0;
                    return View.MeasureSpec.makeMeasureSpec(max, i7);
                }
            } else if (i4 < 0) {
                if (i4 == -1) {
                    i7 = i2;
                } else {
                    if (i4 == -2) {
                        if (i2 == Integer.MIN_VALUE || i2 == 1073741824) {
                            i7 = RecyclerView.UNDEFINED_DURATION;
                        }
                    }
                    max = 0;
                }
                return View.MeasureSpec.makeMeasureSpec(max, i7);
            }
            max = i4;
            i7 = 1073741824;
            return View.MeasureSpec.makeMeasureSpec(max, i7);
        }

        /* renamed from: a */
        public static C0236d m1222a(Context context, AttributeSet attributeSet, int i, int i2) {
            C0236d dVar = new C0236d();
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0856hc.RecyclerView, i, i2);
            dVar.f1367a = obtainStyledAttributes.getInt(C0856hc.RecyclerView_android_orientation, 1);
            dVar.f1368b = obtainStyledAttributes.getInt(C0856hc.RecyclerView_spanCount, 1);
            dVar.f1369c = obtainStyledAttributes.getBoolean(C0856hc.RecyclerView_reverseLayout, false);
            dVar.f1370d = obtainStyledAttributes.getBoolean(C0856hc.RecyclerView_stackFromEnd, false);
            obtainStyledAttributes.recycle();
            return dVar;
        }

        /* renamed from: c */
        public static int m1223c(int i, int i2, int i3) {
            int mode = View.MeasureSpec.getMode(i);
            int size = View.MeasureSpec.getSize(i);
            return mode != Integer.MIN_VALUE ? mode != 1073741824 ? Math.max(i2, i3) : size : Math.min(size, Math.max(i2, i3));
        }

        /* renamed from: d */
        public static boolean m1224d(int i, int i2, int i3) {
            int mode = View.MeasureSpec.getMode(i2);
            int size = View.MeasureSpec.getSize(i2);
            if (i3 > 0 && i != i3) {
                return false;
            }
            if (mode == Integer.MIN_VALUE) {
                return size >= i;
            }
            if (mode != 0) {
                return mode == 1073741824 && size == i;
            }
            return true;
        }

        /* renamed from: A */
        public View mo1865A() {
            return null;
        }

        /* renamed from: B */
        public Parcelable mo1533B() {
            return null;
        }

        /* renamed from: C */
        public boolean mo1866C() {
            return false;
        }

        /* renamed from: D */
        public void mo1867D() {
            for (int f = mo1921f() - 1; f >= 0; f--) {
                this.f1347X.mo7595e(f);
            }
        }

        /* renamed from: E */
        public void mo1868E() {
            RecyclerView recyclerView = this.f1348Y;
            if (recyclerView != null) {
                recyclerView.requestLayout();
            }
        }

        /* renamed from: F */
        public void mo1869F() {
            this.f1354e0 = true;
        }

        /* renamed from: G */
        public boolean mo1534G() {
            return false;
        }

        /* renamed from: H */
        public void mo1870H() {
            C0249z zVar = this.f1353d0;
            if (zVar != null) {
                zVar.mo2005a();
            }
        }

        /* renamed from: I */
        public boolean mo1488I() {
            return false;
        }

        /* renamed from: a */
        public int mo1492a(int i, C0244v vVar, C0212a0 a0Var) {
            return 0;
        }

        /* renamed from: a */
        public int mo1549a(C0212a0 a0Var) {
            return 0;
        }

        /* renamed from: a */
        public int mo1493a(C0244v vVar, C0212a0 a0Var) {
            RecyclerView recyclerView = this.f1348Y;
            if (recyclerView == null || recyclerView.mAdapter == null || !mo1567b()) {
                return 1;
            }
            return this.f1348Y.mAdapter.mo1833a();
        }

        /* renamed from: a */
        public View mo1495a(View view, int i, C0244v vVar, C0212a0 a0Var) {
            return null;
        }

        /* renamed from: a */
        public C0237p mo1497a(Context context, AttributeSet attributeSet) {
            return new C0237p(context, attributeSet);
        }

        /* renamed from: a */
        public C0237p mo1498a(ViewGroup.LayoutParams layoutParams) {
            return layoutParams instanceof C0237p ? new C0237p((C0237p) layoutParams) : layoutParams instanceof ViewGroup.MarginLayoutParams ? new C0237p((ViewGroup.MarginLayoutParams) layoutParams) : new C0237p(layoutParams);
        }

        /* renamed from: a */
        public void mo1871a(int i, int i2) {
            View g = mo1925g(i);
            if (g != null) {
                mo1913d(i);
                mo1909c(g, i2);
                return;
            }
            throw new IllegalArgumentException("Cannot move a child from non-existing index:" + i + this.f1348Y.toString());
        }

        /* renamed from: a */
        public void mo1553a(int i, int i2, C0212a0 a0Var, C0235c cVar) {
        }

        /* renamed from: a */
        public void mo1555a(int i, C0235c cVar) {
        }

        /* renamed from: a */
        public void mo1872a(int i, C0244v vVar) {
            View g = mo1925g(i);
            mo1947l(i);
            vVar.mo1986a(g);
        }

        /* renamed from: a */
        public void mo1499a(Rect rect, int i, int i2) {
            mo1914d(m1223c(i, getPaddingRight() + getPaddingLeft() + rect.width(), mo1950n()), m1223c(i2, getPaddingBottom() + getPaddingTop() + rect.height(), mo1948m()));
        }

        /* renamed from: a */
        public void mo1556a(Parcelable parcelable) {
        }

        /* renamed from: a */
        public void mo1873a(View view, int i) {
            mo1876a(view, i, true);
        }

        /* renamed from: a */
        public void mo1874a(View view, int i, int i2, int i3, int i4) {
            C0237p pVar = (C0237p) view.getLayoutParams();
            Rect rect = pVar.f1372Y;
            view.layout(i + rect.left + pVar.leftMargin, i2 + rect.top + pVar.topMargin, (i3 - rect.right) - pVar.rightMargin, (i4 - rect.bottom) - pVar.bottomMargin);
        }

        /* renamed from: a */
        public void mo1875a(View view, int i, C0237p pVar) {
            C0218d0 childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
            if (childViewHolderInt.mo1815r()) {
                this.f1348Y.mViewInfoStore.mo5093a(childViewHolderInt);
            } else {
                this.f1348Y.mViewInfoStore.mo5097c(childViewHolderInt);
            }
            this.f1347X.mo7587a(view, i, pVar, childViewHolderInt.mo1815r());
        }

        /* renamed from: a */
        public final void mo1876a(View view, int i, boolean z) {
            C0218d0 childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
            if (z || childViewHolderInt.mo1815r()) {
                this.f1348Y.mViewInfoStore.mo5093a(childViewHolderInt);
            } else {
                this.f1348Y.mViewInfoStore.mo5097c(childViewHolderInt);
            }
            C0237p pVar = (C0237p) view.getLayoutParams();
            if (childViewHolderInt.mo1822x() || childViewHolderInt.mo1816s()) {
                if (childViewHolderInt.mo1816s()) {
                    childViewHolderInt.f1329k0.mo1994b(childViewHolderInt);
                } else {
                    childViewHolderInt.mo1807j();
                }
                this.f1347X.mo7587a(view, i, view.getLayoutParams(), false);
            } else if (view.getParent() == this.f1348Y) {
                int a = this.f1347X.mo7585a(view);
                if (i == -1) {
                    i = this.f1347X.mo7584a();
                }
                if (a == -1) {
                    StringBuilder a2 = C0789gk.m5562a("Added View has RecyclerView as parent but view is not a real child. Unfiltered index:");
                    a2.append(this.f1348Y.indexOfChild(view));
                    throw new IllegalStateException(C0789gk.m5554a(this.f1348Y, a2));
                } else if (a != i) {
                    this.f1348Y.mLayout.mo1871a(a, i);
                }
            } else {
                this.f1347X.mo7588a(view, i, false);
                pVar.f1373Z = true;
                C0249z zVar = this.f1353d0;
                if (zVar != null && zVar.f1395e && zVar.mo2003a(view) == zVar.f1391a) {
                    zVar.f1396f = view;
                }
            }
            if (pVar.f1374a0) {
                childViewHolderInt.f1316X.invalidate();
                pVar.f1374a0 = false;
            }
        }

        /* renamed from: a */
        public void mo1877a(View view, Rect rect) {
            RecyclerView recyclerView = this.f1348Y;
            if (recyclerView == null) {
                rect.set(0, 0, 0, 0);
            } else {
                rect.set(recyclerView.getItemDecorInsetsForChild(view));
            }
        }

        /* renamed from: a */
        public void mo1878a(View view, C0244v vVar) {
            mo1955p(view);
            vVar.mo1986a(view);
        }

        /* renamed from: a */
        public void mo1879a(View view, C0759g8 g8Var) {
            C0218d0 childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
            if (childViewHolderInt != null && !childViewHolderInt.mo1815r() && !this.f1347X.mo7591b(childViewHolderInt.f1316X)) {
                RecyclerView recyclerView = this.f1348Y;
                mo1502a(recyclerView.mRecycler, recyclerView.mState, view, g8Var);
            }
        }

        /* renamed from: a */
        public void mo1880a(View view, boolean z, Rect rect) {
            Matrix matrix;
            if (z) {
                Rect rect2 = ((C0237p) view.getLayoutParams()).f1372Y;
                rect.set(-rect2.left, -rect2.top, view.getWidth() + rect2.right, view.getHeight() + rect2.bottom);
            } else {
                rect.set(0, 0, view.getWidth(), view.getHeight());
            }
            if (!(this.f1348Y == null || (matrix = view.getMatrix()) == null || matrix.isIdentity())) {
                RectF rectF = this.f1348Y.mTempRectF;
                rectF.set(rect);
                matrix.mapRect(rectF);
                rect.set((int) Math.floor((double) rectF.left), (int) Math.floor((double) rectF.top), (int) Math.ceil((double) rectF.right), (int) Math.ceil((double) rectF.bottom));
            }
            rect.offset(view.getLeft(), view.getTop());
        }

        /* renamed from: a */
        public void mo1557a(AccessibilityEvent accessibilityEvent) {
            RecyclerView recyclerView = this.f1348Y;
            C0244v vVar = recyclerView.mRecycler;
            C0212a0 a0Var = recyclerView.mState;
            mo1902b(accessibilityEvent);
        }

        /* renamed from: a */
        public void mo1881a(C0221g gVar, C0221g gVar2) {
        }

        /* renamed from: a */
        public void mo1502a(C0244v vVar, C0212a0 a0Var, View view, C0759g8 g8Var) {
            g8Var.mo6041b((Object) C0759g8.C0762c.m5406a(mo1570c() ? mo1949m(view) : 0, 1, mo1567b() ? mo1949m(view) : 0, 1, false, false));
        }

        /* renamed from: a */
        public void mo1884a(C0249z zVar) {
            if (this.f1353d0 == zVar) {
                this.f1353d0 = null;
            }
        }

        /* renamed from: a */
        public void mo1885a(RecyclerView recyclerView) {
            this.f1355f0 = true;
            mo1905b(recyclerView);
        }

        /* renamed from: a */
        public void mo1505a(RecyclerView recyclerView, int i, int i2) {
        }

        /* renamed from: a */
        public void mo1506a(RecyclerView recyclerView, int i, int i2, int i3) {
        }

        /* renamed from: a */
        public void mo1507a(RecyclerView recyclerView, int i, int i2, Object obj) {
            mo1911c(recyclerView, i, i2);
        }

        /* renamed from: a */
        public void mo1561a(RecyclerView recyclerView, C0212a0 a0Var, int i) {
            Log.e(RecyclerView.TAG, "You must override smoothScrollToPosition to support smooth scrolling");
        }

        /* renamed from: a */
        public void mo1886a(RecyclerView recyclerView, C0244v vVar) {
            this.f1355f0 = false;
            mo1565b(recyclerView, vVar);
        }

        /* renamed from: a */
        public void mo1887a(C0759g8 g8Var) {
            RecyclerView recyclerView = this.f1348Y;
            mo1883a(recyclerView.mRecycler, recyclerView.mState, g8Var);
        }

        /* renamed from: a */
        public void mo1562a(String str) {
            RecyclerView recyclerView = this.f1348Y;
            if (recyclerView != null) {
                recyclerView.assertNotInLayoutOrScroll(str);
            }
        }

        @Deprecated
        /* renamed from: a */
        public void mo1888a(boolean z) {
            this.f1356g0 = z;
        }

        /* renamed from: a */
        public boolean mo1889a(int i, Bundle bundle) {
            RecyclerView recyclerView = this.f1348Y;
            C0244v vVar = recyclerView.mRecycler;
            C0212a0 a0Var = recyclerView.mState;
            return mo1944k(i);
        }

        /* renamed from: a */
        public boolean mo1890a(View view, int i, int i2, C0237p pVar) {
            return view.isLayoutRequested() || !this.f1357h0 || !m1224d(view.getWidth(), i, pVar.width) || !m1224d(view.getHeight(), i2, pVar.height);
        }

        /* renamed from: a */
        public boolean mo1891a(View view, int i, Bundle bundle) {
            RecyclerView recyclerView = this.f1348Y;
            C0244v vVar = recyclerView.mRecycler;
            C0212a0 a0Var = recyclerView.mState;
            return mo1866C();
        }

        /* renamed from: a */
        public boolean mo1892a(View view, boolean z) {
            boolean z2 = this.f1351b0.mo4740a(view, 24579) && this.f1352c0.mo4740a(view, 24579);
            return z ? z2 : !z2;
        }

        /* renamed from: a */
        public boolean mo1508a(C0237p pVar) {
            return pVar != null;
        }

        /* renamed from: a */
        public boolean mo1893a(RecyclerView recyclerView, View view, Rect rect, boolean z) {
            return mo1894a(recyclerView, view, rect, z, false);
        }

        /* renamed from: a */
        public boolean mo1895a(RecyclerView recyclerView, View view, View view2) {
            return mo1915d(recyclerView);
        }

        /* renamed from: a */
        public boolean mo1896a(Runnable runnable) {
            RecyclerView recyclerView = this.f1348Y;
            if (recyclerView != null) {
                return recyclerView.removeCallbacks(runnable);
            }
            return false;
        }

        /* renamed from: b */
        public int mo1509b(int i, C0244v vVar, C0212a0 a0Var) {
            return 0;
        }

        /* renamed from: b */
        public int mo1510b(C0212a0 a0Var) {
            return 0;
        }

        /* renamed from: b */
        public int mo1511b(C0244v vVar, C0212a0 a0Var) {
            RecyclerView recyclerView = this.f1348Y;
            if (recyclerView == null || recyclerView.mAdapter == null || !mo1570c()) {
                return 1;
            }
            return this.f1348Y.mAdapter.mo1833a();
        }

        /* renamed from: b */
        public void mo1897b(int i, int i2) {
            this.f1348Y.defaultOnMeasure(i, i2);
        }

        /* renamed from: b */
        public void mo1898b(View view) {
            mo1873a(view, -1);
        }

        /* renamed from: b */
        public void mo1899b(View view, int i) {
            mo1876a(view, i, false);
        }

        /* renamed from: b */
        public void mo1900b(View view, int i, int i2) {
            C0237p pVar = (C0237p) view.getLayoutParams();
            Rect itemDecorInsetsForChild = this.f1348Y.getItemDecorInsetsForChild(view);
            int i3 = itemDecorInsetsForChild.left + itemDecorInsetsForChild.right + i;
            int i4 = itemDecorInsetsForChild.top + itemDecorInsetsForChild.bottom + i2;
            int a = m1221a(mo1954p(), mo1956q(), getPaddingRight() + getPaddingLeft() + pVar.leftMargin + pVar.rightMargin + i3, pVar.width, mo1567b());
            int a2 = m1221a(mo1936i(), mo1939j(), getPaddingBottom() + getPaddingTop() + pVar.topMargin + pVar.bottomMargin + i4, pVar.height, mo1570c());
            if (mo1890a(view, a, a2, pVar)) {
                view.measure(a, a2);
            }
        }

        /* renamed from: b */
        public void mo1901b(View view, Rect rect) {
            RecyclerView.getDecoratedBoundsWithMarginsInt(view, rect);
        }

        /* renamed from: b */
        public void mo1902b(AccessibilityEvent accessibilityEvent) {
            RecyclerView recyclerView = this.f1348Y;
            if (recyclerView != null && accessibilityEvent != null) {
                boolean z = true;
                if (!recyclerView.canScrollVertically(1) && !this.f1348Y.canScrollVertically(-1) && !this.f1348Y.canScrollHorizontally(-1) && !this.f1348Y.canScrollHorizontally(1)) {
                    z = false;
                }
                accessibilityEvent.setScrollable(z);
                C0221g gVar = this.f1348Y.mAdapter;
                if (gVar != null) {
                    accessibilityEvent.setItemCount(gVar.mo1833a());
                }
            }
        }

        /* renamed from: b */
        public void mo1903b(C0244v vVar) {
            for (int f = mo1921f() - 1; f >= 0; f--) {
                if (!RecyclerView.getChildViewHolderInt(mo1925g(f)).mo1821w()) {
                    mo1872a(f, vVar);
                }
            }
        }

        /* renamed from: b */
        public void mo1904b(C0249z zVar) {
            C0249z zVar2 = this.f1353d0;
            if (!(zVar2 == null || zVar == zVar2 || !zVar2.f1395e)) {
                zVar2.mo2005a();
            }
            this.f1353d0 = zVar;
            this.f1353d0.mo2008a(this.f1348Y, this);
        }

        /* renamed from: b */
        public void mo1905b(RecyclerView recyclerView) {
        }

        /* renamed from: b */
        public void mo1514b(RecyclerView recyclerView, int i, int i2) {
        }

        /* renamed from: b */
        public void mo1565b(RecyclerView recyclerView, C0244v vVar) {
            mo1964z();
        }

        /* renamed from: b */
        public boolean mo1567b() {
            return false;
        }

        /* renamed from: b */
        public boolean mo1906b(View view, int i, int i2, C0237p pVar) {
            return !this.f1357h0 || !m1224d(view.getMeasuredWidth(), i, pVar.width) || !m1224d(view.getMeasuredHeight(), i2, pVar.height);
        }

        /* renamed from: c */
        public int mo1515c(C0212a0 a0Var) {
            return 0;
        }

        /* renamed from: c */
        public void mo1907c(int i, int i2) {
            this.f1363n0 = View.MeasureSpec.getSize(i);
            this.f1361l0 = View.MeasureSpec.getMode(i);
            if (this.f1361l0 == 0 && !RecyclerView.ALLOW_SIZE_IN_UNSPECIFIED_SPEC) {
                this.f1363n0 = 0;
            }
            this.f1364o0 = View.MeasureSpec.getSize(i2);
            this.f1362m0 = View.MeasureSpec.getMode(i2);
            if (this.f1362m0 == 0 && !RecyclerView.ALLOW_SIZE_IN_UNSPECIFIED_SPEC) {
                this.f1364o0 = 0;
            }
        }

        /* renamed from: c */
        public void mo1908c(View view) {
            mo1899b(view, -1);
        }

        /* renamed from: c */
        public void mo1909c(View view, int i) {
            mo1875a(view, i, (C0237p) view.getLayoutParams());
        }

        /* renamed from: c */
        public void mo1910c(C0244v vVar) {
            int size = vVar.f1381a.size();
            for (int i = size - 1; i >= 0; i--) {
                View view = vVar.f1381a.get(i).f1316X;
                C0218d0 childViewHolderInt = RecyclerView.getChildViewHolderInt(view);
                if (!childViewHolderInt.mo1821w()) {
                    childViewHolderInt.mo1804a(false);
                    if (childViewHolderInt.mo1817t()) {
                        this.f1348Y.removeDetachedView(view, false);
                    }
                    C0226l lVar = this.f1348Y.mItemAnimator;
                    if (lVar != null) {
                        lVar.mo1854a(childViewHolderInt);
                    }
                    childViewHolderInt.mo1804a(true);
                    C0218d0 childViewHolderInt2 = RecyclerView.getChildViewHolderInt(view);
                    childViewHolderInt2.f1329k0 = null;
                    childViewHolderInt2.f1330l0 = false;
                    childViewHolderInt2.mo1807j();
                    vVar.mo1989a(childViewHolderInt2);
                }
            }
            vVar.f1381a.clear();
            ArrayList<C0218d0> arrayList = vVar.f1382b;
            if (arrayList != null) {
                arrayList.clear();
            }
            if (size > 0) {
                this.f1348Y.invalidate();
            }
        }

        /* renamed from: c */
        public void mo1517c(C0244v vVar, C0212a0 a0Var) {
            Log.e(RecyclerView.TAG, "You must override onLayoutChildren(Recycler recycler, State state) ");
        }

        /* renamed from: c */
        public void mo1518c(RecyclerView recyclerView) {
        }

        /* renamed from: c */
        public void mo1911c(RecyclerView recyclerView, int i, int i2) {
        }

        /* renamed from: c */
        public boolean mo1570c() {
            return false;
        }

        /* renamed from: d */
        public int mo1571d(C0212a0 a0Var) {
            return 0;
        }

        /* renamed from: d */
        public View mo1912d(View view) {
            View findContainingItemView;
            RecyclerView recyclerView = this.f1348Y;
            if (recyclerView == null || (findContainingItemView = recyclerView.findContainingItemView(view)) == null || this.f1347X.f8345c.contains(findContainingItemView)) {
                return null;
            }
            return findContainingItemView;
        }

        /* renamed from: d */
        public abstract C0237p mo1520d();

        /* renamed from: d */
        public void mo1913d(int i) {
            mo1925g(i);
            mo1918e(i);
        }

        /* renamed from: d */
        public void mo1914d(int i, int i2) {
            this.f1348Y.setMeasuredDimension(i, i2);
        }

        @Deprecated
        /* renamed from: d */
        public boolean mo1915d(RecyclerView recyclerView) {
            return mo1962x() || recyclerView.isComputingLayout();
        }

        /* renamed from: e */
        public int mo1916e() {
            return -1;
        }

        /* renamed from: e */
        public int mo1917e(View view) {
            return ((C0237p) view.getLayoutParams()).f1372Y.bottom;
        }

        /* renamed from: e */
        public int mo1521e(C0212a0 a0Var) {
            return 0;
        }

        /* renamed from: e */
        public final void mo1918e(int i) {
            this.f1347X.mo7586a(i);
        }

        /* renamed from: e */
        public void mo1919e(int i, int i2) {
            int f = mo1921f();
            if (f == 0) {
                this.f1348Y.defaultOnMeasure(i, i2);
                return;
            }
            int i3 = Integer.MAX_VALUE;
            int i4 = Integer.MAX_VALUE;
            int i5 = RecyclerView.UNDEFINED_DURATION;
            int i6 = RecyclerView.UNDEFINED_DURATION;
            for (int i7 = 0; i7 < f; i7++) {
                View g = mo1925g(i7);
                Rect rect = this.f1348Y.mTempRect;
                mo1901b(g, rect);
                int i8 = rect.left;
                if (i8 < i3) {
                    i3 = i8;
                }
                int i9 = rect.right;
                if (i9 > i5) {
                    i5 = i9;
                }
                int i10 = rect.top;
                if (i10 < i4) {
                    i4 = i10;
                }
                int i11 = rect.bottom;
                if (i11 > i6) {
                    i6 = i11;
                }
            }
            this.f1348Y.mTempRect.set(i3, i4, i5, i6);
            mo1499a(this.f1348Y.mTempRect, i, i2);
        }

        /* renamed from: e */
        public void mo1920e(RecyclerView recyclerView) {
            mo1907c(View.MeasureSpec.makeMeasureSpec(recyclerView.getWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(recyclerView.getHeight(), 1073741824));
        }

        /* renamed from: f */
        public int mo1921f() {
            C1050jc jcVar = this.f1347X;
            if (jcVar != null) {
                return jcVar.mo7584a();
            }
            return 0;
        }

        /* renamed from: f */
        public int mo1922f(View view) {
            return mo1917e(view) + view.getBottom();
        }

        /* renamed from: f */
        public int mo1522f(C0212a0 a0Var) {
            return 0;
        }

        /* renamed from: f */
        public View mo1574f(int i) {
            int f = mo1921f();
            for (int i2 = 0; i2 < f; i2++) {
                View g = mo1925g(i2);
                C0218d0 childViewHolderInt = RecyclerView.getChildViewHolderInt(g);
                if (childViewHolderInt != null && childViewHolderInt.mo1809l() == i && !childViewHolderInt.mo1821w() && (this.f1348Y.mState.f1296h || !childViewHolderInt.mo1815r())) {
                    return g;
                }
            }
            return null;
        }

        /* renamed from: f */
        public void mo1923f(RecyclerView recyclerView) {
            int i;
            if (recyclerView == null) {
                this.f1348Y = null;
                this.f1347X = null;
                i = 0;
                this.f1363n0 = 0;
            } else {
                this.f1348Y = recyclerView;
                this.f1347X = recyclerView.mChildHelper;
                this.f1363n0 = recyclerView.getWidth();
                i = recyclerView.getHeight();
            }
            this.f1364o0 = i;
            this.f1361l0 = 1073741824;
            this.f1362m0 = 1073741824;
        }

        /* renamed from: g */
        public int mo1924g(View view) {
            return view.getLeft() - mo1946l(view);
        }

        /* renamed from: g */
        public View mo1925g(int i) {
            C1050jc jcVar = this.f1347X;
            if (jcVar == null) {
                return null;
            }
            return ((C0219e) jcVar.f8343a).mo1824a(jcVar.mo7592c(i));
        }

        /* renamed from: g */
        public void mo1523g(C0212a0 a0Var) {
        }

        /* renamed from: g */
        public boolean mo1926g() {
            RecyclerView recyclerView = this.f1348Y;
            return recyclerView != null && recyclerView.mClipToPadding;
        }

        public int getPaddingBottom() {
            RecyclerView recyclerView = this.f1348Y;
            if (recyclerView != null) {
                return recyclerView.getPaddingBottom();
            }
            return 0;
        }

        public int getPaddingEnd() {
            RecyclerView recyclerView = this.f1348Y;
            if (recyclerView != null) {
                return C2189w7.m15022q(recyclerView);
            }
            return 0;
        }

        public int getPaddingLeft() {
            RecyclerView recyclerView = this.f1348Y;
            if (recyclerView != null) {
                return recyclerView.getPaddingLeft();
            }
            return 0;
        }

        public int getPaddingRight() {
            RecyclerView recyclerView = this.f1348Y;
            if (recyclerView != null) {
                return recyclerView.getPaddingRight();
            }
            return 0;
        }

        public int getPaddingStart() {
            RecyclerView recyclerView = this.f1348Y;
            if (recyclerView != null) {
                return C2189w7.m15023r(recyclerView);
            }
            return 0;
        }

        public int getPaddingTop() {
            RecyclerView recyclerView = this.f1348Y;
            if (recyclerView != null) {
                return recyclerView.getPaddingTop();
            }
            return 0;
        }

        /* renamed from: h */
        public int mo1933h(View view) {
            Rect rect = ((C0237p) view.getLayoutParams()).f1372Y;
            return view.getMeasuredHeight() + rect.top + rect.bottom;
        }

        /* renamed from: h */
        public View mo1934h() {
            View focusedChild;
            RecyclerView recyclerView = this.f1348Y;
            if (recyclerView == null || (focusedChild = recyclerView.getFocusedChild()) == null || this.f1347X.f8345c.contains(focusedChild)) {
                return null;
            }
            return focusedChild;
        }

        /* renamed from: h */
        public void mo1935h(int i) {
            RecyclerView recyclerView = this.f1348Y;
            if (recyclerView != null) {
                recyclerView.offsetChildrenHorizontal(i);
            }
        }

        /* renamed from: i */
        public int mo1936i() {
            return this.f1364o0;
        }

        /* renamed from: i */
        public int mo1937i(View view) {
            Rect rect = ((C0237p) view.getLayoutParams()).f1372Y;
            return view.getMeasuredWidth() + rect.left + rect.right;
        }

        /* renamed from: i */
        public void mo1938i(int i) {
            RecyclerView recyclerView = this.f1348Y;
            if (recyclerView != null) {
                recyclerView.offsetChildrenVertical(i);
            }
        }

        /* renamed from: j */
        public int mo1939j() {
            return this.f1362m0;
        }

        /* renamed from: j */
        public int mo1940j(View view) {
            return mo1951n(view) + view.getRight();
        }

        /* renamed from: j */
        public void mo1941j(int i) {
        }

        /* renamed from: k */
        public int mo1942k() {
            RecyclerView recyclerView = this.f1348Y;
            C0221g adapter = recyclerView != null ? recyclerView.getAdapter() : null;
            if (adapter != null) {
                return adapter.mo1833a();
            }
            return 0;
        }

        /* renamed from: k */
        public int mo1943k(View view) {
            return view.getTop() - mo1953o(view);
        }

        /* JADX WARNING: Removed duplicated region for block: B:26:0x007a A[ADDED_TO_REGION] */
        /* renamed from: k */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean mo1944k(int r11) {
            /*
                r10 = this;
                androidx.recyclerview.widget.RecyclerView r0 = r10.f1348Y
                r1 = 0
                if (r0 != 0) goto L_0x0006
                return r1
            L_0x0006:
                r2 = 4096(0x1000, float:5.74E-42)
                r3 = 1
                if (r11 == r2) goto L_0x0047
                r2 = 8192(0x2000, float:1.14794E-41)
                if (r11 == r2) goto L_0x0013
                r5 = 0
                r6 = 0
                goto L_0x0078
            L_0x0013:
                r11 = -1
                boolean r0 = r0.canScrollVertically(r11)
                if (r0 == 0) goto L_0x002a
                int r0 = r10.mo1936i()
                int r2 = r10.getPaddingTop()
                int r0 = r0 - r2
                int r2 = r10.getPaddingBottom()
                int r0 = r0 - r2
                int r0 = -r0
                goto L_0x002b
            L_0x002a:
                r0 = 0
            L_0x002b:
                androidx.recyclerview.widget.RecyclerView r2 = r10.f1348Y
                boolean r11 = r2.canScrollHorizontally(r11)
                if (r11 == 0) goto L_0x0045
                int r11 = r10.mo1954p()
                int r2 = r10.getPaddingLeft()
                int r11 = r11 - r2
                int r2 = r10.getPaddingRight()
                int r11 = r11 - r2
                int r11 = -r11
                r5 = r11
                r6 = r0
                goto L_0x0078
            L_0x0045:
                r6 = r0
                goto L_0x0077
            L_0x0047:
                boolean r11 = r0.canScrollVertically(r3)
                if (r11 == 0) goto L_0x005c
                int r11 = r10.mo1936i()
                int r0 = r10.getPaddingTop()
                int r11 = r11 - r0
                int r0 = r10.getPaddingBottom()
                int r11 = r11 - r0
                goto L_0x005d
            L_0x005c:
                r11 = 0
            L_0x005d:
                androidx.recyclerview.widget.RecyclerView r0 = r10.f1348Y
                boolean r0 = r0.canScrollHorizontally(r3)
                if (r0 == 0) goto L_0x0076
                int r0 = r10.mo1954p()
                int r2 = r10.getPaddingLeft()
                int r0 = r0 - r2
                int r2 = r10.getPaddingRight()
                int r0 = r0 - r2
                r6 = r11
                r5 = r0
                goto L_0x0078
            L_0x0076:
                r6 = r11
            L_0x0077:
                r5 = 0
            L_0x0078:
                if (r6 != 0) goto L_0x007d
                if (r5 != 0) goto L_0x007d
                return r1
            L_0x007d:
                androidx.recyclerview.widget.RecyclerView r4 = r10.f1348Y
                r7 = 0
                r8 = -2147483648(0xffffffff80000000, float:-0.0)
                r9 = 1
                r4.smoothScrollBy(r5, r6, r7, r8, r9)
                return r3
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.C0232o.mo1944k(int):boolean");
        }

        /* renamed from: l */
        public int mo1945l() {
            return C2189w7.m15018m(this.f1348Y);
        }

        /* renamed from: l */
        public int mo1946l(View view) {
            return ((C0237p) view.getLayoutParams()).f1372Y.left;
        }

        /* renamed from: l */
        public void mo1947l(int i) {
            if (mo1925g(i) != null) {
                this.f1347X.mo7595e(i);
            }
        }

        /* renamed from: m */
        public int mo1948m() {
            return C2189w7.m15019n(this.f1348Y);
        }

        /* renamed from: m */
        public int mo1949m(View view) {
            return ((C0237p) view.getLayoutParams()).mo1970n();
        }

        /* renamed from: m */
        public void mo1582m(int i) {
        }

        /* renamed from: n */
        public int mo1950n() {
            return C2189w7.m15020o(this.f1348Y);
        }

        /* renamed from: n */
        public int mo1951n(View view) {
            return ((C0237p) view.getLayoutParams()).f1372Y.right;
        }

        /* renamed from: o */
        public int mo1952o() {
            return 0;
        }

        /* renamed from: o */
        public int mo1953o(View view) {
            return ((C0237p) view.getLayoutParams()).f1372Y.top;
        }

        /* renamed from: p */
        public int mo1954p() {
            return this.f1363n0;
        }

        /* renamed from: p */
        public void mo1955p(View view) {
            C1050jc jcVar = this.f1347X;
            int indexOfChild = RecyclerView.this.indexOfChild(view);
            if (indexOfChild >= 0) {
                if (jcVar.f8344b.mo7603d(indexOfChild)) {
                    jcVar.mo7593c(view);
                }
                ((C0219e) jcVar.f8343a).mo1827b(indexOfChild);
            }
        }

        /* renamed from: q */
        public int mo1956q() {
            return this.f1361l0;
        }

        /* renamed from: r */
        public boolean mo1957r() {
            int f = mo1921f();
            for (int i = 0; i < f; i++) {
                ViewGroup.LayoutParams layoutParams = mo1925g(i).getLayoutParams();
                if (layoutParams.width < 0 && layoutParams.height < 0) {
                    return true;
                }
            }
            return false;
        }

        /* renamed from: s */
        public boolean mo1958s() {
            return this.f1355f0;
        }

        /* renamed from: t */
        public boolean mo1585t() {
            return this.f1356g0;
        }

        /* renamed from: u */
        public final boolean mo1959u() {
            return this.f1358i0;
        }

        /* renamed from: v */
        public boolean mo1960v() {
            return false;
        }

        /* renamed from: w */
        public boolean mo1961w() {
            return this.f1357h0;
        }

        /* renamed from: x */
        public boolean mo1962x() {
            C0249z zVar = this.f1353d0;
            return zVar != null && zVar.f1395e;
        }

        /* renamed from: y */
        public boolean mo1963y() {
            return false;
        }

        @Deprecated
        /* renamed from: z */
        public void mo1964z() {
        }

        /* renamed from: a */
        public void mo1882a(C0244v vVar) {
            for (int f = mo1921f() - 1; f >= 0; f--) {
                View g = mo1925g(f);
                C0218d0 childViewHolderInt = RecyclerView.getChildViewHolderInt(g);
                if (!childViewHolderInt.mo1821w()) {
                    if (!childViewHolderInt.mo1813p() || childViewHolderInt.mo1815r() || this.f1348Y.mAdapter.f1337b) {
                        mo1913d(f);
                        vVar.mo1993b(g);
                        this.f1348Y.mViewInfoStore.mo5097c(childViewHolderInt);
                    } else {
                        mo1947l(f);
                        vVar.mo1989a(childViewHolderInt);
                    }
                }
            }
        }

        /* renamed from: a */
        public void mo1883a(C0244v vVar, C0212a0 a0Var, C0759g8 g8Var) {
            if (this.f1348Y.canScrollVertically(-1) || this.f1348Y.canScrollHorizontally(-1)) {
                g8Var.f6028a.addAction(8192);
                g8Var.f6028a.setScrollable(true);
            }
            if (this.f1348Y.canScrollVertically(1) || this.f1348Y.canScrollHorizontally(1)) {
                g8Var.f6028a.addAction(4096);
                g8Var.f6028a.setScrollable(true);
            }
            int b = mo1511b(vVar, a0Var);
            int a = mo1493a(vVar, a0Var);
            boolean v = mo1960v();
            g8Var.mo6038a((Object) Build.VERSION.SDK_INT >= 21 ? new C0759g8.C0761b(AccessibilityNodeInfo.CollectionInfo.obtain(b, a, v, mo1952o())) : new C0759g8.C0761b(AccessibilityNodeInfo.CollectionInfo.obtain(b, a, v)));
        }

        /* JADX WARNING: Code restructure failed: missing block: B:23:0x00bb, code lost:
            if (r14 == false) goto L_0x00c2;
         */
        /* renamed from: a */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean mo1894a(androidx.recyclerview.widget.RecyclerView r10, android.view.View r11, android.graphics.Rect r12, boolean r13, boolean r14) {
            /*
                r9 = this;
                r0 = 2
                int[] r0 = new int[r0]
                int r1 = r9.getPaddingLeft()
                int r2 = r9.getPaddingTop()
                int r3 = r9.mo1954p()
                int r4 = r9.getPaddingRight()
                int r3 = r3 - r4
                int r4 = r9.mo1936i()
                int r5 = r9.getPaddingBottom()
                int r4 = r4 - r5
                int r5 = r11.getLeft()
                int r6 = r12.left
                int r5 = r5 + r6
                int r6 = r11.getScrollX()
                int r5 = r5 - r6
                int r6 = r11.getTop()
                int r7 = r12.top
                int r6 = r6 + r7
                int r11 = r11.getScrollY()
                int r6 = r6 - r11
                int r11 = r12.width()
                int r11 = r11 + r5
                int r12 = r12.height()
                int r12 = r12 + r6
                int r5 = r5 - r1
                r1 = 0
                int r7 = java.lang.Math.min(r1, r5)
                int r6 = r6 - r2
                int r2 = java.lang.Math.min(r1, r6)
                int r11 = r11 - r3
                int r3 = java.lang.Math.max(r1, r11)
                int r12 = r12 - r4
                int r12 = java.lang.Math.max(r1, r12)
                int r4 = r9.mo1945l()
                r8 = 1
                if (r4 != r8) goto L_0x0063
                if (r3 == 0) goto L_0x005e
                goto L_0x006b
            L_0x005e:
                int r3 = java.lang.Math.max(r7, r11)
                goto L_0x006b
            L_0x0063:
                if (r7 == 0) goto L_0x0066
                goto L_0x006a
            L_0x0066:
                int r7 = java.lang.Math.min(r5, r3)
            L_0x006a:
                r3 = r7
            L_0x006b:
                if (r2 == 0) goto L_0x006e
                goto L_0x0072
            L_0x006e:
                int r2 = java.lang.Math.min(r6, r12)
            L_0x0072:
                r0[r1] = r3
                r0[r8] = r2
                r11 = r0[r1]
                r12 = r0[r8]
                if (r14 == 0) goto L_0x00bd
                android.view.View r14 = r10.getFocusedChild()
                if (r14 != 0) goto L_0x0084
            L_0x0082:
                r14 = 0
                goto L_0x00bb
            L_0x0084:
                int r0 = r9.getPaddingLeft()
                int r2 = r9.getPaddingTop()
                int r3 = r9.mo1954p()
                int r4 = r9.getPaddingRight()
                int r3 = r3 - r4
                int r4 = r9.mo1936i()
                int r5 = r9.getPaddingBottom()
                int r4 = r4 - r5
                androidx.recyclerview.widget.RecyclerView r5 = r9.f1348Y
                android.graphics.Rect r5 = r5.mTempRect
                r9.mo1901b((android.view.View) r14, (android.graphics.Rect) r5)
                int r14 = r5.left
                int r14 = r14 - r11
                if (r14 >= r3) goto L_0x0082
                int r14 = r5.right
                int r14 = r14 - r11
                if (r14 <= r0) goto L_0x0082
                int r14 = r5.top
                int r14 = r14 - r12
                if (r14 >= r4) goto L_0x0082
                int r14 = r5.bottom
                int r14 = r14 - r12
                if (r14 > r2) goto L_0x00ba
                goto L_0x0082
            L_0x00ba:
                r14 = 1
            L_0x00bb:
                if (r14 == 0) goto L_0x00c2
            L_0x00bd:
                if (r11 != 0) goto L_0x00c3
                if (r12 == 0) goto L_0x00c2
                goto L_0x00c3
            L_0x00c2:
                return r1
            L_0x00c3:
                if (r13 == 0) goto L_0x00c9
                r10.scrollBy(r11, r12)
                goto L_0x00cc
            L_0x00c9:
                r10.smoothScrollBy(r11, r12)
            L_0x00cc:
                return r8
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.C0232o.mo1894a(androidx.recyclerview.widget.RecyclerView, android.view.View, android.graphics.Rect, boolean, boolean):boolean");
        }
    }

    /* renamed from: androidx.recyclerview.widget.RecyclerView$g */
    public static abstract class C0221g<VH extends C0218d0> {

        /* renamed from: a */
        public final C0222h f1336a = new C0222h();

        /* renamed from: b */
        public boolean f1337b = false;

        /* renamed from: a */
        public abstract int mo1833a();

        /* renamed from: a */
        public long mo1834a(int i) {
            return -1;
        }

        /* renamed from: a */
        public void mo1836a(VH vh) {
        }

        /* renamed from: a */
        public final void mo1837a(VH vh, int i) {
            vh.f1318Z = i;
            if (this.f1337b) {
                vh.f1320b0 = mo1834a(i);
            }
            vh.mo1801a(1, 519);
            int i2 = Build.VERSION.SDK_INT;
            Trace.beginSection(RecyclerView.TRACE_BIND_VIEW_TAG);
            vh.mo1810m();
            mo1841b(vh, i);
            List<Object> list = vh.f1326h0;
            if (list != null) {
                list.clear();
            }
            vh.f1325g0 &= -1025;
            ViewGroup.LayoutParams layoutParams = vh.f1316X.getLayoutParams();
            if (layoutParams instanceof C0237p) {
                ((C0237p) layoutParams).f1373Z = true;
            }
            int i3 = Build.VERSION.SDK_INT;
            Trace.endSection();
        }

        /* renamed from: a */
        public void mo1838a(RecyclerView recyclerView) {
        }

        /* renamed from: b */
        public int mo1839b(int i) {
            return 0;
        }

        /* renamed from: b */
        public abstract VH mo1840b(ViewGroup viewGroup, int i);

        /* renamed from: b */
        public abstract void mo1841b(VH vh, int i);

        /* renamed from: b */
        public void mo1842b(RecyclerView recyclerView) {
        }

        /* renamed from: b */
        public boolean mo1843b() {
            return false;
        }

        /* renamed from: c */
        public void mo1844c() {
        }

        /* renamed from: d */
        public void mo1845d() {
        }

        /* renamed from: a */
        public final VH mo1835a(ViewGroup viewGroup, int i) {
            try {
                int i2 = Build.VERSION.SDK_INT;
                Trace.beginSection(RecyclerView.TRACE_CREATE_VIEW_TAG);
                VH b = mo1840b(viewGroup, i);
                if (b.f1316X.getParent() == null) {
                    b.f1321c0 = i;
                    return b;
                }
                throw new IllegalStateException("ViewHolder views must not be attached when created. Ensure that you are not passing 'true' to the attachToRoot parameter of LayoutInflater.inflate(..., boolean attachToRoot)");
            } finally {
                int i3 = Build.VERSION.SDK_INT;
                Trace.endSection();
            }
        }
    }
}
