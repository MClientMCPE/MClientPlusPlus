package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.PointF;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import p000.C1692qc;

public class LinearLayoutManager extends RecyclerView.C0232o implements C1754rc, RecyclerView.C0249z.C0251b {

    /* renamed from: A0 */
    public C0209d f1247A0 = null;

    /* renamed from: B0 */
    public final C0206a f1248B0 = new C0206a();

    /* renamed from: C0 */
    public final C0207b f1249C0 = new C0207b();

    /* renamed from: D0 */
    public int f1250D0 = 2;

    /* renamed from: E0 */
    public int[] f1251E0 = new int[2];

    /* renamed from: p0 */
    public int f1252p0 = 1;

    /* renamed from: q0 */
    public C0208c f1253q0;

    /* renamed from: r0 */
    public C2344yc f1254r0;

    /* renamed from: s0 */
    public boolean f1255s0;

    /* renamed from: t0 */
    public boolean f1256t0 = false;

    /* renamed from: u0 */
    public boolean f1257u0 = false;

    /* renamed from: v0 */
    public boolean f1258v0 = false;

    /* renamed from: w0 */
    public boolean f1259w0 = true;

    /* renamed from: x0 */
    public int f1260x0 = -1;

    /* renamed from: y0 */
    public int f1261y0 = RecyclerView.UNDEFINED_DURATION;

    /* renamed from: z0 */
    public boolean f1262z0;

    /* renamed from: androidx.recyclerview.widget.LinearLayoutManager$a */
    public static class C0206a {

        /* renamed from: a */
        public C2344yc f1263a;

        /* renamed from: b */
        public int f1264b;

        /* renamed from: c */
        public int f1265c;

        /* renamed from: d */
        public boolean f1266d;

        /* renamed from: e */
        public boolean f1267e;

        public C0206a() {
            mo1589b();
        }

        /* renamed from: a */
        public void mo1586a() {
            this.f1265c = this.f1266d ? this.f1263a.mo12235b() : this.f1263a.mo12243f();
        }

        /* renamed from: a */
        public void mo1587a(View view, int i) {
            if (this.f1266d) {
                this.f1265c = this.f1263a.mo12898h() + this.f1263a.mo12233a(view);
            } else {
                this.f1265c = this.f1263a.mo12240d(view);
            }
            this.f1264b = i;
        }

        /* renamed from: a */
        public boolean mo1588a(View view, RecyclerView.C0212a0 a0Var) {
            RecyclerView.C0237p pVar = (RecyclerView.C0237p) view.getLayoutParams();
            return !pVar.mo1972p() && pVar.mo1970n() >= 0 && pVar.mo1970n() < a0Var.mo1790a();
        }

        /* renamed from: b */
        public void mo1589b() {
            this.f1264b = -1;
            this.f1265c = RecyclerView.UNDEFINED_DURATION;
            this.f1266d = false;
            this.f1267e = false;
        }

        /* renamed from: b */
        public void mo1590b(View view, int i) {
            int i2;
            int h = this.f1263a.mo12898h();
            if (h >= 0) {
                mo1587a(view, i);
                return;
            }
            this.f1264b = i;
            if (this.f1266d) {
                int b = (this.f1263a.mo12235b() - h) - this.f1263a.mo12233a(view);
                this.f1265c = this.f1263a.mo12235b() - b;
                if (b > 0) {
                    int b2 = this.f1265c - this.f1263a.mo12236b(view);
                    int f = this.f1263a.mo12243f();
                    int min = b2 - (Math.min(this.f1263a.mo12240d(view) - f, 0) + f);
                    if (min < 0) {
                        i2 = Math.min(b, -min) + this.f1265c;
                    } else {
                        return;
                    }
                } else {
                    return;
                }
            } else {
                int d = this.f1263a.mo12240d(view);
                int f2 = d - this.f1263a.mo12243f();
                this.f1265c = d;
                if (f2 > 0) {
                    int b3 = (this.f1263a.mo12235b() - Math.min(0, (this.f1263a.mo12235b() - h) - this.f1263a.mo12233a(view))) - (this.f1263a.mo12236b(view) + d);
                    if (b3 < 0) {
                        i2 = this.f1265c - Math.min(f2, -b3);
                    } else {
                        return;
                    }
                } else {
                    return;
                }
            }
            this.f1265c = i2;
        }

        public String toString() {
            StringBuilder a = C0789gk.m5562a("AnchorInfo{mPosition=");
            a.append(this.f1264b);
            a.append(", mCoordinate=");
            a.append(this.f1265c);
            a.append(", mLayoutFromEnd=");
            a.append(this.f1266d);
            a.append(", mValid=");
            a.append(this.f1267e);
            a.append('}');
            return a.toString();
        }
    }

    /* renamed from: androidx.recyclerview.widget.LinearLayoutManager$b */
    public static class C0207b {

        /* renamed from: a */
        public int f1268a;

        /* renamed from: b */
        public boolean f1269b;

        /* renamed from: c */
        public boolean f1270c;

        /* renamed from: d */
        public boolean f1271d;
    }

    @SuppressLint({"BanParcelableUsage"})
    /* renamed from: androidx.recyclerview.widget.LinearLayoutManager$d */
    public static class C0209d implements Parcelable {
        public static final Parcelable.Creator<C0209d> CREATOR = new C0210a();

        /* renamed from: X */
        public int f1285X;

        /* renamed from: Y */
        public int f1286Y;

        /* renamed from: Z */
        public boolean f1287Z;

        /* renamed from: androidx.recyclerview.widget.LinearLayoutManager$d$a */
        public static class C0210a implements Parcelable.Creator<C0209d> {
            public Object createFromParcel(Parcel parcel) {
                return new C0209d(parcel);
            }

            public Object[] newArray(int i) {
                return new C0209d[i];
            }
        }

        public C0209d() {
        }

        public C0209d(Parcel parcel) {
            this.f1285X = parcel.readInt();
            this.f1286Y = parcel.readInt();
            this.f1287Z = parcel.readInt() != 1 ? false : true;
        }

        public C0209d(C0209d dVar) {
            this.f1285X = dVar.f1285X;
            this.f1286Y = dVar.f1286Y;
            this.f1287Z = dVar.f1287Z;
        }

        public int describeContents() {
            return 0;
        }

        /* renamed from: q */
        public boolean mo1596q() {
            return this.f1285X >= 0;
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeInt(this.f1285X);
            parcel.writeInt(this.f1286Y);
            parcel.writeInt(this.f1287Z ? 1 : 0);
        }
    }

    public LinearLayoutManager(int i, boolean z) {
        mo1584o(i);
        mo1566b(z);
    }

    public LinearLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        RecyclerView.C0232o.C0236d a = RecyclerView.C0232o.m1222a(context, attributeSet, i, i2);
        mo1584o(a.f1367a);
        mo1566b(a.f1369c);
        mo1519c(a.f1370d);
    }

    /* renamed from: B */
    public Parcelable mo1533B() {
        C0209d dVar = this.f1247A0;
        if (dVar != null) {
            return new C0209d(dVar);
        }
        C0209d dVar2 = new C0209d();
        if (mo1921f() > 0) {
            mo1536K();
            boolean z = this.f1255s0 ^ this.f1257u0;
            dVar2.f1287Z = z;
            if (z) {
                View P = mo1541P();
                dVar2.f1286Y = this.f1254r0.mo12235b() - this.f1254r0.mo12233a(P);
                dVar2.f1285X = mo1949m(P);
            } else {
                View Q = mo1542Q();
                dVar2.f1285X = mo1949m(Q);
                dVar2.f1286Y = this.f1254r0.mo12240d(Q) - this.f1254r0.mo12243f();
            }
        } else {
            dVar2.f1285X = -1;
        }
        return dVar2;
    }

    /* renamed from: G */
    public boolean mo1534G() {
        return (mo1939j() == 1073741824 || mo1956q() == 1073741824 || !mo1957r()) ? false : true;
    }

    /* renamed from: I */
    public boolean mo1488I() {
        return this.f1247A0 == null && this.f1255s0 == this.f1258v0;
    }

    /* renamed from: J */
    public C0208c mo1535J() {
        return new C0208c();
    }

    /* renamed from: K */
    public void mo1536K() {
        if (this.f1253q0 == null) {
            this.f1253q0 = mo1535J();
        }
    }

    /* renamed from: L */
    public final View mo1537L() {
        return mo1575f(0, mo1921f());
    }

    /* renamed from: M */
    public int mo1538M() {
        View a = mo1551a(0, mo1921f(), false, true);
        if (a == null) {
            return -1;
        }
        return mo1949m(a);
    }

    /* renamed from: N */
    public final View mo1539N() {
        return mo1575f(mo1921f() - 1, -1);
    }

    /* renamed from: O */
    public int mo1540O() {
        View a = mo1551a(mo1921f() - 1, -1, false, true);
        if (a == null) {
            return -1;
        }
        return mo1949m(a);
    }

    /* renamed from: P */
    public final View mo1541P() {
        return mo1925g(this.f1257u0 ? 0 : mo1921f() - 1);
    }

    /* renamed from: Q */
    public final View mo1542Q() {
        return mo1925g(this.f1257u0 ? mo1921f() - 1 : 0);
    }

    /* renamed from: R */
    public int mo1543R() {
        return this.f1252p0;
    }

    /* renamed from: S */
    public boolean mo1544S() {
        return mo1945l() == 1;
    }

    /* renamed from: T */
    public boolean mo1545T() {
        return this.f1259w0;
    }

    /* renamed from: U */
    public boolean mo1546U() {
        return this.f1254r0.mo12239d() == 0 && this.f1254r0.mo12232a() == 0;
    }

    /* renamed from: V */
    public final void mo1547V() {
        this.f1257u0 = (this.f1252p0 == 1 || !mo1544S()) ? this.f1256t0 : !this.f1256t0;
    }

    /* renamed from: a */
    public int mo1492a(int i, RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var) {
        if (this.f1252p0 == 1) {
            return 0;
        }
        return mo1568c(i, vVar, a0Var);
    }

    /* renamed from: a */
    public final int mo1548a(int i, RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var, boolean z) {
        int b;
        int b2 = this.f1254r0.mo12235b() - i;
        if (b2 <= 0) {
            return 0;
        }
        int i2 = -mo1568c(-b2, vVar, a0Var);
        int i3 = i + i2;
        if (!z || (b = this.f1254r0.mo12235b() - i3) <= 0) {
            return i2;
        }
        this.f1254r0.mo12234a(b);
        return b + i2;
    }

    /* renamed from: a */
    public int mo1549a(RecyclerView.C0212a0 a0Var) {
        return mo1577h(a0Var);
    }

    /* renamed from: a */
    public View mo1551a(int i, int i2, boolean z, boolean z2) {
        mo1536K();
        int i3 = 320;
        int i4 = z ? 24579 : 320;
        if (!z2) {
            i3 = 0;
        }
        return (this.f1252p0 == 0 ? this.f1351b0 : this.f1352c0).mo4739a(i, i2, i4, i3);
    }

    /* renamed from: a */
    public View mo1496a(RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var, int i, int i2, int i3) {
        mo1536K();
        int f = this.f1254r0.mo12243f();
        int b = this.f1254r0.mo12235b();
        int i4 = i2 > i ? 1 : -1;
        View view = null;
        View view2 = null;
        while (i != i2) {
            View g = mo1925g(i);
            int m = mo1949m(g);
            if (m >= 0 && m < i3) {
                if (((RecyclerView.C0237p) g.getLayoutParams()).mo1972p()) {
                    if (view2 == null) {
                        view2 = g;
                    }
                } else if (this.f1254r0.mo12240d(g) < b && this.f1254r0.mo12233a(g) >= f) {
                    return g;
                } else {
                    if (view == null) {
                        view = g;
                    }
                }
            }
            i += i4;
        }
        return view != null ? view : view2;
    }

    /* renamed from: a */
    public View mo1552a(boolean z, boolean z2) {
        int f;
        int i;
        if (this.f1257u0) {
            f = 0;
            i = mo1921f();
        } else {
            f = mo1921f() - 1;
            i = -1;
        }
        return mo1551a(f, i, z, z2);
    }

    /* renamed from: a */
    public void mo1553a(int i, int i2, RecyclerView.C0212a0 a0Var, RecyclerView.C0232o.C0235c cVar) {
        if (this.f1252p0 != 0) {
            i = i2;
        }
        if (mo1921f() != 0 && i != 0) {
            mo1536K();
            mo1554a(i > 0 ? 1 : -1, Math.abs(i), true, a0Var);
            mo1501a(a0Var, this.f1253q0, cVar);
        }
    }

    /* renamed from: a */
    public final void mo1554a(int i, int i2, boolean z, RecyclerView.C0212a0 a0Var) {
        int i3;
        this.f1253q0.f1284m = mo1546U();
        this.f1253q0.f1277f = i;
        int[] iArr = this.f1251E0;
        boolean z2 = false;
        iArr[0] = 0;
        iArr[1] = 0;
        mo1558a(a0Var, iArr);
        int max = Math.max(0, this.f1251E0[0]);
        int max2 = Math.max(0, this.f1251E0[1]);
        if (i == 1) {
            z2 = true;
        }
        this.f1253q0.f1279h = z2 ? max2 : max;
        C0208c cVar = this.f1253q0;
        if (!z2) {
            max = max2;
        }
        cVar.f1280i = max;
        int i4 = -1;
        if (z2) {
            C0208c cVar2 = this.f1253q0;
            cVar2.f1279h = this.f1254r0.mo12237c() + cVar2.f1279h;
            View P = mo1541P();
            C0208c cVar3 = this.f1253q0;
            if (!this.f1257u0) {
                i4 = 1;
            }
            cVar3.f1276e = i4;
            C0208c cVar4 = this.f1253q0;
            int m = mo1949m(P);
            C0208c cVar5 = this.f1253q0;
            cVar4.f1275d = m + cVar5.f1276e;
            cVar5.f1273b = this.f1254r0.mo12233a(P);
            i3 = this.f1254r0.mo12233a(P) - this.f1254r0.mo12235b();
        } else {
            View Q = mo1542Q();
            C0208c cVar6 = this.f1253q0;
            cVar6.f1279h = this.f1254r0.mo12243f() + cVar6.f1279h;
            C0208c cVar7 = this.f1253q0;
            if (this.f1257u0) {
                i4 = 1;
            }
            cVar7.f1276e = i4;
            C0208c cVar8 = this.f1253q0;
            int m2 = mo1949m(Q);
            C0208c cVar9 = this.f1253q0;
            cVar8.f1275d = m2 + cVar9.f1276e;
            cVar9.f1273b = this.f1254r0.mo12240d(Q);
            i3 = (-this.f1254r0.mo12240d(Q)) + this.f1254r0.mo12243f();
        }
        C0208c cVar10 = this.f1253q0;
        cVar10.f1274c = i2;
        if (z) {
            cVar10.f1274c -= i3;
        }
        this.f1253q0.f1278g = i3;
    }

    /* renamed from: a */
    public void mo1555a(int i, RecyclerView.C0232o.C0235c cVar) {
        boolean z;
        int i2;
        C0209d dVar = this.f1247A0;
        int i3 = -1;
        if (dVar == null || !dVar.mo1596q()) {
            mo1547V();
            z = this.f1257u0;
            i2 = this.f1260x0;
            if (i2 == -1) {
                i2 = z ? i - 1 : 0;
            }
        } else {
            C0209d dVar2 = this.f1247A0;
            z = dVar2.f1287Z;
            i2 = dVar2.f1285X;
        }
        if (!z) {
            i3 = 1;
        }
        int i4 = i2;
        for (int i5 = 0; i5 < this.f1250D0 && i4 >= 0 && i4 < i; i5++) {
            ((C1692qc.C1694b) cVar).mo10309a(i4, 0);
            i4 += i3;
        }
    }

    /* renamed from: a */
    public void mo1556a(Parcelable parcelable) {
        if (parcelable instanceof C0209d) {
            this.f1247A0 = (C0209d) parcelable;
            mo1868E();
        }
    }

    /* renamed from: a */
    public void mo1501a(RecyclerView.C0212a0 a0Var, C0208c cVar, RecyclerView.C0232o.C0235c cVar2) {
        int i = cVar.f1275d;
        if (i >= 0 && i < a0Var.mo1790a()) {
            ((C1692qc.C1694b) cVar2).mo10309a(i, Math.max(0, cVar.f1278g));
        }
    }

    /* renamed from: a */
    public void mo1558a(RecyclerView.C0212a0 a0Var, int[] iArr) {
        int i;
        int k = mo1581k(a0Var);
        if (this.f1253q0.f1277f == -1) {
            i = 0;
        } else {
            i = k;
            k = 0;
        }
        iArr[0] = k;
        iArr[1] = i;
    }

    /* renamed from: a */
    public final void mo1559a(RecyclerView.C0244v vVar, int i, int i2) {
        if (i != i2) {
            if (i2 > i) {
                for (int i3 = i2 - 1; i3 >= i; i3--) {
                    mo1872a(i3, vVar);
                }
                return;
            }
            while (i > i2) {
                mo1872a(i, vVar);
                i--;
            }
        }
    }

    /* renamed from: a */
    public void mo1503a(RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var, C0206a aVar, int i) {
    }

    /* renamed from: a */
    public void mo1504a(RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var, C0208c cVar, C0207b bVar) {
        int i;
        int i2;
        int i3;
        int i4;
        int i5;
        View a = cVar.mo1592a(vVar);
        if (a == null) {
            bVar.f1269b = true;
            return;
        }
        RecyclerView.C0237p pVar = (RecyclerView.C0237p) a.getLayoutParams();
        if (cVar.f1283l == null) {
            if (this.f1257u0 == (cVar.f1277f == -1)) {
                mo1908c(a);
            } else {
                mo1899b(a, 0);
            }
        } else {
            if (this.f1257u0 == (cVar.f1277f == -1)) {
                mo1898b(a);
            } else {
                mo1873a(a, 0);
            }
        }
        mo1900b(a, 0, 0);
        bVar.f1268a = this.f1254r0.mo12236b(a);
        if (this.f1252p0 == 1) {
            if (mo1544S()) {
                i5 = mo1954p() - getPaddingRight();
                i4 = i5 - this.f1254r0.mo12238c(a);
            } else {
                i4 = getPaddingLeft();
                i5 = this.f1254r0.mo12238c(a) + i4;
            }
            int i6 = cVar.f1277f;
            int i7 = cVar.f1273b;
            if (i6 == -1) {
                i = i7;
                i2 = i5;
                i3 = i7 - bVar.f1268a;
            } else {
                i3 = i7;
                i2 = i5;
                i = bVar.f1268a + i7;
            }
        } else {
            int paddingTop = getPaddingTop();
            int c = this.f1254r0.mo12238c(a) + paddingTop;
            int i8 = cVar.f1277f;
            int i9 = cVar.f1273b;
            if (i8 == -1) {
                i2 = i9;
                i3 = paddingTop;
                i = c;
                i4 = i9 - bVar.f1268a;
            } else {
                i3 = paddingTop;
                i2 = bVar.f1268a + i9;
                i = c;
                i4 = i9;
            }
        }
        mo1874a(a, i4, i3, i2, i);
        if (pVar.mo1972p() || pVar.mo1971o()) {
            bVar.f1270c = true;
        }
        bVar.f1271d = a.hasFocusable();
    }

    /* renamed from: a */
    public void mo1562a(String str) {
        RecyclerView recyclerView;
        if (this.f1247A0 == null && (recyclerView = this.f1348Y) != null) {
            recyclerView.assertNotInLayoutOrScroll(str);
        }
    }

    /* renamed from: b */
    public int mo1509b(int i, RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var) {
        if (this.f1252p0 == 0) {
            return 0;
        }
        return mo1568c(i, vVar, a0Var);
    }

    /* renamed from: b */
    public final int mo1563b(int i, RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var, boolean z) {
        int f;
        int f2 = i - this.f1254r0.mo12243f();
        if (f2 <= 0) {
            return 0;
        }
        int i2 = -mo1568c(f2, vVar, a0Var);
        int i3 = i + i2;
        if (!z || (f = i3 - this.f1254r0.mo12243f()) <= 0) {
            return i2;
        }
        this.f1254r0.mo12234a(-f);
        return i2 - f;
    }

    /* renamed from: b */
    public int mo1510b(RecyclerView.C0212a0 a0Var) {
        return mo1579i(a0Var);
    }

    /* renamed from: b */
    public View mo1564b(boolean z, boolean z2) {
        int i;
        int f;
        if (this.f1257u0) {
            i = mo1921f() - 1;
            f = -1;
        } else {
            i = 0;
            f = mo1921f();
        }
        return mo1551a(i, f, z, z2);
    }

    /* renamed from: b */
    public void mo1565b(RecyclerView recyclerView, RecyclerView.C0244v vVar) {
        mo1964z();
        if (this.f1262z0) {
            mo1903b(vVar);
            vVar.mo1985a();
        }
    }

    /* renamed from: b */
    public void mo1566b(boolean z) {
        mo1562a((String) null);
        if (z != this.f1256t0) {
            this.f1256t0 = z;
            mo1868E();
        }
    }

    /* renamed from: b */
    public boolean mo1567b() {
        return this.f1252p0 == 0;
    }

    /* renamed from: c */
    public int mo1568c(int i, RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var) {
        if (mo1921f() == 0 || i == 0) {
            return 0;
        }
        mo1536K();
        this.f1253q0.f1272a = true;
        int i2 = i > 0 ? 1 : -1;
        int abs = Math.abs(i);
        mo1554a(i2, abs, true, a0Var);
        C0208c cVar = this.f1253q0;
        int a = mo1550a(vVar, cVar, a0Var, false) + cVar.f1278g;
        if (a < 0) {
            return 0;
        }
        if (abs > a) {
            i = i2 * a;
        }
        this.f1254r0.mo12234a(-i);
        this.f1253q0.f1282k = i;
        return i;
    }

    /* renamed from: c */
    public int mo1515c(RecyclerView.C0212a0 a0Var) {
        return mo1580j(a0Var);
    }

    /* renamed from: c */
    public PointF mo1569c(int i) {
        if (mo1921f() == 0) {
            return null;
        }
        boolean z = false;
        int i2 = 1;
        if (i < mo1949m(mo1925g(0))) {
            z = true;
        }
        if (z != this.f1257u0) {
            i2 = -1;
        }
        return this.f1252p0 == 0 ? new PointF((float) i2, 0.0f) : new PointF(0.0f, (float) i2);
    }

    /* JADX WARNING: Removed duplicated region for block: B:119:0x020b  */
    /* JADX WARNING: Removed duplicated region for block: B:80:0x0179  */
    /* renamed from: c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo1517c(androidx.recyclerview.widget.RecyclerView.C0244v r17, androidx.recyclerview.widget.RecyclerView.C0212a0 r18) {
        /*
            r16 = this;
            r0 = r16
            r1 = r17
            r2 = r18
            androidx.recyclerview.widget.LinearLayoutManager$d r3 = r0.f1247A0
            r4 = -1
            if (r3 != 0) goto L_0x000f
            int r3 = r0.f1260x0
            if (r3 == r4) goto L_0x0019
        L_0x000f:
            int r3 = r18.mo1790a()
            if (r3 != 0) goto L_0x0019
            r16.mo1903b((androidx.recyclerview.widget.RecyclerView.C0244v) r17)
            return
        L_0x0019:
            androidx.recyclerview.widget.LinearLayoutManager$d r3 = r0.f1247A0
            if (r3 == 0) goto L_0x0029
            boolean r3 = r3.mo1596q()
            if (r3 == 0) goto L_0x0029
            androidx.recyclerview.widget.LinearLayoutManager$d r3 = r0.f1247A0
            int r3 = r3.f1285X
            r0.f1260x0 = r3
        L_0x0029:
            r16.mo1536K()
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f1253q0
            r5 = 0
            r3.f1272a = r5
            r16.mo1547V()
            android.view.View r3 = r16.mo1934h()
            androidx.recyclerview.widget.LinearLayoutManager$a r6 = r0.f1248B0
            boolean r6 = r6.f1267e
            r7 = -2147483648(0xffffffff80000000, float:-0.0)
            r8 = 1
            if (r6 == 0) goto L_0x0073
            int r6 = r0.f1260x0
            if (r6 != r4) goto L_0x0073
            androidx.recyclerview.widget.LinearLayoutManager$d r6 = r0.f1247A0
            if (r6 == 0) goto L_0x004a
            goto L_0x0073
        L_0x004a:
            if (r3 == 0) goto L_0x021f
            yc r6 = r0.f1254r0
            int r6 = r6.mo12240d(r3)
            yc r9 = r0.f1254r0
            int r9 = r9.mo12235b()
            if (r6 >= r9) goto L_0x0068
            yc r6 = r0.f1254r0
            int r6 = r6.mo12233a((android.view.View) r3)
            yc r9 = r0.f1254r0
            int r9 = r9.mo12243f()
            if (r6 > r9) goto L_0x021f
        L_0x0068:
            androidx.recyclerview.widget.LinearLayoutManager$a r6 = r0.f1248B0
            int r9 = r0.mo1949m((android.view.View) r3)
            r6.mo1590b(r3, r9)
            goto L_0x021f
        L_0x0073:
            androidx.recyclerview.widget.LinearLayoutManager$a r3 = r0.f1248B0
            r3.mo1589b()
            androidx.recyclerview.widget.LinearLayoutManager$a r3 = r0.f1248B0
            boolean r6 = r0.f1257u0
            boolean r9 = r0.f1258v0
            r6 = r6 ^ r9
            r3.f1266d = r6
            boolean r6 = r2.f1296h
            if (r6 != 0) goto L_0x0174
            int r6 = r0.f1260x0
            if (r6 != r4) goto L_0x008b
            goto L_0x0174
        L_0x008b:
            if (r6 < 0) goto L_0x0170
            int r9 = r18.mo1790a()
            if (r6 < r9) goto L_0x0095
            goto L_0x0170
        L_0x0095:
            int r6 = r0.f1260x0
            r3.f1264b = r6
            androidx.recyclerview.widget.LinearLayoutManager$d r6 = r0.f1247A0
            if (r6 == 0) goto L_0x00c5
            boolean r6 = r6.mo1596q()
            if (r6 == 0) goto L_0x00c5
            androidx.recyclerview.widget.LinearLayoutManager$d r6 = r0.f1247A0
            boolean r6 = r6.f1287Z
            r3.f1266d = r6
            boolean r6 = r3.f1266d
            if (r6 == 0) goto L_0x00b9
            yc r6 = r0.f1254r0
            int r6 = r6.mo12235b()
            androidx.recyclerview.widget.LinearLayoutManager$d r9 = r0.f1247A0
            int r9 = r9.f1286Y
            goto L_0x0161
        L_0x00b9:
            yc r6 = r0.f1254r0
            int r6 = r6.mo12243f()
            androidx.recyclerview.widget.LinearLayoutManager$d r9 = r0.f1247A0
            int r9 = r9.f1286Y
            goto L_0x016b
        L_0x00c5:
            int r6 = r0.f1261y0
            if (r6 != r7) goto L_0x0153
            int r6 = r0.f1260x0
            android.view.View r6 = r0.mo1574f((int) r6)
            if (r6 == 0) goto L_0x0131
            yc r9 = r0.f1254r0
            int r9 = r9.mo12236b(r6)
            yc r10 = r0.f1254r0
            int r10 = r10.mo12245g()
            if (r9 <= r10) goto L_0x00e1
            goto L_0x014f
        L_0x00e1:
            yc r9 = r0.f1254r0
            int r9 = r9.mo12240d(r6)
            yc r10 = r0.f1254r0
            int r10 = r10.mo12243f()
            int r9 = r9 - r10
            if (r9 >= 0) goto L_0x00fc
            yc r6 = r0.f1254r0
            int r6 = r6.mo12243f()
            r3.f1265c = r6
            r3.f1266d = r5
            goto L_0x016e
        L_0x00fc:
            yc r9 = r0.f1254r0
            int r9 = r9.mo12235b()
            yc r10 = r0.f1254r0
            int r10 = r10.mo12233a((android.view.View) r6)
            int r9 = r9 - r10
            if (r9 >= 0) goto L_0x0116
            yc r6 = r0.f1254r0
            int r6 = r6.mo12235b()
            r3.f1265c = r6
            r3.f1266d = r8
            goto L_0x016e
        L_0x0116:
            boolean r9 = r3.f1266d
            if (r9 == 0) goto L_0x0128
            yc r9 = r0.f1254r0
            int r6 = r9.mo12233a((android.view.View) r6)
            yc r9 = r0.f1254r0
            int r9 = r9.mo12898h()
            int r9 = r9 + r6
            goto L_0x012e
        L_0x0128:
            yc r9 = r0.f1254r0
            int r9 = r9.mo12240d(r6)
        L_0x012e:
            r3.f1265c = r9
            goto L_0x016e
        L_0x0131:
            int r6 = r16.mo1921f()
            if (r6 <= 0) goto L_0x014f
            android.view.View r6 = r0.mo1925g((int) r5)
            int r6 = r0.mo1949m((android.view.View) r6)
            int r9 = r0.f1260x0
            if (r9 >= r6) goto L_0x0145
            r6 = 1
            goto L_0x0146
        L_0x0145:
            r6 = 0
        L_0x0146:
            boolean r9 = r0.f1257u0
            if (r6 != r9) goto L_0x014c
            r6 = 1
            goto L_0x014d
        L_0x014c:
            r6 = 0
        L_0x014d:
            r3.f1266d = r6
        L_0x014f:
            r3.mo1586a()
            goto L_0x016e
        L_0x0153:
            boolean r6 = r0.f1257u0
            r3.f1266d = r6
            if (r6 == 0) goto L_0x0163
            yc r6 = r0.f1254r0
            int r6 = r6.mo12235b()
            int r9 = r0.f1261y0
        L_0x0161:
            int r6 = r6 - r9
            goto L_0x016c
        L_0x0163:
            yc r6 = r0.f1254r0
            int r6 = r6.mo12243f()
            int r9 = r0.f1261y0
        L_0x016b:
            int r6 = r6 + r9
        L_0x016c:
            r3.f1265c = r6
        L_0x016e:
            r6 = 1
            goto L_0x0175
        L_0x0170:
            r0.f1260x0 = r4
            r0.f1261y0 = r7
        L_0x0174:
            r6 = 0
        L_0x0175:
            if (r6 == 0) goto L_0x0179
            goto L_0x021b
        L_0x0179:
            int r6 = r16.mo1921f()
            if (r6 != 0) goto L_0x0181
            goto L_0x0207
        L_0x0181:
            android.view.View r6 = r16.mo1934h()
            if (r6 == 0) goto L_0x0196
            boolean r9 = r3.mo1588a((android.view.View) r6, (androidx.recyclerview.widget.RecyclerView.C0212a0) r2)
            if (r9 == 0) goto L_0x0196
            int r9 = r0.mo1949m((android.view.View) r6)
            r3.mo1590b(r6, r9)
            goto L_0x0205
        L_0x0196:
            boolean r6 = r0.f1255s0
            boolean r9 = r0.f1258v0
            if (r6 == r9) goto L_0x019e
            goto L_0x0207
        L_0x019e:
            boolean r6 = r3.f1266d
            if (r6 == 0) goto L_0x01b0
            boolean r6 = r0.f1257u0
            if (r6 == 0) goto L_0x01ab
            android.view.View r6 = r16.mo1572d(r17, r18)
            goto L_0x01bd
        L_0x01ab:
            android.view.View r6 = r16.mo1573e(r17, r18)
            goto L_0x01bd
        L_0x01b0:
            boolean r6 = r0.f1257u0
            if (r6 == 0) goto L_0x01b9
            android.view.View r6 = r16.mo1573e(r17, r18)
            goto L_0x01bd
        L_0x01b9:
            android.view.View r6 = r16.mo1572d(r17, r18)
        L_0x01bd:
            if (r6 == 0) goto L_0x0207
            int r9 = r0.mo1949m((android.view.View) r6)
            r3.mo1587a((android.view.View) r6, (int) r9)
            boolean r9 = r2.f1296h
            if (r9 != 0) goto L_0x0205
            boolean r9 = r16.mo1488I()
            if (r9 == 0) goto L_0x0205
            yc r9 = r0.f1254r0
            int r9 = r9.mo12240d(r6)
            yc r10 = r0.f1254r0
            int r10 = r10.mo12235b()
            if (r9 >= r10) goto L_0x01ef
            yc r9 = r0.f1254r0
            int r6 = r9.mo12233a((android.view.View) r6)
            yc r9 = r0.f1254r0
            int r9 = r9.mo12243f()
            if (r6 >= r9) goto L_0x01ed
            goto L_0x01ef
        L_0x01ed:
            r6 = 0
            goto L_0x01f0
        L_0x01ef:
            r6 = 1
        L_0x01f0:
            if (r6 == 0) goto L_0x0205
            boolean r6 = r3.f1266d
            if (r6 == 0) goto L_0x01fd
            yc r6 = r0.f1254r0
            int r6 = r6.mo12235b()
            goto L_0x0203
        L_0x01fd:
            yc r6 = r0.f1254r0
            int r6 = r6.mo12243f()
        L_0x0203:
            r3.f1265c = r6
        L_0x0205:
            r6 = 1
            goto L_0x0208
        L_0x0207:
            r6 = 0
        L_0x0208:
            if (r6 == 0) goto L_0x020b
            goto L_0x021b
        L_0x020b:
            r3.mo1586a()
            boolean r6 = r0.f1258v0
            if (r6 == 0) goto L_0x0218
            int r6 = r18.mo1790a()
            int r6 = r6 + r4
            goto L_0x0219
        L_0x0218:
            r6 = 0
        L_0x0219:
            r3.f1264b = r6
        L_0x021b:
            androidx.recyclerview.widget.LinearLayoutManager$a r3 = r0.f1248B0
            r3.f1267e = r8
        L_0x021f:
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f1253q0
            int r6 = r3.f1282k
            if (r6 < 0) goto L_0x0227
            r6 = 1
            goto L_0x0228
        L_0x0227:
            r6 = -1
        L_0x0228:
            r3.f1277f = r6
            int[] r3 = r0.f1251E0
            r3[r5] = r5
            r3[r8] = r5
            r0.mo1558a((androidx.recyclerview.widget.RecyclerView.C0212a0) r2, (int[]) r3)
            int[] r3 = r0.f1251E0
            r3 = r3[r5]
            int r3 = java.lang.Math.max(r5, r3)
            yc r6 = r0.f1254r0
            int r6 = r6.mo12243f()
            int r6 = r6 + r3
            int[] r3 = r0.f1251E0
            r3 = r3[r8]
            int r3 = java.lang.Math.max(r5, r3)
            yc r9 = r0.f1254r0
            int r9 = r9.mo12237c()
            int r9 = r9 + r3
            boolean r3 = r2.f1296h
            if (r3 == 0) goto L_0x028c
            int r3 = r0.f1260x0
            if (r3 == r4) goto L_0x028c
            int r10 = r0.f1261y0
            if (r10 == r7) goto L_0x028c
            android.view.View r3 = r0.mo1574f((int) r3)
            if (r3 == 0) goto L_0x028c
            boolean r7 = r0.f1257u0
            if (r7 == 0) goto L_0x0277
            yc r7 = r0.f1254r0
            int r7 = r7.mo12235b()
            yc r10 = r0.f1254r0
            int r3 = r10.mo12233a((android.view.View) r3)
            int r7 = r7 - r3
            int r3 = r0.f1261y0
            goto L_0x0286
        L_0x0277:
            yc r7 = r0.f1254r0
            int r3 = r7.mo12240d(r3)
            yc r7 = r0.f1254r0
            int r7 = r7.mo12243f()
            int r3 = r3 - r7
            int r7 = r0.f1261y0
        L_0x0286:
            int r7 = r7 - r3
            if (r7 <= 0) goto L_0x028b
            int r6 = r6 + r7
            goto L_0x028c
        L_0x028b:
            int r9 = r9 - r7
        L_0x028c:
            androidx.recyclerview.widget.LinearLayoutManager$a r3 = r0.f1248B0
            boolean r3 = r3.f1266d
            if (r3 == 0) goto L_0x0297
            boolean r3 = r0.f1257u0
            if (r3 == 0) goto L_0x029b
            goto L_0x029d
        L_0x0297:
            boolean r3 = r0.f1257u0
            if (r3 == 0) goto L_0x029d
        L_0x029b:
            r3 = -1
            goto L_0x029e
        L_0x029d:
            r3 = 1
        L_0x029e:
            androidx.recyclerview.widget.LinearLayoutManager$a r7 = r0.f1248B0
            r0.mo1503a((androidx.recyclerview.widget.RecyclerView.C0244v) r1, (androidx.recyclerview.widget.RecyclerView.C0212a0) r2, (androidx.recyclerview.widget.LinearLayoutManager.C0206a) r7, (int) r3)
            r16.mo1882a((androidx.recyclerview.widget.RecyclerView.C0244v) r17)
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f1253q0
            boolean r7 = r16.mo1546U()
            r3.f1284m = r7
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f1253q0
            boolean r7 = r2.f1296h
            r3.f1281j = r7
            r3.f1280i = r5
            androidx.recyclerview.widget.LinearLayoutManager$a r3 = r0.f1248B0
            boolean r7 = r3.f1266d
            if (r7 == 0) goto L_0x0303
            int r7 = r3.f1264b
            int r3 = r3.f1265c
            r0.mo1578h(r7, r3)
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f1253q0
            r3.f1279h = r6
            r0.mo1550a((androidx.recyclerview.widget.RecyclerView.C0244v) r1, (androidx.recyclerview.widget.LinearLayoutManager.C0208c) r3, (androidx.recyclerview.widget.RecyclerView.C0212a0) r2, (boolean) r5)
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f1253q0
            int r6 = r3.f1273b
            int r7 = r3.f1275d
            int r3 = r3.f1274c
            if (r3 <= 0) goto L_0x02d5
            int r9 = r9 + r3
        L_0x02d5:
            androidx.recyclerview.widget.LinearLayoutManager$a r3 = r0.f1248B0
            int r10 = r3.f1264b
            int r3 = r3.f1265c
            r0.mo1576g(r10, r3)
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f1253q0
            r3.f1279h = r9
            int r9 = r3.f1275d
            int r10 = r3.f1276e
            int r9 = r9 + r10
            r3.f1275d = r9
            r0.mo1550a((androidx.recyclerview.widget.RecyclerView.C0244v) r1, (androidx.recyclerview.widget.LinearLayoutManager.C0208c) r3, (androidx.recyclerview.widget.RecyclerView.C0212a0) r2, (boolean) r5)
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f1253q0
            int r9 = r3.f1273b
            int r3 = r3.f1274c
            if (r3 <= 0) goto L_0x0349
            r0.mo1578h(r7, r6)
            androidx.recyclerview.widget.LinearLayoutManager$c r6 = r0.f1253q0
            r6.f1279h = r3
            r0.mo1550a((androidx.recyclerview.widget.RecyclerView.C0244v) r1, (androidx.recyclerview.widget.LinearLayoutManager.C0208c) r6, (androidx.recyclerview.widget.RecyclerView.C0212a0) r2, (boolean) r5)
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f1253q0
            int r6 = r3.f1273b
            goto L_0x0349
        L_0x0303:
            int r7 = r3.f1264b
            int r3 = r3.f1265c
            r0.mo1576g(r7, r3)
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f1253q0
            r3.f1279h = r9
            r0.mo1550a((androidx.recyclerview.widget.RecyclerView.C0244v) r1, (androidx.recyclerview.widget.LinearLayoutManager.C0208c) r3, (androidx.recyclerview.widget.RecyclerView.C0212a0) r2, (boolean) r5)
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f1253q0
            int r9 = r3.f1273b
            int r7 = r3.f1275d
            int r3 = r3.f1274c
            if (r3 <= 0) goto L_0x031c
            int r6 = r6 + r3
        L_0x031c:
            androidx.recyclerview.widget.LinearLayoutManager$a r3 = r0.f1248B0
            int r10 = r3.f1264b
            int r3 = r3.f1265c
            r0.mo1578h(r10, r3)
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f1253q0
            r3.f1279h = r6
            int r6 = r3.f1275d
            int r10 = r3.f1276e
            int r6 = r6 + r10
            r3.f1275d = r6
            r0.mo1550a((androidx.recyclerview.widget.RecyclerView.C0244v) r1, (androidx.recyclerview.widget.LinearLayoutManager.C0208c) r3, (androidx.recyclerview.widget.RecyclerView.C0212a0) r2, (boolean) r5)
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f1253q0
            int r6 = r3.f1273b
            int r3 = r3.f1274c
            if (r3 <= 0) goto L_0x0349
            r0.mo1576g(r7, r9)
            androidx.recyclerview.widget.LinearLayoutManager$c r7 = r0.f1253q0
            r7.f1279h = r3
            r0.mo1550a((androidx.recyclerview.widget.RecyclerView.C0244v) r1, (androidx.recyclerview.widget.LinearLayoutManager.C0208c) r7, (androidx.recyclerview.widget.RecyclerView.C0212a0) r2, (boolean) r5)
            androidx.recyclerview.widget.LinearLayoutManager$c r3 = r0.f1253q0
            int r9 = r3.f1273b
        L_0x0349:
            int r3 = r16.mo1921f()
            if (r3 <= 0) goto L_0x036d
            boolean r3 = r0.f1257u0
            boolean r7 = r0.f1258v0
            r3 = r3 ^ r7
            if (r3 == 0) goto L_0x0361
            int r3 = r0.mo1548a((int) r9, (androidx.recyclerview.widget.RecyclerView.C0244v) r1, (androidx.recyclerview.widget.RecyclerView.C0212a0) r2, (boolean) r8)
            int r6 = r6 + r3
            int r9 = r9 + r3
            int r3 = r0.mo1563b(r6, r1, r2, r5)
            goto L_0x036b
        L_0x0361:
            int r3 = r0.mo1563b(r6, r1, r2, r8)
            int r6 = r6 + r3
            int r9 = r9 + r3
            int r3 = r0.mo1548a((int) r9, (androidx.recyclerview.widget.RecyclerView.C0244v) r1, (androidx.recyclerview.widget.RecyclerView.C0212a0) r2, (boolean) r5)
        L_0x036b:
            int r6 = r6 + r3
            int r9 = r9 + r3
        L_0x036d:
            boolean r3 = r2.f1300l
            if (r3 == 0) goto L_0x0405
            int r3 = r16.mo1921f()
            if (r3 == 0) goto L_0x0405
            boolean r3 = r2.f1296h
            if (r3 != 0) goto L_0x0405
            boolean r3 = r16.mo1488I()
            if (r3 != 0) goto L_0x0383
            goto L_0x0405
        L_0x0383:
            java.util.List<androidx.recyclerview.widget.RecyclerView$d0> r3 = r1.f1384d
            int r7 = r3.size()
            android.view.View r10 = r0.mo1925g((int) r5)
            int r10 = r0.mo1949m((android.view.View) r10)
            r11 = 0
            r12 = 0
            r13 = 0
        L_0x0394:
            if (r11 >= r7) goto L_0x03c6
            java.lang.Object r14 = r3.get(r11)
            androidx.recyclerview.widget.RecyclerView$d0 r14 = (androidx.recyclerview.widget.RecyclerView.C0218d0) r14
            boolean r15 = r14.mo1815r()
            if (r15 == 0) goto L_0x03a3
            goto L_0x03c2
        L_0x03a3:
            int r15 = r14.mo1809l()
            if (r15 >= r10) goto L_0x03ab
            r15 = 1
            goto L_0x03ac
        L_0x03ab:
            r15 = 0
        L_0x03ac:
            boolean r8 = r0.f1257u0
            if (r15 == r8) goto L_0x03b2
            r8 = -1
            goto L_0x03b3
        L_0x03b2:
            r8 = 1
        L_0x03b3:
            yc r15 = r0.f1254r0
            android.view.View r14 = r14.f1316X
            int r14 = r15.mo12236b(r14)
            if (r8 != r4) goto L_0x03c0
            int r14 = r14 + r12
            r12 = r14
            goto L_0x03c2
        L_0x03c0:
            int r14 = r14 + r13
            r13 = r14
        L_0x03c2:
            int r11 = r11 + 1
            r8 = 1
            goto L_0x0394
        L_0x03c6:
            androidx.recyclerview.widget.LinearLayoutManager$c r4 = r0.f1253q0
            r4.f1283l = r3
            r3 = 0
            if (r12 <= 0) goto L_0x03e6
            android.view.View r4 = r16.mo1542Q()
            int r4 = r0.mo1949m((android.view.View) r4)
            r0.mo1578h(r4, r6)
            androidx.recyclerview.widget.LinearLayoutManager$c r4 = r0.f1253q0
            r4.f1279h = r12
            r4.f1274c = r5
            r4.mo1593a((android.view.View) r3)
            androidx.recyclerview.widget.LinearLayoutManager$c r4 = r0.f1253q0
            r0.mo1550a((androidx.recyclerview.widget.RecyclerView.C0244v) r1, (androidx.recyclerview.widget.LinearLayoutManager.C0208c) r4, (androidx.recyclerview.widget.RecyclerView.C0212a0) r2, (boolean) r5)
        L_0x03e6:
            if (r13 <= 0) goto L_0x0401
            android.view.View r4 = r16.mo1541P()
            int r4 = r0.mo1949m((android.view.View) r4)
            r0.mo1576g(r4, r9)
            androidx.recyclerview.widget.LinearLayoutManager$c r4 = r0.f1253q0
            r4.f1279h = r13
            r4.f1274c = r5
            r4.mo1593a((android.view.View) r3)
            androidx.recyclerview.widget.LinearLayoutManager$c r4 = r0.f1253q0
            r0.mo1550a((androidx.recyclerview.widget.RecyclerView.C0244v) r1, (androidx.recyclerview.widget.LinearLayoutManager.C0208c) r4, (androidx.recyclerview.widget.RecyclerView.C0212a0) r2, (boolean) r5)
        L_0x0401:
            androidx.recyclerview.widget.LinearLayoutManager$c r1 = r0.f1253q0
            r1.f1283l = r3
        L_0x0405:
            boolean r1 = r2.f1296h
            if (r1 != 0) goto L_0x0412
            yc r1 = r0.f1254r0
            int r2 = r1.mo12245g()
            r1.f17727b = r2
            goto L_0x0417
        L_0x0412:
            androidx.recyclerview.widget.LinearLayoutManager$a r1 = r0.f1248B0
            r1.mo1589b()
        L_0x0417:
            boolean r1 = r0.f1258v0
            r0.f1255s0 = r1
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.LinearLayoutManager.mo1517c(androidx.recyclerview.widget.RecyclerView$v, androidx.recyclerview.widget.RecyclerView$a0):void");
    }

    /* renamed from: c */
    public void mo1519c(boolean z) {
        mo1562a((String) null);
        if (this.f1258v0 != z) {
            this.f1258v0 = z;
            mo1868E();
        }
    }

    /* renamed from: c */
    public boolean mo1570c() {
        return this.f1252p0 == 1;
    }

    /* renamed from: d */
    public int mo1571d(RecyclerView.C0212a0 a0Var) {
        return mo1577h(a0Var);
    }

    /* renamed from: d */
    public final View mo1572d(RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var) {
        return mo1496a(vVar, a0Var, 0, mo1921f(), a0Var.mo1790a());
    }

    /* renamed from: d */
    public RecyclerView.C0237p mo1520d() {
        return new RecyclerView.C0237p(-2, -2);
    }

    /* renamed from: e */
    public int mo1521e(RecyclerView.C0212a0 a0Var) {
        return mo1579i(a0Var);
    }

    /* renamed from: e */
    public final View mo1573e(RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var) {
        return mo1496a(vVar, a0Var, mo1921f() - 1, -1, a0Var.mo1790a());
    }

    /* renamed from: f */
    public int mo1522f(RecyclerView.C0212a0 a0Var) {
        return mo1580j(a0Var);
    }

    /* renamed from: f */
    public View mo1574f(int i) {
        int f = mo1921f();
        if (f == 0) {
            return null;
        }
        int m = i - mo1949m(mo1925g(0));
        if (m >= 0 && m < f) {
            View g = mo1925g(m);
            if (mo1949m(g) == i) {
                return g;
            }
        }
        return super.mo1574f(i);
    }

    /* renamed from: f */
    public View mo1575f(int i, int i2) {
        int i3;
        int i4;
        mo1536K();
        if ((i2 > i ? 1 : i2 < i ? (char) 65535 : 0) == 0) {
            return mo1925g(i);
        }
        if (this.f1254r0.mo12240d(mo1925g(i)) < this.f1254r0.mo12243f()) {
            i4 = 16644;
            i3 = 16388;
        } else {
            i4 = 4161;
            i3 = 4097;
        }
        return (this.f1252p0 == 0 ? this.f1351b0 : this.f1352c0).mo4739a(i, i2, i4, i3);
    }

    /* renamed from: g */
    public final void mo1576g(int i, int i2) {
        this.f1253q0.f1274c = this.f1254r0.mo12235b() - i2;
        this.f1253q0.f1276e = this.f1257u0 ? -1 : 1;
        C0208c cVar = this.f1253q0;
        cVar.f1275d = i;
        cVar.f1277f = 1;
        cVar.f1273b = i2;
        cVar.f1278g = RecyclerView.UNDEFINED_DURATION;
    }

    /* renamed from: g */
    public void mo1523g(RecyclerView.C0212a0 a0Var) {
        this.f1247A0 = null;
        this.f1260x0 = -1;
        this.f1261y0 = RecyclerView.UNDEFINED_DURATION;
        this.f1248B0.mo1589b();
    }

    /* renamed from: h */
    public final int mo1577h(RecyclerView.C0212a0 a0Var) {
        if (mo1921f() == 0) {
            return 0;
        }
        mo1536K();
        C2344yc ycVar = this.f1254r0;
        View b = mo1564b(!this.f1259w0, true);
        return C0815h0.m5775a(a0Var, ycVar, b, mo1552a(!this.f1259w0, true), (RecyclerView.C0232o) this, this.f1259w0);
    }

    /* renamed from: h */
    public final void mo1578h(int i, int i2) {
        this.f1253q0.f1274c = i2 - this.f1254r0.mo12243f();
        C0208c cVar = this.f1253q0;
        cVar.f1275d = i;
        cVar.f1276e = this.f1257u0 ? 1 : -1;
        C0208c cVar2 = this.f1253q0;
        cVar2.f1277f = -1;
        cVar2.f1273b = i2;
        cVar2.f1278g = RecyclerView.UNDEFINED_DURATION;
    }

    /* renamed from: i */
    public final int mo1579i(RecyclerView.C0212a0 a0Var) {
        if (mo1921f() == 0) {
            return 0;
        }
        mo1536K();
        C2344yc ycVar = this.f1254r0;
        View b = mo1564b(!this.f1259w0, true);
        return C0815h0.m5776a(a0Var, ycVar, b, mo1552a(!this.f1259w0, true), (RecyclerView.C0232o) this, this.f1259w0, this.f1257u0);
    }

    /* renamed from: j */
    public final int mo1580j(RecyclerView.C0212a0 a0Var) {
        if (mo1921f() == 0) {
            return 0;
        }
        mo1536K();
        C2344yc ycVar = this.f1254r0;
        View b = mo1564b(!this.f1259w0, true);
        return C0815h0.m5839b(a0Var, ycVar, b, mo1552a(!this.f1259w0, true), this, this.f1259w0);
    }

    @Deprecated
    /* renamed from: k */
    public int mo1581k(RecyclerView.C0212a0 a0Var) {
        if (a0Var.f1289a != -1) {
            return this.f1254r0.mo12245g();
        }
        return 0;
    }

    /* renamed from: m */
    public void mo1582m(int i) {
        this.f1260x0 = i;
        this.f1261y0 = RecyclerView.UNDEFINED_DURATION;
        C0209d dVar = this.f1247A0;
        if (dVar != null) {
            dVar.f1285X = -1;
        }
        mo1868E();
    }

    /* renamed from: n */
    public int mo1583n(int i) {
        if (i == 1) {
            return (this.f1252p0 != 1 && mo1544S()) ? 1 : -1;
        }
        if (i == 2) {
            return (this.f1252p0 != 1 && mo1544S()) ? -1 : 1;
        }
        if (i != 17) {
            if (i != 33) {
                if (i != 66) {
                    if (i == 130 && this.f1252p0 == 1) {
                        return 1;
                    }
                    return RecyclerView.UNDEFINED_DURATION;
                } else if (this.f1252p0 == 0) {
                    return 1;
                } else {
                    return RecyclerView.UNDEFINED_DURATION;
                }
            } else if (this.f1252p0 == 1) {
                return -1;
            } else {
                return RecyclerView.UNDEFINED_DURATION;
            }
        } else if (this.f1252p0 == 0) {
            return -1;
        } else {
            return RecyclerView.UNDEFINED_DURATION;
        }
    }

    /* renamed from: o */
    public void mo1584o(int i) {
        if (i == 0 || i == 1) {
            mo1562a((String) null);
            if (i != this.f1252p0 || this.f1254r0 == null) {
                this.f1254r0 = C2344yc.m16391a(this, i);
                this.f1248B0.f1263a = this.f1254r0;
                this.f1252p0 = i;
                mo1868E();
                return;
            }
            return;
        }
        throw new IllegalArgumentException(C0789gk.m5568b("invalid orientation:", i));
    }

    /* renamed from: t */
    public boolean mo1585t() {
        return true;
    }

    /* renamed from: androidx.recyclerview.widget.LinearLayoutManager$c */
    public static class C0208c {

        /* renamed from: a */
        public boolean f1272a = true;

        /* renamed from: b */
        public int f1273b;

        /* renamed from: c */
        public int f1274c;

        /* renamed from: d */
        public int f1275d;

        /* renamed from: e */
        public int f1276e;

        /* renamed from: f */
        public int f1277f;

        /* renamed from: g */
        public int f1278g;

        /* renamed from: h */
        public int f1279h = 0;

        /* renamed from: i */
        public int f1280i = 0;

        /* renamed from: j */
        public boolean f1281j;

        /* renamed from: k */
        public int f1282k;

        /* renamed from: l */
        public List<RecyclerView.C0218d0> f1283l = null;

        /* renamed from: m */
        public boolean f1284m;

        /* renamed from: a */
        public void mo1593a(View view) {
            int i;
            int n;
            int size = this.f1283l.size();
            View view2 = null;
            int i2 = Integer.MAX_VALUE;
            for (int i3 = 0; i3 < size; i3++) {
                View view3 = this.f1283l.get(i3).f1316X;
                RecyclerView.C0237p pVar = (RecyclerView.C0237p) view3.getLayoutParams();
                if (view3 != view && !pVar.mo1972p() && (n = (pVar.mo1970n() - this.f1275d) * this.f1276e) >= 0 && n < i2) {
                    view2 = view3;
                    if (n == 0) {
                        break;
                    }
                    i2 = n;
                }
            }
            if (view2 == null) {
                i = -1;
            } else {
                i = ((RecyclerView.C0237p) view2.getLayoutParams()).mo1970n();
            }
            this.f1275d = i;
        }

        /* renamed from: a */
        public boolean mo1594a(RecyclerView.C0212a0 a0Var) {
            int i = this.f1275d;
            return i >= 0 && i < a0Var.mo1790a();
        }

        /* renamed from: a */
        public View mo1592a(RecyclerView.C0244v vVar) {
            List<RecyclerView.C0218d0> list = this.f1283l;
            if (list != null) {
                int size = list.size();
                for (int i = 0; i < size; i++) {
                    View view = this.f1283l.get(i).f1316X;
                    RecyclerView.C0237p pVar = (RecyclerView.C0237p) view.getLayoutParams();
                    if (!pVar.mo1972p() && this.f1275d == pVar.mo1970n()) {
                        mo1593a(view);
                        return view;
                    }
                }
                return null;
            }
            View b = vVar.mo1991b(this.f1275d);
            this.f1275d += this.f1276e;
            return b;
        }
    }

    /* renamed from: a */
    public int mo1550a(RecyclerView.C0244v vVar, C0208c cVar, RecyclerView.C0212a0 a0Var, boolean z) {
        int i = cVar.f1274c;
        int i2 = cVar.f1278g;
        if (i2 != Integer.MIN_VALUE) {
            if (i < 0) {
                cVar.f1278g = i2 + i;
            }
            mo1560a(vVar, cVar);
        }
        int i3 = cVar.f1274c + cVar.f1279h;
        C0207b bVar = this.f1249C0;
        while (true) {
            if ((!cVar.f1284m && i3 <= 0) || !cVar.mo1594a(a0Var)) {
                break;
            }
            bVar.f1268a = 0;
            bVar.f1269b = false;
            bVar.f1270c = false;
            bVar.f1271d = false;
            mo1504a(vVar, a0Var, cVar, bVar);
            if (!bVar.f1269b) {
                cVar.f1273b = (bVar.f1268a * cVar.f1277f) + cVar.f1273b;
                if (!bVar.f1270c || cVar.f1283l != null || !a0Var.f1296h) {
                    int i4 = cVar.f1274c;
                    int i5 = bVar.f1268a;
                    cVar.f1274c = i4 - i5;
                    i3 -= i5;
                }
                int i6 = cVar.f1278g;
                if (i6 != Integer.MIN_VALUE) {
                    cVar.f1278g = i6 + bVar.f1268a;
                    int i7 = cVar.f1274c;
                    if (i7 < 0) {
                        cVar.f1278g += i7;
                    }
                    mo1560a(vVar, cVar);
                }
                if (z && bVar.f1271d) {
                    break;
                }
            } else {
                break;
            }
        }
        return i - cVar.f1274c;
    }

    /* renamed from: a */
    public View mo1495a(View view, int i, RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var) {
        int n;
        View view2;
        mo1547V();
        if (mo1921f() == 0 || (n = mo1583n(i)) == Integer.MIN_VALUE) {
            return null;
        }
        mo1536K();
        mo1554a(n, (int) (((float) this.f1254r0.mo12245g()) * 0.33333334f), false, a0Var);
        C0208c cVar = this.f1253q0;
        cVar.f1278g = RecyclerView.UNDEFINED_DURATION;
        cVar.f1272a = false;
        mo1550a(vVar, cVar, a0Var, true);
        if (n == -1) {
            view2 = this.f1257u0 ? mo1539N() : mo1537L();
        } else {
            view2 = this.f1257u0 ? mo1537L() : mo1539N();
        }
        View Q = n == -1 ? mo1542Q() : mo1541P();
        if (!Q.hasFocusable()) {
            return view2;
        }
        if (view2 == null) {
            return null;
        }
        return Q;
    }

    /* renamed from: a */
    public void mo1557a(AccessibilityEvent accessibilityEvent) {
        RecyclerView recyclerView = this.f1348Y;
        RecyclerView.C0244v vVar = recyclerView.mRecycler;
        RecyclerView.C0212a0 a0Var = recyclerView.mState;
        mo1902b(accessibilityEvent);
        if (mo1921f() > 0) {
            accessibilityEvent.setFromIndex(mo1538M());
            accessibilityEvent.setToIndex(mo1540O());
        }
    }

    /* renamed from: a */
    public final void mo1560a(RecyclerView.C0244v vVar, C0208c cVar) {
        if (cVar.f1272a && !cVar.f1284m) {
            int i = cVar.f1278g;
            int i2 = cVar.f1280i;
            if (cVar.f1277f == -1) {
                int f = mo1921f();
                if (i >= 0) {
                    int a = (this.f1254r0.mo12232a() - i) + i2;
                    if (this.f1257u0) {
                        for (int i3 = 0; i3 < f; i3++) {
                            View g = mo1925g(i3);
                            if (this.f1254r0.mo12240d(g) < a || this.f1254r0.mo12244f(g) < a) {
                                mo1559a(vVar, 0, i3);
                                return;
                            }
                        }
                        return;
                    }
                    int i4 = f - 1;
                    for (int i5 = i4; i5 >= 0; i5--) {
                        View g2 = mo1925g(i5);
                        if (this.f1254r0.mo12240d(g2) < a || this.f1254r0.mo12244f(g2) < a) {
                            mo1559a(vVar, i4, i5);
                            return;
                        }
                    }
                }
            } else if (i >= 0) {
                int i6 = i - i2;
                int f2 = mo1921f();
                if (this.f1257u0) {
                    int i7 = f2 - 1;
                    for (int i8 = i7; i8 >= 0; i8--) {
                        View g3 = mo1925g(i8);
                        if (this.f1254r0.mo12233a(g3) > i6 || this.f1254r0.mo12242e(g3) > i6) {
                            mo1559a(vVar, i7, i8);
                            return;
                        }
                    }
                    return;
                }
                for (int i9 = 0; i9 < f2; i9++) {
                    View g4 = mo1925g(i9);
                    if (this.f1254r0.mo12233a(g4) > i6 || this.f1254r0.mo12242e(g4) > i6) {
                        mo1559a(vVar, 0, i9);
                        return;
                    }
                }
            }
        }
    }

    /* renamed from: a */
    public void mo1561a(RecyclerView recyclerView, RecyclerView.C0212a0 a0Var, int i) {
        C1913tc tcVar = new C1913tc(recyclerView.getContext());
        tcVar.f1391a = i;
        mo1904b((RecyclerView.C0249z) tcVar);
    }
}
