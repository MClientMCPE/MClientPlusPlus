package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.List;
import p000.C0759g8;
import p000.C1692qc;

public class StaggeredGridLayoutManager extends RecyclerView.C0232o implements RecyclerView.C0249z.C0251b {

    /* renamed from: A0 */
    public int f1406A0 = RecyclerView.UNDEFINED_DURATION;

    /* renamed from: B0 */
    public C0255d f1407B0 = new C0255d();

    /* renamed from: C0 */
    public int f1408C0 = 2;

    /* renamed from: D0 */
    public boolean f1409D0;

    /* renamed from: E0 */
    public boolean f1410E0;

    /* renamed from: F0 */
    public C0258e f1411F0;

    /* renamed from: G0 */
    public int f1412G0;

    /* renamed from: H0 */
    public final Rect f1413H0 = new Rect();

    /* renamed from: I0 */
    public final C0253b f1414I0 = new C0253b();

    /* renamed from: J0 */
    public boolean f1415J0 = false;

    /* renamed from: K0 */
    public boolean f1416K0 = true;

    /* renamed from: L0 */
    public int[] f1417L0;

    /* renamed from: M0 */
    public final Runnable f1418M0 = new C0252a();

    /* renamed from: p0 */
    public int f1419p0 = -1;

    /* renamed from: q0 */
    public C0260f[] f1420q0;

    /* renamed from: r0 */
    public C2344yc f1421r0;

    /* renamed from: s0 */
    public C2344yc f1422s0;

    /* renamed from: t0 */
    public int f1423t0;

    /* renamed from: u0 */
    public int f1424u0;

    /* renamed from: v0 */
    public final C1851sc f1425v0;

    /* renamed from: w0 */
    public boolean f1426w0 = false;

    /* renamed from: x0 */
    public boolean f1427x0 = false;

    /* renamed from: y0 */
    public BitSet f1428y0;

    /* renamed from: z0 */
    public int f1429z0 = -1;

    /* renamed from: androidx.recyclerview.widget.StaggeredGridLayoutManager$a */
    public class C0252a implements Runnable {
        public C0252a() {
        }

        public void run() {
            StaggeredGridLayoutManager.this.mo2013L();
        }
    }

    /* renamed from: androidx.recyclerview.widget.StaggeredGridLayoutManager$b */
    public class C0253b {

        /* renamed from: a */
        public int f1431a;

        /* renamed from: b */
        public int f1432b;

        /* renamed from: c */
        public boolean f1433c;

        /* renamed from: d */
        public boolean f1434d;

        /* renamed from: e */
        public boolean f1435e;

        /* renamed from: f */
        public int[] f1436f;

        public C0253b() {
            mo2055b();
        }

        /* renamed from: a */
        public void mo2053a() {
            this.f1432b = this.f1433c ? StaggeredGridLayoutManager.this.f1421r0.mo12235b() : StaggeredGridLayoutManager.this.f1421r0.mo12243f();
        }

        /* renamed from: a */
        public void mo2054a(C0260f[] fVarArr) {
            int length = fVarArr.length;
            int[] iArr = this.f1436f;
            if (iArr == null || iArr.length < length) {
                this.f1436f = new int[StaggeredGridLayoutManager.this.f1420q0.length];
            }
            for (int i = 0; i < length; i++) {
                this.f1436f[i] = fVarArr[i].mo2079b((int) RecyclerView.UNDEFINED_DURATION);
            }
        }

        /* renamed from: b */
        public void mo2055b() {
            this.f1431a = -1;
            this.f1432b = RecyclerView.UNDEFINED_DURATION;
            this.f1433c = false;
            this.f1434d = false;
            this.f1435e = false;
            int[] iArr = this.f1436f;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
        }
    }

    /* renamed from: androidx.recyclerview.widget.StaggeredGridLayoutManager$c */
    public static class C0254c extends RecyclerView.C0237p {

        /* renamed from: b0 */
        public C0260f f1438b0;

        /* renamed from: c0 */
        public boolean f1439c0;

        public C0254c(int i, int i2) {
            super(i, i2);
        }

        public C0254c(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public C0254c(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public C0254c(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }
    }

    @SuppressLint({"BanParcelableUsage"})
    /* renamed from: androidx.recyclerview.widget.StaggeredGridLayoutManager$e */
    public static class C0258e implements Parcelable {
        public static final Parcelable.Creator<C0258e> CREATOR = new C0259a();

        /* renamed from: X */
        public int f1446X;

        /* renamed from: Y */
        public int f1447Y;

        /* renamed from: Z */
        public int f1448Z;

        /* renamed from: a0 */
        public int[] f1449a0;

        /* renamed from: b0 */
        public int f1450b0;

        /* renamed from: c0 */
        public int[] f1451c0;

        /* renamed from: d0 */
        public List<C0255d.C0256a> f1452d0;

        /* renamed from: e0 */
        public boolean f1453e0;

        /* renamed from: f0 */
        public boolean f1454f0;

        /* renamed from: g0 */
        public boolean f1455g0;

        /* renamed from: androidx.recyclerview.widget.StaggeredGridLayoutManager$e$a */
        public static class C0259a implements Parcelable.Creator<C0258e> {
            public Object createFromParcel(Parcel parcel) {
                return new C0258e(parcel);
            }

            public Object[] newArray(int i) {
                return new C0258e[i];
            }
        }

        public C0258e() {
        }

        public C0258e(Parcel parcel) {
            this.f1446X = parcel.readInt();
            this.f1447Y = parcel.readInt();
            this.f1448Z = parcel.readInt();
            int i = this.f1448Z;
            if (i > 0) {
                this.f1449a0 = new int[i];
                parcel.readIntArray(this.f1449a0);
            }
            this.f1450b0 = parcel.readInt();
            int i2 = this.f1450b0;
            if (i2 > 0) {
                this.f1451c0 = new int[i2];
                parcel.readIntArray(this.f1451c0);
            }
            boolean z = false;
            this.f1453e0 = parcel.readInt() == 1;
            this.f1454f0 = parcel.readInt() == 1;
            this.f1455g0 = parcel.readInt() == 1 ? true : z;
            this.f1452d0 = parcel.readArrayList(C0255d.C0256a.class.getClassLoader());
        }

        public C0258e(C0258e eVar) {
            this.f1448Z = eVar.f1448Z;
            this.f1446X = eVar.f1446X;
            this.f1447Y = eVar.f1447Y;
            this.f1449a0 = eVar.f1449a0;
            this.f1450b0 = eVar.f1450b0;
            this.f1451c0 = eVar.f1451c0;
            this.f1453e0 = eVar.f1453e0;
            this.f1454f0 = eVar.f1454f0;
            this.f1455g0 = eVar.f1455g0;
            this.f1452d0 = eVar.f1452d0;
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeInt(this.f1446X);
            parcel.writeInt(this.f1447Y);
            parcel.writeInt(this.f1448Z);
            if (this.f1448Z > 0) {
                parcel.writeIntArray(this.f1449a0);
            }
            parcel.writeInt(this.f1450b0);
            if (this.f1450b0 > 0) {
                parcel.writeIntArray(this.f1451c0);
            }
            parcel.writeInt(this.f1453e0 ? 1 : 0);
            parcel.writeInt(this.f1454f0 ? 1 : 0);
            parcel.writeInt(this.f1455g0 ? 1 : 0);
            parcel.writeList(this.f1452d0);
        }
    }

    public StaggeredGridLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        RecyclerView.C0232o.C0236d a = RecyclerView.C0232o.m1222a(context, attributeSet, i, i2);
        mo2049s(a.f1367a);
        mo2050t(a.f1368b);
        mo2037d(a.f1369c);
        this.f1425v0 = new C1851sc();
        this.f1421r0 = C2344yc.m16391a(this, this.f1423t0);
        this.f1422s0 = C2344yc.m16391a(this, 1 - this.f1423t0);
    }

    /* renamed from: B */
    public Parcelable mo1533B() {
        int i;
        int i2;
        int[] iArr;
        C0258e eVar = this.f1411F0;
        if (eVar != null) {
            return new C0258e(eVar);
        }
        C0258e eVar2 = new C0258e();
        eVar2.f1453e0 = this.f1426w0;
        eVar2.f1454f0 = this.f1409D0;
        eVar2.f1455g0 = this.f1410E0;
        C0255d dVar = this.f1407B0;
        if (dVar == null || (iArr = dVar.f1440a) == null) {
            eVar2.f1450b0 = 0;
        } else {
            eVar2.f1451c0 = iArr;
            eVar2.f1450b0 = eVar2.f1451c0.length;
            eVar2.f1452d0 = dVar.f1441b;
        }
        if (mo1921f() > 0) {
            eVar2.f1446X = this.f1409D0 ? mo2016O() : mo2015N();
            eVar2.f1447Y = mo2014M();
            int i3 = this.f1419p0;
            eVar2.f1448Z = i3;
            eVar2.f1449a0 = new int[i3];
            for (int i4 = 0; i4 < this.f1419p0; i4++) {
                if (this.f1409D0) {
                    i = this.f1420q0[i4].mo2074a((int) RecyclerView.UNDEFINED_DURATION);
                    if (i != Integer.MIN_VALUE) {
                        i2 = this.f1421r0.mo12235b();
                    } else {
                        eVar2.f1449a0[i4] = i;
                    }
                } else {
                    i = this.f1420q0[i4].mo2079b((int) RecyclerView.UNDEFINED_DURATION);
                    if (i != Integer.MIN_VALUE) {
                        i2 = this.f1421r0.mo12243f();
                    } else {
                        eVar2.f1449a0[i4] = i;
                    }
                }
                i -= i2;
                eVar2.f1449a0[i4] = i;
            }
        } else {
            eVar2.f1446X = -1;
            eVar2.f1447Y = -1;
            eVar2.f1448Z = 0;
        }
        return eVar2;
    }

    /* renamed from: I */
    public boolean mo1488I() {
        return this.f1411F0 == null;
    }

    /* renamed from: J */
    public boolean mo2011J() {
        int a = this.f1420q0[0].mo2074a((int) RecyclerView.UNDEFINED_DURATION);
        for (int i = 1; i < this.f1419p0; i++) {
            if (this.f1420q0[i].mo2074a((int) RecyclerView.UNDEFINED_DURATION) != a) {
                return false;
            }
        }
        return true;
    }

    /* renamed from: K */
    public boolean mo2012K() {
        int b = this.f1420q0[0].mo2079b((int) RecyclerView.UNDEFINED_DURATION);
        for (int i = 1; i < this.f1419p0; i++) {
            if (this.f1420q0[i].mo2079b((int) RecyclerView.UNDEFINED_DURATION) != b) {
                return false;
            }
        }
        return true;
    }

    /* renamed from: L */
    public boolean mo2013L() {
        int i;
        int i2;
        if (mo1921f() == 0 || this.f1408C0 == 0 || !mo1958s()) {
            return false;
        }
        if (this.f1427x0) {
            i2 = mo2016O();
            i = mo2015N();
        } else {
            i2 = mo2015N();
            i = mo2016O();
        }
        if (i2 == 0 && mo2017P() != null) {
            this.f1407B0.mo2057a();
        } else if (!this.f1415J0) {
            return false;
        } else {
            int i3 = this.f1427x0 ? -1 : 1;
            int i4 = i + 1;
            C0255d.C0256a a = this.f1407B0.mo2056a(i2, i4, i3, true);
            if (a == null) {
                this.f1415J0 = false;
                this.f1407B0.mo2061b(i4);
                return false;
            }
            C0255d.C0256a a2 = this.f1407B0.mo2056a(i2, a.f1442X, i3 * -1, true);
            if (a2 == null) {
                this.f1407B0.mo2061b(a.f1442X);
            } else {
                this.f1407B0.mo2061b(a2.f1442X + 1);
            }
        }
        mo1869F();
        mo1868E();
        return true;
    }

    /* renamed from: M */
    public int mo2014M() {
        View b = this.f1427x0 ? mo2029b(true) : mo2035c(true);
        if (b == null) {
            return -1;
        }
        return mo1949m(b);
    }

    /* renamed from: N */
    public int mo2015N() {
        if (mo1921f() == 0) {
            return 0;
        }
        return mo1949m(mo1925g(0));
    }

    /* renamed from: O */
    public int mo2016O() {
        int f = mo1921f();
        if (f == 0) {
            return 0;
        }
        return mo1949m(mo1925g(f - 1));
    }

    /* JADX WARNING: Code restructure failed: missing block: B:38:0x00ab, code lost:
        if (r11 == r12) goto L_0x00bf;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:42:0x00bd, code lost:
        if (r11 == r12) goto L_0x00bf;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:44:0x00c1, code lost:
        r11 = false;
     */
    /* JADX WARNING: Removed duplicated region for block: B:28:0x0084  */
    /* JADX WARNING: Removed duplicated region for block: B:57:0x0083 A[SYNTHETIC] */
    /* renamed from: P */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.View mo2017P() {
        /*
            r13 = this;
            int r0 = r13.mo1921f()
            r1 = 1
            int r0 = r0 - r1
            java.util.BitSet r2 = new java.util.BitSet
            int r3 = r13.f1419p0
            r2.<init>(r3)
            int r3 = r13.f1419p0
            r4 = 0
            r2.set(r4, r3, r1)
            int r3 = r13.f1423t0
            r5 = -1
            if (r3 != r1) goto L_0x0020
            boolean r3 = r13.mo2019R()
            if (r3 == 0) goto L_0x0020
            r3 = 1
            goto L_0x0021
        L_0x0020:
            r3 = -1
        L_0x0021:
            boolean r6 = r13.f1427x0
            if (r6 == 0) goto L_0x0027
            r6 = -1
            goto L_0x002b
        L_0x0027:
            int r0 = r0 + 1
            r6 = r0
            r0 = 0
        L_0x002b:
            if (r0 >= r6) goto L_0x002f
            r7 = 1
            goto L_0x0030
        L_0x002f:
            r7 = -1
        L_0x0030:
            if (r0 == r6) goto L_0x00e3
            android.view.View r8 = r13.mo1925g((int) r0)
            android.view.ViewGroup$LayoutParams r9 = r8.getLayoutParams()
            androidx.recyclerview.widget.StaggeredGridLayoutManager$c r9 = (androidx.recyclerview.widget.StaggeredGridLayoutManager.C0254c) r9
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f r10 = r9.f1438b0
            int r10 = r10.f1460e
            boolean r10 = r2.get(r10)
            if (r10 == 0) goto L_0x008b
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f r10 = r9.f1438b0
            boolean r11 = r13.f1427x0
            if (r11 == 0) goto L_0x0064
            int r11 = r10.mo2086f()
            yc r12 = r13.f1421r0
            int r12 = r12.mo12235b()
            if (r11 >= r12) goto L_0x0080
            java.util.ArrayList<android.view.View> r11 = r10.f1456a
            int r12 = r11.size()
            int r12 = r12 + r5
            java.lang.Object r11 = r11.get(r12)
            goto L_0x0076
        L_0x0064:
            int r11 = r10.mo2087g()
            yc r12 = r13.f1421r0
            int r12 = r12.mo12243f()
            if (r11 <= r12) goto L_0x0080
            java.util.ArrayList<android.view.View> r11 = r10.f1456a
            java.lang.Object r11 = r11.get(r4)
        L_0x0076:
            android.view.View r11 = (android.view.View) r11
            androidx.recyclerview.widget.StaggeredGridLayoutManager$c r10 = r10.mo2080b((android.view.View) r11)
            boolean r10 = r10.f1439c0
            r10 = r10 ^ r1
            goto L_0x0081
        L_0x0080:
            r10 = 0
        L_0x0081:
            if (r10 == 0) goto L_0x0084
            return r8
        L_0x0084:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f r10 = r9.f1438b0
            int r10 = r10.f1460e
            r2.clear(r10)
        L_0x008b:
            boolean r10 = r9.f1439c0
            if (r10 == 0) goto L_0x0090
            goto L_0x00e0
        L_0x0090:
            int r10 = r0 + r7
            if (r10 == r6) goto L_0x00e0
            android.view.View r10 = r13.mo1925g((int) r10)
            boolean r11 = r13.f1427x0
            if (r11 == 0) goto L_0x00ae
            yc r11 = r13.f1421r0
            int r11 = r11.mo12233a((android.view.View) r8)
            yc r12 = r13.f1421r0
            int r12 = r12.mo12233a((android.view.View) r10)
            if (r11 >= r12) goto L_0x00ab
            return r8
        L_0x00ab:
            if (r11 != r12) goto L_0x00c1
            goto L_0x00bf
        L_0x00ae:
            yc r11 = r13.f1421r0
            int r11 = r11.mo12240d(r8)
            yc r12 = r13.f1421r0
            int r12 = r12.mo12240d(r10)
            if (r11 <= r12) goto L_0x00bd
            return r8
        L_0x00bd:
            if (r11 != r12) goto L_0x00c1
        L_0x00bf:
            r11 = 1
            goto L_0x00c2
        L_0x00c1:
            r11 = 0
        L_0x00c2:
            if (r11 == 0) goto L_0x00e0
            android.view.ViewGroup$LayoutParams r10 = r10.getLayoutParams()
            androidx.recyclerview.widget.StaggeredGridLayoutManager$c r10 = (androidx.recyclerview.widget.StaggeredGridLayoutManager.C0254c) r10
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f r9 = r9.f1438b0
            int r9 = r9.f1460e
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f r10 = r10.f1438b0
            int r10 = r10.f1460e
            int r9 = r9 - r10
            if (r9 >= 0) goto L_0x00d7
            r9 = 1
            goto L_0x00d8
        L_0x00d7:
            r9 = 0
        L_0x00d8:
            if (r3 >= 0) goto L_0x00dc
            r10 = 1
            goto L_0x00dd
        L_0x00dc:
            r10 = 0
        L_0x00dd:
            if (r9 == r10) goto L_0x00e0
            return r8
        L_0x00e0:
            int r0 = r0 + r7
            goto L_0x0030
        L_0x00e3:
            r0 = 0
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.mo2017P():android.view.View");
    }

    /* renamed from: Q */
    public void mo2018Q() {
        this.f1407B0.mo2057a();
        mo1868E();
    }

    /* renamed from: R */
    public boolean mo2019R() {
        return mo1945l() == 1;
    }

    /* renamed from: S */
    public final void mo2020S() {
        this.f1427x0 = (this.f1423t0 == 1 || !mo2019R()) ? this.f1426w0 : !this.f1426w0;
    }

    /* renamed from: a */
    public int mo1492a(int i, RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var) {
        return mo2034c(i, vVar, a0Var);
    }

    /* renamed from: a */
    public int mo1549a(RecyclerView.C0212a0 a0Var) {
        return mo2041h(a0Var);
    }

    /* renamed from: a */
    public int mo1493a(RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var) {
        return this.f1423t0 == 1 ? this.f1419p0 : super.mo1493a(vVar, a0Var);
    }

    /* renamed from: a */
    public RecyclerView.C0237p mo1497a(Context context, AttributeSet attributeSet) {
        return new C0254c(context, attributeSet);
    }

    /* renamed from: a */
    public RecyclerView.C0237p mo1498a(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new C0254c((ViewGroup.MarginLayoutParams) layoutParams) : new C0254c(layoutParams);
    }

    /* renamed from: a */
    public void mo2022a(int i, RecyclerView.C0212a0 a0Var) {
        int i2;
        int i3;
        if (i > 0) {
            i3 = mo2016O();
            i2 = 1;
        } else {
            i3 = mo2015N();
            i2 = -1;
        }
        this.f1425v0.f14094a = true;
        mo2030b(i3, a0Var);
        mo2048r(i2);
        C1851sc scVar = this.f1425v0;
        scVar.f14096c = i3 + scVar.f14097d;
        scVar.f14095b = Math.abs(i);
    }

    /* renamed from: a */
    public void mo1499a(Rect rect, int i, int i2) {
        int i3;
        int i4;
        int paddingRight = getPaddingRight() + getPaddingLeft();
        int paddingBottom = getPaddingBottom() + getPaddingTop();
        if (this.f1423t0 == 1) {
            i4 = RecyclerView.C0232o.m1223c(i2, rect.height() + paddingBottom, mo1948m());
            i3 = RecyclerView.C0232o.m1223c(i, (this.f1424u0 * this.f1419p0) + paddingRight, mo1950n());
        } else {
            i3 = RecyclerView.C0232o.m1223c(i, rect.width() + paddingRight, mo1950n());
            i4 = RecyclerView.C0232o.m1223c(i2, (this.f1424u0 * this.f1419p0) + paddingBottom, mo1948m());
        }
        mo1914d(i3, i4);
    }

    /* renamed from: a */
    public void mo1556a(Parcelable parcelable) {
        if (parcelable instanceof C0258e) {
            this.f1411F0 = (C0258e) parcelable;
            mo1868E();
        }
    }

    /* renamed from: a */
    public final void mo2023a(View view, int i, int i2, boolean z) {
        mo1877a(view, this.f1413H0);
        C0254c cVar = (C0254c) view.getLayoutParams();
        int i3 = cVar.leftMargin;
        Rect rect = this.f1413H0;
        int f = mo2039f(i, i3 + rect.left, cVar.rightMargin + rect.right);
        int i4 = cVar.topMargin;
        Rect rect2 = this.f1413H0;
        int f2 = mo2039f(i2, i4 + rect2.top, cVar.bottomMargin + rect2.bottom);
        if (z ? mo1906b(view, f, f2, cVar) : mo1890a(view, f, f2, (RecyclerView.C0237p) cVar)) {
            view.measure(f, f2);
        }
    }

    /* renamed from: a */
    public final void mo2024a(RecyclerView.C0244v vVar, int i) {
        int f = mo1921f() - 1;
        while (f >= 0) {
            View g = mo1925g(f);
            if (this.f1421r0.mo12240d(g) >= i && this.f1421r0.mo12244f(g) >= i) {
                C0254c cVar = (C0254c) g.getLayoutParams();
                if (cVar.f1439c0) {
                    int i2 = 0;
                    while (i2 < this.f1419p0) {
                        if (this.f1420q0[i2].f1456a.size() != 1) {
                            i2++;
                        } else {
                            return;
                        }
                    }
                    for (int i3 = 0; i3 < this.f1419p0; i3++) {
                        this.f1420q0[i3].mo2088h();
                    }
                } else if (cVar.f1438b0.f1456a.size() != 1) {
                    cVar.f1438b0.mo2088h();
                } else {
                    return;
                }
                mo1878a(g, vVar);
                f--;
            } else {
                return;
            }
        }
    }

    /* renamed from: a */
    public final void mo2025a(RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var, boolean z) {
        int b;
        int o = mo2045o(RecyclerView.UNDEFINED_DURATION);
        if (o != Integer.MIN_VALUE && (b = this.f1421r0.mo12235b() - o) > 0) {
            int i = b - (-mo2034c(-b, vVar, a0Var));
            if (z && i > 0) {
                this.f1421r0.mo12234a(i);
            }
        }
    }

    /* renamed from: a */
    public void mo1505a(RecyclerView recyclerView, int i, int i2) {
        mo2038e(i, i2, 1);
    }

    /* renamed from: a */
    public void mo1506a(RecyclerView recyclerView, int i, int i2, int i3) {
        mo2038e(i, i2, 8);
    }

    /* renamed from: a */
    public void mo1507a(RecyclerView recyclerView, int i, int i2, Object obj) {
        mo2038e(i, i2, 4);
    }

    /* renamed from: a */
    public void mo1562a(String str) {
        RecyclerView recyclerView;
        if (this.f1411F0 == null && (recyclerView = this.f1348Y) != null) {
            recyclerView.assertNotInLayoutOrScroll(str);
        }
    }

    /* renamed from: a */
    public boolean mo1508a(RecyclerView.C0237p pVar) {
        return pVar instanceof C0254c;
    }

    /* renamed from: b */
    public int mo1509b(int i, RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var) {
        return mo2034c(i, vVar, a0Var);
    }

    /* renamed from: b */
    public int mo1510b(RecyclerView.C0212a0 a0Var) {
        return mo2042i(a0Var);
    }

    /* renamed from: b */
    public int mo1511b(RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var) {
        return this.f1423t0 == 0 ? this.f1419p0 : super.mo1511b(vVar, a0Var);
    }

    /* renamed from: b */
    public View mo2029b(boolean z) {
        int f = this.f1421r0.mo12243f();
        int b = this.f1421r0.mo12235b();
        View view = null;
        for (int f2 = mo1921f() - 1; f2 >= 0; f2--) {
            View g = mo1925g(f2);
            int d = this.f1421r0.mo12240d(g);
            int a = this.f1421r0.mo12233a(g);
            if (a > f && d < b) {
                if (a <= b || !z) {
                    return g;
                }
                if (view == null) {
                    view = g;
                }
            }
        }
        return view;
    }

    /* renamed from: b */
    public final void mo2032b(RecyclerView.C0244v vVar, int i) {
        while (mo1921f() > 0) {
            View g = mo1925g(0);
            if (this.f1421r0.mo12233a(g) <= i && this.f1421r0.mo12242e(g) <= i) {
                C0254c cVar = (C0254c) g.getLayoutParams();
                if (cVar.f1439c0) {
                    int i2 = 0;
                    while (i2 < this.f1419p0) {
                        if (this.f1420q0[i2].f1456a.size() != 1) {
                            i2++;
                        } else {
                            return;
                        }
                    }
                    for (int i3 = 0; i3 < this.f1419p0; i3++) {
                        this.f1420q0[i3].mo2089i();
                    }
                } else if (cVar.f1438b0.f1456a.size() != 1) {
                    cVar.f1438b0.mo2089i();
                } else {
                    return;
                }
                mo1878a(g, vVar);
            } else {
                return;
            }
        }
    }

    /* renamed from: b */
    public final void mo2033b(RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var, boolean z) {
        int f;
        int p = mo2046p(Integer.MAX_VALUE);
        if (p != Integer.MAX_VALUE && (f = p - this.f1421r0.mo12243f()) > 0) {
            int c = f - mo2034c(f, vVar, a0Var);
            if (z && c > 0) {
                this.f1421r0.mo12234a(-c);
            }
        }
    }

    /* renamed from: b */
    public void mo1514b(RecyclerView recyclerView, int i, int i2) {
        mo2038e(i, i2, 2);
    }

    /* renamed from: b */
    public void mo1565b(RecyclerView recyclerView, RecyclerView.C0244v vVar) {
        mo1964z();
        mo1896a(this.f1418M0);
        for (int i = 0; i < this.f1419p0; i++) {
            this.f1420q0[i].mo2082c();
        }
        recyclerView.requestLayout();
    }

    /* renamed from: b */
    public boolean mo1567b() {
        return this.f1423t0 == 0;
    }

    /* renamed from: c */
    public int mo2034c(int i, RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var) {
        if (mo1921f() == 0 || i == 0) {
            return 0;
        }
        mo2022a(i, a0Var);
        int a = mo2021a(vVar, this.f1425v0, a0Var);
        if (this.f1425v0.f14095b >= a) {
            i = i < 0 ? -a : a;
        }
        this.f1421r0.mo12234a(-i);
        this.f1409D0 = this.f1427x0;
        C1851sc scVar = this.f1425v0;
        scVar.f14095b = 0;
        mo2026a(vVar, scVar);
        return i;
    }

    /* renamed from: c */
    public int mo1515c(RecyclerView.C0212a0 a0Var) {
        return mo2043j(a0Var);
    }

    /* renamed from: c */
    public PointF mo1569c(int i) {
        int n = mo2044n(i);
        PointF pointF = new PointF();
        if (n == 0) {
            return null;
        }
        if (this.f1423t0 == 0) {
            pointF.x = (float) n;
            pointF.y = 0.0f;
        } else {
            pointF.x = 0.0f;
            pointF.y = (float) n;
        }
        return pointF;
    }

    /* renamed from: c */
    public View mo2035c(boolean z) {
        int f = this.f1421r0.mo12243f();
        int b = this.f1421r0.mo12235b();
        int f2 = mo1921f();
        View view = null;
        for (int i = 0; i < f2; i++) {
            View g = mo1925g(i);
            int d = this.f1421r0.mo12240d(g);
            if (this.f1421r0.mo12233a(g) > f && d < b) {
                if (d >= f || !z) {
                    return g;
                }
                if (view == null) {
                    view = g;
                }
            }
        }
        return view;
    }

    /* renamed from: c */
    public void mo1517c(RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var) {
        mo2036c(vVar, a0Var, true);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:151:0x0298, code lost:
        if (mo2013L() != false) goto L_0x029c;
     */
    /* renamed from: c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo2036c(androidx.recyclerview.widget.RecyclerView.C0244v r12, androidx.recyclerview.widget.RecyclerView.C0212a0 r13, boolean r14) {
        /*
            r11 = this;
            androidx.recyclerview.widget.StaggeredGridLayoutManager$b r0 = r11.f1414I0
            androidx.recyclerview.widget.StaggeredGridLayoutManager$e r1 = r11.f1411F0
            r2 = -1
            if (r1 != 0) goto L_0x000b
            int r1 = r11.f1429z0
            if (r1 == r2) goto L_0x0018
        L_0x000b:
            int r1 = r13.mo1790a()
            if (r1 != 0) goto L_0x0018
            r11.mo1903b((androidx.recyclerview.widget.RecyclerView.C0244v) r12)
            r0.mo2055b()
            return
        L_0x0018:
            boolean r1 = r0.f1435e
            r3 = 0
            r4 = 1
            if (r1 == 0) goto L_0x0029
            int r1 = r11.f1429z0
            if (r1 != r2) goto L_0x0029
            androidx.recyclerview.widget.StaggeredGridLayoutManager$e r1 = r11.f1411F0
            if (r1 == 0) goto L_0x0027
            goto L_0x0029
        L_0x0027:
            r1 = 0
            goto L_0x002a
        L_0x0029:
            r1 = 1
        L_0x002a:
            r5 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r1 == 0) goto L_0x00b7
            r0.mo2055b()
            androidx.recyclerview.widget.StaggeredGridLayoutManager$e r6 = r11.f1411F0
            if (r6 == 0) goto L_0x00ab
            int r7 = r6.f1448Z
            if (r7 <= 0) goto L_0x007d
            int r8 = r11.f1419p0
            if (r7 != r8) goto L_0x006e
            r6 = 0
        L_0x003e:
            int r7 = r11.f1419p0
            if (r6 >= r7) goto L_0x007d
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r7 = r11.f1420q0
            r7 = r7[r6]
            r7.mo2082c()
            androidx.recyclerview.widget.StaggeredGridLayoutManager$e r7 = r11.f1411F0
            int[] r8 = r7.f1449a0
            r8 = r8[r6]
            if (r8 == r5) goto L_0x0063
            boolean r7 = r7.f1454f0
            if (r7 == 0) goto L_0x005c
            yc r7 = r11.f1421r0
            int r7 = r7.mo12235b()
            goto L_0x0062
        L_0x005c:
            yc r7 = r11.f1421r0
            int r7 = r7.mo12243f()
        L_0x0062:
            int r8 = r8 + r7
        L_0x0063:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r7 = r11.f1420q0
            r7 = r7[r6]
            r7.f1457b = r8
            r7.f1458c = r8
            int r6 = r6 + 1
            goto L_0x003e
        L_0x006e:
            r7 = 0
            r6.f1449a0 = r7
            r6.f1448Z = r3
            r6.f1450b0 = r3
            r6.f1451c0 = r7
            r6.f1452d0 = r7
            int r7 = r6.f1447Y
            r6.f1446X = r7
        L_0x007d:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$e r6 = r11.f1411F0
            boolean r7 = r6.f1455g0
            r11.f1410E0 = r7
            boolean r6 = r6.f1453e0
            r11.mo2037d((boolean) r6)
            r11.mo2020S()
            androidx.recyclerview.widget.StaggeredGridLayoutManager$e r6 = r11.f1411F0
            int r7 = r6.f1446X
            if (r7 == r2) goto L_0x0096
            r11.f1429z0 = r7
            boolean r6 = r6.f1454f0
            goto L_0x0098
        L_0x0096:
            boolean r6 = r11.f1427x0
        L_0x0098:
            r0.f1433c = r6
            androidx.recyclerview.widget.StaggeredGridLayoutManager$e r6 = r11.f1411F0
            int r7 = r6.f1450b0
            if (r7 <= r4) goto L_0x00b2
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r7 = r11.f1407B0
            int[] r8 = r6.f1451c0
            r7.f1440a = r8
            java.util.List<androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a> r6 = r6.f1452d0
            r7.f1441b = r6
            goto L_0x00b2
        L_0x00ab:
            r11.mo2020S()
            boolean r6 = r11.f1427x0
            r0.f1433c = r6
        L_0x00b2:
            r11.mo2031b((androidx.recyclerview.widget.RecyclerView.C0212a0) r13, (androidx.recyclerview.widget.StaggeredGridLayoutManager.C0253b) r0)
            r0.f1435e = r4
        L_0x00b7:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$e r6 = r11.f1411F0
            if (r6 != 0) goto L_0x00d4
            int r6 = r11.f1429z0
            if (r6 != r2) goto L_0x00d4
            boolean r6 = r0.f1433c
            boolean r7 = r11.f1409D0
            if (r6 != r7) goto L_0x00cd
            boolean r6 = r11.mo2019R()
            boolean r7 = r11.f1410E0
            if (r6 == r7) goto L_0x00d4
        L_0x00cd:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r6 = r11.f1407B0
            r6.mo2057a()
            r0.f1434d = r4
        L_0x00d4:
            int r6 = r11.mo1921f()
            if (r6 <= 0) goto L_0x016b
            androidx.recyclerview.widget.StaggeredGridLayoutManager$e r6 = r11.f1411F0
            if (r6 == 0) goto L_0x00e2
            int r6 = r6.f1448Z
            if (r6 >= r4) goto L_0x016b
        L_0x00e2:
            boolean r6 = r0.f1434d
            if (r6 == 0) goto L_0x0101
            r1 = 0
        L_0x00e7:
            int r6 = r11.f1419p0
            if (r1 >= r6) goto L_0x016b
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r6 = r11.f1420q0
            r6 = r6[r1]
            r6.mo2082c()
            int r6 = r0.f1432b
            if (r6 == r5) goto L_0x00fe
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r7 = r11.f1420q0
            r7 = r7[r1]
            r7.f1457b = r6
            r7.f1458c = r6
        L_0x00fe:
            int r1 = r1 + 1
            goto L_0x00e7
        L_0x0101:
            if (r1 != 0) goto L_0x0123
            androidx.recyclerview.widget.StaggeredGridLayoutManager$b r1 = r11.f1414I0
            int[] r1 = r1.f1436f
            if (r1 != 0) goto L_0x010a
            goto L_0x0123
        L_0x010a:
            r1 = 0
        L_0x010b:
            int r6 = r11.f1419p0
            if (r1 >= r6) goto L_0x016b
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r6 = r11.f1420q0
            r6 = r6[r1]
            r6.mo2082c()
            androidx.recyclerview.widget.StaggeredGridLayoutManager$b r7 = r11.f1414I0
            int[] r7 = r7.f1436f
            r7 = r7[r1]
            r6.f1457b = r7
            r6.f1458c = r7
            int r1 = r1 + 1
            goto L_0x010b
        L_0x0123:
            r1 = 0
        L_0x0124:
            int r6 = r11.f1419p0
            if (r1 >= r6) goto L_0x0164
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r6 = r11.f1420q0
            r6 = r6[r1]
            boolean r7 = r11.f1427x0
            int r8 = r0.f1432b
            if (r7 == 0) goto L_0x0137
            int r9 = r6.mo2074a((int) r5)
            goto L_0x013b
        L_0x0137:
            int r9 = r6.mo2079b((int) r5)
        L_0x013b:
            r6.mo2082c()
            if (r9 != r5) goto L_0x0141
            goto L_0x0161
        L_0x0141:
            if (r7 == 0) goto L_0x014d
            androidx.recyclerview.widget.StaggeredGridLayoutManager r10 = androidx.recyclerview.widget.StaggeredGridLayoutManager.this
            yc r10 = r10.f1421r0
            int r10 = r10.mo12235b()
            if (r9 < r10) goto L_0x0161
        L_0x014d:
            if (r7 != 0) goto L_0x015a
            androidx.recyclerview.widget.StaggeredGridLayoutManager r7 = androidx.recyclerview.widget.StaggeredGridLayoutManager.this
            yc r7 = r7.f1421r0
            int r7 = r7.mo12243f()
            if (r9 <= r7) goto L_0x015a
            goto L_0x0161
        L_0x015a:
            if (r8 == r5) goto L_0x015d
            int r9 = r9 + r8
        L_0x015d:
            r6.f1458c = r9
            r6.f1457b = r9
        L_0x0161:
            int r1 = r1 + 1
            goto L_0x0124
        L_0x0164:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$b r1 = r11.f1414I0
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r6 = r11.f1420q0
            r1.mo2054a(r6)
        L_0x016b:
            r11.mo1882a((androidx.recyclerview.widget.RecyclerView.C0244v) r12)
            sc r1 = r11.f1425v0
            r1.f14094a = r3
            r11.f1415J0 = r3
            yc r1 = r11.f1422s0
            int r1 = r1.mo12245g()
            r11.mo2051u(r1)
            int r1 = r0.f1431a
            r11.mo2030b((int) r1, (androidx.recyclerview.widget.RecyclerView.C0212a0) r13)
            boolean r1 = r0.f1433c
            if (r1 == 0) goto L_0x0192
            r11.mo2048r(r2)
            sc r1 = r11.f1425v0
            r11.mo2021a((androidx.recyclerview.widget.RecyclerView.C0244v) r12, (p000.C1851sc) r1, (androidx.recyclerview.widget.RecyclerView.C0212a0) r13)
            r11.mo2048r(r4)
            goto L_0x019d
        L_0x0192:
            r11.mo2048r(r4)
            sc r1 = r11.f1425v0
            r11.mo2021a((androidx.recyclerview.widget.RecyclerView.C0244v) r12, (p000.C1851sc) r1, (androidx.recyclerview.widget.RecyclerView.C0212a0) r13)
            r11.mo2048r(r2)
        L_0x019d:
            sc r1 = r11.f1425v0
            int r2 = r0.f1431a
            int r6 = r1.f14097d
            int r2 = r2 + r6
            r1.f14096c = r2
            r11.mo2021a((androidx.recyclerview.widget.RecyclerView.C0244v) r12, (p000.C1851sc) r1, (androidx.recyclerview.widget.RecyclerView.C0212a0) r13)
            yc r1 = r11.f1422s0
            int r1 = r1.mo12239d()
            r2 = 1073741824(0x40000000, float:2.0)
            if (r1 != r2) goto L_0x01b5
            goto L_0x0259
        L_0x01b5:
            int r1 = r11.mo1921f()
            r2 = 0
            r2 = 0
            r6 = 0
        L_0x01bc:
            if (r2 >= r1) goto L_0x01e7
            android.view.View r7 = r11.mo1925g((int) r2)
            yc r8 = r11.f1422s0
            int r8 = r8.mo12236b(r7)
            float r8 = (float) r8
            int r9 = (r8 > r6 ? 1 : (r8 == r6 ? 0 : -1))
            if (r9 >= 0) goto L_0x01ce
            goto L_0x01e4
        L_0x01ce:
            android.view.ViewGroup$LayoutParams r7 = r7.getLayoutParams()
            androidx.recyclerview.widget.StaggeredGridLayoutManager$c r7 = (androidx.recyclerview.widget.StaggeredGridLayoutManager.C0254c) r7
            boolean r7 = r7.f1439c0
            if (r7 == 0) goto L_0x01e0
            r7 = 1065353216(0x3f800000, float:1.0)
            float r8 = r8 * r7
            int r7 = r11.f1419p0
            float r7 = (float) r7
            float r8 = r8 / r7
        L_0x01e0:
            float r6 = java.lang.Math.max(r6, r8)
        L_0x01e4:
            int r2 = r2 + 1
            goto L_0x01bc
        L_0x01e7:
            int r2 = r11.f1424u0
            int r7 = r11.f1419p0
            float r7 = (float) r7
            float r6 = r6 * r7
            int r6 = java.lang.Math.round(r6)
            yc r7 = r11.f1422s0
            int r7 = r7.mo12239d()
            if (r7 != r5) goto L_0x0204
            yc r5 = r11.f1422s0
            int r5 = r5.mo12245g()
            int r6 = java.lang.Math.min(r6, r5)
        L_0x0204:
            r11.mo2051u(r6)
            int r5 = r11.f1424u0
            if (r5 != r2) goto L_0x020c
            goto L_0x0259
        L_0x020c:
            r5 = 0
        L_0x020d:
            if (r5 >= r1) goto L_0x0259
            android.view.View r6 = r11.mo1925g((int) r5)
            android.view.ViewGroup$LayoutParams r7 = r6.getLayoutParams()
            androidx.recyclerview.widget.StaggeredGridLayoutManager$c r7 = (androidx.recyclerview.widget.StaggeredGridLayoutManager.C0254c) r7
            boolean r8 = r7.f1439c0
            if (r8 == 0) goto L_0x021e
            goto L_0x0256
        L_0x021e:
            boolean r8 = r11.mo2019R()
            if (r8 == 0) goto L_0x0240
            int r8 = r11.f1423t0
            if (r8 != r4) goto L_0x0240
            int r8 = r11.f1419p0
            int r9 = r8 + -1
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f r7 = r7.f1438b0
            int r7 = r7.f1460e
            int r9 = r9 - r7
            int r9 = -r9
            int r10 = r11.f1424u0
            int r9 = r9 * r10
            int r8 = r8 - r4
            int r8 = r8 - r7
            int r7 = -r8
            int r7 = r7 * r2
            int r9 = r9 - r7
            r6.offsetLeftAndRight(r9)
            goto L_0x0256
        L_0x0240:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f r7 = r7.f1438b0
            int r7 = r7.f1460e
            int r8 = r11.f1424u0
            int r8 = r8 * r7
            int r7 = r7 * r2
            int r9 = r11.f1423t0
            int r8 = r8 - r7
            if (r9 != r4) goto L_0x0253
            r6.offsetLeftAndRight(r8)
            goto L_0x0256
        L_0x0253:
            r6.offsetTopAndBottom(r8)
        L_0x0256:
            int r5 = r5 + 1
            goto L_0x020d
        L_0x0259:
            int r1 = r11.mo1921f()
            if (r1 <= 0) goto L_0x0270
            boolean r1 = r11.f1427x0
            if (r1 == 0) goto L_0x026a
            r11.mo2025a((androidx.recyclerview.widget.RecyclerView.C0244v) r12, (androidx.recyclerview.widget.RecyclerView.C0212a0) r13, (boolean) r4)
            r11.mo2033b((androidx.recyclerview.widget.RecyclerView.C0244v) r12, (androidx.recyclerview.widget.RecyclerView.C0212a0) r13, (boolean) r3)
            goto L_0x0270
        L_0x026a:
            r11.mo2033b((androidx.recyclerview.widget.RecyclerView.C0244v) r12, (androidx.recyclerview.widget.RecyclerView.C0212a0) r13, (boolean) r4)
            r11.mo2025a((androidx.recyclerview.widget.RecyclerView.C0244v) r12, (androidx.recyclerview.widget.RecyclerView.C0212a0) r13, (boolean) r3)
        L_0x0270:
            if (r14 == 0) goto L_0x029b
            boolean r14 = r13.f1296h
            if (r14 != 0) goto L_0x029b
            int r14 = r11.f1408C0
            if (r14 == 0) goto L_0x028c
            int r14 = r11.mo1921f()
            if (r14 <= 0) goto L_0x028c
            boolean r14 = r11.f1415J0
            if (r14 != 0) goto L_0x028a
            android.view.View r14 = r11.mo2017P()
            if (r14 == 0) goto L_0x028c
        L_0x028a:
            r14 = 1
            goto L_0x028d
        L_0x028c:
            r14 = 0
        L_0x028d:
            if (r14 == 0) goto L_0x029b
            java.lang.Runnable r14 = r11.f1418M0
            r11.mo1896a((java.lang.Runnable) r14)
            boolean r14 = r11.mo2013L()
            if (r14 == 0) goto L_0x029b
            goto L_0x029c
        L_0x029b:
            r4 = 0
        L_0x029c:
            boolean r14 = r13.f1296h
            if (r14 == 0) goto L_0x02a5
            androidx.recyclerview.widget.StaggeredGridLayoutManager$b r14 = r11.f1414I0
            r14.mo2055b()
        L_0x02a5:
            boolean r14 = r0.f1433c
            r11.f1409D0 = r14
            boolean r14 = r11.mo2019R()
            r11.f1410E0 = r14
            if (r4 == 0) goto L_0x02b9
            androidx.recyclerview.widget.StaggeredGridLayoutManager$b r14 = r11.f1414I0
            r14.mo2055b()
            r11.mo2036c((androidx.recyclerview.widget.RecyclerView.C0244v) r12, (androidx.recyclerview.widget.RecyclerView.C0212a0) r13, (boolean) r3)
        L_0x02b9:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.mo2036c(androidx.recyclerview.widget.RecyclerView$v, androidx.recyclerview.widget.RecyclerView$a0, boolean):void");
    }

    /* renamed from: c */
    public void mo1518c(RecyclerView recyclerView) {
        this.f1407B0.mo2057a();
        mo1868E();
    }

    /* renamed from: c */
    public boolean mo1570c() {
        return this.f1423t0 == 1;
    }

    /* renamed from: d */
    public int mo1571d(RecyclerView.C0212a0 a0Var) {
        return mo2041h(a0Var);
    }

    /* renamed from: d */
    public RecyclerView.C0237p mo1520d() {
        return this.f1423t0 == 0 ? new C0254c(-2, -1) : new C0254c(-1, -2);
    }

    /* renamed from: d */
    public void mo2037d(boolean z) {
        mo1562a((String) null);
        C0258e eVar = this.f1411F0;
        if (!(eVar == null || eVar.f1453e0 == z)) {
            eVar.f1453e0 = z;
        }
        this.f1426w0 = z;
        mo1868E();
    }

    /* renamed from: e */
    public int mo1521e(RecyclerView.C0212a0 a0Var) {
        return mo2042i(a0Var);
    }

    /* JADX WARNING: Removed duplicated region for block: B:13:0x0027  */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x003e  */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x0045 A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0046  */
    /* renamed from: e */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo2038e(int r7, int r8, int r9) {
        /*
            r6 = this;
            boolean r0 = r6.f1427x0
            if (r0 == 0) goto L_0x0009
            int r0 = r6.mo2016O()
            goto L_0x000d
        L_0x0009:
            int r0 = r6.mo2015N()
        L_0x000d:
            r1 = 8
            if (r9 != r1) goto L_0x001b
            if (r7 >= r8) goto L_0x0016
            int r2 = r8 + 1
            goto L_0x001d
        L_0x0016:
            int r2 = r7 + 1
            r3 = r2
            r2 = r8
            goto L_0x001f
        L_0x001b:
            int r2 = r7 + r8
        L_0x001d:
            r3 = r2
            r2 = r7
        L_0x001f:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r4 = r6.f1407B0
            r4.mo2064d(r2)
            r4 = 1
            if (r9 == r4) goto L_0x003e
            r5 = 2
            if (r9 == r5) goto L_0x0038
            if (r9 == r1) goto L_0x002d
            goto L_0x0043
        L_0x002d:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r9 = r6.f1407B0
            r9.mo2062b(r7, r4)
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r7 = r6.f1407B0
            r7.mo2059a(r8, r4)
            goto L_0x0043
        L_0x0038:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r9 = r6.f1407B0
            r9.mo2062b(r7, r8)
            goto L_0x0043
        L_0x003e:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r9 = r6.f1407B0
            r9.mo2059a(r7, r8)
        L_0x0043:
            if (r3 > r0) goto L_0x0046
            return
        L_0x0046:
            boolean r7 = r6.f1427x0
            if (r7 == 0) goto L_0x004f
            int r7 = r6.mo2015N()
            goto L_0x0053
        L_0x004f:
            int r7 = r6.mo2016O()
        L_0x0053:
            if (r2 > r7) goto L_0x0058
            r6.mo1868E()
        L_0x0058:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.mo2038e(int, int, int):void");
    }

    /* renamed from: f */
    public final int mo2039f(int i, int i2, int i3) {
        if (i2 == 0 && i3 == 0) {
            return i;
        }
        int mode = View.MeasureSpec.getMode(i);
        return (mode == Integer.MIN_VALUE || mode == 1073741824) ? View.MeasureSpec.makeMeasureSpec(Math.max(0, (View.MeasureSpec.getSize(i) - i2) - i3), mode) : i;
    }

    /* renamed from: f */
    public int mo1522f(RecyclerView.C0212a0 a0Var) {
        return mo2043j(a0Var);
    }

    /* renamed from: f */
    public final void mo2040f(int i, int i2) {
        for (int i3 = 0; i3 < this.f1419p0; i3++) {
            if (!this.f1420q0[i3].f1456a.isEmpty()) {
                mo2027a(this.f1420q0[i3], i, i2);
            }
        }
    }

    /* renamed from: g */
    public void mo1523g(RecyclerView.C0212a0 a0Var) {
        this.f1429z0 = -1;
        this.f1406A0 = RecyclerView.UNDEFINED_DURATION;
        this.f1411F0 = null;
        this.f1414I0.mo2055b();
    }

    /* renamed from: h */
    public final int mo2041h(RecyclerView.C0212a0 a0Var) {
        if (mo1921f() == 0) {
            return 0;
        }
        return C0815h0.m5775a(a0Var, this.f1421r0, mo2035c(!this.f1416K0), mo2029b(!this.f1416K0), (RecyclerView.C0232o) this, this.f1416K0);
    }

    /* renamed from: h */
    public void mo1935h(int i) {
        RecyclerView recyclerView = this.f1348Y;
        if (recyclerView != null) {
            recyclerView.offsetChildrenHorizontal(i);
        }
        for (int i2 = 0; i2 < this.f1419p0; i2++) {
            C0260f fVar = this.f1420q0[i2];
            int i3 = fVar.f1457b;
            if (i3 != Integer.MIN_VALUE) {
                fVar.f1457b = i3 + i;
            }
            int i4 = fVar.f1458c;
            if (i4 != Integer.MIN_VALUE) {
                fVar.f1458c = i4 + i;
            }
        }
    }

    /* renamed from: i */
    public final int mo2042i(RecyclerView.C0212a0 a0Var) {
        if (mo1921f() == 0) {
            return 0;
        }
        return C0815h0.m5776a(a0Var, this.f1421r0, mo2035c(!this.f1416K0), mo2029b(!this.f1416K0), (RecyclerView.C0232o) this, this.f1416K0, this.f1427x0);
    }

    /* renamed from: i */
    public void mo1938i(int i) {
        RecyclerView recyclerView = this.f1348Y;
        if (recyclerView != null) {
            recyclerView.offsetChildrenVertical(i);
        }
        for (int i2 = 0; i2 < this.f1419p0; i2++) {
            C0260f fVar = this.f1420q0[i2];
            int i3 = fVar.f1457b;
            if (i3 != Integer.MIN_VALUE) {
                fVar.f1457b = i3 + i;
            }
            int i4 = fVar.f1458c;
            if (i4 != Integer.MIN_VALUE) {
                fVar.f1458c = i4 + i;
            }
        }
    }

    /* renamed from: j */
    public final int mo2043j(RecyclerView.C0212a0 a0Var) {
        if (mo1921f() == 0) {
            return 0;
        }
        return C0815h0.m5839b(a0Var, this.f1421r0, mo2035c(!this.f1416K0), mo2029b(!this.f1416K0), this, this.f1416K0);
    }

    /* renamed from: j */
    public void mo1941j(int i) {
        if (i == 0) {
            mo2013L();
        }
    }

    /* renamed from: m */
    public void mo1582m(int i) {
        C0258e eVar = this.f1411F0;
        if (!(eVar == null || eVar.f1446X == i)) {
            eVar.f1449a0 = null;
            eVar.f1448Z = 0;
            eVar.f1446X = -1;
            eVar.f1447Y = -1;
        }
        this.f1429z0 = i;
        this.f1406A0 = RecyclerView.UNDEFINED_DURATION;
        mo1868E();
    }

    /* renamed from: n */
    public final int mo2044n(int i) {
        if (mo1921f() == 0) {
            return this.f1427x0 ? 1 : -1;
        }
        return (i < mo2015N()) != this.f1427x0 ? -1 : 1;
    }

    /* renamed from: o */
    public final int mo2045o(int i) {
        int a = this.f1420q0[0].mo2074a(i);
        for (int i2 = 1; i2 < this.f1419p0; i2++) {
            int a2 = this.f1420q0[i2].mo2074a(i);
            if (a2 > a) {
                a = a2;
            }
        }
        return a;
    }

    /* renamed from: p */
    public final int mo2046p(int i) {
        int b = this.f1420q0[0].mo2079b(i);
        for (int i2 = 1; i2 < this.f1419p0; i2++) {
            int b2 = this.f1420q0[i2].mo2079b(i);
            if (b2 < b) {
                b = b2;
            }
        }
        return b;
    }

    /* renamed from: q */
    public final boolean mo2047q(int i) {
        if (this.f1423t0 == 0) {
            return (i == -1) != this.f1427x0;
        }
        return ((i == -1) == this.f1427x0) == mo2019R();
    }

    /* renamed from: r */
    public final void mo2048r(int i) {
        C1851sc scVar = this.f1425v0;
        scVar.f14098e = i;
        int i2 = 1;
        if (this.f1427x0 != (i == -1)) {
            i2 = -1;
        }
        scVar.f14097d = i2;
    }

    /* renamed from: s */
    public void mo2049s(int i) {
        if (i == 0 || i == 1) {
            mo1562a((String) null);
            if (i != this.f1423t0) {
                this.f1423t0 = i;
                C2344yc ycVar = this.f1421r0;
                this.f1421r0 = this.f1422s0;
                this.f1422s0 = ycVar;
                mo1868E();
                return;
            }
            return;
        }
        throw new IllegalArgumentException("invalid orientation.");
    }

    /* renamed from: t */
    public void mo2050t(int i) {
        mo1562a((String) null);
        if (i != this.f1419p0) {
            mo2018Q();
            this.f1419p0 = i;
            this.f1428y0 = new BitSet(this.f1419p0);
            this.f1420q0 = new C0260f[this.f1419p0];
            for (int i2 = 0; i2 < this.f1419p0; i2++) {
                this.f1420q0[i2] = new C0260f(i2);
            }
            mo1868E();
        }
    }

    /* renamed from: t */
    public boolean mo1585t() {
        return this.f1408C0 != 0;
    }

    /* renamed from: u */
    public void mo2051u(int i) {
        this.f1424u0 = i / this.f1419p0;
        this.f1412G0 = View.MeasureSpec.makeMeasureSpec(i, this.f1422s0.mo12239d());
    }

    /* renamed from: androidx.recyclerview.widget.StaggeredGridLayoutManager$d */
    public static class C0255d {

        /* renamed from: a */
        public int[] f1440a;

        /* renamed from: b */
        public List<C0256a> f1441b;

        @SuppressLint({"BanParcelableUsage"})
        /* renamed from: androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a */
        public static class C0256a implements Parcelable {
            public static final Parcelable.Creator<C0256a> CREATOR = new C0257a();

            /* renamed from: X */
            public int f1442X;

            /* renamed from: Y */
            public int f1443Y;

            /* renamed from: Z */
            public int[] f1444Z;

            /* renamed from: a0 */
            public boolean f1445a0;

            /* renamed from: androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a$a */
            public static class C0257a implements Parcelable.Creator<C0256a> {
                public Object createFromParcel(Parcel parcel) {
                    return new C0256a(parcel);
                }

                public Object[] newArray(int i) {
                    return new C0256a[i];
                }
            }

            public C0256a() {
            }

            public C0256a(Parcel parcel) {
                this.f1442X = parcel.readInt();
                this.f1443Y = parcel.readInt();
                this.f1445a0 = parcel.readInt() != 1 ? false : true;
                int readInt = parcel.readInt();
                if (readInt > 0) {
                    this.f1444Z = new int[readInt];
                    parcel.readIntArray(this.f1444Z);
                }
            }

            public int describeContents() {
                return 0;
            }

            public String toString() {
                StringBuilder a = C0789gk.m5562a("FullSpanItem{mPosition=");
                a.append(this.f1442X);
                a.append(", mGapDir=");
                a.append(this.f1443Y);
                a.append(", mHasUnwantedGapAfter=");
                a.append(this.f1445a0);
                a.append(", mGapPerSpan=");
                a.append(Arrays.toString(this.f1444Z));
                a.append('}');
                return a.toString();
            }

            public void writeToParcel(Parcel parcel, int i) {
                parcel.writeInt(this.f1442X);
                parcel.writeInt(this.f1443Y);
                parcel.writeInt(this.f1445a0 ? 1 : 0);
                int[] iArr = this.f1444Z;
                if (iArr == null || iArr.length <= 0) {
                    parcel.writeInt(0);
                    return;
                }
                parcel.writeInt(iArr.length);
                parcel.writeIntArray(this.f1444Z);
            }
        }

        /* renamed from: a */
        public C0256a mo2056a(int i, int i2, int i3, boolean z) {
            List<C0256a> list = this.f1441b;
            if (list == null) {
                return null;
            }
            int size = list.size();
            for (int i4 = 0; i4 < size; i4++) {
                C0256a aVar = this.f1441b.get(i4);
                int i5 = aVar.f1442X;
                if (i5 >= i2) {
                    return null;
                }
                if (i5 >= i && (i3 == 0 || aVar.f1443Y == i3 || (z && aVar.f1445a0))) {
                    return aVar;
                }
            }
            return null;
        }

        /* renamed from: a */
        public void mo2057a() {
            int[] iArr = this.f1440a;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
            this.f1441b = null;
        }

        /* renamed from: a */
        public void mo2058a(int i) {
            int[] iArr = this.f1440a;
            if (iArr == null) {
                this.f1440a = new int[(Math.max(i, 10) + 1)];
                Arrays.fill(this.f1440a, -1);
            } else if (i >= iArr.length) {
                int length = iArr.length;
                while (length <= i) {
                    length *= 2;
                }
                this.f1440a = new int[length];
                System.arraycopy(iArr, 0, this.f1440a, 0, iArr.length);
                int[] iArr2 = this.f1440a;
                Arrays.fill(iArr2, iArr.length, iArr2.length, -1);
            }
        }

        /* renamed from: a */
        public void mo2060a(C0256a aVar) {
            if (this.f1441b == null) {
                this.f1441b = new ArrayList();
            }
            int size = this.f1441b.size();
            for (int i = 0; i < size; i++) {
                C0256a aVar2 = this.f1441b.get(i);
                if (aVar2.f1442X == aVar.f1442X) {
                    this.f1441b.remove(i);
                }
                if (aVar2.f1442X >= aVar.f1442X) {
                    this.f1441b.add(i, aVar);
                    return;
                }
            }
            this.f1441b.add(aVar);
        }

        /* renamed from: b */
        public int mo2061b(int i) {
            List<C0256a> list = this.f1441b;
            if (list != null) {
                for (int size = list.size() - 1; size >= 0; size--) {
                    if (this.f1441b.get(size).f1442X >= i) {
                        this.f1441b.remove(size);
                    }
                }
            }
            return mo2064d(i);
        }

        /* renamed from: b */
        public void mo2062b(int i, int i2) {
            int[] iArr = this.f1440a;
            if (iArr != null && i < iArr.length) {
                int i3 = i + i2;
                mo2058a(i3);
                int[] iArr2 = this.f1440a;
                System.arraycopy(iArr2, i3, iArr2, i, (iArr2.length - i) - i2);
                int[] iArr3 = this.f1440a;
                Arrays.fill(iArr3, iArr3.length - i2, iArr3.length, -1);
                List<C0256a> list = this.f1441b;
                if (list != null) {
                    for (int size = list.size() - 1; size >= 0; size--) {
                        C0256a aVar = this.f1441b.get(size);
                        int i4 = aVar.f1442X;
                        if (i4 >= i) {
                            if (i4 < i3) {
                                this.f1441b.remove(size);
                            } else {
                                aVar.f1442X = i4 - i2;
                            }
                        }
                    }
                }
            }
        }

        /* renamed from: c */
        public C0256a mo2063c(int i) {
            List<C0256a> list = this.f1441b;
            if (list == null) {
                return null;
            }
            for (int size = list.size() - 1; size >= 0; size--) {
                C0256a aVar = this.f1441b.get(size);
                if (aVar.f1442X == i) {
                    return aVar;
                }
            }
            return null;
        }

        /* JADX WARNING: Removed duplicated region for block: B:21:0x0048  */
        /* JADX WARNING: Removed duplicated region for block: B:23:0x0052  */
        /* renamed from: d */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public int mo2064d(int r5) {
            /*
                r4 = this;
                int[] r0 = r4.f1440a
                r1 = -1
                if (r0 != 0) goto L_0x0006
                return r1
            L_0x0006:
                int r0 = r0.length
                if (r5 < r0) goto L_0x000a
                return r1
            L_0x000a:
                java.util.List<androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a> r0 = r4.f1441b
                if (r0 != 0) goto L_0x0010
            L_0x000e:
                r0 = -1
                goto L_0x0046
            L_0x0010:
                androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a r0 = r4.mo2063c(r5)
                if (r0 == 0) goto L_0x001b
                java.util.List<androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a> r2 = r4.f1441b
                r2.remove(r0)
            L_0x001b:
                java.util.List<androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a> r0 = r4.f1441b
                int r0 = r0.size()
                r2 = 0
            L_0x0022:
                if (r2 >= r0) goto L_0x0034
                java.util.List<androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a> r3 = r4.f1441b
                java.lang.Object r3 = r3.get(r2)
                androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a r3 = (androidx.recyclerview.widget.StaggeredGridLayoutManager.C0255d.C0256a) r3
                int r3 = r3.f1442X
                if (r3 < r5) goto L_0x0031
                goto L_0x0035
            L_0x0031:
                int r2 = r2 + 1
                goto L_0x0022
            L_0x0034:
                r2 = -1
            L_0x0035:
                if (r2 == r1) goto L_0x000e
                java.util.List<androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a> r0 = r4.f1441b
                java.lang.Object r0 = r0.get(r2)
                androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a r0 = (androidx.recyclerview.widget.StaggeredGridLayoutManager.C0255d.C0256a) r0
                java.util.List<androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a> r3 = r4.f1441b
                r3.remove(r2)
                int r0 = r0.f1442X
            L_0x0046:
                if (r0 != r1) goto L_0x0052
                int[] r0 = r4.f1440a
                int r2 = r0.length
                java.util.Arrays.fill(r0, r5, r2, r1)
                int[] r5 = r4.f1440a
                int r5 = r5.length
                return r5
            L_0x0052:
                int[] r2 = r4.f1440a
                int r0 = r0 + 1
                java.util.Arrays.fill(r2, r5, r0, r1)
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.C0255d.mo2064d(int):int");
        }

        /* renamed from: a */
        public void mo2059a(int i, int i2) {
            int[] iArr = this.f1440a;
            if (iArr != null && i < iArr.length) {
                int i3 = i + i2;
                mo2058a(i3);
                int[] iArr2 = this.f1440a;
                System.arraycopy(iArr2, i, iArr2, i3, (iArr2.length - i) - i2);
                Arrays.fill(this.f1440a, i, i3, -1);
                List<C0256a> list = this.f1441b;
                if (list != null) {
                    for (int size = list.size() - 1; size >= 0; size--) {
                        C0256a aVar = this.f1441b.get(size);
                        int i4 = aVar.f1442X;
                        if (i4 >= i) {
                            aVar.f1442X = i4 + i2;
                        }
                    }
                }
            }
        }
    }

    /* renamed from: androidx.recyclerview.widget.StaggeredGridLayoutManager$f */
    public class C0260f {

        /* renamed from: a */
        public ArrayList<View> f1456a = new ArrayList<>();

        /* renamed from: b */
        public int f1457b = RecyclerView.UNDEFINED_DURATION;

        /* renamed from: c */
        public int f1458c = RecyclerView.UNDEFINED_DURATION;

        /* renamed from: d */
        public int f1459d = 0;

        /* renamed from: e */
        public final int f1460e;

        public C0260f(int i) {
            this.f1460e = i;
        }

        /* renamed from: a */
        public int mo2074a(int i) {
            int i2 = this.f1458c;
            if (i2 != Integer.MIN_VALUE) {
                return i2;
            }
            if (this.f1456a.size() == 0) {
                return i;
            }
            mo2077a();
            return this.f1458c;
        }

        /* renamed from: a */
        public View mo2076a(int i, int i2) {
            View view = null;
            if (i2 != -1) {
                int size = this.f1456a.size() - 1;
                while (size >= 0) {
                    View view2 = this.f1456a.get(size);
                    StaggeredGridLayoutManager staggeredGridLayoutManager = StaggeredGridLayoutManager.this;
                    if (staggeredGridLayoutManager.f1426w0 && staggeredGridLayoutManager.mo1949m(view2) >= i) {
                        break;
                    }
                    StaggeredGridLayoutManager staggeredGridLayoutManager2 = StaggeredGridLayoutManager.this;
                    if ((!staggeredGridLayoutManager2.f1426w0 && staggeredGridLayoutManager2.mo1949m(view2) <= i) || !view2.hasFocusable()) {
                        break;
                    }
                    size--;
                    view = view2;
                }
            } else {
                int size2 = this.f1456a.size();
                int i3 = 0;
                while (i3 < size2) {
                    View view3 = this.f1456a.get(i3);
                    StaggeredGridLayoutManager staggeredGridLayoutManager3 = StaggeredGridLayoutManager.this;
                    if (staggeredGridLayoutManager3.f1426w0 && staggeredGridLayoutManager3.mo1949m(view3) <= i) {
                        break;
                    }
                    StaggeredGridLayoutManager staggeredGridLayoutManager4 = StaggeredGridLayoutManager.this;
                    if ((!staggeredGridLayoutManager4.f1426w0 && staggeredGridLayoutManager4.mo1949m(view3) >= i) || !view3.hasFocusable()) {
                        break;
                    }
                    i3++;
                    view = view3;
                }
            }
            return view;
        }

        /* renamed from: a */
        public void mo2077a() {
            C0255d.C0256a c;
            ArrayList<View> arrayList = this.f1456a;
            View view = arrayList.get(arrayList.size() - 1);
            C0254c b = mo2080b(view);
            this.f1458c = StaggeredGridLayoutManager.this.f1421r0.mo12233a(view);
            if (b.f1439c0 && (c = StaggeredGridLayoutManager.this.f1407B0.mo2063c(b.mo1970n())) != null && c.f1443Y == 1) {
                int i = this.f1458c;
                int i2 = this.f1460e;
                int[] iArr = c.f1444Z;
                this.f1458c = (iArr == null ? 0 : iArr[i2]) + i;
            }
        }

        /* renamed from: a */
        public void mo2078a(View view) {
            C0254c b = mo2080b(view);
            b.f1438b0 = this;
            this.f1456a.add(view);
            this.f1458c = RecyclerView.UNDEFINED_DURATION;
            if (this.f1456a.size() == 1) {
                this.f1457b = RecyclerView.UNDEFINED_DURATION;
            }
            if (b.mo1972p() || b.mo1971o()) {
                this.f1459d = StaggeredGridLayoutManager.this.f1421r0.mo12236b(view) + this.f1459d;
            }
        }

        /* renamed from: b */
        public int mo2079b(int i) {
            int i2 = this.f1457b;
            if (i2 != Integer.MIN_VALUE) {
                return i2;
            }
            if (this.f1456a.size() == 0) {
                return i;
            }
            mo2081b();
            return this.f1457b;
        }

        /* renamed from: b */
        public C0254c mo2080b(View view) {
            return (C0254c) view.getLayoutParams();
        }

        /* renamed from: b */
        public void mo2081b() {
            C0255d.C0256a c;
            int i = 0;
            View view = this.f1456a.get(0);
            C0254c b = mo2080b(view);
            this.f1457b = StaggeredGridLayoutManager.this.f1421r0.mo12240d(view);
            if (b.f1439c0 && (c = StaggeredGridLayoutManager.this.f1407B0.mo2063c(b.mo1970n())) != null && c.f1443Y == -1) {
                int i2 = this.f1457b;
                int i3 = this.f1460e;
                int[] iArr = c.f1444Z;
                if (iArr != null) {
                    i = iArr[i3];
                }
                this.f1457b = i2 - i;
            }
        }

        /* renamed from: c */
        public void mo2082c() {
            this.f1456a.clear();
            this.f1457b = RecyclerView.UNDEFINED_DURATION;
            this.f1458c = RecyclerView.UNDEFINED_DURATION;
            this.f1459d = 0;
        }

        /* renamed from: c */
        public void mo2083c(View view) {
            C0254c b = mo2080b(view);
            b.f1438b0 = this;
            this.f1456a.add(0, view);
            this.f1457b = RecyclerView.UNDEFINED_DURATION;
            if (this.f1456a.size() == 1) {
                this.f1458c = RecyclerView.UNDEFINED_DURATION;
            }
            if (b.mo1972p() || b.mo1971o()) {
                this.f1459d = StaggeredGridLayoutManager.this.f1421r0.mo12236b(view) + this.f1459d;
            }
        }

        /* renamed from: d */
        public int mo2084d() {
            int i;
            int i2;
            if (StaggeredGridLayoutManager.this.f1426w0) {
                i2 = this.f1456a.size() - 1;
                i = -1;
            } else {
                i2 = 0;
                i = this.f1456a.size();
            }
            return mo2075a(i2, i, true);
        }

        /* renamed from: e */
        public int mo2085e() {
            int i;
            int i2;
            if (StaggeredGridLayoutManager.this.f1426w0) {
                i2 = 0;
                i = this.f1456a.size();
            } else {
                i2 = this.f1456a.size() - 1;
                i = -1;
            }
            return mo2075a(i2, i, true);
        }

        /* renamed from: f */
        public int mo2086f() {
            int i = this.f1458c;
            if (i != Integer.MIN_VALUE) {
                return i;
            }
            mo2077a();
            return this.f1458c;
        }

        /* renamed from: g */
        public int mo2087g() {
            int i = this.f1457b;
            if (i != Integer.MIN_VALUE) {
                return i;
            }
            mo2081b();
            return this.f1457b;
        }

        /* renamed from: h */
        public void mo2088h() {
            int size = this.f1456a.size();
            View remove = this.f1456a.remove(size - 1);
            C0254c b = mo2080b(remove);
            b.f1438b0 = null;
            if (b.mo1972p() || b.mo1971o()) {
                this.f1459d -= StaggeredGridLayoutManager.this.f1421r0.mo12236b(remove);
            }
            if (size == 1) {
                this.f1457b = RecyclerView.UNDEFINED_DURATION;
            }
            this.f1458c = RecyclerView.UNDEFINED_DURATION;
        }

        /* renamed from: i */
        public void mo2089i() {
            View remove = this.f1456a.remove(0);
            C0254c b = mo2080b(remove);
            b.f1438b0 = null;
            if (this.f1456a.size() == 0) {
                this.f1458c = RecyclerView.UNDEFINED_DURATION;
            }
            if (b.mo1972p() || b.mo1971o()) {
                this.f1459d -= StaggeredGridLayoutManager.this.f1421r0.mo12236b(remove);
            }
            this.f1457b = RecyclerView.UNDEFINED_DURATION;
        }

        /* renamed from: a */
        public int mo2075a(int i, int i2, boolean z) {
            int f = StaggeredGridLayoutManager.this.f1421r0.mo12243f();
            int b = StaggeredGridLayoutManager.this.f1421r0.mo12235b();
            int i3 = i2 > i ? 1 : -1;
            while (i != i2) {
                View view = this.f1456a.get(i);
                int d = StaggeredGridLayoutManager.this.f1421r0.mo12240d(view);
                int a = StaggeredGridLayoutManager.this.f1421r0.mo12233a(view);
                boolean z2 = false;
                boolean z3 = !z ? d < b : d <= b;
                if (!z ? a > f : a >= f) {
                    z2 = true;
                }
                if (z3 && z2 && (d < f || a > b)) {
                    return StaggeredGridLayoutManager.this.mo1949m(view);
                }
                i += i3;
            }
            return -1;
        }
    }

    /* renamed from: a */
    public void mo1553a(int i, int i2, RecyclerView.C0212a0 a0Var, RecyclerView.C0232o.C0235c cVar) {
        int i3;
        int i4;
        if (this.f1423t0 != 0) {
            i = i2;
        }
        if (mo1921f() != 0 && i != 0) {
            mo2022a(i, a0Var);
            int[] iArr = this.f1417L0;
            if (iArr == null || iArr.length < this.f1419p0) {
                this.f1417L0 = new int[this.f1419p0];
            }
            int i5 = 0;
            for (int i6 = 0; i6 < this.f1419p0; i6++) {
                C1851sc scVar = this.f1425v0;
                if (scVar.f14097d == -1) {
                    i4 = scVar.f14099f;
                    i3 = this.f1420q0[i6].mo2079b(i4);
                } else {
                    i4 = this.f1420q0[i6].mo2074a(scVar.f14100g);
                    i3 = this.f1425v0.f14100g;
                }
                int i7 = i4 - i3;
                if (i7 >= 0) {
                    this.f1417L0[i5] = i7;
                    i5++;
                }
            }
            Arrays.sort(this.f1417L0, 0, i5);
            int i8 = 0;
            while (i8 < i5) {
                int i9 = this.f1425v0.f14096c;
                if (i9 >= 0 && i9 < a0Var.mo1790a()) {
                    ((C1692qc.C1694b) cVar).mo10309a(this.f1425v0.f14096c, this.f1417L0[i8]);
                    C1851sc scVar2 = this.f1425v0;
                    scVar2.f14096c += scVar2.f14097d;
                    i8++;
                } else {
                    return;
                }
            }
        }
    }

    /* renamed from: b */
    public void mo2031b(RecyclerView.C0212a0 a0Var, C0253b bVar) {
        if (!mo2028a(a0Var, bVar)) {
            boolean z = this.f1409D0;
            int a = a0Var.mo1790a();
            int i = 0;
            if (!z) {
                int f = mo1921f();
                int i2 = 0;
                while (true) {
                    if (i2 < f) {
                        int m = mo1949m(mo1925g(i2));
                        if (m >= 0 && m < a) {
                            i = m;
                            break;
                        }
                        i2++;
                    } else {
                        break;
                    }
                }
            } else {
                int f2 = mo1921f();
                while (true) {
                    f2--;
                    if (f2 >= 0) {
                        int m2 = mo1949m(mo1925g(f2));
                        if (m2 >= 0 && m2 < a) {
                            i = m2;
                            break;
                        }
                    } else {
                        break;
                    }
                }
            }
            bVar.f1431a = i;
            bVar.f1432b = RecyclerView.UNDEFINED_DURATION;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:112:0x0226  */
    /* JADX WARNING: Removed duplicated region for block: B:124:0x0248  */
    /* JADX WARNING: Removed duplicated region for block: B:127:0x024d  */
    /* JADX WARNING: Removed duplicated region for block: B:134:0x0265  */
    /* JADX WARNING: Removed duplicated region for block: B:145:0x0287  */
    /* JADX WARNING: Removed duplicated region for block: B:150:0x02ae  */
    /* JADX WARNING: Removed duplicated region for block: B:157:0x02d4  */
    /* JADX WARNING: Removed duplicated region for block: B:158:0x02e1  */
    /* JADX WARNING: Removed duplicated region for block: B:161:0x02ef  */
    /* JADX WARNING: Removed duplicated region for block: B:162:0x02f7  */
    /* JADX WARNING: Removed duplicated region for block: B:169:0x0313  */
    /* JADX WARNING: Removed duplicated region for block: B:170:0x0319  */
    /* JADX WARNING: Removed duplicated region for block: B:80:0x018d  */
    /* JADX WARNING: Removed duplicated region for block: B:94:0x01d6  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final int mo2021a(androidx.recyclerview.widget.RecyclerView.C0244v r19, p000.C1851sc r20, androidx.recyclerview.widget.RecyclerView.C0212a0 r21) {
        /*
            r18 = this;
            r6 = r18
            r7 = r19
            r8 = r20
            java.util.BitSet r0 = r6.f1428y0
            int r1 = r6.f1419p0
            r9 = 1
            r10 = 0
            r0.set(r10, r1, r9)
            sc r0 = r6.f1425v0
            boolean r0 = r0.f14102i
            if (r0 == 0) goto L_0x0020
            int r0 = r8.f14098e
            if (r0 != r9) goto L_0x001d
            r13 = 2147483647(0x7fffffff, float:NaN)
            goto L_0x0030
        L_0x001d:
            r13 = -2147483648(0xffffffff80000000, float:-0.0)
            goto L_0x0030
        L_0x0020:
            int r0 = r8.f14098e
            if (r0 != r9) goto L_0x002a
            int r0 = r8.f14100g
            int r1 = r8.f14095b
            int r0 = r0 + r1
            goto L_0x002f
        L_0x002a:
            int r0 = r8.f14099f
            int r1 = r8.f14095b
            int r0 = r0 - r1
        L_0x002f:
            r13 = r0
        L_0x0030:
            int r0 = r8.f14098e
            r6.mo2040f(r0, r13)
            boolean r0 = r6.f1427x0
            if (r0 == 0) goto L_0x0040
            yc r0 = r6.f1421r0
            int r0 = r0.mo12235b()
            goto L_0x0046
        L_0x0040:
            yc r0 = r6.f1421r0
            int r0 = r0.mo12243f()
        L_0x0046:
            r14 = r0
            r0 = 0
        L_0x0048:
            int r1 = r8.f14096c
            if (r1 < 0) goto L_0x0054
            int r2 = r21.mo1790a()
            if (r1 >= r2) goto L_0x0054
            r1 = 1
            goto L_0x0055
        L_0x0054:
            r1 = 0
        L_0x0055:
            r2 = -1
            if (r1 == 0) goto L_0x0328
            sc r1 = r6.f1425v0
            boolean r1 = r1.f14102i
            if (r1 != 0) goto L_0x0066
            java.util.BitSet r1 = r6.f1428y0
            boolean r1 = r1.isEmpty()
            if (r1 != 0) goto L_0x0328
        L_0x0066:
            int r0 = r8.f14096c
            android.view.View r15 = r7.mo1991b((int) r0)
            int r0 = r8.f14096c
            int r1 = r8.f14097d
            int r0 = r0 + r1
            r8.f14096c = r0
            android.view.ViewGroup$LayoutParams r0 = r15.getLayoutParams()
            r5 = r0
            androidx.recyclerview.widget.StaggeredGridLayoutManager$c r5 = (androidx.recyclerview.widget.StaggeredGridLayoutManager.C0254c) r5
            int r0 = r5.mo1970n()
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r1 = r6.f1407B0
            int[] r1 = r1.f1440a
            if (r1 == 0) goto L_0x008b
            int r3 = r1.length
            if (r0 < r3) goto L_0x0088
            goto L_0x008b
        L_0x0088:
            r1 = r1[r0]
            goto L_0x008c
        L_0x008b:
            r1 = -1
        L_0x008c:
            if (r1 != r2) goto L_0x0090
            r3 = 1
            goto L_0x0091
        L_0x0090:
            r3 = 0
        L_0x0091:
            if (r3 == 0) goto L_0x00fc
            boolean r1 = r5.f1439c0
            if (r1 == 0) goto L_0x009c
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r1 = r6.f1420q0
            r1 = r1[r10]
            goto L_0x00f0
        L_0x009c:
            int r1 = r8.f14098e
            boolean r1 = r6.mo2047q(r1)
            if (r1 == 0) goto L_0x00ab
            int r1 = r6.f1419p0
            int r1 = r1 - r9
            r4 = -1
            r16 = -1
            goto L_0x00b1
        L_0x00ab:
            int r1 = r6.f1419p0
            r4 = r1
            r1 = 0
            r16 = 1
        L_0x00b1:
            int r11 = r8.f14098e
            r17 = 0
            if (r11 != r9) goto L_0x00d4
            yc r11 = r6.f1421r0
            int r11 = r11.mo12243f()
            r12 = 2147483647(0x7fffffff, float:NaN)
        L_0x00c0:
            if (r1 == r4) goto L_0x00ee
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r2 = r6.f1420q0
            r2 = r2[r1]
            int r10 = r2.mo2074a((int) r11)
            if (r10 >= r12) goto L_0x00cf
            r17 = r2
            r12 = r10
        L_0x00cf:
            int r1 = r1 + r16
            r2 = -1
            r10 = 0
            goto L_0x00c0
        L_0x00d4:
            yc r2 = r6.f1421r0
            int r2 = r2.mo12235b()
            r10 = -2147483648(0xffffffff80000000, float:-0.0)
        L_0x00dc:
            if (r1 == r4) goto L_0x00ee
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r11 = r6.f1420q0
            r11 = r11[r1]
            int r12 = r11.mo2079b((int) r2)
            if (r12 <= r10) goto L_0x00eb
            r17 = r11
            r10 = r12
        L_0x00eb:
            int r1 = r1 + r16
            goto L_0x00dc
        L_0x00ee:
            r1 = r17
        L_0x00f0:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r2 = r6.f1407B0
            r2.mo2058a((int) r0)
            int[] r2 = r2.f1440a
            int r4 = r1.f1460e
            r2[r0] = r4
            goto L_0x0100
        L_0x00fc:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r2 = r6.f1420q0
            r1 = r2[r1]
        L_0x0100:
            r10 = r1
            r5.f1438b0 = r10
            int r1 = r8.f14098e
            if (r1 != r9) goto L_0x010b
            r6.mo1908c((android.view.View) r15)
            goto L_0x010f
        L_0x010b:
            r1 = 0
            r6.mo1899b((android.view.View) r15, (int) r1)
        L_0x010f:
            boolean r1 = r5.f1439c0
            if (r1 == 0) goto L_0x0138
            int r1 = r6.f1423t0
            if (r1 != r9) goto L_0x011a
            int r1 = r6.f1412G0
            goto L_0x0149
        L_0x011a:
            int r1 = r18.mo1954p()
            int r2 = r18.mo1956q()
            int r4 = r18.getPaddingLeft()
            int r11 = r18.getPaddingRight()
            int r11 = r11 + r4
            int r4 = r5.width
            int r1 = androidx.recyclerview.widget.RecyclerView.C0232o.m1221a((int) r1, (int) r2, (int) r11, (int) r4, (boolean) r9)
            int r2 = r6.f1412G0
            r4 = 0
            r6.mo2023a((android.view.View) r15, (int) r1, (int) r2, (boolean) r4)
            goto L_0x0189
        L_0x0138:
            r4 = 0
            int r1 = r6.f1423t0
            if (r1 != r9) goto L_0x0162
            int r1 = r6.f1424u0
            int r2 = r18.mo1956q()
            int r11 = r5.width
            int r1 = androidx.recyclerview.widget.RecyclerView.C0232o.m1221a((int) r1, (int) r2, (int) r4, (int) r11, (boolean) r4)
        L_0x0149:
            int r2 = r18.mo1936i()
            int r4 = r18.mo1939j()
            int r11 = r18.getPaddingTop()
            int r12 = r18.getPaddingBottom()
            int r12 = r12 + r11
            int r11 = r5.height
            int r2 = androidx.recyclerview.widget.RecyclerView.C0232o.m1221a((int) r2, (int) r4, (int) r12, (int) r11, (boolean) r9)
            r12 = 0
            goto L_0x0186
        L_0x0162:
            int r1 = r18.mo1954p()
            int r2 = r18.mo1956q()
            int r4 = r18.getPaddingLeft()
            int r11 = r18.getPaddingRight()
            int r11 = r11 + r4
            int r4 = r5.width
            int r1 = androidx.recyclerview.widget.RecyclerView.C0232o.m1221a((int) r1, (int) r2, (int) r11, (int) r4, (boolean) r9)
            int r2 = r6.f1424u0
            int r4 = r18.mo1939j()
            int r11 = r5.height
            r12 = 0
            int r2 = androidx.recyclerview.widget.RecyclerView.C0232o.m1221a((int) r2, (int) r4, (int) r12, (int) r11, (boolean) r12)
        L_0x0186:
            r6.mo2023a((android.view.View) r15, (int) r1, (int) r2, (boolean) r12)
        L_0x0189:
            int r1 = r8.f14098e
            if (r1 != r9) goto L_0x01d6
            boolean r1 = r5.f1439c0
            if (r1 == 0) goto L_0x0196
            int r1 = r6.mo2045o(r14)
            goto L_0x019a
        L_0x0196:
            int r1 = r10.mo2074a((int) r14)
        L_0x019a:
            yc r2 = r6.f1421r0
            int r2 = r2.mo12236b(r15)
            int r2 = r2 + r1
            if (r3 == 0) goto L_0x01d3
            boolean r4 = r5.f1439c0
            if (r4 == 0) goto L_0x01d3
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a r4 = new androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a
            r4.<init>()
            int r11 = r6.f1419p0
            int[] r11 = new int[r11]
            r4.f1444Z = r11
            r11 = 0
        L_0x01b3:
            int r12 = r6.f1419p0
            if (r11 >= r12) goto L_0x01c9
            int[] r12 = r4.f1444Z
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r9 = r6.f1420q0
            r9 = r9[r11]
            int r9 = r9.mo2074a((int) r1)
            int r9 = r1 - r9
            r12[r11] = r9
            int r11 = r11 + 1
            r9 = 1
            goto L_0x01b3
        L_0x01c9:
            r9 = -1
            r4.f1443Y = r9
            r4.f1442X = r0
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r9 = r6.f1407B0
            r9.mo2060a((androidx.recyclerview.widget.StaggeredGridLayoutManager.C0255d.C0256a) r4)
        L_0x01d3:
            r4 = r1
            r9 = r2
            goto L_0x021d
        L_0x01d6:
            boolean r1 = r5.f1439c0
            if (r1 == 0) goto L_0x01df
            int r1 = r6.mo2046p(r14)
            goto L_0x01e3
        L_0x01df:
            int r1 = r10.mo2079b((int) r14)
        L_0x01e3:
            yc r2 = r6.f1421r0
            int r2 = r2.mo12236b(r15)
            int r2 = r1 - r2
            if (r3 == 0) goto L_0x021b
            boolean r4 = r5.f1439c0
            if (r4 == 0) goto L_0x021b
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a r4 = new androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a
            r4.<init>()
            int r9 = r6.f1419p0
            int[] r9 = new int[r9]
            r4.f1444Z = r9
            r9 = 0
        L_0x01fd:
            int r11 = r6.f1419p0
            if (r9 >= r11) goto L_0x0211
            int[] r11 = r4.f1444Z
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r12 = r6.f1420q0
            r12 = r12[r9]
            int r12 = r12.mo2079b((int) r1)
            int r12 = r12 - r1
            r11[r9] = r12
            int r9 = r9 + 1
            goto L_0x01fd
        L_0x0211:
            r9 = 1
            r4.f1443Y = r9
            r4.f1442X = r0
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r9 = r6.f1407B0
            r9.mo2060a((androidx.recyclerview.widget.StaggeredGridLayoutManager.C0255d.C0256a) r4)
        L_0x021b:
            r9 = r1
            r4 = r2
        L_0x021d:
            boolean r1 = r5.f1439c0
            if (r1 == 0) goto L_0x0248
            int r1 = r8.f14097d
            r2 = -1
            if (r1 != r2) goto L_0x0248
            if (r3 == 0) goto L_0x022a
            r2 = 1
            goto L_0x0245
        L_0x022a:
            int r1 = r8.f14098e
            r2 = 1
            if (r1 != r2) goto L_0x0234
            boolean r1 = r18.mo2011J()
            goto L_0x0238
        L_0x0234:
            boolean r1 = r18.mo2012K()
        L_0x0238:
            r1 = r1 ^ r2
            if (r1 == 0) goto L_0x0249
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r1 = r6.f1407B0
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a r0 = r1.mo2063c(r0)
            if (r0 == 0) goto L_0x0245
            r0.f1445a0 = r2
        L_0x0245:
            r6.f1415J0 = r2
            goto L_0x0249
        L_0x0248:
            r2 = 1
        L_0x0249:
            int r0 = r8.f14098e
            if (r0 != r2) goto L_0x0265
            boolean r0 = r5.f1439c0
            if (r0 == 0) goto L_0x025f
            int r0 = r6.f1419p0
        L_0x0253:
            r1 = -1
            int r0 = r0 + r1
            if (r0 < 0) goto L_0x027c
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r1 = r6.f1420q0
            r1 = r1[r0]
            r1.mo2078a((android.view.View) r15)
            goto L_0x0253
        L_0x025f:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f r0 = r5.f1438b0
            r0.mo2078a((android.view.View) r15)
            goto L_0x027c
        L_0x0265:
            boolean r0 = r5.f1439c0
            if (r0 == 0) goto L_0x0277
            int r0 = r6.f1419p0
        L_0x026b:
            r1 = -1
            int r0 = r0 + r1
            if (r0 < 0) goto L_0x027c
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r1 = r6.f1420q0
            r1 = r1[r0]
            r1.mo2083c(r15)
            goto L_0x026b
        L_0x0277:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f r0 = r5.f1438b0
            r0.mo2083c(r15)
        L_0x027c:
            boolean r0 = r18.mo2019R()
            if (r0 == 0) goto L_0x02ae
            int r0 = r6.f1423t0
            r1 = 1
            if (r0 != r1) goto L_0x02ae
            boolean r0 = r5.f1439c0
            if (r0 == 0) goto L_0x0292
            yc r0 = r6.f1422s0
            int r0 = r0.mo12235b()
            goto L_0x02a3
        L_0x0292:
            yc r0 = r6.f1422s0
            int r0 = r0.mo12235b()
            int r2 = r6.f1419p0
            int r2 = r2 - r1
            int r1 = r10.f1460e
            int r2 = r2 - r1
            int r1 = r6.f1424u0
            int r2 = r2 * r1
            int r0 = r0 - r2
        L_0x02a3:
            yc r1 = r6.f1422s0
            int r1 = r1.mo12236b(r15)
            int r1 = r0 - r1
            r11 = r0
            r3 = r1
            goto L_0x02cf
        L_0x02ae:
            boolean r0 = r5.f1439c0
            if (r0 == 0) goto L_0x02b9
            yc r0 = r6.f1422s0
            int r0 = r0.mo12243f()
            goto L_0x02c6
        L_0x02b9:
            int r0 = r10.f1460e
            int r1 = r6.f1424u0
            int r0 = r0 * r1
            yc r1 = r6.f1422s0
            int r1 = r1.mo12243f()
            int r0 = r0 + r1
        L_0x02c6:
            yc r1 = r6.f1422s0
            int r1 = r1.mo12236b(r15)
            int r1 = r1 + r0
            r3 = r0
            r11 = r1
        L_0x02cf:
            int r0 = r6.f1423t0
            r12 = 1
            if (r0 != r12) goto L_0x02e1
            r0 = r18
            r1 = r15
            r2 = r3
            r3 = r4
            r4 = r11
            r11 = r5
            r5 = r9
            r0.mo1874a((android.view.View) r1, (int) r2, (int) r3, (int) r4, (int) r5)
            r9 = r11
            goto L_0x02eb
        L_0x02e1:
            r0 = r18
            r1 = r15
            r2 = r4
            r4 = r9
            r9 = r5
            r5 = r11
            r0.mo1874a((android.view.View) r1, (int) r2, (int) r3, (int) r4, (int) r5)
        L_0x02eb:
            boolean r0 = r9.f1439c0
            if (r0 == 0) goto L_0x02f7
            sc r0 = r6.f1425v0
            int r0 = r0.f14098e
            r6.mo2040f(r0, r13)
            goto L_0x02fe
        L_0x02f7:
            sc r0 = r6.f1425v0
            int r0 = r0.f14098e
            r6.mo2027a((androidx.recyclerview.widget.StaggeredGridLayoutManager.C0260f) r10, (int) r0, (int) r13)
        L_0x02fe:
            sc r0 = r6.f1425v0
            r6.mo2026a((androidx.recyclerview.widget.RecyclerView.C0244v) r7, (p000.C1851sc) r0)
            sc r0 = r6.f1425v0
            boolean r0 = r0.f14101h
            if (r0 == 0) goto L_0x0322
            boolean r0 = r15.hasFocusable()
            if (r0 == 0) goto L_0x0322
            boolean r0 = r9.f1439c0
            if (r0 == 0) goto L_0x0319
            java.util.BitSet r0 = r6.f1428y0
            r0.clear()
            goto L_0x0322
        L_0x0319:
            java.util.BitSet r0 = r6.f1428y0
            int r1 = r10.f1460e
            r2 = 0
            r0.set(r1, r2)
            goto L_0x0323
        L_0x0322:
            r2 = 0
        L_0x0323:
            r0 = 1
            r9 = 1
            r10 = 0
            goto L_0x0048
        L_0x0328:
            r2 = 0
            if (r0 != 0) goto L_0x0330
            sc r0 = r6.f1425v0
            r6.mo2026a((androidx.recyclerview.widget.RecyclerView.C0244v) r7, (p000.C1851sc) r0)
        L_0x0330:
            sc r0 = r6.f1425v0
            int r0 = r0.f14098e
            r1 = -1
            if (r0 != r1) goto L_0x0349
            yc r0 = r6.f1421r0
            int r0 = r0.mo12243f()
            int r0 = r6.mo2046p(r0)
            yc r1 = r6.f1421r0
            int r1 = r1.mo12243f()
            int r1 = r1 - r0
            goto L_0x035b
        L_0x0349:
            yc r0 = r6.f1421r0
            int r0 = r0.mo12235b()
            int r0 = r6.mo2045o(r0)
            yc r1 = r6.f1421r0
            int r1 = r1.mo12235b()
            int r1 = r0 - r1
        L_0x035b:
            if (r1 <= 0) goto L_0x0364
            int r0 = r8.f14095b
            int r10 = java.lang.Math.min(r0, r1)
            r2 = r10
        L_0x0364:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.mo2021a(androidx.recyclerview.widget.RecyclerView$v, sc, androidx.recyclerview.widget.RecyclerView$a0):int");
    }

    /* JADX WARNING: Removed duplicated region for block: B:15:0x0034  */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x004b  */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo2030b(int r5, androidx.recyclerview.widget.RecyclerView.C0212a0 r6) {
        /*
            r4 = this;
            sc r0 = r4.f1425v0
            r1 = 0
            r0.f14095b = r1
            r0.f14096c = r5
            boolean r0 = r4.mo1962x()
            r2 = 1
            if (r0 == 0) goto L_0x002c
            int r6 = r6.f1289a
            r0 = -1
            if (r6 == r0) goto L_0x002c
            boolean r0 = r4.f1427x0
            if (r6 >= r5) goto L_0x0019
            r5 = 1
            goto L_0x001a
        L_0x0019:
            r5 = 0
        L_0x001a:
            if (r0 != r5) goto L_0x0023
            yc r5 = r4.f1421r0
            int r5 = r5.mo12245g()
            goto L_0x002d
        L_0x0023:
            yc r5 = r4.f1421r0
            int r5 = r5.mo12245g()
            r6 = r5
            r5 = 0
            goto L_0x002e
        L_0x002c:
            r5 = 0
        L_0x002d:
            r6 = 0
        L_0x002e:
            boolean r0 = r4.mo1926g()
            if (r0 == 0) goto L_0x004b
            sc r0 = r4.f1425v0
            yc r3 = r4.f1421r0
            int r3 = r3.mo12243f()
            int r3 = r3 - r6
            r0.f14099f = r3
            sc r6 = r4.f1425v0
            yc r0 = r4.f1421r0
            int r0 = r0.mo12235b()
            int r0 = r0 + r5
            r6.f14100g = r0
            goto L_0x005b
        L_0x004b:
            sc r0 = r4.f1425v0
            yc r3 = r4.f1421r0
            int r3 = r3.mo12232a()
            int r3 = r3 + r5
            r0.f14100g = r3
            sc r5 = r4.f1425v0
            int r6 = -r6
            r5.f14099f = r6
        L_0x005b:
            sc r5 = r4.f1425v0
            r5.f14101h = r1
            r5.f14094a = r2
            yc r6 = r4.f1421r0
            int r6 = r6.mo12239d()
            if (r6 != 0) goto L_0x0072
            yc r6 = r4.f1421r0
            int r6 = r6.mo12232a()
            if (r6 != 0) goto L_0x0072
            r1 = 1
        L_0x0072:
            r5.f14102i = r1
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.mo2030b(int, androidx.recyclerview.widget.RecyclerView$a0):void");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:25:0x003c, code lost:
        if (r9.f1423t0 == 1) goto L_0x003e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:28:0x0042, code lost:
        if (r9.f1423t0 == 0) goto L_0x003e;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:32:0x004e, code lost:
        if (mo2019R() == false) goto L_0x0030;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:36:0x005a, code lost:
        if (mo2019R() == false) goto L_0x003e;
     */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x005f A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x0060  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.View mo1495a(android.view.View r10, int r11, androidx.recyclerview.widget.RecyclerView.C0244v r12, androidx.recyclerview.widget.RecyclerView.C0212a0 r13) {
        /*
            r9 = this;
            int r0 = r9.mo1921f()
            r1 = 0
            if (r0 != 0) goto L_0x0008
            return r1
        L_0x0008:
            android.view.View r10 = r9.mo1912d((android.view.View) r10)
            if (r10 != 0) goto L_0x000f
            return r1
        L_0x000f:
            r9.mo2020S()
            r0 = -1
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = 1
            if (r11 == r3) goto L_0x0051
            r4 = 2
            if (r11 == r4) goto L_0x0045
            r4 = 17
            if (r11 == r4) goto L_0x0040
            r4 = 33
            if (r11 == r4) goto L_0x003a
            r4 = 66
            if (r11 == r4) goto L_0x0035
            r4 = 130(0x82, float:1.82E-43)
            if (r11 == r4) goto L_0x002c
            goto L_0x0032
        L_0x002c:
            int r11 = r9.f1423t0
            if (r11 != r3) goto L_0x0032
        L_0x0030:
            r11 = 1
            goto L_0x005d
        L_0x0032:
            r11 = -2147483648(0xffffffff80000000, float:-0.0)
            goto L_0x005d
        L_0x0035:
            int r11 = r9.f1423t0
            if (r11 != 0) goto L_0x0032
            goto L_0x0030
        L_0x003a:
            int r11 = r9.f1423t0
            if (r11 != r3) goto L_0x0032
        L_0x003e:
            r11 = -1
            goto L_0x005d
        L_0x0040:
            int r11 = r9.f1423t0
            if (r11 != 0) goto L_0x0032
        L_0x0044:
            goto L_0x003e
        L_0x0045:
            int r11 = r9.f1423t0
            if (r11 != r3) goto L_0x004a
            goto L_0x0030
        L_0x004a:
            boolean r11 = r9.mo2019R()
            if (r11 == 0) goto L_0x0030
            goto L_0x0055
        L_0x0051:
            int r11 = r9.f1423t0
            if (r11 != r3) goto L_0x0056
        L_0x0055:
            goto L_0x0044
        L_0x0056:
            boolean r11 = r9.mo2019R()
            if (r11 == 0) goto L_0x003e
            goto L_0x0030
        L_0x005d:
            if (r11 != r2) goto L_0x0060
            return r1
        L_0x0060:
            android.view.ViewGroup$LayoutParams r2 = r10.getLayoutParams()
            androidx.recyclerview.widget.StaggeredGridLayoutManager$c r2 = (androidx.recyclerview.widget.StaggeredGridLayoutManager.C0254c) r2
            boolean r4 = r2.f1439c0
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f r2 = r2.f1438b0
            if (r11 != r3) goto L_0x0071
            int r5 = r9.mo2016O()
            goto L_0x0075
        L_0x0071:
            int r5 = r9.mo2015N()
        L_0x0075:
            r9.mo2030b((int) r5, (androidx.recyclerview.widget.RecyclerView.C0212a0) r13)
            r9.mo2048r(r11)
            sc r6 = r9.f1425v0
            int r7 = r6.f14097d
            int r7 = r7 + r5
            r6.f14096c = r7
            r7 = 1051372203(0x3eaaaaab, float:0.33333334)
            yc r8 = r9.f1421r0
            int r8 = r8.mo12245g()
            float r8 = (float) r8
            float r8 = r8 * r7
            int r7 = (int) r8
            r6.f14095b = r7
            sc r6 = r9.f1425v0
            r6.f14101h = r3
            r7 = 0
            r6.f14094a = r7
            r9.mo2021a((androidx.recyclerview.widget.RecyclerView.C0244v) r12, (p000.C1851sc) r6, (androidx.recyclerview.widget.RecyclerView.C0212a0) r13)
            boolean r12 = r9.f1427x0
            r9.f1409D0 = r12
            if (r4 != 0) goto L_0x00aa
            android.view.View r12 = r2.mo2076a(r5, r11)
            if (r12 == 0) goto L_0x00aa
            if (r12 == r10) goto L_0x00aa
            return r12
        L_0x00aa:
            boolean r12 = r9.mo2047q(r11)
            if (r12 == 0) goto L_0x00c5
            int r12 = r9.f1419p0
            int r12 = r12 - r3
        L_0x00b3:
            if (r12 < 0) goto L_0x00da
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r13 = r9.f1420q0
            r13 = r13[r12]
            android.view.View r13 = r13.mo2076a(r5, r11)
            if (r13 == 0) goto L_0x00c2
            if (r13 == r10) goto L_0x00c2
            return r13
        L_0x00c2:
            int r12 = r12 + -1
            goto L_0x00b3
        L_0x00c5:
            r12 = 0
        L_0x00c6:
            int r13 = r9.f1419p0
            if (r12 >= r13) goto L_0x00da
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r13 = r9.f1420q0
            r13 = r13[r12]
            android.view.View r13 = r13.mo2076a(r5, r11)
            if (r13 == 0) goto L_0x00d7
            if (r13 == r10) goto L_0x00d7
            return r13
        L_0x00d7:
            int r12 = r12 + 1
            goto L_0x00c6
        L_0x00da:
            boolean r12 = r9.f1426w0
            r12 = r12 ^ r3
            if (r11 != r0) goto L_0x00e1
            r13 = 1
            goto L_0x00e2
        L_0x00e1:
            r13 = 0
        L_0x00e2:
            if (r12 != r13) goto L_0x00e6
            r12 = 1
            goto L_0x00e7
        L_0x00e6:
            r12 = 0
        L_0x00e7:
            if (r4 != 0) goto L_0x00fd
            if (r12 == 0) goto L_0x00f0
            int r13 = r2.mo2084d()
            goto L_0x00f4
        L_0x00f0:
            int r13 = r2.mo2085e()
        L_0x00f4:
            android.view.View r13 = r9.mo1574f((int) r13)
            if (r13 == 0) goto L_0x00fd
            if (r13 == r10) goto L_0x00fd
            return r13
        L_0x00fd:
            boolean r11 = r9.mo2047q(r11)
            if (r11 == 0) goto L_0x012a
            int r11 = r9.f1419p0
            int r11 = r11 - r3
        L_0x0106:
            if (r11 < 0) goto L_0x014b
            int r13 = r2.f1460e
            if (r11 != r13) goto L_0x010d
            goto L_0x0127
        L_0x010d:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r13 = r9.f1420q0
            if (r12 == 0) goto L_0x0118
            r13 = r13[r11]
            int r13 = r13.mo2084d()
            goto L_0x011e
        L_0x0118:
            r13 = r13[r11]
            int r13 = r13.mo2085e()
        L_0x011e:
            android.view.View r13 = r9.mo1574f((int) r13)
            if (r13 == 0) goto L_0x0127
            if (r13 == r10) goto L_0x0127
            return r13
        L_0x0127:
            int r11 = r11 + -1
            goto L_0x0106
        L_0x012a:
            int r11 = r9.f1419p0
            if (r7 >= r11) goto L_0x014b
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r11 = r9.f1420q0
            if (r12 == 0) goto L_0x0139
            r11 = r11[r7]
            int r11 = r11.mo2084d()
            goto L_0x013f
        L_0x0139:
            r11 = r11[r7]
            int r11 = r11.mo2085e()
        L_0x013f:
            android.view.View r11 = r9.mo1574f((int) r11)
            if (r11 == 0) goto L_0x0148
            if (r11 == r10) goto L_0x0148
            return r11
        L_0x0148:
            int r7 = r7 + 1
            goto L_0x012a
        L_0x014b:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.mo1495a(android.view.View, int, androidx.recyclerview.widget.RecyclerView$v, androidx.recyclerview.widget.RecyclerView$a0):android.view.View");
    }

    /* renamed from: a */
    public void mo1557a(AccessibilityEvent accessibilityEvent) {
        RecyclerView recyclerView = this.f1348Y;
        RecyclerView.C0244v vVar = recyclerView.mRecycler;
        RecyclerView.C0212a0 a0Var = recyclerView.mState;
        mo1902b(accessibilityEvent);
        if (mo1921f() > 0) {
            View c = mo2035c(false);
            View b = mo2029b(false);
            if (c != null && b != null) {
                int m = mo1949m(c);
                int m2 = mo1949m(b);
                if (m < m2) {
                    accessibilityEvent.setFromIndex(m);
                    accessibilityEvent.setToIndex(m2);
                    return;
                }
                accessibilityEvent.setFromIndex(m2);
                accessibilityEvent.setToIndex(m);
            }
        }
    }

    /* renamed from: a */
    public void mo1502a(RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var, View view, C0759g8 g8Var) {
        int i;
        int i2;
        int i3;
        int i4;
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (!(layoutParams instanceof C0254c)) {
            super.mo1879a(view, g8Var);
            return;
        }
        C0254c cVar = (C0254c) layoutParams;
        int i5 = 1;
        if (this.f1423t0 == 0) {
            C0260f fVar = cVar.f1438b0;
            int i6 = fVar == null ? -1 : fVar.f1460e;
            if (cVar.f1439c0) {
                i5 = this.f1419p0;
            }
            i4 = i6;
            i3 = i5;
            i2 = -1;
            i = -1;
        } else {
            C0260f fVar2 = cVar.f1438b0;
            int i7 = fVar2 == null ? -1 : fVar2.f1460e;
            if (cVar.f1439c0) {
                i2 = i7;
                i = this.f1419p0;
                i4 = -1;
                i3 = -1;
            } else {
                i2 = i7;
                i4 = -1;
                i3 = -1;
                i = 1;
            }
        }
        g8Var.mo6041b((Object) C0759g8.C0762c.m5406a(i4, i3, i2, i, false, false));
    }

    /* JADX WARNING: Code restructure failed: missing block: B:7:0x0011, code lost:
        if (r6.f14098e == -1) goto L_0x0013;
     */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo2026a(androidx.recyclerview.widget.RecyclerView.C0244v r5, p000.C1851sc r6) {
        /*
            r4 = this;
            boolean r0 = r6.f14094a
            if (r0 == 0) goto L_0x007c
            boolean r0 = r6.f14102i
            if (r0 == 0) goto L_0x000a
            goto L_0x007c
        L_0x000a:
            int r0 = r6.f14095b
            r1 = -1
            if (r0 != 0) goto L_0x001f
            int r0 = r6.f14098e
            if (r0 != r1) goto L_0x0019
        L_0x0013:
            int r6 = r6.f14100g
        L_0x0015:
            r4.mo2024a((androidx.recyclerview.widget.RecyclerView.C0244v) r5, (int) r6)
            goto L_0x007c
        L_0x0019:
            int r6 = r6.f14099f
        L_0x001b:
            r4.mo2032b((androidx.recyclerview.widget.RecyclerView.C0244v) r5, (int) r6)
            goto L_0x007c
        L_0x001f:
            int r0 = r6.f14098e
            r2 = 0
            r3 = 1
            if (r0 != r1) goto L_0x0050
            int r0 = r6.f14099f
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r1 = r4.f1420q0
            r1 = r1[r2]
            int r1 = r1.mo2079b((int) r0)
        L_0x002f:
            int r2 = r4.f1419p0
            if (r3 >= r2) goto L_0x0041
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r2 = r4.f1420q0
            r2 = r2[r3]
            int r2 = r2.mo2079b((int) r0)
            if (r2 <= r1) goto L_0x003e
            r1 = r2
        L_0x003e:
            int r3 = r3 + 1
            goto L_0x002f
        L_0x0041:
            int r0 = r0 - r1
            if (r0 >= 0) goto L_0x0045
            goto L_0x0013
        L_0x0045:
            int r1 = r6.f14100g
            int r6 = r6.f14095b
            int r6 = java.lang.Math.min(r0, r6)
            int r6 = r1 - r6
            goto L_0x0015
        L_0x0050:
            int r0 = r6.f14100g
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r1 = r4.f1420q0
            r1 = r1[r2]
            int r1 = r1.mo2074a((int) r0)
        L_0x005a:
            int r2 = r4.f1419p0
            if (r3 >= r2) goto L_0x006c
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r2 = r4.f1420q0
            r2 = r2[r3]
            int r2 = r2.mo2074a((int) r0)
            if (r2 >= r1) goto L_0x0069
            r1 = r2
        L_0x0069:
            int r3 = r3 + 1
            goto L_0x005a
        L_0x006c:
            int r0 = r6.f14100g
            int r1 = r1 - r0
            if (r1 >= 0) goto L_0x0072
            goto L_0x0019
        L_0x0072:
            int r0 = r6.f14099f
            int r6 = r6.f14095b
            int r6 = java.lang.Math.min(r1, r6)
            int r6 = r6 + r0
            goto L_0x001b
        L_0x007c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.mo2026a(androidx.recyclerview.widget.RecyclerView$v, sc):void");
    }

    /* renamed from: a */
    public void mo1561a(RecyclerView recyclerView, RecyclerView.C0212a0 a0Var, int i) {
        C1913tc tcVar = new C1913tc(recyclerView.getContext());
        tcVar.f1391a = i;
        mo1904b((RecyclerView.C0249z) tcVar);
    }

    /* renamed from: a */
    public boolean mo2028a(RecyclerView.C0212a0 a0Var, C0253b bVar) {
        int i;
        int i2;
        int i3;
        boolean z = false;
        if (!a0Var.f1296h && (i = this.f1429z0) != -1) {
            if (i < 0 || i >= a0Var.mo1790a()) {
                this.f1429z0 = -1;
                this.f1406A0 = RecyclerView.UNDEFINED_DURATION;
            } else {
                C0258e eVar = this.f1411F0;
                if (eVar == null || eVar.f1446X == -1 || eVar.f1448Z < 1) {
                    View f = mo1574f(this.f1429z0);
                    if (f != null) {
                        bVar.f1431a = this.f1427x0 ? mo2016O() : mo2015N();
                        if (this.f1406A0 != Integer.MIN_VALUE) {
                            if (bVar.f1433c) {
                                i3 = this.f1421r0.mo12235b() - this.f1406A0;
                                i2 = this.f1421r0.mo12233a(f);
                            } else {
                                i3 = this.f1421r0.mo12243f() + this.f1406A0;
                                i2 = this.f1421r0.mo12240d(f);
                            }
                            bVar.f1432b = i3 - i2;
                            return true;
                        } else if (this.f1421r0.mo12236b(f) > this.f1421r0.mo12245g()) {
                            bVar.f1432b = bVar.f1433c ? this.f1421r0.mo12235b() : this.f1421r0.mo12243f();
                            return true;
                        } else {
                            int d = this.f1421r0.mo12240d(f) - this.f1421r0.mo12243f();
                            if (d < 0) {
                                bVar.f1432b = -d;
                                return true;
                            }
                            int b = this.f1421r0.mo12235b() - this.f1421r0.mo12233a(f);
                            if (b < 0) {
                                bVar.f1432b = b;
                                return true;
                            }
                            bVar.f1432b = RecyclerView.UNDEFINED_DURATION;
                        }
                    } else {
                        bVar.f1431a = this.f1429z0;
                        int i4 = this.f1406A0;
                        if (i4 == Integer.MIN_VALUE) {
                            if (mo2044n(bVar.f1431a) == 1) {
                                z = true;
                            }
                            bVar.f1433c = z;
                            bVar.mo2053a();
                        } else {
                            bVar.f1432b = bVar.f1433c ? StaggeredGridLayoutManager.this.f1421r0.mo12235b() - i4 : StaggeredGridLayoutManager.this.f1421r0.mo12243f() + i4;
                        }
                        bVar.f1434d = true;
                    }
                } else {
                    bVar.f1432b = RecyclerView.UNDEFINED_DURATION;
                    bVar.f1431a = this.f1429z0;
                }
                return true;
            }
        }
        return false;
    }

    /* renamed from: a */
    public final void mo2027a(C0260f fVar, int i, int i2) {
        int i3 = fVar.f1459d;
        if (i == -1) {
            int i4 = fVar.f1457b;
            if (i4 == Integer.MIN_VALUE) {
                fVar.mo2081b();
                i4 = fVar.f1457b;
            }
            if (i4 + i3 > i2) {
                return;
            }
        } else {
            int i5 = fVar.f1458c;
            if (i5 == Integer.MIN_VALUE) {
                fVar.mo2077a();
                i5 = fVar.f1458c;
            }
            if (i5 - i3 < i2) {
                return;
            }
        }
        this.f1428y0.set(fVar.f1460e, false);
    }
}
