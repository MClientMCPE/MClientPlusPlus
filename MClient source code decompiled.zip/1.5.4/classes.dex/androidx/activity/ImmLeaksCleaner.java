package androidx.activity;

import android.app.Activity;
import java.lang.reflect.Field;

public final class ImmLeaksCleaner implements C1321mb {

    /* renamed from: b */
    public static int f641b;

    /* renamed from: c */
    public static Field f642c;

    /* renamed from: d */
    public static Field f643d;

    /* renamed from: e */
    public static Field f644e;

    /* renamed from: a */
    public Activity f645a;

    public ImmLeaksCleaner(Activity activity) {
        this.f645a = activity;
    }

    /* JADX WARNING: Can't wrap try/catch for region: R(3:32|33|34) */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x0076, code lost:
        return;
     */
    /* JADX WARNING: Missing exception handler attribute for start block: B:32:0x0075 */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo644a(p000.C1509ob r3, p000.C1234lb.C1235a r4) {
        /*
            r2 = this;
            lb$a r3 = p000.C1234lb.C1235a.ON_DESTROY
            if (r4 == r3) goto L_0x0005
            return
        L_0x0005:
            int r3 = f641b
            r4 = 1
            if (r3 != 0) goto L_0x003e
            r3 = 2
            f641b = r3     // Catch:{ NoSuchFieldException -> 0x003d }
            java.lang.Class<android.view.inputmethod.InputMethodManager> r3 = android.view.inputmethod.InputMethodManager.class
            java.lang.String r0 = "mServedView"
            java.lang.reflect.Field r3 = r3.getDeclaredField(r0)     // Catch:{ NoSuchFieldException -> 0x003d }
            f643d = r3     // Catch:{ NoSuchFieldException -> 0x003d }
            java.lang.reflect.Field r3 = f643d     // Catch:{ NoSuchFieldException -> 0x003d }
            r3.setAccessible(r4)     // Catch:{ NoSuchFieldException -> 0x003d }
            java.lang.Class<android.view.inputmethod.InputMethodManager> r3 = android.view.inputmethod.InputMethodManager.class
            java.lang.String r0 = "mNextServedView"
            java.lang.reflect.Field r3 = r3.getDeclaredField(r0)     // Catch:{ NoSuchFieldException -> 0x003d }
            f644e = r3     // Catch:{ NoSuchFieldException -> 0x003d }
            java.lang.reflect.Field r3 = f644e     // Catch:{ NoSuchFieldException -> 0x003d }
            r3.setAccessible(r4)     // Catch:{ NoSuchFieldException -> 0x003d }
            java.lang.Class<android.view.inputmethod.InputMethodManager> r3 = android.view.inputmethod.InputMethodManager.class
            java.lang.String r0 = "mH"
            java.lang.reflect.Field r3 = r3.getDeclaredField(r0)     // Catch:{ NoSuchFieldException -> 0x003d }
            f642c = r3     // Catch:{ NoSuchFieldException -> 0x003d }
            java.lang.reflect.Field r3 = f642c     // Catch:{ NoSuchFieldException -> 0x003d }
            r3.setAccessible(r4)     // Catch:{ NoSuchFieldException -> 0x003d }
            f641b = r4     // Catch:{ NoSuchFieldException -> 0x003d }
            goto L_0x003e
        L_0x003d:
        L_0x003e:
            int r3 = f641b
            if (r3 != r4) goto L_0x007f
            android.app.Activity r3 = r2.f645a
            java.lang.String r4 = "input_method"
            java.lang.Object r3 = r3.getSystemService(r4)
            android.view.inputmethod.InputMethodManager r3 = (android.view.inputmethod.InputMethodManager) r3
            java.lang.reflect.Field r4 = f642c     // Catch:{ IllegalAccessException -> 0x007f }
            java.lang.Object r4 = r4.get(r3)     // Catch:{ IllegalAccessException -> 0x007f }
            if (r4 != 0) goto L_0x0055
            return
        L_0x0055:
            monitor-enter(r4)
            java.lang.reflect.Field r0 = f643d     // Catch:{ IllegalAccessException -> 0x007b, ClassCastException -> 0x0079 }
            java.lang.Object r0 = r0.get(r3)     // Catch:{ IllegalAccessException -> 0x007b, ClassCastException -> 0x0079 }
            android.view.View r0 = (android.view.View) r0     // Catch:{ IllegalAccessException -> 0x007b, ClassCastException -> 0x0079 }
            if (r0 != 0) goto L_0x0062
            monitor-exit(r4)     // Catch:{ all -> 0x0077 }
            return
        L_0x0062:
            boolean r0 = r0.isAttachedToWindow()     // Catch:{ all -> 0x0077 }
            if (r0 == 0) goto L_0x006a
            monitor-exit(r4)     // Catch:{ all -> 0x0077 }
            return
        L_0x006a:
            java.lang.reflect.Field r0 = f644e     // Catch:{ IllegalAccessException -> 0x0075 }
            r1 = 0
            r0.set(r3, r1)     // Catch:{ IllegalAccessException -> 0x0075 }
            monitor-exit(r4)     // Catch:{ all -> 0x0077 }
            r3.isActive()
            goto L_0x007f
        L_0x0075:
            monitor-exit(r4)     // Catch:{ all -> 0x0077 }
            return
        L_0x0077:
            r3 = move-exception
            goto L_0x007d
        L_0x0079:
            monitor-exit(r4)     // Catch:{ all -> 0x0077 }
            return
        L_0x007b:
            monitor-exit(r4)     // Catch:{ all -> 0x0077 }
            return
        L_0x007d:
            monitor-exit(r4)     // Catch:{ all -> 0x0077 }
            throw r3
        L_0x007f:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.activity.ImmLeaksCleaner.mo644a(ob, lb$a):void");
    }
}
