package androidx.activity;

import android.app.Activity;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import p000.C1234lb;

public class ComponentActivity extends androidx.core.app.ComponentActivity implements C1509ob, C0296bc, C0857hd, C0331c {

    /* renamed from: Y */
    public final C1607pb f632Y = new C1607pb(this);

    /* renamed from: Z */
    public final C0768gd f633Z = new C0768gd(this);

    /* renamed from: a0 */
    public C0091ac f634a0;

    /* renamed from: b0 */
    public final OnBackPressedDispatcher f635b0 = new OnBackPressedDispatcher(new C0122a());

    /* renamed from: c0 */
    public int f636c0;

    /* renamed from: androidx.activity.ComponentActivity$a */
    public class C0122a implements Runnable {
        public C0122a() {
        }

        public void run() {
            ComponentActivity.super.onBackPressed();
        }
    }

    /* renamed from: androidx.activity.ComponentActivity$b */
    public static final class C0123b {

        /* renamed from: a */
        public C0091ac f640a;
    }

    public ComponentActivity() {
        if (mo635a() != null) {
            int i = Build.VERSION.SDK_INT;
            mo635a().mo8347a(new C1321mb() {
                /* renamed from: a */
                public void mo644a(C1509ob obVar, C1234lb.C1235a aVar) {
                    if (aVar == C1234lb.C1235a.ON_STOP) {
                        Window window = ComponentActivity.this.getWindow();
                        View peekDecorView = window != null ? window.peekDecorView() : null;
                        if (peekDecorView != null) {
                            peekDecorView.cancelPendingInputEvents();
                        }
                    }
                }
            });
            mo635a().mo8347a(new C1321mb() {
                /* renamed from: a */
                public void mo644a(C1509ob obVar, C1234lb.C1235a aVar) {
                    if (aVar == C1234lb.C1235a.ON_DESTROY && !ComponentActivity.this.isChangingConfigurations()) {
                        ComponentActivity.this.mo638d().mo361a();
                    }
                }
            });
            if (Build.VERSION.SDK_INT <= 23) {
                mo635a().mo8347a(new ImmLeaksCleaner(this));
                return;
            }
            return;
        }
        throw new IllegalStateException("getLifecycle() returned null in ComponentActivity's constructor. Please make sure you are lazily constructing your Lifecycle in the first call to getLifecycle() rather than relying on field initialization.");
    }

    /* renamed from: a */
    public C1234lb mo635a() {
        return this.f632Y;
    }

    /* renamed from: b */
    public final OnBackPressedDispatcher mo636b() {
        return this.f635b0;
    }

    /* renamed from: c */
    public final C0677fd mo637c() {
        return this.f633Z.f6093b;
    }

    /* renamed from: d */
    public C0091ac mo638d() {
        if (getApplication() != null) {
            if (this.f634a0 == null) {
                C0123b bVar = (C0123b) getLastNonConfigurationInstance();
                if (bVar != null) {
                    this.f634a0 = bVar.f640a;
                }
                if (this.f634a0 == null) {
                    this.f634a0 = new C0091ac();
                }
            }
            return this.f634a0;
        }
        throw new IllegalStateException("Your activity is not yet attached to the Application instance. You can't request ViewModel before onCreate call.");
    }

    @Deprecated
    /* renamed from: g */
    public Object mo639g() {
        return null;
    }

    public void onBackPressed() {
        this.f635b0.mo646a();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f633Z.mo6069a(bundle);
        C2209wb.m15093a((Activity) this);
        int i = this.f636c0;
        if (i != 0) {
            setContentView(i);
        }
    }

    public final Object onRetainNonConfigurationInstance() {
        C0123b bVar;
        Object g = mo639g();
        C0091ac acVar = this.f634a0;
        if (acVar == null && (bVar = (C0123b) getLastNonConfigurationInstance()) != null) {
            acVar = bVar.f640a;
        }
        if (acVar == null && g == null) {
            return null;
        }
        C0123b bVar2 = new C0123b();
        bVar2.f640a = acVar;
        return bVar2;
    }

    public void onSaveInstanceState(Bundle bundle) {
        C1234lb a = mo635a();
        if (a instanceof C1607pb) {
            ((C1607pb) a).mo9941a(C1234lb.C1236b.CREATED);
        }
        super.onSaveInstanceState(bundle);
        this.f633Z.f6093b.mo5549a(bundle);
    }
}
