package androidx.activity;

import java.util.ArrayDeque;
import java.util.Iterator;
import p000.C1234lb;

public final class OnBackPressedDispatcher {

    /* renamed from: a */
    public final Runnable f646a;

    /* renamed from: b */
    public final ArrayDeque<C0275b> f647b = new ArrayDeque<>();

    public class LifecycleOnBackPressedCancellable implements C1321mb, C0010a {

        /* renamed from: a */
        public final C1234lb f648a;

        /* renamed from: b */
        public final C0275b f649b;

        /* renamed from: c */
        public C0010a f650c;

        public LifecycleOnBackPressedCancellable(C1234lb lbVar, C0275b bVar) {
            this.f648a = lbVar;
            this.f649b = bVar;
            lbVar.mo8347a(this);
        }

        /* renamed from: a */
        public void mo644a(C1509ob obVar, C1234lb.C1235a aVar) {
            if (aVar == C1234lb.C1235a.ON_START) {
                OnBackPressedDispatcher onBackPressedDispatcher = OnBackPressedDispatcher.this;
                C0275b bVar = this.f649b;
                onBackPressedDispatcher.f647b.add(bVar);
                C0124a aVar2 = new C0124a(bVar);
                bVar.mo2218a(aVar2);
                this.f650c = aVar2;
            } else if (aVar == C1234lb.C1235a.ON_STOP) {
                C0010a aVar3 = this.f650c;
                if (aVar3 != null) {
                    aVar3.cancel();
                }
            } else if (aVar == C1234lb.C1235a.ON_DESTROY) {
                cancel();
            }
        }

        public void cancel() {
            ((C1607pb) this.f648a).f12332a.remove(this);
            this.f649b.f1610b.remove(this);
            C0010a aVar = this.f650c;
            if (aVar != null) {
                aVar.cancel();
                this.f650c = null;
            }
        }
    }

    /* renamed from: androidx.activity.OnBackPressedDispatcher$a */
    public class C0124a implements C0010a {

        /* renamed from: a */
        public final C0275b f652a;

        public C0124a(C0275b bVar) {
            this.f652a = bVar;
        }

        public void cancel() {
            OnBackPressedDispatcher.this.f647b.remove(this.f652a);
            this.f652a.f1610b.remove(this);
        }
    }

    public OnBackPressedDispatcher(Runnable runnable) {
        this.f646a = runnable;
    }

    /* renamed from: a */
    public void mo647a(C1509ob obVar, C0275b bVar) {
        C1234lb a = obVar.mo635a();
        if (((C1607pb) a).f12333b != C1234lb.C1236b.DESTROYED) {
            bVar.f1610b.add(new LifecycleOnBackPressedCancellable(a, bVar));
        }
    }

    /* renamed from: a */
    public void mo646a() {
        Iterator<C0275b> descendingIterator = this.f647b.descendingIterator();
        while (descendingIterator.hasNext()) {
            C0275b next = descendingIterator.next();
            if (next.f1609a) {
                C1002ja jaVar = C1002ja.this;
                jaVar.mo7545i();
                if (jaVar.f8217h0.f1609a) {
                    jaVar.mo6884b();
                    return;
                } else {
                    jaVar.f8216g0.mo646a();
                    return;
                }
            }
        }
        Runnable runnable = this.f646a;
        if (runnable != null) {
            runnable.run();
        }
    }
}
