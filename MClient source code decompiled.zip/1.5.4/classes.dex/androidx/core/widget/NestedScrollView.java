package androidx.core.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import android.widget.ScrollView;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

public class NestedScrollView extends FrameLayout implements C1502o7, C1131k7, C1984u7 {

    /* renamed from: A0 */
    public static final C0183a f1074A0 = new C0183a();

    /* renamed from: B0 */
    public static final int[] f1075B0 = {16843130};

    /* renamed from: a0 */
    public long f1076a0;

    /* renamed from: b0 */
    public final Rect f1077b0;

    /* renamed from: c0 */
    public OverScroller f1078c0;

    /* renamed from: d0 */
    public EdgeEffect f1079d0;

    /* renamed from: e0 */
    public EdgeEffect f1080e0;

    /* renamed from: f0 */
    public int f1081f0;

    /* renamed from: g0 */
    public boolean f1082g0;

    /* renamed from: h0 */
    public boolean f1083h0;

    /* renamed from: i0 */
    public View f1084i0;

    /* renamed from: j0 */
    public boolean f1085j0;

    /* renamed from: k0 */
    public VelocityTracker f1086k0;

    /* renamed from: l0 */
    public boolean f1087l0;

    /* renamed from: m0 */
    public boolean f1088m0;

    /* renamed from: n0 */
    public int f1089n0;

    /* renamed from: o0 */
    public int f1090o0;

    /* renamed from: p0 */
    public int f1091p0;

    /* renamed from: q0 */
    public int f1092q0;

    /* renamed from: r0 */
    public final int[] f1093r0;

    /* renamed from: s0 */
    public final int[] f1094s0;

    /* renamed from: t0 */
    public int f1095t0;

    /* renamed from: u0 */
    public int f1096u0;

    /* renamed from: v0 */
    public C0185c f1097v0;

    /* renamed from: w0 */
    public final C1674q7 f1098w0;

    /* renamed from: x0 */
    public final C1313m7 f1099x0;

    /* renamed from: y0 */
    public float f1100y0;

    /* renamed from: z0 */
    public C0184b f1101z0;

    /* renamed from: androidx.core.widget.NestedScrollView$a */
    public static class C0183a extends C0757g7 {
        public C0183a() {
            super(C0757g7.f6013c);
        }

        /* renamed from: a */
        public void mo1378a(View view, C0759g8 g8Var) {
            int scrollRange;
            this.f6014a.onInitializeAccessibilityNodeInfo(view, g8Var.f6028a);
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            g8Var.f6028a.setClassName(ScrollView.class.getName());
            if (nestedScrollView.isEnabled() && (scrollRange = nestedScrollView.getScrollRange()) > 0) {
                g8Var.f6028a.setScrollable(true);
                if (nestedScrollView.getScrollY() > 0) {
                    g8Var.f6028a.addAction(8192);
                }
                if (nestedScrollView.getScrollY() < scrollRange) {
                    g8Var.f6028a.addAction(4096);
                }
            }
        }

        /* renamed from: a */
        public boolean mo1379a(View view, int i, Bundle bundle) {
            if (super.mo1379a(view, i, bundle)) {
                return true;
            }
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            if (!nestedScrollView.isEnabled()) {
                return false;
            }
            if (i == 4096) {
                int min = Math.min(nestedScrollView.getScrollY() + ((nestedScrollView.getHeight() - nestedScrollView.getPaddingBottom()) - nestedScrollView.getPaddingTop()), nestedScrollView.getScrollRange());
                if (min == nestedScrollView.getScrollY()) {
                    return false;
                }
                nestedScrollView.mo1324b(0, min);
                return true;
            } else if (i != 8192) {
                return false;
            } else {
                int max = Math.max(nestedScrollView.getScrollY() - ((nestedScrollView.getHeight() - nestedScrollView.getPaddingBottom()) - nestedScrollView.getPaddingTop()), 0);
                if (max == nestedScrollView.getScrollY()) {
                    return false;
                }
                nestedScrollView.mo1324b(0, max);
                return true;
            }
        }

        /* renamed from: b */
        public void mo1380b(View view, AccessibilityEvent accessibilityEvent) {
            this.f6014a.onInitializeAccessibilityEvent(view, accessibilityEvent);
            NestedScrollView nestedScrollView = (NestedScrollView) view;
            accessibilityEvent.setClassName(ScrollView.class.getName());
            accessibilityEvent.setScrollable(nestedScrollView.getScrollRange() > 0);
            accessibilityEvent.setScrollX(nestedScrollView.getScrollX());
            accessibilityEvent.setScrollY(nestedScrollView.getScrollY());
            int scrollX = nestedScrollView.getScrollX();
            int i = Build.VERSION.SDK_INT;
            accessibilityEvent.setMaxScrollX(scrollX);
            int scrollRange = nestedScrollView.getScrollRange();
            int i2 = Build.VERSION.SDK_INT;
            accessibilityEvent.setMaxScrollY(scrollRange);
        }
    }

    /* renamed from: androidx.core.widget.NestedScrollView$b */
    public interface C0184b {
        /* renamed from: a */
        void mo1381a(NestedScrollView nestedScrollView, int i, int i2, int i3, int i4);
    }

    /* renamed from: androidx.core.widget.NestedScrollView$c */
    public static class C0185c extends View.BaseSavedState {
        public static final Parcelable.Creator<C0185c> CREATOR = new C0186a();

        /* renamed from: X */
        public int f1102X;

        /* renamed from: androidx.core.widget.NestedScrollView$c$a */
        public static class C0186a implements Parcelable.Creator<C0185c> {
            public Object createFromParcel(Parcel parcel) {
                return new C0185c(parcel);
            }

            public Object[] newArray(int i) {
                return new C0185c[i];
            }
        }

        public C0185c(Parcel parcel) {
            super(parcel);
            this.f1102X = parcel.readInt();
        }

        public C0185c(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            StringBuilder a = C0789gk.m5562a("HorizontalScrollView.SavedState{");
            a.append(Integer.toHexString(System.identityHashCode(this)));
            a.append(" scrollPosition=");
            a.append(this.f1102X);
            a.append("}");
            return a.toString();
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.f1102X);
        }
    }

    public NestedScrollView(Context context) {
        this(context, (AttributeSet) null);
    }

    public NestedScrollView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public NestedScrollView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f1077b0 = new Rect();
        this.f1082g0 = true;
        this.f1083h0 = false;
        this.f1084i0 = null;
        this.f1085j0 = false;
        this.f1088m0 = true;
        this.f1092q0 = -1;
        this.f1093r0 = new int[2];
        this.f1094s0 = new int[2];
        this.f1078c0 = new OverScroller(getContext());
        setFocusable(true);
        setDescendantFocusability(262144);
        setWillNotDraw(false);
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        this.f1089n0 = viewConfiguration.getScaledTouchSlop();
        this.f1090o0 = viewConfiguration.getScaledMinimumFlingVelocity();
        this.f1091p0 = viewConfiguration.getScaledMaximumFlingVelocity();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f1075B0, i, 0);
        setFillViewport(obtainStyledAttributes.getBoolean(0, false));
        obtainStyledAttributes.recycle();
        this.f1098w0 = new C1674q7();
        this.f1099x0 = new C1313m7(this);
        setNestedScrollingEnabled(true);
        C2189w7.m14988a((View) this, (C0757g7) f1074A0);
    }

    /* renamed from: a */
    public static boolean m883a(View view, View view2) {
        if (view == view2) {
            return true;
        }
        ViewParent parent = view.getParent();
        return (parent instanceof ViewGroup) && m883a((View) parent, view2);
    }

    /* renamed from: b */
    public static int m884b(int i, int i2, int i3) {
        if (i2 >= i3 || i < 0) {
            return 0;
        }
        return i2 + i > i3 ? i3 - i2 : i;
    }

    private float getVerticalScrollFactorCompat() {
        if (this.f1100y0 == 0.0f) {
            TypedValue typedValue = new TypedValue();
            Context context = getContext();
            if (context.getTheme().resolveAttribute(16842829, typedValue, true)) {
                this.f1100y0 = typedValue.getDimension(context.getResources().getDisplayMetrics());
            } else {
                throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
            }
        }
        return this.f1100y0;
    }

    /* renamed from: a */
    public int mo1304a(Rect rect) {
        if (getChildCount() == 0) {
            return 0;
        }
        int height = getHeight();
        int scrollY = getScrollY();
        int i = scrollY + height;
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        if (rect.top > 0) {
            scrollY += verticalFadingEdgeLength;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        int i2 = rect.bottom < (childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin ? i - verticalFadingEdgeLength : i;
        if (rect.bottom > i2 && rect.top > scrollY) {
            return Math.min((rect.height() > height ? rect.top - scrollY : rect.bottom - i2) + 0, (childAt.getBottom() + layoutParams.bottomMargin) - i);
        } else if (rect.top >= scrollY || rect.bottom >= i2) {
            return 0;
        } else {
            return Math.max(rect.height() > height ? 0 - (i2 - rect.bottom) : 0 - (scrollY - rect.top), -getScrollY());
        }
    }

    /* renamed from: a */
    public final void mo1305a() {
        this.f1078c0.abortAnimation();
        mo1344g(1);
    }

    /* renamed from: a */
    public final void mo1306a(int i, int i2) {
        if (getChildCount() != 0) {
            if (AnimationUtils.currentAnimationTimeMillis() - this.f1076a0 > 250) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                int height = childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
                int height2 = (getHeight() - getPaddingTop()) - getPaddingBottom();
                int scrollY = getScrollY();
                OverScroller overScroller = this.f1078c0;
                int scrollX = getScrollX();
                overScroller.startScroll(scrollX, scrollY, 0, Math.max(0, Math.min(i2 + scrollY, Math.max(0, height - height2))) - scrollY);
                mo1311a(false);
            } else {
                if (!this.f1078c0.isFinished()) {
                    mo1305a();
                }
                scrollBy(i, i2);
            }
            this.f1076a0 = AnimationUtils.currentAnimationTimeMillis();
        }
    }

    /* renamed from: a */
    public final void mo1308a(int i, int i2, int[] iArr) {
        int scrollY = getScrollY();
        scrollBy(0, i);
        int scrollY2 = getScrollY() - scrollY;
        if (iArr != null) {
            iArr[1] = iArr[1] + scrollY2;
        }
        this.f1099x0.mo8619a(0, scrollY2, 0, i - scrollY2, (int[]) null, i2, iArr);
    }

    /* renamed from: a */
    public final void mo1309a(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f1092q0) {
            int i = actionIndex == 0 ? 1 : 0;
            this.f1081f0 = (int) motionEvent.getY(i);
            this.f1092q0 = motionEvent.getPointerId(i);
            VelocityTracker velocityTracker = this.f1086k0;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    /* renamed from: a */
    public final void mo1310a(View view) {
        view.getDrawingRect(this.f1077b0);
        offsetDescendantRectToMyCoords(view, this.f1077b0);
        int a = mo1304a(this.f1077b0);
        if (a != 0) {
            scrollBy(0, a);
        }
    }

    /* renamed from: a */
    public void mo802a(View view, int i, int i2, int i3, int i4, int i5) {
        mo1308a(i4, i5, (int[]) null);
    }

    /* renamed from: a */
    public void mo803a(View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
        mo1308a(i4, i5, iArr);
    }

    /* renamed from: a */
    public void mo804a(View view, int i, int i2, int[] iArr, int i3) {
        mo1315a(i, i2, iArr, (int[]) null, i3);
    }

    /* renamed from: a */
    public final void mo1311a(boolean z) {
        if (z) {
            mo1327c(2, 1);
        } else {
            mo1344g(1);
        }
        this.f1096u0 = getScrollY();
        C2189w7.m14972D(this);
    }

    /* renamed from: a */
    public boolean mo1312a(int i) {
        View findFocus = findFocus();
        if (findFocus == this) {
            findFocus = null;
        }
        View findNextFocus = FocusFinder.getInstance().findNextFocus(this, findFocus, i);
        int maxScrollAmount = getMaxScrollAmount();
        if (findNextFocus == null || !mo1317a(findNextFocus, maxScrollAmount, getHeight())) {
            if (i == 33 && getScrollY() < maxScrollAmount) {
                maxScrollAmount = getScrollY();
            } else if (i == 130 && getChildCount() > 0) {
                View childAt = getChildAt(0);
                maxScrollAmount = Math.min((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - ((getHeight() + getScrollY()) - getPaddingBottom()), maxScrollAmount);
            }
            if (maxScrollAmount == 0) {
                return false;
            }
            if (i != 130) {
                maxScrollAmount = -maxScrollAmount;
            }
            mo1323b(maxScrollAmount);
        } else {
            findNextFocus.getDrawingRect(this.f1077b0);
            offsetDescendantRectToMyCoords(findNextFocus, this.f1077b0);
            mo1323b(mo1304a(this.f1077b0));
            findNextFocus.requestFocus(i);
        }
        if (findFocus != null && findFocus.isFocused() && (!mo1317a(findFocus, 0, getHeight()))) {
            int descendantFocusability = getDescendantFocusability();
            setDescendantFocusability(131072);
            requestFocus();
            setDescendantFocusability(descendantFocusability);
        }
        return true;
    }

    /* JADX WARNING: Removed duplicated region for block: B:33:0x0057  */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x005a  */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x0083 A[ADDED_TO_REGION] */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo1314a(int r13, int r14, int r15, int r16, int r17, int r18, int r19, int r20) {
        /*
            r12 = this;
            r0 = r12
            int r1 = r12.getOverScrollMode()
            int r2 = r12.computeHorizontalScrollRange()
            int r3 = r12.computeHorizontalScrollExtent()
            r4 = 0
            r5 = 1
            if (r2 <= r3) goto L_0x0013
            r2 = 1
            goto L_0x0014
        L_0x0013:
            r2 = 0
        L_0x0014:
            int r3 = r12.computeVerticalScrollRange()
            int r6 = r12.computeVerticalScrollExtent()
            if (r3 <= r6) goto L_0x0020
            r3 = 1
            goto L_0x0021
        L_0x0020:
            r3 = 0
        L_0x0021:
            if (r1 == 0) goto L_0x002a
            if (r1 != r5) goto L_0x0028
            if (r2 == 0) goto L_0x0028
            goto L_0x002a
        L_0x0028:
            r2 = 0
            goto L_0x002b
        L_0x002a:
            r2 = 1
        L_0x002b:
            if (r1 == 0) goto L_0x0034
            if (r1 != r5) goto L_0x0032
            if (r3 == 0) goto L_0x0032
            goto L_0x0034
        L_0x0032:
            r1 = 0
            goto L_0x0035
        L_0x0034:
            r1 = 1
        L_0x0035:
            int r3 = r15 + r13
            if (r2 != 0) goto L_0x003b
            r2 = 0
            goto L_0x003d
        L_0x003b:
            r2 = r19
        L_0x003d:
            int r6 = r16 + r14
            if (r1 != 0) goto L_0x0043
            r1 = 0
            goto L_0x0045
        L_0x0043:
            r1 = r20
        L_0x0045:
            int r7 = -r2
            int r2 = r2 + r17
            int r8 = -r1
            int r1 = r1 + r18
            if (r3 <= r2) goto L_0x0050
            r7 = r2
        L_0x004e:
            r2 = 1
            goto L_0x0055
        L_0x0050:
            if (r3 >= r7) goto L_0x0053
            goto L_0x004e
        L_0x0053:
            r7 = r3
            r2 = 0
        L_0x0055:
            if (r6 <= r1) goto L_0x005a
            r8 = r1
        L_0x0058:
            r1 = 1
            goto L_0x005f
        L_0x005a:
            if (r6 >= r8) goto L_0x005d
            goto L_0x0058
        L_0x005d:
            r8 = r6
            r1 = 0
        L_0x005f:
            if (r1 == 0) goto L_0x007e
            boolean r3 = r12.mo1342e(r5)
            if (r3 != 0) goto L_0x007e
            android.widget.OverScroller r3 = r0.f1078c0
            r6 = 0
            r9 = 0
            r10 = 0
            int r11 = r12.getScrollRange()
            r13 = r3
            r14 = r7
            r15 = r8
            r16 = r6
            r17 = r9
            r18 = r10
            r19 = r11
            r13.springBack(r14, r15, r16, r17, r18, r19)
        L_0x007e:
            r12.onOverScrolled(r7, r8, r2, r1)
            if (r2 != 0) goto L_0x0085
            if (r1 == 0) goto L_0x0086
        L_0x0085:
            r4 = 1
        L_0x0086:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.mo1314a(int, int, int, int, int, int, int, int):boolean");
    }

    /* renamed from: a */
    public boolean mo1315a(int i, int i2, int[] iArr, int[] iArr2, int i3) {
        return this.f1099x0.mo8624a(i, i2, iArr, iArr2, i3);
    }

    /* renamed from: a */
    public final boolean mo1317a(View view, int i, int i2) {
        view.getDrawingRect(this.f1077b0);
        offsetDescendantRectToMyCoords(view, this.f1077b0);
        return this.f1077b0.bottom + i >= getScrollY() && this.f1077b0.top - i <= getScrollY() + i2;
    }

    public void addView(View view) {
        if (getChildCount() <= 0) {
            super.addView(view);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public void addView(View view, int i) {
        if (getChildCount() <= 0) {
            super.addView(view, i);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, i, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    public void addView(View view, ViewGroup.LayoutParams layoutParams) {
        if (getChildCount() <= 0) {
            super.addView(view, layoutParams);
            return;
        }
        throw new IllegalStateException("ScrollView can host only one direct child");
    }

    /* renamed from: b */
    public final void mo1322b() {
        if (getOverScrollMode() == 2) {
            this.f1079d0 = null;
            this.f1080e0 = null;
        } else if (this.f1079d0 == null) {
            Context context = getContext();
            this.f1079d0 = new EdgeEffect(context);
            this.f1080e0 = new EdgeEffect(context);
        }
    }

    /* renamed from: b */
    public final void mo1323b(int i) {
        if (i == 0) {
            return;
        }
        if (this.f1088m0) {
            mo1306a(0, i);
        } else {
            scrollBy(0, i);
        }
    }

    /* renamed from: b */
    public final void mo1324b(int i, int i2) {
        mo1306a(i - getScrollX(), i2 - getScrollY());
    }

    /* renamed from: b */
    public boolean mo810b(View view, View view2, int i, int i2) {
        return (i & 2) != 0;
    }

    /* renamed from: c */
    public final void mo1325c() {
        VelocityTracker velocityTracker = this.f1086k0;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.f1086k0 = null;
        }
    }

    /* renamed from: c */
    public void mo1326c(int i) {
        if (getChildCount() > 0) {
            this.f1078c0.fling(getScrollX(), getScrollY(), 0, i, 0, 0, RecyclerView.UNDEFINED_DURATION, Integer.MAX_VALUE, 0, 0);
            mo1311a(true);
        }
    }

    /* renamed from: c */
    public boolean mo1327c(int i, int i2) {
        return this.f1099x0.mo8622a(i, i2);
    }

    public int computeHorizontalScrollExtent() {
        return super.computeHorizontalScrollExtent();
    }

    public int computeHorizontalScrollOffset() {
        return super.computeHorizontalScrollOffset();
    }

    public int computeHorizontalScrollRange() {
        return super.computeHorizontalScrollRange();
    }

    public void computeScroll() {
        EdgeEffect edgeEffect;
        if (!this.f1078c0.isFinished()) {
            this.f1078c0.computeScrollOffset();
            int currY = this.f1078c0.getCurrY();
            int i = currY - this.f1096u0;
            this.f1096u0 = currY;
            int[] iArr = this.f1094s0;
            boolean z = false;
            iArr[1] = 0;
            mo1315a(0, i, iArr, (int[]) null, 1);
            int i2 = i - this.f1094s0[1];
            int scrollRange = getScrollRange();
            if (i2 != 0) {
                int scrollY = getScrollY();
                mo1314a(0, i2, getScrollX(), scrollY, 0, scrollRange, 0, 0);
                int scrollY2 = getScrollY() - scrollY;
                int i3 = i2 - scrollY2;
                int[] iArr2 = this.f1094s0;
                iArr2[1] = 0;
                mo1307a(0, scrollY2, 0, i3, this.f1093r0, 1, iArr2);
                i2 = i3 - this.f1094s0[1];
            }
            if (i2 != 0) {
                int overScrollMode = getOverScrollMode();
                if (overScrollMode == 0 || (overScrollMode == 1 && scrollRange > 0)) {
                    z = true;
                }
                if (z) {
                    mo1322b();
                    if (i2 < 0) {
                        if (this.f1079d0.isFinished()) {
                            edgeEffect = this.f1079d0;
                        }
                    } else if (this.f1080e0.isFinished()) {
                        edgeEffect = this.f1080e0;
                    }
                    edgeEffect.onAbsorb((int) this.f1078c0.getCurrVelocity());
                }
                mo1305a();
            }
            if (!this.f1078c0.isFinished()) {
                C2189w7.m14972D(this);
            }
        }
    }

    public int computeVerticalScrollExtent() {
        return super.computeVerticalScrollExtent();
    }

    public int computeVerticalScrollOffset() {
        return Math.max(0, super.computeVerticalScrollOffset());
    }

    public int computeVerticalScrollRange() {
        int childCount = getChildCount();
        int height = (getHeight() - getPaddingBottom()) - getPaddingTop();
        if (childCount == 0) {
            return height;
        }
        View childAt = getChildAt(0);
        int bottom = childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
        int scrollY = getScrollY();
        int max = Math.max(0, bottom - height);
        return scrollY < 0 ? bottom - scrollY : scrollY > max ? bottom + (scrollY - max) : bottom;
    }

    /* renamed from: d */
    public boolean mo1335d(int i) {
        int childCount;
        boolean z = i == 130;
        int height = getHeight();
        Rect rect = this.f1077b0;
        rect.top = 0;
        rect.bottom = height;
        if (z && (childCount = getChildCount()) > 0) {
            View childAt = getChildAt(childCount - 1);
            this.f1077b0.bottom = getPaddingBottom() + childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin;
            Rect rect2 = this.f1077b0;
            rect2.top = rect2.bottom - height;
        }
        Rect rect3 = this.f1077b0;
        return mo1313a(i, rect3.top, rect3.bottom);
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent) || mo1316a(keyEvent);
    }

    public boolean dispatchNestedFling(float f, float f2, boolean z) {
        return this.f1099x0.mo8621a(f, f2, z);
    }

    public boolean dispatchNestedPreFling(float f, float f2) {
        return this.f1099x0.mo8620a(f, f2);
    }

    public boolean dispatchNestedPreScroll(int i, int i2, int[] iArr, int[] iArr2) {
        return mo1315a(i, i2, iArr, iArr2, 0);
    }

    public boolean dispatchNestedScroll(int i, int i2, int i3, int i4, int[] iArr) {
        return this.f1099x0.mo8623a(i, i2, i3, i4, iArr);
    }

    public void draw(Canvas canvas) {
        int i;
        super.draw(canvas);
        if (this.f1079d0 != null) {
            int scrollY = getScrollY();
            int i2 = 0;
            if (!this.f1079d0.isFinished()) {
                int save = canvas.save();
                int width = getWidth();
                int height = getHeight();
                int min = Math.min(0, scrollY);
                if (Build.VERSION.SDK_INT < 21 || getClipToPadding()) {
                    width -= getPaddingRight() + getPaddingLeft();
                    i = getPaddingLeft() + 0;
                } else {
                    i = 0;
                }
                if (Build.VERSION.SDK_INT >= 21 && getClipToPadding()) {
                    height -= getPaddingBottom() + getPaddingTop();
                    min += getPaddingTop();
                }
                canvas.translate((float) i, (float) min);
                this.f1079d0.setSize(width, height);
                if (this.f1079d0.draw(canvas)) {
                    C2189w7.m14972D(this);
                }
                canvas.restoreToCount(save);
            }
            if (!this.f1080e0.isFinished()) {
                int save2 = canvas.save();
                int width2 = getWidth();
                int height2 = getHeight();
                int max = Math.max(getScrollRange(), scrollY) + height2;
                if (Build.VERSION.SDK_INT < 21 || getClipToPadding()) {
                    width2 -= getPaddingRight() + getPaddingLeft();
                    i2 = 0 + getPaddingLeft();
                }
                if (Build.VERSION.SDK_INT >= 21 && getClipToPadding()) {
                    height2 -= getPaddingBottom() + getPaddingTop();
                    max -= getPaddingBottom();
                }
                canvas.translate((float) (i2 - width2), (float) max);
                canvas.rotate(180.0f, (float) width2, 0.0f);
                this.f1080e0.setSize(width2, height2);
                if (this.f1080e0.draw(canvas)) {
                    C2189w7.m14972D(this);
                }
                canvas.restoreToCount(save2);
            }
        }
    }

    /* renamed from: e */
    public boolean mo1342e(int i) {
        return this.f1099x0.mo8618a(i) != null;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:12:0x004b, code lost:
        if (r0.top < 0) goto L_0x004d;
     */
    /* renamed from: f */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo1343f(int r5) {
        /*
            r4 = this;
            r0 = 1
            r1 = 0
            r2 = 130(0x82, float:1.82E-43)
            if (r5 != r2) goto L_0x0008
            r2 = 1
            goto L_0x0009
        L_0x0008:
            r2 = 0
        L_0x0009:
            int r3 = r4.getHeight()
            if (r2 == 0) goto L_0x003e
            android.graphics.Rect r1 = r4.f1077b0
            int r2 = r4.getScrollY()
            int r2 = r2 + r3
            r1.top = r2
            int r1 = r4.getChildCount()
            if (r1 <= 0) goto L_0x004f
            int r1 = r1 - r0
            android.view.View r0 = r4.getChildAt(r1)
            android.view.ViewGroup$LayoutParams r1 = r0.getLayoutParams()
            android.widget.FrameLayout$LayoutParams r1 = (android.widget.FrameLayout.LayoutParams) r1
            int r0 = r0.getBottom()
            int r1 = r1.bottomMargin
            int r0 = r0 + r1
            int r1 = r4.getPaddingBottom()
            int r1 = r1 + r0
            android.graphics.Rect r0 = r4.f1077b0
            int r2 = r0.top
            int r2 = r2 + r3
            if (r2 <= r1) goto L_0x004f
            int r1 = r1 - r3
            goto L_0x004d
        L_0x003e:
            android.graphics.Rect r0 = r4.f1077b0
            int r2 = r4.getScrollY()
            int r2 = r2 - r3
            r0.top = r2
            android.graphics.Rect r0 = r4.f1077b0
            int r2 = r0.top
            if (r2 >= 0) goto L_0x004f
        L_0x004d:
            r0.top = r1
        L_0x004f:
            android.graphics.Rect r0 = r4.f1077b0
            int r1 = r0.top
            int r3 = r3 + r1
            r0.bottom = r3
            int r0 = r0.bottom
            boolean r5 = r4.mo1313a((int) r5, (int) r1, (int) r0)
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.mo1343f(int):boolean");
    }

    /* renamed from: g */
    public void mo1344g(int i) {
        this.f1099x0.mo8627c(i);
    }

    public float getBottomFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        View childAt = getChildAt(0);
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int bottom = ((childAt.getBottom() + ((FrameLayout.LayoutParams) childAt.getLayoutParams()).bottomMargin) - getScrollY()) - (getHeight() - getPaddingBottom());
        if (bottom < verticalFadingEdgeLength) {
            return ((float) bottom) / ((float) verticalFadingEdgeLength);
        }
        return 1.0f;
    }

    public int getMaxScrollAmount() {
        return (int) (((float) getHeight()) * 0.5f);
    }

    public int getNestedScrollAxes() {
        return this.f1098w0.mo10254a();
    }

    public int getScrollRange() {
        if (getChildCount() <= 0) {
            return 0;
        }
        View childAt = getChildAt(0);
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
        return Math.max(0, ((childAt.getHeight() + layoutParams.topMargin) + layoutParams.bottomMargin) - ((getHeight() - getPaddingTop()) - getPaddingBottom()));
    }

    public float getTopFadingEdgeStrength() {
        if (getChildCount() == 0) {
            return 0.0f;
        }
        int verticalFadingEdgeLength = getVerticalFadingEdgeLength();
        int scrollY = getScrollY();
        if (scrollY < verticalFadingEdgeLength) {
            return ((float) scrollY) / ((float) verticalFadingEdgeLength);
        }
        return 1.0f;
    }

    public boolean hasNestedScrollingParent() {
        return mo1342e(0);
    }

    public boolean isNestedScrollingEnabled() {
        return this.f1099x0.f10039d;
    }

    public void measureChild(View view, int i, int i2) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        view.measure(FrameLayout.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft(), layoutParams.width), View.MeasureSpec.makeMeasureSpec(0, 0));
    }

    public void measureChildWithMargins(View view, int i, int i2, int i3, int i4) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        view.measure(FrameLayout.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i2, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f1083h0 = false;
    }

    public boolean onGenericMotionEvent(MotionEvent motionEvent) {
        if ((motionEvent.getSource() & 2) != 0 && motionEvent.getAction() == 8 && !this.f1085j0) {
            float axisValue = motionEvent.getAxisValue(9);
            if (axisValue != 0.0f) {
                int scrollRange = getScrollRange();
                int scrollY = getScrollY();
                int verticalScrollFactorCompat = scrollY - ((int) (axisValue * getVerticalScrollFactorCompat()));
                if (verticalScrollFactorCompat < 0) {
                    verticalScrollFactorCompat = 0;
                } else if (verticalScrollFactorCompat > scrollRange) {
                    verticalScrollFactorCompat = scrollRange;
                }
                if (verticalScrollFactorCompat != scrollY) {
                    super.scrollTo(getScrollX(), verticalScrollFactorCompat);
                    return true;
                }
            }
        }
        return false;
    }

    /* JADX WARNING: Removed duplicated region for block: B:47:0x00e1  */
    /* JADX WARNING: Removed duplicated region for block: B:48:0x00e7  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onInterceptTouchEvent(android.view.MotionEvent r12) {
        /*
            r11 = this;
            int r0 = r12.getAction()
            r1 = 1
            r2 = 2
            if (r0 != r2) goto L_0x000d
            boolean r3 = r11.f1085j0
            if (r3 == 0) goto L_0x000d
            return r1
        L_0x000d:
            r0 = r0 & 255(0xff, float:3.57E-43)
            r3 = 0
            if (r0 == 0) goto L_0x00aa
            r4 = -1
            if (r0 == r1) goto L_0x0085
            if (r0 == r2) goto L_0x0024
            r1 = 3
            if (r0 == r1) goto L_0x0085
            r1 = 6
            if (r0 == r1) goto L_0x001f
            goto L_0x0113
        L_0x001f:
            r11.mo1309a((android.view.MotionEvent) r12)
            goto L_0x0113
        L_0x0024:
            int r0 = r11.f1092q0
            if (r0 != r4) goto L_0x002a
            goto L_0x0113
        L_0x002a:
            int r5 = r12.findPointerIndex(r0)
            if (r5 != r4) goto L_0x004d
            java.lang.StringBuilder r12 = new java.lang.StringBuilder
            r12.<init>()
            java.lang.String r1 = "Invalid pointerId="
            r12.append(r1)
            r12.append(r0)
            java.lang.String r0 = " in onInterceptTouchEvent"
            r12.append(r0)
            java.lang.String r12 = r12.toString()
            java.lang.String r0 = "NestedScrollView"
            android.util.Log.e(r0, r12)
            goto L_0x0113
        L_0x004d:
            float r0 = r12.getY(r5)
            int r0 = (int) r0
            int r4 = r11.f1081f0
            int r4 = r0 - r4
            int r4 = java.lang.Math.abs(r4)
            int r5 = r11.f1089n0
            if (r4 <= r5) goto L_0x0113
            int r4 = r11.getNestedScrollAxes()
            r2 = r2 & r4
            if (r2 != 0) goto L_0x0113
            r11.f1085j0 = r1
            r11.f1081f0 = r0
            android.view.VelocityTracker r0 = r11.f1086k0
            if (r0 != 0) goto L_0x0073
            android.view.VelocityTracker r0 = android.view.VelocityTracker.obtain()
            r11.f1086k0 = r0
        L_0x0073:
            android.view.VelocityTracker r0 = r11.f1086k0
            r0.addMovement(r12)
            r11.f1095t0 = r3
            android.view.ViewParent r12 = r11.getParent()
            if (r12 == 0) goto L_0x0113
            r12.requestDisallowInterceptTouchEvent(r1)
            goto L_0x0113
        L_0x0085:
            r11.f1085j0 = r3
            r11.f1092q0 = r4
            r11.mo1325c()
            android.widget.OverScroller r4 = r11.f1078c0
            int r5 = r11.getScrollX()
            int r6 = r11.getScrollY()
            r7 = 0
            r8 = 0
            r9 = 0
            int r10 = r11.getScrollRange()
            boolean r12 = r4.springBack(r5, r6, r7, r8, r9, r10)
            if (r12 == 0) goto L_0x00a6
            p000.C2189w7.m14972D(r11)
        L_0x00a6:
            r11.mo1344g(r3)
            goto L_0x0113
        L_0x00aa:
            float r0 = r12.getY()
            int r0 = (int) r0
            float r4 = r12.getX()
            int r4 = (int) r4
            int r5 = r11.getChildCount()
            if (r5 <= 0) goto L_0x00de
            int r5 = r11.getScrollY()
            android.view.View r6 = r11.getChildAt(r3)
            int r7 = r6.getTop()
            int r7 = r7 - r5
            if (r0 < r7) goto L_0x00de
            int r7 = r6.getBottom()
            int r7 = r7 - r5
            if (r0 >= r7) goto L_0x00de
            int r5 = r6.getLeft()
            if (r4 < r5) goto L_0x00de
            int r5 = r6.getRight()
            if (r4 >= r5) goto L_0x00de
            r4 = 1
            goto L_0x00df
        L_0x00de:
            r4 = 0
        L_0x00df:
            if (r4 != 0) goto L_0x00e7
            r11.f1085j0 = r3
            r11.mo1325c()
            goto L_0x0113
        L_0x00e7:
            r11.f1081f0 = r0
            int r0 = r12.getPointerId(r3)
            r11.f1092q0 = r0
            android.view.VelocityTracker r0 = r11.f1086k0
            if (r0 != 0) goto L_0x00fa
            android.view.VelocityTracker r0 = android.view.VelocityTracker.obtain()
            r11.f1086k0 = r0
            goto L_0x00fd
        L_0x00fa:
            r0.clear()
        L_0x00fd:
            android.view.VelocityTracker r0 = r11.f1086k0
            r0.addMovement(r12)
            android.widget.OverScroller r12 = r11.f1078c0
            r12.computeScrollOffset()
            android.widget.OverScroller r12 = r11.f1078c0
            boolean r12 = r12.isFinished()
            r12 = r12 ^ r1
            r11.f1085j0 = r12
            r11.mo1327c(r2, r3)
        L_0x0113:
            boolean r12 = r11.f1085j0
            return r12
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.onInterceptTouchEvent(android.view.MotionEvent):boolean");
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        int i5 = 0;
        this.f1082g0 = false;
        View view = this.f1084i0;
        if (view != null && m883a(view, (View) this)) {
            mo1310a(this.f1084i0);
        }
        this.f1084i0 = null;
        if (!this.f1083h0) {
            if (this.f1097v0 != null) {
                scrollTo(getScrollX(), this.f1097v0.f1102X);
                this.f1097v0 = null;
            }
            if (getChildCount() > 0) {
                View childAt = getChildAt(0);
                FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
                i5 = childAt.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
            }
            int paddingTop = ((i4 - i2) - getPaddingTop()) - getPaddingBottom();
            int scrollY = getScrollY();
            int b = m884b(scrollY, paddingTop, i5);
            if (b != scrollY) {
                scrollTo(getScrollX(), b);
            }
        }
        scrollTo(getScrollX(), getScrollY());
        this.f1083h0 = true;
    }

    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        if (this.f1087l0 && View.MeasureSpec.getMode(i2) != 0 && getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int measuredHeight2 = (((getMeasuredHeight() - getPaddingTop()) - getPaddingBottom()) - layoutParams.topMargin) - layoutParams.bottomMargin;
            if (measuredHeight < measuredHeight2) {
                childAt.measure(FrameLayout.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), View.MeasureSpec.makeMeasureSpec(measuredHeight2, 1073741824));
            }
        }
    }

    public boolean onNestedFling(View view, float f, float f2, boolean z) {
        if (z) {
            return false;
        }
        dispatchNestedFling(0.0f, f2, true);
        mo1326c((int) f2);
        return true;
    }

    public boolean onNestedPreFling(View view, float f, float f2) {
        return dispatchNestedPreFling(f, f2);
    }

    public void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
        mo804a(view, i, i2, iArr, 0);
    }

    public void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        mo1308a(i4, 0, (int[]) null);
    }

    public void onNestedScrollAccepted(View view, View view2, int i) {
        mo805a(view, view2, i, 0);
    }

    public void onOverScrolled(int i, int i2, boolean z, boolean z2) {
        super.scrollTo(i, i2);
    }

    public boolean onRequestFocusInDescendants(int i, Rect rect) {
        if (i == 2) {
            i = 130;
        } else if (i == 1) {
            i = 33;
        }
        FocusFinder instance = FocusFinder.getInstance();
        View findNextFocus = rect == null ? instance.findNextFocus(this, (View) null, i) : instance.findNextFocusFromRect(this, rect, i);
        if (findNextFocus != null && !(true ^ mo1317a(findNextFocus, 0, getHeight()))) {
            return findNextFocus.requestFocus(i, rect);
        }
        return false;
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof C0185c)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        C0185c cVar = (C0185c) parcelable;
        super.onRestoreInstanceState(cVar.getSuperState());
        this.f1097v0 = cVar;
        requestLayout();
    }

    public Parcelable onSaveInstanceState() {
        C0185c cVar = new C0185c(super.onSaveInstanceState());
        cVar.f1102X = getScrollY();
        return cVar;
    }

    public void onScrollChanged(int i, int i2, int i3, int i4) {
        super.onScrollChanged(i, i2, i3, i4);
        C0184b bVar = this.f1101z0;
        if (bVar != null) {
            bVar.mo1381a(this, i, i2, i3, i4);
        }
    }

    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        View findFocus = findFocus();
        if (findFocus != null && this != findFocus && mo1317a(findFocus, 0, i4)) {
            findFocus.getDrawingRect(this.f1077b0);
            offsetDescendantRectToMyCoords(findFocus, this.f1077b0);
            mo1323b(mo1304a(this.f1077b0));
        }
    }

    public boolean onStartNestedScroll(View view, View view2, int i) {
        return mo810b(view, view2, i, 0);
    }

    public void onStopNestedScroll(View view) {
        mo801a(view, 0);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:24:0x007d, code lost:
        if (r9.f1078c0.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange()) != false) goto L_0x0209;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:81:0x0207, code lost:
        if (r9.f1078c0.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange()) != false) goto L_0x0209;
     */
    /* JADX WARNING: Removed duplicated region for block: B:85:0x021a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r23) {
        /*
            r22 = this;
            r9 = r22
            r10 = r23
            android.view.VelocityTracker r0 = r9.f1086k0
            if (r0 != 0) goto L_0x000e
            android.view.VelocityTracker r0 = android.view.VelocityTracker.obtain()
            r9.f1086k0 = r0
        L_0x000e:
            int r0 = r23.getActionMasked()
            r11 = 0
            if (r0 != 0) goto L_0x0017
            r9.f1095t0 = r11
        L_0x0017:
            android.view.MotionEvent r12 = android.view.MotionEvent.obtain(r23)
            int r1 = r9.f1095t0
            float r1 = (float) r1
            r2 = 0
            r12.offsetLocation(r2, r1)
            r1 = 2
            r13 = 1
            if (r0 == 0) goto L_0x0223
            r3 = -1
            if (r0 == r13) goto L_0x01c7
            if (r0 == r1) goto L_0x0081
            r1 = 3
            if (r0 == r1) goto L_0x005b
            r1 = 5
            if (r0 == r1) goto L_0x0048
            r1 = 6
            if (r0 == r1) goto L_0x0036
            goto L_0x0259
        L_0x0036:
            r22.mo1309a((android.view.MotionEvent) r23)
            int r0 = r9.f1092q0
            int r0 = r10.findPointerIndex(r0)
            float r0 = r10.getY(r0)
            int r0 = (int) r0
            r9.f1081f0 = r0
            goto L_0x0259
        L_0x0048:
            int r0 = r23.getActionIndex()
            float r1 = r10.getY(r0)
            int r1 = (int) r1
            r9.f1081f0 = r1
            int r0 = r10.getPointerId(r0)
            r9.f1092q0 = r0
            goto L_0x0259
        L_0x005b:
            boolean r0 = r9.f1085j0
            if (r0 == 0) goto L_0x020c
            int r0 = r22.getChildCount()
            if (r0 <= 0) goto L_0x020c
            android.widget.OverScroller r14 = r9.f1078c0
            int r15 = r22.getScrollX()
            int r16 = r22.getScrollY()
            r17 = 0
            r18 = 0
            r19 = 0
            int r20 = r22.getScrollRange()
            boolean r0 = r14.springBack(r15, r16, r17, r18, r19, r20)
            if (r0 == 0) goto L_0x020c
            goto L_0x0209
        L_0x0081:
            int r0 = r9.f1092q0
            int r14 = r10.findPointerIndex(r0)
            if (r14 != r3) goto L_0x00a4
            java.lang.String r0 = "Invalid pointerId="
            java.lang.StringBuilder r0 = p000.C0789gk.m5562a((java.lang.String) r0)
            int r1 = r9.f1092q0
            r0.append(r1)
            java.lang.String r1 = " in onTouchEvent"
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            java.lang.String r1 = "NestedScrollView"
            android.util.Log.e(r1, r0)
            goto L_0x0259
        L_0x00a4:
            float r0 = r10.getY(r14)
            int r6 = (int) r0
            int r0 = r9.f1081f0
            int r7 = r0 - r6
            r1 = 0
            int[] r3 = r9.f1094s0
            int[] r4 = r9.f1093r0
            r5 = 0
            r0 = r22
            r2 = r7
            boolean r0 = r0.mo1315a((int) r1, (int) r2, (int[]) r3, (int[]) r4, (int) r5)
            if (r0 == 0) goto L_0x00ca
            int[] r0 = r9.f1094s0
            r0 = r0[r13]
            int r7 = r7 - r0
            int r0 = r9.f1095t0
            int[] r1 = r9.f1093r0
            r1 = r1[r13]
            int r0 = r0 + r1
            r9.f1095t0 = r0
        L_0x00ca:
            boolean r0 = r9.f1085j0
            if (r0 != 0) goto L_0x00e8
            int r0 = java.lang.Math.abs(r7)
            int r1 = r9.f1089n0
            if (r0 <= r1) goto L_0x00e8
            android.view.ViewParent r0 = r22.getParent()
            if (r0 == 0) goto L_0x00df
            r0.requestDisallowInterceptTouchEvent(r13)
        L_0x00df:
            r9.f1085j0 = r13
            int r0 = r9.f1089n0
            if (r7 <= 0) goto L_0x00e7
            int r7 = r7 - r0
            goto L_0x00e8
        L_0x00e7:
            int r7 = r7 + r0
        L_0x00e8:
            r15 = r7
            boolean r0 = r9.f1085j0
            if (r0 == 0) goto L_0x0259
            int[] r0 = r9.f1093r0
            r0 = r0[r13]
            int r6 = r6 - r0
            r9.f1081f0 = r6
            int r16 = r22.getScrollY()
            int r8 = r22.getScrollRange()
            int r0 = r22.getOverScrollMode()
            if (r0 == 0) goto L_0x010b
            if (r0 != r13) goto L_0x0107
            if (r8 <= 0) goto L_0x0107
            goto L_0x010b
        L_0x0107:
            r0 = 0
            r17 = 0
            goto L_0x010e
        L_0x010b:
            r0 = 1
            r17 = 1
        L_0x010e:
            r1 = 0
            r3 = 0
            int r4 = r22.getScrollY()
            r5 = 0
            r7 = 0
            r18 = 0
            r0 = r22
            r2 = r15
            r6 = r8
            r21 = r8
            r8 = r18
            boolean r0 = r0.mo1314a(r1, r2, r3, r4, r5, r6, r7, r8)
            if (r0 == 0) goto L_0x0131
            boolean r0 = r9.mo1342e(r11)
            if (r0 != 0) goto L_0x0131
            android.view.VelocityTracker r0 = r9.f1086k0
            r0.clear()
        L_0x0131:
            int r0 = r22.getScrollY()
            int r2 = r0 - r16
            int r4 = r15 - r2
            int[] r7 = r9.f1094s0
            r7[r13] = r11
            r1 = 0
            r3 = 0
            int[] r5 = r9.f1093r0
            r6 = 0
            r0 = r22
            r0.mo1307a((int) r1, (int) r2, (int) r3, (int) r4, (int[]) r5, (int) r6, (int[]) r7)
            int r0 = r9.f1081f0
            int[] r1 = r9.f1093r0
            r2 = r1[r13]
            int r0 = r0 - r2
            r9.f1081f0 = r0
            int r0 = r9.f1095t0
            r1 = r1[r13]
            int r0 = r0 + r1
            r9.f1095t0 = r0
            if (r17 == 0) goto L_0x0259
            int[] r0 = r9.f1094s0
            r0 = r0[r13]
            int r15 = r15 - r0
            r22.mo1322b()
            int r0 = r16 + r15
            if (r0 >= 0) goto L_0x0186
            android.widget.EdgeEffect r0 = r9.f1079d0
            float r1 = (float) r15
            int r2 = r22.getHeight()
            float r2 = (float) r2
            float r1 = r1 / r2
            float r2 = r10.getX(r14)
            int r3 = r22.getWidth()
            float r3 = (float) r3
            float r2 = r2 / r3
            p000.C0815h0.m5810a((android.widget.EdgeEffect) r0, (float) r1, (float) r2)
            android.widget.EdgeEffect r0 = r9.f1080e0
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x01b0
            android.widget.EdgeEffect r0 = r9.f1080e0
            goto L_0x01ad
        L_0x0186:
            r1 = r21
            if (r0 <= r1) goto L_0x01b0
            android.widget.EdgeEffect r0 = r9.f1080e0
            float r1 = (float) r15
            int r2 = r22.getHeight()
            float r2 = (float) r2
            float r1 = r1 / r2
            r2 = 1065353216(0x3f800000, float:1.0)
            float r3 = r10.getX(r14)
            int r4 = r22.getWidth()
            float r4 = (float) r4
            float r3 = r3 / r4
            float r2 = r2 - r3
            p000.C0815h0.m5810a((android.widget.EdgeEffect) r0, (float) r1, (float) r2)
            android.widget.EdgeEffect r0 = r9.f1079d0
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x01b0
            android.widget.EdgeEffect r0 = r9.f1079d0
        L_0x01ad:
            r0.onRelease()
        L_0x01b0:
            android.widget.EdgeEffect r0 = r9.f1079d0
            if (r0 == 0) goto L_0x0259
            boolean r0 = r0.isFinished()
            if (r0 == 0) goto L_0x01c2
            android.widget.EdgeEffect r0 = r9.f1080e0
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x0259
        L_0x01c2:
            p000.C2189w7.m14972D(r22)
            goto L_0x0259
        L_0x01c7:
            android.view.VelocityTracker r0 = r9.f1086k0
            r1 = 1000(0x3e8, float:1.401E-42)
            int r4 = r9.f1091p0
            float r4 = (float) r4
            r0.computeCurrentVelocity(r1, r4)
            int r1 = r9.f1092q0
            float r0 = r0.getYVelocity(r1)
            int r0 = (int) r0
            int r1 = java.lang.Math.abs(r0)
            int r4 = r9.f1090o0
            if (r1 <= r4) goto L_0x01ef
            int r0 = -r0
            float r1 = (float) r0
            boolean r4 = r9.dispatchNestedPreFling(r2, r1)
            if (r4 != 0) goto L_0x020c
            r9.dispatchNestedFling(r2, r1, r13)
            r9.mo1326c(r0)
            goto L_0x020c
        L_0x01ef:
            android.widget.OverScroller r14 = r9.f1078c0
            int r15 = r22.getScrollX()
            int r16 = r22.getScrollY()
            r17 = 0
            r18 = 0
            r19 = 0
            int r20 = r22.getScrollRange()
            boolean r0 = r14.springBack(r15, r16, r17, r18, r19, r20)
            if (r0 == 0) goto L_0x020c
        L_0x0209:
            p000.C2189w7.m14972D(r22)
        L_0x020c:
            r9.f1092q0 = r3
            r9.f1085j0 = r11
            r22.mo1325c()
            r9.mo1344g(r11)
            android.widget.EdgeEffect r0 = r9.f1079d0
            if (r0 == 0) goto L_0x0259
            r0.onRelease()
            android.widget.EdgeEffect r0 = r9.f1080e0
            r0.onRelease()
            goto L_0x0259
        L_0x0223:
            int r0 = r22.getChildCount()
            if (r0 != 0) goto L_0x022a
            return r11
        L_0x022a:
            android.widget.OverScroller r0 = r9.f1078c0
            boolean r0 = r0.isFinished()
            r0 = r0 ^ r13
            r9.f1085j0 = r0
            if (r0 == 0) goto L_0x023e
            android.view.ViewParent r0 = r22.getParent()
            if (r0 == 0) goto L_0x023e
            r0.requestDisallowInterceptTouchEvent(r13)
        L_0x023e:
            android.widget.OverScroller r0 = r9.f1078c0
            boolean r0 = r0.isFinished()
            if (r0 != 0) goto L_0x0249
            r22.mo1305a()
        L_0x0249:
            float r0 = r23.getY()
            int r0 = (int) r0
            r9.f1081f0 = r0
            int r0 = r10.getPointerId(r11)
            r9.f1092q0 = r0
            r9.mo1327c(r1, r11)
        L_0x0259:
            android.view.VelocityTracker r0 = r9.f1086k0
            if (r0 == 0) goto L_0x0260
            r0.addMovement(r12)
        L_0x0260:
            r12.recycle()
            return r13
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.onTouchEvent(android.view.MotionEvent):boolean");
    }

    public void requestChildFocus(View view, View view2) {
        if (!this.f1082g0) {
            mo1310a(view2);
        } else {
            this.f1084i0 = view2;
        }
        super.requestChildFocus(view, view2);
    }

    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        rect.offset(view.getLeft() - view.getScrollX(), view.getTop() - view.getScrollY());
        int a = mo1304a(rect);
        boolean z2 = a != 0;
        if (z2) {
            if (z) {
                scrollBy(0, a);
            } else {
                mo1306a(0, a);
            }
        }
        return z2;
    }

    public void requestDisallowInterceptTouchEvent(boolean z) {
        if (z) {
            mo1325c();
        }
        super.requestDisallowInterceptTouchEvent(z);
    }

    public void requestLayout() {
        this.f1082g0 = true;
        super.requestLayout();
    }

    public void scrollTo(int i, int i2) {
        if (getChildCount() > 0) {
            View childAt = getChildAt(0);
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) childAt.getLayoutParams();
            int b = m884b(i, (getWidth() - getPaddingLeft()) - getPaddingRight(), childAt.getWidth() + layoutParams.leftMargin + layoutParams.rightMargin);
            int b2 = m884b(i2, (getHeight() - getPaddingTop()) - getPaddingBottom(), childAt.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin);
            if (b != getScrollX() || b2 != getScrollY()) {
                super.scrollTo(b, b2);
            }
        }
    }

    public void setFillViewport(boolean z) {
        if (z != this.f1087l0) {
            this.f1087l0 = z;
            requestLayout();
        }
    }

    public void setNestedScrollingEnabled(boolean z) {
        C1313m7 m7Var = this.f1099x0;
        if (m7Var.f10039d) {
            C2189w7.m14974F(m7Var.f10038c);
        }
        m7Var.f10039d = z;
    }

    public void setOnScrollChangeListener(C0184b bVar) {
        this.f1101z0 = bVar;
    }

    public void setSmoothScrollingEnabled(boolean z) {
        this.f1088m0 = z;
    }

    public boolean shouldDelayChildPressedState() {
        return true;
    }

    public boolean startNestedScroll(int i) {
        return mo1327c(i, 0);
    }

    public void stopNestedScroll() {
        mo1344g(0);
    }

    /* renamed from: a */
    public void mo1307a(int i, int i2, int i3, int i4, int[] iArr, int i5, int[] iArr2) {
        this.f1099x0.mo8626b(i, i2, i3, i4, iArr, i5, iArr2);
    }

    /* JADX WARNING: Removed duplicated region for block: B:22:0x0062  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0038  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo1316a(android.view.KeyEvent r6) {
        /*
            r5 = this;
            android.graphics.Rect r0 = r5.f1077b0
            r0.setEmpty()
            int r0 = r5.getChildCount()
            r1 = 1
            r2 = 0
            if (r0 <= 0) goto L_0x0033
            android.view.View r0 = r5.getChildAt(r2)
            android.view.ViewGroup$LayoutParams r3 = r0.getLayoutParams()
            android.widget.FrameLayout$LayoutParams r3 = (android.widget.FrameLayout.LayoutParams) r3
            int r0 = r0.getHeight()
            int r4 = r3.topMargin
            int r0 = r0 + r4
            int r3 = r3.bottomMargin
            int r0 = r0 + r3
            int r3 = r5.getHeight()
            int r4 = r5.getPaddingTop()
            int r3 = r3 - r4
            int r4 = r5.getPaddingBottom()
            int r3 = r3 - r4
            if (r0 <= r3) goto L_0x0033
            r0 = 1
            goto L_0x0034
        L_0x0033:
            r0 = 0
        L_0x0034:
            r3 = 130(0x82, float:1.82E-43)
            if (r0 != 0) goto L_0x0062
            boolean r0 = r5.isFocused()
            if (r0 == 0) goto L_0x0061
            int r6 = r6.getKeyCode()
            r0 = 4
            if (r6 == r0) goto L_0x0061
            android.view.View r6 = r5.findFocus()
            if (r6 != r5) goto L_0x004c
            r6 = 0
        L_0x004c:
            android.view.FocusFinder r0 = android.view.FocusFinder.getInstance()
            android.view.View r6 = r0.findNextFocus(r5, r6, r3)
            if (r6 == 0) goto L_0x005f
            if (r6 == r5) goto L_0x005f
            boolean r6 = r6.requestFocus(r3)
            if (r6 == 0) goto L_0x005f
            goto L_0x0060
        L_0x005f:
            r1 = 0
        L_0x0060:
            return r1
        L_0x0061:
            return r2
        L_0x0062:
            int r0 = r6.getAction()
            if (r0 != 0) goto L_0x00a6
            int r0 = r6.getKeyCode()
            r1 = 19
            r4 = 33
            if (r0 == r1) goto L_0x0097
            r1 = 20
            if (r0 == r1) goto L_0x0087
            r1 = 62
            if (r0 == r1) goto L_0x007b
            goto L_0x00a6
        L_0x007b:
            boolean r6 = r6.isShiftPressed()
            if (r6 == 0) goto L_0x0083
            r3 = 33
        L_0x0083:
            r5.mo1343f(r3)
            goto L_0x00a6
        L_0x0087:
            boolean r6 = r6.isAltPressed()
            if (r6 != 0) goto L_0x0092
            boolean r2 = r5.mo1312a((int) r3)
            goto L_0x00a6
        L_0x0092:
            boolean r2 = r5.mo1335d(r3)
            goto L_0x00a6
        L_0x0097:
            boolean r6 = r6.isAltPressed()
            if (r6 != 0) goto L_0x00a2
            boolean r2 = r5.mo1312a((int) r4)
            goto L_0x00a6
        L_0x00a2:
            boolean r2 = r5.mo1335d(r4)
        L_0x00a6:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.widget.NestedScrollView.mo1316a(android.view.KeyEvent):boolean");
    }

    /* renamed from: a */
    public void mo805a(View view, View view2, int i, int i2) {
        C1674q7 q7Var = this.f1098w0;
        if (i2 == 1) {
            q7Var.f12903b = i;
        } else {
            q7Var.f12902a = i;
        }
        mo1327c(2, i2);
    }

    /* renamed from: a */
    public void mo801a(View view, int i) {
        C1674q7 q7Var = this.f1098w0;
        if (i == 1) {
            q7Var.f12903b = 0;
        } else {
            q7Var.f12902a = 0;
        }
        mo1344g(i);
    }

    /* renamed from: a */
    public final boolean mo1313a(int i, int i2, int i3) {
        boolean z;
        int i4 = i;
        int i5 = i2;
        int i6 = i3;
        int height = getHeight();
        int scrollY = getScrollY();
        int i7 = height + scrollY;
        boolean z2 = i4 == 33;
        ArrayList focusables = getFocusables(2);
        int size = focusables.size();
        View view = null;
        boolean z3 = false;
        for (int i8 = 0; i8 < size; i8++) {
            View view2 = (View) focusables.get(i8);
            int top = view2.getTop();
            int bottom = view2.getBottom();
            if (i5 < bottom && top < i6) {
                boolean z4 = i5 < top && bottom < i6;
                if (view == null) {
                    view = view2;
                    z3 = z4;
                } else {
                    boolean z5 = (z2 && top < view.getTop()) || (!z2 && bottom > view.getBottom());
                    if (z3) {
                        if (z4) {
                            if (!z5) {
                            }
                        }
                    } else if (z4) {
                        view = view2;
                        z3 = true;
                    } else if (!z5) {
                    }
                    view = view2;
                }
            }
        }
        if (view == null) {
            view = this;
        }
        if (i5 < scrollY || i6 > i7) {
            mo1323b(z2 ? i5 - scrollY : i6 - i7);
            z = true;
        } else {
            z = false;
        }
        if (view != findFocus()) {
            view.requestFocus(i4);
        }
        return z;
    }
}
