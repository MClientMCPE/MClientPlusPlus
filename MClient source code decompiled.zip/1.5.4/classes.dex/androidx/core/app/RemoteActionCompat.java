package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;

public final class RemoteActionCompat implements C0535df {

    /* renamed from: a */
    public IconCompat f1058a;

    /* renamed from: b */
    public CharSequence f1059b;

    /* renamed from: c */
    public CharSequence f1060c;

    /* renamed from: d */
    public PendingIntent f1061d;

    /* renamed from: e */
    public boolean f1062e;

    /* renamed from: f */
    public boolean f1063f;
}
