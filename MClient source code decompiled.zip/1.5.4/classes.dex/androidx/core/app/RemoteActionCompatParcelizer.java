package androidx.core.app;

import android.app.PendingIntent;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.core.graphics.drawable.IconCompat;

public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(C0300bf bfVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        Object obj = remoteActionCompat.f1058a;
        if (bfVar.mo2506a(1)) {
            obj = bfVar.mo2514d();
        }
        remoteActionCompat.f1058a = (IconCompat) obj;
        remoteActionCompat.f1059b = bfVar.mo2501a(remoteActionCompat.f1059b, 2);
        remoteActionCompat.f1060c = bfVar.mo2501a(remoteActionCompat.f1060c, 3);
        remoteActionCompat.f1061d = (PendingIntent) bfVar.mo2500a(remoteActionCompat.f1061d, 4);
        remoteActionCompat.f1062e = bfVar.mo2507a(remoteActionCompat.f1062e, 5);
        remoteActionCompat.f1063f = bfVar.mo2507a(remoteActionCompat.f1063f, 6);
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, C0300bf bfVar) {
        bfVar.mo2515e();
        IconCompat iconCompat = remoteActionCompat.f1058a;
        bfVar.mo2510b(1);
        bfVar.mo2505a((C0535df) iconCompat);
        CharSequence charSequence = remoteActionCompat.f1059b;
        bfVar.mo2510b(2);
        C0371cf cfVar = (C0371cf) bfVar;
        TextUtils.writeToParcel(charSequence, cfVar.f2686e, 0);
        CharSequence charSequence2 = remoteActionCompat.f1060c;
        bfVar.mo2510b(3);
        TextUtils.writeToParcel(charSequence2, cfVar.f2686e, 0);
        bfVar.mo2512b((Parcelable) remoteActionCompat.f1061d, 4);
        boolean z = remoteActionCompat.f1062e;
        bfVar.mo2510b(5);
        cfVar.f2686e.writeInt(z ? 1 : 0);
        boolean z2 = remoteActionCompat.f1063f;
        bfVar.mo2510b(6);
        cfVar.f2686e.writeInt(z2 ? 1 : 0);
    }
}
