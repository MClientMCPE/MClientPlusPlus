package androidx.core.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import p000.C0908i7;
import p000.C1234lb;

public class ComponentActivity extends Activity implements C1509ob, C0908i7.C0909a {

    /* renamed from: X */
    public C1607pb f1057X = new C1607pb(this);

    public ComponentActivity() {
        int[] iArr = C0339c5.f2506a;
        Object[] objArr = C0339c5.f2508c;
    }

    /* renamed from: a */
    public C1234lb mo635a() {
        return this.f1057X;
    }

    /* renamed from: a */
    public boolean mo1291a(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent);
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        View decorView = getWindow().getDecorView();
        if (decorView == null || !C2189w7.m15001b(decorView, keyEvent)) {
            return C0908i7.m6729a(this, decorView, this, keyEvent);
        }
        return true;
    }

    public boolean dispatchKeyShortcutEvent(KeyEvent keyEvent) {
        View decorView = getWindow().getDecorView();
        if (decorView == null || !C2189w7.m15001b(decorView, keyEvent)) {
            return super.dispatchKeyShortcutEvent(keyEvent);
        }
        return true;
    }

    @SuppressLint({"RestrictedApi"})
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        C2209wb.m15093a((Activity) this);
    }

    public void onSaveInstanceState(Bundle bundle) {
        this.f1057X.mo9941a(C1234lb.C1236b.CREATED);
        super.onSaveInstanceState(bundle);
    }
}
