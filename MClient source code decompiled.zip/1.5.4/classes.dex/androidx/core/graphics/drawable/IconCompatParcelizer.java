package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.os.Parcelable;

public class IconCompatParcelizer {
    public static IconCompat read(C0300bf bfVar) {
        IconCompat iconCompat = new IconCompat();
        iconCompat.f1065a = bfVar.mo2499a(iconCompat.f1065a, 1);
        byte[] bArr = iconCompat.f1067c;
        if (bfVar.mo2506a(2)) {
            C0371cf cfVar = (C0371cf) bfVar;
            int readInt = cfVar.f2686e.readInt();
            if (readInt < 0) {
                bArr = null;
            } else {
                byte[] bArr2 = new byte[readInt];
                cfVar.f2686e.readByteArray(bArr2);
                bArr = bArr2;
            }
        }
        iconCompat.f1067c = bArr;
        iconCompat.f1068d = bfVar.mo2500a(iconCompat.f1068d, 3);
        iconCompat.f1069e = bfVar.mo2499a(iconCompat.f1069e, 4);
        iconCompat.f1070f = bfVar.mo2499a(iconCompat.f1070f, 5);
        iconCompat.f1071g = (ColorStateList) bfVar.mo2500a(iconCompat.f1071g, 6);
        String str = iconCompat.f1073i;
        if (bfVar.mo2506a(7)) {
            str = bfVar.mo2513c();
        }
        iconCompat.f1073i = str;
        iconCompat.mo1302c();
        return iconCompat;
    }

    public static void write(IconCompat iconCompat, C0300bf bfVar) {
        bfVar.mo2515e();
        iconCompat.mo1300a(false);
        int i = iconCompat.f1065a;
        if (-1 != i) {
            bfVar.mo2511b(i, 1);
        }
        byte[] bArr = iconCompat.f1067c;
        if (bArr != null) {
            bfVar.mo2510b(2);
            C0371cf cfVar = (C0371cf) bfVar;
            cfVar.f2686e.writeInt(bArr.length);
            cfVar.f2686e.writeByteArray(bArr);
        }
        Parcelable parcelable = iconCompat.f1068d;
        if (parcelable != null) {
            bfVar.mo2510b(3);
            ((C0371cf) bfVar).f2686e.writeParcelable(parcelable, 0);
        }
        int i2 = iconCompat.f1069e;
        if (i2 != 0) {
            bfVar.mo2511b(i2, 4);
        }
        int i3 = iconCompat.f1070f;
        if (i3 != 0) {
            bfVar.mo2511b(i3, 5);
        }
        ColorStateList colorStateList = iconCompat.f1071g;
        if (colorStateList != null) {
            bfVar.mo2510b(6);
            ((C0371cf) bfVar).f2686e.writeParcelable(colorStateList, 0);
        }
        String str = iconCompat.f1073i;
        if (str != null) {
            bfVar.mo2510b(7);
            ((C0371cf) bfVar).f2686e.writeString(str);
        }
    }
}
