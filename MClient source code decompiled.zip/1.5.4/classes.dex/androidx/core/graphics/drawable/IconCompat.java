package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Parcelable;
import android.util.Log;
import androidx.versionedparcelable.CustomVersionedParcelable;
import java.io.ByteArrayOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.nio.charset.Charset;

public class IconCompat extends CustomVersionedParcelable {

    /* renamed from: j */
    public static final PorterDuff.Mode f1064j = PorterDuff.Mode.SRC_IN;

    /* renamed from: a */
    public int f1065a = -1;

    /* renamed from: b */
    public Object f1066b;

    /* renamed from: c */
    public byte[] f1067c = null;

    /* renamed from: d */
    public Parcelable f1068d = null;

    /* renamed from: e */
    public int f1069e = 0;

    /* renamed from: f */
    public int f1070f = 0;

    /* renamed from: g */
    public ColorStateList f1071g = null;

    /* renamed from: h */
    public PorterDuff.Mode f1072h = f1064j;

    /* renamed from: i */
    public String f1073i = null;

    /* renamed from: a */
    public int mo1299a() {
        int i;
        if (this.f1065a == -1 && (i = Build.VERSION.SDK_INT) >= 23) {
            Icon icon = (Icon) this.f1066b;
            if (i >= 28) {
                return icon.getResId();
            }
            try {
                return ((Integer) icon.getClass().getMethod("getResId", new Class[0]).invoke(icon, new Object[0])).intValue();
            } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
                Log.e("IconCompat", "Unable to get icon resource", e);
                return 0;
            }
        } else if (this.f1065a == 2) {
            return this.f1069e;
        } else {
            throw new IllegalStateException("called getResId() on " + this);
        }
    }

    /* renamed from: a */
    public void mo1300a(boolean z) {
        this.f1073i = this.f1072h.name();
        int i = this.f1065a;
        if (i != -1) {
            if (i != 1) {
                if (i == 2) {
                    this.f1067c = ((String) this.f1066b).getBytes(Charset.forName("UTF-16"));
                    return;
                } else if (i == 3) {
                    this.f1067c = (byte[]) this.f1066b;
                    return;
                } else if (i == 4) {
                    this.f1067c = this.f1066b.toString().getBytes(Charset.forName("UTF-16"));
                    return;
                } else if (i != 5) {
                    return;
                }
            }
            if (z) {
                ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                ((Bitmap) this.f1066b).compress(Bitmap.CompressFormat.PNG, 90, byteArrayOutputStream);
                this.f1067c = byteArrayOutputStream.toByteArray();
                return;
            }
        } else if (z) {
            throw new IllegalArgumentException("Can't serialize Icon created with IconCompat#createFromIcon");
        }
        this.f1068d = (Parcelable) this.f1066b;
    }

    /* renamed from: b */
    public String mo1301b() {
        int i;
        if (this.f1065a == -1 && (i = Build.VERSION.SDK_INT) >= 23) {
            Icon icon = (Icon) this.f1066b;
            if (i >= 28) {
                return icon.getResPackage();
            }
            try {
                return (String) icon.getClass().getMethod("getResPackage", new Class[0]).invoke(icon, new Object[0]);
            } catch (IllegalAccessException | NoSuchMethodException | InvocationTargetException e) {
                Log.e("IconCompat", "Unable to get icon package", e);
                return null;
            }
        } else if (this.f1065a == 2) {
            return ((String) this.f1066b).split(":", -1)[0];
        } else {
            throw new IllegalStateException("called getResPackage() on " + this);
        }
    }

    /* renamed from: c */
    public void mo1302c() {
        Parcelable parcelable;
        this.f1072h = PorterDuff.Mode.valueOf(this.f1073i);
        int i = this.f1065a;
        if (i != -1) {
            if (i != 1) {
                if (i != 2) {
                    if (i == 3) {
                        this.f1066b = this.f1067c;
                        return;
                    } else if (i != 4) {
                        if (i != 5) {
                            return;
                        }
                    }
                }
                this.f1066b = new String(this.f1067c, Charset.forName("UTF-16"));
                return;
            }
            parcelable = this.f1068d;
            if (parcelable == null) {
                byte[] bArr = this.f1067c;
                this.f1066b = bArr;
                this.f1065a = 3;
                this.f1069e = 0;
                this.f1070f = bArr.length;
                return;
            }
        } else {
            parcelable = this.f1068d;
            if (parcelable == null) {
                throw new IllegalArgumentException("Invalid icon");
            }
        }
        this.f1066b = parcelable;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0042, code lost:
        if (r1 != 5) goto L_0x00ae;
     */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x00b2  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x00c2  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.lang.String toString() {
        /*
            r7 = this;
            int r0 = r7.f1065a
            r1 = -1
            if (r0 != r1) goto L_0x000c
            java.lang.Object r0 = r7.f1066b
            java.lang.String r0 = java.lang.String.valueOf(r0)
            return r0
        L_0x000c:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r1 = "Icon(typ="
            r0.<init>(r1)
            int r1 = r7.f1065a
            r2 = 5
            r3 = 4
            r4 = 3
            r5 = 2
            r6 = 1
            if (r1 == r6) goto L_0x0033
            if (r1 == r5) goto L_0x0030
            if (r1 == r4) goto L_0x002d
            if (r1 == r3) goto L_0x002a
            if (r1 == r2) goto L_0x0027
            java.lang.String r1 = "UNKNOWN"
            goto L_0x0035
        L_0x0027:
            java.lang.String r1 = "BITMAP_MASKABLE"
            goto L_0x0035
        L_0x002a:
            java.lang.String r1 = "URI"
            goto L_0x0035
        L_0x002d:
            java.lang.String r1 = "DATA"
            goto L_0x0035
        L_0x0030:
            java.lang.String r1 = "RESOURCE"
            goto L_0x0035
        L_0x0033:
            java.lang.String r1 = "BITMAP"
        L_0x0035:
            r0.append(r1)
            int r1 = r7.f1065a
            if (r1 == r6) goto L_0x008e
            if (r1 == r5) goto L_0x0066
            if (r1 == r4) goto L_0x0050
            if (r1 == r3) goto L_0x0045
            if (r1 == r2) goto L_0x008e
            goto L_0x00ae
        L_0x0045:
            java.lang.String r1 = " uri="
            r0.append(r1)
            java.lang.Object r1 = r7.f1066b
            r0.append(r1)
            goto L_0x00ae
        L_0x0050:
            java.lang.String r1 = " len="
            r0.append(r1)
            int r1 = r7.f1069e
            r0.append(r1)
            int r1 = r7.f1070f
            if (r1 == 0) goto L_0x00ae
            java.lang.String r1 = " off="
            r0.append(r1)
            int r1 = r7.f1070f
            goto L_0x00ab
        L_0x0066:
            java.lang.String r1 = " pkg="
            r0.append(r1)
            java.lang.String r1 = r7.mo1301b()
            r0.append(r1)
            java.lang.String r1 = " id="
            r0.append(r1)
            java.lang.Object[] r1 = new java.lang.Object[r6]
            r2 = 0
            int r3 = r7.mo1299a()
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)
            r1[r2] = r3
            java.lang.String r2 = "0x%08x"
            java.lang.String r1 = java.lang.String.format(r2, r1)
            r0.append(r1)
            goto L_0x00ae
        L_0x008e:
            java.lang.String r1 = " size="
            r0.append(r1)
            java.lang.Object r1 = r7.f1066b
            android.graphics.Bitmap r1 = (android.graphics.Bitmap) r1
            int r1 = r1.getWidth()
            r0.append(r1)
            java.lang.String r1 = "x"
            r0.append(r1)
            java.lang.Object r1 = r7.f1066b
            android.graphics.Bitmap r1 = (android.graphics.Bitmap) r1
            int r1 = r1.getHeight()
        L_0x00ab:
            r0.append(r1)
        L_0x00ae:
            android.content.res.ColorStateList r1 = r7.f1071g
            if (r1 == 0) goto L_0x00bc
            java.lang.String r1 = " tint="
            r0.append(r1)
            android.content.res.ColorStateList r1 = r7.f1071g
            r0.append(r1)
        L_0x00bc:
            android.graphics.PorterDuff$Mode r1 = r7.f1072h
            android.graphics.PorterDuff$Mode r2 = f1064j
            if (r1 == r2) goto L_0x00cc
            java.lang.String r1 = " mode="
            r0.append(r1)
            android.graphics.PorterDuff$Mode r1 = r7.f1072h
            r0.append(r1)
        L_0x00cc:
            java.lang.String r1 = ")"
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.graphics.drawable.IconCompat.toString():java.lang.String");
    }
}
