package androidx.coordinatorlayout.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CoordinatorLayout extends ViewGroup implements C1403n7, C1502o7 {

    /* renamed from: u0 */
    public static final String f1011u0;

    /* renamed from: v0 */
    public static final Class<?>[] f1012v0 = {Context.class, AttributeSet.class};

    /* renamed from: w0 */
    public static final ThreadLocal<Map<String, Constructor<C0174c>>> f1013w0 = new ThreadLocal<>();

    /* renamed from: x0 */
    public static final Comparator<View> f1014x0;

    /* renamed from: y0 */
    public static final C0590e7<Rect> f1015y0 = new C0666f7(12);

    /* renamed from: a0 */
    public final List<View> f1016a0;

    /* renamed from: b0 */
    public final C1220l5<View> f1017b0;

    /* renamed from: c0 */
    public final List<View> f1018c0;

    /* renamed from: d0 */
    public final List<View> f1019d0;

    /* renamed from: e0 */
    public Paint f1020e0;

    /* renamed from: f0 */
    public final int[] f1021f0;

    /* renamed from: g0 */
    public final int[] f1022g0;

    /* renamed from: h0 */
    public boolean f1023h0;

    /* renamed from: i0 */
    public boolean f1024i0;

    /* renamed from: j0 */
    public int[] f1025j0;

    /* renamed from: k0 */
    public View f1026k0;

    /* renamed from: l0 */
    public View f1027l0;

    /* renamed from: m0 */
    public C0178g f1028m0;

    /* renamed from: n0 */
    public boolean f1029n0;

    /* renamed from: o0 */
    public C0592e8 f1030o0;

    /* renamed from: p0 */
    public boolean f1031p0;

    /* renamed from: q0 */
    public Drawable f1032q0;

    /* renamed from: r0 */
    public ViewGroup.OnHierarchyChangeListener f1033r0;

    /* renamed from: s0 */
    public C1746r7 f1034s0;

    /* renamed from: t0 */
    public final C1674q7 f1035t0;

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$a */
    public class C0172a implements C1746r7 {
        public C0172a() {
        }

        /* renamed from: a */
        public C0592e8 mo1250a(View view, C0592e8 e8Var) {
            return CoordinatorLayout.this.mo1193a(e8Var);
        }
    }

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$b */
    public interface C0173b {
        C0174c getBehavior();
    }

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$c */
    public static abstract class C0174c<V extends View> {
        public C0174c() {
        }

        public C0174c(Context context, AttributeSet attributeSet) {
        }

        /* renamed from: a */
        public int mo1252a() {
            return -16777216;
        }

        /* renamed from: a */
        public C0592e8 mo1253a(C0592e8 e8Var) {
            return e8Var;
        }

        /* renamed from: a */
        public void mo1254a(C0177f fVar) {
        }

        /* renamed from: a */
        public void mo1255a(CoordinatorLayout coordinatorLayout, V v, Parcelable parcelable) {
        }

        /* renamed from: a */
        public void mo1256a(CoordinatorLayout coordinatorLayout, V v, View view, int i) {
            if (i == 0) {
                mo1280h();
            }
        }

        @Deprecated
        /* renamed from: a */
        public void mo1257a(CoordinatorLayout coordinatorLayout, V v, View view, int i, int i2, int i3, int i4) {
        }

        @Deprecated
        /* renamed from: a */
        public void mo1258a(CoordinatorLayout coordinatorLayout, V v, View view, int i, int i2, int i3, int i4, int i5) {
            if (i5 == 0) {
                mo1257a(coordinatorLayout, v, view, i, i2, i3, i4);
            }
        }

        /* renamed from: a */
        public void mo1259a(CoordinatorLayout coordinatorLayout, V v, View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
            iArr[0] = iArr[0] + i3;
            iArr[1] = iArr[1] + i4;
            mo1258a(coordinatorLayout, v, view, i, i2, i3, i4, i5);
        }

        /* renamed from: a */
        public void mo1260a(CoordinatorLayout coordinatorLayout, V v, View view, int i, int i2, int[] iArr, int i3) {
            if (i3 == 0) {
                mo1278f();
            }
        }

        /* renamed from: a */
        public void mo1261a(CoordinatorLayout coordinatorLayout, V v, View view, View view2, int i, int i2) {
            if (i2 == 0) {
                mo1279g();
            }
        }

        /* renamed from: a */
        public boolean mo1262a(CoordinatorLayout coordinatorLayout, V v) {
            return mo1270b() > 0.0f;
        }

        /* renamed from: a */
        public boolean mo203a(CoordinatorLayout coordinatorLayout, V v, int i) {
            return false;
        }

        /* renamed from: a */
        public boolean mo1263a(CoordinatorLayout coordinatorLayout, V v, int i, int i2, int i3, int i4) {
            return false;
        }

        /* renamed from: a */
        public boolean mo1264a(CoordinatorLayout coordinatorLayout, V v, Rect rect) {
            return false;
        }

        /* renamed from: a */
        public boolean mo1265a(CoordinatorLayout coordinatorLayout, V v, Rect rect, boolean z) {
            return false;
        }

        /* renamed from: a */
        public boolean mo1266a(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
            return false;
        }

        /* renamed from: a */
        public boolean mo1267a(CoordinatorLayout coordinatorLayout, V v, View view) {
            return false;
        }

        /* renamed from: a */
        public boolean mo1268a(CoordinatorLayout coordinatorLayout, V v, View view, float f, float f2) {
            return false;
        }

        @Deprecated
        /* renamed from: a */
        public boolean mo1269a(CoordinatorLayout coordinatorLayout, V v, View view, View view2, int i) {
            return false;
        }

        /* renamed from: b */
        public float mo1270b() {
            return 0.0f;
        }

        /* renamed from: b */
        public Parcelable mo1271b(CoordinatorLayout coordinatorLayout, V v) {
            return View.BaseSavedState.EMPTY_STATE;
        }

        /* renamed from: b */
        public boolean mo1272b(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
            return false;
        }

        /* renamed from: b */
        public boolean mo1273b(CoordinatorLayout coordinatorLayout, V v, View view) {
            return false;
        }

        /* renamed from: b */
        public boolean mo1274b(CoordinatorLayout coordinatorLayout, V v, View view, View view2, int i, int i2) {
            if (i2 == 0) {
                return mo1269a(coordinatorLayout, v, view, view2, i);
            }
            return false;
        }

        /* renamed from: c */
        public void mo1275c() {
        }

        /* renamed from: d */
        public void mo1276d() {
        }

        /* renamed from: e */
        public boolean mo1277e() {
            return false;
        }

        @Deprecated
        /* renamed from: f */
        public void mo1278f() {
        }

        @Deprecated
        /* renamed from: g */
        public void mo1279g() {
        }

        @Deprecated
        /* renamed from: h */
        public void mo1280h() {
        }
    }

    @Deprecated
    @Retention(RetentionPolicy.RUNTIME)
    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$d */
    public @interface C0175d {
        Class<? extends C0174c> value();
    }

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$e */
    public class C0176e implements ViewGroup.OnHierarchyChangeListener {
        public C0176e() {
        }

        public void onChildViewAdded(View view, View view2) {
            ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = CoordinatorLayout.this.f1033r0;
            if (onHierarchyChangeListener != null) {
                onHierarchyChangeListener.onChildViewAdded(view, view2);
            }
        }

        public void onChildViewRemoved(View view, View view2) {
            CoordinatorLayout.this.mo1208b(2);
            ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = CoordinatorLayout.this.f1033r0;
            if (onHierarchyChangeListener != null) {
                onHierarchyChangeListener.onChildViewRemoved(view, view2);
            }
        }
    }

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$f */
    public static class C0177f extends ViewGroup.MarginLayoutParams {

        /* renamed from: a */
        public C0174c f1038a;

        /* renamed from: b */
        public boolean f1039b = false;

        /* renamed from: c */
        public int f1040c = 0;

        /* renamed from: d */
        public int f1041d = 0;

        /* renamed from: e */
        public int f1042e = -1;

        /* renamed from: f */
        public int f1043f = -1;

        /* renamed from: g */
        public int f1044g = 0;

        /* renamed from: h */
        public int f1045h = 0;

        /* renamed from: i */
        public int f1046i;

        /* renamed from: j */
        public int f1047j;

        /* renamed from: k */
        public View f1048k;

        /* renamed from: l */
        public View f1049l;

        /* renamed from: m */
        public boolean f1050m;

        /* renamed from: n */
        public boolean f1051n;

        /* renamed from: o */
        public boolean f1052o;

        /* renamed from: p */
        public boolean f1053p;

        /* renamed from: q */
        public final Rect f1054q = new Rect();

        public C0177f(int i, int i2) {
            super(i, i2);
        }

        public C0177f(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C1128k5.CoordinatorLayout_Layout);
            this.f1040c = obtainStyledAttributes.getInteger(C1128k5.CoordinatorLayout_Layout_android_layout_gravity, 0);
            this.f1043f = obtainStyledAttributes.getResourceId(C1128k5.CoordinatorLayout_Layout_layout_anchor, -1);
            this.f1041d = obtainStyledAttributes.getInteger(C1128k5.CoordinatorLayout_Layout_layout_anchorGravity, 0);
            this.f1042e = obtainStyledAttributes.getInteger(C1128k5.CoordinatorLayout_Layout_layout_keyline, -1);
            this.f1044g = obtainStyledAttributes.getInt(C1128k5.CoordinatorLayout_Layout_layout_insetEdge, 0);
            this.f1045h = obtainStyledAttributes.getInt(C1128k5.CoordinatorLayout_Layout_layout_dodgeInsetEdges, 0);
            this.f1039b = obtainStyledAttributes.hasValue(C1128k5.CoordinatorLayout_Layout_layout_behavior);
            if (this.f1039b) {
                this.f1038a = CoordinatorLayout.m803a(context, attributeSet, obtainStyledAttributes.getString(C1128k5.CoordinatorLayout_Layout_layout_behavior));
            }
            obtainStyledAttributes.recycle();
            C0174c cVar = this.f1038a;
            if (cVar != null) {
                cVar.mo1254a(this);
            }
        }

        public C0177f(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public C0177f(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        public C0177f(C0177f fVar) {
            super(fVar);
        }

        /* renamed from: a */
        public void mo1284a(int i, boolean z) {
            if (i == 0) {
                this.f1051n = z;
            } else if (i == 1) {
                this.f1052o = z;
            }
        }

        /* renamed from: a */
        public boolean mo1285a(int i) {
            if (i == 0) {
                return this.f1051n;
            }
            if (i != 1) {
                return false;
            }
            return this.f1052o;
        }
    }

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$g */
    public class C0178g implements ViewTreeObserver.OnPreDrawListener {
        public C0178g() {
        }

        public boolean onPreDraw() {
            CoordinatorLayout.this.mo1208b(0);
            return true;
        }
    }

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$h */
    public static class C0179h extends C1904t8 {
        public static final Parcelable.Creator<C0179h> CREATOR = new C0180a();

        /* renamed from: Z */
        public SparseArray<Parcelable> f1056Z;

        /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$h$a */
        public static class C0180a implements Parcelable.ClassLoaderCreator<C0179h> {
            public Object createFromParcel(Parcel parcel) {
                return new C0179h(parcel, (ClassLoader) null);
            }

            public Object[] newArray(int i) {
                return new C0179h[i];
            }

            public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new C0179h(parcel, classLoader);
            }
        }

        public C0179h(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            int readInt = parcel.readInt();
            int[] iArr = new int[readInt];
            parcel.readIntArray(iArr);
            Parcelable[] readParcelableArray = parcel.readParcelableArray(classLoader);
            this.f1056Z = new SparseArray<>(readInt);
            for (int i = 0; i < readInt; i++) {
                this.f1056Z.append(iArr[i], readParcelableArray[i]);
            }
        }

        public C0179h(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeParcelable(this.f14707X, i);
            SparseArray<Parcelable> sparseArray = this.f1056Z;
            int size = sparseArray != null ? sparseArray.size() : 0;
            parcel.writeInt(size);
            int[] iArr = new int[size];
            Parcelable[] parcelableArr = new Parcelable[size];
            for (int i2 = 0; i2 < size; i2++) {
                iArr[i2] = this.f1056Z.keyAt(i2);
                parcelableArr[i2] = this.f1056Z.valueAt(i2);
            }
            parcel.writeIntArray(iArr);
            parcel.writeParcelableArray(parcelableArr, i);
        }
    }

    /* renamed from: androidx.coordinatorlayout.widget.CoordinatorLayout$i */
    public static class C0181i implements Comparator<View> {
        public int compare(Object obj, Object obj2) {
            float u = C2189w7.m15026u((View) obj);
            float u2 = C2189w7.m15026u((View) obj2);
            if (u > u2) {
                return -1;
            }
            return u < u2 ? 1 : 0;
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v5, resolved type: java.lang.Class<?>[]} */
    /* JADX WARNING: Multi-variable type inference failed */
    static {
        /*
            java.lang.Class<androidx.coordinatorlayout.widget.CoordinatorLayout> r0 = androidx.coordinatorlayout.widget.CoordinatorLayout.class
            java.lang.Package r0 = r0.getPackage()
            r1 = 0
            if (r0 == 0) goto L_0x000e
            java.lang.String r0 = r0.getName()
            goto L_0x000f
        L_0x000e:
            r0 = r1
        L_0x000f:
            f1011u0 = r0
            int r0 = android.os.Build.VERSION.SDK_INT
            r2 = 21
            if (r0 < r2) goto L_0x001f
            androidx.coordinatorlayout.widget.CoordinatorLayout$i r0 = new androidx.coordinatorlayout.widget.CoordinatorLayout$i
            r0.<init>()
            f1014x0 = r0
            goto L_0x0021
        L_0x001f:
            f1014x0 = r1
        L_0x0021:
            r0 = 2
            java.lang.Class[] r0 = new java.lang.Class[r0]
            r1 = 0
            java.lang.Class<android.content.Context> r2 = android.content.Context.class
            r0[r1] = r2
            r1 = 1
            java.lang.Class<android.util.AttributeSet> r2 = android.util.AttributeSet.class
            r0[r1] = r2
            f1012v0 = r0
            java.lang.ThreadLocal r0 = new java.lang.ThreadLocal
            r0.<init>()
            f1013w0 = r0
            f7 r0 = new f7
            r1 = 12
            r0.<init>(r1)
            f1015y0 = r0
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.<clinit>():void");
    }

    public CoordinatorLayout(Context context) {
        this(context, (AttributeSet) null);
    }

    public CoordinatorLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0906i5.coordinatorLayoutStyle);
    }

    public CoordinatorLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f1016a0 = new ArrayList();
        this.f1017b0 = new C1220l5<>();
        this.f1018c0 = new ArrayList();
        this.f1019d0 = new ArrayList();
        this.f1021f0 = new int[2];
        this.f1022g0 = new int[2];
        this.f1035t0 = new C1674q7();
        int[] iArr = C1128k5.CoordinatorLayout;
        TypedArray obtainStyledAttributes = i == 0 ? context.obtainStyledAttributes(attributeSet, iArr, 0, C0988j5.Widget_Support_CoordinatorLayout) : context.obtainStyledAttributes(attributeSet, iArr, i, 0);
        if (Build.VERSION.SDK_INT >= 29) {
            int[] iArr2 = C1128k5.CoordinatorLayout;
            if (i == 0) {
                saveAttributeDataForStyleable(context, iArr2, attributeSet, obtainStyledAttributes, 0, C0988j5.Widget_Support_CoordinatorLayout);
            } else {
                saveAttributeDataForStyleable(context, iArr2, attributeSet, obtainStyledAttributes, i, 0);
            }
        }
        int resourceId = obtainStyledAttributes.getResourceId(C1128k5.CoordinatorLayout_keylines, 0);
        if (resourceId != 0) {
            Resources resources = context.getResources();
            this.f1025j0 = resources.getIntArray(resourceId);
            float f = resources.getDisplayMetrics().density;
            int length = this.f1025j0.length;
            for (int i2 = 0; i2 < length; i2++) {
                int[] iArr3 = this.f1025j0;
                iArr3[i2] = (int) (((float) iArr3[i2]) * f);
            }
        }
        this.f1032q0 = obtainStyledAttributes.getDrawable(C1128k5.CoordinatorLayout_statusBarBackground);
        obtainStyledAttributes.recycle();
        mo1221e();
        super.setOnHierarchyChangeListener(new C0176e());
        if (C2189w7.m15016k(this) == 0) {
            int i3 = Build.VERSION.SDK_INT;
            setImportantForAccessibility(1);
        }
    }

    /* renamed from: a */
    public static C0174c m803a(Context context, AttributeSet attributeSet, String str) {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        if (str.startsWith(".")) {
            str = context.getPackageName() + str;
        } else if (str.indexOf(46) < 0 && !TextUtils.isEmpty(f1011u0)) {
            str = f1011u0 + '.' + str;
        }
        try {
            Map map = f1013w0.get();
            if (map == null) {
                map = new HashMap();
                f1013w0.set(map);
            }
            Constructor<?> constructor = (Constructor) map.get(str);
            if (constructor == null) {
                constructor = Class.forName(str, false, context.getClassLoader()).getConstructor(f1012v0);
                constructor.setAccessible(true);
                map.put(str, constructor);
            }
            return (C0174c) constructor.newInstance(new Object[]{context, attributeSet});
        } catch (Exception e) {
            throw new RuntimeException(C0789gk.m5557a("Could not inflate Behavior subclass ", str), e);
        }
    }

    /* renamed from: a */
    public static void m804a(Rect rect) {
        rect.setEmpty();
        f1015y0.mo5049a(rect);
    }

    /* renamed from: c */
    public static int m805c(int i) {
        if ((i & 7) == 0) {
            i |= 8388611;
        }
        return (i & 112) == 0 ? i | 48 : i;
    }

    /* renamed from: d */
    public static int m806d(int i) {
        if (i == 0) {
            return 8388661;
        }
        return i;
    }

    /* renamed from: f */
    public static Rect m807f() {
        Rect a = f1015y0.mo5048a();
        return a == null ? new Rect() : a;
    }

    /* renamed from: a */
    public final int mo1192a(int i) {
        StringBuilder sb;
        int[] iArr = this.f1025j0;
        if (iArr == null) {
            sb = new StringBuilder();
            sb.append("No keylines defined for ");
            sb.append(this);
            sb.append(" - attempted index lookup ");
            sb.append(i);
        } else if (i >= 0 && i < iArr.length) {
            return iArr[i];
        } else {
            sb = new StringBuilder();
            sb.append("Keyline index ");
            sb.append(i);
            sb.append(" out of range for ");
            sb.append(this);
        }
        Log.e("CoordinatorLayout", sb.toString());
        return 0;
    }

    /* renamed from: a */
    public void mo1194a() {
        if (this.f1024i0) {
            if (this.f1028m0 == null) {
                this.f1028m0 = new C0178g();
            }
            getViewTreeObserver().addOnPreDrawListener(this.f1028m0);
        }
        this.f1029n0 = true;
    }

    /* renamed from: a */
    public final void mo1195a(int i, Rect rect, Rect rect2, C0177f fVar, int i2, int i3) {
        int i4 = fVar.f1040c;
        if (i4 == 0) {
            i4 = 17;
        }
        int a = C0815h0.m5770a(i4, i);
        int i5 = fVar.f1041d;
        if ((i5 & 7) == 0) {
            i5 |= 8388611;
        }
        if ((i5 & 112) == 0) {
            i5 |= 48;
        }
        int a2 = C0815h0.m5770a(i5, i);
        int i6 = a & 7;
        int i7 = a & 112;
        int i8 = a2 & 7;
        int i9 = a2 & 112;
        int width = i8 != 1 ? i8 != 5 ? rect.left : rect.right : rect.left + (rect.width() / 2);
        int height = i9 != 16 ? i9 != 80 ? rect.top : rect.bottom : rect.top + (rect.height() / 2);
        if (i6 == 1) {
            width -= i2 / 2;
        } else if (i6 != 5) {
            width -= i2;
        }
        if (i7 == 16) {
            height -= i3 / 2;
        } else if (i7 != 80) {
            height -= i3;
        }
        rect2.set(width, height, i2 + width, i3 + height);
    }

    /* renamed from: a */
    public void mo1196a(View view) {
        List orDefault = this.f1017b0.f9459b.getOrDefault(view, null);
        if (orDefault != null && !orDefault.isEmpty()) {
            for (int i = 0; i < orDefault.size(); i++) {
                View view2 = (View) orDefault.get(i);
                C0174c cVar = ((C0177f) view2.getLayoutParams()).f1038a;
                if (cVar != null) {
                    cVar.mo1273b(this, view2, view);
                }
            }
        }
    }

    /* renamed from: a */
    public void mo1197a(View view, int i, int i2, int i3, int i4) {
        measureChildWithMargins(view, i, i2, i3, i4);
    }

    /* renamed from: a */
    public void mo802a(View view, int i, int i2, int i3, int i4, int i5) {
        mo803a(view, i, i2, i3, i4, 0, this.f1022g0);
    }

    /* renamed from: a */
    public void mo1198a(View view, int i, Rect rect, Rect rect2) {
        C0177f fVar = (C0177f) view.getLayoutParams();
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        mo1195a(i, rect, rect2, fVar, measuredWidth, measuredHeight);
        mo1201a(fVar, rect2, measuredWidth, measuredHeight);
    }

    /* renamed from: a */
    public void mo1199a(View view, Rect rect) {
        C1308m5.m9038a((ViewGroup) this, view, rect);
    }

    /* renamed from: a */
    public void mo1200a(View view, boolean z, Rect rect) {
        if (view.isLayoutRequested() || view.getVisibility() == 8) {
            rect.setEmpty();
        } else if (z) {
            mo1199a(view, rect);
        } else {
            rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        }
    }

    /* renamed from: a */
    public final void mo1201a(C0177f fVar, Rect rect, int i, int i2) {
        int width = getWidth();
        int height = getHeight();
        int max = Math.max(getPaddingLeft() + fVar.leftMargin, Math.min(rect.left, ((width - getPaddingRight()) - i) - fVar.rightMargin));
        int max2 = Math.max(getPaddingTop() + fVar.topMargin, Math.min(rect.top, ((height - getPaddingBottom()) - i2) - fVar.bottomMargin));
        rect.set(max, max2, i + max, i2 + max2);
    }

    /* renamed from: a */
    public final void mo1202a(List<View> list) {
        list.clear();
        boolean isChildrenDrawingOrderEnabled = isChildrenDrawingOrderEnabled();
        int childCount = getChildCount();
        for (int i = childCount - 1; i >= 0; i--) {
            list.add(getChildAt(isChildrenDrawingOrderEnabled ? getChildDrawingOrder(childCount, i) : i));
        }
        Comparator<View> comparator = f1014x0;
        if (comparator != null) {
            Collections.sort(list, comparator);
        }
    }

    /* renamed from: b */
    public void mo1207b() {
        boolean z;
        int childCount = getChildCount();
        boolean z2 = false;
        int i = 0;
        while (true) {
            if (i >= childCount) {
                break;
            }
            View childAt = getChildAt(i);
            C1220l5<View> l5Var = this.f1017b0;
            int i2 = l5Var.f9459b.f5965Z;
            int i3 = 0;
            while (true) {
                if (i3 < i2) {
                    ArrayList e = l5Var.f9459b.mo5982e(i3);
                    if (e != null && e.contains(childAt)) {
                        z = true;
                        break;
                    }
                    i3++;
                } else {
                    z = false;
                    break;
                }
            }
            if (z) {
                z2 = true;
                break;
            }
            i++;
        }
        if (z2 == this.f1029n0) {
            return;
        }
        if (z2) {
            mo1194a();
        } else {
            mo1217d();
        }
    }

    /* renamed from: c */
    public List<View> mo1211c(View view) {
        List orDefault = this.f1017b0.f9459b.getOrDefault(view, null);
        this.f1019d0.clear();
        if (orDefault != null) {
            this.f1019d0.addAll(orDefault);
        }
        return this.f1019d0;
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof C0177f) && super.checkLayoutParams(layoutParams);
    }

    /* renamed from: d */
    public C0177f mo1216d(View view) {
        C0177f fVar = (C0177f) view.getLayoutParams();
        if (!fVar.f1039b) {
            if (view instanceof C0173b) {
                C0174c behavior = ((C0173b) view).getBehavior();
                if (behavior == null) {
                    Log.e("CoordinatorLayout", "Attached behavior class is null");
                }
                C0174c cVar = fVar.f1038a;
                if (cVar != behavior) {
                    if (cVar != null) {
                        cVar.mo1276d();
                    }
                    fVar.f1038a = behavior;
                    fVar.f1039b = true;
                    if (behavior != null) {
                        behavior.mo1254a(fVar);
                    }
                }
            } else {
                C0175d dVar = null;
                for (Class cls = view.getClass(); cls != null; cls = cls.getSuperclass()) {
                    dVar = (C0175d) cls.getAnnotation(C0175d.class);
                    if (dVar != null) {
                        break;
                    }
                }
                if (dVar != null) {
                    try {
                        C0174c cVar2 = (C0174c) dVar.value().getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
                        C0174c cVar3 = fVar.f1038a;
                        if (cVar3 != cVar2) {
                            if (cVar3 != null) {
                                cVar3.mo1276d();
                            }
                            fVar.f1038a = cVar2;
                            fVar.f1039b = true;
                            if (cVar2 != null) {
                                cVar2.mo1254a(fVar);
                            }
                        }
                    } catch (Exception e) {
                        StringBuilder a = C0789gk.m5562a("Default behavior class ");
                        a.append(dVar.value().getName());
                        a.append(" could not be instantiated. Did you forget a default constructor?");
                        Log.e("CoordinatorLayout", a.toString(), e);
                    }
                }
            }
            fVar.f1039b = true;
        }
        return fVar;
    }

    /* renamed from: d */
    public void mo1217d() {
        if (this.f1024i0 && this.f1028m0 != null) {
            getViewTreeObserver().removeOnPreDrawListener(this.f1028m0);
        }
        this.f1029n0 = false;
    }

    /* renamed from: d */
    public final void mo1218d(View view, int i) {
        C0177f fVar = (C0177f) view.getLayoutParams();
        int i2 = fVar.f1046i;
        if (i2 != i) {
            C2189w7.m15005d(view, i - i2);
            fVar.f1046i = i;
        }
    }

    public boolean drawChild(Canvas canvas, View view, long j) {
        C0177f fVar = (C0177f) view.getLayoutParams();
        C0174c cVar = fVar.f1038a;
        if (cVar != null) {
            float b = cVar.mo1270b();
            if (b > 0.0f) {
                if (this.f1020e0 == null) {
                    this.f1020e0 = new Paint();
                }
                this.f1020e0.setColor(fVar.f1038a.mo1252a());
                Paint paint = this.f1020e0;
                int round = Math.round(b * 255.0f);
                if (round < 0) {
                    round = 0;
                } else if (round > 255) {
                    round = 255;
                }
                paint.setAlpha(round);
                int save = canvas.save();
                if (view.isOpaque()) {
                    canvas.clipRect((float) view.getLeft(), (float) view.getTop(), (float) view.getRight(), (float) view.getBottom(), Region.Op.DIFFERENCE);
                }
                canvas.drawRect((float) getPaddingLeft(), (float) getPaddingTop(), (float) (getWidth() - getPaddingRight()), (float) (getHeight() - getPaddingBottom()), this.f1020e0);
                canvas.restoreToCount(save);
            }
        }
        return super.drawChild(canvas, view, j);
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.f1032q0;
        boolean z = false;
        if (drawable != null && drawable.isStateful()) {
            z = false | drawable.setState(drawableState);
        }
        if (z) {
            invalidate();
        }
    }

    /* renamed from: e */
    public final void mo1221e() {
        if (Build.VERSION.SDK_INT >= 21) {
            if (C2189w7.m15015j(this)) {
                if (this.f1034s0 == null) {
                    this.f1034s0 = new C0172a();
                }
                C2189w7.m14994a((View) this, this.f1034s0);
                setSystemUiVisibility(1280);
                return;
            }
            C2189w7.m14994a((View) this, (C1746r7) null);
        }
    }

    /* renamed from: e */
    public final void mo1222e(View view, int i) {
        C0177f fVar = (C0177f) view.getLayoutParams();
        int i2 = fVar.f1047j;
        if (i2 != i) {
            C2189w7.m15007e(view, i - i2);
            fVar.f1047j = i;
        }
    }

    public C0177f generateDefaultLayoutParams() {
        return new C0177f(-2, -2);
    }

    public C0177f generateLayoutParams(AttributeSet attributeSet) {
        return new C0177f(getContext(), attributeSet);
    }

    public C0177f generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0177f ? new C0177f((C0177f) layoutParams) : layoutParams instanceof ViewGroup.MarginLayoutParams ? new C0177f((ViewGroup.MarginLayoutParams) layoutParams) : new C0177f(layoutParams);
    }

    public final List<View> getDependencySortedChildren() {
        mo1212c();
        return Collections.unmodifiableList(this.f1016a0);
    }

    public final C0592e8 getLastWindowInsets() {
        return this.f1030o0;
    }

    public int getNestedScrollAxes() {
        return this.f1035t0.mo10254a();
    }

    public Drawable getStatusBarBackground() {
        return this.f1032q0;
    }

    public int getSuggestedMinimumHeight() {
        return Math.max(super.getSuggestedMinimumHeight(), getPaddingBottom() + getPaddingTop());
    }

    public int getSuggestedMinimumWidth() {
        return Math.max(super.getSuggestedMinimumWidth(), getPaddingRight() + getPaddingLeft());
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        mo1203a(false);
        if (this.f1029n0) {
            if (this.f1028m0 == null) {
                this.f1028m0 = new C0178g();
            }
            getViewTreeObserver().addOnPreDrawListener(this.f1028m0);
        }
        if (this.f1030o0 == null && C2189w7.m15015j(this)) {
            C2189w7.m14973E(this);
        }
        this.f1024i0 = true;
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        mo1203a(false);
        if (this.f1029n0 && this.f1028m0 != null) {
            getViewTreeObserver().removeOnPreDrawListener(this.f1028m0);
        }
        View view = this.f1027l0;
        if (view != null) {
            onStopNestedScroll(view);
        }
        this.f1024i0 = false;
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f1031p0 && this.f1032q0 != null) {
            C0592e8 e8Var = this.f1030o0;
            int d = e8Var != null ? e8Var.mo5057d() : 0;
            if (d > 0) {
                this.f1032q0.setBounds(0, 0, getWidth(), d);
                this.f1032q0.draw(canvas);
            }
        }
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            mo1203a(true);
        }
        boolean a = mo1204a(motionEvent, 0);
        if (actionMasked == 1 || actionMasked == 3) {
            mo1203a(true);
        }
        return a;
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        C0174c cVar;
        int m = C2189w7.m15018m(this);
        int size = this.f1016a0.size();
        for (int i5 = 0; i5 < size; i5++) {
            View view = this.f1016a0.get(i5);
            if (view.getVisibility() != 8 && ((cVar = ((C0177f) view.getLayoutParams()).f1038a) == null || !cVar.mo203a(this, view, m))) {
                mo1213c(view, m);
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:45:0x0118, code lost:
        if (r0.mo1263a(r30, r20, r11, r21, r23, 0) == false) goto L_0x0127;
     */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x00c8  */
    /* JADX WARNING: Removed duplicated region for block: B:41:0x00f2  */
    /* JADX WARNING: Removed duplicated region for block: B:44:0x00fa  */
    /* JADX WARNING: Removed duplicated region for block: B:46:0x011b  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r31, int r32) {
        /*
            r30 = this;
            r7 = r30
            r30.mo1212c()
            r30.mo1207b()
            int r8 = r30.getPaddingLeft()
            int r0 = r30.getPaddingTop()
            int r9 = r30.getPaddingRight()
            int r1 = r30.getPaddingBottom()
            int r10 = p000.C2189w7.m15018m(r30)
            r2 = 1
            if (r10 != r2) goto L_0x0021
            r12 = 1
            goto L_0x0022
        L_0x0021:
            r12 = 0
        L_0x0022:
            int r13 = android.view.View.MeasureSpec.getMode(r31)
            int r14 = android.view.View.MeasureSpec.getSize(r31)
            int r15 = android.view.View.MeasureSpec.getMode(r32)
            int r16 = android.view.View.MeasureSpec.getSize(r32)
            int r17 = r8 + r9
            int r18 = r0 + r1
            int r0 = r30.getSuggestedMinimumWidth()
            int r1 = r30.getSuggestedMinimumHeight()
            e8 r3 = r7.f1030o0
            if (r3 == 0) goto L_0x004b
            boolean r3 = p000.C2189w7.m15015j(r30)
            if (r3 == 0) goto L_0x004b
            r19 = 1
            goto L_0x004d
        L_0x004b:
            r19 = 0
        L_0x004d:
            java.util.List<android.view.View> r2 = r7.f1016a0
            int r6 = r2.size()
            r2 = r0
            r4 = r1
            r3 = 0
            r5 = 0
        L_0x0057:
            if (r5 >= r6) goto L_0x016d
            java.util.List<android.view.View> r0 = r7.f1016a0
            java.lang.Object r0 = r0.get(r5)
            r20 = r0
            android.view.View r20 = (android.view.View) r20
            int r0 = r20.getVisibility()
            r1 = 8
            if (r0 != r1) goto L_0x0071
            r22 = r5
            r29 = r6
            goto L_0x0167
        L_0x0071:
            android.view.ViewGroup$LayoutParams r0 = r20.getLayoutParams()
            r1 = r0
            androidx.coordinatorlayout.widget.CoordinatorLayout$f r1 = (androidx.coordinatorlayout.widget.CoordinatorLayout.C0177f) r1
            int r0 = r1.f1042e
            if (r0 < 0) goto L_0x00bb
            if (r13 == 0) goto L_0x00bb
            int r0 = r7.mo1192a((int) r0)
            int r11 = r1.f1040c
            if (r11 != 0) goto L_0x0089
            r11 = 8388661(0x800035, float:1.1755018E-38)
        L_0x0089:
            int r11 = p000.C0815h0.m5770a((int) r11, (int) r10)
            r11 = r11 & 7
            r22 = r2
            r2 = 3
            if (r11 != r2) goto L_0x0096
            if (r12 == 0) goto L_0x009b
        L_0x0096:
            r2 = 5
            if (r11 != r2) goto L_0x00a7
            if (r12 == 0) goto L_0x00a7
        L_0x009b:
            int r2 = r14 - r9
            int r2 = r2 - r0
            r0 = 0
            int r2 = java.lang.Math.max(r0, r2)
            r21 = r2
            r11 = 0
            goto L_0x00c0
        L_0x00a7:
            if (r11 != r2) goto L_0x00ab
            if (r12 == 0) goto L_0x00b0
        L_0x00ab:
            r2 = 3
            if (r11 != r2) goto L_0x00b9
            if (r12 == 0) goto L_0x00b9
        L_0x00b0:
            int r0 = r0 - r8
            r11 = 0
            int r0 = java.lang.Math.max(r11, r0)
            r21 = r0
            goto L_0x00c0
        L_0x00b9:
            r11 = 0
            goto L_0x00be
        L_0x00bb:
            r22 = r2
            goto L_0x00b9
        L_0x00be:
            r21 = 0
        L_0x00c0:
            if (r19 == 0) goto L_0x00f2
            boolean r0 = p000.C2189w7.m15015j(r20)
            if (r0 != 0) goto L_0x00f2
            e8 r0 = r7.f1030o0
            int r0 = r0.mo5055b()
            e8 r2 = r7.f1030o0
            int r2 = r2.mo5056c()
            int r2 = r2 + r0
            e8 r0 = r7.f1030o0
            int r0 = r0.mo5057d()
            e8 r11 = r7.f1030o0
            int r11 = r11.mo5054a()
            int r11 = r11 + r0
            int r0 = r14 - r2
            int r0 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r13)
            int r2 = r16 - r11
            int r2 = android.view.View.MeasureSpec.makeMeasureSpec(r2, r15)
            r11 = r0
            r23 = r2
            goto L_0x00f6
        L_0x00f2:
            r11 = r31
            r23 = r32
        L_0x00f6:
            androidx.coordinatorlayout.widget.CoordinatorLayout$c r0 = r1.f1038a
            if (r0 == 0) goto L_0x011b
            r24 = 0
            r2 = r1
            r1 = r30
            r26 = r2
            r25 = r22
            r2 = r20
            r27 = r3
            r3 = r11
            r28 = r4
            r4 = r21
            r22 = r5
            r5 = r23
            r29 = r6
            r6 = r24
            boolean r0 = r0.mo1263a((androidx.coordinatorlayout.widget.CoordinatorLayout) r1, r2, (int) r3, (int) r4, (int) r5, (int) r6)
            if (r0 != 0) goto L_0x0134
            goto L_0x0127
        L_0x011b:
            r26 = r1
            r27 = r3
            r28 = r4
            r29 = r6
            r25 = r22
            r22 = r5
        L_0x0127:
            r5 = 0
            r0 = r30
            r1 = r20
            r2 = r11
            r3 = r21
            r4 = r23
            r0.mo1197a((android.view.View) r1, (int) r2, (int) r3, (int) r4, (int) r5)
        L_0x0134:
            int r0 = r20.getMeasuredWidth()
            int r0 = r0 + r17
            r1 = r26
            int r2 = r1.leftMargin
            int r0 = r0 + r2
            int r2 = r1.rightMargin
            int r0 = r0 + r2
            r2 = r25
            int r0 = java.lang.Math.max(r2, r0)
            int r2 = r20.getMeasuredHeight()
            int r2 = r2 + r18
            int r3 = r1.topMargin
            int r2 = r2 + r3
            int r1 = r1.bottomMargin
            int r2 = r2 + r1
            r1 = r28
            int r1 = java.lang.Math.max(r1, r2)
            int r2 = r20.getMeasuredState()
            r11 = r27
            int r2 = android.view.View.combineMeasuredStates(r11, r2)
            r4 = r1
            r3 = r2
            r2 = r0
        L_0x0167:
            int r5 = r22 + 1
            r6 = r29
            goto L_0x0057
        L_0x016d:
            r11 = r3
            r1 = r4
            r0 = -16777216(0xffffffffff000000, float:-1.7014118E38)
            r0 = r0 & r11
            r3 = r31
            int r0 = android.view.View.resolveSizeAndState(r2, r3, r0)
            int r2 = r11 << 16
            r3 = r32
            int r1 = android.view.View.resolveSizeAndState(r1, r3, r2)
            r7.setMeasuredDimension(r0, r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.onMeasure(int, int):void");
    }

    public boolean onNestedFling(View view, float f, float f2, boolean z) {
        C0174c cVar;
        int childCount = getChildCount();
        boolean z2 = false;
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() != 8) {
                C0177f fVar = (C0177f) childAt.getLayoutParams();
                if (fVar.mo1285a(0) && (cVar = fVar.f1038a) != null) {
                    z2 |= cVar.mo1277e();
                }
            }
        }
        if (z2) {
            mo1208b(1);
        }
        return z2;
    }

    public boolean onNestedPreFling(View view, float f, float f2) {
        C0174c cVar;
        int childCount = getChildCount();
        boolean z = false;
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() != 8) {
                C0177f fVar = (C0177f) childAt.getLayoutParams();
                if (fVar.mo1285a(0) && (cVar = fVar.f1038a) != null) {
                    z |= cVar.mo1268a(this, childAt, view, f, f2);
                }
            }
        }
        return z;
    }

    public void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
        mo804a(view, i, i2, iArr, 0);
    }

    public void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        mo802a(view, i, i2, i3, i4, 0);
    }

    public void onNestedScrollAccepted(View view, View view2, int i) {
        mo805a(view, view2, i, 0);
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        Parcelable parcelable2;
        if (!(parcelable instanceof C0179h)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        C0179h hVar = (C0179h) parcelable;
        super.onRestoreInstanceState(hVar.f14707X);
        SparseArray<Parcelable> sparseArray = hVar.f1056Z;
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            int id = childAt.getId();
            C0174c cVar = mo1216d(childAt).f1038a;
            if (!(id == -1 || cVar == null || (parcelable2 = sparseArray.get(id)) == null)) {
                cVar.mo1255a(this, childAt, parcelable2);
            }
        }
    }

    public Parcelable onSaveInstanceState() {
        Parcelable b;
        C0179h hVar = new C0179h(super.onSaveInstanceState());
        SparseArray<Parcelable> sparseArray = new SparseArray<>();
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            int id = childAt.getId();
            C0174c cVar = ((C0177f) childAt.getLayoutParams()).f1038a;
            if (!(id == -1 || cVar == null || (b = cVar.mo1271b(this, childAt)) == null)) {
                sparseArray.append(id, b);
            }
        }
        hVar.f1056Z = sparseArray;
        return hVar;
    }

    public boolean onStartNestedScroll(View view, View view2, int i) {
        return mo810b(view, view2, i, 0);
    }

    public void onStopNestedScroll(View view) {
        mo801a(view, 0);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:3:0x0012, code lost:
        if (r3 != false) goto L_0x0016;
     */
    /* JADX WARNING: Removed duplicated region for block: B:11:0x002f  */
    /* JADX WARNING: Removed duplicated region for block: B:12:0x0035  */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x004a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r18) {
        /*
            r17 = this;
            r0 = r17
            r1 = r18
            int r2 = r18.getActionMasked()
            android.view.View r3 = r0.f1026k0
            r4 = 1
            r5 = 0
            if (r3 != 0) goto L_0x0015
            boolean r3 = r0.mo1204a((android.view.MotionEvent) r1, (int) r4)
            if (r3 == 0) goto L_0x0029
            goto L_0x0016
        L_0x0015:
            r3 = 0
        L_0x0016:
            android.view.View r6 = r0.f1026k0
            android.view.ViewGroup$LayoutParams r6 = r6.getLayoutParams()
            androidx.coordinatorlayout.widget.CoordinatorLayout$f r6 = (androidx.coordinatorlayout.widget.CoordinatorLayout.C0177f) r6
            androidx.coordinatorlayout.widget.CoordinatorLayout$c r6 = r6.f1038a
            if (r6 == 0) goto L_0x0029
            android.view.View r7 = r0.f1026k0
            boolean r6 = r6.mo1272b((androidx.coordinatorlayout.widget.CoordinatorLayout) r0, r7, (android.view.MotionEvent) r1)
            goto L_0x002a
        L_0x0029:
            r6 = 0
        L_0x002a:
            android.view.View r7 = r0.f1026k0
            r8 = 0
            if (r7 != 0) goto L_0x0035
            boolean r1 = super.onTouchEvent(r18)
            r6 = r6 | r1
            goto L_0x0048
        L_0x0035:
            if (r3 == 0) goto L_0x0048
            long r11 = android.os.SystemClock.uptimeMillis()
            r13 = 3
            r14 = 0
            r15 = 0
            r16 = 0
            r9 = r11
            android.view.MotionEvent r8 = android.view.MotionEvent.obtain(r9, r11, r13, r14, r15, r16)
            super.onTouchEvent(r8)
        L_0x0048:
            if (r8 == 0) goto L_0x004d
            r8.recycle()
        L_0x004d:
            if (r2 == r4) goto L_0x0052
            r1 = 3
            if (r2 != r1) goto L_0x0055
        L_0x0052:
            r0.mo1203a((boolean) r5)
        L_0x0055:
            return r6
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.onTouchEvent(android.view.MotionEvent):boolean");
    }

    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        C0174c cVar = ((C0177f) view.getLayoutParams()).f1038a;
        if (cVar == null || !cVar.mo1265a(this, view, rect, z)) {
            return super.requestChildRectangleOnScreen(view, rect, z);
        }
        return true;
    }

    public void requestDisallowInterceptTouchEvent(boolean z) {
        super.requestDisallowInterceptTouchEvent(z);
        if (z && !this.f1023h0) {
            mo1203a(false);
            this.f1023h0 = true;
        }
    }

    public void setFitsSystemWindows(boolean z) {
        super.setFitsSystemWindows(z);
        mo1221e();
    }

    public void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener) {
        this.f1033r0 = onHierarchyChangeListener;
    }

    public void setStatusBarBackground(Drawable drawable) {
        Drawable drawable2 = this.f1032q0;
        if (drawable2 != drawable) {
            Drawable drawable3 = null;
            if (drawable2 != null) {
                drawable2.setCallback((Drawable.Callback) null);
            }
            if (drawable != null) {
                drawable3 = drawable.mutate();
            }
            this.f1032q0 = drawable3;
            Drawable drawable4 = this.f1032q0;
            if (drawable4 != null) {
                if (drawable4.isStateful()) {
                    this.f1032q0.setState(getDrawableState());
                }
                C0815h0.m5824a(this.f1032q0, C2189w7.m15018m(this));
                this.f1032q0.setVisible(getVisibility() == 0, false);
                this.f1032q0.setCallback(this);
            }
            C2189w7.m14972D(this);
        }
    }

    public void setStatusBarBackgroundColor(int i) {
        setStatusBarBackground(new ColorDrawable(i));
    }

    public void setStatusBarBackgroundResource(int i) {
        setStatusBarBackground(i != 0 ? C2085v5.m14462c(getContext(), i) : null);
    }

    public void setVisibility(int i) {
        super.setVisibility(i);
        boolean z = i == 0;
        Drawable drawable = this.f1032q0;
        if (drawable != null && drawable.isVisible() != z) {
            this.f1032q0.setVisible(z, false);
        }
    }

    public boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f1032q0;
    }

    /* renamed from: c */
    public void mo1213c(View view, int i) {
        C0177f fVar = (C0177f) view.getLayoutParams();
        int i2 = 0;
        if (!(fVar.f1048k == null && fVar.f1043f != -1)) {
            View view2 = fVar.f1048k;
            if (view2 != null) {
                Rect f = m807f();
                Rect f2 = m807f();
                try {
                    mo1199a(view2, f);
                    mo1198a(view, i, f, f2);
                    view.layout(f2.left, f2.top, f2.right, f2.bottom);
                    m804a(f);
                    f2.setEmpty();
                    f1015y0.mo5049a(f2);
                } catch (Throwable th) {
                    m804a(f);
                    m804a(f2);
                    throw th;
                }
            } else {
                int i3 = fVar.f1042e;
                if (i3 >= 0) {
                    C0177f fVar2 = (C0177f) view.getLayoutParams();
                    int a = C0815h0.m5770a(m806d(fVar2.f1040c), i);
                    int i4 = a & 7;
                    int i5 = a & 112;
                    int width = getWidth();
                    int height = getHeight();
                    int measuredWidth = view.getMeasuredWidth();
                    int measuredHeight = view.getMeasuredHeight();
                    if (i == 1) {
                        i3 = width - i3;
                    }
                    int a2 = mo1192a(i3) - measuredWidth;
                    if (i4 == 1) {
                        a2 += measuredWidth / 2;
                    } else if (i4 == 5) {
                        a2 += measuredWidth;
                    }
                    if (i5 == 16) {
                        i2 = 0 + (measuredHeight / 2);
                    } else if (i5 == 80) {
                        i2 = measuredHeight + 0;
                    }
                    int max = Math.max(getPaddingLeft() + fVar2.leftMargin, Math.min(a2, ((width - getPaddingRight()) - measuredWidth) - fVar2.rightMargin));
                    int max2 = Math.max(getPaddingTop() + fVar2.topMargin, Math.min(i2, ((height - getPaddingBottom()) - measuredHeight) - fVar2.bottomMargin));
                    view.layout(max, max2, measuredWidth + max, measuredHeight + max2);
                    return;
                }
                C0177f fVar3 = (C0177f) view.getLayoutParams();
                Rect f3 = m807f();
                f3.set(getPaddingLeft() + fVar3.leftMargin, getPaddingTop() + fVar3.topMargin, (getWidth() - getPaddingRight()) - fVar3.rightMargin, (getHeight() - getPaddingBottom()) - fVar3.bottomMargin);
                if (this.f1030o0 != null && C2189w7.m15015j(this) && !C2189w7.m15015j(view)) {
                    f3.left = this.f1030o0.mo5055b() + f3.left;
                    f3.top = this.f1030o0.mo5057d() + f3.top;
                    f3.right -= this.f1030o0.mo5056c();
                    f3.bottom -= this.f1030o0.mo5054a();
                }
                Rect f4 = m807f();
                C0815h0.m5797a(m805c(fVar3.f1040c), view.getMeasuredWidth(), view.getMeasuredHeight(), f3, f4, i);
                view.layout(f4.left, f4.top, f4.right, f4.bottom);
                f3.setEmpty();
                f1015y0.mo5049a(f3);
                f4.setEmpty();
                f1015y0.mo5049a(f4);
            }
        } else {
            throw new IllegalStateException("An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete.");
        }
    }

    /* renamed from: b */
    public List<View> mo1206b(View view) {
        C1220l5<View> l5Var = this.f1017b0;
        int i = l5Var.f9459b.f5965Z;
        ArrayList arrayList = null;
        for (int i2 = 0; i2 < i; i2++) {
            ArrayList e = l5Var.f9459b.mo5982e(i2);
            if (e != null && e.contains(view)) {
                if (arrayList == null) {
                    arrayList = new ArrayList();
                }
                arrayList.add(l5Var.f9459b.mo5977c(i2));
            }
        }
        this.f1019d0.clear();
        if (arrayList != null) {
            this.f1019d0.addAll(arrayList);
        }
        return this.f1019d0;
    }

    /* renamed from: a */
    public boolean mo1205a(View view, int i, int i2) {
        Rect f = m807f();
        mo1199a(view, f);
        try {
            boolean contains = f.contains(i, i2);
            f.setEmpty();
            f1015y0.mo5049a(f);
            return contains;
        } catch (Throwable th) {
            m804a(f);
            throw th;
        }
    }

    /* renamed from: a */
    public void mo804a(View view, int i, int i2, int[] iArr, int i3) {
        C0174c cVar;
        int childCount = getChildCount();
        boolean z = false;
        int i4 = 0;
        int i5 = 0;
        for (int i6 = 0; i6 < childCount; i6++) {
            View childAt = getChildAt(i6);
            if (childAt.getVisibility() == 8) {
                int i7 = i3;
            } else {
                C0177f fVar = (C0177f) childAt.getLayoutParams();
                if (fVar.mo1285a(i3) && (cVar = fVar.f1038a) != null) {
                    int[] iArr2 = this.f1021f0;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    cVar.mo1260a(this, childAt, view, i, i2, iArr2, i3);
                    int[] iArr3 = this.f1021f0;
                    int max = i > 0 ? Math.max(i4, iArr3[0]) : Math.min(i4, iArr3[0]);
                    int[] iArr4 = this.f1021f0;
                    i4 = max;
                    i5 = i2 > 0 ? Math.max(i5, iArr4[1]) : Math.min(i5, iArr4[1]);
                    z = true;
                }
            }
        }
        iArr[0] = i4;
        iArr[1] = i5;
        if (z) {
            mo1208b(1);
        }
    }

    /* renamed from: b */
    public void mo1210b(View view, Rect rect) {
        rect.set(((C0177f) view.getLayoutParams()).f1054q);
    }

    /* renamed from: a */
    public void mo803a(View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
        C0174c cVar;
        int childCount = getChildCount();
        boolean z = false;
        int i6 = 0;
        int i7 = 0;
        for (int i8 = 0; i8 < childCount; i8++) {
            View childAt = getChildAt(i8);
            if (childAt.getVisibility() != 8) {
                C0177f fVar = (C0177f) childAt.getLayoutParams();
                if (fVar.mo1285a(i5) && (cVar = fVar.f1038a) != null) {
                    int[] iArr2 = this.f1021f0;
                    iArr2[0] = 0;
                    iArr2[1] = 0;
                    cVar.mo1259a(this, childAt, view, i, i2, i3, i4, i5, iArr2);
                    int[] iArr3 = this.f1021f0;
                    i6 = i3 > 0 ? Math.max(i6, iArr3[0]) : Math.min(i6, iArr3[0]);
                    i7 = i4 > 0 ? Math.max(i7, this.f1021f0[1]) : Math.min(i7, this.f1021f0[1]);
                    z = true;
                }
            }
        }
        iArr[0] = iArr[0] + i6;
        iArr[1] = iArr[1] + i7;
        if (z) {
            mo1208b(1);
        }
    }

    /* renamed from: b */
    public void mo1209b(View view, int i) {
        C0174c cVar;
        View view2 = view;
        C0177f fVar = (C0177f) view.getLayoutParams();
        if (fVar.f1048k != null) {
            Rect f = m807f();
            Rect f2 = m807f();
            Rect f3 = m807f();
            mo1199a(fVar.f1048k, f);
            boolean z = false;
            mo1200a(view2, false, f2);
            int measuredWidth = view.getMeasuredWidth();
            int measuredHeight = view.getMeasuredHeight();
            mo1195a(i, f, f3, fVar, measuredWidth, measuredHeight);
            if (!(f3.left == f2.left && f3.top == f2.top)) {
                z = true;
            }
            mo1201a(fVar, f3, measuredWidth, measuredHeight);
            int i2 = f3.left - f2.left;
            int i3 = f3.top - f2.top;
            if (i2 != 0) {
                C2189w7.m15005d(view2, i2);
            }
            if (i3 != 0) {
                C2189w7.m15007e(view2, i3);
            }
            if (z && (cVar = fVar.f1038a) != null) {
                cVar.mo1273b(this, view2, fVar.f1048k);
            }
            m804a(f);
            f2.setEmpty();
            f1015y0.mo5049a(f2);
            f3.setEmpty();
            f1015y0.mo5049a(f3);
        }
    }

    /* renamed from: a */
    public void mo805a(View view, View view2, int i, int i2) {
        C0174c cVar;
        C1674q7 q7Var = this.f1035t0;
        if (i2 == 1) {
            q7Var.f12903b = i;
        } else {
            q7Var.f12902a = i;
        }
        this.f1027l0 = view2;
        int childCount = getChildCount();
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            C0177f fVar = (C0177f) childAt.getLayoutParams();
            if (fVar.mo1285a(i2) && (cVar = fVar.f1038a) != null) {
                cVar.mo1261a(this, childAt, view, view2, i, i2);
            }
        }
    }

    /* renamed from: b */
    public final void mo1208b(int i) {
        int i2;
        int i3;
        boolean z;
        boolean z2;
        boolean z3;
        int width;
        int i4;
        int i5;
        int i6;
        int height;
        int i7;
        int i8;
        int i9;
        int i10 = i;
        int m = C2189w7.m15018m(this);
        int size = this.f1016a0.size();
        Rect f = m807f();
        Rect f2 = m807f();
        Rect f3 = m807f();
        int i11 = 0;
        while (i11 < size) {
            View view = this.f1016a0.get(i11);
            C0177f fVar = (C0177f) view.getLayoutParams();
            if (i10 == 0 && view.getVisibility() == 8) {
                i2 = size;
            } else {
                for (int i12 = 0; i12 < i11; i12++) {
                    if (fVar.f1049l == this.f1016a0.get(i12)) {
                        mo1209b(view, m);
                    }
                }
                mo1200a(view, true, f2);
                if (fVar.f1044g != 0 && !f2.isEmpty()) {
                    int a = C0815h0.m5770a(fVar.f1044g, m);
                    int i13 = a & 112;
                    if (i13 == 48) {
                        f.top = Math.max(f.top, f2.bottom);
                    } else if (i13 == 80) {
                        f.bottom = Math.max(f.bottom, getHeight() - f2.top);
                    }
                    int i14 = a & 7;
                    if (i14 == 3) {
                        f.left = Math.max(f.left, f2.right);
                    } else if (i14 == 5) {
                        f.right = Math.max(f.right, getWidth() - f2.left);
                    }
                }
                if (fVar.f1045h == 0 || view.getVisibility() != 0 || !C2189w7.m15031z(view) || view.getWidth() <= 0 || view.getHeight() <= 0) {
                    i3 = size;
                } else {
                    C0177f fVar2 = (C0177f) view.getLayoutParams();
                    C0174c cVar = fVar2.f1038a;
                    Rect f4 = m807f();
                    Rect f5 = m807f();
                    i3 = size;
                    f5.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
                    if (cVar == null || !cVar.mo1264a(this, view, f4)) {
                        f4.set(f5);
                    } else if (!f5.contains(f4)) {
                        StringBuilder a2 = C0789gk.m5562a("Rect should be within the child's bounds. Rect:");
                        a2.append(f4.toShortString());
                        a2.append(" | Bounds:");
                        a2.append(f5.toShortString());
                        throw new IllegalArgumentException(a2.toString());
                    }
                    f5.setEmpty();
                    f1015y0.mo5049a(f5);
                    if (!f4.isEmpty()) {
                        int a3 = C0815h0.m5770a(fVar2.f1045h, m);
                        if ((a3 & 48) != 48 || (i8 = (f4.top - fVar2.topMargin) - fVar2.f1047j) >= (i9 = f.top)) {
                            z2 = false;
                        } else {
                            mo1222e(view, i9 - i8);
                            z2 = true;
                        }
                        if ((a3 & 80) == 80 && (height = ((getHeight() - f4.bottom) - fVar2.bottomMargin) + fVar2.f1047j) < (i7 = f.bottom)) {
                            mo1222e(view, height - i7);
                            z2 = true;
                        }
                        if (!z2) {
                            mo1222e(view, 0);
                        }
                        if ((a3 & 3) != 3 || (i5 = (f4.left - fVar2.leftMargin) - fVar2.f1046i) >= (i6 = f.left)) {
                            z3 = false;
                        } else {
                            mo1218d(view, i6 - i5);
                            z3 = true;
                        }
                        if ((a3 & 5) == 5 && (width = ((getWidth() - f4.right) - fVar2.rightMargin) + fVar2.f1046i) < (i4 = f.right)) {
                            mo1218d(view, width - i4);
                            z3 = true;
                        }
                        if (!z3) {
                            mo1218d(view, 0);
                        }
                    }
                    f4.setEmpty();
                    f1015y0.mo5049a(f4);
                }
                if (i10 != 2) {
                    mo1210b(view, f3);
                    if (f3.equals(f2)) {
                        i2 = i3;
                    } else {
                        mo1214c(view, f2);
                    }
                }
                i2 = i3;
                for (int i15 = i11 + 1; i15 < i2; i15++) {
                    View view2 = this.f1016a0.get(i15);
                    C0177f fVar3 = (C0177f) view2.getLayoutParams();
                    C0174c cVar2 = fVar3.f1038a;
                    if (cVar2 != null && cVar2.mo1267a(this, view2, view)) {
                        if (i10 != 0 || !fVar3.f1053p) {
                            if (i10 != 2) {
                                z = cVar2.mo1273b(this, view2, view);
                            } else {
                                cVar2.mo1275c();
                                z = true;
                            }
                            if (i10 == 1) {
                                fVar3.f1053p = z;
                            }
                        } else {
                            fVar3.f1053p = false;
                        }
                    }
                }
            }
            i11++;
            size = i2;
        }
        m804a(f);
        m804a(f2);
        m804a(f3);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:26:0x0073, code lost:
        if (r5 != false) goto L_0x00c4;
     */
    /* JADX WARNING: Removed duplicated region for block: B:124:0x0164 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:70:0x010a  */
    /* renamed from: c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo1212c() {
        /*
            r11 = this;
            java.util.List<android.view.View> r0 = r11.f1016a0
            r0.clear()
            l5<android.view.View> r0 = r11.f1017b0
            g5<T, java.util.ArrayList<T>> r1 = r0.f9459b
            int r1 = r1.f5965Z
            r2 = 0
            r3 = 0
        L_0x000d:
            if (r3 >= r1) goto L_0x0024
            g5<T, java.util.ArrayList<T>> r4 = r0.f9459b
            java.lang.Object r4 = r4.mo5982e(r3)
            java.util.ArrayList r4 = (java.util.ArrayList) r4
            if (r4 == 0) goto L_0x0021
            r4.clear()
            e7<java.util.ArrayList<T>> r5 = r0.f9458a
            r5.mo5049a(r4)
        L_0x0021:
            int r3 = r3 + 1
            goto L_0x000d
        L_0x0024:
            g5<T, java.util.ArrayList<T>> r0 = r0.f9459b
            r0.clear()
            int r0 = r11.getChildCount()
            r1 = 0
        L_0x002e:
            if (r1 >= r0) goto L_0x0191
            android.view.View r3 = r11.getChildAt(r1)
            androidx.coordinatorlayout.widget.CoordinatorLayout$f r4 = r11.mo1216d((android.view.View) r3)
            int r5 = r4.f1043f
            r6 = -1
            r7 = 0
            if (r5 != r6) goto L_0x0044
            r4.f1049l = r7
            r4.f1048k = r7
            goto L_0x00c6
        L_0x0044:
            android.view.View r5 = r4.f1048k
            if (r5 == 0) goto L_0x0075
            int r5 = r5.getId()
            int r6 = r4.f1043f
            if (r5 == r6) goto L_0x0051
            goto L_0x006e
        L_0x0051:
            android.view.View r5 = r4.f1048k
            android.view.ViewParent r6 = r5.getParent()
        L_0x0057:
            if (r6 == r11) goto L_0x0070
            if (r6 == 0) goto L_0x006a
            if (r6 != r3) goto L_0x005e
            goto L_0x006a
        L_0x005e:
            boolean r8 = r6 instanceof android.view.View
            if (r8 == 0) goto L_0x0065
            r5 = r6
            android.view.View r5 = (android.view.View) r5
        L_0x0065:
            android.view.ViewParent r6 = r6.getParent()
            goto L_0x0057
        L_0x006a:
            r4.f1049l = r7
            r4.f1048k = r7
        L_0x006e:
            r5 = 0
            goto L_0x0073
        L_0x0070:
            r4.f1049l = r5
            r5 = 1
        L_0x0073:
            if (r5 != 0) goto L_0x00c4
        L_0x0075:
            int r5 = r4.f1043f
            android.view.View r5 = r11.findViewById(r5)
            r4.f1048k = r5
            android.view.View r5 = r4.f1048k
            if (r5 == 0) goto L_0x00ba
            if (r5 != r11) goto L_0x0092
            boolean r5 = r11.isInEditMode()
            if (r5 == 0) goto L_0x008a
            goto L_0x00c0
        L_0x008a:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "View can not be anchored to the the parent CoordinatorLayout"
            r0.<init>(r1)
            throw r0
        L_0x0092:
            android.view.ViewParent r6 = r5.getParent()
        L_0x0096:
            if (r6 == r11) goto L_0x00b7
            if (r6 == 0) goto L_0x00b7
            if (r6 != r3) goto L_0x00ab
            boolean r5 = r11.isInEditMode()
            if (r5 == 0) goto L_0x00a3
            goto L_0x00c0
        L_0x00a3:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "Anchor must not be a descendant of the anchored view"
            r0.<init>(r1)
            throw r0
        L_0x00ab:
            boolean r8 = r6 instanceof android.view.View
            if (r8 == 0) goto L_0x00b2
            r5 = r6
            android.view.View r5 = (android.view.View) r5
        L_0x00b2:
            android.view.ViewParent r6 = r6.getParent()
            goto L_0x0096
        L_0x00b7:
            r4.f1049l = r5
            goto L_0x00c4
        L_0x00ba:
            boolean r5 = r11.isInEditMode()
            if (r5 == 0) goto L_0x016c
        L_0x00c0:
            r4.f1049l = r7
            r4.f1048k = r7
        L_0x00c4:
            android.view.View r5 = r4.f1048k
        L_0x00c6:
            l5<android.view.View> r5 = r11.f1017b0
            r5.mo8292a(r3)
            r5 = 0
        L_0x00cc:
            if (r5 >= r0) goto L_0x0168
            if (r5 != r1) goto L_0x00d2
            goto L_0x0164
        L_0x00d2:
            android.view.View r6 = r11.getChildAt(r5)
            android.view.View r8 = r4.f1049l
            if (r6 == r8) goto L_0x0107
            int r8 = p000.C2189w7.m15018m(r11)
            android.view.ViewGroup$LayoutParams r9 = r6.getLayoutParams()
            androidx.coordinatorlayout.widget.CoordinatorLayout$f r9 = (androidx.coordinatorlayout.widget.CoordinatorLayout.C0177f) r9
            int r9 = r9.f1044g
            int r9 = p000.C0815h0.m5770a((int) r9, (int) r8)
            if (r9 == 0) goto L_0x00f7
            int r10 = r4.f1045h
            int r8 = p000.C0815h0.m5770a((int) r10, (int) r8)
            r8 = r8 & r9
            if (r8 != r9) goto L_0x00f7
            r8 = 1
            goto L_0x00f8
        L_0x00f7:
            r8 = 0
        L_0x00f8:
            if (r8 != 0) goto L_0x0107
            androidx.coordinatorlayout.widget.CoordinatorLayout$c r8 = r4.f1038a
            if (r8 == 0) goto L_0x0105
            boolean r8 = r8.mo1267a((androidx.coordinatorlayout.widget.CoordinatorLayout) r11, r3, (android.view.View) r6)
            if (r8 == 0) goto L_0x0105
            goto L_0x0107
        L_0x0105:
            r8 = 0
            goto L_0x0108
        L_0x0107:
            r8 = 1
        L_0x0108:
            if (r8 == 0) goto L_0x0164
            l5<android.view.View> r8 = r11.f1017b0
            g5<T, java.util.ArrayList<T>> r8 = r8.f9459b
            int r8 = r8.mo5971a((java.lang.Object) r6)
            if (r8 < 0) goto L_0x0116
            r8 = 1
            goto L_0x0117
        L_0x0116:
            r8 = 0
        L_0x0117:
            if (r8 != 0) goto L_0x011e
            l5<android.view.View> r8 = r11.f1017b0
            r8.mo8292a(r6)
        L_0x011e:
            l5<android.view.View> r8 = r11.f1017b0
            g5<T, java.util.ArrayList<T>> r9 = r8.f9459b
            int r9 = r9.mo5971a((java.lang.Object) r6)
            if (r9 < 0) goto L_0x012a
            r9 = 1
            goto L_0x012b
        L_0x012a:
            r9 = 0
        L_0x012b:
            if (r9 == 0) goto L_0x015c
            g5<T, java.util.ArrayList<T>> r9 = r8.f9459b
            int r9 = r9.mo5971a((java.lang.Object) r3)
            if (r9 < 0) goto L_0x0137
            r9 = 1
            goto L_0x0138
        L_0x0137:
            r9 = 0
        L_0x0138:
            if (r9 == 0) goto L_0x015c
            g5<T, java.util.ArrayList<T>> r9 = r8.f9459b
            java.lang.Object r9 = r9.getOrDefault(r6, r7)
            java.util.ArrayList r9 = (java.util.ArrayList) r9
            if (r9 != 0) goto L_0x0158
            e7<java.util.ArrayList<T>> r9 = r8.f9458a
            java.lang.Object r9 = r9.mo5048a()
            java.util.ArrayList r9 = (java.util.ArrayList) r9
            if (r9 != 0) goto L_0x0153
            java.util.ArrayList r9 = new java.util.ArrayList
            r9.<init>()
        L_0x0153:
            g5<T, java.util.ArrayList<T>> r8 = r8.f9459b
            r8.put(r6, r9)
        L_0x0158:
            r9.add(r3)
            goto L_0x0164
        L_0x015c:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.String r1 = "All nodes must be present in the graph before being added as an edge"
            r0.<init>(r1)
            throw r0
        L_0x0164:
            int r5 = r5 + 1
            goto L_0x00cc
        L_0x0168:
            int r1 = r1 + 1
            goto L_0x002e
        L_0x016c:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "Could not find CoordinatorLayout descendant view with id "
            java.lang.StringBuilder r1 = p000.C0789gk.m5562a((java.lang.String) r1)
            android.content.res.Resources r2 = r11.getResources()
            int r4 = r4.f1043f
            java.lang.String r2 = r2.getResourceName(r4)
            r1.append(r2)
            java.lang.String r2 = " to anchor view "
            r1.append(r2)
            r1.append(r3)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x0191:
            java.util.List<android.view.View> r0 = r11.f1016a0
            l5<android.view.View> r1 = r11.f1017b0
            java.util.ArrayList<T> r3 = r1.f9460c
            r3.clear()
            java.util.HashSet<T> r3 = r1.f9461d
            r3.clear()
            g5<T, java.util.ArrayList<T>> r3 = r1.f9459b
            int r3 = r3.f5965Z
        L_0x01a3:
            if (r2 >= r3) goto L_0x01b5
            g5<T, java.util.ArrayList<T>> r4 = r1.f9459b
            java.lang.Object r4 = r4.mo5977c(r2)
            java.util.ArrayList<T> r5 = r1.f9460c
            java.util.HashSet<T> r6 = r1.f9461d
            r1.mo8293a(r4, r5, r6)
            int r2 = r2 + 1
            goto L_0x01a3
        L_0x01b5:
            java.util.ArrayList<T> r1 = r1.f9460c
            r0.addAll(r1)
            java.util.List<android.view.View> r0 = r11.f1016a0
            java.util.Collections.reverse(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.coordinatorlayout.widget.CoordinatorLayout.mo1212c():void");
    }

    /* renamed from: a */
    public void mo801a(View view, int i) {
        C1674q7 q7Var = this.f1035t0;
        if (i == 1) {
            q7Var.f12903b = 0;
        } else {
            q7Var.f12902a = 0;
        }
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            C0177f fVar = (C0177f) childAt.getLayoutParams();
            if (fVar.mo1285a(i)) {
                C0174c cVar = fVar.f1038a;
                if (cVar != null) {
                    cVar.mo1256a(this, childAt, view, i);
                }
                fVar.mo1284a(i, false);
                fVar.f1053p = false;
            }
        }
        this.f1027l0 = null;
    }

    /* renamed from: a */
    public final boolean mo1204a(MotionEvent motionEvent, int i) {
        boolean z;
        MotionEvent motionEvent2 = motionEvent;
        int i2 = i;
        int actionMasked = motionEvent.getActionMasked();
        List<View> list = this.f1018c0;
        mo1202a(list);
        int size = list.size();
        MotionEvent motionEvent3 = null;
        boolean z2 = false;
        boolean z3 = false;
        for (int i3 = 0; i3 < size; i3++) {
            View view = list.get(i3);
            C0177f fVar = (C0177f) view.getLayoutParams();
            C0174c cVar = fVar.f1038a;
            boolean z4 = true;
            if ((!z2 && !z3) || actionMasked == 0) {
                if (!z2 && cVar != null) {
                    if (i2 == 0) {
                        z2 = cVar.mo1266a(this, view, motionEvent2);
                    } else if (i2 == 1) {
                        z2 = cVar.mo1272b(this, view, motionEvent2);
                    }
                    if (z2) {
                        this.f1026k0 = view;
                    }
                }
                if (fVar.f1038a == null) {
                    fVar.f1050m = false;
                }
                boolean z5 = fVar.f1050m;
                if (z5) {
                    z = true;
                } else {
                    C0174c cVar2 = fVar.f1038a;
                    z = (cVar2 != null ? cVar2.mo1262a(this, view) : false) | z5;
                    fVar.f1050m = z;
                }
                if (!z || z5) {
                    z4 = false;
                }
                if (z && !z4) {
                    break;
                }
                z3 = z4;
            } else if (cVar != null) {
                if (motionEvent3 == null) {
                    long uptimeMillis = SystemClock.uptimeMillis();
                    motionEvent3 = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                }
                if (i2 == 0) {
                    cVar.mo1266a(this, view, motionEvent3);
                } else if (i2 == 1) {
                    cVar.mo1272b(this, view, motionEvent3);
                }
            }
        }
        list.clear();
        return z2;
    }

    /* renamed from: a */
    public final void mo1203a(boolean z) {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            C0174c cVar = ((C0177f) childAt.getLayoutParams()).f1038a;
            if (cVar != null) {
                long uptimeMillis = SystemClock.uptimeMillis();
                MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                if (z) {
                    cVar.mo1266a(this, childAt, obtain);
                } else {
                    cVar.mo1272b(this, childAt, obtain);
                }
                obtain.recycle();
            }
        }
        for (int i2 = 0; i2 < childCount; i2++) {
            ((C0177f) getChildAt(i2).getLayoutParams()).f1050m = false;
        }
        this.f1026k0 = null;
        this.f1023h0 = false;
    }

    /* renamed from: b */
    public boolean mo810b(View view, View view2, int i, int i2) {
        int i3 = i2;
        int childCount = getChildCount();
        int i4 = 0;
        boolean z = false;
        while (true) {
            if (i4 >= childCount) {
                return z;
            }
            View childAt = getChildAt(i4);
            if (childAt.getVisibility() != 8) {
                C0177f fVar = (C0177f) childAt.getLayoutParams();
                C0174c cVar = fVar.f1038a;
                if (cVar != null) {
                    boolean b = cVar.mo1274b(this, childAt, view, view2, i, i2);
                    fVar.mo1284a(i3, b);
                    z |= b;
                } else {
                    fVar.mo1284a(i3, false);
                }
            }
            i4++;
        }
    }

    /* renamed from: a */
    public final C0592e8 mo1193a(C0592e8 e8Var) {
        C0174c cVar;
        if (!C0815h0.m5849b((Object) this.f1030o0, (Object) e8Var)) {
            this.f1030o0 = e8Var;
            boolean z = true;
            this.f1031p0 = e8Var != null && e8Var.mo5057d() > 0;
            if (this.f1031p0 || getBackground() != null) {
                z = false;
            }
            setWillNotDraw(z);
            if (!e8Var.mo5058e()) {
                int childCount = getChildCount();
                for (int i = 0; i < childCount; i++) {
                    View childAt = getChildAt(i);
                    if (C2189w7.m15015j(childAt) && (cVar = ((C0177f) childAt.getLayoutParams()).f1038a) != null) {
                        e8Var = cVar.mo1253a(e8Var);
                        if (e8Var.mo5058e()) {
                            break;
                        }
                    }
                }
            }
            requestLayout();
        }
        return e8Var;
    }

    /* renamed from: c */
    public void mo1214c(View view, Rect rect) {
        ((C0177f) view.getLayoutParams()).f1054q.set(rect);
    }
}
