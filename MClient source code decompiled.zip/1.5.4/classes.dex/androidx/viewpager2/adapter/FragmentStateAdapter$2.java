package androidx.viewpager2.adapter;

import p000.C1234lb;

public class FragmentStateAdapter$2 implements C1321mb {
    /* renamed from: a */
    public void mo644a(C1509ob obVar, C1234lb.C1235a aVar) {
        throw null;
    }
}
