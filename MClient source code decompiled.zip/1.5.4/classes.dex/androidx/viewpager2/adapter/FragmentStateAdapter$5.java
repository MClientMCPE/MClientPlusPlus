package androidx.viewpager2.adapter;

import android.os.Handler;
import p000.C1234lb;

public class FragmentStateAdapter$5 implements C1321mb {

    /* renamed from: a */
    public final /* synthetic */ Handler f1465a;

    /* renamed from: b */
    public final /* synthetic */ Runnable f1466b;

    /* renamed from: a */
    public void mo644a(C1509ob obVar, C1234lb.C1235a aVar) {
        if (aVar == C1234lb.C1235a.ON_DESTROY) {
            this.f1465a.removeCallbacks(this.f1466b);
            ((C1607pb) obVar.mo635a()).f12332a.remove(this);
        }
    }
}
