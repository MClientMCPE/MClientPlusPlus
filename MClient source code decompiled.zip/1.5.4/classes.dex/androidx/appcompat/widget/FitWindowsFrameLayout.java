package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.widget.FrameLayout;
import p000.C0508d3;

public class FitWindowsFrameLayout extends FrameLayout implements C0508d3 {

    /* renamed from: a0 */
    public C0508d3.C0509a f869a0;

    public FitWindowsFrameLayout(Context context) {
        super(context);
    }

    public FitWindowsFrameLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public boolean fitSystemWindows(Rect rect) {
        C0508d3.C0509a aVar = this.f869a0;
        if (aVar != null) {
            rect.top = ((C0332c0) aVar).f2405a.mo42h(rect.top);
        }
        return super.fitSystemWindows(rect);
    }

    public void setOnFitSystemWindowsListener(C0508d3.C0509a aVar) {
        this.f869a0 = aVar;
    }
}
