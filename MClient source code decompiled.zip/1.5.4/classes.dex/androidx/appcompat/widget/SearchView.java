package androidx.appcompat.widget;

import android.app.PendingIntent;
import android.app.SearchableInfo;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.TouchDelegate;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.TextView;
import java.lang.reflect.Method;
import java.util.WeakHashMap;

public class SearchView extends C0639f3 implements C1957u0 {

    /* renamed from: k1 */
    public static final C0155k f871k1 = new C0155k();

    /* renamed from: A0 */
    public Rect f872A0;

    /* renamed from: B0 */
    public int[] f873B0;

    /* renamed from: C0 */
    public int[] f874C0;

    /* renamed from: D0 */
    public final ImageView f875D0;

    /* renamed from: E0 */
    public final Drawable f876E0;

    /* renamed from: F0 */
    public final int f877F0;

    /* renamed from: G0 */
    public final int f878G0;

    /* renamed from: H0 */
    public final Intent f879H0;

    /* renamed from: I0 */
    public final Intent f880I0;

    /* renamed from: J0 */
    public final CharSequence f881J0;

    /* renamed from: K0 */
    public View.OnFocusChangeListener f882K0;

    /* renamed from: L0 */
    public View.OnClickListener f883L0;

    /* renamed from: M0 */
    public boolean f884M0;

    /* renamed from: N0 */
    public boolean f885N0;

    /* renamed from: O0 */
    public C1676q8 f886O0;

    /* renamed from: P0 */
    public boolean f887P0;

    /* renamed from: Q0 */
    public CharSequence f888Q0;

    /* renamed from: R0 */
    public boolean f889R0;

    /* renamed from: S0 */
    public boolean f890S0;

    /* renamed from: T0 */
    public int f891T0;

    /* renamed from: U0 */
    public boolean f892U0;

    /* renamed from: V0 */
    public CharSequence f893V0;

    /* renamed from: W0 */
    public CharSequence f894W0;

    /* renamed from: X0 */
    public boolean f895X0;

    /* renamed from: Y0 */
    public int f896Y0;

    /* renamed from: Z0 */
    public SearchableInfo f897Z0;

    /* renamed from: a1 */
    public Bundle f898a1;

    /* renamed from: b1 */
    public final Runnable f899b1;

    /* renamed from: c1 */
    public Runnable f900c1;

    /* renamed from: d1 */
    public final WeakHashMap<String, Drawable.ConstantState> f901d1;

    /* renamed from: e1 */
    public final View.OnClickListener f902e1;

    /* renamed from: f1 */
    public View.OnKeyListener f903f1;

    /* renamed from: g1 */
    public final TextView.OnEditorActionListener f904g1;

    /* renamed from: h1 */
    public final AdapterView.OnItemClickListener f905h1;

    /* renamed from: i1 */
    public final AdapterView.OnItemSelectedListener f906i1;

    /* renamed from: j1 */
    public TextWatcher f907j1;

    /* renamed from: p0 */
    public final SearchAutoComplete f908p0;

    /* renamed from: q0 */
    public final View f909q0;

    /* renamed from: r0 */
    public final View f910r0;

    /* renamed from: s0 */
    public final View f911s0;

    /* renamed from: t0 */
    public final ImageView f912t0;

    /* renamed from: u0 */
    public final ImageView f913u0;

    /* renamed from: v0 */
    public final ImageView f914v0;

    /* renamed from: w0 */
    public final ImageView f915w0;

    /* renamed from: x0 */
    public final View f916x0;

    /* renamed from: y0 */
    public C0161p f917y0;

    /* renamed from: z0 */
    public Rect f918z0;

    public static class SearchAutoComplete extends C0278b2 {

        /* renamed from: d0 */
        public int f919d0;

        /* renamed from: e0 */
        public SearchView f920e0;

        /* renamed from: f0 */
        public boolean f921f0;

        /* renamed from: g0 */
        public final Runnable f922g0;

        /* renamed from: androidx.appcompat.widget.SearchView$SearchAutoComplete$a */
        public class C0144a implements Runnable {
            public C0144a() {
            }

            public void run() {
                SearchAutoComplete.this.mo1009b();
            }
        }

        public SearchAutoComplete(Context context) {
            this(context, (AttributeSet) null);
        }

        public SearchAutoComplete(Context context, AttributeSet attributeSet) {
            this(context, attributeSet, C0502d.autoCompleteTextViewStyle);
        }

        public SearchAutoComplete(Context context, AttributeSet attributeSet, int i) {
            super(context, attributeSet, i);
            this.f922g0 = new C0144a();
            this.f919d0 = getThreshold();
        }

        private int getSearchViewTextMinWidthDp() {
            Configuration configuration = getResources().getConfiguration();
            int i = configuration.screenWidthDp;
            int i2 = configuration.screenHeightDp;
            if (i >= 960 && i2 >= 720 && configuration.orientation == 2) {
                return 256;
            }
            if (i < 600) {
                return (i < 640 || i2 < 480) ? 160 : 192;
            }
            return 192;
        }

        /* renamed from: a */
        public boolean mo1008a() {
            return TextUtils.getTrimmedLength(getText()) == 0;
        }

        /* renamed from: b */
        public void mo1009b() {
            if (this.f921f0) {
                ((InputMethodManager) getContext().getSystemService("input_method")).showSoftInput(this, 0);
                this.f921f0 = false;
            }
        }

        public boolean enoughToFilter() {
            return this.f919d0 <= 0 || super.enoughToFilter();
        }

        public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
            InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
            if (this.f921f0) {
                removeCallbacks(this.f922g0);
                post(this.f922g0);
            }
            return onCreateInputConnection;
        }

        public void onFinishInflate() {
            super.onFinishInflate();
            setMinWidth((int) TypedValue.applyDimension(1, (float) getSearchViewTextMinWidthDp(), getResources().getDisplayMetrics()));
        }

        public void onFocusChanged(boolean z, int i, Rect rect) {
            super.onFocusChanged(z, i, rect);
            this.f920e0.mo981o();
        }

        public boolean onKeyPreIme(int i, KeyEvent keyEvent) {
            if (i == 4) {
                if (keyEvent.getAction() == 0 && keyEvent.getRepeatCount() == 0) {
                    KeyEvent.DispatcherState keyDispatcherState = getKeyDispatcherState();
                    if (keyDispatcherState != null) {
                        keyDispatcherState.startTracking(keyEvent, this);
                    }
                    return true;
                } else if (keyEvent.getAction() == 1) {
                    KeyEvent.DispatcherState keyDispatcherState2 = getKeyDispatcherState();
                    if (keyDispatcherState2 != null) {
                        keyDispatcherState2.handleUpEvent(keyEvent);
                    }
                    if (keyEvent.isTracking() && !keyEvent.isCanceled()) {
                        this.f920e0.clearFocus();
                        setImeVisibility(false);
                        return true;
                    }
                }
            }
            return super.onKeyPreIme(i, keyEvent);
        }

        public void onWindowFocusChanged(boolean z) {
            Method method;
            super.onWindowFocusChanged(z);
            if (z && this.f920e0.hasFocus() && getVisibility() == 0) {
                this.f921f0 = true;
                if (SearchView.m727a(getContext()) && (method = SearchView.f871k1.f936c) != null) {
                    try {
                        method.invoke(this, new Object[]{true});
                    } catch (Exception unused) {
                    }
                }
            }
        }

        public void performCompletion() {
        }

        public void replaceText(CharSequence charSequence) {
        }

        public void setImeVisibility(boolean z) {
            InputMethodManager inputMethodManager = (InputMethodManager) getContext().getSystemService("input_method");
            if (!z) {
                this.f921f0 = false;
                removeCallbacks(this.f922g0);
                inputMethodManager.hideSoftInputFromWindow(getWindowToken(), 0);
            } else if (inputMethodManager.isActive(this)) {
                this.f921f0 = false;
                removeCallbacks(this.f922g0);
                inputMethodManager.showSoftInput(this, 0);
            } else {
                this.f921f0 = true;
            }
        }

        public void setSearchView(SearchView searchView) {
            this.f920e0 = searchView;
        }

        public void setThreshold(int i) {
            super.setThreshold(i);
            this.f919d0 = i;
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$a */
    public class C0145a implements TextWatcher {
        public C0145a() {
        }

        public void afterTextChanged(Editable editable) {
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            SearchView.this.mo960b(charSequence);
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$b */
    public class C0146b implements Runnable {
        public C0146b() {
        }

        public void run() {
            SearchView.this.mo988r();
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$c */
    public class C0147c implements Runnable {
        public C0147c() {
        }

        public void run() {
            C1676q8 q8Var = SearchView.this.f886O0;
            if (q8Var instanceof C1736r3) {
                q8Var.mo10268a((Cursor) null);
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$d */
    public class C0148d implements View.OnFocusChangeListener {
        public C0148d() {
        }

        public void onFocusChange(View view, boolean z) {
            SearchView searchView = SearchView.this;
            View.OnFocusChangeListener onFocusChangeListener = searchView.f882K0;
            if (onFocusChangeListener != null) {
                onFocusChangeListener.onFocusChange(searchView, z);
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$e */
    public class C0149e implements View.OnLayoutChangeListener {
        public C0149e() {
        }

        public void onLayoutChange(View view, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
            SearchView.this.mo966g();
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$f */
    public class C0150f implements View.OnClickListener {
        public C0150f() {
        }

        public void onClick(View view) {
            SearchView searchView = SearchView.this;
            if (view == searchView.f912t0) {
                searchView.mo979m();
            } else if (view == searchView.f914v0) {
                searchView.mo978l();
            } else if (view == searchView.f913u0) {
                searchView.mo980n();
            } else if (view == searchView.f915w0) {
                searchView.mo986p();
            } else if (view == searchView.f908p0) {
                searchView.mo975h();
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$g */
    public class C0151g implements View.OnKeyListener {
        public C0151g() {
        }

        public boolean onKey(View view, int i, KeyEvent keyEvent) {
            SearchView searchView = SearchView.this;
            if (searchView.f897Z0 == null) {
                return false;
            }
            if (searchView.f908p0.isPopupShowing() && SearchView.this.f908p0.getListSelection() != -1) {
                return SearchView.this.mo958a(i, keyEvent);
            }
            if (SearchView.this.f908p0.mo1008a() || !keyEvent.hasNoModifiers() || keyEvent.getAction() != 1 || i != 66) {
                return false;
            }
            view.cancelLongPress();
            SearchView searchView2 = SearchView.this;
            searchView2.mo954a(0, (String) null, searchView2.f908p0.getText().toString());
            return true;
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$h */
    public class C0152h implements TextView.OnEditorActionListener {
        public C0152h() {
        }

        public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
            SearchView.this.mo980n();
            return true;
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$i */
    public class C0153i implements AdapterView.OnItemClickListener {
        public C0153i() {
        }

        public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
            SearchView.this.mo963c(i);
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$j */
    public class C0154j implements AdapterView.OnItemSelectedListener {
        public C0154j() {
        }

        public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
            SearchView.this.mo965d(i);
        }

        public void onNothingSelected(AdapterView<?> adapterView) {
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$k */
    public static class C0155k {

        /* renamed from: a */
        public Method f934a;

        /* renamed from: b */
        public Method f935b;

        /* renamed from: c */
        public Method f936c;

        public C0155k() {
            try {
                this.f934a = AutoCompleteTextView.class.getDeclaredMethod("doBeforeTextChanged", new Class[0]);
                this.f934a.setAccessible(true);
            } catch (NoSuchMethodException unused) {
            }
            try {
                this.f935b = AutoCompleteTextView.class.getDeclaredMethod("doAfterTextChanged", new Class[0]);
                this.f935b.setAccessible(true);
            } catch (NoSuchMethodException unused2) {
            }
            Class<AutoCompleteTextView> cls = AutoCompleteTextView.class;
            try {
                this.f936c = cls.getMethod("ensureImeVisible", new Class[]{Boolean.TYPE});
                this.f936c.setAccessible(true);
            } catch (NoSuchMethodException unused3) {
            }
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$l */
    public interface C0156l {
    }

    /* renamed from: androidx.appcompat.widget.SearchView$m */
    public interface C0157m {
    }

    /* renamed from: androidx.appcompat.widget.SearchView$n */
    public interface C0158n {
    }

    /* renamed from: androidx.appcompat.widget.SearchView$o */
    public static class C0159o extends C1904t8 {
        public static final Parcelable.Creator<C0159o> CREATOR = new C0160a();

        /* renamed from: Z */
        public boolean f937Z;

        /* renamed from: androidx.appcompat.widget.SearchView$o$a */
        public static class C0160a implements Parcelable.ClassLoaderCreator<C0159o> {
            public Object createFromParcel(Parcel parcel) {
                return new C0159o(parcel, (ClassLoader) null);
            }

            public Object[] newArray(int i) {
                return new C0159o[i];
            }

            public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new C0159o(parcel, classLoader);
            }
        }

        public C0159o(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f937Z = ((Boolean) parcel.readValue((ClassLoader) null)).booleanValue();
        }

        public C0159o(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            StringBuilder a = C0789gk.m5562a("SearchView.SavedState{");
            a.append(Integer.toHexString(System.identityHashCode(this)));
            a.append(" isIconified=");
            a.append(this.f937Z);
            a.append("}");
            return a.toString();
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeParcelable(this.f14707X, i);
            parcel.writeValue(Boolean.valueOf(this.f937Z));
        }
    }

    /* renamed from: androidx.appcompat.widget.SearchView$p */
    public static class C0161p extends TouchDelegate {

        /* renamed from: a */
        public final View f938a;

        /* renamed from: b */
        public final Rect f939b = new Rect();

        /* renamed from: c */
        public final Rect f940c = new Rect();

        /* renamed from: d */
        public final Rect f941d = new Rect();

        /* renamed from: e */
        public final int f942e;

        /* renamed from: f */
        public boolean f943f;

        public C0161p(Rect rect, Rect rect2, View view) {
            super(rect, view);
            this.f942e = ViewConfiguration.get(view.getContext()).getScaledTouchSlop();
            mo1040a(rect, rect2);
            this.f938a = view;
        }

        /* renamed from: a */
        public void mo1040a(Rect rect, Rect rect2) {
            this.f939b.set(rect);
            this.f941d.set(rect);
            Rect rect3 = this.f941d;
            int i = this.f942e;
            rect3.inset(-i, -i);
            this.f940c.set(rect2);
        }

        /* JADX WARNING: Removed duplicated region for block: B:17:0x003d  */
        /* JADX WARNING: Removed duplicated region for block: B:24:? A[RETURN, SYNTHETIC] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean onTouchEvent(android.view.MotionEvent r8) {
            /*
                r7 = this;
                float r0 = r8.getX()
                int r0 = (int) r0
                float r1 = r8.getY()
                int r1 = (int) r1
                int r2 = r8.getAction()
                r3 = 2
                r4 = 1
                r5 = 0
                if (r2 == 0) goto L_0x002e
                if (r2 == r4) goto L_0x0020
                if (r2 == r3) goto L_0x0020
                r6 = 3
                if (r2 == r6) goto L_0x001b
                goto L_0x003a
            L_0x001b:
                boolean r2 = r7.f943f
                r7.f943f = r5
                goto L_0x003b
            L_0x0020:
                boolean r2 = r7.f943f
                if (r2 == 0) goto L_0x003b
                android.graphics.Rect r6 = r7.f941d
                boolean r6 = r6.contains(r0, r1)
                if (r6 != 0) goto L_0x003b
                r4 = 0
                goto L_0x003b
            L_0x002e:
                android.graphics.Rect r2 = r7.f939b
                boolean r2 = r2.contains(r0, r1)
                if (r2 == 0) goto L_0x003a
                r7.f943f = r4
                r2 = 1
                goto L_0x003b
            L_0x003a:
                r2 = 0
            L_0x003b:
                if (r2 == 0) goto L_0x006a
                if (r4 == 0) goto L_0x0057
                android.graphics.Rect r2 = r7.f940c
                boolean r2 = r2.contains(r0, r1)
                if (r2 != 0) goto L_0x0057
                android.view.View r0 = r7.f938a
                int r0 = r0.getWidth()
                int r0 = r0 / r3
                float r0 = (float) r0
                android.view.View r1 = r7.f938a
                int r1 = r1.getHeight()
                int r1 = r1 / r3
                goto L_0x0060
            L_0x0057:
                android.graphics.Rect r2 = r7.f940c
                int r3 = r2.left
                int r0 = r0 - r3
                float r0 = (float) r0
                int r2 = r2.top
                int r1 = r1 - r2
            L_0x0060:
                float r1 = (float) r1
                r8.setLocation(r0, r1)
                android.view.View r0 = r7.f938a
                boolean r5 = r0.dispatchTouchEvent(r8)
            L_0x006a:
                return r5
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.SearchView.C0161p.onTouchEvent(android.view.MotionEvent):boolean");
        }
    }

    public SearchView(Context context) {
        this(context, (AttributeSet) null);
    }

    public SearchView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0502d.searchViewStyle);
    }

    public SearchView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f918z0 = new Rect();
        this.f872A0 = new Rect();
        this.f873B0 = new int[2];
        this.f874C0 = new int[2];
        this.f899b1 = new C0146b();
        this.f900c1 = new C0147c();
        this.f901d1 = new WeakHashMap<>();
        this.f902e1 = new C0150f();
        this.f903f1 = new C0151g();
        this.f904g1 = new C0152h();
        this.f905h1 = new C0153i();
        this.f906i1 = new C0154j();
        this.f907j1 = new C0145a();
        C2322y3 y3Var = new C2322y3(context, context.obtainStyledAttributes(attributeSet, C1292m.SearchView, i, 0));
        LayoutInflater.from(context).inflate(y3Var.mo12744f(C1292m.SearchView_layout, C0978j.abc_search_view), this, true);
        this.f908p0 = (SearchAutoComplete) findViewById(C0887i.search_src_text);
        this.f908p0.setSearchView(this);
        this.f909q0 = findViewById(C0887i.search_edit_frame);
        this.f910r0 = findViewById(C0887i.search_plate);
        this.f911s0 = findViewById(C0887i.submit_area);
        this.f912t0 = (ImageView) findViewById(C0887i.search_button);
        this.f913u0 = (ImageView) findViewById(C0887i.search_go_btn);
        this.f914v0 = (ImageView) findViewById(C0887i.search_close_btn);
        this.f915w0 = (ImageView) findViewById(C0887i.search_voice_btn);
        this.f875D0 = (ImageView) findViewById(C0887i.search_mag_icon);
        C2189w7.m14987a(this.f910r0, y3Var.mo12737b(C1292m.SearchView_queryBackground));
        View view = this.f911s0;
        Drawable b = y3Var.mo12737b(C1292m.SearchView_submitBackground);
        int i2 = Build.VERSION.SDK_INT;
        view.setBackground(b);
        this.f912t0.setImageDrawable(y3Var.mo12737b(C1292m.SearchView_searchIcon));
        this.f913u0.setImageDrawable(y3Var.mo12737b(C1292m.SearchView_goIcon));
        this.f914v0.setImageDrawable(y3Var.mo12737b(C1292m.SearchView_closeIcon));
        this.f915w0.setImageDrawable(y3Var.mo12737b(C1292m.SearchView_voiceIcon));
        this.f875D0.setImageDrawable(y3Var.mo12737b(C1292m.SearchView_searchIcon));
        this.f876E0 = y3Var.mo12737b(C1292m.SearchView_searchHintIcon);
        C0815h0.m5806a((View) this.f912t0, (CharSequence) getResources().getString(C1109k.abc_searchview_description_search));
        this.f877F0 = y3Var.mo12744f(C1292m.SearchView_suggestionRowLayout, C0978j.abc_search_dropdown_item_icons_2line);
        this.f878G0 = y3Var.mo12744f(C1292m.SearchView_commitIcon, 0);
        this.f912t0.setOnClickListener(this.f902e1);
        this.f914v0.setOnClickListener(this.f902e1);
        this.f913u0.setOnClickListener(this.f902e1);
        this.f915w0.setOnClickListener(this.f902e1);
        this.f908p0.setOnClickListener(this.f902e1);
        this.f908p0.addTextChangedListener(this.f907j1);
        this.f908p0.setOnEditorActionListener(this.f904g1);
        this.f908p0.setOnItemClickListener(this.f905h1);
        this.f908p0.setOnItemSelectedListener(this.f906i1);
        this.f908p0.setOnKeyListener(this.f903f1);
        this.f908p0.setOnFocusChangeListener(new C0148d());
        setIconifiedByDefault(y3Var.mo12735a(C1292m.SearchView_iconifiedByDefault, true));
        int c = y3Var.mo12738c(C1292m.SearchView_android_maxWidth, -1);
        if (c != -1) {
            setMaxWidth(c);
        }
        this.f881J0 = y3Var.mo12743e(C1292m.SearchView_defaultQueryHint);
        this.f888Q0 = y3Var.mo12743e(C1292m.SearchView_queryHint);
        int d = y3Var.mo12740d(C1292m.SearchView_android_imeOptions, -1);
        if (d != -1) {
            setImeOptions(d);
        }
        int d2 = y3Var.mo12740d(C1292m.SearchView_android_inputType, -1);
        if (d2 != -1) {
            setInputType(d2);
        }
        setFocusable(y3Var.mo12735a(C1292m.SearchView_android_focusable, true));
        y3Var.f17544b.recycle();
        this.f879H0 = new Intent("android.speech.action.WEB_SEARCH");
        this.f879H0.addFlags(268435456);
        this.f879H0.putExtra("android.speech.extra.LANGUAGE_MODEL", "web_search");
        this.f880I0 = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        this.f880I0.addFlags(268435456);
        this.f916x0 = findViewById(this.f908p0.getDropDownAnchor());
        View view2 = this.f916x0;
        if (view2 != null) {
            view2.addOnLayoutChangeListener(new C0149e());
        }
        mo961b(this.f884M0);
        mo990s();
    }

    /* renamed from: a */
    public static boolean m727a(Context context) {
        return context.getResources().getConfiguration().orientation == 2;
    }

    private int getPreferredHeight() {
        return getContext().getResources().getDimensionPixelSize(C0729g.abc_search_view_preferred_height);
    }

    private int getPreferredWidth() {
        return getContext().getResources().getDimensionPixelSize(C0729g.abc_search_view_preferred_width);
    }

    private void setQuery(CharSequence charSequence) {
        this.f908p0.setText(charSequence);
        this.f908p0.setSelection(TextUtils.isEmpty(charSequence) ? 0 : charSequence.length());
    }

    /* renamed from: a */
    public final Intent mo951a(Intent intent, SearchableInfo searchableInfo) {
        ComponentName searchActivity = searchableInfo.getSearchActivity();
        Intent intent2 = new Intent("android.intent.action.SEARCH");
        intent2.setComponent(searchActivity);
        PendingIntent activity = PendingIntent.getActivity(getContext(), 0, intent2, 1073741824);
        Bundle bundle = new Bundle();
        Bundle bundle2 = this.f898a1;
        if (bundle2 != null) {
            bundle.putParcelable("app_data", bundle2);
        }
        Intent intent3 = new Intent(intent);
        int i = 1;
        Resources resources = getResources();
        String string = searchableInfo.getVoiceLanguageModeId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageModeId()) : "free_form";
        String str = null;
        String string2 = searchableInfo.getVoicePromptTextId() != 0 ? resources.getString(searchableInfo.getVoicePromptTextId()) : null;
        String string3 = searchableInfo.getVoiceLanguageId() != 0 ? resources.getString(searchableInfo.getVoiceLanguageId()) : null;
        if (searchableInfo.getVoiceMaxResults() != 0) {
            i = searchableInfo.getVoiceMaxResults();
        }
        intent3.putExtra("android.speech.extra.LANGUAGE_MODEL", string);
        intent3.putExtra("android.speech.extra.PROMPT", string2);
        intent3.putExtra("android.speech.extra.LANGUAGE", string3);
        intent3.putExtra("android.speech.extra.MAX_RESULTS", i);
        if (searchActivity != null) {
            str = searchActivity.flattenToShortString();
        }
        intent3.putExtra("calling_package", str);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT", activity);
        intent3.putExtra("android.speech.extra.RESULTS_PENDINGINTENT_BUNDLE", bundle);
        return intent3;
    }

    /* renamed from: a */
    public final Intent mo952a(String str, Uri uri, String str2, String str3, int i, String str4) {
        Intent intent = new Intent(str);
        intent.addFlags(268435456);
        if (uri != null) {
            intent.setData(uri);
        }
        intent.putExtra("user_query", this.f894W0);
        if (str3 != null) {
            intent.putExtra("query", str3);
        }
        if (str2 != null) {
            intent.putExtra("intent_extra_data_key", str2);
        }
        Bundle bundle = this.f898a1;
        if (bundle != null) {
            intent.putExtra("app_data", bundle);
        }
        if (i != 0) {
            intent.putExtra("action_key", i);
            intent.putExtra("action_msg", str4);
        }
        intent.setComponent(this.f897Z0.getSearchActivity());
        return intent;
    }

    /* renamed from: a */
    public void mo953a() {
        if (!this.f895X0) {
            this.f895X0 = true;
            this.f896Y0 = this.f908p0.getImeOptions();
            this.f908p0.setImeOptions(this.f896Y0 | 33554432);
            this.f908p0.setText("");
            setIconified(false);
        }
    }

    /* renamed from: a */
    public void mo954a(int i, String str, String str2) {
        getContext().startActivity(mo952a("android.intent.action.SEARCH", (Uri) null, (String) null, str2, i, str));
    }

    /* renamed from: a */
    public void mo955a(CharSequence charSequence) {
        setQuery(charSequence);
    }

    /* renamed from: a */
    public void mo956a(CharSequence charSequence, boolean z) {
        this.f908p0.setText(charSequence);
        if (charSequence != null) {
            SearchAutoComplete searchAutoComplete = this.f908p0;
            searchAutoComplete.setSelection(searchAutoComplete.length());
            this.f894W0 = charSequence;
        }
        if (z && !TextUtils.isEmpty(charSequence)) {
            mo980n();
        }
    }

    /* renamed from: a */
    public final void mo957a(boolean z) {
        this.f913u0.setVisibility((!this.f887P0 || !mo977k() || !hasFocus() || (!z && this.f892U0)) ? 8 : 0);
    }

    /* renamed from: a */
    public boolean mo958a(int i, KeyEvent keyEvent) {
        if (this.f897Z0 != null && this.f886O0 != null && keyEvent.getAction() == 0 && keyEvent.hasNoModifiers()) {
            if (i == 66 || i == 84 || i == 61) {
                return mo963c(this.f908p0.getListSelection());
            }
            if (i == 21 || i == 22) {
                this.f908p0.setSelection(i == 21 ? 0 : this.f908p0.length());
                this.f908p0.setListSelection(0);
                this.f908p0.clearListSelection();
                C0155k kVar = f871k1;
                SearchAutoComplete searchAutoComplete = this.f908p0;
                Method method = kVar.f936c;
                if (method != null) {
                    try {
                        method.invoke(searchAutoComplete, new Object[]{true});
                    } catch (Exception unused) {
                    }
                }
                return true;
            } else if (i != 19 || this.f908p0.getListSelection() == 0) {
                return false;
            }
        }
        return false;
    }

    /* renamed from: b */
    public void mo959b() {
        mo956a((CharSequence) "", false);
        clearFocus();
        mo961b(true);
        this.f908p0.setImeOptions(this.f896Y0);
        this.f895X0 = false;
    }

    /* renamed from: b */
    public void mo960b(CharSequence charSequence) {
        Editable text = this.f908p0.getText();
        this.f894W0 = text;
        boolean z = !TextUtils.isEmpty(text);
        mo957a(z);
        mo962c(!z);
        mo987q();
        mo1007t();
        this.f893V0 = charSequence.toString();
    }

    /* renamed from: b */
    public final void mo961b(boolean z) {
        this.f885N0 = z;
        int i = 0;
        int i2 = z ? 0 : 8;
        boolean z2 = !TextUtils.isEmpty(this.f908p0.getText());
        this.f912t0.setVisibility(i2);
        mo957a(z2);
        this.f909q0.setVisibility(z ? 8 : 0);
        if (this.f875D0.getDrawable() == null || this.f884M0) {
            i = 8;
        }
        this.f875D0.setVisibility(i);
        mo987q();
        mo962c(!z2);
        mo1007t();
    }

    /* renamed from: c */
    public final void mo962c(boolean z) {
        int i;
        if (!this.f892U0 || mo976j() || !z) {
            i = 8;
        } else {
            i = 0;
            this.f913u0.setVisibility(8);
        }
        this.f915w0.setVisibility(i);
    }

    /* renamed from: c */
    public boolean mo963c(int i) {
        int i2;
        String a;
        Cursor cursor = this.f886O0.f12921Z;
        if (cursor != null && cursor.moveToPosition(i)) {
            Intent intent = null;
            try {
                String a2 = C1736r3.m11901a(cursor, "suggest_intent_action");
                if (a2 == null) {
                    a2 = this.f897Z0.getSuggestIntentAction();
                }
                if (a2 == null) {
                    a2 = "android.intent.action.SEARCH";
                }
                String str = a2;
                String a3 = C1736r3.m11900a(cursor, cursor.getColumnIndex("suggest_intent_data"));
                if (a3 == null) {
                    a3 = this.f897Z0.getSuggestIntentData();
                }
                if (!(a3 == null || (a = C1736r3.m11900a(cursor, cursor.getColumnIndex("suggest_intent_data_id"))) == null)) {
                    a3 = a3 + "/" + Uri.encode(a);
                }
                intent = mo952a(str, a3 == null ? null : Uri.parse(a3), C1736r3.m11900a(cursor, cursor.getColumnIndex("suggest_intent_extra_data")), C1736r3.m11900a(cursor, cursor.getColumnIndex("suggest_intent_query")), 0, (String) null);
            } catch (RuntimeException e) {
                try {
                    i2 = cursor.getPosition();
                } catch (RuntimeException unused) {
                    i2 = -1;
                }
                Log.w("SearchView", "Search suggestions cursor at row " + i2 + " returned exception.", e);
            }
            if (intent != null) {
                try {
                    getContext().startActivity(intent);
                } catch (RuntimeException e2) {
                    Log.e("SearchView", "Failed launch activity: " + intent, e2);
                }
            }
        }
        this.f908p0.setImeVisibility(false);
        this.f908p0.dismissDropDown();
        return true;
    }

    public void clearFocus() {
        this.f890S0 = true;
        super.clearFocus();
        this.f908p0.clearFocus();
        this.f908p0.setImeVisibility(false);
        this.f890S0 = false;
    }

    /* renamed from: d */
    public boolean mo965d(int i) {
        CharSequence b;
        Editable text = this.f908p0.getText();
        Cursor cursor = this.f886O0.f12921Z;
        if (cursor == null) {
            return true;
        }
        if (!cursor.moveToPosition(i) || (b = this.f886O0.mo10270b(cursor)) == null) {
            setQuery(text);
            return true;
        }
        setQuery(b);
        return true;
    }

    /* renamed from: g */
    public void mo966g() {
        if (this.f916x0.getWidth() > 1) {
            Resources resources = getContext().getResources();
            int paddingLeft = this.f910r0.getPaddingLeft();
            Rect rect = new Rect();
            boolean a = C0580e4.m3915a(this);
            int dimensionPixelSize = this.f884M0 ? resources.getDimensionPixelSize(C0729g.abc_dropdownitem_text_padding_left) + resources.getDimensionPixelSize(C0729g.abc_dropdownitem_icon_width) : 0;
            this.f908p0.getDropDownBackground().getPadding(rect);
            this.f908p0.setDropDownHorizontalOffset(a ? -rect.left : paddingLeft - (rect.left + dimensionPixelSize));
            this.f908p0.setDropDownWidth((((this.f916x0.getWidth() + rect.left) + rect.right) + dimensionPixelSize) - paddingLeft);
        }
    }

    public int getImeOptions() {
        return this.f908p0.getImeOptions();
    }

    public int getInputType() {
        return this.f908p0.getInputType();
    }

    public int getMaxWidth() {
        return this.f891T0;
    }

    public CharSequence getQuery() {
        return this.f908p0.getText();
    }

    public CharSequence getQueryHint() {
        CharSequence charSequence = this.f888Q0;
        if (charSequence != null) {
            return charSequence;
        }
        SearchableInfo searchableInfo = this.f897Z0;
        return (searchableInfo == null || searchableInfo.getHintId() == 0) ? this.f881J0 : getContext().getText(this.f897Z0.getHintId());
    }

    public int getSuggestionCommitIconResId() {
        return this.f878G0;
    }

    public int getSuggestionRowLayout() {
        return this.f877F0;
    }

    public C1676q8 getSuggestionsAdapter() {
        return this.f886O0;
    }

    /* renamed from: h */
    public void mo975h() {
        if (Build.VERSION.SDK_INT >= 29) {
            this.f908p0.refreshAutoCompleteResults();
            return;
        }
        C0155k kVar = f871k1;
        SearchAutoComplete searchAutoComplete = this.f908p0;
        Method method = kVar.f934a;
        if (method != null) {
            try {
                method.invoke(searchAutoComplete, new Object[0]);
            } catch (Exception unused) {
            }
        }
        C0155k kVar2 = f871k1;
        SearchAutoComplete searchAutoComplete2 = this.f908p0;
        Method method2 = kVar2.f935b;
        if (method2 != null) {
            try {
                method2.invoke(searchAutoComplete2, new Object[0]);
            } catch (Exception unused2) {
            }
        }
    }

    /* renamed from: j */
    public boolean mo976j() {
        return this.f885N0;
    }

    /* renamed from: k */
    public final boolean mo977k() {
        return (this.f887P0 || this.f892U0) && !mo976j();
    }

    /* renamed from: l */
    public void mo978l() {
        if (!TextUtils.isEmpty(this.f908p0.getText())) {
            this.f908p0.setText("");
            this.f908p0.requestFocus();
            this.f908p0.setImeVisibility(true);
        } else if (this.f884M0) {
            clearFocus();
            mo961b(true);
        }
    }

    /* renamed from: m */
    public void mo979m() {
        mo961b(false);
        this.f908p0.requestFocus();
        this.f908p0.setImeVisibility(true);
        View.OnClickListener onClickListener = this.f883L0;
        if (onClickListener != null) {
            onClickListener.onClick(this);
        }
    }

    /* renamed from: n */
    public void mo980n() {
        Editable text = this.f908p0.getText();
        if (text != null && TextUtils.getTrimmedLength(text) > 0) {
            if (this.f897Z0 != null) {
                mo954a(0, (String) null, text.toString());
            }
            this.f908p0.setImeVisibility(false);
            this.f908p0.dismissDropDown();
        }
    }

    /* renamed from: o */
    public void mo981o() {
        mo961b(mo976j());
        post(this.f899b1);
        if (this.f908p0.hasFocus()) {
            mo975h();
        }
    }

    public void onDetachedFromWindow() {
        removeCallbacks(this.f899b1);
        post(this.f900c1);
        super.onDetachedFromWindow();
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        if (this.f4950d0 == 1) {
            mo5301b(i, i2, i3, i4);
        } else {
            mo5296a(i, i2, i3, i4);
        }
        if (z) {
            SearchAutoComplete searchAutoComplete = this.f908p0;
            Rect rect = this.f918z0;
            searchAutoComplete.getLocationInWindow(this.f873B0);
            getLocationInWindow(this.f874C0);
            int[] iArr = this.f873B0;
            int i5 = iArr[1];
            int[] iArr2 = this.f874C0;
            int i6 = i5 - iArr2[1];
            int i7 = iArr[0] - iArr2[0];
            rect.set(i7, i6, searchAutoComplete.getWidth() + i7, searchAutoComplete.getHeight() + i6);
            Rect rect2 = this.f872A0;
            Rect rect3 = this.f918z0;
            rect2.set(rect3.left, 0, rect3.right, i4 - i2);
            C0161p pVar = this.f917y0;
            if (pVar == null) {
                this.f917y0 = new C0161p(this.f872A0, this.f918z0, this.f908p0);
                setTouchDelegate(this.f917y0);
                return;
            }
            pVar.mo1040a(this.f872A0, this.f918z0);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x0028, code lost:
        if (r0 <= 0) goto L_0x0042;
     */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x004c  */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x0054  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r4, int r5) {
        /*
            r3 = this;
            boolean r0 = r3.mo976j()
            if (r0 == 0) goto L_0x0013
            int r0 = r3.f4950d0
            r1 = 1
            if (r0 != r1) goto L_0x000f
            r3.mo5308d(r4, r5)
            goto L_0x0012
        L_0x000f:
            r3.mo5306c(r4, r5)
        L_0x0012:
            return
        L_0x0013:
            int r0 = android.view.View.MeasureSpec.getMode(r4)
            int r4 = android.view.View.MeasureSpec.getSize(r4)
            r1 = -2147483648(0xffffffff80000000, float:-0.0)
            r2 = 1073741824(0x40000000, float:2.0)
            if (r0 == r1) goto L_0x0035
            if (r0 == 0) goto L_0x002b
            if (r0 == r2) goto L_0x0026
            goto L_0x0042
        L_0x0026:
            int r0 = r3.f891T0
            if (r0 <= 0) goto L_0x0042
            goto L_0x0039
        L_0x002b:
            int r4 = r3.f891T0
            if (r4 <= 0) goto L_0x0030
            goto L_0x0042
        L_0x0030:
            int r4 = r3.getPreferredWidth()
            goto L_0x0042
        L_0x0035:
            int r0 = r3.f891T0
            if (r0 <= 0) goto L_0x003a
        L_0x0039:
            goto L_0x003e
        L_0x003a:
            int r0 = r3.getPreferredWidth()
        L_0x003e:
            int r4 = java.lang.Math.min(r0, r4)
        L_0x0042:
            int r0 = android.view.View.MeasureSpec.getMode(r5)
            int r5 = android.view.View.MeasureSpec.getSize(r5)
            if (r0 == r1) goto L_0x0054
            if (r0 == 0) goto L_0x004f
            goto L_0x005c
        L_0x004f:
            int r5 = r3.getPreferredHeight()
            goto L_0x005c
        L_0x0054:
            int r0 = r3.getPreferredHeight()
            int r5 = java.lang.Math.min(r0, r5)
        L_0x005c:
            int r4 = android.view.View.MeasureSpec.makeMeasureSpec(r4, r2)
            int r5 = android.view.View.MeasureSpec.makeMeasureSpec(r5, r2)
            super.onMeasure(r4, r5)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.SearchView.onMeasure(int, int):void");
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof C0159o)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        C0159o oVar = (C0159o) parcelable;
        super.onRestoreInstanceState(oVar.f14707X);
        mo961b(oVar.f937Z);
        requestLayout();
    }

    public Parcelable onSaveInstanceState() {
        C0159o oVar = new C0159o(super.onSaveInstanceState());
        oVar.f937Z = mo976j();
        return oVar;
    }

    public void onWindowFocusChanged(boolean z) {
        super.onWindowFocusChanged(z);
        post(this.f899b1);
    }

    /* renamed from: p */
    public void mo986p() {
        SearchableInfo searchableInfo = this.f897Z0;
        if (searchableInfo != null) {
            try {
                if (searchableInfo.getVoiceSearchLaunchWebSearch()) {
                    Intent intent = new Intent(this.f879H0);
                    ComponentName searchActivity = searchableInfo.getSearchActivity();
                    intent.putExtra("calling_package", searchActivity == null ? null : searchActivity.flattenToShortString());
                    getContext().startActivity(intent);
                } else if (searchableInfo.getVoiceSearchLaunchRecognizer()) {
                    getContext().startActivity(mo951a(this.f880I0, searchableInfo));
                }
            } catch (ActivityNotFoundException unused) {
                Log.w("SearchView", "Could not find voice search activity");
            }
        }
    }

    /* renamed from: q */
    public final void mo987q() {
        boolean z = true;
        boolean z2 = !TextUtils.isEmpty(this.f908p0.getText());
        int i = 0;
        if (!z2 && (!this.f884M0 || this.f895X0)) {
            z = false;
        }
        ImageView imageView = this.f914v0;
        if (!z) {
            i = 8;
        }
        imageView.setVisibility(i);
        Drawable drawable = this.f914v0.getDrawable();
        if (drawable != null) {
            drawable.setState(z2 ? ViewGroup.ENABLED_STATE_SET : ViewGroup.EMPTY_STATE_SET);
        }
    }

    /* renamed from: r */
    public void mo988r() {
        int[] iArr = this.f908p0.hasFocus() ? ViewGroup.FOCUSED_STATE_SET : ViewGroup.EMPTY_STATE_SET;
        Drawable background = this.f910r0.getBackground();
        if (background != null) {
            background.setState(iArr);
        }
        Drawable background2 = this.f911s0.getBackground();
        if (background2 != null) {
            background2.setState(iArr);
        }
        invalidate();
    }

    public boolean requestFocus(int i, Rect rect) {
        if (this.f890S0 || !isFocusable()) {
            return false;
        }
        if (mo976j()) {
            return super.requestFocus(i, rect);
        }
        boolean requestFocus = this.f908p0.requestFocus(i, rect);
        if (requestFocus) {
            mo961b(false);
        }
        return requestFocus;
    }

    /* renamed from: s */
    public final void mo990s() {
        SpannableStringBuilder queryHint = getQueryHint();
        SearchAutoComplete searchAutoComplete = this.f908p0;
        if (queryHint == null) {
            queryHint = "";
        }
        if (this.f884M0 && this.f876E0 != null) {
            double textSize = (double) this.f908p0.getTextSize();
            Double.isNaN(textSize);
            Double.isNaN(textSize);
            int i = (int) (textSize * 1.25d);
            this.f876E0.setBounds(0, 0, i, i);
            SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder("   ");
            spannableStringBuilder.setSpan(new ImageSpan(this.f876E0), 1, 2, 33);
            spannableStringBuilder.append(queryHint);
            queryHint = spannableStringBuilder;
        }
        searchAutoComplete.setHint(queryHint);
    }

    public void setAppSearchData(Bundle bundle) {
        this.f898a1 = bundle;
    }

    public void setIconified(boolean z) {
        if (z) {
            mo978l();
        } else {
            mo979m();
        }
    }

    public void setIconifiedByDefault(boolean z) {
        if (this.f884M0 != z) {
            this.f884M0 = z;
            mo961b(z);
            mo990s();
        }
    }

    public void setImeOptions(int i) {
        this.f908p0.setImeOptions(i);
    }

    public void setInputType(int i) {
        this.f908p0.setInputType(i);
    }

    public void setMaxWidth(int i) {
        this.f891T0 = i;
        requestLayout();
    }

    public void setOnCloseListener(C0156l lVar) {
    }

    public void setOnQueryTextFocusChangeListener(View.OnFocusChangeListener onFocusChangeListener) {
        this.f882K0 = onFocusChangeListener;
    }

    public void setOnQueryTextListener(C0157m mVar) {
    }

    public void setOnSearchClickListener(View.OnClickListener onClickListener) {
        this.f883L0 = onClickListener;
    }

    public void setOnSuggestionListener(C0158n nVar) {
    }

    public void setQueryHint(CharSequence charSequence) {
        this.f888Q0 = charSequence;
        mo990s();
    }

    public void setQueryRefinementEnabled(boolean z) {
        this.f889R0 = z;
        C1676q8 q8Var = this.f886O0;
        if (q8Var instanceof C1736r3) {
            ((C1736r3) q8Var).f13376o0 = z ? 2 : 1;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:30:0x00a1, code lost:
        if (getContext().getPackageManager().resolveActivity(r2, 65536) != null) goto L_0x00a5;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void setSearchableInfo(android.app.SearchableInfo r7) {
        /*
            r6 = this;
            r6.f897Z0 = r7
            android.app.SearchableInfo r7 = r6.f897Z0
            r0 = 1
            r1 = 65536(0x10000, float:9.18355E-41)
            r2 = 0
            if (r7 == 0) goto L_0x0073
            androidx.appcompat.widget.SearchView$SearchAutoComplete r3 = r6.f908p0
            int r7 = r7.getSuggestThreshold()
            r3.setThreshold(r7)
            androidx.appcompat.widget.SearchView$SearchAutoComplete r7 = r6.f908p0
            android.app.SearchableInfo r3 = r6.f897Z0
            int r3 = r3.getImeOptions()
            r7.setImeOptions(r3)
            android.app.SearchableInfo r7 = r6.f897Z0
            int r7 = r7.getInputType()
            r3 = r7 & 15
            if (r3 != r0) goto L_0x0038
            r3 = -65537(0xfffffffffffeffff, float:NaN)
            r7 = r7 & r3
            android.app.SearchableInfo r3 = r6.f897Z0
            java.lang.String r3 = r3.getSuggestAuthority()
            if (r3 == 0) goto L_0x0038
            r7 = r7 | r1
            r3 = 524288(0x80000, float:7.34684E-40)
            r7 = r7 | r3
        L_0x0038:
            androidx.appcompat.widget.SearchView$SearchAutoComplete r3 = r6.f908p0
            r3.setInputType(r7)
            q8 r7 = r6.f886O0
            if (r7 == 0) goto L_0x0044
            r7.mo10268a(r2)
        L_0x0044:
            android.app.SearchableInfo r7 = r6.f897Z0
            java.lang.String r7 = r7.getSuggestAuthority()
            if (r7 == 0) goto L_0x0070
            r3 r7 = new r3
            android.content.Context r3 = r6.getContext()
            android.app.SearchableInfo r4 = r6.f897Z0
            java.util.WeakHashMap<java.lang.String, android.graphics.drawable.Drawable$ConstantState> r5 = r6.f901d1
            r7.<init>(r3, r6, r4, r5)
            r6.f886O0 = r7
            androidx.appcompat.widget.SearchView$SearchAutoComplete r7 = r6.f908p0
            q8 r3 = r6.f886O0
            r7.setAdapter(r3)
            q8 r7 = r6.f886O0
            r3 r7 = (p000.C1736r3) r7
            boolean r3 = r6.f889R0
            if (r3 == 0) goto L_0x006c
            r3 = 2
            goto L_0x006d
        L_0x006c:
            r3 = 1
        L_0x006d:
            r7.mo10517a((int) r3)
        L_0x0070:
            r6.mo990s()
        L_0x0073:
            android.app.SearchableInfo r7 = r6.f897Z0
            r3 = 0
            if (r7 == 0) goto L_0x00a4
            boolean r7 = r7.getVoiceSearchEnabled()
            if (r7 == 0) goto L_0x00a4
            android.app.SearchableInfo r7 = r6.f897Z0
            boolean r7 = r7.getVoiceSearchLaunchWebSearch()
            if (r7 == 0) goto L_0x0089
            android.content.Intent r2 = r6.f879H0
            goto L_0x0093
        L_0x0089:
            android.app.SearchableInfo r7 = r6.f897Z0
            boolean r7 = r7.getVoiceSearchLaunchRecognizer()
            if (r7 == 0) goto L_0x0093
            android.content.Intent r2 = r6.f880I0
        L_0x0093:
            if (r2 == 0) goto L_0x00a4
            android.content.Context r7 = r6.getContext()
            android.content.pm.PackageManager r7 = r7.getPackageManager()
            android.content.pm.ResolveInfo r7 = r7.resolveActivity(r2, r1)
            if (r7 == 0) goto L_0x00a4
            goto L_0x00a5
        L_0x00a4:
            r0 = 0
        L_0x00a5:
            r6.f892U0 = r0
            boolean r7 = r6.f892U0
            if (r7 == 0) goto L_0x00b2
            androidx.appcompat.widget.SearchView$SearchAutoComplete r7 = r6.f908p0
            java.lang.String r0 = "nm"
            r7.setPrivateImeOptions(r0)
        L_0x00b2:
            boolean r7 = r6.mo976j()
            r6.mo961b((boolean) r7)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.SearchView.setSearchableInfo(android.app.SearchableInfo):void");
    }

    public void setSubmitButtonEnabled(boolean z) {
        this.f887P0 = z;
        mo961b(mo976j());
    }

    public void setSuggestionsAdapter(C1676q8 q8Var) {
        this.f886O0 = q8Var;
        this.f908p0.setAdapter(this.f886O0);
    }

    /* renamed from: t */
    public final void mo1007t() {
        this.f911s0.setVisibility((!mo977k() || !(this.f913u0.getVisibility() == 0 || this.f915w0.getVisibility() == 0)) ? 8 : 0);
    }
}
