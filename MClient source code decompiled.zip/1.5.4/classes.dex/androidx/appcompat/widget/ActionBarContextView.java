package androidx.appcompat.widget;

import android.content.Context;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

public class ActionBarContextView extends C2319y1 {

    /* renamed from: i0 */
    public CharSequence f791i0;

    /* renamed from: j0 */
    public CharSequence f792j0;

    /* renamed from: k0 */
    public View f793k0;

    /* renamed from: l0 */
    public View f794l0;

    /* renamed from: m0 */
    public LinearLayout f795m0;

    /* renamed from: n0 */
    public TextView f796n0;

    /* renamed from: o0 */
    public TextView f797o0;

    /* renamed from: p0 */
    public int f798p0;

    /* renamed from: q0 */
    public int f799q0;

    /* renamed from: r0 */
    public boolean f800r0;

    /* renamed from: s0 */
    public int f801s0;

    /* renamed from: androidx.appcompat.widget.ActionBarContextView$a */
    public class C0132a implements View.OnClickListener {

        /* renamed from: X */
        public final /* synthetic */ C1889t0 f802X;

        public C0132a(ActionBarContextView actionBarContextView, C1889t0 t0Var) {
            this.f802X = t0Var;
        }

        public void onClick(View view) {
            this.f802X.mo7754a();
        }
    }

    public ActionBarContextView(Context context) {
        this(context, (AttributeSet) null);
    }

    public ActionBarContextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0502d.actionModeStyle);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0012, code lost:
        r0 = r4.getResourceId(r5, 0);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public ActionBarContextView(android.content.Context r3, android.util.AttributeSet r4, int r5) {
        /*
            r2 = this;
            r2.<init>(r3, r4, r5)
            int[] r0 = p000.C1292m.ActionMode
            r1 = 0
            android.content.res.TypedArray r4 = r3.obtainStyledAttributes(r4, r0, r5, r1)
            int r5 = p000.C1292m.ActionMode_background
            boolean r0 = r4.hasValue(r5)
            if (r0 == 0) goto L_0x001d
            int r0 = r4.getResourceId(r5, r1)
            if (r0 == 0) goto L_0x001d
            android.graphics.drawable.Drawable r3 = p000.C1206l0.m8461c(r3, r0)
            goto L_0x0021
        L_0x001d:
            android.graphics.drawable.Drawable r3 = r4.getDrawable(r5)
        L_0x0021:
            p000.C2189w7.m14987a((android.view.View) r2, (android.graphics.drawable.Drawable) r3)
            int r3 = p000.C1292m.ActionMode_titleTextStyle
            int r3 = r4.getResourceId(r3, r1)
            r2.f798p0 = r3
            int r3 = p000.C1292m.ActionMode_subtitleTextStyle
            int r3 = r4.getResourceId(r3, r1)
            r2.f799q0 = r3
            int r3 = p000.C1292m.ActionMode_height
            int r3 = r4.getLayoutDimension(r3, r1)
            r2.f17496e0 = r3
            int r3 = p000.C1292m.ActionMode_closeItemLayout
            int r5 = p000.C0978j.abc_action_mode_close_item_material
            int r3 = r4.getResourceId(r3, r5)
            r2.f801s0 = r3
            r4.recycle()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionBarContextView.<init>(android.content.Context, android.util.AttributeSet, int):void");
    }

    /* renamed from: a */
    public void mo774a() {
        if (this.f793k0 == null) {
            mo778d();
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:4:0x001a, code lost:
        if (r0.getParent() == null) goto L_0x001c;
     */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo775a(p000.C1889t0 r7) {
        /*
            r6 = this;
            android.view.View r0 = r6.f793k0
            r1 = 0
            if (r0 != 0) goto L_0x0016
            android.content.Context r0 = r6.getContext()
            android.view.LayoutInflater r0 = android.view.LayoutInflater.from(r0)
            int r2 = r6.f801s0
            android.view.View r0 = r0.inflate(r2, r6, r1)
            r6.f793k0 = r0
            goto L_0x001c
        L_0x0016:
            android.view.ViewParent r0 = r0.getParent()
            if (r0 != 0) goto L_0x0021
        L_0x001c:
            android.view.View r0 = r6.f793k0
            r6.addView(r0)
        L_0x0021:
            android.view.View r0 = r6.f793k0
            int r2 = p000.C0887i.action_mode_close_button
            android.view.View r0 = r0.findViewById(r2)
            androidx.appcompat.widget.ActionBarContextView$a r2 = new androidx.appcompat.widget.ActionBarContextView$a
            r2.<init>(r6, r7)
            r0.setOnClickListener(r2)
            android.view.Menu r7 = r7.mo7762c()
            h1 r7 = (p000.C0816h1) r7
            a2 r0 = r6.f17495d0
            if (r0 == 0) goto L_0x003e
            r0.mo135b()
        L_0x003e:
            a2 r0 = new a2
            android.content.Context r2 = r6.getContext()
            r0.<init>(r2)
            r6.f17495d0 = r0
            a2 r0 = r6.f17495d0
            r2 = 1
            r0.f112i0 = r2
            r0.f113j0 = r2
            android.view.ViewGroup$LayoutParams r0 = new android.view.ViewGroup$LayoutParams
            r3 = -2
            r4 = -1
            r0.<init>(r3, r4)
            a2 r3 = r6.f17495d0
            android.content.Context r4 = r6.f17493b0
            r7.mo6287a((p000.C1581p1) r3, (android.content.Context) r4)
            a2 r7 = r6.f17495d0
            q1 r3 = r7.f2419e0
            if (r3 != 0) goto L_0x007a
            android.view.LayoutInflater r4 = r7.f2415a0
            int r5 = r7.f2417c0
            android.view.View r1 = r4.inflate(r5, r6, r1)
            q1 r1 = (p000.C1655q1) r1
            r7.f2419e0 = r1
            q1 r1 = r7.f2419e0
            h1 r4 = r7.f2414Z
            r1.mo735a(r4)
            r7.mo131a((boolean) r2)
        L_0x007a:
            q1 r1 = r7.f2419e0
            if (r3 == r1) goto L_0x0084
            r2 = r1
            androidx.appcompat.widget.ActionMenuView r2 = (androidx.appcompat.widget.ActionMenuView) r2
            r2.setPresenter(r7)
        L_0x0084:
            androidx.appcompat.widget.ActionMenuView r1 = (androidx.appcompat.widget.ActionMenuView) r1
            r6.f17494c0 = r1
            androidx.appcompat.widget.ActionMenuView r7 = r6.f17494c0
            r1 = 0
            p000.C2189w7.m14987a((android.view.View) r7, (android.graphics.drawable.Drawable) r1)
            androidx.appcompat.widget.ActionMenuView r7 = r6.f17494c0
            r6.addView(r7, r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionBarContextView.mo775a(t0):void");
    }

    /* renamed from: b */
    public final void mo776b() {
        if (this.f795m0 == null) {
            LayoutInflater.from(getContext()).inflate(C0978j.abc_action_bar_title_item, this);
            this.f795m0 = (LinearLayout) getChildAt(getChildCount() - 1);
            this.f796n0 = (TextView) this.f795m0.findViewById(C0887i.action_bar_title);
            this.f797o0 = (TextView) this.f795m0.findViewById(C0887i.action_bar_subtitle);
            if (this.f798p0 != 0) {
                this.f796n0.setTextAppearance(getContext(), this.f798p0);
            }
            if (this.f799q0 != 0) {
                this.f797o0.setTextAppearance(getContext(), this.f799q0);
            }
        }
        this.f796n0.setText(this.f791i0);
        this.f797o0.setText(this.f792j0);
        boolean z = !TextUtils.isEmpty(this.f791i0);
        boolean z2 = !TextUtils.isEmpty(this.f792j0);
        int i = 0;
        this.f797o0.setVisibility(z2 ? 0 : 8);
        LinearLayout linearLayout = this.f795m0;
        if (!z && !z2) {
            i = 8;
        }
        linearLayout.setVisibility(i);
        if (this.f795m0.getParent() == null) {
            addView(this.f795m0);
        }
    }

    /* renamed from: c */
    public boolean mo777c() {
        return this.f800r0;
    }

    /* renamed from: d */
    public void mo778d() {
        removeAllViews();
        this.f794l0 = null;
        this.f17494c0 = null;
    }

    /* renamed from: e */
    public boolean mo779e() {
        C0027a2 a2Var = this.f17495d0;
        if (a2Var != null) {
            return a2Var.mo139f();
        }
        return false;
    }

    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new ViewGroup.MarginLayoutParams(-1, -2);
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new ViewGroup.MarginLayoutParams(getContext(), attributeSet);
    }

    public /* bridge */ /* synthetic */ int getAnimatedVisibility() {
        return super.getAnimatedVisibility();
    }

    public /* bridge */ /* synthetic */ int getContentHeight() {
        return super.getContentHeight();
    }

    public CharSequence getSubtitle() {
        return this.f792j0;
    }

    public CharSequence getTitle() {
        return this.f791i0;
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        C0027a2 a2Var = this.f17495d0;
        if (a2Var != null) {
            a2Var.mo136c();
            this.f17495d0.mo137d();
        }
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        if (accessibilityEvent.getEventType() == 32) {
            accessibilityEvent.setSource(this);
            accessibilityEvent.setClassName(ActionBarContextView.class.getName());
            accessibilityEvent.setPackageName(getContext().getPackageName());
            accessibilityEvent.setContentDescription(this.f791i0);
            return;
        }
        super.onInitializeAccessibilityEvent(accessibilityEvent);
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5;
        boolean a = C0580e4.m3915a(this);
        int paddingRight = a ? (i3 - i) - getPaddingRight() : getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingTop2 = ((i4 - i2) - getPaddingTop()) - getPaddingBottom();
        View view = this.f793k0;
        if (view == null || view.getVisibility() == 8) {
            i5 = paddingRight;
        } else {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f793k0.getLayoutParams();
            int i6 = a ? marginLayoutParams.rightMargin : marginLayoutParams.leftMargin;
            int i7 = a ? marginLayoutParams.leftMargin : marginLayoutParams.rightMargin;
            int i8 = a ? paddingRight - i6 : paddingRight + i6;
            int a2 = i8 + mo12714a(this.f793k0, i8, paddingTop, paddingTop2, a);
            i5 = a ? a2 - i7 : a2 + i7;
        }
        LinearLayout linearLayout = this.f795m0;
        if (!(linearLayout == null || this.f794l0 != null || linearLayout.getVisibility() == 8)) {
            i5 += mo12714a(this.f795m0, i5, paddingTop, paddingTop2, a);
        }
        int i9 = i5;
        View view2 = this.f794l0;
        if (view2 != null) {
            mo12714a(view2, i9, paddingTop, paddingTop2, a);
        }
        int paddingLeft = a ? getPaddingLeft() : (i3 - i) - getPaddingRight();
        ActionMenuView actionMenuView = this.f17494c0;
        if (actionMenuView != null) {
            mo12714a(actionMenuView, paddingLeft, paddingTop, paddingTop2, !a);
        }
    }

    public void onMeasure(int i, int i2) {
        int i3 = 1073741824;
        if (View.MeasureSpec.getMode(i) != 1073741824) {
            throw new IllegalStateException(ActionBarContextView.class.getSimpleName() + " can only be used with android:layout_width=\"match_parent\" (or fill_parent)");
        } else if (View.MeasureSpec.getMode(i2) != 0) {
            int size = View.MeasureSpec.getSize(i);
            int i4 = this.f17496e0;
            if (i4 <= 0) {
                i4 = View.MeasureSpec.getSize(i2);
            }
            int paddingBottom = getPaddingBottom() + getPaddingTop();
            int paddingLeft = (size - getPaddingLeft()) - getPaddingRight();
            int i5 = i4 - paddingBottom;
            int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(i5, RecyclerView.UNDEFINED_DURATION);
            View view = this.f793k0;
            if (view != null) {
                int a = mo12713a(view, paddingLeft, makeMeasureSpec, 0);
                ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f793k0.getLayoutParams();
                paddingLeft = a - (marginLayoutParams.leftMargin + marginLayoutParams.rightMargin);
            }
            ActionMenuView actionMenuView = this.f17494c0;
            if (actionMenuView != null && actionMenuView.getParent() == this) {
                paddingLeft = mo12713a(this.f17494c0, paddingLeft, makeMeasureSpec, 0);
            }
            LinearLayout linearLayout = this.f795m0;
            if (linearLayout != null && this.f794l0 == null) {
                if (this.f800r0) {
                    this.f795m0.measure(View.MeasureSpec.makeMeasureSpec(0, 0), makeMeasureSpec);
                    int measuredWidth = this.f795m0.getMeasuredWidth();
                    boolean z = measuredWidth <= paddingLeft;
                    if (z) {
                        paddingLeft -= measuredWidth;
                    }
                    this.f795m0.setVisibility(z ? 0 : 8);
                } else {
                    paddingLeft = mo12713a(linearLayout, paddingLeft, makeMeasureSpec, 0);
                }
            }
            View view2 = this.f794l0;
            if (view2 != null) {
                ViewGroup.LayoutParams layoutParams = view2.getLayoutParams();
                int i6 = layoutParams.width != -2 ? 1073741824 : RecyclerView.UNDEFINED_DURATION;
                int i7 = layoutParams.width;
                if (i7 >= 0) {
                    paddingLeft = Math.min(i7, paddingLeft);
                }
                if (layoutParams.height == -2) {
                    i3 = RecyclerView.UNDEFINED_DURATION;
                }
                int i8 = layoutParams.height;
                if (i8 >= 0) {
                    i5 = Math.min(i8, i5);
                }
                this.f794l0.measure(View.MeasureSpec.makeMeasureSpec(paddingLeft, i6), View.MeasureSpec.makeMeasureSpec(i5, i3));
            }
            if (this.f17496e0 <= 0) {
                int childCount = getChildCount();
                i4 = 0;
                for (int i9 = 0; i9 < childCount; i9++) {
                    int measuredHeight = getChildAt(i9).getMeasuredHeight() + paddingBottom;
                    if (measuredHeight > i4) {
                        i4 = measuredHeight;
                    }
                }
            }
            setMeasuredDimension(size, i4);
        } else {
            throw new IllegalStateException(ActionBarContextView.class.getSimpleName() + " can only be used with android:layout_height=\"wrap_content\"");
        }
    }

    public void setContentHeight(int i) {
        this.f17496e0 = i;
    }

    public void setCustomView(View view) {
        LinearLayout linearLayout;
        View view2 = this.f794l0;
        if (view2 != null) {
            removeView(view2);
        }
        this.f794l0 = view;
        if (!(view == null || (linearLayout = this.f795m0) == null)) {
            removeView(linearLayout);
            this.f795m0 = null;
        }
        if (view != null) {
            addView(view);
        }
        requestLayout();
    }

    public void setSubtitle(CharSequence charSequence) {
        this.f792j0 = charSequence;
        mo776b();
    }

    public void setTitle(CharSequence charSequence) {
        this.f791i0 = charSequence;
        mo776b();
    }

    public void setTitleOptional(boolean z) {
        if (z != this.f800r0) {
            requestLayout();
        }
        this.f800r0 = z;
    }

    public /* bridge */ /* synthetic */ void setVisibility(int i) {
        super.setVisibility(i);
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }
}
