package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

public class ActionBarContainer extends FrameLayout {

    /* renamed from: a0 */
    public boolean f781a0;

    /* renamed from: b0 */
    public View f782b0;

    /* renamed from: c0 */
    public View f783c0;

    /* renamed from: d0 */
    public View f784d0;

    /* renamed from: e0 */
    public Drawable f785e0;

    /* renamed from: f0 */
    public Drawable f786f0;

    /* renamed from: g0 */
    public Drawable f787g0;

    /* renamed from: h0 */
    public boolean f788h0;

    /* renamed from: i0 */
    public boolean f789i0;

    /* renamed from: j0 */
    public int f790j0;

    public ActionBarContainer(Context context) {
        this(context, (AttributeSet) null);
    }

    public ActionBarContainer(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        C2189w7.m14987a((View) this, (Drawable) new C2389z1(this));
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C1292m.ActionBar);
        this.f785e0 = obtainStyledAttributes.getDrawable(C1292m.ActionBar_background);
        this.f786f0 = obtainStyledAttributes.getDrawable(C1292m.ActionBar_backgroundStacked);
        this.f790j0 = obtainStyledAttributes.getDimensionPixelSize(C1292m.ActionBar_height, -1);
        if (getId() == C0887i.split_action_bar) {
            this.f788h0 = true;
            this.f787g0 = obtainStyledAttributes.getDrawable(C1292m.ActionBar_backgroundSplit);
        }
        obtainStyledAttributes.recycle();
        boolean z = false;
        if (!this.f788h0 ? this.f785e0 == null && this.f786f0 == null : this.f787g0 == null) {
            z = true;
        }
        setWillNotDraw(z);
    }

    /* renamed from: a */
    public final int mo754a(View view) {
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) view.getLayoutParams();
        return view.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
    }

    /* renamed from: b */
    public final boolean mo755b(View view) {
        return view == null || view.getVisibility() == 8 || view.getMeasuredHeight() == 0;
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.f785e0;
        if (drawable != null && drawable.isStateful()) {
            this.f785e0.setState(getDrawableState());
        }
        Drawable drawable2 = this.f786f0;
        if (drawable2 != null && drawable2.isStateful()) {
            this.f786f0.setState(getDrawableState());
        }
        Drawable drawable3 = this.f787g0;
        if (drawable3 != null && drawable3.isStateful()) {
            this.f787g0.setState(getDrawableState());
        }
    }

    public View getTabContainer() {
        return this.f782b0;
    }

    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f785e0;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
        Drawable drawable2 = this.f786f0;
        if (drawable2 != null) {
            drawable2.jumpToCurrentState();
        }
        Drawable drawable3 = this.f787g0;
        if (drawable3 != null) {
            drawable3.jumpToCurrentState();
        }
    }

    public void onFinishInflate() {
        super.onFinishInflate();
        this.f783c0 = findViewById(C0887i.action_bar);
        this.f784d0 = findViewById(C0887i.action_context_bar);
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        super.onHoverEvent(motionEvent);
        return true;
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return this.f781a0 || super.onInterceptTouchEvent(motionEvent);
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        Drawable drawable;
        Drawable drawable2;
        int left;
        int top;
        int right;
        View view;
        super.onLayout(z, i, i2, i3, i4);
        View view2 = this.f782b0;
        boolean z2 = true;
        boolean z3 = false;
        boolean z4 = (view2 == null || view2.getVisibility() == 8) ? false : true;
        if (!(view2 == null || view2.getVisibility() == 8)) {
            int measuredHeight = getMeasuredHeight();
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) view2.getLayoutParams();
            view2.layout(i, (measuredHeight - view2.getMeasuredHeight()) - layoutParams.bottomMargin, i3, measuredHeight - layoutParams.bottomMargin);
        }
        if (this.f788h0) {
            Drawable drawable3 = this.f787g0;
            if (drawable3 != null) {
                drawable3.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            } else {
                z2 = false;
            }
        } else {
            if (this.f785e0 != null) {
                if (this.f783c0.getVisibility() == 0) {
                    drawable2 = this.f785e0;
                    left = this.f783c0.getLeft();
                    top = this.f783c0.getTop();
                    right = this.f783c0.getRight();
                    view = this.f783c0;
                } else {
                    View view3 = this.f784d0;
                    if (view3 == null || view3.getVisibility() != 0) {
                        this.f785e0.setBounds(0, 0, 0, 0);
                        z3 = true;
                    } else {
                        drawable2 = this.f785e0;
                        left = this.f784d0.getLeft();
                        top = this.f784d0.getTop();
                        right = this.f784d0.getRight();
                        view = this.f784d0;
                    }
                }
                drawable2.setBounds(left, top, right, view.getBottom());
                z3 = true;
            }
            this.f789i0 = z4;
            if (!z4 || (drawable = this.f786f0) == null) {
                z2 = z3;
            } else {
                drawable.setBounds(view2.getLeft(), view2.getTop(), view2.getRight(), view2.getBottom());
            }
        }
        if (z2) {
            invalidate();
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:25:0x0055  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x005a  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r4, int r5) {
        /*
            r3 = this;
            android.view.View r0 = r3.f783c0
            r1 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r0 != 0) goto L_0x001c
            int r0 = android.view.View.MeasureSpec.getMode(r5)
            if (r0 != r1) goto L_0x001c
            int r0 = r3.f790j0
            if (r0 < 0) goto L_0x001c
            int r5 = android.view.View.MeasureSpec.getSize(r5)
            int r5 = java.lang.Math.min(r0, r5)
            int r5 = android.view.View.MeasureSpec.makeMeasureSpec(r5, r1)
        L_0x001c:
            super.onMeasure(r4, r5)
            android.view.View r4 = r3.f783c0
            if (r4 != 0) goto L_0x0024
            return
        L_0x0024:
            int r4 = android.view.View.MeasureSpec.getMode(r5)
            android.view.View r0 = r3.f782b0
            if (r0 == 0) goto L_0x006f
            int r0 = r0.getVisibility()
            r2 = 8
            if (r0 == r2) goto L_0x006f
            r0 = 1073741824(0x40000000, float:2.0)
            if (r4 == r0) goto L_0x006f
            android.view.View r0 = r3.f783c0
            boolean r0 = r3.mo755b(r0)
            if (r0 != 0) goto L_0x0047
            android.view.View r0 = r3.f783c0
        L_0x0042:
            int r0 = r3.mo754a(r0)
            goto L_0x0053
        L_0x0047:
            android.view.View r0 = r3.f784d0
            boolean r0 = r3.mo755b(r0)
            if (r0 != 0) goto L_0x0052
            android.view.View r0 = r3.f784d0
            goto L_0x0042
        L_0x0052:
            r0 = 0
        L_0x0053:
            if (r4 != r1) goto L_0x005a
            int r4 = android.view.View.MeasureSpec.getSize(r5)
            goto L_0x005d
        L_0x005a:
            r4 = 2147483647(0x7fffffff, float:NaN)
        L_0x005d:
            int r5 = r3.getMeasuredWidth()
            android.view.View r1 = r3.f782b0
            int r1 = r3.mo754a(r1)
            int r1 = r1 + r0
            int r4 = java.lang.Math.min(r1, r4)
            r3.setMeasuredDimension(r5, r4)
        L_0x006f:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionBarContainer.onMeasure(int, int):void");
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        super.onTouchEvent(motionEvent);
        return true;
    }

    public void setPrimaryBackground(Drawable drawable) {
        Drawable drawable2 = this.f785e0;
        if (drawable2 != null) {
            drawable2.setCallback((Drawable.Callback) null);
            unscheduleDrawable(this.f785e0);
        }
        this.f785e0 = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            View view = this.f783c0;
            if (view != null) {
                this.f785e0.setBounds(view.getLeft(), this.f783c0.getTop(), this.f783c0.getRight(), this.f783c0.getBottom());
            }
        }
        boolean z = true;
        if (!this.f788h0 ? !(this.f785e0 == null && this.f786f0 == null) : this.f787g0 != null) {
            z = false;
        }
        setWillNotDraw(z);
        invalidate();
        if (Build.VERSION.SDK_INT >= 21) {
            invalidateOutline();
        }
    }

    public void setSplitBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.f787g0;
        if (drawable3 != null) {
            drawable3.setCallback((Drawable.Callback) null);
            unscheduleDrawable(this.f787g0);
        }
        this.f787g0 = drawable;
        boolean z = false;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.f788h0 && (drawable2 = this.f787g0) != null) {
                drawable2.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
            }
        }
        if (!this.f788h0 ? this.f785e0 == null && this.f786f0 == null : this.f787g0 == null) {
            z = true;
        }
        setWillNotDraw(z);
        invalidate();
        if (Build.VERSION.SDK_INT >= 21) {
            invalidateOutline();
        }
    }

    public void setStackedBackground(Drawable drawable) {
        Drawable drawable2;
        Drawable drawable3 = this.f786f0;
        if (drawable3 != null) {
            drawable3.setCallback((Drawable.Callback) null);
            unscheduleDrawable(this.f786f0);
        }
        this.f786f0 = drawable;
        if (drawable != null) {
            drawable.setCallback(this);
            if (this.f789i0 && (drawable2 = this.f786f0) != null) {
                drawable2.setBounds(this.f782b0.getLeft(), this.f782b0.getTop(), this.f782b0.getRight(), this.f782b0.getBottom());
            }
        }
        boolean z = true;
        if (!this.f788h0 ? !(this.f785e0 == null && this.f786f0 == null) : this.f787g0 != null) {
            z = false;
        }
        setWillNotDraw(z);
        invalidate();
        if (Build.VERSION.SDK_INT >= 21) {
            invalidateOutline();
        }
    }

    public void setTabContainer(C1661q3 q3Var) {
        View view = this.f782b0;
        if (view != null) {
            removeView(view);
        }
        this.f782b0 = q3Var;
        if (q3Var != null) {
            addView(q3Var);
            ViewGroup.LayoutParams layoutParams = q3Var.getLayoutParams();
            layoutParams.width = -1;
            layoutParams.height = -2;
            q3Var.setAllowCollapse(false);
        }
    }

    public void setTransitioning(boolean z) {
        this.f781a0 = z;
        setDescendantFocusability(z ? 393216 : 262144);
    }

    public void setVisibility(int i) {
        super.setVisibility(i);
        boolean z = i == 0;
        Drawable drawable = this.f785e0;
        if (drawable != null) {
            drawable.setVisible(z, false);
        }
        Drawable drawable2 = this.f786f0;
        if (drawable2 != null) {
            drawable2.setVisible(z, false);
        }
        Drawable drawable3 = this.f787g0;
        if (drawable3 != null) {
            drawable3.setVisible(z, false);
        }
    }

    public ActionMode startActionModeForChild(View view, ActionMode.Callback callback) {
        return null;
    }

    public ActionMode startActionModeForChild(View view, ActionMode.Callback callback, int i) {
        if (i != 0) {
            return super.startActionModeForChild(view, callback, i);
        }
        return null;
    }

    public boolean verifyDrawable(Drawable drawable) {
        return (drawable == this.f785e0 && !this.f788h0) || (drawable == this.f786f0 && this.f789i0) || ((drawable == this.f787g0 && this.f788h0) || super.verifyDrawable(drawable));
    }
}
