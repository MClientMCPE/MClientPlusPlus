package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewDebug;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.RecyclerView;
import p000.C0027a2;
import p000.C0639f3;
import p000.C0816h1;
import p000.C1581p1;

public class ActionMenuView extends C0639f3 implements C0816h1.C0818b, C1655q1 {

    /* renamed from: A0 */
    public C0142e f834A0;

    /* renamed from: p0 */
    public C0816h1 f835p0;

    /* renamed from: q0 */
    public Context f836q0;

    /* renamed from: r0 */
    public int f837r0;

    /* renamed from: s0 */
    public boolean f838s0;

    /* renamed from: t0 */
    public C0027a2 f839t0;

    /* renamed from: u0 */
    public C1581p1.C1582a f840u0;

    /* renamed from: v0 */
    public C0816h1.C0817a f841v0;

    /* renamed from: w0 */
    public boolean f842w0;

    /* renamed from: x0 */
    public int f843x0;

    /* renamed from: y0 */
    public int f844y0;

    /* renamed from: z0 */
    public int f845z0;

    /* renamed from: androidx.appcompat.widget.ActionMenuView$a */
    public interface C0138a {
        /* renamed from: j */
        boolean mo142j();

        /* renamed from: k */
        boolean mo143k();
    }

    /* renamed from: androidx.appcompat.widget.ActionMenuView$b */
    public static class C0139b implements C1581p1.C1582a {
        /* renamed from: a */
        public void mo55a(C0816h1 h1Var, boolean z) {
        }

        /* renamed from: a */
        public boolean mo56a(C0816h1 h1Var) {
            return false;
        }
    }

    /* renamed from: androidx.appcompat.widget.ActionMenuView$c */
    public static class C0140c extends C0639f3.C0640a {
        @ViewDebug.ExportedProperty

        /* renamed from: c */
        public boolean f846c;
        @ViewDebug.ExportedProperty

        /* renamed from: d */
        public int f847d;
        @ViewDebug.ExportedProperty

        /* renamed from: e */
        public int f848e;
        @ViewDebug.ExportedProperty

        /* renamed from: f */
        public boolean f849f;
        @ViewDebug.ExportedProperty

        /* renamed from: g */
        public boolean f850g;

        /* renamed from: h */
        public boolean f851h;

        public C0140c(int i, int i2) {
            super(i, i2);
            this.f846c = false;
        }

        public C0140c(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public C0140c(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public C0140c(C0140c cVar) {
            super(cVar);
            this.f846c = cVar.f846c;
        }
    }

    /* renamed from: androidx.appcompat.widget.ActionMenuView$d */
    public class C0141d implements C0816h1.C0817a {
        public C0141d() {
        }

        /* renamed from: a */
        public void mo19a(C0816h1 h1Var) {
            C0816h1.C0817a aVar = ActionMenuView.this.f841v0;
            if (aVar != null) {
                aVar.mo19a(h1Var);
            }
        }

        /* renamed from: a */
        public boolean mo24a(C0816h1 h1Var, MenuItem menuItem) {
            C0142e eVar = ActionMenuView.this.f834A0;
            if (eVar == null) {
                return false;
            }
            Toolbar.C0167f fVar = Toolbar.this.f950G0;
            return fVar != null ? fVar.onMenuItemClick(menuItem) : false;
        }
    }

    /* renamed from: androidx.appcompat.widget.ActionMenuView$e */
    public interface C0142e {
    }

    public ActionMenuView(Context context) {
        this(context, (AttributeSet) null);
    }

    public ActionMenuView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        setBaselineAligned(false);
        float f = context.getResources().getDisplayMetrics().density;
        this.f844y0 = (int) (56.0f * f);
        this.f845z0 = (int) (f * 4.0f);
        this.f836q0 = context;
        this.f837r0 = 0;
    }

    /* renamed from: b */
    public static int m702b(View view, int i, int i2, int i3, int i4) {
        C0140c cVar = (C0140c) view.getLayoutParams();
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(i3) - i4, View.MeasureSpec.getMode(i3));
        ActionMenuItemView actionMenuItemView = view instanceof ActionMenuItemView ? (ActionMenuItemView) view : null;
        boolean z = true;
        boolean z2 = actionMenuItemView != null && actionMenuItemView.mo719l();
        int i5 = 2;
        if (i2 <= 0 || (z2 && i2 < 2)) {
            i5 = 0;
        } else {
            view.measure(View.MeasureSpec.makeMeasureSpec(i2 * i, RecyclerView.UNDEFINED_DURATION), makeMeasureSpec);
            int measuredWidth = view.getMeasuredWidth();
            int i6 = measuredWidth / i;
            if (measuredWidth % i != 0) {
                i6++;
            }
            if (!z2 || i6 >= 2) {
                i5 = i6;
            }
        }
        if (cVar.f846c || !z2) {
            z = false;
        }
        cVar.f849f = z;
        cVar.f847d = i5;
        view.measure(View.MeasureSpec.makeMeasureSpec(i * i5, 1073741824), makeMeasureSpec);
        return i5;
    }

    /* renamed from: a */
    public void mo735a(C0816h1 h1Var) {
        this.f835p0 = h1Var;
    }

    /* renamed from: a */
    public void mo858a(C1581p1.C1582a aVar, C0816h1.C0817a aVar2) {
        this.f840u0 = aVar;
        this.f841v0 = aVar2;
    }

    /* renamed from: a */
    public boolean mo736a(C1115k1 k1Var) {
        return this.f835p0.mo6290a((MenuItem) k1Var, (C1581p1) null, 0);
    }

    /* renamed from: c */
    public boolean mo859c(int i) {
        boolean z = false;
        if (i == 0) {
            return false;
        }
        View childAt = getChildAt(i - 1);
        View childAt2 = getChildAt(i);
        if (i < getChildCount() && (childAt instanceof C0138a)) {
            z = false | ((C0138a) childAt).mo142j();
        }
        return (i <= 0 || !(childAt2 instanceof C0138a)) ? z : z | ((C0138a) childAt2).mo143k();
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0140c;
    }

    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        return false;
    }

    /* renamed from: g */
    public void mo862g() {
        C0027a2 a2Var = this.f839t0;
        if (a2Var != null) {
            a2Var.mo135b();
        }
    }

    public C0140c generateDefaultLayoutParams() {
        C0140c cVar = new C0140c(-2, -2);
        cVar.f4963b = 16;
        return cVar;
    }

    public C0140c generateLayoutParams(AttributeSet attributeSet) {
        return new C0140c(getContext(), attributeSet);
    }

    public C0140c generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams == null) {
            return generateDefaultLayoutParams();
        }
        C0140c cVar = layoutParams instanceof C0140c ? new C0140c((C0140c) layoutParams) : new C0140c(layoutParams);
        if (cVar.f4963b <= 0) {
            cVar.f4963b = 16;
        }
        return cVar;
    }

    public Menu getMenu() {
        if (this.f835p0 == null) {
            Context context = getContext();
            this.f835p0 = new C0816h1(context);
            this.f835p0.mo6284a((C0816h1.C0817a) new C0141d());
            this.f839t0 = new C0027a2(context);
            C0027a2 a2Var = this.f839t0;
            a2Var.f112i0 = true;
            a2Var.f113j0 = true;
            C1581p1.C1582a aVar = this.f840u0;
            if (aVar == null) {
                aVar = new C0139b();
            }
            a2Var.f2416b0 = aVar;
            this.f835p0.mo6287a((C1581p1) this.f839t0, this.f836q0);
            C0027a2 a2Var2 = this.f839t0;
            a2Var2.f2419e0 = this;
            mo735a(a2Var2.f2414Z);
        }
        return this.f835p0;
    }

    public Drawable getOverflowIcon() {
        getMenu();
        C0027a2 a2Var = this.f839t0;
        C0027a2.C0031d dVar = a2Var.f109f0;
        if (dVar != null) {
            return dVar.getDrawable();
        }
        if (a2Var.f111h0) {
            return a2Var.f110g0;
        }
        return null;
    }

    public int getPopupTheme() {
        return this.f837r0;
    }

    public int getWindowAnimations() {
        return 0;
    }

    /* renamed from: h */
    public C0140c mo870h() {
        C0140c generateDefaultLayoutParams = generateDefaultLayoutParams();
        generateDefaultLayoutParams.f846c = true;
        return generateDefaultLayoutParams;
    }

    /* renamed from: j */
    public boolean mo871j() {
        C0027a2 a2Var = this.f839t0;
        return a2Var != null && a2Var.mo136c();
    }

    /* renamed from: k */
    public boolean mo872k() {
        C0027a2 a2Var = this.f839t0;
        if (a2Var != null) {
            if (a2Var.f125v0 != null || a2Var.mo138e()) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: l */
    public boolean mo873l() {
        C0027a2 a2Var = this.f839t0;
        return a2Var != null && a2Var.mo138e();
    }

    /* renamed from: m */
    public boolean mo874m() {
        return this.f838s0;
    }

    /* renamed from: n */
    public C0816h1 mo875n() {
        return this.f835p0;
    }

    /* renamed from: o */
    public boolean mo876o() {
        C0027a2 a2Var = this.f839t0;
        return a2Var != null && a2Var.mo139f();
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        C0027a2 a2Var = this.f839t0;
        if (a2Var != null) {
            a2Var.mo131a(false);
            if (this.f839t0.mo138e()) {
                this.f839t0.mo136c();
                this.f839t0.mo139f();
            }
        }
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        mo862g();
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5;
        int i6;
        int i7;
        int i8;
        if (this.f842w0) {
            int childCount = getChildCount();
            int i9 = (i4 - i2) / 2;
            int dividerWidth = getDividerWidth();
            int i10 = i3 - i;
            int paddingRight = (i10 - getPaddingRight()) - getPaddingLeft();
            boolean a = C0580e4.m3915a(this);
            int i11 = 0;
            int i12 = 0;
            for (int i13 = 0; i13 < childCount; i13++) {
                View childAt = getChildAt(i13);
                if (childAt.getVisibility() != 8) {
                    C0140c cVar = (C0140c) childAt.getLayoutParams();
                    if (cVar.f846c) {
                        int measuredWidth = childAt.getMeasuredWidth();
                        if (mo859c(i13)) {
                            measuredWidth += dividerWidth;
                        }
                        int measuredHeight = childAt.getMeasuredHeight();
                        if (a) {
                            i7 = getPaddingLeft() + cVar.leftMargin;
                            i8 = i7 + measuredWidth;
                        } else {
                            i8 = (getWidth() - getPaddingRight()) - cVar.rightMargin;
                            i7 = i8 - measuredWidth;
                        }
                        int i14 = i9 - (measuredHeight / 2);
                        childAt.layout(i7, i14, i8, measuredHeight + i14);
                        paddingRight -= measuredWidth;
                        i11 = 1;
                    } else {
                        paddingRight -= (childAt.getMeasuredWidth() + cVar.leftMargin) + cVar.rightMargin;
                        mo859c(i13);
                        i12++;
                    }
                }
            }
            if (childCount == 1 && i11 == 0) {
                View childAt2 = getChildAt(0);
                int measuredWidth2 = childAt2.getMeasuredWidth();
                int measuredHeight2 = childAt2.getMeasuredHeight();
                int i15 = (i10 / 2) - (measuredWidth2 / 2);
                int i16 = i9 - (measuredHeight2 / 2);
                childAt2.layout(i15, i16, measuredWidth2 + i15, measuredHeight2 + i16);
                return;
            }
            int i17 = i12 - (i11 ^ 1);
            if (i17 > 0) {
                i6 = paddingRight / i17;
                i5 = 0;
            } else {
                i5 = 0;
                i6 = 0;
            }
            int max = Math.max(i5, i6);
            if (a) {
                int width = getWidth() - getPaddingRight();
                while (i5 < childCount) {
                    View childAt3 = getChildAt(i5);
                    C0140c cVar2 = (C0140c) childAt3.getLayoutParams();
                    if (childAt3.getVisibility() != 8 && !cVar2.f846c) {
                        int i18 = width - cVar2.rightMargin;
                        int measuredWidth3 = childAt3.getMeasuredWidth();
                        int measuredHeight3 = childAt3.getMeasuredHeight();
                        int i19 = i9 - (measuredHeight3 / 2);
                        childAt3.layout(i18 - measuredWidth3, i19, i18, measuredHeight3 + i19);
                        width = i18 - ((measuredWidth3 + cVar2.leftMargin) + max);
                    }
                    i5++;
                }
                return;
            }
            int paddingLeft = getPaddingLeft();
            while (i5 < childCount) {
                View childAt4 = getChildAt(i5);
                C0140c cVar3 = (C0140c) childAt4.getLayoutParams();
                if (childAt4.getVisibility() != 8 && !cVar3.f846c) {
                    int i20 = paddingLeft + cVar3.leftMargin;
                    int measuredWidth4 = childAt4.getMeasuredWidth();
                    int measuredHeight4 = childAt4.getMeasuredHeight();
                    int i21 = i9 - (measuredHeight4 / 2);
                    childAt4.layout(i20, i21, i20 + measuredWidth4, measuredHeight4 + i21);
                    paddingLeft = C0789gk.m5547a(measuredWidth4, cVar3.rightMargin, max, i20);
                }
                i5++;
            }
        } else if (this.f4950d0 == 1) {
            mo5301b(i, i2, i3, i4);
        } else {
            mo5296a(i, i2, i3, i4);
        }
    }

    public void onMeasure(int i, int i2) {
        int i3;
        boolean z;
        int i4;
        int i5;
        int i6;
        int i7;
        boolean z2;
        C0816h1 h1Var;
        boolean z3 = this.f842w0;
        this.f842w0 = View.MeasureSpec.getMode(i) == 1073741824;
        if (z3 != this.f842w0) {
            this.f843x0 = 0;
        }
        int size = View.MeasureSpec.getSize(i);
        if (!(!this.f842w0 || (h1Var = this.f835p0) == null || size == this.f843x0)) {
            this.f843x0 = size;
            h1Var.mo6304b(true);
        }
        int childCount = getChildCount();
        if (!this.f842w0 || childCount <= 0) {
            int i8 = i2;
            for (int i9 = 0; i9 < childCount; i9++) {
                C0140c cVar = (C0140c) getChildAt(i9).getLayoutParams();
                cVar.rightMargin = 0;
                cVar.leftMargin = 0;
            }
            if (this.f4950d0 == 1) {
                mo5308d(i, i2);
            } else {
                mo5306c(i, i2);
            }
        } else {
            int mode = View.MeasureSpec.getMode(i2);
            int size2 = View.MeasureSpec.getSize(i);
            int size3 = View.MeasureSpec.getSize(i2);
            int paddingRight = getPaddingRight() + getPaddingLeft();
            int paddingBottom = getPaddingBottom() + getPaddingTop();
            int childMeasureSpec = ViewGroup.getChildMeasureSpec(i2, paddingBottom, -2);
            int i10 = size2 - paddingRight;
            int i11 = this.f844y0;
            int i12 = i10 / i11;
            int i13 = i10 % i11;
            if (i12 == 0) {
                setMeasuredDimension(i10, 0);
                return;
            }
            int i14 = (i13 / i12) + i11;
            int childCount2 = getChildCount();
            int i15 = i12;
            int i16 = 0;
            int i17 = 0;
            int i18 = 0;
            boolean z4 = false;
            int i19 = 0;
            int i20 = 0;
            long j = 0;
            while (i17 < childCount2) {
                View childAt = getChildAt(i17);
                if (childAt.getVisibility() == 8) {
                    i7 = size3;
                } else {
                    boolean z5 = childAt instanceof ActionMenuItemView;
                    i19++;
                    if (z5) {
                        int i21 = this.f845z0;
                        i7 = size3;
                        z2 = false;
                        childAt.setPadding(i21, 0, i21, 0);
                    } else {
                        i7 = size3;
                        z2 = false;
                    }
                    C0140c cVar2 = (C0140c) childAt.getLayoutParams();
                    cVar2.f851h = z2;
                    cVar2.f848e = z2 ? 1 : 0;
                    cVar2.f847d = z2;
                    cVar2.f849f = z2;
                    cVar2.leftMargin = z2;
                    cVar2.rightMargin = z2;
                    cVar2.f850g = z5 && ((ActionMenuItemView) childAt).mo719l();
                    int b = m702b(childAt, i14, cVar2.f846c ? 1 : i15, childMeasureSpec, paddingBottom);
                    i16 = Math.max(i16, b);
                    if (cVar2.f849f) {
                        i20++;
                    }
                    if (cVar2.f846c) {
                        z4 = true;
                    }
                    i15 -= b;
                    int max = Math.max(i18, childAt.getMeasuredHeight());
                    if (b == 1) {
                        j |= (long) (1 << i17);
                    }
                    i18 = max;
                }
                i17++;
                size3 = i7;
            }
            int i22 = size3;
            boolean z6 = z4 && i19 == 2;
            int i23 = i15;
            boolean z7 = false;
            while (true) {
                if (i20 <= 0 || i23 <= 0) {
                    i5 = mode;
                    i3 = i10;
                    z = z7;
                    i4 = i18;
                } else {
                    int i24 = Integer.MAX_VALUE;
                    int i25 = 0;
                    int i26 = 0;
                    long j2 = 0;
                    while (i25 < childCount2) {
                        boolean z8 = z7;
                        C0140c cVar3 = (C0140c) getChildAt(i25).getLayoutParams();
                        int i27 = i18;
                        if (cVar3.f849f) {
                            int i28 = cVar3.f847d;
                            if (i28 < i24) {
                                i24 = i28;
                                j2 = 1 << i25;
                                i26 = 1;
                            } else if (i28 == i24) {
                                j2 |= 1 << i25;
                                i26++;
                            }
                        }
                        i25++;
                        i18 = i27;
                        z7 = z8;
                    }
                    z = z7;
                    i4 = i18;
                    j |= j2;
                    if (i26 > i23) {
                        i5 = mode;
                        i3 = i10;
                        break;
                    }
                    int i29 = i24 + 1;
                    int i30 = i23;
                    int i31 = 0;
                    while (i31 < childCount2) {
                        View childAt2 = getChildAt(i31);
                        C0140c cVar4 = (C0140c) childAt2.getLayoutParams();
                        int i32 = i10;
                        int i33 = mode;
                        long j3 = (long) (1 << i31);
                        if ((j2 & j3) == 0) {
                            if (cVar4.f847d == i29) {
                                j |= j3;
                            }
                            i6 = i29;
                        } else {
                            if (!z6 || !cVar4.f850g || i30 != 1) {
                                i6 = i29;
                            } else {
                                int i34 = this.f845z0;
                                i6 = i29;
                                childAt2.setPadding(i34 + i14, 0, i34, 0);
                            }
                            cVar4.f847d++;
                            cVar4.f851h = true;
                            i30--;
                        }
                        i31++;
                        mode = i33;
                        i29 = i6;
                        i10 = i32;
                    }
                    i23 = i30;
                    i18 = i4;
                    z7 = true;
                }
            }
            boolean z9 = !z4 && i19 == 1;
            if (i23 > 0 && j != 0 && (i23 < i19 - 1 || z9 || i16 > 1)) {
                float bitCount = (float) Long.bitCount(j);
                if (!z9) {
                    if ((j & 1) != 0 && !((C0140c) getChildAt(0).getLayoutParams()).f850g) {
                        bitCount -= 0.5f;
                    }
                    int i35 = childCount2 - 1;
                    if ((j & ((long) (1 << i35))) != 0 && !((C0140c) getChildAt(i35).getLayoutParams()).f850g) {
                        bitCount -= 0.5f;
                    }
                }
                int i36 = bitCount > 0.0f ? (int) (((float) (i23 * i14)) / bitCount) : 0;
                boolean z10 = z;
                for (int i37 = 0; i37 < childCount2; i37++) {
                    if ((j & ((long) (1 << i37))) != 0) {
                        View childAt3 = getChildAt(i37);
                        C0140c cVar5 = (C0140c) childAt3.getLayoutParams();
                        if (childAt3 instanceof ActionMenuItemView) {
                            cVar5.f848e = i36;
                            cVar5.f851h = true;
                            if (i37 == 0 && !cVar5.f850g) {
                                cVar5.leftMargin = (-i36) / 2;
                            }
                        } else if (cVar5.f846c) {
                            cVar5.f848e = i36;
                            cVar5.f851h = true;
                            cVar5.rightMargin = (-i36) / 2;
                        } else {
                            if (i37 != 0) {
                                cVar5.leftMargin = i36 / 2;
                            }
                            if (i37 != childCount2 - 1) {
                                cVar5.rightMargin = i36 / 2;
                            }
                        }
                        z10 = true;
                    }
                }
                z = z10;
            }
            if (z) {
                for (int i38 = 0; i38 < childCount2; i38++) {
                    View childAt4 = getChildAt(i38);
                    C0140c cVar6 = (C0140c) childAt4.getLayoutParams();
                    if (cVar6.f851h) {
                        childAt4.measure(View.MeasureSpec.makeMeasureSpec((cVar6.f847d * i14) + cVar6.f848e, 1073741824), childMeasureSpec);
                    }
                }
            }
            setMeasuredDimension(i3, i5 != 1073741824 ? i4 : i22);
        }
    }

    public void setExpandedActionViewsExclusive(boolean z) {
        this.f839t0.f120q0 = z;
    }

    public void setOnMenuItemClickListener(C0142e eVar) {
        this.f834A0 = eVar;
    }

    public void setOverflowIcon(Drawable drawable) {
        getMenu();
        C0027a2 a2Var = this.f839t0;
        C0027a2.C0031d dVar = a2Var.f109f0;
        if (dVar != null) {
            dVar.setImageDrawable(drawable);
            return;
        }
        a2Var.f111h0 = true;
        a2Var.f110g0 = drawable;
    }

    public void setOverflowReserved(boolean z) {
        this.f838s0 = z;
    }

    public void setPopupTheme(int i) {
        if (this.f837r0 != i) {
            this.f837r0 = i;
            if (i == 0) {
                this.f836q0 = getContext();
            } else {
                this.f836q0 = new ContextThemeWrapper(getContext(), i);
            }
        }
    }

    public void setPresenter(C0027a2 a2Var) {
        this.f839t0 = a2Var;
        C0027a2 a2Var2 = this.f839t0;
        a2Var2.f2419e0 = this;
        mo735a(a2Var2.f2414Z);
    }
}
