package androidx.appcompat.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import p000.C2327y6;

public class AppCompatTextView extends TextView implements C2097v7, C1504o8, C1133k8 {

    /* renamed from: a0 */
    public final C0334c2 f854a0;

    /* renamed from: b0 */
    public final C2176w2 f855b0;

    /* renamed from: c0 */
    public final C2082v2 f856c0;

    /* renamed from: d0 */
    public Future<C2327y6> f857d0;

    public AppCompatTextView(Context context) {
        this(context, (AttributeSet) null);
    }

    public AppCompatTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 16842884);
    }

    public AppCompatTextView(Context context, AttributeSet attributeSet, int i) {
        super(C2083v3.m14434a(context), attributeSet, i);
        this.f854a0 = new C0334c2(this);
        this.f854a0.mo2717a(attributeSet, i);
        this.f855b0 = new C2176w2(this);
        this.f855b0.mo12087a(attributeSet, i);
        this.f855b0.mo12081a();
        this.f856c0 = new C2082v2(this);
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        C0334c2 c2Var = this.f854a0;
        if (c2Var != null) {
            c2Var.mo2713a();
        }
        C2176w2 w2Var = this.f855b0;
        if (w2Var != null) {
            w2Var.mo12081a();
        }
    }

    public int getAutoSizeMaxTextSize() {
        if (C1133k8.f8952a) {
            return super.getAutoSizeMaxTextSize();
        }
        C2176w2 w2Var = this.f855b0;
        if (w2Var != null) {
            return w2Var.mo12089b();
        }
        return -1;
    }

    public int getAutoSizeMinTextSize() {
        if (C1133k8.f8952a) {
            return super.getAutoSizeMinTextSize();
        }
        C2176w2 w2Var = this.f855b0;
        if (w2Var != null) {
            return w2Var.mo12090c();
        }
        return -1;
    }

    public int getAutoSizeStepGranularity() {
        if (C1133k8.f8952a) {
            return super.getAutoSizeStepGranularity();
        }
        C2176w2 w2Var = this.f855b0;
        if (w2Var != null) {
            return w2Var.mo12091d();
        }
        return -1;
    }

    public int[] getAutoSizeTextAvailableSizes() {
        if (C1133k8.f8952a) {
            return super.getAutoSizeTextAvailableSizes();
        }
        C2176w2 w2Var = this.f855b0;
        return w2Var != null ? w2Var.mo12092e() : new int[0];
    }

    @SuppressLint({"WrongConstant"})
    public int getAutoSizeTextType() {
        if (C1133k8.f8952a) {
            return super.getAutoSizeTextType() == 1 ? 1 : 0;
        }
        C2176w2 w2Var = this.f855b0;
        if (w2Var != null) {
            return w2Var.mo12093f();
        }
        return 0;
    }

    public int getFirstBaselineToTopHeight() {
        return getPaddingTop() - getPaint().getFontMetricsInt().top;
    }

    public int getLastBaselineToBottomHeight() {
        return getPaddingBottom() + getPaint().getFontMetricsInt().bottom;
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0334c2 c2Var = this.f854a0;
        if (c2Var != null) {
            return c2Var.mo2718b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0334c2 c2Var = this.f854a0;
        if (c2Var != null) {
            return c2Var.mo2720c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        C2179w3 w3Var = this.f855b0.f16500h;
        if (w3Var != null) {
            return w3Var.f16519a;
        }
        return null;
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        C2179w3 w3Var = this.f855b0.f16500h;
        if (w3Var != null) {
            return w3Var.f16520b;
        }
        return null;
    }

    public CharSequence getText() {
        Future<C2327y6> future = this.f857d0;
        if (future != null) {
            try {
                this.f857d0 = null;
                C0815h0.m5818a((TextView) this, future.get());
            } catch (InterruptedException | ExecutionException unused) {
            }
        }
        return super.getText();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0006, code lost:
        r0 = r2.f856c0;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public android.view.textclassifier.TextClassifier getTextClassifier() {
        /*
            r2 = this;
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 28
            if (r0 >= r1) goto L_0x0010
            v2 r0 = r2.f856c0
            if (r0 != 0) goto L_0x000b
            goto L_0x0010
        L_0x000b:
            android.view.textclassifier.TextClassifier r0 = r0.mo11799a()
            return r0
        L_0x0010:
            android.view.textclassifier.TextClassifier r0 = super.getTextClassifier()
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.AppCompatTextView.getTextClassifier():android.view.textclassifier.TextClassifier");
    }

    public C2327y6.C2328a getTextMetricsParamsCompat() {
        return C0815h0.m5852c((TextView) this);
    }

    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        C0815h0.m5787a(onCreateInputConnection, editorInfo, (View) this);
        return onCreateInputConnection;
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        C2176w2 w2Var = this.f855b0;
        if (w2Var != null && !C1133k8.f8952a) {
            w2Var.f16501i.mo12417a();
        }
    }

    public void onMeasure(int i, int i2) {
        Future<C2327y6> future = this.f857d0;
        if (future != null) {
            try {
                this.f857d0 = null;
                C0815h0.m5818a((TextView) this, future.get());
            } catch (InterruptedException | ExecutionException unused) {
            }
        }
        super.onMeasure(i, i2);
    }

    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        super.onTextChanged(charSequence, i, i2, i3);
        C2176w2 w2Var = this.f855b0;
        if (w2Var != null && !C1133k8.f8952a && w2Var.mo12094g()) {
            this.f855b0.f16501i.mo12417a();
        }
    }

    public void setAutoSizeTextTypeUniformWithConfiguration(int i, int i2, int i3, int i4) {
        if (C1133k8.f8952a) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i, i2, i3, i4);
            return;
        }
        C2176w2 w2Var = this.f855b0;
        if (w2Var != null) {
            w2Var.mo12083a(i, i2, i3, i4);
        }
    }

    public void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i) {
        if (C1133k8.f8952a) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i);
            return;
        }
        C2176w2 w2Var = this.f855b0;
        if (w2Var != null) {
            w2Var.mo12088a(iArr, i);
        }
    }

    public void setAutoSizeTextTypeWithDefaults(int i) {
        if (C1133k8.f8952a) {
            super.setAutoSizeTextTypeWithDefaults(i);
            return;
        }
        C2176w2 w2Var = this.f855b0;
        if (w2Var != null) {
            w2Var.mo12082a(i);
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0334c2 c2Var = this.f854a0;
        if (c2Var != null) {
            c2Var.mo2721d();
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C0334c2 c2Var = this.f854a0;
        if (c2Var != null) {
            c2Var.mo2714a(i);
        }
    }

    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        C2176w2 w2Var = this.f855b0;
        if (w2Var != null) {
            w2Var.mo12081a();
        }
    }

    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        C2176w2 w2Var = this.f855b0;
        if (w2Var != null) {
            w2Var.mo12081a();
        }
    }

    public void setCompoundDrawablesRelativeWithIntrinsicBounds(int i, int i2, int i3, int i4) {
        Context context = getContext();
        Drawable drawable = null;
        Drawable c = i != 0 ? C1206l0.m8461c(context, i) : null;
        Drawable c2 = i2 != 0 ? C1206l0.m8461c(context, i2) : null;
        Drawable c3 = i3 != 0 ? C1206l0.m8461c(context, i3) : null;
        if (i4 != 0) {
            drawable = C1206l0.m8461c(context, i4);
        }
        setCompoundDrawablesRelativeWithIntrinsicBounds(c, c2, c3, drawable);
        C2176w2 w2Var = this.f855b0;
        if (w2Var != null) {
            w2Var.mo12081a();
        }
    }

    public void setCompoundDrawablesWithIntrinsicBounds(int i, int i2, int i3, int i4) {
        Context context = getContext();
        Drawable drawable = null;
        Drawable c = i != 0 ? C1206l0.m8461c(context, i) : null;
        Drawable c2 = i2 != 0 ? C1206l0.m8461c(context, i2) : null;
        Drawable c3 = i3 != 0 ? C1206l0.m8461c(context, i3) : null;
        if (i4 != 0) {
            drawable = C1206l0.m8461c(context, i4);
        }
        setCompoundDrawablesWithIntrinsicBounds(c, c2, c3, drawable);
        C2176w2 w2Var = this.f855b0;
        if (w2Var != null) {
            w2Var.mo12081a();
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(C0815h0.m5786a((TextView) this, callback));
    }

    public void setFirstBaselineToTopHeight(int i) {
        if (Build.VERSION.SDK_INT >= 28) {
            super.setFirstBaselineToTopHeight(i);
        } else {
            C0815h0.m5814a((TextView) this, i);
        }
    }

    public void setLastBaselineToBottomHeight(int i) {
        if (Build.VERSION.SDK_INT >= 28) {
            super.setLastBaselineToBottomHeight(i);
        } else {
            C0815h0.m5847b((TextView) this, i);
        }
    }

    public void setLineHeight(int i) {
        C0815h0.m5853c(this, i);
    }

    public void setPrecomputedText(C2327y6 y6Var) {
        C0815h0.m5818a((TextView) this, y6Var);
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0334c2 c2Var = this.f854a0;
        if (c2Var != null) {
            c2Var.mo2719b(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0334c2 c2Var = this.f854a0;
        if (c2Var != null) {
            c2Var.mo2716a(mode);
        }
    }

    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        C2176w2 w2Var = this.f855b0;
        if (w2Var.f16500h == null) {
            w2Var.f16500h = new C2179w3();
        }
        C2179w3 w3Var = w2Var.f16500h;
        w3Var.f16519a = colorStateList;
        w3Var.f16522d = colorStateList != null;
        w2Var.mo12095h();
        this.f855b0.mo12081a();
    }

    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        C2176w2 w2Var = this.f855b0;
        if (w2Var.f16500h == null) {
            w2Var.f16500h = new C2179w3();
        }
        C2179w3 w3Var = w2Var.f16500h;
        w3Var.f16520b = mode;
        w3Var.f16521c = mode != null;
        w2Var.mo12095h();
        this.f855b0.mo12081a();
    }

    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        C2176w2 w2Var = this.f855b0;
        if (w2Var != null) {
            w2Var.mo12084a(context, i);
        }
    }

    public void setTextClassifier(TextClassifier textClassifier) {
        C2082v2 v2Var;
        if (Build.VERSION.SDK_INT >= 28 || (v2Var = this.f856c0) == null) {
            super.setTextClassifier(textClassifier);
        } else {
            v2Var.f15811b = textClassifier;
        }
    }

    public void setTextFuture(Future<C2327y6> future) {
        this.f857d0 = future;
        if (future != null) {
            requestLayout();
        }
    }

    public void setTextMetricsParamsCompat(C2327y6.C2328a aVar) {
        int i = Build.VERSION.SDK_INT;
        TextDirectionHeuristic c = aVar.mo12784c();
        int i2 = 1;
        if (!(c == TextDirectionHeuristics.FIRSTSTRONG_RTL || c == TextDirectionHeuristics.FIRSTSTRONG_LTR)) {
            if (c == TextDirectionHeuristics.ANYRTL_LTR) {
                i2 = 2;
            } else if (c == TextDirectionHeuristics.LTR) {
                i2 = 3;
            } else if (c == TextDirectionHeuristics.RTL) {
                i2 = 4;
            } else if (c == TextDirectionHeuristics.LOCALE) {
                i2 = 5;
            } else if (c == TextDirectionHeuristics.FIRSTSTRONG_LTR) {
                i2 = 6;
            } else if (c == TextDirectionHeuristics.FIRSTSTRONG_RTL) {
                i2 = 7;
            }
        }
        setTextDirection(i2);
        if (Build.VERSION.SDK_INT < 23) {
            float textScaleX = aVar.f17593a.getTextScaleX();
            getPaint().set(aVar.f17593a);
            if (textScaleX == getTextScaleX()) {
                setTextScaleX((textScaleX / 2.0f) + 1.0f);
            }
            setTextScaleX(textScaleX);
            return;
        }
        getPaint().set(aVar.f17593a);
        setBreakStrategy(aVar.mo12781a());
        setHyphenationFrequency(aVar.mo12783b());
    }

    public void setTextSize(int i, float f) {
        boolean z = C1133k8.f8952a;
        if (z) {
            super.setTextSize(i, f);
            return;
        }
        C2176w2 w2Var = this.f855b0;
        if (w2Var != null && !z && !w2Var.mo12094g()) {
            w2Var.f16501i.mo12419a(i, f);
        }
    }

    public void setTypeface(Typeface typeface, int i) {
        Typeface a = (typeface == null || i <= 0) ? null : C0755g6.m5363a(getContext(), typeface, i);
        if (a != null) {
            typeface = a;
        }
        super.setTypeface(typeface, i);
    }

    public void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        C2176w2 w2Var = this.f855b0;
        if (w2Var != null) {
            w2Var.mo12081a();
        }
    }

    public void setCompoundDrawablesWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        C2176w2 w2Var = this.f855b0;
        if (w2Var != null) {
            w2Var.mo12081a();
        }
    }
}
