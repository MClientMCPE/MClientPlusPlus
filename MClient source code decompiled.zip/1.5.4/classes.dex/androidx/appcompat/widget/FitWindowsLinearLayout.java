package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.widget.LinearLayout;
import p000.C0508d3;

public class FitWindowsLinearLayout extends LinearLayout implements C0508d3 {

    /* renamed from: a0 */
    public C0508d3.C0509a f870a0;

    public FitWindowsLinearLayout(Context context) {
        super(context);
    }

    public FitWindowsLinearLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public boolean fitSystemWindows(Rect rect) {
        C0508d3.C0509a aVar = this.f870a0;
        if (aVar != null) {
            rect.top = ((C0332c0) aVar).f2405a.mo42h(rect.top);
        }
        return super.fitSystemWindows(rect);
    }

    public void setOnFitSystemWindowsListener(C0508d3.C0509a aVar) {
        this.f870a0 = aVar;
    }
}
