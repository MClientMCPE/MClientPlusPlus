package androidx.appcompat.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.widget.OverScroller;
import androidx.recyclerview.widget.RecyclerView;
import p000.C1581p1;

public class ActionBarOverlayLayout extends ViewGroup implements C2390z2, C1595p7, C1403n7, C1502o7 {

    /* renamed from: B0 */
    public static final int[] f803B0 = {C0502d.actionBarSize, 16842841};

    /* renamed from: A0 */
    public final C1674q7 f804A0;

    /* renamed from: a0 */
    public int f805a0;

    /* renamed from: b0 */
    public int f806b0;

    /* renamed from: c0 */
    public ContentFrameLayout f807c0;

    /* renamed from: d0 */
    public ActionBarContainer f808d0;

    /* renamed from: e0 */
    public C0035a3 f809e0;

    /* renamed from: f0 */
    public Drawable f810f0;

    /* renamed from: g0 */
    public boolean f811g0;

    /* renamed from: h0 */
    public boolean f812h0;

    /* renamed from: i0 */
    public boolean f813i0;

    /* renamed from: j0 */
    public boolean f814j0;

    /* renamed from: k0 */
    public boolean f815k0;

    /* renamed from: l0 */
    public int f816l0;

    /* renamed from: m0 */
    public int f817m0;

    /* renamed from: n0 */
    public final Rect f818n0;

    /* renamed from: o0 */
    public final Rect f819o0;

    /* renamed from: p0 */
    public final Rect f820p0;

    /* renamed from: q0 */
    public final Rect f821q0;

    /* renamed from: r0 */
    public final Rect f822r0;

    /* renamed from: s0 */
    public final Rect f823s0;

    /* renamed from: t0 */
    public final Rect f824t0;

    /* renamed from: u0 */
    public C0136d f825u0;

    /* renamed from: v0 */
    public OverScroller f826v0;

    /* renamed from: w0 */
    public ViewPropertyAnimator f827w0;

    /* renamed from: x0 */
    public final AnimatorListenerAdapter f828x0;

    /* renamed from: y0 */
    public final Runnable f829y0;

    /* renamed from: z0 */
    public final Runnable f830z0;

    /* renamed from: androidx.appcompat.widget.ActionBarOverlayLayout$a */
    public class C0133a extends AnimatorListenerAdapter {
        public C0133a() {
        }

        public void onAnimationCancel(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.f827w0 = null;
            actionBarOverlayLayout.f815k0 = false;
        }

        public void onAnimationEnd(Animator animator) {
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.f827w0 = null;
            actionBarOverlayLayout.f815k0 = false;
        }
    }

    /* renamed from: androidx.appcompat.widget.ActionBarOverlayLayout$b */
    public class C0134b implements Runnable {
        public C0134b() {
        }

        public void run() {
            ActionBarOverlayLayout.this.mo825h();
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.f827w0 = actionBarOverlayLayout.f808d0.animate().translationY(0.0f).setListener(ActionBarOverlayLayout.this.f828x0);
        }
    }

    /* renamed from: androidx.appcompat.widget.ActionBarOverlayLayout$c */
    public class C0135c implements Runnable {
        public C0135c() {
        }

        public void run() {
            ActionBarOverlayLayout.this.mo825h();
            ActionBarOverlayLayout actionBarOverlayLayout = ActionBarOverlayLayout.this;
            actionBarOverlayLayout.f827w0 = actionBarOverlayLayout.f808d0.animate().translationY((float) (-ActionBarOverlayLayout.this.f808d0.getHeight())).setListener(ActionBarOverlayLayout.this.f828x0);
        }
    }

    /* renamed from: androidx.appcompat.widget.ActionBarOverlayLayout$d */
    public interface C0136d {
    }

    /* renamed from: androidx.appcompat.widget.ActionBarOverlayLayout$e */
    public static class C0137e extends ViewGroup.MarginLayoutParams {
        public C0137e(int i, int i2) {
            super(i, i2);
        }

        public C0137e(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public C0137e(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    public ActionBarOverlayLayout(Context context) {
        this(context, (AttributeSet) null);
    }

    public ActionBarOverlayLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f806b0 = 0;
        this.f818n0 = new Rect();
        this.f819o0 = new Rect();
        this.f820p0 = new Rect();
        this.f821q0 = new Rect();
        this.f822r0 = new Rect();
        this.f823s0 = new Rect();
        this.f824t0 = new Rect();
        this.f828x0 = new C0133a();
        this.f829y0 = new C0134b();
        this.f830z0 = new C0135c();
        mo799a(context);
        this.f804A0 = new C1674q7();
    }

    /* renamed from: a */
    public void mo798a(int i) {
        mo827j();
        if (i == 2) {
            ((C0036a4) this.f809e0).mo168c();
        } else if (i == 5) {
            ((C0036a4) this.f809e0).mo166b();
        } else if (i == 109) {
            setOverlayMode(true);
        }
    }

    /* renamed from: a */
    public final void mo799a(Context context) {
        TypedArray obtainStyledAttributes = getContext().getTheme().obtainStyledAttributes(f803B0);
        boolean z = false;
        this.f805a0 = obtainStyledAttributes.getDimensionPixelSize(0, 0);
        this.f810f0 = obtainStyledAttributes.getDrawable(1);
        setWillNotDraw(this.f810f0 == null);
        obtainStyledAttributes.recycle();
        if (context.getApplicationInfo().targetSdkVersion < 19) {
            z = true;
        }
        this.f811g0 = z;
        this.f826v0 = new OverScroller(context);
    }

    /* renamed from: a */
    public void mo801a(View view, int i) {
        if (i == 0) {
            onStopNestedScroll(view);
        }
    }

    /* renamed from: a */
    public void mo802a(View view, int i, int i2, int i3, int i4, int i5) {
        if (i5 == 0) {
            onNestedScroll(view, i, i2, i3, i4);
        }
    }

    /* renamed from: a */
    public void mo803a(View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
        mo802a(view, i, i2, i3, i4, i5);
    }

    /* renamed from: a */
    public void mo804a(View view, int i, int i2, int[] iArr, int i3) {
        if (i3 == 0) {
            onNestedPreScroll(view, i, i2, iArr);
        }
    }

    /* renamed from: a */
    public void mo805a(View view, View view2, int i, int i2) {
        if (i2 == 0) {
            onNestedScrollAccepted(view, view2, i);
        }
    }

    /* renamed from: a */
    public boolean mo806a() {
        mo827j();
        return ((C0036a4) this.f809e0).f147a.mo1105m();
    }

    /* renamed from: a */
    public final boolean mo807a(float f) {
        this.f826v0.fling(0, 0, 0, (int) f, 0, 0, RecyclerView.UNDEFINED_DURATION, Integer.MAX_VALUE);
        return this.f826v0.getFinalY() > this.f808d0.getHeight();
    }

    /* renamed from: a */
    public final boolean mo808a(View view, Rect rect, boolean z, boolean z2, boolean z3, boolean z4) {
        boolean z5;
        int i;
        int i2;
        int i3;
        int i4;
        C0137e eVar = (C0137e) view.getLayoutParams();
        if (!z || eVar.leftMargin == (i4 = rect.left)) {
            z5 = false;
        } else {
            eVar.leftMargin = i4;
            z5 = true;
        }
        if (z2 && eVar.topMargin != (i3 = rect.top)) {
            eVar.topMargin = i3;
            z5 = true;
        }
        if (z4 && eVar.rightMargin != (i2 = rect.right)) {
            eVar.rightMargin = i2;
            z5 = true;
        }
        if (!z3 || eVar.bottomMargin == (i = rect.bottom)) {
            return z5;
        }
        eVar.bottomMargin = i;
        return true;
    }

    /* renamed from: b */
    public void mo809b() {
        mo827j();
        ((C0036a4) this.f809e0).f147a.mo1062d();
    }

    /* renamed from: b */
    public boolean mo810b(View view, View view2, int i, int i2) {
        return i2 == 0 && onStartNestedScroll(view, view2, i);
    }

    /* renamed from: c */
    public void mo811c() {
        mo827j();
        ((C0036a4) this.f809e0).f159m = true;
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0137e;
    }

    /* renamed from: d */
    public boolean mo813d() {
        mo827j();
        return ((C0036a4) this.f809e0).f147a.mo1104l();
    }

    public void draw(Canvas canvas) {
        int i;
        super.draw(canvas);
        if (this.f810f0 != null && !this.f811g0) {
            if (this.f808d0.getVisibility() == 0) {
                i = (int) (this.f808d0.getTranslationY() + ((float) this.f808d0.getBottom()) + 0.5f);
            } else {
                i = 0;
            }
            this.f810f0.setBounds(0, i, getWidth(), this.f810f0.getIntrinsicHeight() + i);
            this.f810f0.draw(canvas);
        }
    }

    /* renamed from: e */
    public boolean mo815e() {
        mo827j();
        return ((C0036a4) this.f809e0).f147a.mo1103k();
    }

    /* renamed from: f */
    public boolean mo816f() {
        mo827j();
        return ((C0036a4) this.f809e0).f147a.mo1107o();
    }

    public boolean fitSystemWindows(Rect rect) {
        mo827j();
        int t = C2189w7.m15025t(this) & 256;
        boolean a = mo808a((View) this.f808d0, rect, true, true, false, true);
        this.f821q0.set(rect);
        C0580e4.m3914a(this, this.f821q0, this.f818n0);
        if (!this.f822r0.equals(this.f821q0)) {
            this.f822r0.set(this.f821q0);
            a = true;
        }
        if (!this.f819o0.equals(this.f818n0)) {
            this.f819o0.set(this.f818n0);
            a = true;
        }
        if (a) {
            requestLayout();
        }
        return true;
    }

    /* renamed from: g */
    public boolean mo818g() {
        mo827j();
        return ((C0036a4) this.f809e0).f147a.mo1058b();
    }

    public C0137e generateDefaultLayoutParams() {
        return new C0137e(-1, -1);
    }

    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new C0137e(layoutParams);
    }

    public C0137e generateLayoutParams(AttributeSet attributeSet) {
        return new C0137e(getContext(), attributeSet);
    }

    public int getActionBarHideOffset() {
        ActionBarContainer actionBarContainer = this.f808d0;
        if (actionBarContainer != null) {
            return -((int) actionBarContainer.getTranslationY());
        }
        return 0;
    }

    public int getNestedScrollAxes() {
        return this.f804A0.mo10254a();
    }

    public CharSequence getTitle() {
        mo827j();
        return ((C0036a4) this.f809e0).f147a.getTitle();
    }

    /* renamed from: h */
    public void mo825h() {
        removeCallbacks(this.f829y0);
        removeCallbacks(this.f830z0);
        ViewPropertyAnimator viewPropertyAnimator = this.f827w0;
        if (viewPropertyAnimator != null) {
            viewPropertyAnimator.cancel();
        }
    }

    /* renamed from: i */
    public boolean mo826i() {
        return this.f812h0;
    }

    /* renamed from: j */
    public void mo827j() {
        C0035a3 a3Var;
        if (this.f807c0 == null) {
            this.f807c0 = (ContentFrameLayout) findViewById(C0887i.action_bar_activity_content);
            this.f808d0 = (ActionBarContainer) findViewById(C0887i.action_bar_container);
            View findViewById = findViewById(C0887i.action_bar);
            if (findViewById instanceof C0035a3) {
                a3Var = (C0035a3) findViewById;
            } else if (findViewById instanceof Toolbar) {
                a3Var = ((Toolbar) findViewById).getWrapper();
            } else {
                StringBuilder a = C0789gk.m5562a("Can't make a decor toolbar out of ");
                a.append(findViewById.getClass().getSimpleName());
                throw new IllegalStateException(a.toString());
            }
            this.f809e0 = a3Var;
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        mo799a(getContext());
        C2189w7.m14973E(this);
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        mo825h();
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int childCount = getChildCount();
        int paddingLeft = getPaddingLeft();
        getPaddingRight();
        int paddingTop = getPaddingTop();
        getPaddingBottom();
        for (int i5 = 0; i5 < childCount; i5++) {
            View childAt = getChildAt(i5);
            if (childAt.getVisibility() != 8) {
                C0137e eVar = (C0137e) childAt.getLayoutParams();
                int measuredWidth = childAt.getMeasuredWidth();
                int measuredHeight = childAt.getMeasuredHeight();
                int i6 = eVar.leftMargin + paddingLeft;
                int i7 = eVar.topMargin + paddingTop;
                childAt.layout(i6, i7, measuredWidth + i6, measuredHeight + i7);
            }
        }
    }

    public void onMeasure(int i, int i2) {
        int i3;
        mo827j();
        measureChildWithMargins(this.f808d0, i, 0, i2, 0);
        C0137e eVar = (C0137e) this.f808d0.getLayoutParams();
        int max = Math.max(0, this.f808d0.getMeasuredWidth() + eVar.leftMargin + eVar.rightMargin);
        int max2 = Math.max(0, this.f808d0.getMeasuredHeight() + eVar.topMargin + eVar.bottomMargin);
        int combineMeasuredStates = View.combineMeasuredStates(0, this.f808d0.getMeasuredState());
        boolean z = (C2189w7.m15025t(this) & 256) != 0;
        if (z) {
            i3 = this.f805a0;
            if (this.f813i0 && this.f808d0.getTabContainer() != null) {
                i3 += this.f805a0;
            }
        } else {
            i3 = this.f808d0.getVisibility() != 8 ? this.f808d0.getMeasuredHeight() : 0;
        }
        this.f820p0.set(this.f818n0);
        this.f823s0.set(this.f821q0);
        Rect rect = (this.f812h0 || z) ? this.f823s0 : this.f820p0;
        rect.top += i3;
        rect.bottom += 0;
        mo808a((View) this.f807c0, this.f820p0, true, true, true, true);
        if (!this.f824t0.equals(this.f823s0)) {
            this.f824t0.set(this.f823s0);
            this.f807c0.mo937a(this.f823s0);
        }
        measureChildWithMargins(this.f807c0, i, 0, i2, 0);
        C0137e eVar2 = (C0137e) this.f807c0.getLayoutParams();
        int max3 = Math.max(max, this.f807c0.getMeasuredWidth() + eVar2.leftMargin + eVar2.rightMargin);
        int max4 = Math.max(max2, this.f807c0.getMeasuredHeight() + eVar2.topMargin + eVar2.bottomMargin);
        int combineMeasuredStates2 = View.combineMeasuredStates(combineMeasuredStates, this.f807c0.getMeasuredState());
        setMeasuredDimension(View.resolveSizeAndState(Math.max(getPaddingRight() + getPaddingLeft() + max3, getSuggestedMinimumWidth()), i, combineMeasuredStates2), View.resolveSizeAndState(Math.max(getPaddingBottom() + getPaddingTop() + max4, getSuggestedMinimumHeight()), i2, combineMeasuredStates2 << 16));
    }

    public boolean onNestedFling(View view, float f, float f2, boolean z) {
        if (!this.f814j0 || !z) {
            return false;
        }
        if (mo807a(f2)) {
            mo825h();
            this.f830z0.run();
        } else {
            mo825h();
            this.f829y0.run();
        }
        this.f815k0 = true;
        return true;
    }

    public boolean onNestedPreFling(View view, float f, float f2) {
        return false;
    }

    public void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
    }

    public void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        this.f816l0 += i2;
        setActionBarHideOffset(this.f816l0);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0011, code lost:
        r1 = (p000.C1110k0) r1;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onNestedScrollAccepted(android.view.View r1, android.view.View r2, int r3) {
        /*
            r0 = this;
            q7 r1 = r0.f804A0
            r1.f12902a = r3
            int r1 = r0.getActionBarHideOffset()
            r0.f816l0 = r1
            r0.mo825h()
            androidx.appcompat.widget.ActionBarOverlayLayout$d r1 = r0.f825u0
            if (r1 == 0) goto L_0x001d
            k0 r1 = (p000.C1110k0) r1
            z0 r2 = r1.f8752v
            if (r2 == 0) goto L_0x001d
            r2.mo13040a()
            r2 = 0
            r1.f8752v = r2
        L_0x001d:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ActionBarOverlayLayout.onNestedScrollAccepted(android.view.View, android.view.View, int):void");
    }

    public boolean onStartNestedScroll(View view, View view2, int i) {
        if ((i & 2) == 0 || this.f808d0.getVisibility() != 0) {
            return false;
        }
        return this.f814j0;
    }

    public void onStopNestedScroll(View view) {
        if (this.f814j0 && !this.f815k0) {
            if (this.f816l0 <= this.f808d0.getHeight()) {
                mo825h();
                postDelayed(this.f829y0, 600);
            } else {
                mo825h();
                postDelayed(this.f830z0, 600);
            }
        }
        C0136d dVar = this.f825u0;
        if (dVar != null) {
            ((C1110k0) dVar).mo7750d();
        }
    }

    public void onWindowSystemUiVisibilityChanged(int i) {
        int i2 = Build.VERSION.SDK_INT;
        super.onWindowSystemUiVisibilityChanged(i);
        mo827j();
        int i3 = this.f817m0 ^ i;
        this.f817m0 = i;
        boolean z = (i & 4) == 0;
        boolean z2 = (i & 256) != 0;
        C0136d dVar = this.f825u0;
        if (dVar != null) {
            ((C1110k0) dVar).f8747q = !z2;
            if (z || !z2) {
                C1110k0 k0Var = (C1110k0) this.f825u0;
                if (k0Var.f8749s) {
                    k0Var.f8749s = false;
                    k0Var.mo7753f(true);
                }
            } else {
                C1110k0 k0Var2 = (C1110k0) dVar;
                if (!k0Var2.f8749s) {
                    k0Var2.f8749s = true;
                    k0Var2.mo7753f(true);
                }
            }
        }
        if ((i3 & 256) != 0 && this.f825u0 != null) {
            C2189w7.m14973E(this);
        }
    }

    public void onWindowVisibilityChanged(int i) {
        super.onWindowVisibilityChanged(i);
        this.f806b0 = i;
        C0136d dVar = this.f825u0;
        if (dVar != null) {
            ((C1110k0) dVar).f8746p = i;
        }
    }

    public void setActionBarHideOffset(int i) {
        mo825h();
        this.f808d0.setTranslationY((float) (-Math.max(0, Math.min(i, this.f808d0.getHeight()))));
    }

    public void setActionBarVisibilityCallback(C0136d dVar) {
        this.f825u0 = dVar;
        if (getWindowToken() != null) {
            ((C1110k0) this.f825u0).f8746p = this.f806b0;
            int i = this.f817m0;
            if (i != 0) {
                onWindowSystemUiVisibilityChanged(i);
                C2189w7.m14973E(this);
            }
        }
    }

    public void setHasNonEmbeddedTabs(boolean z) {
        this.f813i0 = z;
    }

    public void setHideOnContentScrollEnabled(boolean z) {
        if (z != this.f814j0) {
            this.f814j0 = z;
            if (!z) {
                mo825h();
                setActionBarHideOffset(0);
            }
        }
    }

    public void setIcon(int i) {
        mo827j();
        C0036a4 a4Var = (C0036a4) this.f809e0;
        a4Var.f151e = i != 0 ? C1206l0.m8461c(a4Var.mo159a(), i) : null;
        a4Var.mo171f();
    }

    public void setLogo(int i) {
        mo827j();
        C0036a4 a4Var = (C0036a4) this.f809e0;
        a4Var.mo161a(i != 0 ? C1206l0.m8461c(a4Var.mo159a(), i) : null);
    }

    public void setOverlayMode(boolean z) {
        this.f812h0 = z;
        this.f811g0 = z && getContext().getApplicationInfo().targetSdkVersion < 19;
    }

    public void setShowingForActionMode(boolean z) {
    }

    public void setUiOptions(int i) {
    }

    public void setWindowCallback(Window.Callback callback) {
        mo827j();
        ((C0036a4) this.f809e0).f158l = callback;
    }

    public void setWindowTitle(CharSequence charSequence) {
        mo827j();
        ((C0036a4) this.f809e0).mo167b(charSequence);
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }

    /* renamed from: a */
    public void mo800a(Menu menu, C1581p1.C1582a aVar) {
        mo827j();
        C0036a4 a4Var = (C0036a4) this.f809e0;
        if (a4Var.f160n == null) {
            a4Var.f160n = new C0027a2(a4Var.f147a.getContext());
            a4Var.f160n.mo2706a(C0887i.action_menu_presenter);
        }
        C0027a2 a2Var = a4Var.f160n;
        a2Var.f2416b0 = aVar;
        a4Var.f147a.mo1052a((C0816h1) menu, a2Var);
    }

    public void setIcon(Drawable drawable) {
        mo827j();
        C0036a4 a4Var = (C0036a4) this.f809e0;
        a4Var.f151e = drawable;
        a4Var.mo171f();
    }
}
