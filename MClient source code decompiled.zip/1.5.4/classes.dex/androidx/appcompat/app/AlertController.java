package androidx.appcompat.app;

import android.content.Context;
import android.content.DialogInterface;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStub;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import androidx.core.widget.NestedScrollView;
import java.lang.ref.WeakReference;

public class AlertController {

    /* renamed from: A */
    public NestedScrollView f654A;

    /* renamed from: B */
    public int f655B = 0;

    /* renamed from: C */
    public Drawable f656C;

    /* renamed from: D */
    public ImageView f657D;

    /* renamed from: E */
    public TextView f658E;

    /* renamed from: F */
    public TextView f659F;

    /* renamed from: G */
    public View f660G;

    /* renamed from: H */
    public ListAdapter f661H;

    /* renamed from: I */
    public int f662I = -1;

    /* renamed from: J */
    public int f663J;

    /* renamed from: K */
    public int f664K;

    /* renamed from: L */
    public int f665L;

    /* renamed from: M */
    public int f666M;

    /* renamed from: N */
    public int f667N;

    /* renamed from: O */
    public int f668O;

    /* renamed from: P */
    public boolean f669P;

    /* renamed from: Q */
    public int f670Q = 0;

    /* renamed from: R */
    public Handler f671R;

    /* renamed from: S */
    public final View.OnClickListener f672S = new C0125a();

    /* renamed from: a */
    public final Context f673a;

    /* renamed from: b */
    public final C0730g0 f674b;

    /* renamed from: c */
    public final Window f675c;

    /* renamed from: d */
    public final int f676d;

    /* renamed from: e */
    public CharSequence f677e;

    /* renamed from: f */
    public CharSequence f678f;

    /* renamed from: g */
    public ListView f679g;

    /* renamed from: h */
    public View f680h;

    /* renamed from: i */
    public int f681i;

    /* renamed from: j */
    public int f682j;

    /* renamed from: k */
    public int f683k;

    /* renamed from: l */
    public int f684l;

    /* renamed from: m */
    public int f685m;

    /* renamed from: n */
    public boolean f686n = false;

    /* renamed from: o */
    public Button f687o;

    /* renamed from: p */
    public CharSequence f688p;

    /* renamed from: q */
    public Message f689q;

    /* renamed from: r */
    public Drawable f690r;

    /* renamed from: s */
    public Button f691s;

    /* renamed from: t */
    public CharSequence f692t;

    /* renamed from: u */
    public Message f693u;

    /* renamed from: v */
    public Drawable f694v;

    /* renamed from: w */
    public Button f695w;

    /* renamed from: x */
    public CharSequence f696x;

    /* renamed from: y */
    public Message f697y;

    /* renamed from: z */
    public Drawable f698z;

    public static class RecycleListView extends ListView {

        /* renamed from: a0 */
        public final int f699a0;

        /* renamed from: b0 */
        public final int f700b0;

        public RecycleListView(Context context) {
            this(context, (AttributeSet) null);
        }

        public RecycleListView(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C1292m.RecycleListView);
            this.f700b0 = obtainStyledAttributes.getDimensionPixelOffset(C1292m.RecycleListView_paddingBottomNoButtons, -1);
            this.f699a0 = obtainStyledAttributes.getDimensionPixelOffset(C1292m.RecycleListView_paddingTopNoTitle, -1);
        }

        /* renamed from: a */
        public void mo654a(boolean z, boolean z2) {
            if (!z2 || !z) {
                setPadding(getPaddingLeft(), z ? getPaddingTop() : this.f699a0, getPaddingRight(), z2 ? getPaddingBottom() : this.f700b0);
            }
        }
    }

    /* renamed from: androidx.appcompat.app.AlertController$a */
    public class C0125a implements View.OnClickListener {
        public C0125a() {
        }

        /* JADX WARNING: Code restructure failed: missing block: B:11:0x0020, code lost:
            r3 = r0.f697y;
         */
        /* JADX WARNING: Removed duplicated region for block: B:16:0x002c  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void onClick(android.view.View r3) {
            /*
                r2 = this;
                androidx.appcompat.app.AlertController r0 = androidx.appcompat.app.AlertController.this
                android.widget.Button r1 = r0.f687o
                if (r3 != r1) goto L_0x000f
                android.os.Message r0 = r0.f689q
                if (r0 == 0) goto L_0x000f
            L_0x000a:
                android.os.Message r3 = android.os.Message.obtain(r0)
                goto L_0x002a
            L_0x000f:
                androidx.appcompat.app.AlertController r0 = androidx.appcompat.app.AlertController.this
                android.widget.Button r1 = r0.f691s
                if (r3 != r1) goto L_0x001a
                android.os.Message r0 = r0.f693u
                if (r0 == 0) goto L_0x001a
                goto L_0x000a
            L_0x001a:
                androidx.appcompat.app.AlertController r0 = androidx.appcompat.app.AlertController.this
                android.widget.Button r1 = r0.f695w
                if (r3 != r1) goto L_0x0029
                android.os.Message r3 = r0.f697y
                if (r3 == 0) goto L_0x0029
                android.os.Message r3 = android.os.Message.obtain(r3)
                goto L_0x002a
            L_0x0029:
                r3 = 0
            L_0x002a:
                if (r3 == 0) goto L_0x002f
                r3.sendToTarget()
            L_0x002f:
                androidx.appcompat.app.AlertController r3 = androidx.appcompat.app.AlertController.this
                android.os.Handler r0 = r3.f671R
                r1 = 1
                g0 r3 = r3.f674b
                android.os.Message r3 = r0.obtainMessage(r1, r3)
                r3.sendToTarget()
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.AlertController.C0125a.onClick(android.view.View):void");
        }
    }

    /* renamed from: androidx.appcompat.app.AlertController$b */
    public static class C0126b {

        /* renamed from: A */
        public int f702A;

        /* renamed from: B */
        public int f703B;

        /* renamed from: C */
        public int f704C;

        /* renamed from: D */
        public int f705D;

        /* renamed from: E */
        public boolean f706E = false;

        /* renamed from: F */
        public boolean[] f707F;

        /* renamed from: G */
        public boolean f708G;

        /* renamed from: H */
        public boolean f709H;

        /* renamed from: I */
        public int f710I = -1;

        /* renamed from: J */
        public DialogInterface.OnMultiChoiceClickListener f711J;

        /* renamed from: K */
        public Cursor f712K;

        /* renamed from: L */
        public String f713L;

        /* renamed from: M */
        public String f714M;

        /* renamed from: N */
        public AdapterView.OnItemSelectedListener f715N;

        /* renamed from: a */
        public final Context f716a;

        /* renamed from: b */
        public final LayoutInflater f717b;

        /* renamed from: c */
        public int f718c = 0;

        /* renamed from: d */
        public Drawable f719d;

        /* renamed from: e */
        public int f720e = 0;

        /* renamed from: f */
        public CharSequence f721f;

        /* renamed from: g */
        public View f722g;

        /* renamed from: h */
        public CharSequence f723h;

        /* renamed from: i */
        public CharSequence f724i;

        /* renamed from: j */
        public Drawable f725j;

        /* renamed from: k */
        public DialogInterface.OnClickListener f726k;

        /* renamed from: l */
        public CharSequence f727l;

        /* renamed from: m */
        public Drawable f728m;

        /* renamed from: n */
        public DialogInterface.OnClickListener f729n;

        /* renamed from: o */
        public CharSequence f730o;

        /* renamed from: p */
        public Drawable f731p;

        /* renamed from: q */
        public DialogInterface.OnClickListener f732q;

        /* renamed from: r */
        public boolean f733r;

        /* renamed from: s */
        public DialogInterface.OnCancelListener f734s;

        /* renamed from: t */
        public DialogInterface.OnDismissListener f735t;

        /* renamed from: u */
        public DialogInterface.OnKeyListener f736u;

        /* renamed from: v */
        public CharSequence[] f737v;

        /* renamed from: w */
        public ListAdapter f738w;

        /* renamed from: x */
        public DialogInterface.OnClickListener f739x;

        /* renamed from: y */
        public int f740y;

        /* renamed from: z */
        public View f741z;

        public C0126b(Context context) {
            this.f716a = context;
            this.f733r = true;
            this.f717b = (LayoutInflater) context.getSystemService("layout_inflater");
        }
    }

    /* renamed from: androidx.appcompat.app.AlertController$c */
    public static final class C0127c extends Handler {

        /* renamed from: a */
        public WeakReference<DialogInterface> f742a;

        public C0127c(DialogInterface dialogInterface) {
            this.f742a = new WeakReference<>(dialogInterface);
        }

        public void handleMessage(Message message) {
            int i = message.what;
            if (i == -3 || i == -2 || i == -1) {
                ((DialogInterface.OnClickListener) message.obj).onClick((DialogInterface) this.f742a.get(), message.what);
            } else if (i == 1) {
                ((DialogInterface) message.obj).dismiss();
            }
        }
    }

    /* renamed from: androidx.appcompat.app.AlertController$d */
    public static class C0128d extends ArrayAdapter<CharSequence> {
        public C0128d(Context context, int i, int i2, CharSequence[] charSequenceArr) {
            super(context, i, i2, charSequenceArr);
        }

        public long getItemId(int i) {
            return (long) i;
        }

        public boolean hasStableIds() {
            return true;
        }
    }

    public AlertController(Context context, C0730g0 g0Var, Window window) {
        this.f673a = context;
        this.f674b = g0Var;
        this.f675c = window;
        this.f671R = new C0127c(g0Var);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes((AttributeSet) null, C1292m.AlertDialog, C0502d.alertDialogStyle, 0);
        this.f663J = obtainStyledAttributes.getResourceId(C1292m.AlertDialog_android_layout, 0);
        this.f664K = obtainStyledAttributes.getResourceId(C1292m.AlertDialog_buttonPanelSideLayout, 0);
        this.f665L = obtainStyledAttributes.getResourceId(C1292m.AlertDialog_listLayout, 0);
        this.f666M = obtainStyledAttributes.getResourceId(C1292m.AlertDialog_multiChoiceItemLayout, 0);
        this.f667N = obtainStyledAttributes.getResourceId(C1292m.AlertDialog_singleChoiceItemLayout, 0);
        this.f668O = obtainStyledAttributes.getResourceId(C1292m.AlertDialog_listItemLayout, 0);
        this.f669P = obtainStyledAttributes.getBoolean(C1292m.AlertDialog_showTitle, true);
        this.f676d = obtainStyledAttributes.getDimensionPixelSize(C1292m.AlertDialog_buttonIconDimen, 0);
        obtainStyledAttributes.recycle();
        g0Var.mo5811a(1);
    }

    /* renamed from: a */
    public static void m631a(View view, View view2, View view3) {
        int i = 0;
        if (view2 != null) {
            view2.setVisibility(view.canScrollVertically(-1) ? 0 : 4);
        }
        if (view3 != null) {
            if (!view.canScrollVertically(1)) {
                i = 4;
            }
            view3.setVisibility(i);
        }
    }

    /* renamed from: a */
    public static boolean m632a(View view) {
        if (view.onCheckIsTextEditor()) {
            return true;
        }
        if (!(view instanceof ViewGroup)) {
            return false;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        while (childCount > 0) {
            childCount--;
            if (m632a(viewGroup.getChildAt(childCount))) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: a */
    public int mo648a(int i) {
        TypedValue typedValue = new TypedValue();
        this.f673a.getTheme().resolveAttribute(i, typedValue, true);
        return typedValue.resourceId;
    }

    /* renamed from: a */
    public final ViewGroup mo649a(View view, View view2) {
        if (view == null) {
            if (view2 instanceof ViewStub) {
                view2 = ((ViewStub) view2).inflate();
            }
            return (ViewGroup) view2;
        }
        if (view2 != null) {
            ViewParent parent = view2.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(view2);
            }
        }
        if (view instanceof ViewStub) {
            view = ((ViewStub) view).inflate();
        }
        return (ViewGroup) view;
    }

    /* renamed from: a */
    public void mo650a(int i, CharSequence charSequence, DialogInterface.OnClickListener onClickListener, Message message, Drawable drawable) {
        if (message == null && onClickListener != null) {
            message = this.f671R.obtainMessage(i, onClickListener);
        }
        if (i == -3) {
            this.f696x = charSequence;
            this.f697y = message;
            this.f698z = drawable;
        } else if (i == -2) {
            this.f692t = charSequence;
            this.f693u = message;
            this.f694v = drawable;
        } else if (i == -1) {
            this.f688p = charSequence;
            this.f689q = message;
            this.f690r = drawable;
        } else {
            throw new IllegalArgumentException("Button does not exist");
        }
    }

    /* renamed from: a */
    public final void mo651a(Button button) {
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) button.getLayoutParams();
        layoutParams.gravity = 1;
        layoutParams.weight = 0.5f;
        button.setLayoutParams(layoutParams);
    }

    /* renamed from: a */
    public void mo652a(CharSequence charSequence) {
        this.f677e = charSequence;
        TextView textView = this.f658E;
        if (textView != null) {
            textView.setText(charSequence);
        }
    }

    /* renamed from: b */
    public void mo653b(int i) {
        this.f656C = null;
        this.f655B = i;
        ImageView imageView = this.f657D;
        if (imageView == null) {
            return;
        }
        if (i != 0) {
            imageView.setVisibility(0);
            this.f657D.setImageResource(this.f655B);
            return;
        }
        imageView.setVisibility(8);
    }
}
