package androidx.appcompat.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.FragmentActivity;
import java.util.ArrayList;
import p000.C1889t0;
import p000.C1981u5;

public class AppCompatActivity extends FragmentActivity implements C2314y, C1981u5.C1982a, C1489o {

    /* renamed from: m0 */
    public C2386z f743m0;

    /* renamed from: n0 */
    public Resources f744n0;

    /* renamed from: a */
    public C1889t0 mo659a(C1889t0.C1890a aVar) {
        return null;
    }

    /* renamed from: a */
    public void mo660a(Intent intent) {
        int i = Build.VERSION.SDK_INT;
        navigateUpTo(intent);
    }

    /* renamed from: a */
    public void mo661a(C1889t0 t0Var) {
    }

    /* renamed from: a */
    public void mo662a(C1981u5 u5Var) {
        u5Var.mo11523a(this);
    }

    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        mo676l().mo17a(view, layoutParams);
    }

    public void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        C0011a0 a0Var = (C0011a0) mo676l();
        a0Var.mo25a(false);
        a0Var.f15F0 = true;
    }

    /* renamed from: b */
    public void mo665b(C1889t0 t0Var) {
    }

    /* renamed from: b */
    public boolean mo666b(Intent intent) {
        int i = Build.VERSION.SDK_INT;
        return shouldUpRecreateTask(intent);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0026, code lost:
        r0 = getWindow();
     */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean mo667b(android.view.KeyEvent r3) {
        /*
            r2 = this;
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 26
            if (r0 >= r1) goto L_0x003e
            boolean r0 = r3.isCtrlPressed()
            if (r0 != 0) goto L_0x003e
            int r0 = r3.getMetaState()
            boolean r0 = android.view.KeyEvent.metaStateHasNoModifiers(r0)
            if (r0 != 0) goto L_0x003e
            int r0 = r3.getRepeatCount()
            if (r0 != 0) goto L_0x003e
            int r0 = r3.getKeyCode()
            boolean r0 = android.view.KeyEvent.isModifierKey(r0)
            if (r0 != 0) goto L_0x003e
            android.view.Window r0 = r2.getWindow()
            if (r0 == 0) goto L_0x003e
            android.view.View r1 = r0.getDecorView()
            if (r1 == 0) goto L_0x003e
            android.view.View r0 = r0.getDecorView()
            boolean r3 = r0.dispatchKeyShortcutEvent(r3)
            if (r3 == 0) goto L_0x003e
            r3 = 1
            return r3
        L_0x003e:
            r3 = 0
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.app.AppCompatActivity.mo667b(android.view.KeyEvent):boolean");
    }

    public void closeOptionsMenu() {
        C1377n m = mo677m();
        if (getWindow().hasFeature(0)) {
            super.closeOptionsMenu();
        }
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        int keyCode = keyEvent.getKeyCode();
        C1377n m = mo677m();
        return super.dispatchKeyEvent(keyEvent);
    }

    /* renamed from: f */
    public Intent mo670f() {
        return C0815h0.m5779a((Activity) this);
    }

    public <T extends View> T findViewById(int i) {
        C0011a0 a0Var = (C0011a0) mo676l();
        a0Var.mo43h();
        return a0Var.f34b0.findViewById(i);
    }

    public MenuInflater getMenuInflater() {
        return mo676l().mo9a();
    }

    public Resources getResources() {
        if (this.f744n0 == null) {
            C0512d4.m3429a();
        }
        Resources resources = this.f744n0;
        return resources == null ? super.getResources() : resources;
    }

    public void invalidateOptionsMenu() {
        mo676l().mo32c();
    }

    /* renamed from: k */
    public void mo675k() {
        mo676l().mo32c();
    }

    /* renamed from: l */
    public C2386z mo676l() {
        if (this.f743m0 == null) {
            this.f743m0 = C2386z.m16740a((Activity) this, (C2314y) this);
        }
        return this.f743m0;
    }

    /* renamed from: m */
    public C1377n mo677m() {
        C0011a0 a0Var = (C0011a0) mo676l();
        a0Var.mo48m();
        return a0Var.f37e0;
    }

    /* renamed from: n */
    public void mo678n() {
    }

    /* renamed from: o */
    public void mo679o() {
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        if (this.f744n0 != null) {
            this.f744n0.updateConfiguration(configuration, super.getResources().getDisplayMetrics());
        }
        mo676l().mo14a(configuration);
    }

    public void onContentChanged() {
        mo693p();
    }

    public void onCreate(Bundle bundle) {
        C2386z l = mo676l();
        l.mo26b();
        l.mo15a(bundle);
        super.onCreate(bundle);
    }

    public void onDestroy() {
        super.onDestroy();
        mo676l().mo35d();
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (mo667b(keyEvent)) {
            return true;
        }
        return super.onKeyDown(i, keyEvent);
    }

    public final boolean onMenuItemSelected(int i, MenuItem menuItem) {
        if (super.onMenuItemSelected(i, menuItem)) {
            return true;
        }
        C1377n m = mo677m();
        if (menuItem.getItemId() != 16908332 || m == null || (m.mo7745b() & 4) == 0) {
            return false;
        }
        return mo694q();
    }

    public boolean onMenuOpened(int i, Menu menu) {
        return super.onMenuOpened(i, menu);
    }

    public void onPanelClosed(int i, Menu menu) {
        super.onPanelClosed(i, menu);
    }

    public void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
        ((C0011a0) mo676l()).mo43h();
    }

    public void onPostResume() {
        super.onPostResume();
        C0011a0 a0Var = (C0011a0) mo676l();
        a0Var.mo48m();
        C1377n nVar = a0Var.f37e0;
        if (nVar != null) {
            nVar.mo7749c(true);
        }
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        mo676l().mo28b(bundle);
    }

    public void onStart() {
        super.onStart();
        C0011a0 a0Var = (C0011a0) mo676l();
        a0Var.f17H0 = true;
        a0Var.mo39f();
        C2386z.m16742a((C2386z) a0Var);
    }

    public void onStop() {
        super.onStop();
        mo676l().mo36e();
    }

    public void onTitleChanged(CharSequence charSequence, int i) {
        super.onTitleChanged(charSequence, i);
        mo676l().mo20a(charSequence);
    }

    public void openOptionsMenu() {
        C1377n m = mo677m();
        if (getWindow().hasFeature(0)) {
            super.openOptionsMenu();
        }
    }

    @Deprecated
    /* renamed from: p */
    public void mo693p() {
    }

    /* renamed from: q */
    public boolean mo694q() {
        Intent f = mo670f();
        if (f == null) {
            return false;
        }
        if (mo666b(f)) {
            C1981u5 u5Var = new C1981u5(this);
            mo662a(u5Var);
            mo679o();
            if (!u5Var.f15336X.isEmpty()) {
                ArrayList<Intent> arrayList = u5Var.f15336X;
                Intent[] intentArr = (Intent[]) arrayList.toArray(new Intent[arrayList.size()]);
                intentArr[0] = new Intent(intentArr[0]).addFlags(268484608);
                C2085v5.m14460a(u5Var.f15337Y, intentArr, (Bundle) null);
                try {
                    C1669q5.m11514a(this);
                    return true;
                } catch (IllegalStateException unused) {
                    finish();
                    return true;
                }
            } else {
                throw new IllegalStateException("No intents added to TaskStackBuilder; cannot startActivities");
            }
        } else {
            mo660a(f);
            return true;
        }
    }

    public void setContentView(int i) {
        mo676l().mo27b(i);
    }

    public void setContentView(View view) {
        mo676l().mo16a(view);
    }

    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        mo676l().mo29b(view, layoutParams);
    }

    public void setTheme(int i) {
        super.setTheme(i);
        ((C0011a0) mo676l()).f20K0 = i;
    }
}
