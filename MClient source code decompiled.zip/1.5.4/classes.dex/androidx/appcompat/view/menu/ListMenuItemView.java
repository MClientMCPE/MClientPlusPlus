package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import p000.C1655q1;

public class ListMenuItemView extends LinearLayout implements C1655q1.C1656a, AbsListView.SelectionBoundsAdjuster {

    /* renamed from: a0 */
    public C1115k1 f764a0;

    /* renamed from: b0 */
    public ImageView f765b0;

    /* renamed from: c0 */
    public RadioButton f766c0;

    /* renamed from: d0 */
    public TextView f767d0;

    /* renamed from: e0 */
    public CheckBox f768e0;

    /* renamed from: f0 */
    public TextView f769f0;

    /* renamed from: g0 */
    public ImageView f770g0;

    /* renamed from: h0 */
    public ImageView f771h0;

    /* renamed from: i0 */
    public LinearLayout f772i0;

    /* renamed from: j0 */
    public Drawable f773j0;

    /* renamed from: k0 */
    public int f774k0;

    /* renamed from: l0 */
    public Context f775l0;

    /* renamed from: m0 */
    public boolean f776m0;

    /* renamed from: n0 */
    public Drawable f777n0;

    /* renamed from: o0 */
    public boolean f778o0;

    /* renamed from: p0 */
    public LayoutInflater f779p0;

    /* renamed from: q0 */
    public boolean f780q0;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0502d.listMenuViewStyle);
    }

    public ListMenuItemView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet);
        C2322y3 a = C2322y3.m16057a(getContext(), attributeSet, C1292m.MenuView, i, 0);
        this.f773j0 = a.mo12737b(C1292m.MenuView_android_itemBackground);
        this.f774k0 = a.mo12744f(C1292m.MenuView_android_itemTextAppearance, -1);
        this.f776m0 = a.mo12735a(C1292m.MenuView_preserveIconSpacing, false);
        this.f775l0 = context;
        this.f777n0 = a.mo12737b(C1292m.MenuView_subMenuArrow);
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes((AttributeSet) null, new int[]{16843049}, C0502d.dropDownListViewStyle, 0);
        this.f778o0 = obtainStyledAttributes.hasValue(0);
        a.f17544b.recycle();
        obtainStyledAttributes.recycle();
    }

    private LayoutInflater getInflater() {
        if (this.f779p0 == null) {
            this.f779p0 = LayoutInflater.from(getContext());
        }
        return this.f779p0;
    }

    private void setSubMenuArrowVisible(boolean z) {
        ImageView imageView = this.f770g0;
        if (imageView != null) {
            imageView.setVisibility(z ? 0 : 8);
        }
    }

    /* renamed from: a */
    public final void mo740a() {
        this.f768e0 = (CheckBox) getInflater().inflate(C0978j.abc_list_menu_item_checkbox, this, false);
        mo741a((View) this.f768e0);
    }

    /* renamed from: a */
    public final void mo741a(View view) {
        LinearLayout linearLayout = this.f772i0;
        if (linearLayout != null) {
            linearLayout.addView(view, -1);
        } else {
            addView(view, -1);
        }
    }

    /* renamed from: a */
    public final void mo742a(View view, int i) {
        LinearLayout linearLayout = this.f772i0;
        if (linearLayout != null) {
            linearLayout.addView(view, i);
        } else {
            addView(view, i);
        }
    }

    public void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.f771h0;
        if (imageView != null && imageView.getVisibility() == 0) {
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.f771h0.getLayoutParams();
            rect.top = this.f771h0.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin + rect.top;
        }
    }

    /* renamed from: b */
    public final void mo745b() {
        this.f766c0 = (RadioButton) getInflater().inflate(C0978j.abc_list_menu_item_radio, this, false);
        mo741a((View) this.f766c0);
    }

    public C1115k1 getItemData() {
        return this.f764a0;
    }

    /* renamed from: i */
    public boolean mo718i() {
        return false;
    }

    public void onFinishInflate() {
        super.onFinishInflate();
        C2189w7.m14987a((View) this, this.f773j0);
        this.f767d0 = (TextView) findViewById(C0887i.title);
        int i = this.f774k0;
        if (i != -1) {
            this.f767d0.setTextAppearance(this.f775l0, i);
        }
        this.f769f0 = (TextView) findViewById(C0887i.shortcut);
        this.f770g0 = (ImageView) findViewById(C0887i.submenuarrow);
        ImageView imageView = this.f770g0;
        if (imageView != null) {
            imageView.setImageDrawable(this.f777n0);
        }
        this.f771h0 = (ImageView) findViewById(C0887i.group_divider);
        this.f772i0 = (LinearLayout) findViewById(C0887i.content);
    }

    public void onMeasure(int i, int i2) {
        if (this.f765b0 != null && this.f776m0) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.f765b0.getLayoutParams();
            if (layoutParams.height > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = layoutParams.height;
            }
        }
        super.onMeasure(i, i2);
    }

    public void setCheckable(boolean z) {
        CompoundButton compoundButton;
        CompoundButton compoundButton2;
        if (z || this.f766c0 != null || this.f768e0 != null) {
            if (this.f764a0.mo7793e()) {
                if (this.f766c0 == null) {
                    mo745b();
                }
                compoundButton2 = this.f766c0;
                compoundButton = this.f768e0;
            } else {
                if (this.f768e0 == null) {
                    mo740a();
                }
                compoundButton2 = this.f768e0;
                compoundButton = this.f766c0;
            }
            if (z) {
                compoundButton2.setChecked(this.f764a0.isChecked());
                if (compoundButton2.getVisibility() != 0) {
                    compoundButton2.setVisibility(0);
                }
                if (compoundButton != null && compoundButton.getVisibility() != 8) {
                    compoundButton.setVisibility(8);
                    return;
                }
                return;
            }
            CheckBox checkBox = this.f768e0;
            if (checkBox != null) {
                checkBox.setVisibility(8);
            }
            RadioButton radioButton = this.f766c0;
            if (radioButton != null) {
                radioButton.setVisibility(8);
            }
        }
    }

    public void setChecked(boolean z) {
        CompoundButton compoundButton;
        if (this.f764a0.mo7793e()) {
            if (this.f766c0 == null) {
                mo745b();
            }
            compoundButton = this.f766c0;
        } else {
            if (this.f768e0 == null) {
                mo740a();
            }
            compoundButton = this.f768e0;
        }
        compoundButton.setChecked(z);
    }

    public void setForceShowIcon(boolean z) {
        this.f780q0 = z;
        this.f776m0 = z;
    }

    public void setGroupDividerEnabled(boolean z) {
        ImageView imageView = this.f771h0;
        if (imageView != null) {
            imageView.setVisibility((this.f778o0 || !z) ? 8 : 0);
        }
    }

    public void setIcon(Drawable drawable) {
        boolean z = this.f764a0.f8796n.f6513t || this.f780q0;
        if (!z && !this.f776m0) {
            return;
        }
        if (this.f765b0 != null || drawable != null || this.f776m0) {
            if (this.f765b0 == null) {
                this.f765b0 = (ImageView) getInflater().inflate(C0978j.abc_list_menu_item_icon, this, false);
                mo742a((View) this.f765b0, 0);
            }
            if (drawable != null || this.f776m0) {
                ImageView imageView = this.f765b0;
                if (!z) {
                    drawable = null;
                }
                imageView.setImageDrawable(drawable);
                if (this.f765b0.getVisibility() != 0) {
                    this.f765b0.setVisibility(0);
                    return;
                }
                return;
            }
            this.f765b0.setVisibility(8);
        }
    }

    public void setTitle(CharSequence charSequence) {
        TextView textView;
        int i;
        if (charSequence != null) {
            this.f767d0.setText(charSequence);
            if (this.f767d0.getVisibility() != 0) {
                textView = this.f767d0;
                i = 0;
            } else {
                return;
            }
        } else {
            i = 8;
            if (this.f767d0.getVisibility() != 8) {
                textView = this.f767d0;
            } else {
                return;
            }
        }
        textView.setVisibility(i);
    }

    /* renamed from: a */
    public void mo716a(C1115k1 k1Var, int i) {
        CharSequence charSequence;
        this.f764a0 = k1Var;
        setVisibility(k1Var.isVisible() ? 0 : 8);
        if (mo718i()) {
            charSequence = k1Var.getTitleCondensed();
        } else {
            charSequence = k1Var.f8787e;
        }
        setTitle(charSequence);
        setCheckable(k1Var.isCheckable());
        boolean f = k1Var.mo7794f();
        k1Var.mo7788b();
        mo743a(f);
        setIcon(k1Var.getIcon());
        setEnabled(k1Var.isEnabled());
        setSubMenuArrowVisible(k1Var.hasSubMenu());
        setContentDescription(k1Var.f8800r);
    }

    /* renamed from: a */
    public void mo743a(boolean z) {
        String str;
        int i;
        int i2 = (!z || !this.f764a0.mo7794f()) ? 8 : 0;
        if (i2 == 0) {
            TextView textView = this.f769f0;
            C1115k1 k1Var = this.f764a0;
            char b = k1Var.mo7788b();
            if (b == 0) {
                str = "";
            } else {
                Resources resources = k1Var.f8796n.f6494a.getResources();
                StringBuilder sb = new StringBuilder();
                if (ViewConfiguration.get(k1Var.f8796n.f6494a).hasPermanentMenuKey()) {
                    sb.append(resources.getString(C1109k.abc_prepend_shortcut_label));
                }
                int i3 = k1Var.f8796n.mo6312f() ? k1Var.f8793k : k1Var.f8791i;
                C1115k1.m7959a(sb, i3, 65536, resources.getString(C1109k.abc_menu_meta_shortcut_label));
                C1115k1.m7959a(sb, i3, 4096, resources.getString(C1109k.abc_menu_ctrl_shortcut_label));
                C1115k1.m7959a(sb, i3, 2, resources.getString(C1109k.abc_menu_alt_shortcut_label));
                C1115k1.m7959a(sb, i3, 1, resources.getString(C1109k.abc_menu_shift_shortcut_label));
                C1115k1.m7959a(sb, i3, 4, resources.getString(C1109k.abc_menu_sym_shortcut_label));
                C1115k1.m7959a(sb, i3, 8, resources.getString(C1109k.abc_menu_function_shortcut_label));
                if (b == 8) {
                    i = C1109k.abc_menu_delete_shortcut_label;
                } else if (b == 10) {
                    i = C1109k.abc_menu_enter_shortcut_label;
                } else if (b != ' ') {
                    sb.append(b);
                    str = sb.toString();
                } else {
                    i = C1109k.abc_menu_space_shortcut_label;
                }
                sb.append(resources.getString(i));
                str = sb.toString();
            }
            textView.setText(str);
        }
        if (this.f769f0.getVisibility() != i2) {
            this.f769f0.setVisibility(i2);
        }
    }
}
