package androidx.appcompat.view.menu;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.AppCompatTextView;
import p000.C0027a2;
import p000.C0816h1;
import p000.C1655q1;

public class ActionMenuItemView extends AppCompatTextView implements C1655q1.C1656a, View.OnClickListener, ActionMenuView.C0138a {

    /* renamed from: e0 */
    public C1115k1 f749e0;

    /* renamed from: f0 */
    public CharSequence f750f0;

    /* renamed from: g0 */
    public Drawable f751g0;

    /* renamed from: h0 */
    public C0816h1.C0818b f752h0;

    /* renamed from: i0 */
    public C0577e3 f753i0;

    /* renamed from: j0 */
    public C0131b f754j0;

    /* renamed from: k0 */
    public boolean f755k0;

    /* renamed from: l0 */
    public boolean f756l0;

    /* renamed from: m0 */
    public int f757m0;

    /* renamed from: n0 */
    public int f758n0;

    /* renamed from: o0 */
    public int f759o0;

    /* renamed from: androidx.appcompat.view.menu.ActionMenuItemView$a */
    public class C0130a extends C0577e3 {
        public C0130a() {
            super(ActionMenuItemView.this);
        }

        /* renamed from: j */
        public C1788s1 mo146j() {
            C0027a2.C0028a aVar;
            C0131b bVar = ActionMenuItemView.this.f754j0;
            if (bVar == null || (aVar = C0027a2.this.f124u0) == null) {
                return null;
            }
            return aVar.mo8981a();
        }

        /* JADX WARNING: Code restructure failed: missing block: B:4:0x000f, code lost:
            r0 = mo146j();
         */
        /* renamed from: k */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean mo147k() {
            /*
                r3 = this;
                androidx.appcompat.view.menu.ActionMenuItemView r0 = androidx.appcompat.view.menu.ActionMenuItemView.this
                h1$b r1 = r0.f752h0
                r2 = 0
                if (r1 == 0) goto L_0x001c
                k1 r0 = r0.f749e0
                boolean r0 = r1.mo736a(r0)
                if (r0 == 0) goto L_0x001c
                s1 r0 = r3.mo146j()
                if (r0 == 0) goto L_0x001c
                boolean r0 = r0.mo4983r()
                if (r0 == 0) goto L_0x001c
                r2 = 1
            L_0x001c:
                return r2
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.view.menu.ActionMenuItemView.C0130a.mo147k():boolean");
        }
    }

    /* renamed from: androidx.appcompat.view.menu.ActionMenuItemView$b */
    public static abstract class C0131b {
    }

    public ActionMenuItemView(Context context) {
        this(context, (AttributeSet) null);
    }

    public ActionMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ActionMenuItemView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        Resources resources = context.getResources();
        this.f755k0 = mo720m();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C1292m.ActionMenuItemView, i, 0);
        this.f757m0 = obtainStyledAttributes.getDimensionPixelSize(C1292m.ActionMenuItemView_android_minWidth, 0);
        obtainStyledAttributes.recycle();
        this.f759o0 = (int) ((resources.getDisplayMetrics().density * 32.0f) + 0.5f);
        setOnClickListener(this);
        this.f758n0 = -1;
        setSaveEnabled(false);
    }

    /* renamed from: a */
    public void mo716a(C1115k1 k1Var, int i) {
        CharSequence charSequence;
        this.f749e0 = k1Var;
        setIcon(k1Var.getIcon());
        if (mo718i()) {
            charSequence = k1Var.getTitleCondensed();
        } else {
            charSequence = k1Var.f8787e;
        }
        setTitle(charSequence);
        setId(k1Var.f8783a);
        setVisibility(k1Var.isVisible() ? 0 : 8);
        setEnabled(k1Var.isEnabled());
        if (k1Var.hasSubMenu() && this.f753i0 == null) {
            this.f753i0 = new C0130a();
        }
    }

    public C1115k1 getItemData() {
        return this.f749e0;
    }

    /* renamed from: i */
    public boolean mo718i() {
        return true;
    }

    /* renamed from: j */
    public boolean mo142j() {
        return mo719l();
    }

    /* renamed from: k */
    public boolean mo143k() {
        return mo719l() && this.f749e0.getIcon() == null;
    }

    /* renamed from: l */
    public boolean mo719l() {
        return !TextUtils.isEmpty(getText());
    }

    /* renamed from: m */
    public final boolean mo720m() {
        Configuration configuration = getContext().getResources().getConfiguration();
        int i = configuration.screenWidthDp;
        return i >= 480 || (i >= 640 && configuration.screenHeightDp >= 480) || configuration.orientation == 2;
    }

    /* renamed from: n */
    public final void mo721n() {
        boolean z = true;
        boolean z2 = !TextUtils.isEmpty(this.f750f0);
        if (this.f751g0 != null) {
            if (!((this.f749e0.f8808z & 4) == 4) || (!this.f755k0 && !this.f756l0)) {
                z = false;
            }
        }
        boolean z3 = z2 & z;
        CharSequence charSequence = null;
        setText(z3 ? this.f750f0 : null);
        CharSequence charSequence2 = this.f749e0.f8800r;
        if (TextUtils.isEmpty(charSequence2)) {
            if (z3) {
                charSequence2 = null;
            } else {
                charSequence2 = this.f749e0.f8787e;
            }
        }
        setContentDescription(charSequence2);
        CharSequence charSequence3 = this.f749e0.f8801s;
        if (TextUtils.isEmpty(charSequence3)) {
            if (!z3) {
                charSequence = this.f749e0.f8787e;
            }
            C0815h0.m5806a((View) this, charSequence);
            return;
        }
        C0815h0.m5806a((View) this, charSequence3);
    }

    public void onClick(View view) {
        C0816h1.C0818b bVar = this.f752h0;
        if (bVar != null) {
            bVar.mo736a(this.f749e0);
        }
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        this.f755k0 = mo720m();
        mo721n();
    }

    public void onMeasure(int i, int i2) {
        int i3;
        boolean l = mo719l();
        if (l && (i3 = this.f758n0) >= 0) {
            super.setPadding(i3, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
        super.onMeasure(i, i2);
        int mode = View.MeasureSpec.getMode(i);
        int size = View.MeasureSpec.getSize(i);
        int measuredWidth = getMeasuredWidth();
        int min = mode == Integer.MIN_VALUE ? Math.min(size, this.f757m0) : this.f757m0;
        if (mode != 1073741824 && this.f757m0 > 0 && measuredWidth < min) {
            super.onMeasure(View.MeasureSpec.makeMeasureSpec(min, 1073741824), i2);
        }
        if (!l && this.f751g0 != null) {
            super.setPadding((getMeasuredWidth() - this.f751g0.getBounds().width()) / 2, getPaddingTop(), getPaddingRight(), getPaddingBottom());
        }
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        super.onRestoreInstanceState((Parcelable) null);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        C0577e3 e3Var;
        if (!this.f749e0.hasSubMenu() || (e3Var = this.f753i0) == null || !e3Var.onTouch(this, motionEvent)) {
            return super.onTouchEvent(motionEvent);
        }
        return true;
    }

    public void setCheckable(boolean z) {
    }

    public void setChecked(boolean z) {
    }

    public void setExpandedFormat(boolean z) {
        if (this.f756l0 != z) {
            this.f756l0 = z;
            C1115k1 k1Var = this.f749e0;
            if (k1Var != null) {
                k1Var.f8796n.mo6316h();
            }
        }
    }

    public void setIcon(Drawable drawable) {
        this.f751g0 = drawable;
        if (drawable != null) {
            int intrinsicWidth = drawable.getIntrinsicWidth();
            int intrinsicHeight = drawable.getIntrinsicHeight();
            int i = this.f759o0;
            if (intrinsicWidth > i) {
                intrinsicHeight = (int) (((float) intrinsicHeight) * (((float) i) / ((float) intrinsicWidth)));
                intrinsicWidth = i;
            }
            int i2 = this.f759o0;
            if (intrinsicHeight > i2) {
                intrinsicWidth = (int) (((float) intrinsicWidth) * (((float) i2) / ((float) intrinsicHeight)));
                intrinsicHeight = i2;
            }
            drawable.setBounds(0, 0, intrinsicWidth, intrinsicHeight);
        }
        setCompoundDrawables(drawable, (Drawable) null, (Drawable) null, (Drawable) null);
        mo721n();
    }

    public void setItemInvoker(C0816h1.C0818b bVar) {
        this.f752h0 = bVar;
    }

    public void setPadding(int i, int i2, int i3, int i4) {
        this.f758n0 = i;
        super.setPadding(i, i2, i3, i4);
    }

    public void setPopupCallback(C0131b bVar) {
        this.f754j0 = bVar;
    }

    public void setTitle(CharSequence charSequence) {
        this.f750f0 = charSequence;
        mo721n();
    }
}
