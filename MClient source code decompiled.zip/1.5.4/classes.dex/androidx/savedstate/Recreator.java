package androidx.savedstate;

import android.annotation.SuppressLint;
import android.os.Bundle;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Iterator;
import p000.C0677fd;
import p000.C1234lb;

@SuppressLint({"RestrictedApi"})
public final class Recreator implements C1138kb {

    /* renamed from: a */
    public final C0857hd f1462a;

    public Recreator(C0857hd hdVar) {
        this.f1462a = hdVar;
    }

    /* renamed from: a */
    public void mo644a(C1509ob obVar, C1234lb.C1235a aVar) {
        Bundle bundle;
        if (aVar == C1234lb.C1235a.ON_CREATE) {
            ((C1607pb) obVar.mo635a()).f12332a.remove(this);
            C0677fd c = this.f1462a.mo637c();
            if (c.f5230c) {
                Bundle bundle2 = c.f5229b;
                if (bundle2 != null) {
                    bundle = bundle2.getBundle("androidx.savedstate.Restarter");
                    c.f5229b.remove("androidx.savedstate.Restarter");
                    if (c.f5229b.isEmpty()) {
                        c.f5229b = null;
                    }
                } else {
                    bundle = null;
                }
                if (bundle != null) {
                    ArrayList<String> stringArrayList = bundle.getStringArrayList("classes_to_restore");
                    if (stringArrayList != null) {
                        Iterator<String> it = stringArrayList.iterator();
                        while (it.hasNext()) {
                            String next = it.next();
                            try {
                                Class<? extends U> asSubclass = Class.forName(next, false, Recreator.class.getClassLoader()).asSubclass(C0677fd.C0678a.class);
                                try {
                                    Constructor<? extends U> declaredConstructor = asSubclass.getDeclaredConstructor(new Class[0]);
                                    declaredConstructor.setAccessible(true);
                                    try {
                                        ((C0677fd.C0678a) declaredConstructor.newInstance(new Object[0])).mo5550a(this.f1462a);
                                    } catch (Exception e) {
                                        throw new RuntimeException(C0789gk.m5557a("Failed to instantiate ", next), e);
                                    }
                                } catch (NoSuchMethodException e2) {
                                    StringBuilder a = C0789gk.m5562a("Class");
                                    a.append(asSubclass.getSimpleName());
                                    a.append(" must have default constructor in order to be automatically recreated");
                                    throw new IllegalStateException(a.toString(), e2);
                                }
                            } catch (ClassNotFoundException e3) {
                                throw new RuntimeException(C0789gk.m5558a("Class ", next, " wasn't found"), e3);
                            }
                        }
                        return;
                    }
                    throw new IllegalStateException("Bundle with restored state for the component \"androidx.savedstate.Restarter\" must contain list of strings by the key \"classes_to_restore\"");
                }
                return;
            }
            throw new IllegalStateException("You can consumeRestoredStateForKey only after super.onCreate of corresponding component");
        }
        throw new AssertionError("Next event must be ON_CREATE");
    }
}
