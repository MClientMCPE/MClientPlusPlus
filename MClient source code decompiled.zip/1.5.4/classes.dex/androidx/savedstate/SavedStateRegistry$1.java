package androidx.savedstate;

import p000.C1234lb;

public class SavedStateRegistry$1 implements C1138kb {

    /* renamed from: a */
    public final /* synthetic */ C0677fd f1463a;

    public SavedStateRegistry$1(C0677fd fdVar) {
        this.f1463a = fdVar;
    }

    /* renamed from: a */
    public void mo644a(C1509ob obVar, C1234lb.C1235a aVar) {
        C0677fd fdVar;
        boolean z;
        if (aVar == C1234lb.C1235a.ON_START) {
            fdVar = this.f1463a;
            z = true;
        } else if (aVar == C1234lb.C1235a.ON_STOP) {
            fdVar = this.f1463a;
            z = false;
        } else {
            return;
        }
        fdVar.f5231d = z;
    }
}
