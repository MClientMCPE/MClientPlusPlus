package androidx.cardview.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;

public class CardView extends FrameLayout {

    /* renamed from: h0 */
    public static final int[] f1000h0 = {16842801};

    /* renamed from: i0 */
    public static final C2180w4 f1001i0 = (Build.VERSION.SDK_INT >= 21 ? new C1898t4() : new C1792s4());

    /* renamed from: a0 */
    public boolean f1002a0;

    /* renamed from: b0 */
    public boolean f1003b0;

    /* renamed from: c0 */
    public int f1004c0;

    /* renamed from: d0 */
    public int f1005d0;

    /* renamed from: e0 */
    public final Rect f1006e0;

    /* renamed from: f0 */
    public final Rect f1007f0;

    /* renamed from: g0 */
    public final C2084v4 f1008g0;

    /* renamed from: androidx.cardview.widget.CardView$a */
    public class C0171a implements C2084v4 {

        /* renamed from: a */
        public Drawable f1009a;

        public C0171a() {
        }

        /* renamed from: a */
        public void mo1190a(int i, int i2, int i3, int i4) {
            CardView.this.f1007f0.set(i, i2, i3, i4);
            CardView cardView = CardView.this;
            Rect rect = cardView.f1006e0;
            CardView.super.setPadding(i + rect.left, i2 + rect.top, i3 + rect.right, i4 + rect.bottom);
        }

        /* renamed from: a */
        public boolean mo1191a() {
            return CardView.this.getPreventCornerOverlap();
        }
    }

    static {
        f1001i0.mo10845a();
    }

    public CardView(Context context) {
        this(context, (AttributeSet) null);
    }

    public CardView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C1396n4.cardViewStyle);
    }

    public CardView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        Resources resources;
        int i2;
        ColorStateList valueOf;
        this.f1006e0 = new Rect();
        this.f1007f0 = new Rect();
        this.f1008g0 = new C0171a();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C1739r4.CardView, i, C1666q4.CardView);
        if (obtainStyledAttributes.hasValue(C1739r4.CardView_cardBackgroundColor)) {
            valueOf = obtainStyledAttributes.getColorStateList(C1739r4.CardView_cardBackgroundColor);
        } else {
            TypedArray obtainStyledAttributes2 = getContext().obtainStyledAttributes(f1000h0);
            int color = obtainStyledAttributes2.getColor(0, 0);
            obtainStyledAttributes2.recycle();
            float[] fArr = new float[3];
            Color.colorToHSV(color, fArr);
            if (fArr[2] > 0.5f) {
                resources = getResources();
                i2 = C1497o4.cardview_light_background;
            } else {
                resources = getResources();
                i2 = C1497o4.cardview_dark_background;
            }
            valueOf = ColorStateList.valueOf(resources.getColor(i2));
        }
        ColorStateList colorStateList = valueOf;
        float dimension = obtainStyledAttributes.getDimension(C1739r4.CardView_cardCornerRadius, 0.0f);
        float dimension2 = obtainStyledAttributes.getDimension(C1739r4.CardView_cardElevation, 0.0f);
        float dimension3 = obtainStyledAttributes.getDimension(C1739r4.CardView_cardMaxElevation, 0.0f);
        this.f1002a0 = obtainStyledAttributes.getBoolean(C1739r4.CardView_cardUseCompatPadding, false);
        this.f1003b0 = obtainStyledAttributes.getBoolean(C1739r4.CardView_cardPreventCornerOverlap, true);
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(C1739r4.CardView_contentPadding, 0);
        this.f1006e0.left = obtainStyledAttributes.getDimensionPixelSize(C1739r4.CardView_contentPaddingLeft, dimensionPixelSize);
        this.f1006e0.top = obtainStyledAttributes.getDimensionPixelSize(C1739r4.CardView_contentPaddingTop, dimensionPixelSize);
        this.f1006e0.right = obtainStyledAttributes.getDimensionPixelSize(C1739r4.CardView_contentPaddingRight, dimensionPixelSize);
        this.f1006e0.bottom = obtainStyledAttributes.getDimensionPixelSize(C1739r4.CardView_contentPaddingBottom, dimensionPixelSize);
        float f = dimension2 > dimension3 ? dimension2 : dimension3;
        this.f1004c0 = obtainStyledAttributes.getDimensionPixelSize(C1739r4.CardView_android_minWidth, 0);
        this.f1005d0 = obtainStyledAttributes.getDimensionPixelSize(C1739r4.CardView_android_minHeight, 0);
        obtainStyledAttributes.recycle();
        f1001i0.mo11145a(this.f1008g0, context, colorStateList, dimension, dimension2, f);
    }

    public ColorStateList getCardBackgroundColor() {
        return f1001i0.mo11147b(this.f1008g0);
    }

    public float getCardElevation() {
        return f1001i0.mo11149c(this.f1008g0);
    }

    public int getContentPaddingBottom() {
        return this.f1006e0.bottom;
    }

    public int getContentPaddingLeft() {
        return this.f1006e0.left;
    }

    public int getContentPaddingRight() {
        return this.f1006e0.right;
    }

    public int getContentPaddingTop() {
        return this.f1006e0.top;
    }

    public float getMaxCardElevation() {
        return f1001i0.mo11143a(this.f1008g0);
    }

    public boolean getPreventCornerOverlap() {
        return this.f1003b0;
    }

    public float getRadius() {
        return f1001i0.mo11151d(this.f1008g0);
    }

    public boolean getUseCompatPadding() {
        return this.f1002a0;
    }

    public void onMeasure(int i, int i2) {
        if (!(f1001i0 instanceof C1898t4)) {
            int mode = View.MeasureSpec.getMode(i);
            if (mode == Integer.MIN_VALUE || mode == 1073741824) {
                i = View.MeasureSpec.makeMeasureSpec(Math.max((int) Math.ceil((double) f1001i0.mo11153f(this.f1008g0)), View.MeasureSpec.getSize(i)), mode);
            }
            int mode2 = View.MeasureSpec.getMode(i2);
            if (mode2 == Integer.MIN_VALUE || mode2 == 1073741824) {
                i2 = View.MeasureSpec.makeMeasureSpec(Math.max((int) Math.ceil((double) f1001i0.mo11152e(this.f1008g0)), View.MeasureSpec.getSize(i2)), mode2);
            }
        }
        super.onMeasure(i, i2);
    }

    public void setCardBackgroundColor(int i) {
        f1001i0.mo11146a(this.f1008g0, ColorStateList.valueOf(i));
    }

    public void setCardBackgroundColor(ColorStateList colorStateList) {
        f1001i0.mo11146a(this.f1008g0, colorStateList);
    }

    public void setCardElevation(float f) {
        f1001i0.mo11148b(this.f1008g0, f);
    }

    public void setMaxCardElevation(float f) {
        f1001i0.mo11150c(this.f1008g0, f);
    }

    public void setMinimumHeight(int i) {
        this.f1005d0 = i;
        super.setMinimumHeight(i);
    }

    public void setMinimumWidth(int i) {
        this.f1004c0 = i;
        super.setMinimumWidth(i);
    }

    public void setPadding(int i, int i2, int i3, int i4) {
    }

    public void setPaddingRelative(int i, int i2, int i3, int i4) {
    }

    public void setPreventCornerOverlap(boolean z) {
        if (z != this.f1003b0) {
            this.f1003b0 = z;
            f1001i0.mo11155h(this.f1008g0);
        }
    }

    public void setRadius(float f) {
        f1001i0.mo11144a(this.f1008g0, f);
    }

    public void setUseCompatPadding(boolean z) {
        if (this.f1002a0 != z) {
            this.f1002a0 = z;
            f1001i0.mo11154g(this.f1008g0);
        }
    }
}
