package p002io.mrarm.mctoolbox.p003ui;

import android.content.Context;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import p002io.mrarm.mctoolbox.R;

/* renamed from: io.mrarm.mctoolbox.ui.FullscreenTextEditDialog */
public class FullscreenTextEditDialog extends C0730g0 {

    /* renamed from: Z */
    public C0954a f7822Z;

    /* renamed from: a0 */
    public SpecialEditText f7823a0 = ((SpecialEditText) findViewById(R.id.editText));

    /* renamed from: io.mrarm.mctoolbox.ui.FullscreenTextEditDialog$SpecialEditText */
    public static class SpecialEditText extends C0893i2 {

        /* renamed from: d0 */
        public Runnable f7824d0;

        public SpecialEditText(Context context) {
            super(context);
        }

        public SpecialEditText(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public SpecialEditText(Context context, AttributeSet attributeSet, int i) {
            super(context, attributeSet, i);
        }

        public boolean onKeyPreIme(int i, KeyEvent keyEvent) {
            if (i == 4) {
                this.f7824d0.run();
            }
            return super.onKeyPreIme(i, keyEvent);
        }
    }

    /* renamed from: io.mrarm.mctoolbox.ui.FullscreenTextEditDialog$a */
    public interface C0954a {
        /* renamed from: a */
        boolean mo7158a();
    }

    static {
        Class<FullscreenTextEditDialog> cls = FullscreenTextEditDialog.class;
    }

    public FullscreenTextEditDialog(Context context) {
        super(context, 2131820554);
        mo5811a(1);
        setContentView((int) R.layout.dialog_edit_fullscreen);
        this.f7823a0.f7824d0 = new xk3(this);
        findViewById(R.id.done).setOnClickListener(new jm3(this));
    }

    /* renamed from: a */
    public /* synthetic */ void mo7152a(View view) {
        if (this.f7822Z.mo7158a()) {
            dismiss();
        }
    }

    /* renamed from: a */
    public /* synthetic */ void mo7153a(Window window) {
        Rect rect = new Rect();
        window.getDecorView().getWindowVisibleDisplayFrame(rect);
        ((ViewGroup.MarginLayoutParams) findViewById(R.id.root).getLayoutParams()).bottomMargin = window.getDecorView().getRootView().getHeight() - rect.height();
        findViewById(R.id.root).requestLayout();
    }

    /* renamed from: a */
    public void mo7154a(C0954a aVar) {
        this.f7822Z = aVar;
    }

    /* renamed from: a */
    public void mo7155a(String str) {
        if (str == null) {
            this.f7823a0.setText("");
        } else {
            this.f7823a0.setText(str);
        }
    }

    public void dismiss() {
        Window window = getWindow();
        if (window != null) {
            ((InputMethodManager) getContext().getSystemService("input_method")).hideSoftInputFromWindow(window.getDecorView().getRootView().getWindowToken(), 2);
        }
        super.dismiss();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Window window = getWindow();
        window.setSoftInputMode(5);
        window.setLayout(-1, -1);
        window.setFlags(1024, 1024);
        if (Build.VERSION.SDK_INT >= 24) {
            window.setSoftInputMode(21);
        } else {
            window.getDecorView().getViewTreeObserver().addOnGlobalLayoutListener(new im3(this, window));
        }
        this.f7823a0.requestFocus();
    }
}
