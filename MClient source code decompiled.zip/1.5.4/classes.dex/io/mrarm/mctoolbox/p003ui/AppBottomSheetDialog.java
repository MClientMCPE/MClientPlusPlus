package p002io.mrarm.mctoolbox.p003ui;

import android.animation.ValueAnimator;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.os.Build;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.animation.DecelerateInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.FrameLayout;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetBehaviorMod;
import java.lang.ref.WeakReference;
import p002io.mrarm.mctoolbox.R;

/* renamed from: io.mrarm.mctoolbox.ui.AppBottomSheetDialog */
public class AppBottomSheetDialog extends C0730g0 {

    /* renamed from: Z */
    public ViewGroup f7804Z;

    /* renamed from: a0 */
    public BottomSheetBehavior f7805a0;

    /* renamed from: b0 */
    public boolean f7806b0 = true;

    /* renamed from: c0 */
    public C1406n9 f7807c0;

    /* renamed from: io.mrarm.mctoolbox.ui.AppBottomSheetDialog$AutoSizedFrameLayout */
    public static class AutoSizedFrameLayout extends FrameLayout implements ViewTreeObserver.OnGlobalLayoutListener {

        /* renamed from: a0 */
        public int f7808a0;

        /* renamed from: b0 */
        public float f7809b0;

        /* renamed from: c0 */
        public int f7810c0;

        /* renamed from: d0 */
        public boolean f7811d0;

        /* renamed from: e0 */
        public C1406n9 f7812e0;

        /* renamed from: f0 */
        public ValueAnimator f7813f0;

        public AutoSizedFrameLayout(Context context) {
            this(context, (AttributeSet) null);
        }

        public AutoSizedFrameLayout(Context context, AttributeSet attributeSet) {
            this(context, attributeSet, 0);
        }

        public AutoSizedFrameLayout(Context context, AttributeSet attributeSet, int i) {
            super(context, attributeSet, i);
            this.f7811d0 = false;
            setWillNotDraw(false);
            this.f7808a0 = context.getResources().getDimensionPixelSize(R.dimen.min_peek_height);
            this.f7813f0 = new ValueAnimator();
            this.f7813f0.setFloatValues(new float[]{1.0f, 1.0f});
            this.f7813f0.addUpdateListener(new cl3(this));
            this.f7813f0.setDuration(200);
            this.f7813f0.setInterpolator(new DecelerateInterpolator(2.0f));
        }

        /* renamed from: a */
        public /* synthetic */ void mo7143a(ValueAnimator valueAnimator) {
            setScaleX(((Float) valueAnimator.getAnimatedValue()).floatValue());
            setScaleY(((Float) valueAnimator.getAnimatedValue()).floatValue());
        }

        /* renamed from: a */
        public /* synthetic */ void mo7144a(C1406n9 n9Var) {
            this.f7813f0.setFloatValues(new float[]{getScaleX(), 1.0f - (((float) n9Var.mo8140u()) * 0.05f)});
            this.f7813f0.start();
            requestLayout();
        }

        public void onGlobalLayout() {
            BottomSheetBehavior b = BottomSheetBehavior.m2945b(this);
            b.mo3417c(this.f7809b0 < ((float) this.f7808a0));
            C2189w7.m15007e(this, this.f7810c0 - getTop());
            if (b.mo3427l()) {
                if (b.mo3428m() == 4) {
                    this.f7811d0 = true;
                    b.mo3420e(3);
                }
            } else if (this.f7811d0) {
                b.mo3416c((int) this.f7809b0);
                b.mo3420e(4);
                this.f7811d0 = false;
            } else {
                b.mo3406a((int) this.f7809b0, true);
                if (this.f7812e0.mo8140u() != 0) {
                    b.mo3420e(4);
                }
            }
            getRootView().getViewTreeObserver().removeOnGlobalLayoutListener(this);
        }

        public void onLayout(boolean z, int i, int i2, int i3, int i4) {
            super.onLayout(z, i, i2, i3, i4);
        }

        public void onMeasure(int i, int i2) {
            this.f7810c0 = getTop();
            super.onMeasure(View.MeasureSpec.makeMeasureSpec((int) (((float) View.MeasureSpec.getSize(i)) * 0.75f), View.MeasureSpec.getMode(i)), i2);
            this.f7809b0 = ((float) View.MeasureSpec.getSize(i2)) * 0.85f;
            C1406n9 n9Var = this.f7812e0;
            if (!(n9Var == null || n9Var.mo8140u() == 0)) {
                this.f7809b0 = (((float) getMeasuredWidth()) * 0.09f) + this.f7809b0;
            }
            getRootView().getViewTreeObserver().addOnGlobalLayoutListener(this);
        }

        public void setStackIndex(C1406n9 n9Var) {
            this.f7812e0 = n9Var;
            n9Var.mo13097a(new rw3(new bl3(this, n9Var)));
        }
    }

    /* renamed from: io.mrarm.mctoolbox.ui.AppBottomSheetDialog$a */
    public class C0952a extends BottomSheetBehavior.C0428d {

        /* renamed from: a */
        public final /* synthetic */ C0953b f7814a;

        public C0952a(C0953b bVar) {
            this.f7814a = bVar;
        }

        /* renamed from: a */
        public void mo3432a(View view, float f) {
        }
    }

    /* renamed from: io.mrarm.mctoolbox.ui.AppBottomSheetDialog$b */
    public static class C0953b {

        /* renamed from: a */
        public final ShapeDrawable f7816a = new ShapeDrawable(this.f7817b);

        /* renamed from: b */
        public RoundRectShape f7817b = new RoundRectShape(this.f7821f, (RectF) null, (float[]) null);

        /* renamed from: c */
        public final ValueAnimator f7818c;

        /* renamed from: d */
        public final float f7819d;

        /* renamed from: e */
        public boolean f7820e;

        /* renamed from: f */
        public final float[] f7821f = new float[8];

        public C0953b(float f, int i) {
            this.f7819d = f;
            this.f7816a.getPaint().setColor(i);
            this.f7818c = new ValueAnimator();
            this.f7818c.addUpdateListener(new dl3(this));
            this.f7818c.setDuration(200);
            mo7151a(true, false);
        }

        /* renamed from: a */
        public final void mo7149a(float f) {
            float[] fArr = this.f7821f;
            fArr[0] = f;
            fArr[1] = f;
            fArr[2] = f;
            fArr[3] = f;
            this.f7817b = new RoundRectShape(fArr, (RectF) null, (float[]) null);
            this.f7816a.setShape(this.f7817b);
        }

        /* renamed from: a */
        public /* synthetic */ void mo7150a(ValueAnimator valueAnimator) {
            mo7149a(((Float) valueAnimator.getAnimatedValue()).floatValue());
        }

        /* renamed from: a */
        public void mo7151a(boolean z, boolean z2) {
            if (this.f7820e != z || !z2) {
                this.f7820e = z;
                float f = z ? this.f7819d : 0.0f;
                if (z2) {
                    ValueAnimator valueAnimator = this.f7818c;
                    valueAnimator.setFloatValues(new float[]{((Float) valueAnimator.getAnimatedValue()).floatValue(), f});
                    this.f7818c.start();
                    return;
                }
                this.f7818c.cancel();
                mo7149a(f);
                this.f7818c.setFloatValues(new float[]{f, f});
            }
        }
    }

    static {
        Class<AppBottomSheetDialog> cls = AppBottomSheetDialog.class;
    }

    public AppBottomSheetDialog(Context context) {
        super(context, 2131820554);
        mo5811a(1);
    }

    /* renamed from: a */
    public /* synthetic */ void mo7135a(View view) {
        if (this.f7806b0) {
            cancel();
        }
    }

    /* renamed from: a */
    public final void mo7136a(ViewGroup viewGroup) {
        C0953b bVar = new C0953b((float) getContext().getResources().getDimensionPixelSize(R.dimen.bottom_sheet_dialog_radius), getContext().getResources().getColor(R.color.bottomSheetDialogBg));
        viewGroup.setBackground(bVar.f7816a);
        this.f7804Z = viewGroup;
        this.f7805a0 = BottomSheetBehavior.m2945b(viewGroup);
        this.f7805a0.mo3415b(true);
        ((BottomSheetBehaviorMod) this.f7805a0).mo3437a(new fl3(this, viewGroup, (float) getContext().getResources().getDimensionPixelSize(R.dimen.bottom_sheet_min_velocity)));
        this.f7805a0.mo3411a((BottomSheetBehavior.C0428d) new C0952a(bVar));
        findViewById(R.id.cancel).setOnClickListener(new el3(this));
    }

    /* renamed from: a */
    public /* synthetic */ void mo7137a(Window window) {
        Rect rect = new Rect();
        window.getDecorView().getWindowVisibleDisplayFrame(rect);
        if (this.f7804Z != null) {
            ((ViewGroup.MarginLayoutParams) findViewById(R.id.root).getLayoutParams()).bottomMargin = window.getDecorView().getRootView().getHeight() - rect.height();
            findViewById(R.id.root).requestLayout();
        }
    }

    /* renamed from: a */
    public /* synthetic */ boolean mo7138a(ViewGroup viewGroup, float f, View view, float f2) {
        if (this.f7806b0 || ((float) view.getTop()) > ((float) viewGroup.getHeight()) * 0.8f) {
            return true;
        }
        if ((view.getTop() > (viewGroup.getHeight() - this.f7805a0.mo3426k()) / 2 || f2 > f / 2.0f) && getCurrentFocus() != null) {
            ((InputMethodManager) getContext().getSystemService("input_method")).hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
        return false;
    }

    public void cancel() {
        BottomSheetBehavior bottomSheetBehavior = this.f7805a0;
        if (bottomSheetBehavior != null) {
            bottomSheetBehavior.mo3420e(5);
        } else {
            super.cancel();
        }
    }

    public void dismiss() {
        Window window = getWindow();
        if (window != null) {
            ((InputMethodManager) getContext().getSystemService("input_method")).hideSoftInputFromWindow(window.getDecorView().getRootView().getWindowToken(), 2);
        }
        super.dismiss();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Window window = getWindow();
        window.setLayout(-1, -1);
        window.setFlags(1024, 1024);
        if (Build.VERSION.SDK_INT >= 24) {
            window.setSoftInputMode(16);
        } else {
            window.getDecorView().getViewTreeObserver().addOnGlobalLayoutListener(new al3(this, window));
        }
    }

    public void onStart() {
        super.onStart();
        BottomSheetBehavior bottomSheetBehavior = this.f7805a0;
        if (bottomSheetBehavior != null) {
            bottomSheetBehavior.mo3420e(4);
        }
        is3 a = is3.m7141a(getContext());
        if (a != null) {
            a.f7966a.add(new WeakReference(this));
            a.f7967b.add(new C1406n9(0));
            int size = a.f7967b.size();
            while (true) {
                size--;
                if (size >= 0) {
                    a.f7967b.get(size).mo8139d(a.mo7269b((Dialog) a.f7966a.get(size).get()));
                } else {
                    this.f7807c0 = a.f7967b.get(a.mo7268a((Dialog) this));
                    ((AutoSizedFrameLayout) this.f7804Z).setStackIndex(this.f7807c0);
                    return;
                }
            }
        }
    }

    public void onStop() {
        int a;
        super.onStop();
        is3 a2 = is3.m7141a(getContext());
        if (!(a2 == null || (a = a2.mo7268a((Dialog) this)) == -1)) {
            a2.f7966a.remove(a);
            a2.f7967b.remove(a);
            for (int i = a - 1; i >= 0; i--) {
                a2.f7967b.get(i).mo8139d(a2.mo7269b((Dialog) a2.f7966a.get(i).get()));
            }
        }
        this.f7807c0 = null;
    }

    public void setCanceledOnTouchOutside(boolean z) {
        super.setCanceledOnTouchOutside(z);
        this.f7806b0 = z;
    }

    public void setContentView(int i) {
        super.setContentView((int) R.layout.app_bottom_sheet_dialog);
        ViewGroup viewGroup = (ViewGroup) findViewById(R.id.container);
        LayoutInflater.from(getContext()).inflate(i, viewGroup);
        mo7136a(viewGroup);
    }

    public void setContentView(View view) {
        super.setContentView((int) R.layout.app_bottom_sheet_dialog);
        ViewGroup viewGroup = (ViewGroup) findViewById(R.id.container);
        viewGroup.addView(view);
        mo7136a(viewGroup);
    }
}
