package p002io.mrarm.mctoolbox.p003ui.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;

/* renamed from: io.mrarm.mctoolbox.ui.view.ColorHuePicker */
public class ColorHuePicker extends bx3 {

    /* renamed from: p0 */
    public Bitmap f7833p0;

    /* renamed from: q0 */
    public Paint f7834q0;

    /* renamed from: r0 */
    public float[] f7835r0;

    /* renamed from: s0 */
    public Rect f7836s0;

    /* renamed from: t0 */
    public RectF f7837t0;

    public ColorHuePicker(Context context) {
        this(context, (AttributeSet) null);
    }

    public ColorHuePicker(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ColorHuePicker(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f7835r0 = new float[3];
        this.f7836s0 = new Rect();
        this.f7837t0 = new RectF();
        this.f7834q0 = new Paint();
    }

    /* renamed from: a */
    public void mo2685a(Canvas canvas) {
        int width = (getWidth() - getPaddingLeft()) - getPaddingRight();
        int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
        Bitmap bitmap = this.f7833p0;
        if (bitmap == null || bitmap.getHeight() != height) {
            int height2 = (getHeight() - getPaddingTop()) - getPaddingBottom();
            this.f7833p0 = Bitmap.createBitmap(1, height2, Bitmap.Config.ARGB_8888);
            float[] fArr = this.f7835r0;
            fArr[1] = 1.0f;
            fArr[2] = 1.0f;
            for (int i = 0; i < height2; i++) {
                float[] fArr2 = this.f7835r0;
                fArr2[0] = (((float) i) / ((float) (height2 - 1))) * 360.0f;
                this.f7833p0.setPixel(0, i, Color.HSVToColor(fArr2));
            }
            Paint paint = this.f7834q0;
            Bitmap bitmap2 = this.f7833p0;
            Shader.TileMode tileMode = Shader.TileMode.CLAMP;
            paint.setShader(new BitmapShader(bitmap2, tileMode, tileMode));
            this.f7836s0.set(0, 0, 1, height2);
        }
        canvas.translate((float) getPaddingLeft(), (float) getPaddingTop());
        this.f7837t0.set(0.0f, 0.0f, (float) width, (float) height);
        RectF rectF = this.f7837t0;
        float f = this.f2380c0;
        canvas.drawRoundRect(rectF, f, f, this.f7834q0);
        canvas.translate((float) (-getPaddingLeft()), (float) (-getPaddingTop()));
    }

    public int getColorValue() {
        this.f7835r0[0] = getValue();
        float[] fArr = this.f7835r0;
        fArr[1] = 1.0f;
        fArr[2] = 1.0f;
        return Color.HSVToColor(fArr);
    }

    public int getHandleFillColor() {
        return getColorValue();
    }

    public float getMaxValue() {
        return 360.0f;
    }
}
