package p002io.mrarm.mctoolbox.p003ui.view;

import android.content.Context;
import android.util.AttributeSet;

/* renamed from: io.mrarm.mctoolbox.ui.view.SwitchNoGlitch */
public class SwitchNoGlitch extends C1790s3 {
    public SwitchNoGlitch(Context context) {
        super(context);
    }

    public SwitchNoGlitch(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public SwitchNoGlitch(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public boolean isLaidOut() {
        return true;
    }
}
