package p002io.mrarm.mctoolbox.p003ui.view;

import android.content.Context;
import android.os.IBinder;
import android.util.AttributeSet;
import android.widget.LinearLayout;

/* renamed from: io.mrarm.mctoolbox.ui.view.PopupCrashWorkaroundLinearLayout */
public class PopupCrashWorkaroundLinearLayout extends LinearLayout {
    public PopupCrashWorkaroundLinearLayout(Context context) {
        super(context);
    }

    public PopupCrashWorkaroundLinearLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public PopupCrashWorkaroundLinearLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public IBinder getWindowToken() {
        return getApplicationWindowToken();
    }
}
