package p002io.mrarm.mctoolbox.p003ui.view;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.text.Editable;
import android.text.TextPaint;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import p002io.mrarm.mctoolbox.R;

/* renamed from: io.mrarm.mctoolbox.ui.view.LabelLayout */
public class LabelLayout extends FrameLayout {

    /* renamed from: a0 */
    public FrameLayout f7855a0;

    /* renamed from: b0 */
    public View f7856b0;

    /* renamed from: c0 */
    public CharSequence f7857c0;

    /* renamed from: d0 */
    public Paint f7858d0;

    /* renamed from: e0 */
    public ColorStateList f7859e0;

    /* renamed from: f0 */
    public int f7860f0;

    /* renamed from: g0 */
    public boolean f7861g0;

    /* renamed from: h0 */
    public float f7862h0;

    /* renamed from: i0 */
    public float f7863i0;

    /* renamed from: j0 */
    public float f7864j0;

    /* renamed from: k0 */
    public int f7865k0;

    /* renamed from: l0 */
    public int f7866l0;

    /* renamed from: m0 */
    public float f7867m0;

    /* renamed from: n0 */
    public boolean f7868n0;

    /* renamed from: o0 */
    public ValueAnimator f7869o0;

    /* renamed from: p0 */
    public Interpolator f7870p0;

    /* renamed from: q0 */
    public Interpolator f7871q0;

    /* renamed from: io.mrarm.mctoolbox.ui.view.LabelLayout$a */
    public class C0958a implements TextWatcher {
        public C0958a() {
        }

        public void afterTextChanged(Editable editable) {
            LabelLayout.this.mo7176a(false);
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }
    }

    public LabelLayout(Context context) {
        this(context, (AttributeSet) null);
    }

    public LabelLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    /* JADX INFO: finally extract failed */
    public LabelLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f7862h0 = 0.0f;
        this.f7863i0 = 0.0f;
        this.f7864j0 = 0.0f;
        this.f7865k0 = 0;
        this.f7866l0 = 0;
        this.f7867m0 = 1.0f;
        this.f7868n0 = false;
        this.f7870p0 = new C0595eb();
        this.f7871q0 = new AccelerateInterpolator();
        setWillNotDraw(false);
        setAddStatesFromChildren(true);
        this.f7855a0 = new FrameLayout(context);
        this.f7855a0.setAddStatesFromChildren(true);
        super.addView(this.f7855a0, -1, generateDefaultLayoutParams());
        this.f7858d0 = new TextPaint(129);
        this.f7858d0.setTypeface(Typeface.DEFAULT);
        this.f7865k0 = getResources().getDimensionPixelSize(R.dimen.abc_text_size_caption_material);
        this.f7866l0 = getResources().getDimensionPixelSize(R.dimen.abc_text_size_medium_material);
        this.f7858d0.setTextSize((float) this.f7865k0);
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(attributeSet, ag3.LabelLayout, 0, 0);
        try {
            this.f7868n0 = obtainStyledAttributes.getBoolean(3, false);
            this.f7857c0 = obtainStyledAttributes.getString(1);
            this.f7859e0 = obtainStyledAttributes.getColorStateList(0);
            this.f7860f0 = obtainStyledAttributes.getColor(2, 0);
            obtainStyledAttributes.recycle();
            this.f7858d0.setColor(this.f7859e0.getColorForState(getDrawableState(), this.f7859e0.getDefaultColor()));
            this.f7869o0 = ValueAnimator.ofFloat(new float[]{0.0f, 1.0f});
            this.f7869o0.setInterpolator(new LinearInterpolator());
            this.f7869o0.setDuration(200);
            this.f7869o0.addUpdateListener(new vw3(this));
            mo7179b();
            mo7174a();
        } catch (Throwable th) {
            obtainStyledAttributes.recycle();
            throw th;
        }
    }

    /* renamed from: a */
    public static boolean m7044a(View view) {
        if (view.isFocused()) {
            return true;
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            for (int i = 0; i < viewGroup.getChildCount(); i++) {
                if (m7044a(viewGroup.getChildAt(i))) {
                    return true;
                }
            }
        }
        return false;
    }

    /* renamed from: a */
    public final void mo7174a() {
        View view = this.f7856b0;
        if (view != null) {
            this.f7862h0 = (float) (this.f7856b0.getPaddingLeft() + view.getLeft());
            this.f7858d0.setTextSize((float) this.f7865k0);
            this.f7863i0 = ((float) getPaddingTop()) - this.f7858d0.ascent();
            this.f7858d0.setTextSize((float) this.f7866l0);
            int top = this.f7856b0.getTop();
            View view2 = this.f7856b0;
            int compoundPaddingTop = top + (view2 instanceof TextView ? ((TextView) view2).getCompoundPaddingTop() : view2.getPaddingTop());
            int bottom = this.f7856b0.getBottom();
            View view3 = this.f7856b0;
            this.f7864j0 = (float) (((compoundPaddingTop + (bottom - (view3 instanceof TextView ? ((TextView) view3).getCompoundPaddingBottom() : view3.getPaddingBottom()))) / 2) + this.f7855a0.getTop());
            this.f7864j0 = (((this.f7858d0.descent() - this.f7858d0.ascent()) / 2.0f) - this.f7858d0.descent()) + this.f7864j0;
        }
    }

    /* renamed from: a */
    public /* synthetic */ void mo7175a(ValueAnimator valueAnimator) {
        this.f7867m0 = ((Float) valueAnimator.getAnimatedValue()).floatValue();
        invalidate();
    }

    /* renamed from: a */
    public final void mo7176a(boolean z) {
        View view = this.f7856b0;
        boolean z2 = true;
        if (!(view != null && (view instanceof TextView) && ((TextView) view).getText().length() == 0) || m7044a((View) this)) {
            z2 = false;
        }
        mo7177a(z2, z);
    }

    /* renamed from: a */
    public void mo7177a(boolean z, boolean z2) {
        if (this.f7868n0) {
            z = false;
        }
        float f = this.f7867m0;
        float f2 = 0.0f;
        if (f <= 0.0f || f >= 1.0f) {
            if (z == (this.f7867m0 == 1.0f) && !this.f7869o0.isRunning()) {
                return;
            }
        }
        if (z2) {
            ValueAnimator valueAnimator = this.f7869o0;
            float[] fArr = new float[2];
            fArr[0] = this.f7867m0;
            if (z) {
                f2 = 1.0f;
            }
            fArr[1] = f2;
            valueAnimator.setFloatValues(fArr);
            this.f7869o0.start();
            return;
        }
        this.f7869o0.cancel();
        if (z) {
            f2 = 1.0f;
        }
        this.f7867m0 = f2;
    }

    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        this.f7856b0 = view;
        this.f7855a0.addView(view, i, layoutParams);
        mo7179b();
        if (view instanceof EditText) {
            ((EditText) view).addTextChangedListener(new C0958a());
        }
        mo7176a(false);
    }

    /* renamed from: b */
    public final void mo7179b() {
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) this.f7855a0.getLayoutParams();
        this.f7858d0.setTextSize((float) this.f7865k0);
        int i = (int) (-this.f7858d0.ascent());
        if (i != layoutParams.topMargin) {
            layoutParams.topMargin = i;
            this.f7855a0.requestLayout();
            requestLayout();
        }
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        int save = canvas.save();
        if (this.f7857c0 != null) {
            this.f7867m0 = Math.min(Math.max(this.f7867m0, 0.0f), 1.0f);
            float f = this.f7863i0;
            float interpolation = ((1.0f - this.f7871q0.getInterpolation(1.0f - this.f7867m0)) * (this.f7864j0 - f)) + f;
            this.f7858d0.setTextSize((float) (this.f7867m0 > 0.0f ? this.f7866l0 : this.f7865k0));
            this.f7858d0.setLinearText(false);
            float f2 = this.f7867m0;
            if (f2 > 0.0f && f2 < 1.0f) {
                int i = this.f7865k0;
                float interpolation2 = (((1.0f - this.f7870p0.getInterpolation(1.0f - f2)) * ((float) (this.f7866l0 - i))) + ((float) i)) / ((float) this.f7866l0);
                canvas.scale(interpolation2, interpolation2, this.f7862h0, interpolation);
                this.f7858d0.setLinearText(true);
            }
            CharSequence charSequence = this.f7857c0;
            canvas.drawText(charSequence, 0, charSequence.length(), this.f7862h0, interpolation, this.f7858d0);
        }
        canvas.restoreToCount(save);
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        if (this.f7856b0 != null) {
            boolean a = m7044a((View) this);
            this.f7858d0.setColor(a ? this.f7860f0 : this.f7859e0.getColorForState(getDrawableState(), this.f7859e0.getDefaultColor()));
            if (this.f7861g0 != a) {
                this.f7861g0 = a;
                mo7176a(true);
                invalidate();
            }
        }
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        mo7174a();
    }

    public void setHint(CharSequence charSequence) {
        this.f7857c0 = charSequence;
        mo7179b();
    }
}
