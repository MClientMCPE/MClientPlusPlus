package p002io.mrarm.mctoolbox.p003ui.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import com.google.android.material.textfield.TextInputLayout;
import p002io.mrarm.mctoolbox.R;

/* renamed from: io.mrarm.mctoolbox.ui.view.StaticLabelTextInputLayout */
public class StaticLabelTextInputLayout extends TextInputLayout {

    /* renamed from: p1 */
    public boolean f7877p1;

    /* renamed from: q1 */
    public boolean f7878q1;

    /* renamed from: r1 */
    public CharSequence f7879r1;

    /* renamed from: s1 */
    public Paint f7880s1;

    /* renamed from: t1 */
    public int f7881t1;

    /* renamed from: u1 */
    public int f7882u1;

    /* renamed from: v1 */
    public boolean f7883v1;

    /* renamed from: w1 */
    public float f7884w1;

    /* renamed from: x1 */
    public float f7885x1;

    public StaticLabelTextInputLayout(Context context) {
        this(context, (AttributeSet) null);
    }

    public StaticLabelTextInputLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public StaticLabelTextInputLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f7877p1 = false;
        this.f7878q1 = false;
        this.f7884w1 = 0.0f;
        this.f7885x1 = 0.0f;
        this.f7880s1 = new TextPaint(129);
        this.f7880s1.setTypeface(getTypeface());
        this.f7880s1.setTextSize((float) getResources().getDimensionPixelSize(R.dimen.abc_text_size_caption_material));
        this.f7881t1 = getDefaultHintTextColor().getColorForState(LinearLayout.ENABLED_STATE_SET, 0);
        this.f7882u1 = getHintTextColor().getColorForState(LinearLayout.ENABLED_FOCUSED_STATE_SET, 0);
        this.f7880s1.setColor(this.f7881t1);
    }

    /* renamed from: a */
    public void mo7191a(boolean z, CharSequence charSequence) {
        CharSequence charSequence2 = this.f7879r1;
        this.f7879r1 = charSequence;
        if (z != this.f7877p1) {
            this.f7878q1 = mo7193t();
            int i = 0;
            if (z) {
                setHintEnabled(false);
            }
            this.f7877p1 = z;
            FrameLayout frameLayout = (FrameLayout) getChildAt(0);
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) frameLayout.getLayoutParams();
            if (z) {
                i = (int) (-this.f7880s1.ascent());
            }
            if (i != layoutParams.topMargin) {
                layoutParams.topMargin = i;
                frameLayout.requestLayout();
            }
            if (!z) {
                setHintEnabled(this.f7878q1);
                setHint(charSequence2);
            }
        }
    }

    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        super.addView(view, i, layoutParams);
        if (getEditText() != null) {
            setForceShowHint(true);
        }
    }

    public void draw(Canvas canvas) {
        CharSequence charSequence;
        super.draw(canvas);
        int save = canvas.save();
        if (this.f7877p1 && (charSequence = this.f7879r1) != null) {
            canvas.drawText(charSequence, 0, charSequence.length(), this.f7884w1, this.f7885x1 - this.f7880s1.ascent(), this.f7880s1);
        }
        canvas.restoreToCount(save);
    }

    public void drawableStateChanged() {
        boolean isFocused;
        int i;
        Paint paint;
        super.drawableStateChanged();
        if (getEditText() != null && this.f7883v1 != (isFocused = getEditText().isFocused())) {
            this.f7883v1 = isFocused;
            if (isFocused) {
                paint = this.f7880s1;
                i = this.f7882u1;
            } else {
                paint = this.f7880s1;
                i = this.f7881t1;
            }
            paint.setColor(i);
        }
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        if (getEditText() != null) {
            this.f7884w1 = (float) (getEditText().getCompoundPaddingLeft() + getEditText().getLeft());
            this.f7885x1 = (float) getPaddingTop();
        }
    }

    public void setForceShowHint(boolean z) {
        mo7191a(z, z ? getHint() : null);
    }

    public void setHintEnabled(boolean z) {
        if (this.f7877p1) {
            this.f7878q1 = z;
        } else {
            super.setHintEnabled(z);
        }
    }

    /* renamed from: t */
    public boolean mo7193t() {
        return this.f3343n0 || this.f7877p1;
    }
}
