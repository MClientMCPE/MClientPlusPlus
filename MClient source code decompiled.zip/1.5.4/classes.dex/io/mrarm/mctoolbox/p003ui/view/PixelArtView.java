package p002io.mrarm.mctoolbox.p003ui.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;

/* renamed from: io.mrarm.mctoolbox.ui.view.PixelArtView */
public class PixelArtView extends View {

    /* renamed from: a0 */
    public final Paint f7873a0;

    /* renamed from: b0 */
    public Bitmap f7874b0;

    /* renamed from: c0 */
    public final Rect f7875c0;

    /* renamed from: d0 */
    public final Rect f7876d0;

    public PixelArtView(Context context) {
        this(context, (AttributeSet) null);
    }

    public PixelArtView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public PixelArtView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f7873a0 = new Paint();
        this.f7875c0 = new Rect();
        this.f7876d0 = new Rect();
        setWillNotDraw(false);
        this.f7873a0.setAntiAlias(false);
        this.f7873a0.setFilterBitmap(false);
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        Bitmap bitmap = this.f7874b0;
        if (bitmap != null) {
            this.f7875c0.set(0, 0, bitmap.getWidth(), this.f7874b0.getHeight());
            this.f7876d0.set(getPaddingLeft(), getPaddingTop(), getWidth() - getPaddingRight(), getHeight() - getPaddingBottom());
            canvas.drawBitmap(this.f7874b0, this.f7875c0, this.f7876d0, this.f7873a0);
        }
    }

    public void setBitmap(Bitmap bitmap) {
        this.f7874b0 = bitmap;
    }
}
