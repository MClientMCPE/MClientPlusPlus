package p002io.mrarm.mctoolbox.p003ui.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.List;
import p000.bx3;

/* renamed from: io.mrarm.mctoolbox.ui.view.ColorPicker */
public class ColorPicker extends View {

    /* renamed from: a0 */
    public float f7838a0;

    /* renamed from: b0 */
    public float f7839b0;

    /* renamed from: c0 */
    public float f7840c0;

    /* renamed from: d0 */
    public Paint f7841d0;

    /* renamed from: e0 */
    public RectF f7842e0;

    /* renamed from: f0 */
    public LinearGradient f7843f0;

    /* renamed from: g0 */
    public Paint f7844g0;

    /* renamed from: h0 */
    public LinearGradient f7845h0;

    /* renamed from: i0 */
    public Paint f7846i0;

    /* renamed from: j0 */
    public float f7847j0;

    /* renamed from: k0 */
    public Paint f7848k0;

    /* renamed from: l0 */
    public Paint f7849l0;

    /* renamed from: m0 */
    public float f7850m0;

    /* renamed from: n0 */
    public boolean f7851n0;

    /* renamed from: o0 */
    public float[] f7852o0;

    /* renamed from: p0 */
    public ColorHuePicker f7853p0;

    /* renamed from: q0 */
    public List<C0957a> f7854q0;

    /* renamed from: io.mrarm.mctoolbox.ui.view.ColorPicker$a */
    public interface C0957a {
        /* renamed from: a */
        void mo7173a(int i);
    }

    public ColorPicker(Context context) {
        this(context, (AttributeSet) null);
    }

    public ColorPicker(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ColorPicker(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f7838a0 = 0.0f;
        this.f7839b0 = 1.0f;
        this.f7840c0 = 1.0f;
        this.f7842e0 = new RectF();
        this.f7851n0 = false;
        this.f7852o0 = new float[3];
        this.f7854q0 = new ArrayList();
        this.f7841d0 = new Paint();
        this.f7844g0 = new Paint();
        this.f7844g0.setDither(true);
        this.f7846i0 = new Paint();
        this.f7846i0.setDither(true);
        this.f7848k0 = new Paint();
        this.f7848k0.setStyle(Paint.Style.STROKE);
        this.f7848k0.setStrokeWidth(TypedValue.applyDimension(1, 3.0f, getResources().getDisplayMetrics()));
        this.f7849l0 = new Paint();
        this.f7850m0 = TypedValue.applyDimension(1, 8.0f, getResources().getDisplayMetrics());
        this.f7847j0 = TypedValue.applyDimension(1, 2.0f, getResources().getDisplayMetrics());
    }

    private float getHandleX() {
        return (((float) ((getWidth() - getPaddingLeft()) - getPaddingRight())) * this.f7839b0) + ((float) getPaddingLeft());
    }

    private float getHandleY() {
        return ((1.0f - this.f7840c0) * ((float) ((getHeight() - getPaddingTop()) - getPaddingBottom()))) + ((float) getPaddingTop());
    }

    /* renamed from: a */
    public void mo7165a(ColorHuePicker colorHuePicker) {
        this.f7853p0 = colorHuePicker;
        setHue(colorHuePicker.getValue());
        colorHuePicker.mo2686a((bx3.C0328a) new xw3(this));
    }

    /* renamed from: a */
    public void mo7166a(C0957a aVar) {
        this.f7854q0.add(aVar);
    }

    public void draw(Canvas canvas) {
        int i;
        Paint paint;
        super.draw(canvas);
        float[] fArr = this.f7852o0;
        fArr[0] = this.f7838a0;
        fArr[1] = 1.0f;
        fArr[2] = 1.0f;
        this.f7841d0.setColor(Color.HSVToColor(fArr));
        this.f7842e0.set((float) getPaddingLeft(), (float) getPaddingTop(), (float) (getWidth() - getPaddingRight()), (float) (getHeight() - getPaddingBottom()));
        RectF rectF = this.f7842e0;
        float f = this.f7847j0;
        canvas.drawRoundRect(rectF, f, f, this.f7841d0);
        RectF rectF2 = this.f7842e0;
        float f2 = this.f7847j0;
        canvas.drawRoundRect(rectF2, f2, f2, this.f7844g0);
        RectF rectF3 = this.f7842e0;
        float f3 = this.f7847j0;
        canvas.drawRoundRect(rectF3, f3, f3, this.f7846i0);
        int color = getColor();
        this.f7849l0.setColor(color);
        if (Color.red(color) <= 140 || Color.green(color) <= 140 || Color.blue(color) <= 140) {
            paint = this.f7848k0;
            i = -1;
        } else {
            paint = this.f7848k0;
            i = -16777216;
        }
        paint.setColor(i);
        float handleX = getHandleX();
        float handleY = getHandleY();
        canvas.drawCircle(handleX, handleY, this.f7850m0, this.f7849l0);
        canvas.drawCircle(handleX, handleY, this.f7850m0, this.f7848k0);
    }

    public int getColor() {
        float[] fArr = this.f7852o0;
        fArr[0] = this.f7838a0;
        fArr[1] = this.f7839b0;
        fArr[2] = this.f7840c0;
        return Color.HSVToColor(fArr);
    }

    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        this.f7843f0 = new LinearGradient((float) getPaddingLeft(), 0.0f, (float) (i - getPaddingRight()), 0.0f, -1, 16777215, Shader.TileMode.CLAMP);
        this.f7844g0.setShader(this.f7843f0);
        this.f7845h0 = new LinearGradient(0.0f, (float) getPaddingTop(), 0.0f, (float) (i2 - getPaddingRight()), 0, -16777216, Shader.TileMode.CLAMP);
        this.f7846i0.setShader(this.f7845h0);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.f7851n0 = true;
            getParent().requestDisallowInterceptTouchEvent(true);
        }
        if (this.f7851n0 && (motionEvent.getAction() == 0 || motionEvent.getAction() == 2 || motionEvent.getAction() == 1)) {
            this.f7839b0 = (motionEvent.getX() - ((float) getPaddingLeft())) / ((float) ((getWidth() - getPaddingLeft()) - getPaddingRight()));
            this.f7840c0 = 1.0f - ((motionEvent.getY() - ((float) getPaddingTop())) / ((float) ((getHeight() - getPaddingTop()) - getPaddingBottom())));
            this.f7839b0 = Math.min(Math.max(this.f7839b0, 0.0f), 1.0f);
            this.f7840c0 = Math.min(Math.max(this.f7840c0, 0.0f), 1.0f);
            invalidate();
            int color = getColor();
            for (C0957a a : this.f7854q0) {
                a.mo7173a(color);
            }
        }
        return motionEvent.getAction() == 0 || motionEvent.getAction() == 2 || motionEvent.getAction() == 1 || motionEvent.getAction() == 3 || super.onTouchEvent(motionEvent);
    }

    public void setColor(int i) {
        Color.RGBToHSV(Color.red(i), Color.green(i), Color.blue(i), this.f7852o0);
        float[] fArr = this.f7852o0;
        this.f7839b0 = fArr[1];
        this.f7840c0 = fArr[2];
        ColorHuePicker colorHuePicker = this.f7853p0;
        if (colorHuePicker != null) {
            colorHuePicker.setValue(fArr[0]);
        } else {
            setHue(fArr[0]);
        }
    }

    public void setHue(float f) {
        this.f7838a0 = f;
        invalidate();
        int color = getColor();
        for (C0957a a : this.f7854q0) {
            a.mo7173a(color);
        }
    }
}
