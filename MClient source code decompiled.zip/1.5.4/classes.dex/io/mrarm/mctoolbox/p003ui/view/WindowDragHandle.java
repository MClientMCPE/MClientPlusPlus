package p002io.mrarm.mctoolbox.p003ui.view;

import android.content.Context;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.widget.LinearLayout;

/* renamed from: io.mrarm.mctoolbox.ui.view.WindowDragHandle */
public class WindowDragHandle extends LinearLayout {

    /* renamed from: a0 */
    public final lw3 f7886a0;

    public WindowDragHandle(Context context) {
        this(context, (AttributeSet) null);
    }

    public WindowDragHandle(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public WindowDragHandle(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f7886a0 = new lw3(TypedValue.applyDimension(1, 4.0f, context.getResources().getDisplayMetrics()));
    }

    public lw3 getDragHelper() {
        return this.f7886a0;
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        return this.f7886a0.mo8497a(motionEvent);
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        this.f7886a0.mo8497a(motionEvent);
        return true;
    }
}
