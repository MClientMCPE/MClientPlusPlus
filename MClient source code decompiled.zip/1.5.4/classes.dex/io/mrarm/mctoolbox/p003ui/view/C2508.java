package p002io.mrarm.mctoolbox.p003ui.view;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/* renamed from: io.mrarm.mctoolbox.ui.view.⁤⁤⁠⁤⁤⁠⁠⁠⁤⁠⁤⁤  reason: contains not printable characters */
public class C2508 {

    /* renamed from: ⁣⁣⁣⁣⁣⁠⁤⁠⁤⁤⁣⁠⁠⁤⁠⁣  reason: not valid java name and contains not printable characters */
    public static int f18649 = -98;

    /* renamed from: ⁠⁣⁤⁣⁤⁠⁤⁠⁤⁣⁠⁣⁣⁠⁠⁣  reason: not valid java name and contains not printable characters */
    public static Class m17555(Object obj) {
        int r1 = C2507.m17548();
        char c = 20104;
        while (true) {
            c ^= 20121;
            switch (c) {
                case 17:
                    if (r1 < 0) {
                        c = 20197;
                        break;
                    }
                case '>':
                    c = 20166;
                    break;
                case '_':
                    char c2 = 20228;
                    while (true) {
                        c2 ^= 20245;
                        switch (c2) {
                            case 17:
                                c2 = 20910;
                                break;
                            case 7867:
                                return null;
                        }
                    }
                    break;
                case '|':
                    return C2498.m17486((String) obj);
            }
        }
    }

    /* renamed from: ⁣⁠⁠⁤⁠⁠⁣⁠⁠⁤⁠⁣  reason: not valid java name and contains not printable characters */
    public static Field[] m17556(Object obj) {
        int r1 = C2507.m17548();
        char c = 21003;
        while (true) {
            c ^= 21020;
            switch (c) {
                case 23:
                    if (r1 <= 0) {
                        c = 21096;
                        break;
                    }
                case '6':
                    c = 21065;
                    break;
                case 'U':
                    char c2 = 21127;
                    while (true) {
                        c2 ^= 21144;
                        switch (c2) {
                            case 31:
                                c2 = 21158;
                                break;
                            case '>':
                                return null;
                        }
                    }
                    break;
                case 't':
                    return ((Class) obj).getFields();
            }
        }
    }

    /* renamed from: ⁣⁣⁣⁣⁣⁠⁠⁠⁠⁣⁣⁤⁣⁤⁠⁠⁣  reason: not valid java name and contains not printable characters */
    public static void m17557(Object obj, boolean z) {
        int r1 = C2505.m17532();
        char c = 21902;
        while (true) {
            c ^= 21919;
            switch (c) {
                case 17:
                    if (r1 < 0) {
                        c = 21995;
                        break;
                    }
                case '2':
                    c = 21964;
                    break;
                case 'S':
                    char c2 = 22026;
                    while (true) {
                        c2 ^= 22043;
                        switch (c2) {
                            case 17:
                                c2 = 22057;
                                break;
                            case '2':
                                return;
                        }
                    }
                    break;
                case 't':
                    ((Method) obj).setAccessible(z);
                    return;
            }
        }
    }

    /* renamed from: ⁣⁣⁣⁣⁤⁤⁠⁠⁠⁣⁣⁣  reason: not valid java name and contains not printable characters */
    public static String m17558() {
        int r1 = C2506.m17541();
        char c = 22150;
        while (true) {
            c ^= 22167;
            switch (c) {
                case 17:
                    if (r1 <= 0) {
                        c = 22894;
                        break;
                    }
                case 4007:
                    c = 22863;
                    break;
                case 4056:
                    char c2 = 22925;
                    while (true) {
                        c2 ^= 22942;
                        switch (c2) {
                            case 19:
                                c2 = 22956;
                                break;
                            case '2':
                                return null;
                        }
                    }
                    break;
                case 4089:
                    return "ۢۖ۠";
            }
        }
    }

    /* renamed from: ⁣⁤⁠⁠⁠⁠⁠⁠⁣⁣⁠⁠⁠⁠⁣⁣⁤  reason: not valid java name and contains not printable characters */
    public static String m17559() {
        int r1 = C2507.m17548();
        char c = 23049;
        while (true) {
            c ^= 23066;
            switch (c) {
                case 19:
                    if (r1 <= 0) {
                        c = 23793;
                        break;
                    }
                case '2':
                    c = 23111;
                    break;
                case ']':
                    char c2 = 23824;
                    while (true) {
                        c2 ^= 23841;
                        switch (c2) {
                            case 14:
                                return null;
                            case '1':
                                c2 = 23855;
                                break;
                        }
                    }
                    break;
                case 1771:
                    return "۠ۘ۠";
            }
        }
    }

    /* renamed from: ⁣⁤⁠⁠⁠⁤⁠⁤⁣⁤⁤⁠⁤⁤  reason: not valid java name and contains not printable characters */
    public static String m17560() {
        int r1 = C2504.m17531();
        char c = 23948;
        while (true) {
            c ^= 23965;
            switch (c) {
                case 17:
                    if (r1 > 0) {
                        c = 24041;
                        break;
                    }
                case '6':
                    c = 24010;
                    break;
                case 'W':
                    char c2 = 24072;
                    while (true) {
                        c2 ^= 24089;
                        switch (c2) {
                            case 17:
                                c2 = 24754;
                                break;
                            case 16043:
                                return null;
                        }
                    }
                    break;
                case 't':
                    return "ۡ۬ۖ";
            }
        }
    }

    /* renamed from: ⁣⁤⁠⁠⁠⁤⁤⁠⁤⁣⁠⁣⁤⁣⁤⁠  reason: not valid java name and contains not printable characters */
    public static Class m17561(Object obj) {
        int r1 = C2507.m17548();
        char c = 24847;
        while (true) {
            c ^= 24864;
            switch (c) {
                case '/':
                    if (r1 < 0) {
                        c = 24940;
                        break;
                    }
                case 14:
                    c = 24909;
                    break;
                case 'L':
                    return ((Class) obj).getSuperclass();
                case 'm':
                    char c2 = 24971;
                    while (true) {
                        c2 ^= 24988;
                        switch (c2) {
                            case 23:
                                c2 = 25002;
                                break;
                            case '6':
                                return null;
                        }
                    }
                    break;
            }
        }
    }

    /* renamed from: ⁤⁠⁤⁣  reason: not valid java name and contains not printable characters */
    public static Object m17562(Object obj, Object obj2) {
        int r1 = C2505.m17532();
        char c = 25746;
        while (true) {
            c ^= 25763;
            switch (c) {
                case '1':
                    if (r1 <= 0) {
                        c = 25839;
                        break;
                    }
                case 18:
                    c = 25808;
                    break;
                case 'L':
                    return ((Field) obj).get(obj2);
                case 's':
                    char c2 = 25870;
                    while (true) {
                        c2 ^= 25887;
                        switch (c2) {
                            case 17:
                                c2 = 25901;
                                break;
                            case '2':
                                return null;
                        }
                    }
                    break;
            }
        }
    }

    /* renamed from: ⁤⁠⁤⁤⁣⁠⁠⁤⁠⁣⁣⁤⁠⁠⁠  reason: not valid java name and contains not printable characters */
    public static void m17563(Object obj, boolean z) {
        int r1 = C2507.m17548();
        char c = 25994;
        while (true) {
            c ^= 26011;
            switch (c) {
                case 17:
                    if (r1 <= 0) {
                        c = 26738;
                        break;
                    }
                case 3503:
                    c = 26707;
                    break;
                case 3528:
                    char c2 = 26769;
                    while (true) {
                        c2 ^= 26786;
                        switch (c2) {
                            case 18:
                                return;
                            case '3':
                                c2 = 26800;
                                break;
                        }
                    }
                    break;
                case 3561:
                    ((Field) obj).setAccessible(z);
                    return;
            }
        }
    }

    /* renamed from: ⁤⁠⁤⁤⁣⁣⁣⁣⁣⁠⁣⁤⁣⁠⁣⁤⁠  reason: not valid java name and contains not printable characters */
    public static String m17564(short[] sArr, int i, int i2, int i3) {
        char[] cArr = new char[i2];
        int i4 = 0;
        while (true) {
            char c = 26893;
            while (true) {
                c ^= 26910;
                switch (c) {
                    case 19:
                        if (i4 < i2) {
                            c = 47818;
                            break;
                        }
                    case '2':
                        c = 26955;
                        break;
                    case 'U':
                        return new String(cArr);
                    case 54228:
                        short s = sArr[0 - ((0 - i) - i4)];
                        cArr[i4] = (char) ((char) ((s & (i3 ^ -1)) | ((s ^ -1) & i3)));
                        i4 = 1 - (0 - i4);
                        char c2 = 47849;
                        while (true) {
                            c2 ^= 47866;
                            switch (c2) {
                                case 19:
                                    c2 = 47880;
                                    break;
                                case 498:
                            }
                        }
                        break;
                }
            }
        }
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ⁤⁠⁤⁤⁤⁠⁤⁤⁣⁤⁠⁠⁣  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.Object m17565(java.lang.Object r3, java.lang.Object r4, java.lang.Object r5) {
        /*
            int r1 = p002io.mrarm.mctoolbox.p003ui.view.C2507.m17548()
            r0 = 1686373(0x19bb65, float:2.363112E-39)
        L_0x0007:
            r2 = 1686390(0x19bb76, float:2.363136E-39)
            r0 = r0 ^ r2
            switch(r0) {
                case 19: goto L_0x000f;
                case 180: goto L_0x0019;
                case 213: goto L_0x0024;
                case 242: goto L_0x0015;
                default: goto L_0x000e;
            }
        L_0x000e:
            goto L_0x0007
        L_0x000f:
            if (r1 > 0) goto L_0x0015
            r0 = 1686466(0x19bbc2, float:2.363242E-39)
            goto L_0x0007
        L_0x0015:
            r0 = 1686435(0x19bba3, float:2.363199E-39)
            goto L_0x0007
        L_0x0019:
            java.lang.Class r3 = (java.lang.Class) r3
            java.lang.String r4 = (java.lang.String) r4
            java.lang.String r5 = (java.lang.String) r5
            java.lang.Object r0 = p002io.mrarm.mctoolbox.p003ui.view.C2498.m17487((java.lang.Class) r3, (java.lang.String) r4, (java.lang.String) r5)
        L_0x0023:
            return r0
        L_0x0024:
            r0 = 0
            r1 = 1686497(0x19bbe1, float:2.363286E-39)
        L_0x0028:
            r2 = 1686514(0x19bbf2, float:2.36331E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 19: goto L_0x0030;
                case 1401: goto L_0x0023;
                default: goto L_0x002f;
            }
        L_0x002f:
            goto L_0x0028
        L_0x0030:
            r1 = 1687179(0x19be8b, float:2.364241E-39)
            goto L_0x0028
        */
        throw new UnsupportedOperationException("Method not decompiled: p002io.mrarm.mctoolbox.p003ui.view.C2508.m17565(java.lang.Object, java.lang.Object, java.lang.Object):java.lang.Object");
    }

    /* renamed from: ⁤⁤⁠⁤⁤⁣⁤⁠⁠⁤⁠⁠⁠⁣⁣⁠  reason: not valid java name and contains not printable characters */
    public static int m17566() {
        int i = 0;
        String str = "ۘ۟ۧ";
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        while (true) {
            switch (C2498.m17512((Object) str)) {
                case 1738715:
                    i = i3 & i4;
                    str = "ۨۤۥ";
                    break;
                case 1739154:
                    i3 = i4 ^ -1;
                    str = "ۙ۫۫";
                    break;
                case 1741305:
                    i2 = i3 & -1754857;
                    str = "ۢۜۚ";
                    break;
                case 1749472:
                    i3 = 1754856;
                    str = "ۗۖۚ";
                    break;
                case 1754449:
                    return i3;
                case 1755497:
                    i3 = i | i2;
                    str = "ۧۡ۫";
                    break;
                default:
                    i4 = C2498.m17512((Object) "ۧ۬ۦ");
                    str = "ۗۤ۟";
                    break;
            }
        }
    }
}
