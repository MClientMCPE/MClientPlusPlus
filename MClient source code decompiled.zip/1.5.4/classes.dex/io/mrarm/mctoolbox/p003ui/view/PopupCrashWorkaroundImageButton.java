package p002io.mrarm.mctoolbox.p003ui.view;

import android.content.Context;
import android.os.IBinder;
import android.util.AttributeSet;

/* renamed from: io.mrarm.mctoolbox.ui.view.PopupCrashWorkaroundImageButton */
public class PopupCrashWorkaroundImageButton extends C0983j2 {
    public PopupCrashWorkaroundImageButton(Context context) {
        super(context);
    }

    public PopupCrashWorkaroundImageButton(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public PopupCrashWorkaroundImageButton(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    public IBinder getWindowToken() {
        return getApplicationWindowToken();
    }
}
