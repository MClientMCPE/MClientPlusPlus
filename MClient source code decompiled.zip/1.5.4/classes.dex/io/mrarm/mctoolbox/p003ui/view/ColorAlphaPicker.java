package p002io.mrarm.mctoolbox.p003ui.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.util.TypedValue;

/* renamed from: io.mrarm.mctoolbox.ui.view.ColorAlphaPicker */
public class ColorAlphaPicker extends bx3 {

    /* renamed from: p0 */
    public Bitmap f7826p0;

    /* renamed from: q0 */
    public Paint f7827q0;

    /* renamed from: r0 */
    public RectF f7828r0;

    /* renamed from: s0 */
    public float f7829s0;

    /* renamed from: t0 */
    public LinearGradient f7830t0;

    /* renamed from: u0 */
    public Paint f7831u0;

    /* renamed from: v0 */
    public int f7832v0;

    public ColorAlphaPicker(Context context) {
        this(context, (AttributeSet) null);
    }

    public ColorAlphaPicker(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ColorAlphaPicker(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f7828r0 = new RectF();
        this.f7827q0 = new Paint();
        this.f7829s0 = TypedValue.applyDimension(1, 4.0f, getResources().getDisplayMetrics());
        int i2 = (int) (this.f7829s0 * 2.0f);
        this.f7826p0 = Bitmap.createBitmap(i2, i2, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(this.f7826p0);
        Paint paint = new Paint();
        paint.setColor(-1118482);
        float f = this.f7829s0;
        Canvas canvas2 = canvas;
        Paint paint2 = paint;
        canvas2.drawRect(0.0f, 0.0f, f, f, paint2);
        float f2 = this.f7829s0;
        float f3 = f2 * 2.0f;
        canvas2.drawRect(f2, f2, f3, f3, paint2);
        paint.setColor(-9079435);
        float f4 = this.f7829s0;
        Canvas canvas3 = canvas;
        canvas3.drawRect(f4, 0.0f, f4 * 2.0f, f4, paint2);
        float f5 = this.f7829s0;
        canvas3.drawRect(0.0f, f5, f5, f5 * 2.0f, paint2);
        Paint paint3 = this.f7827q0;
        Bitmap bitmap = this.f7826p0;
        Shader.TileMode tileMode = Shader.TileMode.REPEAT;
        paint3.setShader(new BitmapShader(bitmap, tileMode, tileMode));
        this.f7831u0 = new Paint();
        this.f7831u0.setDither(true);
        setColor(-1);
    }

    /* renamed from: a */
    public void mo2685a(Canvas canvas) {
        int width = (getWidth() - getPaddingLeft()) - getPaddingRight();
        int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
        canvas.save();
        canvas.translate((float) getPaddingLeft(), (float) getPaddingTop());
        this.f7828r0.set(0.0f, 0.0f, (float) width, (float) height);
        RectF rectF = this.f7828r0;
        float f = this.f2380c0;
        canvas.drawRoundRect(rectF, f, f, this.f7827q0);
        this.f7831u0.setColor(-65536);
        RectF rectF2 = this.f7828r0;
        float f2 = this.f2380c0;
        canvas.drawRoundRect(rectF2, f2, f2, this.f7831u0);
        canvas.restore();
    }

    public int getHandleFillColor() {
        return this.f7832v0;
    }

    public float getMaxValue() {
        return 0.0f;
    }

    public float getMinValue() {
        return 1.0f;
    }

    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        this.f7830t0 = new LinearGradient(0.0f, (float) getPaddingTop(), 0.0f, (float) (i2 - getPaddingRight()), -1, 16777215, Shader.TileMode.CLAMP);
        this.f7831u0.setShader(this.f7830t0);
    }

    public void setColor(int i) {
        int i2 = i | -16777216;
        this.f7832v0 = i2;
        this.f7831u0.setColorFilter(new PorterDuffColorFilter(i2, PorterDuff.Mode.MULTIPLY));
        invalidate();
    }
}
