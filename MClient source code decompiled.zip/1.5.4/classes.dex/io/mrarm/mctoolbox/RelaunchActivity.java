package p002io.mrarm.mctoolbox;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Process;
import android.util.Log;
import android.view.View;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/* renamed from: io.mrarm.mctoolbox.RelaunchActivity */
public class RelaunchActivity extends Activity {

    /* renamed from: a0 */
    public static boolean f7800a0;

    /* renamed from: X */
    public ServerSocket f7801X;

    /* renamed from: Y */
    public boolean f7802Y = false;

    /* renamed from: Z */
    public boolean f7803Z = false;

    @SuppressLint({"PrivateApi"})
    /* renamed from: a */
    public static void m7017a(Context context) {
        Object obj;
        if (!f7800a0) {
            try {
                obj = ActivityManager.class.getDeclaredMethod("getService", new Class[0]).invoke((Object) null, new Object[0]);
            } catch (Exception unused) {
                try {
                    obj = Class.forName("android.app.ActivityManagerNative").getDeclaredMethod("getDefault", new Class[0]).invoke((Object) null, new Object[0]);
                } catch (Exception e) {
                    e.printStackTrace();
                    throw new RuntimeException(e);
                }
            }
            Class<?> cls = Class.forName("android.app.IActivityManager");
            Class[] clsArr = new Class[8];
            clsArr[0] = ComponentName.class;
            clsArr[1] = String.class;
            clsArr[2] = Integer.TYPE;
            clsArr[3] = Bundle.class;
            clsArr[4] = Class.forName("android.app.IInstrumentationWatcher");
            clsArr[5] = Class.forName("android.app.IUiAutomationConnection");
            clsArr[6] = Integer.TYPE;
            clsArr[7] = String.class;
            if (((Boolean) cls.getDeclaredMethod("startInstrumentation", clsArr).invoke(obj, new Object[]{new ComponentName(context, RelaunchInstrumentation.class), null, 0, new Bundle(), null, null, Integer.valueOf(Process.myUserHandle().hashCode()), "armeabi-v7a"})).booleanValue()) {
                f7800a0 = true;
                Log.i("RelaunchActivity", "Restart OK");
                return;
            }
            throw new RuntimeException("Restart failed");
        }
    }

    /* renamed from: a */
    public /* synthetic */ void mo7128a() {
        this.f7802Y = true;
        if (this.f7803Z) {
            m7017a(this);
        }
    }

    /* renamed from: a */
    public /* synthetic */ void mo7129a(String str, Runnable runnable) {
        String readLine;
        try {
            Socket accept = this.f7801X.accept();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(accept.getInputStream()));
            do {
                readLine = bufferedReader.readLine();
                if (readLine == null || readLine.equals("")) {
                    OutputStream outputStream = accept.getOutputStream();
                    outputStream.write(("HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nConnection: Closed\r\n\r\n" + str).getBytes("UTF-8"));
                    outputStream.close();
                    runnable.run();
                }
                readLine = bufferedReader.readLine();
                break;
            } while (readLine.equals(""));
            OutputStream outputStream2 = accept.getOutputStream();
            outputStream2.write(("HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nConnection: Closed\r\n\r\n" + str).getBytes("UTF-8"));
            outputStream2.close();
            runnable.run();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /* renamed from: b */
    public /* synthetic */ void mo7130b() {
        this.f7803Z = true;
        if (this.f7802Y) {
            m7017a(this);
        }
    }

    /* renamed from: c */
    public /* synthetic */ void mo7131c() {
        m7017a(this);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:14:0x002d, code lost:
        r2 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:16:?, code lost:
        r0.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0036, code lost:
        throw r2;
     */
    /* renamed from: d */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.String mo7132d() {
        /*
            r4 = this;
            java.io.BufferedReader r0 = new java.io.BufferedReader     // Catch:{ IOException -> 0x0037 }
            java.io.InputStreamReader r1 = new java.io.InputStreamReader     // Catch:{ IOException -> 0x0037 }
            android.content.res.AssetManager r2 = r4.getAssets()     // Catch:{ IOException -> 0x0037 }
            java.lang.String r3 = "loading.html"
            java.io.InputStream r2 = r2.open(r3)     // Catch:{ IOException -> 0x0037 }
            r1.<init>(r2)     // Catch:{ IOException -> 0x0037 }
            r0.<init>(r1)     // Catch:{ IOException -> 0x0037 }
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ all -> 0x002b }
            r1.<init>()     // Catch:{ all -> 0x002b }
        L_0x0019:
            java.lang.String r2 = r0.readLine()     // Catch:{ all -> 0x002b }
            if (r2 == 0) goto L_0x0023
            r1.append(r2)     // Catch:{ all -> 0x002b }
            goto L_0x0019
        L_0x0023:
            java.lang.String r1 = r1.toString()     // Catch:{ all -> 0x002b }
            r0.close()     // Catch:{ IOException -> 0x0037 }
            return r1
        L_0x002b:
            r1 = move-exception
            throw r1     // Catch:{ all -> 0x002d }
        L_0x002d:
            r2 = move-exception
            r0.close()     // Catch:{ all -> 0x0032 }
            goto L_0x0036
        L_0x0032:
            r0 = move-exception
            r1.addSuppressed(r0)     // Catch:{ IOException -> 0x0037 }
        L_0x0036:
            throw r2     // Catch:{ IOException -> 0x0037 }
        L_0x0037:
            java.lang.String r0 = "<h1>Loading</h1>"
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: p002io.mrarm.mctoolbox.RelaunchActivity.mo7132d():java.lang.String");
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        View view = new View(this);
        setContentView(view);
        try {
            PackageInfo packageInfo = getPackageManager().getPackageInfo("com.mojang.minecraftpe", 0);
            wf3 a = wf3.m15213a((Context) this);
            if (a.mo12273a(packageInfo.versionName, true) || a.mo12273a(packageInfo.versionName, false)) {
                if (!(!t53.m13143d() ? false : t53.m13116a(packageInfo.applicationInfo))) {
                    startActivity(new Intent(this, MinecraftActivity.class));
                    finish();
                } else if (!t53.m13143d()) {
                    startActivity(new Intent(this, MinecraftActivity.class));
                    finish();
                } else {
                    try {
                        String d = mo7132d();
                        pf3 pf3 = new pf3(this);
                        if (this.f7801X == null) {
                            this.f7801X = new ServerSocket(0);
                            new Thread(new nf3(this, d, pf3)).start();
                            String str = "http://localhost:" + this.f7801X.getLocalPort() + "/";
                            Intent intent = new Intent("android.intent.action.VIEW");
                            Bundle bundle2 = new Bundle();
                            int i = Build.VERSION.SDK_INT;
                            bundle2.putBinder("android.support.customtabs.extra.SESSION", (IBinder) null);
                            intent.putExtras(bundle2);
                            intent.putExtra("android.support.customtabs.extra.TOOLBAR_COLOR", -12303292);
                            intent.putExtra("android.support.customtabs.extra.SECONDARY_TOOLBAR_COLOR", 0);
                            Bundle a2 = C1740r5.m11946a(this, R.anim.loading_start_anim, R.anim.loading_start_anim_exit).mo10529a();
                            intent.putExtra("android.support.customtabs.extra.EXTRA_ENABLE_INSTANT_APPS", true);
                            intent.setPackage("com.android.chrome");
                            intent.addFlags(268435456);
                            try {
                                intent.setData(Uri.parse(str));
                                C2085v5.m14459a((Context) this, intent, a2);
                                view.postDelayed(new mf3(this), 100);
                                view.postDelayed(new of3(this), 3000);
                            } catch (Exception unused) {
                                m7017a(this);
                            }
                        } else {
                            throw new IllegalStateException();
                        }
                    } catch (IOException unused2) {
                        m7017a(this);
                    }
                }
            } else {
                Intent intent2 = new Intent(this, ErrorActivity.class);
                intent2.putExtra("error", "not_supported");
                startActivity(intent2);
                finish();
            }
        } catch (PackageManager.NameNotFoundException unused3) {
            Intent intent3 = new Intent(this, ErrorActivity.class);
            intent3.putExtra("error", "not_installed");
            startActivity(intent3);
            finish();
        }
    }
}
