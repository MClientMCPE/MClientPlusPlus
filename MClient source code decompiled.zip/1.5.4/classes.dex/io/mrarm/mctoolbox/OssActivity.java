package p002io.mrarm.mctoolbox;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;

/* renamed from: io.mrarm.mctoolbox.OssActivity */
public class OssActivity extends Activity {
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        WebView webView = new WebView(this);
        setContentView(webView);
        webView.loadUrl("file:///android_asset/oss.html");
    }
}
