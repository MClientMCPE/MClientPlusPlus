package p002io.mrarm.mctoolbox;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.os.Build;
import android.os.Bundle;
import android.support.p001v4.appcompat.library.BottomSheetDialog;
import android.util.Log;
import com.mojang.minecraftpe.MainActivity;
import java.io.File;
import java.lang.ref.ReferenceQueue;
import java.util.Iterator;
import java.util.List;
import p000.rg3;
import p000.wf3;
import p000.zg3;

/* renamed from: io.mrarm.mctoolbox.MinecraftActivity */
public class MinecraftActivity extends AppCompatYuraiActivity {

    /* renamed from: d0 */
    public gg3 f7789d0;

    /* renamed from: e0 */
    public PackageInfo f7790e0;

    /* renamed from: f0 */
    public zx3 f7791f0;

    /* renamed from: g0 */
    public du3 f7792g0;

    /* renamed from: h0 */
    public bg3 f7793h0;

    /* renamed from: i0 */
    public xf3 f7794i0;

    /* renamed from: j0 */
    public qk3 f7795j0;

    /* renamed from: k0 */
    public mk3 f7796k0;

    /* renamed from: l0 */
    public ok3 f7797l0;

    /* renamed from: m0 */
    public zf3 f7798m0;

    /* renamed from: n0 */
    public String f7799n0;

    /* renamed from: a */
    public static void m7007a(int i) {
        tw3.m13649a(new kf3(i));
    }

    /* renamed from: a */
    public static native void m7008a(AssetManager assetManager);

    /* renamed from: a */
    public static native void m7009a(boolean z);

    /* renamed from: b */
    public static /* synthetic */ void m7010b(int i) {
        MinecraftActivity minecraftActivity = (MinecraftActivity) MainActivity.currentMainActivity.get();
        if ((i & 256) != 0) {
            for (mv3 next : minecraftActivity.f7792g0.f4118d.f2374c) {
                if (next.isVisible().f8963Y) {
                    List<lv3> b = next.mo6724b();
                    int i2 = i & 255;
                    if (i2 < b.size()) {
                        b.get(i2).mo4945c();
                    }
                }
            }
        }
        C1505o9<iu3> o9Var = minecraftActivity.f7792g0.f4123i;
        if (i < o9Var.size()) {
            ((iu3) o9Var.get(i)).f7991a.mo4945c();
        }
    }

    /* renamed from: b */
    public static void m7011b(boolean z) {
        if (Build.VERSION.SDK_INT >= 26) {
            ((MinecraftActivity) MainActivity.currentMainActivity.get()).setCursorLocked(z);
        }
    }

    /* renamed from: b */
    public void mo7118b() {
        super.mo7118b();
        mo7123h();
        System.loadLibrary(this.f7799n0);
        m7008a(getAssets());
    }

    /* renamed from: c */
    public zx3 mo7119c() {
        return this.f7791f0;
    }

    /* renamed from: f */
    public boolean mo7120f() {
        return !zg3.f18348h.f18351c.f8963Y;
    }

    /* renamed from: g */
    public gg3 mo7121g() {
        return this.f7789d0;
    }

    public PackageManager getPackageManager() {
        zf3 zf3 = this.f7798m0;
        return zf3 != null ? zf3 : super.getPackageManager();
    }

    /* renamed from: h */
    public final void mo7123h() {
        File a = ((ay3) mo7119c()).mo2200a("libc++_shared.so");
        if (a == null && (a = ((ay3) mo7119c()).mo2200a("libgnustl_shared.so")) == null) {
            System.loadLibrary("gnustl_shared");
        } else {
            System.load(a.getAbsolutePath());
        }
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        du3 du3 = this.f7792g0;
        if (du3 != null) {
            du3.f4129o.mo7899a(true);
        }
    }

    public void onCreate(Bundle bundle) {
        String str;
        try {
            boolean z = false;
            this.f7790e0 = getPackageManager().getPackageInfo("com.mojang.minecraftpe", 0);
            this.f7791f0 = new ay3(this, "com.mojang.minecraftpe");
            wf3 a = wf3.m15213a((Context) this);
            boolean a2 = a.mo12273a(this.f7790e0.versionName, true);
            BottomSheetDialog.run(this, this);
            if (a2 || a.mo12273a(this.f7790e0.versionName, false)) {
                ApplicationInfo applicationInfo = this.f7790e0.applicationInfo;
                if (t53.m13143d()) {
                    z = t53.m13116a(applicationInfo);
                }
                if (z) {
                    startActivity(new Intent(this, RelaunchActivity.class));
                    cancelOnCreate();
                    super.onCreate(bundle);
                } else if (!t53.m13143d() || a.mo12273a(this.f7790e0.versionName, true)) {
                    String str2 = this.f7790e0.versionName;
                    boolean d = t53.m13143d();
                    Iterator<wf3.C2218b> it = a.f16693a.f16694a.iterator();
                    while (true) {
                        if (!it.hasNext()) {
                            str = null;
                            break;
                        }
                        wf3.C2218b next = it.next();
                        if (str2.equals(next.f16696a) && next.f16698c == d) {
                            str = next.f16697b;
                            break;
                        }
                    }
                    this.f7799n0 = str;
                    if (!t53.m13143d()) {
                        this.f7794i0 = new xf3(this, this.f7799n0);
                    }
                    mo7123h();
                    if (Build.VERSION.SDK_INT < 24 && this.f7794i0 != null) {
                        this.f7798m0 = new zf3(super.getPackageManager(), MinecraftActivity.class.getName(), this.f7794i0.f17160a.getAbsolutePath());
                    }
                    super.onCreate(bundle);
                    this.f7798m0 = null;
                    this.f7793h0 = new bg3(this, zg3.f18348h);
                    this.f7793h0.mo2525a();
                    bg3 bg3 = this.f7793h0;
                    rg3 rg3 = bg3.f1930b;
                    rg3.C1759a aVar = bg3.f1934f;
                    zg3 zg3 = (zg3) rg3;
                    zg3.mo13264a();
                    zg3.C2454d dVar = new zg3.C2454d(zg3, aVar, zg3.f18349a, (String) null);
                    if (dVar.f18356b == 0 || zg3.f18350b.put(dVar, dVar) == null) {
                        this.f7795j0 = new qk3();
                        this.f7789d0 = new hg3(this);
                        this.f7796k0 = new mk3(this, zg3.f18348h, this.f7795j0.f13123a);
                        this.f7797l0 = new ok3(this, this.f7795j0.f13123a, zg3.f18348h, yg3.f17796b, this.f7796k0);
                        this.f7792g0 = new du3(this, zg3.f18348h, yg3.f17796b, xg3.f17175a, this.f7789d0, new yf3(this, this.f7796k0));
                        m7009a(true);
                        ((hg3) this.f7789d0).mo6543a();
                        ((hg3) this.f7789d0).mo6542a("play_clicked");
                        return;
                    }
                    throw new IllegalStateException();
                } else {
                    Intent intent = new Intent(this, ErrorActivity.class);
                    intent.putExtra("error", "not_supported_64bit");
                    startActivity(intent);
                    cancelOnCreate();
                    super.onCreate(bundle);
                    finish();
                }
            } else {
                Intent intent2 = new Intent(this, ErrorActivity.class);
                intent2.putExtra("error", "not_supported");
                startActivity(intent2);
                cancelOnCreate();
                super.onCreate(bundle);
                finish();
            }
        } catch (PackageManager.NameNotFoundException unused) {
            Log.e("MinecraftActivity", "Game not found");
            Intent intent3 = new Intent(this, ErrorActivity.class);
            intent3.putExtra("error", "not_installed");
            startActivity(intent3);
            cancelOnCreate();
            super.onCreate(bundle);
            finish();
        }
    }

    public void onDestroy() {
        super.onDestroy();
        bg3 bg3 = this.f7793h0;
        if (bg3 != null) {
            rg3 rg3 = bg3.f1930b;
            zg3 zg3 = (zg3) rg3;
            zg3.C2453c remove = zg3.f18350b.remove(new zg3.C2452b(bg3.f1934f, (ReferenceQueue<? super rg3.C1759a>) null, (String) null));
            if (remove != null) {
                remove.mo13288b();
                remove.enqueue();
            }
            zg3.mo13264a();
        }
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        du3 du3 = this.f7792g0;
        if (du3 != null) {
            du3.f4129o.mo7899a(true);
        }
    }

    public void onPause() {
        super.onPause();
        ok3 ok3 = this.f7797l0;
        if (ok3 != null) {
            ok3.mo9730a(false);
        }
    }

    public void onResume() {
        super.onResume();
        ok3 ok3 = this.f7797l0;
        if (ok3 != null) {
            ok3.mo9730a(true);
        }
    }
}
