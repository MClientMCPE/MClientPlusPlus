package p002io.mrarm.mctoolbox;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

/* renamed from: io.mrarm.mctoolbox.ErrorActivity */
public class ErrorActivity extends AppCompatActivity {

    /* renamed from: o0 */
    public ch3 f7788o0;

    /* JADX WARNING: Code restructure failed: missing block: B:8:?, code lost:
        return;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0020 */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo7114a(java.lang.String r5) {
        /*
            r4 = this;
            java.lang.String r0 = "android.intent.action.VIEW"
            android.content.Intent r1 = new android.content.Intent     // Catch:{ all -> 0x0020 }
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ all -> 0x0020 }
            r2.<init>()     // Catch:{ all -> 0x0020 }
            java.lang.String r3 = "market://details?id="
            r2.append(r3)     // Catch:{ all -> 0x0020 }
            r2.append(r5)     // Catch:{ all -> 0x0020 }
            java.lang.String r2 = r2.toString()     // Catch:{ all -> 0x0020 }
            android.net.Uri r2 = android.net.Uri.parse(r2)     // Catch:{ all -> 0x0020 }
            r1.<init>(r0, r2)     // Catch:{ all -> 0x0020 }
            r4.startActivity(r1)     // Catch:{ all -> 0x0020 }
            goto L_0x003d
        L_0x0020:
            android.content.Intent r1 = new android.content.Intent     // Catch:{ all -> 0x003d }
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ all -> 0x003d }
            r2.<init>()     // Catch:{ all -> 0x003d }
            java.lang.String r3 = "https://play.google.com/store/apps/details?id="
            r2.append(r3)     // Catch:{ all -> 0x003d }
            r2.append(r5)     // Catch:{ all -> 0x003d }
            java.lang.String r5 = r2.toString()     // Catch:{ all -> 0x003d }
            android.net.Uri r5 = android.net.Uri.parse(r5)     // Catch:{ all -> 0x003d }
            r1.<init>(r0, r5)     // Catch:{ all -> 0x003d }
            r4.startActivity(r1)     // Catch:{ all -> 0x003d }
        L_0x003d:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p002io.mrarm.mctoolbox.ErrorActivity.mo7114a(java.lang.String):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:31:0x0081  */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x009f  */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo7115b(java.lang.String r8) {
        /*
            r7 = this;
            if (r8 != 0) goto L_0x0006
            r7.finish()
            return
        L_0x0006:
            java.lang.String r0 = "not_installed"
            boolean r1 = r8.equals(r0)
            r2 = 1
            if (r1 == 0) goto L_0x002a
            ch3 r8 = r7.f7788o0
            r0 = 2131755085(0x7f10004d, float:1.914104E38)
            r8.mo2945e(r0)
            ch3 r8 = r7.f7788o0
            r0 = 2131755084(0x7f10004c, float:1.9141037E38)
            java.lang.String r0 = r7.getString(r0)
        L_0x0020:
            r8.mo2940a((java.lang.CharSequence) r0)
            ch3 r8 = r7.f7788o0
            r8.mo2942a((boolean) r2)
            goto L_0x00f3
        L_0x002a:
            java.lang.String r1 = "not_supported"
            boolean r1 = r8.equals(r1)
            r3 = 0
            if (r1 == 0) goto L_0x00c9
            android.content.pm.PackageManager r8 = r7.getPackageManager()     // Catch:{ NameNotFoundException -> 0x00c5, IllegalArgumentException -> 0x007e }
            java.lang.String r1 = "com.mojang.minecraftpe"
            android.content.pm.PackageInfo r8 = r8.getPackageInfo(r1, r3)     // Catch:{ NameNotFoundException -> 0x00c5, IllegalArgumentException -> 0x007e }
            wf3 r1 = p000.wf3.m15213a((android.content.Context) r7)     // Catch:{ NameNotFoundException -> 0x00c5, IllegalArgumentException -> 0x007e }
            java.lang.String r4 = r8.versionName     // Catch:{ NameNotFoundException -> 0x00c5, IllegalArgumentException -> 0x007e }
            boolean r4 = r1.mo12273a(r4, r2)     // Catch:{ NameNotFoundException -> 0x00c5, IllegalArgumentException -> 0x007e }
            if (r4 != 0) goto L_0x0051
            java.lang.String r4 = r8.versionName     // Catch:{ NameNotFoundException -> 0x00c5, IllegalArgumentException -> 0x007e }
            boolean r4 = r1.mo12273a(r4, r3)     // Catch:{ NameNotFoundException -> 0x00c5, IllegalArgumentException -> 0x007e }
            if (r4 == 0) goto L_0x0054
        L_0x0051:
            r7.finish()     // Catch:{ NameNotFoundException -> 0x00c5, IllegalArgumentException -> 0x007e }
        L_0x0054:
            wf3$a r1 = r1.f16693a     // Catch:{ NameNotFoundException -> 0x00c5, IllegalArgumentException -> 0x007e }
            java.lang.String r1 = r1.f16695b     // Catch:{ NameNotFoundException -> 0x00c5, IllegalArgumentException -> 0x007e }
            java.lang.String r8 = r8.versionName     // Catch:{ NameNotFoundException -> 0x00c5, IllegalArgumentException -> 0x007e }
            int[] r1 = p000.wf3.m15214a((java.lang.String) r1)     // Catch:{ NameNotFoundException -> 0x00c5, IllegalArgumentException -> 0x007e }
            int[] r8 = p000.wf3.m15214a((java.lang.String) r8)     // Catch:{ NameNotFoundException -> 0x00c5, IllegalArgumentException -> 0x007e }
            r4 = 0
        L_0x0063:
            r5 = 4
            if (r4 >= r5) goto L_0x0079
            r5 = r1[r4]     // Catch:{ NameNotFoundException -> 0x00c5, IllegalArgumentException -> 0x007e }
            r6 = r8[r4]     // Catch:{ NameNotFoundException -> 0x00c5, IllegalArgumentException -> 0x007e }
            if (r5 <= r6) goto L_0x006e
            r8 = -1
            goto L_0x007a
        L_0x006e:
            r5 = r1[r4]     // Catch:{ NameNotFoundException -> 0x00c5, IllegalArgumentException -> 0x007e }
            r6 = r8[r4]     // Catch:{ NameNotFoundException -> 0x00c5, IllegalArgumentException -> 0x007e }
            if (r5 >= r6) goto L_0x0076
            r8 = 1
            goto L_0x007a
        L_0x0076:
            int r4 = r4 + 1
            goto L_0x0063
        L_0x0079:
            r8 = 0
        L_0x007a:
            if (r8 >= 0) goto L_0x007e
            r8 = 1
            goto L_0x007f
        L_0x007e:
            r8 = 0
        L_0x007f:
            if (r8 == 0) goto L_0x009f
            ch3 r8 = r7.f7788o0
            r0 = 2131755091(0x7f100053, float:1.9141051E38)
            r8.mo2945e(r0)
            ch3 r8 = r7.f7788o0
            r0 = 2131755090(0x7f100052, float:1.914105E38)
            java.lang.Object[] r1 = new java.lang.Object[r2]
            wf3 r4 = p000.wf3.m15213a((android.content.Context) r7)
            java.lang.String r4 = r4.mo12272a()
            r1[r3] = r4
            java.lang.String r0 = r7.getString(r0, r1)
            goto L_0x0020
        L_0x009f:
            ch3 r8 = r7.f7788o0
            r0 = 2131755089(0x7f100051, float:1.9141047E38)
            r8.mo2945e(r0)
            ch3 r8 = r7.f7788o0
            r0 = 2131755088(0x7f100050, float:1.9141045E38)
            java.lang.Object[] r1 = new java.lang.Object[r2]
            wf3 r4 = p000.wf3.m15213a((android.content.Context) r7)
            java.lang.String r4 = r4.mo12272a()
            r1[r3] = r4
            java.lang.String r0 = r7.getString(r0, r1)
            r8.mo2940a((java.lang.CharSequence) r0)
            ch3 r8 = r7.f7788o0
            r8.mo2942a((boolean) r2)
            goto L_0x00ea
        L_0x00c5:
            r7.mo7115b(r0)
            return
        L_0x00c9:
            java.lang.String r0 = "not_supported_64bit"
            boolean r8 = r8.equals(r0)
            if (r8 == 0) goto L_0x00f0
            ch3 r8 = r7.f7788o0
            r0 = 2131755087(0x7f10004f, float:1.9141043E38)
            r8.mo2945e(r0)
            ch3 r8 = r7.f7788o0
            r0 = 2131755086(0x7f10004e, float:1.9141041E38)
            java.lang.String r0 = r7.getString(r0)
            r8.mo2940a((java.lang.CharSequence) r0)
            ch3 r8 = r7.f7788o0
            r8.mo2942a((boolean) r3)
        L_0x00ea:
            ch3 r8 = r7.f7788o0
            r8.mo2944b((boolean) r2)
            goto L_0x00f3
        L_0x00f0:
            r7.finish()
        L_0x00f3:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p002io.mrarm.mctoolbox.ErrorActivity.mo7115b(java.lang.String):void");
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f7788o0 = (ch3) C0672f9.m4595a(this, R.layout.activity_error);
        mo677m().mo7746b(16);
        mo677m().mo7738a((int) R.layout.activity_error_title);
        this.f7788o0.mo2941a((Runnable) new jf3(this));
        this.f7788o0.mo2943b((Runnable) new if3(this));
        mo7115b(getIntent().getStringExtra("error"));
    }

    /* renamed from: r */
    public /* synthetic */ void mo7116r() {
        mo7114a("com.mojang.minecraftpe");
    }

    /* renamed from: s */
    public /* synthetic */ void mo7117s() {
        mo7114a(getPackageName());
    }
}
