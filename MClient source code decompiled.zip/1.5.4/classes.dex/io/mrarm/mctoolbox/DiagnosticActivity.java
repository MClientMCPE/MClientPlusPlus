package p002io.mrarm.mctoolbox;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;

/* renamed from: io.mrarm.mctoolbox.DiagnosticActivity */
public class DiagnosticActivity extends AppCompatActivity {

    /* renamed from: o0 */
    public ah3 f7787o0;

    /* renamed from: a */
    public static void m6996a(Context context) {
        File file = new File(Environment.getExternalStorageDirectory(), "ToolboxLogSnapshot.txt");
        try {
            file.delete();
            Runtime runtime = Runtime.getRuntime();
            runtime.exec("logcat -L -d -b all -f " + file.getAbsolutePath()).waitFor();
            if (file.exists()) {
                Toast.makeText(context, "Saved logcat to: " + file, 0).show();
                return;
            }
            throw new RuntimeException("File not saved");
        } catch (Exception e) {
            StringBuilder a = C0789gk.m5562a("Failed to save logcat: ");
            a.append(e.getMessage());
            Toast.makeText(context, a.toString(), 0).show();
            e.printStackTrace();
        }
    }

    /* renamed from: a */
    public /* synthetic */ void mo7109a(View view) {
        new File(mo7112r()).delete();
        this.f7787o0.f486v0.setText(mo7113s());
    }

    /* renamed from: b */
    public /* synthetic */ void mo7110b(View view) {
        startActivity(new Intent(this, MinecraftActivity.class));
    }

    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0033, code lost:
        r1 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:17:?, code lost:
        r0.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x003c, code lost:
        throw r1;
     */
    /* renamed from: c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo7111c(android.content.Intent r5) {
        /*
            r4 = this;
            if (r5 == 0) goto L_0x0041
            android.net.Uri r0 = r5.getData()
            if (r0 == 0) goto L_0x0041
            android.net.Uri r5 = r5.getData()
            java.lang.String r0 = "setHM"
            java.lang.String r5 = r5.getQueryParameter(r0)
            if (r5 == 0) goto L_0x0041
            r4.getFilesDir()
            java.io.BufferedWriter r0 = new java.io.BufferedWriter     // Catch:{ IOException -> 0x003d }
            java.io.FileWriter r1 = new java.io.FileWriter     // Catch:{ IOException -> 0x003d }
            java.io.File r2 = new java.io.File     // Catch:{ IOException -> 0x003d }
            java.lang.String r3 = r4.mo7112r()     // Catch:{ IOException -> 0x003d }
            r2.<init>(r3)     // Catch:{ IOException -> 0x003d }
            r1.<init>(r2)     // Catch:{ IOException -> 0x003d }
            r0.<init>(r1)     // Catch:{ IOException -> 0x003d }
            r0.write(r5)     // Catch:{ all -> 0x0031 }
            r0.close()     // Catch:{ IOException -> 0x003d }
            goto L_0x0041
        L_0x0031:
            r5 = move-exception
            throw r5     // Catch:{ all -> 0x0033 }
        L_0x0033:
            r1 = move-exception
            r0.close()     // Catch:{ all -> 0x0038 }
            goto L_0x003c
        L_0x0038:
            r0 = move-exception
            r5.addSuppressed(r0)     // Catch:{ IOException -> 0x003d }
        L_0x003c:
            throw r1     // Catch:{ IOException -> 0x003d }
        L_0x003d:
            r5 = move-exception
            r5.printStackTrace()
        L_0x0041:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p002io.mrarm.mctoolbox.DiagnosticActivity.mo7111c(android.content.Intent):void");
    }

    public void onCreate(Bundle bundle) {
        String str;
        String str2;
        super.onCreate(bundle);
        mo7111c(getIntent());
        this.f7787o0 = (ah3) C0672f9.m4595a(this, R.layout.activity_diagnostic);
        TextView textView = this.f7787o0.f482r0;
        StringBuilder sb = new StringBuilder();
        if (Build.VERSION.SDK_INT >= 21) {
            for (String append : Build.SUPPORTED_ABIS) {
                sb.append(append);
                sb.append(" ");
            }
        } else {
            sb.append(Build.CPU_ABI);
            sb.append(" ");
            sb.append(Build.CPU_ABI2);
        }
        StringBuilder a = C0789gk.m5562a("Device Model: ");
        a.append(Build.MANUFACTURER);
        a.append(" (");
        a.append(Build.BRAND);
        a.append(") ");
        a.append(Build.MODEL);
        a.append("\nAndroid Version: ");
        a.append(Build.VERSION.RELEASE);
        a.append(" (SDK_INT=");
        a.append(Build.VERSION.SDK_INT);
        a.append(")\nABI: ");
        a.append(sb);
        textView.setText(a.toString());
        TextView textView2 = this.f7787o0.f484t0;
        String str3 = "";
        try {
            PackageInfo packageInfo = getPackageManager().getPackageInfo(getPackageName(), 0);
            try {
                PackageInfo packageInfo2 = getPackageManager().getPackageInfo("com.mojang.minecraftpe", 0);
                try {
                    str2 = getPackageManager().getInstallerPackageName(getPackageName());
                    try {
                        str3 = getPackageManager().getInstallerPackageName("com.mojang.minecraftpe");
                    } catch (IllegalArgumentException unused) {
                    }
                } catch (IllegalArgumentException unused2) {
                    str2 = str3;
                }
                wf3 a2 = wf3.m15213a((Context) this);
                StringBuilder a3 = C0789gk.m5562a("Minecraft: ");
                a3.append(packageInfo2.versionName);
                a3.append(" ");
                a3.append(packageInfo2.versionCode);
                a3.append(" ");
                a3.append(str3);
                a3.append("\nToolbox: ");
                a3.append(packageInfo.packageName);
                a3.append(" ");
                a3.append(packageInfo.versionName);
                a3.append(" ");
                a3.append(packageInfo.versionCode);
                a3.append(" ");
                a3.append(str2);
                a3.append("\nSupported versions: ");
                a3.append(wf3.m15213a((Context) this).mo12272a());
                a3.append("\n64-bit: Process ");
                String str4 = "YES";
                a3.append(t53.m13143d() ? str4 : "NO");
                a3.append(", Minecraft ");
                a3.append(!t53.m13116a(packageInfo2.applicationInfo) ? str4 : "NO");
                a3.append("\nVersion Supported: 64-bit ");
                a3.append(a2.mo12273a(packageInfo2.versionName, true) ? str4 : "NO");
                a3.append(", 32-bit ");
                if (!a2.mo12273a(packageInfo2.versionName, false)) {
                    str4 = "NO";
                }
                a3.append(str4);
                str = a3.toString();
            } catch (PackageManager.NameNotFoundException unused3) {
                str = "Minecraft NOT INSTALLED";
            }
        } catch (PackageManager.NameNotFoundException unused4) {
            str = "Toolbox missing?";
        }
        textView2.setText(str);
        this.f7787o0.f486v0.setText(mo7113s());
        this.f7787o0.f487w0.setOnClickListener(new ff3(this));
        this.f7787o0.f483s0.setOnClickListener(gf3.f6109X);
        this.f7787o0.f485u0.setOnClickListener(new hf3(this));
    }

    public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        mo7111c(intent);
        ah3 ah3 = this.f7787o0;
        if (ah3 != null) {
            ah3.f486v0.setText(mo7113s());
        }
    }

    @SuppressLint({"SdCardPath"})
    /* renamed from: r */
    public final String mo7112r() {
        StringBuilder a = C0789gk.m5562a("/data/data/");
        a.append(getPackageName());
        a.append("/files/StartupHM.txt");
        return a.toString();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0063, code lost:
        r4 = move-exception;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:?, code lost:
        r2.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x006c, code lost:
        throw r4;
     */
    /* renamed from: s */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.String mo7113s() {
        /*
            r6 = this;
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.io.File r1 = new java.io.File
            java.io.File r2 = android.os.Environment.getExternalStorageDirectory()
            java.lang.String r3 = "tbgui"
            r1.<init>(r2, r3)
            boolean r1 = r1.exists()
            if (r1 == 0) goto L_0x001b
            java.lang.String r1 = "IMGUI menu files exist\n"
            r0.append(r1)
        L_0x001b:
            java.io.File r1 = new java.io.File
            java.io.File r2 = android.os.Environment.getExternalStorageDirectory()
            java.lang.String r3 = "ToolboxMenuOverride"
            r1.<init>(r2, r3)
            boolean r1 = r1.exists()
            if (r1 == 0) goto L_0x0031
            java.lang.String r1 = "Menu override exists\n"
            r0.append(r1)
        L_0x0031:
            java.io.File r1 = new java.io.File
            java.lang.String r2 = r6.mo7112r()
            r1.<init>(r2)
            boolean r1 = r1.exists()
            if (r1 == 0) goto L_0x007e
            java.lang.String r1 = "StartupHM file exists: "
            java.lang.StringBuilder r1 = p000.C0789gk.m5562a((java.lang.String) r1)
            java.io.BufferedReader r2 = new java.io.BufferedReader     // Catch:{ IOException -> 0x006d }
            java.io.FileReader r3 = new java.io.FileReader     // Catch:{ IOException -> 0x006d }
            java.io.File r4 = new java.io.File     // Catch:{ IOException -> 0x006d }
            java.lang.String r5 = r6.mo7112r()     // Catch:{ IOException -> 0x006d }
            r4.<init>(r5)     // Catch:{ IOException -> 0x006d }
            r3.<init>(r4)     // Catch:{ IOException -> 0x006d }
            r2.<init>(r3)     // Catch:{ IOException -> 0x006d }
            java.lang.String r3 = r2.readLine()     // Catch:{ all -> 0x0061 }
            r2.close()     // Catch:{ IOException -> 0x006d }
            goto L_0x006f
        L_0x0061:
            r3 = move-exception
            throw r3     // Catch:{ all -> 0x0063 }
        L_0x0063:
            r4 = move-exception
            r2.close()     // Catch:{ all -> 0x0068 }
            goto L_0x006c
        L_0x0068:
            r2 = move-exception
            r3.addSuppressed(r2)     // Catch:{ IOException -> 0x006d }
        L_0x006c:
            throw r4     // Catch:{ IOException -> 0x006d }
        L_0x006d:
            java.lang.String r3 = "Failed to read file"
        L_0x006f:
            r1.append(r3)
            java.lang.String r2 = "\n"
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.append(r1)
        L_0x007e:
            int r1 = r0.length()
            if (r1 <= 0) goto L_0x008d
            java.lang.String r0 = r0.toString()
            java.lang.String r0 = r0.trim()
            goto L_0x008f
        L_0x008d:
            java.lang.String r0 = "No launch options"
        L_0x008f:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: p002io.mrarm.mctoolbox.DiagnosticActivity.mo7113s():java.lang.String");
    }
}
