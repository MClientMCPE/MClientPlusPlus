package p002io.mrarm.mctoolbox;

import android.app.Instrumentation;
import android.content.Intent;
import android.os.Bundle;

/* renamed from: io.mrarm.mctoolbox.RelaunchInstrumentation */
public class RelaunchInstrumentation extends Instrumentation {
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        Intent intent = new Intent(getContext(), MinecraftActivity.class);
        intent.addFlags(268435456);
        getContext().startActivity(intent, C1740r5.m11946a(getContext(), R.anim.loading_start_anim_exit, R.anim.loading_start_anim_exit).mo10529a());
    }
}
