package p002io.mrarm.mctoolbox;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import p000.C1889t0;
import p002io.mrarm.yurai.YuraiActivity;

/* renamed from: io.mrarm.mctoolbox.AppCompatYuraiActivity */
public abstract class AppCompatYuraiActivity extends YuraiActivity implements C2314y {

    /* renamed from: b0 */
    public C2386z f7785b0;

    /* renamed from: c0 */
    public Resources f7786c0;

    /* renamed from: a */
    public C1889t0 mo659a(C1889t0.C1890a aVar) {
        return null;
    }

    /* renamed from: a */
    public void mo661a(C1889t0 t0Var) {
    }

    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        mo7095e().mo17a(view, layoutParams);
    }

    public void attachBaseContext(Context context) {
        super.attachBaseContext(context);
        C0011a0 a0Var = (C0011a0) mo7095e();
        a0Var.mo25a(false);
        a0Var.f15F0 = true;
    }

    /* renamed from: b */
    public void mo665b(C1889t0 t0Var) {
    }

    /* renamed from: e */
    public C2386z mo7095e() {
        if (this.f7785b0 == null) {
            this.f7785b0 = C2386z.m16740a((Activity) this, (C2314y) this);
        }
        return this.f7785b0;
    }

    public MenuInflater getMenuInflater() {
        return mo7095e().mo9a();
    }

    public Resources getResources() {
        if (this.f7786c0 == null) {
            C0512d4.m3429a();
        }
        Resources resources = this.f7786c0;
        return resources == null ? super.getResources() : resources;
    }

    public void invalidateOptionsMenu() {
        mo7095e().mo32c();
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        if (this.f7786c0 != null) {
            this.f7786c0.updateConfiguration(configuration, super.getResources().getDisplayMetrics());
        }
        mo7095e().mo14a(configuration);
    }

    public void onCreate(Bundle bundle) {
        C2386z e = mo7095e();
        e.mo26b();
        e.mo15a(bundle);
        super.onCreate(bundle);
    }

    public void onDestroy() {
        super.onDestroy();
        mo7095e().mo35d();
    }

    public void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
        ((C0011a0) mo7095e()).mo43h();
    }

    public void onPostResume() {
        super.onPostResume();
        C0011a0 a0Var = (C0011a0) mo7095e();
        a0Var.mo48m();
        C1377n nVar = a0Var.f37e0;
        if (nVar != null) {
            nVar.mo7749c(true);
        }
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        mo7095e().mo28b(bundle);
    }

    public void onStart() {
        super.onStart();
        C0011a0 a0Var = (C0011a0) mo7095e();
        a0Var.f17H0 = true;
        a0Var.mo39f();
        C2386z.m16742a((C2386z) a0Var);
    }

    public void onStop() {
        super.onStop();
        mo7095e().mo36e();
    }

    public void onTitleChanged(CharSequence charSequence, int i) {
        super.onTitleChanged(charSequence, i);
        mo7095e().mo20a(charSequence);
    }

    public void setContentView(int i) {
        mo7095e().mo27b(i);
    }

    public void setContentView(View view) {
        mo7095e().mo16a(view);
    }

    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        mo7095e().mo29b(view, layoutParams);
    }

    public void setTheme(int i) {
        super.setTheme(i);
        ((C0011a0) mo7095e()).f20K0 = i;
    }
}
