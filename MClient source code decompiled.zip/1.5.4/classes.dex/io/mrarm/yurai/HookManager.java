package p002io.mrarm.yurai;

/* renamed from: io.mrarm.yurai.HookManager */
public class HookManager {

    /* renamed from: a */
    public long f7902a = nativeCreate();

    public static native void nativeAddLibrary(long j, String str);

    public static native void nativeApplyHooks(long j);

    public static native long nativeCreate();

    public static native void nativeDestroy(long j);

    public static native void nativeMakeActive(long j);

    /* renamed from: a */
    public void mo7198a() {
        nativeApplyHooks(this.f7902a);
    }

    /* renamed from: a */
    public void mo7199a(String str) {
        nativeAddLibrary(this.f7902a, str);
    }

    /* renamed from: b */
    public long mo7200b() {
        return this.f7902a;
    }

    /* renamed from: c */
    public void mo7201c() {
        nativeMakeActive(this.f7902a);
    }

    public void finalize() {
        nativeDestroy(this.f7902a);
        super.finalize();
    }
}
