package p002io.mrarm.yurai.xbox;

/* renamed from: io.mrarm.yurai.xbox.CLLInstance */
public class CLLInstance {

    /* renamed from: a */
    public long f7919a;

    public CLLInstance(String str, String str2, String str3, String str4, String str5) {
        this.f7919a = nativeCreate(str, str2, str3, str4, str5);
    }

    public static native long nativeCreate(String str, String str2, String str3, String str4, String str5);

    public static native void nativeDestroy(long j);

    public static native void nativeLog(long j, String str, String str2, String str3);

    public static native void nativeSetAccount(long j, String str);

    /* renamed from: a */
    public void mo7234a(String str) {
        nativeSetAccount(this.f7919a, str);
    }

    /* renamed from: a */
    public void mo7235a(String str, String str2, String str3) {
        nativeLog(this.f7919a, str, str2, str3);
    }

    public void finalize() {
        nativeDestroy(this.f7919a);
        super.finalize();
    }
}
