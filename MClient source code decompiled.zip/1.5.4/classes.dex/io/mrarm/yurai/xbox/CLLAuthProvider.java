package p002io.mrarm.yurai.xbox;

import android.content.Context;
import android.util.Log;
import com.microsoft.xbox.idp.interop.Interop;
import p002io.mrarm.yurai.msa.Account;
import p002io.mrarm.yurai.msa.AccountManager;
import p002io.mrarm.yurai.msa.CompactToken;
import p002io.mrarm.yurai.msa.MSASingleton;
import p002io.mrarm.yurai.msa.SecurityScope;
import p002io.mrarm.yurai.msa.TokenResponse;

/* renamed from: io.mrarm.yurai.xbox.CLLAuthProvider */
public class CLLAuthProvider {

    /* renamed from: a */
    public static final SecurityScope f7918a = new SecurityScope("vortex.data.microsoft.com", "mbi_ssl");

    public static String refreshCllMsaToken(String str) {
        MSASingleton instance = MSASingleton.getInstance((Context) null);
        if (instance == null) {
            return null;
        }
        try {
            Account findAccount = instance.getAccountManager().findAccount(str);
            try {
                TokenResponse[] requestTokens = findAccount.requestTokens(instance.getLoginManager(), new SecurityScope[]{f7918a}, "android-app://com.mojang.minecraftpe.H62DKCBHJP6WXXIV7RBFOGOL4NAK4E6Y");
                if (requestTokens.length == 1 && requestTokens[0].getToken() != null && (requestTokens[0].getToken() instanceof CompactToken)) {
                    return ((CompactToken) requestTokens[0].getToken()).getBinaryToken();
                }
                Log.e("CLLAuthProvider", "Failed to get token: no token found");
                return null;
            } catch (Exception e) {
                Log.e("CLLAuthProvider", "Failed to get token");
                e.printStackTrace();
                return null;
            }
        } catch (AccountManager.NoSuchAccountException unused) {
            Log.e("CLLAuthProvider", "Account not found: " + str);
            return null;
        }
    }

    public static String refreshCllXTicket(String str) {
        return Interop.GetXTokenCallback(str);
    }

    public static String refreshCllXToken(boolean z) {
        return Interop.GetLiveXTokenCallback(z);
    }
}
