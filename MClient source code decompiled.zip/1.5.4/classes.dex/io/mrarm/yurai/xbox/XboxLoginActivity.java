package p002io.mrarm.yurai.xbox;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;
import com.microsoft.xbox.idp.interop.Interop;

/* renamed from: io.mrarm.yurai.xbox.XboxLoginActivity */
public class XboxLoginActivity extends AppCompatActivity {

    /* renamed from: s0 */
    public static long f7920s0;

    /* renamed from: o0 */
    public long f7921o0;

    /* renamed from: p0 */
    public xy3 f7922p0;

    /* renamed from: q0 */
    public boolean f7923q0;

    /* renamed from: r0 */
    public boolean f7924r0;

    /* renamed from: a */
    public static void m7112a(boolean z, String str) {
        Bundle bundle = new Bundle();
        bundle.putLong("success", z ? 1 : 0);
        bundle.putString("result", str);
        gy3.f6451b.mo6264a("xbl_login", bundle);
    }

    /* renamed from: a */
    public /* synthetic */ void mo7237a(String str) {
        m7112a(false, str);
        Interop.auth_flow_callback(this.f7921o0, 2, "");
        finish();
    }

    /* renamed from: a */
    public /* synthetic */ void mo7238a(xy3 xy3) {
        this.f7922p0 = xy3;
        this.f7922p0.mo12690f();
    }

    /* renamed from: b */
    public /* synthetic */ void mo7239b(String str) {
        m7112a(true, "Success");
        Interop.auth_flow_callback(this.f7921o0, 0, str);
        finish();
    }

    /* renamed from: b */
    public void mo7240b(xy3 xy3) {
        synchronized (this) {
            this.f7924r0 = true;
            if (!this.f7923q0) {
                xy3.f17431a = this;
                runOnUiThread(new py3(this, xy3));
            }
        }
    }

    /* renamed from: c */
    public void mo7241c(String str) {
        runOnUiThread(new qy3(this, str));
    }

    /* renamed from: d */
    public void mo7242d(String str) {
        runOnUiThread(new sy3(this, str));
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        this.f7922p0.mo2215a(i, i2, intent);
        super.onActivityResult(i, i2, intent);
    }

    public void onBackPressed() {
        if (this.f7922p0.mo2216b()) {
            synchronized (this) {
                if (!this.f7924r0) {
                    this.f7923q0 = true;
                    mo7245t();
                }
            }
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(dy3.xbox_sign_in_progress);
        this.f7921o0 = getIntent().getLongExtra("native_ptr", 0);
        if (this.f7921o0 != f7920s0) {
            this.f7921o0 = 0;
        }
        if (this.f7921o0 == 0) {
            Log.i(" XboxLoginActivity", "Native pointer is invalid");
            finish();
            return;
        }
        this.f7922p0 = new zy3();
        xy3 xy3 = this.f7922p0;
        xy3.f17431a = this;
        xy3.mo12690f();
    }

    /* renamed from: r */
    public long mo7243r() {
        return this.f7921o0;
    }

    /* renamed from: s */
    public /* synthetic */ void mo7244s() {
        Interop.auth_flow_callback(this.f7921o0, 1, "");
        finish();
    }

    /* renamed from: t */
    public void mo7245t() {
        runOnUiThread(new ry3(this));
    }
}
