package p002io.mrarm.yurai;

/* renamed from: io.mrarm.yurai.Sopatch */
public class Sopatch {
    public static native int patchLoadLibrary(String str, String str2, String str3);
}
