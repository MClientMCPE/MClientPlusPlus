package p002io.mrarm.yurai.msa;

/* renamed from: io.mrarm.yurai.msa.LoginManager */
public class LoginManager {
    public long handle;

    public LoginManager(StorageManager storageManager) {
        this.handle = nativeCreate(storageManager != null ? storageManager.handle : 0);
    }

    public static native long nativeCreate(long j);

    public static native void nativeDestroy(long j);

    public void finalize() {
        nativeDestroy(this.handle);
        super.finalize();
    }
}
