package p002io.mrarm.yurai.msa;

/* renamed from: io.mrarm.yurai.msa.CompactToken */
public final class CompactToken extends Token {
    public CompactToken(long j) {
        super(j);
    }

    public static native String nativeGetBinaryToken(long j);

    public String getBinaryToken() {
        return nativeGetBinaryToken(this.sharedHandle);
    }
}
