package p002io.mrarm.yurai.msa;

/* renamed from: io.mrarm.yurai.msa.SimpleStorageManager */
public class SimpleStorageManager extends StorageManager {
    public SimpleStorageManager(String str) {
        super(nativeCreate(str));
    }

    public static native long nativeCreate(String str);
}
