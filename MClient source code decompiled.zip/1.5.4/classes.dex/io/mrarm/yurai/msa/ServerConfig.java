package p002io.mrarm.yurai.msa;

/* renamed from: io.mrarm.yurai.msa.ServerConfig */
public class ServerConfig {
    public static native String getInlineConnectPartnerUrl();
}
