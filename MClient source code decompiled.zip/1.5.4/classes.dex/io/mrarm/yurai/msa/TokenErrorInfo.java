package p002io.mrarm.yurai.msa;

/* renamed from: io.mrarm.yurai.msa.TokenErrorInfo */
public final class TokenErrorInfo {
    public long sharedHandle;

    public TokenErrorInfo(long j) {
        this.sharedHandle = j;
    }

    public static native void nativeDestroy(long j);

    public static native String nativeGetInlineAuthUrl(long j);

    public void finalize() {
        nativeDestroy(this.sharedHandle);
        super.finalize();
    }

    public String getInlineAuthUrl() {
        return nativeGetInlineAuthUrl(this.sharedHandle);
    }
}
