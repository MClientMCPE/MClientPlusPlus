package p002io.mrarm.yurai.msa;

/* renamed from: io.mrarm.yurai.msa.Token */
public abstract class Token {
    public long sharedHandle;

    /* renamed from: io.mrarm.yurai.msa.Token$TimePoint */
    public static final class TimePoint {
        public long value;

        public TimePoint(long j) {
            this.value = j;
        }

        public static TimePoint fromString(String str) {
            return new TimePoint(Token.nativeParseTimePoint(str));
        }
    }

    public Token(long j) {
        this.sharedHandle = j;
    }

    public static native void nativeDestroy(long j);

    public static native long nativeParseTimePoint(String str);

    public void finalize() {
        nativeDestroy(this.sharedHandle);
        super.finalize();
    }
}
