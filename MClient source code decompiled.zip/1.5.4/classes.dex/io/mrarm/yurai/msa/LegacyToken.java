package p002io.mrarm.yurai.msa;

import p002io.mrarm.yurai.msa.Token;

/* renamed from: io.mrarm.yurai.msa.LegacyToken */
public final class LegacyToken extends Token {
    public LegacyToken(long j) {
        super(j);
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public LegacyToken(SecurityScope securityScope, Token.TimePoint timePoint, Token.TimePoint timePoint2, String str, String str2) {
        super(nativeCreate(securityScope != null ? securityScope.getAddress() : null, securityScope != null ? securityScope.getPolicyRef() : null, timePoint.value, timePoint2.value, str, str2));
    }

    public static native long nativeCreate(String str, String str2, long j, long j2, String str3, String str4);
}
