package p002io.mrarm.yurai.msa;

/* renamed from: io.mrarm.yurai.msa.TokenResponse */
public class TokenResponse {
    public SecurityScope securityScope;
    public Token token;
    public TokenErrorInfo tokenErrorInfo;

    public TokenResponse(String str, String str2, Token token2, long j) {
        this.securityScope = new SecurityScope(str, str2);
        this.token = token2;
        if (j != 0) {
            this.tokenErrorInfo = new TokenErrorInfo(j);
        }
    }

    public SecurityScope getSecurityScope() {
        return this.securityScope;
    }

    public Token getToken() {
        return this.token;
    }

    public TokenErrorInfo getTokenErrorInfo() {
        return this.tokenErrorInfo;
    }
}
