package p002io.mrarm.yurai.msa;

/* renamed from: io.mrarm.yurai.msa.SecurityScope */
public class SecurityScope {
    public String address;
    public String policyRef;

    public SecurityScope(String str) {
        this.address = str;
    }

    public SecurityScope(String str, String str2) {
        this.address = str;
        this.policyRef = str2;
    }

    public String getAddress() {
        return this.address;
    }

    public String getPolicyRef() {
        return this.policyRef;
    }
}
