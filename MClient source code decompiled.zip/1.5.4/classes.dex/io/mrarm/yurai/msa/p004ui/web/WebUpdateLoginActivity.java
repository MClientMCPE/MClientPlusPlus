package p002io.mrarm.yurai.msa.p004ui.web;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import androidx.appcompat.app.AppCompatActivity;
import p000.my3;
import p002io.mrarm.yurai.msa.Account;
import p002io.mrarm.yurai.msa.AccountManager;
import p002io.mrarm.yurai.msa.LegacyToken;
import p002io.mrarm.yurai.msa.MSASingleton;

/* renamed from: io.mrarm.yurai.msa.ui.web.WebUpdateLoginActivity */
public class WebUpdateLoginActivity extends AppCompatActivity implements my3.C1375a {

    /* renamed from: o0 */
    public String f7909o0;

    /* renamed from: p0 */
    public WebView f7910p0;

    /* renamed from: q0 */
    public my3 f7911q0;

    /* renamed from: a */
    public final void mo7232a(String str) {
        Intent intent = new Intent();
        intent.putExtra("error", str);
        setResult(1, intent);
        finish();
    }

    /* renamed from: a */
    public void mo7230a(ny3 ny3) {
        String str = ny3.f11603a.get("CID");
        if (str == null || str.equals(this.f7909o0)) {
            try {
                Account findAccount = MSASingleton.getInstance(this).getAccountManager().findAccount(this.f7909o0);
                String str2 = ny3.f11603a.get("PUID");
                if (str2 == null || !str2.equals(findAccount.getPUID())) {
                    Log.e("WebUpdateLoginActivity", "PUID does not match");
                    mo7232a("PUID does not match");
                    return;
                }
                String str3 = ny3.f11603a.get("Username");
                LegacyToken a = ny3.mo9385a();
                if (str3 == null || a == null) {
                    Log.e("WebUpdateLoginActivity", "No username or token");
                    mo7232a("No username or token");
                    return;
                }
                StringBuilder a2 = C0789gk.m5562a("Updating account details: ");
                a2.append(this.f7909o0);
                Log.d("WebLoginActivity", a2.toString());
                findAccount.updateDetails(str3, a);
                Log.d("WebLoginActivity", "Account details updated successfully!");
                setResult(-1);
                finish();
            } catch (AccountManager.NoSuchAccountException unused) {
                Log.e("WebUpdateLoginActivity", "Failed to find account");
                mo7232a("Failed to find account");
            }
        } else {
            Log.e("WebUpdateLoginActivity", "Different account returned");
            mo7232a("Different account returned");
        }
    }

    /* renamed from: e */
    public void mo7231e() {
        finish();
    }

    @SuppressLint({"SetJavaScriptEnabled"})
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f7910p0 = new WebView(this);
        this.f7910p0.getSettings().setJavaScriptEnabled(true);
        this.f7911q0 = new my3(this);
        this.f7910p0.addJavascriptInterface(this.f7911q0, "external");
        this.f7909o0 = getIntent().getStringExtra("cid");
        String stringExtra = getIntent().getStringExtra("url");
        Log.d("WebUpdateLoginActivity", "Sign in url is: " + stringExtra);
        this.f7910p0.loadUrl(stringExtra);
        setContentView((View) this.f7910p0);
    }
}
