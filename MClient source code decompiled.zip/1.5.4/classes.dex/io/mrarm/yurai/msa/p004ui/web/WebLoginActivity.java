package p002io.mrarm.yurai.msa.p004ui.web;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import androidx.appcompat.app.AppCompatActivity;
import p000.my3;
import p002io.mrarm.yurai.msa.LegacyToken;
import p002io.mrarm.yurai.msa.MSASingleton;
import p002io.mrarm.yurai.msa.ServerConfig;

/* renamed from: io.mrarm.yurai.msa.ui.web.WebLoginActivity */
public class WebLoginActivity extends AppCompatActivity implements my3.C1375a {

    /* renamed from: o0 */
    public WebView f7907o0;

    /* renamed from: p0 */
    public my3 f7908p0;

    /* renamed from: a */
    public void mo7230a(ny3 ny3) {
        String str = ny3.f11603a.get("CID");
        String str2 = ny3.f11603a.get("PUID");
        String str3 = ny3.f11603a.get("Username");
        LegacyToken a = ny3.mo9385a();
        if (str == null || str2 == null || str3 == null || a == null) {
            mo7231e();
            return;
        }
        Log.d("WebLoginActivity", "Adding account: " + str);
        MSASingleton.getInstance(this).getAccountManager().addAccount(str3, str, str2, a);
        Log.d("WebLoginActivity", "Account added successfully!");
        Intent intent = new Intent();
        intent.putExtra("cid", str);
        setResult(-1, intent);
        finish();
    }

    /* renamed from: e */
    public void mo7231e() {
        finish();
    }

    @SuppressLint({"SetJavaScriptEnabled"})
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f7907o0 = new WebView(this);
        this.f7907o0.getSettings().setJavaScriptEnabled(true);
        this.f7908p0 = new my3(this);
        this.f7907o0.addJavascriptInterface(this.f7908p0, "external");
        Intent intent = getIntent();
        Uri.Builder buildUpon = Uri.parse(ServerConfig.getInlineConnectPartnerUrl()).buildUpon();
        buildUpon.appendQueryParameter("platform", "android2.1.0504.0524");
        if (intent.hasExtra("client_id")) {
            buildUpon.appendQueryParameter("client_id", intent.getStringExtra("client_id"));
        }
        if (intent.hasExtra("cobrandid")) {
            buildUpon.appendQueryParameter("cobrandid", intent.getStringExtra("cobrandid"));
        }
        String uri = buildUpon.build().toString();
        Log.d("WebLoginActivity", "Sign in url is: " + uri);
        this.f7907o0.loadUrl(uri);
        setContentView((View) this.f7907o0);
    }
}
