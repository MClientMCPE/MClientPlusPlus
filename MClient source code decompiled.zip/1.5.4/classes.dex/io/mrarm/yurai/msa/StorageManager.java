package p002io.mrarm.yurai.msa;

/* renamed from: io.mrarm.yurai.msa.StorageManager */
public abstract class StorageManager {
    public long handle;

    public StorageManager(long j) {
        this.handle = j;
    }

    public static native void nativeDestroy(long j);

    public void finalize() {
        nativeDestroy(this.handle);
        super.finalize();
    }
}
