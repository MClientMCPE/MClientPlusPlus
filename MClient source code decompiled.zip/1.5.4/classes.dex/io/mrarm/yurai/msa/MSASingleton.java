package p002io.mrarm.yurai.msa;

import android.content.Context;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

/* renamed from: io.mrarm.yurai.msa.MSASingleton */
public class MSASingleton {
    public static MSASingleton instance;
    public AccountManager accountManager = new AccountManager(this.storageManager);
    public LoginManager loginManager = new LoginManager(this.storageManager);
    public File path;
    public StorageManager storageManager = new SimpleStorageManager(this.path.getAbsolutePath());

    public MSASingleton(Context context) {
        this.path = new File(context.getFilesDir(), "msa");
        this.path.mkdirs();
        initCurlSsl(context);
    }

    public static MSASingleton getInstance(Context context) {
        if (instance == null && context != null) {
            instance = new MSASingleton(context);
        }
        return instance;
    }

    private void initCurlSsl(Context context) {
        File file = new File(this.path, "microsoft_ca.pem");
        try {
            InputStream openRawResource = context.getResources().openRawResource(ey3.microsoft_ca);
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            byte[] bArr = new byte[16384];
            while (true) {
                int read = openRawResource.read(bArr);
                if (read > 0) {
                    fileOutputStream.write(bArr, 0, read);
                } else {
                    openRawResource.close();
                    fileOutputStream.close();
                    nativeInitCurlSsl(file.getAbsolutePath());
                    return;
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static native void nativeInitCurlSsl(String str);

    public AccountManager getAccountManager() {
        return this.accountManager;
    }

    public LoginManager getLoginManager() {
        return this.loginManager;
    }
}
