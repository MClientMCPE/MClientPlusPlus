package p002io.mrarm.yurai.msa;

/* renamed from: io.mrarm.yurai.msa.AccountList */
public class AccountList {
    public String[] cid;
    public Entry[] entries;
    public String[] username;

    /* renamed from: io.mrarm.yurai.msa.AccountList$Entry */
    public class Entry {
        public int index;

        public Entry(int i) {
            this.index = i;
        }

        public String getCID() {
            return AccountList.this.cid[this.index];
        }

        public String getUsername() {
            return AccountList.this.username[this.index];
        }
    }

    public AccountList(String[] strArr, String[] strArr2) {
        this.username = strArr;
        this.cid = strArr2;
        this.entries = new Entry[strArr.length];
    }

    public Entry get(int i) {
        Entry[] entryArr = this.entries;
        if (entryArr[i] == null) {
            entryArr[i] = new Entry(i);
        }
        return this.entries[i];
    }

    public int size() {
        return this.username.length;
    }
}
