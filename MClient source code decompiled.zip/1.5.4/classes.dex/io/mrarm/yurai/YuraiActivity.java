package p002io.mrarm.yurai;

import android.annotation.SuppressLint;
import android.content.res.AssetManager;
import android.os.Bundle;
import com.mojang.minecraftpe.MainActivity;
import java.io.File;
import java.io.InputStream;

/* renamed from: io.mrarm.yurai.YuraiActivity */
public abstract class YuraiActivity extends MainActivity {

    /* renamed from: X */
    public AssetManager f7903X;

    /* renamed from: Y */
    public String f7904Y;

    /* renamed from: Z */
    public String f7905Z;

    /* renamed from: a0 */
    public HookManager f7906a0;

    private String getGameLibraryDlopenPath() {
        return this.f7905Z;
    }

    public static native void nativeLoadLibrary();

    public static native void nativePatchDataLocations(long j, String str);

    /* renamed from: b */
    public void mo7118b() {
        this.f7906a0.mo7201c();
        nativeLoadLibrary();
        nativePatchDataLocations(this.f7906a0.mo7200b(), C2085v5.m14458a(this).getAbsolutePath());
    }

    /* renamed from: c */
    public abstract zx3 mo7119c();

    /* renamed from: d */
    public void mo7203d() {
        System.loadLibrary("yurai");
    }

    public AssetManager getGameAssetManager() {
        return this.f7903X;
    }

    @SuppressLint({"UnsafeDynamicallyLoadedCode"})
    public void onCreate(Bundle bundle) {
        mo7203d();
        if (isOnCreateCancelled()) {
            super.onCreate(bundle);
            return;
        }
        ty3.m13665a(this);
        File a = ((ay3) mo7119c()).mo2200a("libc++_shared.so");
        if (a != null) {
            System.load(a.getAbsolutePath());
        }
        File a2 = ((ay3) mo7119c()).mo2200a("libgnustl_shared.so");
        if (a2 != null) {
            System.load(a2.getAbsolutePath());
        }
        System.load(((ay3) mo7119c()).mo2200a("libfmod.so").getAbsolutePath());
        this.f7904Y = ((ay3) mo7119c()).mo2200a("libminecraftpe.so").getAbsolutePath();
        String str = this.f7904Y;
        this.f7905Z = str;
        int patchLoadLibrary = Sopatch.patchLoadLibrary(str, "libminecraftpe.so", getCacheDir().getAbsolutePath());
        if ((patchLoadLibrary & 1) != 0) {
            this.f7905Z = "libminecraftpe.so";
        }
        if ((patchLoadLibrary & 4) != 0) {
            this.f7904Y = new File(getCacheDir(), "libminecraftpe.so").getAbsolutePath();
        }
        this.f7906a0 = new HookManager();
        this.f7906a0.mo7199a("libminecraftpe.so");
        mo7118b();
        this.f7906a0.mo7198a();
        System.load(this.f7904Y);
        this.f7903X = ((ay3) mo7119c()).f1607d;
        super.onCreate(bundle);
    }

    public InputStream openAssetFile(String str) {
        return this.f7903X.open(str);
    }
}
