package p002io.mrarm.yurai.xal;

import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;
import com.microsoft.xal.browser.BrowserLaunchActivity;
import java.util.HashMap;

/* renamed from: io.mrarm.yurai.xal.XalLoginActivity */
public class XalLoginActivity extends AppCompatActivity {

    /* renamed from: o0 */
    public WebView f7912o0;

    /* renamed from: p0 */
    public long f7913p0;

    /* renamed from: q0 */
    public String f7914q0;

    /* renamed from: r0 */
    public boolean f7915r0;

    /* renamed from: s0 */
    public boolean f7916s0;

    /* renamed from: io.mrarm.yurai.xal.XalLoginActivity$b */
    public class C0961b extends WebViewClient {
        public /* synthetic */ C0961b(C0960a aVar) {
        }

        public boolean shouldOverrideUrlLoading(WebView webView, String str) {
            if (!str.startsWith(XalLoginActivity.this.f7914q0)) {
                return false;
            }
            Log.d("XalLoginActivity", "Reached endUrl: " + str);
            XalLoginActivity xalLoginActivity = XalLoginActivity.this;
            boolean z = xalLoginActivity.f7916s0;
            long j = xalLoginActivity.f7913p0;
            if (z) {
                BrowserLaunchActivity.urlOperationSucceeded(j, str, false, com.microsoft.xal.browser.WebView.DEFAULT_BROWSER_INFO);
            } else {
                com.microsoft.xal.browser.WebView.urlOperationSucceeded(j, str, false, com.microsoft.xal.browser.WebView.DEFAULT_BROWSER_INFO);
            }
            XalLoginActivity xalLoginActivity2 = XalLoginActivity.this;
            xalLoginActivity2.f7915r0 = true;
            xalLoginActivity2.finish();
            return true;
        }
    }

    /* renamed from: r */
    public static void m7109r() {
        for (String str : new String[]{"login.live.com", "account.live.com", "live.com", "xboxlive.com", "sisu.xboxlive.com"}) {
            CookieManager instance = CookieManager.getInstance();
            String cookie = instance.getCookie("https://" + str);
            if (cookie != null) {
                for (String str2 : cookie.split(";")) {
                    int indexOf = str2.indexOf("=");
                    if (indexOf != -1) {
                        String trim = str2.substring(0, indexOf).trim();
                        Log.d("XalLoginActivity", "Deleting cookie: " + str2);
                        instance.setCookie("https://" + str, trim + "=;Expires=Thu, 01 Jan 1970 00:00:01 GMT;Domain=" + str + ";Path=/");
                    }
                }
            }
        }
        if (Build.VERSION.SDK_INT >= 21) {
            CookieManager.getInstance().flush();
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f7913p0 = getIntent().getLongExtra("native_op", 0);
        String stringExtra = getIntent().getStringExtra("start_url");
        this.f7914q0 = getIntent().getStringExtra("end_url");
        this.f7916s0 = getIntent().getBooleanExtra("browser_launch_activity_natives", false);
        String[] stringArrayExtra = getIntent().getStringArrayExtra("header_keys");
        String[] stringArrayExtra2 = getIntent().getStringArrayExtra("header_vals");
        HashMap hashMap = new HashMap();
        if (!(stringArrayExtra == null || stringArrayExtra2 == null || stringArrayExtra.length != stringArrayExtra2.length)) {
            for (int i = 0; i < stringArrayExtra.length; i++) {
                hashMap.put(stringArrayExtra[i], stringArrayExtra2[i]);
            }
        }
        this.f7912o0 = new WebView(this);
        this.f7912o0.getSettings().setJavaScriptEnabled(true);
        this.f7912o0.setWebViewClient(new C0961b((C0960a) null));
        Log.d("XalLoginActivity", "Sign in url is: " + stringExtra);
        Log.d("XalLoginActivity", "End url is: " + this.f7914q0);
        this.f7912o0.loadUrl(stringExtra, hashMap);
        setContentView((View) this.f7912o0);
    }

    public void onDestroy() {
        super.onDestroy();
        if (!this.f7915r0) {
            boolean z = this.f7916s0;
            long j = this.f7913p0;
            if (z) {
                BrowserLaunchActivity.urlOperationCanceled(j, false, com.microsoft.xal.browser.WebView.DEFAULT_BROWSER_INFO);
            } else {
                com.microsoft.xal.browser.WebView.urlOperationCanceled(j, false, com.microsoft.xal.browser.WebView.DEFAULT_BROWSER_INFO);
            }
        }
    }
}
