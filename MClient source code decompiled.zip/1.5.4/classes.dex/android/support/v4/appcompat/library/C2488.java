package android.support.p001v4.appcompat.library;

import android.C2490;

/* renamed from: android.support.v4.appcompat.library.ۤۦۤۡ  reason: contains not printable characters */
public class C2488 {

    /* renamed from: ۢۨۢۨ  reason: not valid java name and contains not printable characters */
    public static boolean f18635;

    /* renamed from: ۟۠۠ۦۧ  reason: not valid java name and contains not printable characters */
    public static String m17397(short[] sArr, int i, int i2, int i3) {
        char[] cArr = new char[i2];
        int i4 = 0;
        while (true) {
            char c = 1616;
            while (true) {
                c ^= 1633;
                switch (c) {
                    case '1':
                        if (i4 < i2) {
                            c = 1709;
                            break;
                        }
                    case 14:
                        c = 1678;
                        break;
                    case 204:
                        short s = sArr[0 - ((0 - i) - i4)];
                        cArr[i4] = (char) ((char) ((s & (i3 ^ -1)) | ((s ^ -1) & i3)));
                        i4++;
                        char c2 = 1740;
                        while (true) {
                            c2 ^= 1757;
                            switch (c2) {
                                case 17:
                                    c2 = 1771;
                                    break;
                                case '6':
                            }
                        }
                        break;
                    case 239:
                        return new String(cArr);
                }
            }
        }
    }

    /* renamed from: ۣ۟ۥۨۢ  reason: not valid java name and contains not printable characters */
    public static int m17398() {
        String str = "ۣۥۢ";
        int i = 0;
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        Integer num = null;
        Object[] objArr = null;
        String str2 = null;
        Object obj = null;
        while (true) {
            switch (C2486.m17391((Object) str)) {
                case 56478:
                    str = "ۧ۟۠";
                    i3 = 1752554;
                    break;
                case 1746780:
                    str = "ۦۦۤ";
                    i3 = i | i2;
                    break;
                case 1746942:
                    str = "ۨۡۧ";
                    i3 = i4 ^ -1;
                    break;
                case 1747712:
                    str2 = (String) obj;
                    str = "ۥۦ۠";
                    break;
                case 1750720:
                    obj = C2490.m592n(44751);
                    str = "۠ۡۡ";
                    break;
                case 1750819:
                    objArr[0] = str2;
                    str = "ۨۧ۟";
                    break;
                case 1752671:
                    str = "ۣۨۨ";
                    objArr = new Object[1];
                    break;
                case 1753636:
                    return i3;
                case 1754376:
                    str = "۟ۢ۟";
                    i = i3 & i4;
                    break;
                case 1754657:
                    str = "۟ۧۦ";
                    i4 = num.intValue();
                    break;
                case 1755406:
                    str = "ۥۣ";
                    i2 = i3 & -1752555;
                    break;
                case 1755584:
                    obj = C2490.m594n(39369, (Object) null, objArr);
                    str = "۠ۨۦ";
                    break;
                default:
                    num = obj;
                    str = "ۧۨۢ";
                    break;
            }
        }
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ۣۣ۠ۧ  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String m17399(java.lang.String r15) {
        /*
            r14 = 25614(0x640e, float:3.5893E-41)
            r11 = 3076(0xc04, float:4.31E-42)
            r13 = 93024(0x16b60, float:1.30354E-40)
            r12 = 1
            r4 = 0
            r0 = 2
            java.lang.Object[] r5 = new java.lang.Object[r0]
            java.lang.Integer r0 = new java.lang.Integer
            r1 = 8216238(0x7d5eae, float:1.1513402E-38)
            r0.<init>(r1)
            r5[r4] = r0
            java.lang.Integer r0 = new java.lang.Integer
            r1 = -5994417(0xffffffffffa4884f, float:NaN)
            r0.<init>(r1)
            r5[r12] = r0
            java.lang.Object r0 = android.C2491.m601n(r14)
            java.lang.String r0 = (java.lang.String) r0
            java.lang.Object r1 = android.C2491.m601n(r14)
            java.lang.String r1 = (java.lang.String) r1
            r3 = r4
            r2 = r1
            r1 = r0
        L_0x002f:
            r0 = 1616(0x650, float:2.264E-42)
        L_0x0031:
            r0 = r0 ^ 1633(0x661, float:2.288E-42)
            switch(r0) {
                case 14: goto L_0x0037;
                case 49: goto L_0x003a;
                case 204: goto L_0x0041;
                case 239: goto L_0x00d6;
                default: goto L_0x0036;
            }
        L_0x0036:
            goto L_0x0031
        L_0x0037:
            r0 = 1678(0x68e, float:2.351E-42)
            goto L_0x0031
        L_0x003a:
            r0 = 15
            if (r3 < r0) goto L_0x0037
            r0 = 1709(0x6ad, float:2.395E-42)
            goto L_0x0031
        L_0x0041:
            java.lang.Object[] r0 = new java.lang.Object[r4]
            java.lang.Object r0 = android.C2491.m603n(r13, r15, r0)
            java.lang.Integer r0 = (java.lang.Integer) r0
            int r3 = r0.intValue()
            r6 = 86268(0x150fc, float:1.20887E-40)
            r0 = r5[r4]
            java.lang.Integer r0 = (java.lang.Integer) r0
            java.lang.Object[] r7 = new java.lang.Object[r4]
            java.lang.Object r0 = android.C2490.m594n(r6, r0, r7)
            java.lang.Integer r0 = (java.lang.Integer) r0
            int r0 = r0.intValue()
            java.io.ByteArrayOutputStream r6 = new java.io.ByteArrayOutputStream
            r7 = r0 ^ -1
            r8 = 8216236(0x7d5eac, float:1.1513399E-38)
            r7 = r7 & r8
            r8 = -8216237(0xffffffffff82a153, float:NaN)
            r0 = r0 & r8
            r0 = r0 | r7
            int r0 = r3 / r0
            r6.<init>(r0)
            r3 = r4
        L_0x0073:
            java.lang.Object[] r0 = new java.lang.Object[r4]
            java.lang.Object r0 = android.C2491.m603n(r13, r15, r0)
            java.lang.Integer r0 = (java.lang.Integer) r0
            int r7 = r0.intValue()
            r0 = 1740(0x6cc, float:2.438E-42)
        L_0x0081:
            r0 = r0 ^ 1757(0x6dd, float:2.462E-42)
            switch(r0) {
                case 17: goto L_0x0087;
                case 54: goto L_0x008c;
                case 471: goto L_0x016c;
                case 500: goto L_0x008f;
                default: goto L_0x0086;
            }
        L_0x0086:
            goto L_0x0081
        L_0x0087:
            if (r3 < r7) goto L_0x008c
            r0 = 1833(0x729, float:2.569E-42)
            goto L_0x0081
        L_0x008c:
            r0 = 1802(0x70a, float:2.525E-42)
            goto L_0x0081
        L_0x008f:
            r0 = 82775(0x14357, float:1.15992E-40)
            java.lang.Object[] r1 = new java.lang.Object[r4]
            java.lang.Object r0 = android.C2491.m603n(r0, r6, r1)
            byte[] r0 = (byte[]) r0
            int r3 = r0.length
            java.lang.Object[] r1 = new java.lang.Object[r4]
            java.lang.Object r1 = android.C2491.m603n(r13, r2, r1)
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r6 = r1.intValue()
        L_0x00a7:
            r1 = 1864(0x748, float:2.612E-42)
        L_0x00a9:
            r1 = r1 ^ 1881(0x759, float:2.636E-42)
            switch(r1) {
                case 17: goto L_0x00af;
                case 47384: goto L_0x01ed;
                case 47417: goto L_0x00b9;
                case 47483: goto L_0x00b5;
                default: goto L_0x00ae;
            }
        L_0x00ae:
            goto L_0x00a9
        L_0x00af:
            if (r3 > 0) goto L_0x00b5
            r1 = 48736(0xbe60, float:6.8294E-41)
            goto L_0x00a9
        L_0x00b5:
            r1 = 48705(0xbe41, float:6.825E-41)
            goto L_0x00a9
        L_0x00b9:
            r1 = r4
        L_0x00ba:
            int r3 = r0.length
            r2 = 48767(0xbe7f, float:6.8337E-41)
        L_0x00be:
            r5 = 48784(0xbe90, float:6.8361E-41)
            r2 = r2 ^ r5
            switch(r2) {
                case 14: goto L_0x00c6;
                case 45: goto L_0x023d;
                case 76: goto L_0x00d0;
                case 239: goto L_0x00ca;
                default: goto L_0x00c5;
            }
        L_0x00c5:
            goto L_0x00be
        L_0x00c6:
            r2 = 48829(0xbebd, float:6.8424E-41)
            goto L_0x00be
        L_0x00ca:
            if (r1 < r3) goto L_0x00c6
            r2 = 48860(0xbedc, float:6.8467E-41)
            goto L_0x00be
        L_0x00d0:
            java.lang.String r1 = new java.lang.String
            r1.<init>(r0)
            return r1
        L_0x00d6:
            r6 = 70144(0x11200, float:9.8293E-41)
            java.lang.StringBuffer r0 = new java.lang.StringBuffer
            r0.<init>()
            java.lang.Object[] r7 = new java.lang.Object[r12]
            r7[r4] = r1
            java.lang.Object r0 = android.C2491.m603n(r11, r0, r7)
            java.lang.StringBuffer r0 = (java.lang.StringBuffer) r0
            java.lang.Object[] r7 = new java.lang.Object[r12]
            r1 = 39014(0x9866, float:5.467E-41)
            r8 = 0
            java.lang.Object[] r9 = new java.lang.Object[r12]
            java.lang.Integer r10 = java.lang.Integer.valueOf(r3)
            r9[r4] = r10
            java.lang.Object r1 = android.C2491.m603n(r1, r8, r9)
            java.lang.String r1 = (java.lang.String) r1
            r7[r4] = r1
            java.lang.Object r0 = android.C2491.m603n(r11, r0, r7)
            java.lang.StringBuffer r0 = (java.lang.StringBuffer) r0
            java.lang.Object[] r1 = new java.lang.Object[r4]
            java.lang.Object r0 = android.C2491.m603n(r6, r0, r1)
            java.lang.String r0 = (java.lang.String) r0
            java.lang.StringBuffer r1 = new java.lang.StringBuffer
            r1.<init>()
            java.lang.Object[] r6 = new java.lang.Object[r12]
            r6[r4] = r2
            java.lang.Object r1 = android.C2491.m603n(r11, r1, r6)
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            r2 = 14369(0x3821, float:2.0135E-41)
            r6 = 0
            java.lang.Object[] r7 = new java.lang.Object[r4]
            java.lang.Object r2 = android.C2491.m603n(r2, r6, r7)
            java.lang.Double r2 = (java.lang.Double) r2
            double r6 = r2.doubleValue()
            r2 = 10
            double r8 = (double) r2
            double r6 = r6 * r8
            int r2 = (int) r6
            r6 = 70144(0x11200, float:9.8293E-41)
            r7 = 49679(0xc20f, float:6.9615E-41)
            java.lang.Object[] r8 = new java.lang.Object[r12]
            r9 = r2 ^ -1
            r9 = r9 & r3
            r10 = r3 ^ -1
            r2 = r2 & r10
            r2 = r2 | r9
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            r8[r4] = r2
            java.lang.Object r1 = android.C2491.m603n(r7, r1, r8)
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            java.lang.Object[] r2 = new java.lang.Object[r4]
            java.lang.Object r1 = android.C2491.m603n(r6, r1, r2)
            java.lang.String r1 = (java.lang.String) r1
            int r2 = r3 + -24
            int r2 = r2 + 1
            int r2 = r2 + 24
            r3 = 48891(0xbefb, float:6.8511E-41)
        L_0x015b:
            r6 = 48908(0xbf0c, float:6.8535E-41)
            r3 = r3 ^ r6
            switch(r3) {
                case 22: goto L_0x0163;
                case 503: goto L_0x0168;
                default: goto L_0x0162;
            }
        L_0x0162:
            goto L_0x015b
        L_0x0163:
            r3 = r2
            r2 = r1
            r1 = r0
            goto L_0x002f
        L_0x0168:
            r3 = 48922(0xbf1a, float:6.8554E-41)
            goto L_0x015b
        L_0x016c:
            r7 = 33291(0x820b, float:4.665E-41)
            java.lang.Object[] r8 = new java.lang.Object[r12]
            r0 = 28217(0x6e39, float:3.954E-41)
            java.lang.Object[] r9 = new java.lang.Object[r12]
            java.lang.Integer r10 = java.lang.Integer.valueOf(r3)
            r9[r4] = r10
            java.lang.Object r0 = android.C2491.m603n(r0, r15, r9)
            java.lang.Character r0 = (java.lang.Character) r0
            char r0 = r0.charValue()
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)
            r8[r4] = r0
            java.lang.Object r0 = android.C2491.m603n(r7, r1, r8)
            java.lang.Integer r0 = (java.lang.Integer) r0
            int r0 = r0.intValue()
            int r7 = r0 << 4
            r8 = 33291(0x820b, float:4.665E-41)
            java.lang.Object[] r9 = new java.lang.Object[r12]
            r0 = 28217(0x6e39, float:3.954E-41)
            java.lang.Object[] r10 = new java.lang.Object[r12]
            int r11 = 0 - r3
            int r11 = 1 - r11
            java.lang.Integer r11 = java.lang.Integer.valueOf(r11)
            r10[r4] = r11
            java.lang.Object r0 = android.C2491.m603n(r0, r15, r10)
            java.lang.Character r0 = (java.lang.Character) r0
            char r0 = r0.charValue()
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)
            r9[r4] = r0
            java.lang.Object r0 = android.C2491.m603n(r8, r1, r9)
            java.lang.Integer r0 = (java.lang.Integer) r0
            int r0 = r0.intValue()
            r8 = 3899(0xf3b, float:5.464E-42)
            java.lang.Object[] r9 = new java.lang.Object[r12]
            r10 = r7 ^ r0
            r0 = r0 & r7
            r0 = r0 | r10
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)
            r9[r4] = r0
            android.C2491.m603n(r8, r6, r9)
            int r0 = 0 - r3
            int r0 = r0 + -2
            int r0 = 0 - r0
            r3 = 49666(0xc202, float:6.9597E-41)
        L_0x01de:
            r7 = 49683(0xc213, float:6.9621E-41)
            r3 = r3 ^ r7
            switch(r3) {
                case 17: goto L_0x01e6;
                case 50: goto L_0x01ea;
                default: goto L_0x01e5;
            }
        L_0x01e5:
            goto L_0x01de
        L_0x01e6:
            r3 = 49697(0xc221, float:6.964E-41)
            goto L_0x01de
        L_0x01ea:
            r3 = r0
            goto L_0x0073
        L_0x01ed:
            r7 = 86268(0x150fc, float:1.20887E-40)
            r1 = r5[r12]
            java.lang.Integer r1 = (java.lang.Integer) r1
            java.lang.Object[] r8 = new java.lang.Object[r4]
            java.lang.Object r1 = android.C2490.m594n(r7, r1, r8)
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r7 = r1 ^ -1
            r8 = 5994416(0x5b77b0, float:8.399966E-39)
            r7 = r7 & r8
            r8 = -5994417(0xffffffffffa4884f, float:NaN)
            r1 = r1 & r8
            r7 = r7 | r1
            byte r8 = r0[r7]
            r1 = 28217(0x6e39, float:3.954E-41)
            java.lang.Object[] r9 = new java.lang.Object[r12]
            int r10 = r7 % r6
            java.lang.Integer r10 = java.lang.Integer.valueOf(r10)
            r9[r4] = r10
            java.lang.Object r1 = android.C2491.m603n(r1, r2, r9)
            java.lang.Character r1 = (java.lang.Character) r1
            char r1 = r1.charValue()
            r9 = r8 ^ -1
            r9 = r9 & r1
            r1 = r1 ^ -1
            r1 = r1 & r8
            r1 = r1 | r9
            byte r1 = (byte) r1
            byte r1 = (byte) r1
            r0[r7] = r1
            r1 = 49790(0xc27e, float:6.977E-41)
        L_0x0231:
            r7 = 49807(0xc28f, float:6.9794E-41)
            r1 = r1 ^ r7
            switch(r1) {
                case 18: goto L_0x00a7;
                case 241: goto L_0x0239;
                default: goto L_0x0238;
            }
        L_0x0238:
            goto L_0x0231
        L_0x0239:
            r1 = 49821(0xc29d, float:6.9814E-41)
            goto L_0x0231
        L_0x023d:
            java.lang.Object r1 = android.C2491.m601n(r14)
            java.lang.String r1 = (java.lang.String) r1
            java.lang.Object[] r2 = new java.lang.Object[r4]
            java.lang.Object r1 = android.C2491.m603n(r13, r1, r2)
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            int r1 = 0 - r1
            int r1 = r1 + -1
            int r1 = 0 - r1
            r2 = 49914(0xc2fa, float:6.9944E-41)
        L_0x0258:
            r3 = 49931(0xc30b, float:6.9968E-41)
            r2 = r2 ^ r3
            switch(r2) {
                case 497: goto L_0x0260;
                case 1711: goto L_0x00ba;
                default: goto L_0x025f;
            }
        L_0x025f:
            goto L_0x0258
        L_0x0260:
            r2 = 50596(0xc5a4, float:7.09E-41)
            goto L_0x0258
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p001v4.appcompat.library.C2488.m17399(java.lang.String):java.lang.String");
    }
}
