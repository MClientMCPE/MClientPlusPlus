package android.support.p001v4.appcompat.library;

import android.C2490;
import android.C2491;

/* renamed from: android.support.v4.appcompat.library.ۣ۟۟۠۠  reason: contains not printable characters */
public class C2484 {

    /* renamed from: short  reason: not valid java name */
    private static final short[] f18630short;

    /* renamed from: ۨۤۤۢ  reason: not valid java name and contains not printable characters */
    public static boolean f18631;

    static {
        int intValue = ((Integer) C2490.m594n(86268, (Integer) new Object[]{new Integer(2154281)}[0], new Object[0])).intValue();
        short[] sArr = new short[((intValue & -2154284) | ((intValue ^ -1) & 2154283))];
        sArr[0] = 3027;
        sArr[1] = 700;
        f18630short = sArr;
    }

    /* renamed from: ۟۟۟  reason: not valid java name and contains not printable characters */
    public static int m17382() {
        String str = "ۦۦۤ";
        int i = 0;
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        Integer num = null;
        Object[] objArr = null;
        String str2 = null;
        Object obj = null;
        while (true) {
            switch (C2486.m17391((Object) str)) {
                case 1746781:
                    str = "۠ۤۦ";
                    i2 = i3 & 1749675;
                    break;
                case 1746785:
                    str = "۟ۢ۠";
                    i3 = i4 ^ -1;
                    break;
                case 1747810:
                    str = "ۤۡۦ";
                    i3 = -1749676;
                    break;
                case 1748641:
                    obj = C2490.m594n(39369, (Object) null, objArr);
                    str = "ۧ۠ۢ";
                    break;
                case 1748645:
                    return i3;
                case 1750655:
                    str = "ۡ۠ۤ";
                    i3 = i | i2;
                    break;
                case 1751561:
                    str = "ۣۣ۟";
                    i = i3 & i4;
                    break;
                case 1752581:
                    objArr[0] = str2;
                    str = "ۡ۠۠";
                    break;
                case 1753483:
                    str2 = (String) obj;
                    str = "۟۟۟";
                    break;
                case 1753636:
                    obj = C2491.m601n(32124);
                    str = "ۦۡۦ";
                    break;
                case 1754409:
                    num = obj;
                    str = "ۣۧۨ";
                    break;
                case 1754658:
                    str = "۟ۢۤ";
                    i4 = num.intValue();
                    break;
                default:
                    str = "ۥۣۣ";
                    objArr = new Object[1];
                    break;
            }
        }
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ۣۣ۟۠ۨ  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String m17383(java.lang.String r14) {
        /*
            java.lang.Integer r6 = new java.lang.Integer
            r0 = 2276357(0x22bc05, float:3.189856E-39)
            r6.<init>(r0)
            r5 = 0
            r0 = 25614(0x640e, float:3.5893E-41)
            java.lang.Object r0 = android.C2491.m601n(r0)
            java.lang.String r0 = (java.lang.String) r0
            r1 = 25614(0x640e, float:3.5893E-41)
            java.lang.Object r1 = android.C2491.m601n(r1)
            java.lang.String r1 = (java.lang.String) r1
            r2 = 0
            r3 = r2
            r4 = r1
            r1 = r0
        L_0x001d:
            r0 = 1616(0x650, float:2.264E-42)
        L_0x001f:
            r0 = r0 ^ 1633(0x661, float:2.288E-42)
            switch(r0) {
                case 14: goto L_0x0025;
                case 49: goto L_0x0028;
                case 204: goto L_0x002f;
                case 239: goto L_0x01b6;
                default: goto L_0x0024;
            }
        L_0x0024:
            goto L_0x001f
        L_0x0025:
            r0 = 1678(0x68e, float:2.351E-42)
            goto L_0x001f
        L_0x0028:
            r0 = 15
            if (r3 < r0) goto L_0x0025
            r0 = 1709(0x6ad, float:2.395E-42)
            goto L_0x001f
        L_0x002f:
            r0 = 93024(0x16b60, float:1.30354E-40)
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]
            java.lang.Object r0 = android.C2491.m603n(r0, r14, r2)
            java.lang.Integer r0 = (java.lang.Integer) r0
            int r2 = r0.intValue()
            r3 = 86268(0x150fc, float:1.20887E-40)
            r0 = 1
            java.lang.Object[] r0 = new java.lang.Object[r0]
            r7 = 0
            r0[r7] = r6
            r6 = 0
            r0 = r0[r6]
            java.lang.Integer r0 = (java.lang.Integer) r0
            r6 = 0
            java.lang.Object[] r6 = new java.lang.Object[r6]
            java.lang.Object r0 = android.C2490.m594n(r3, r0, r6)
            java.lang.Integer r0 = (java.lang.Integer) r0
            int r0 = r0.intValue()
            java.io.ByteArrayOutputStream r3 = new java.io.ByteArrayOutputStream
            r6 = r0 ^ -1
            r7 = 2276359(0x22bc07, float:3.189858E-39)
            r6 = r6 & r7
            r7 = -2276360(0xffffffffffdd43f8, float:NaN)
            r0 = r0 & r7
            r0 = r0 | r6
            int r0 = r2 / r0
            r3.<init>(r0)
            r0 = 0
            r2 = r0
        L_0x006e:
            r0 = 93024(0x16b60, float:1.30354E-40)
            r6 = 0
            java.lang.Object[] r6 = new java.lang.Object[r6]
            java.lang.Object r0 = android.C2491.m603n(r0, r14, r6)
            java.lang.Integer r0 = (java.lang.Integer) r0
            int r6 = r0.intValue()
            r0 = 1740(0x6cc, float:2.438E-42)
        L_0x0080:
            r0 = r0 ^ 1757(0x6dd, float:2.462E-42)
            switch(r0) {
                case 17: goto L_0x0086;
                case 54: goto L_0x008b;
                case 471: goto L_0x025f;
                case 500: goto L_0x008e;
                default: goto L_0x0085;
            }
        L_0x0085:
            goto L_0x0080
        L_0x0086:
            if (r2 < r6) goto L_0x008b
            r0 = 1833(0x729, float:2.569E-42)
            goto L_0x0080
        L_0x008b:
            r0 = 1802(0x70a, float:2.525E-42)
            goto L_0x0080
        L_0x008e:
            r0 = 82775(0x14357, float:1.15992E-40)
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.Object r0 = android.C2491.m603n(r0, r3, r1)
            byte[] r0 = (byte[]) r0
            r1 = 46713(0xb679, float:6.5459E-41)
            java.lang.Object r1 = android.C2491.m601n(r1)
            short[] r1 = (short[]) r1
            r3 = 39369(0x99c9, float:5.5168E-41)
            r6 = 0
            r2 = 1
            java.lang.Object[] r7 = new java.lang.Object[r2]
            r8 = 0
            r2 = 35026(0x88d2, float:4.9082E-41)
            java.lang.Object r2 = android.C2491.m601n(r2)
            java.lang.String r2 = (java.lang.String) r2
            r7[r8] = r2
            java.lang.Object r2 = android.C2490.m594n(r3, r6, r7)
            java.lang.Integer r2 = (java.lang.Integer) r2
            int r3 = r2.intValue()
            r6 = 39369(0x99c9, float:5.5168E-41)
            r7 = 0
            r2 = 1
            java.lang.Object[] r8 = new java.lang.Object[r2]
            r9 = 0
            r2 = 11935(0x2e9f, float:1.6724E-41)
            java.lang.Object r2 = android.C2491.m601n(r2)
            java.lang.String r2 = (java.lang.String) r2
            r8[r9] = r2
            java.lang.Object r2 = android.C2490.m594n(r6, r7, r8)
            java.lang.Integer r2 = (java.lang.Integer) r2
            int r6 = r2.intValue()
            r7 = 39369(0x99c9, float:5.5168E-41)
            r8 = 0
            r2 = 1
            java.lang.Object[] r9 = new java.lang.Object[r2]
            r10 = 0
            r2 = 41252(0xa124, float:5.7806E-41)
            java.lang.Object r2 = android.C2491.m601n(r2)
            java.lang.String r2 = (java.lang.String) r2
            r9[r10] = r2
            java.lang.Object r2 = android.C2490.m594n(r7, r8, r9)
            java.lang.Integer r2 = (java.lang.Integer) r2
            int r2 = r2.intValue()
            r7 = 80494(0x13a6e, float:1.12796E-40)
            r8 = 0
            r9 = 4
            java.lang.Object[] r9 = new java.lang.Object[r9]
            r10 = 0
            r9[r10] = r1
            r1 = 1
            r10 = -1746818(0xffffffffffe5587e, float:NaN)
            r10 = r10 & r6
            r6 = r6 ^ -1
            r11 = 1746817(0x1aa781, float:2.447812E-39)
            r6 = r6 & r11
            r6 = r6 | r10
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)
            r9[r1] = r6
            r1 = 2
            r6 = -1754629(0xffffffffffe539fb, float:NaN)
            r6 = r6 & r2
            r2 = r2 ^ -1
            r10 = 1754628(0x1ac604, float:2.458758E-39)
            r2 = r2 & r10
            r2 = r2 | r6
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            r9[r1] = r2
            r1 = 3
            r2 = -1753948(0xffffffffffe53ca4, float:NaN)
            r2 = r2 & r3
            r3 = r3 ^ -1
            r6 = 1753947(0x1ac35b, float:2.457803E-39)
            r3 = r3 & r6
            r2 = r2 | r3
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            r9[r1] = r2
            java.lang.Object r1 = android.C2490.m594n(r7, r8, r9)
            java.lang.String r1 = (java.lang.String) r1
            r2 = r1
        L_0x0140:
            r1 = 93024(0x16b60, float:1.30354E-40)
            r3 = 0
            java.lang.Object[] r3 = new java.lang.Object[r3]
            java.lang.Object r1 = android.C2491.m603n(r1, r2, r3)
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r3 = r1.intValue()
            r1 = 1864(0x748, float:2.612E-42)
        L_0x0152:
            r1 = r1 ^ 1881(0x759, float:2.636E-42)
            switch(r1) {
                case 17: goto L_0x0158;
                case 47384: goto L_0x02ec;
                case 47417: goto L_0x0162;
                case 47483: goto L_0x015e;
                default: goto L_0x0157;
            }
        L_0x0157:
            goto L_0x0152
        L_0x0158:
            if (r3 > 0) goto L_0x015e
            r1 = 48736(0xbe60, float:6.8294E-41)
            goto L_0x0152
        L_0x015e:
            r1 = 48705(0xbe41, float:6.825E-41)
            goto L_0x0152
        L_0x0162:
            r1 = 93024(0x16b60, float:1.30354E-40)
            r3 = 0
            java.lang.Object[] r3 = new java.lang.Object[r3]
            java.lang.Object r1 = android.C2491.m603n(r1, r2, r3)
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r3 = r1.intValue()
            r1 = 93024(0x16b60, float:1.30354E-40)
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]
            java.lang.Object r1 = android.C2491.m603n(r1, r4, r2)
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r6 = r1.intValue()
            r1 = 0
            r2 = r1
        L_0x0184:
            r1 = 48767(0xbe7f, float:6.8337E-41)
        L_0x0187:
            r7 = 48784(0xbe90, float:6.8361E-41)
            r1 = r1 ^ r7
            switch(r1) {
                case 14: goto L_0x018f;
                case 45: goto L_0x03d0;
                case 76: goto L_0x0199;
                case 239: goto L_0x0193;
                default: goto L_0x018e;
            }
        L_0x018e:
            goto L_0x0187
        L_0x018f:
            r1 = 48829(0xbebd, float:6.8424E-41)
            goto L_0x0187
        L_0x0193:
            if (r2 < r3) goto L_0x018f
            r1 = 48860(0xbedc, float:6.8467E-41)
            goto L_0x0187
        L_0x0199:
            r1 = r5
        L_0x019a:
            int r3 = r0.length
            r2 = 48891(0xbefb, float:6.8511E-41)
        L_0x019e:
            r4 = 48908(0xbf0c, float:6.8535E-41)
            r2 = r2 ^ r4
            switch(r2) {
                case 22: goto L_0x01a6;
                case 53: goto L_0x0409;
                case 503: goto L_0x01aa;
                case 32495: goto L_0x01b0;
                default: goto L_0x01a5;
            }
        L_0x01a5:
            goto L_0x019e
        L_0x01a6:
            r2 = 48953(0xbf39, float:6.8598E-41)
            goto L_0x019e
        L_0x01aa:
            if (r1 < r3) goto L_0x01a6
            r2 = 49635(0xc1e3, float:6.9553E-41)
            goto L_0x019e
        L_0x01b0:
            java.lang.String r1 = new java.lang.String
            r1.<init>(r0)
            return r1
        L_0x01b6:
            r2 = 70144(0x11200, float:9.8293E-41)
            r7 = 3076(0xc04, float:4.31E-42)
            r0 = 3076(0xc04, float:4.31E-42)
            java.lang.StringBuffer r8 = new java.lang.StringBuffer
            r8.<init>()
            r9 = 1
            java.lang.Object[] r9 = new java.lang.Object[r9]
            r10 = 0
            r9[r10] = r1
            java.lang.Object r0 = android.C2491.m603n(r0, r8, r9)
            java.lang.StringBuffer r0 = (java.lang.StringBuffer) r0
            r1 = 1
            java.lang.Object[] r8 = new java.lang.Object[r1]
            r9 = 0
            r1 = 39014(0x9866, float:5.467E-41)
            r10 = 0
            r11 = 1
            java.lang.Object[] r11 = new java.lang.Object[r11]
            r12 = 0
            java.lang.Integer r13 = java.lang.Integer.valueOf(r3)
            r11[r12] = r13
            java.lang.Object r1 = android.C2491.m603n(r1, r10, r11)
            java.lang.String r1 = (java.lang.String) r1
            r8[r9] = r1
            java.lang.Object r0 = android.C2491.m603n(r7, r0, r8)
            java.lang.StringBuffer r0 = (java.lang.StringBuffer) r0
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]
            java.lang.Object r0 = android.C2491.m603n(r2, r0, r1)
            java.lang.String r0 = (java.lang.String) r0
            r1 = 3076(0xc04, float:4.31E-42)
            java.lang.StringBuffer r2 = new java.lang.StringBuffer
            r2.<init>()
            r7 = 1
            java.lang.Object[] r7 = new java.lang.Object[r7]
            r8 = 0
            r7[r8] = r4
            java.lang.Object r1 = android.C2491.m603n(r1, r2, r7)
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            r2 = 14369(0x3821, float:2.0135E-41)
            r4 = 0
            r7 = 0
            java.lang.Object[] r7 = new java.lang.Object[r7]
            java.lang.Object r2 = android.C2491.m603n(r2, r4, r7)
            java.lang.Double r2 = (java.lang.Double) r2
            double r8 = r2.doubleValue()
            r2 = 10
            double r10 = (double) r2
            double r8 = r8 * r10
            int r2 = (int) r8
            r4 = 70144(0x11200, float:9.8293E-41)
            r7 = 49679(0xc20f, float:6.9615E-41)
            r8 = 1
            java.lang.Object[] r8 = new java.lang.Object[r8]
            r9 = 0
            r10 = r2 ^ -1
            r10 = r10 & r3
            r11 = r3 ^ -1
            r2 = r2 & r11
            r2 = r2 | r10
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            r8[r9] = r2
            java.lang.Object r1 = android.C2491.m603n(r7, r1, r8)
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]
            java.lang.Object r1 = android.C2491.m603n(r4, r1, r2)
            java.lang.String r1 = (java.lang.String) r1
            int r2 = r3 + -2
            int r2 = r2 + 1
            int r2 = r2 + 2
            r3 = 49666(0xc202, float:6.9597E-41)
        L_0x024e:
            r4 = 49683(0xc213, float:6.9621E-41)
            r3 = r3 ^ r4
            switch(r3) {
                case 17: goto L_0x0256;
                case 50: goto L_0x025a;
                default: goto L_0x0255;
            }
        L_0x0255:
            goto L_0x024e
        L_0x0256:
            r3 = 49697(0xc221, float:6.964E-41)
            goto L_0x024e
        L_0x025a:
            r3 = r2
            r4 = r1
            r1 = r0
            goto L_0x001d
        L_0x025f:
            r6 = 33291(0x820b, float:4.665E-41)
            r0 = 1
            java.lang.Object[] r7 = new java.lang.Object[r0]
            r8 = 0
            r0 = 28217(0x6e39, float:3.954E-41)
            r9 = 1
            java.lang.Object[] r9 = new java.lang.Object[r9]
            r10 = 0
            java.lang.Integer r11 = java.lang.Integer.valueOf(r2)
            r9[r10] = r11
            java.lang.Object r0 = android.C2491.m603n(r0, r14, r9)
            java.lang.Character r0 = (java.lang.Character) r0
            char r0 = r0.charValue()
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)
            r7[r8] = r0
            java.lang.Object r0 = android.C2491.m603n(r6, r1, r7)
            java.lang.Integer r0 = (java.lang.Integer) r0
            int r0 = r0.intValue()
            int r6 = r0 << 4
            r7 = 33291(0x820b, float:4.665E-41)
            r0 = 1
            java.lang.Object[] r8 = new java.lang.Object[r0]
            r9 = 0
            r0 = 28217(0x6e39, float:3.954E-41)
            r10 = 1
            java.lang.Object[] r10 = new java.lang.Object[r10]
            r11 = 0
            int r12 = r2 + 10
            int r12 = r12 + 1
            int r12 = r12 + -10
            java.lang.Integer r12 = java.lang.Integer.valueOf(r12)
            r10[r11] = r12
            java.lang.Object r0 = android.C2491.m603n(r0, r14, r10)
            java.lang.Character r0 = (java.lang.Character) r0
            char r0 = r0.charValue()
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)
            r8[r9] = r0
            java.lang.Object r0 = android.C2491.m603n(r7, r1, r8)
            java.lang.Integer r0 = (java.lang.Integer) r0
            int r0 = r0.intValue()
            r7 = 3899(0xf3b, float:5.464E-42)
            r8 = 1
            java.lang.Object[] r8 = new java.lang.Object[r8]
            r9 = 0
            r10 = r6 ^ r0
            r0 = r0 & r6
            r0 = r0 | r10
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)
            r8[r9] = r0
            android.C2491.m603n(r7, r3, r8)
            int r0 = r2 + -29
            int r0 = r0 + 2
            int r0 = r0 + 29
            r2 = 49790(0xc27e, float:6.977E-41)
        L_0x02dd:
            r6 = 49807(0xc28f, float:6.9794E-41)
            r2 = r2 ^ r6
            switch(r2) {
                case 18: goto L_0x02e5;
                case 241: goto L_0x02e8;
                default: goto L_0x02e4;
            }
        L_0x02e4:
            goto L_0x02dd
        L_0x02e5:
            r2 = r0
            goto L_0x006e
        L_0x02e8:
            r2 = 49821(0xc29d, float:6.9814E-41)
            goto L_0x02dd
        L_0x02ec:
            r1 = 25614(0x640e, float:3.5893E-41)
            java.lang.Object r1 = android.C2491.m601n(r1)
            java.lang.String r1 = (java.lang.String) r1
            r2 = 93024(0x16b60, float:1.30354E-40)
            r3 = 0
            java.lang.Object[] r3 = new java.lang.Object[r3]
            java.lang.Object r2 = android.C2491.m603n(r2, r1, r3)
            java.lang.Integer r2 = (java.lang.Integer) r2
            int r3 = r2.intValue()
            r2 = 49914(0xc2fa, float:6.9944E-41)
        L_0x0307:
            r6 = 49931(0xc30b, float:6.9968E-41)
            r2 = r2 ^ r6
            switch(r2) {
                case 497: goto L_0x030f;
                case 1711: goto L_0x0315;
                case 1736: goto L_0x0436;
                case 1769: goto L_0x0319;
                default: goto L_0x030e;
            }
        L_0x030e:
            goto L_0x0307
        L_0x030f:
            if (r3 != 0) goto L_0x0315
            r2 = 50658(0xc5e2, float:7.0987E-41)
            goto L_0x0307
        L_0x0315:
            r2 = 50627(0xc5c3, float:7.0944E-41)
            goto L_0x0307
        L_0x0319:
            r1 = 46713(0xb679, float:6.5459E-41)
            java.lang.Object r1 = android.C2491.m601n(r1)
            short[] r1 = (short[]) r1
            r3 = 39369(0x99c9, float:5.5168E-41)
            r6 = 0
            r2 = 1
            java.lang.Object[] r7 = new java.lang.Object[r2]
            r8 = 0
            r2 = 50833(0xc691, float:7.1232E-41)
            java.lang.Object r2 = android.C2491.m601n(r2)
            java.lang.String r2 = (java.lang.String) r2
            r7[r8] = r2
            java.lang.Object r2 = android.C2490.m594n(r3, r6, r7)
            java.lang.Integer r2 = (java.lang.Integer) r2
            int r3 = r2.intValue()
            r6 = 39369(0x99c9, float:5.5168E-41)
            r7 = 0
            r2 = 1
            java.lang.Object[] r8 = new java.lang.Object[r2]
            r9 = 0
            r2 = 47539(0xb9b3, float:6.6616E-41)
            java.lang.Object r2 = android.C2491.m601n(r2)
            java.lang.String r2 = (java.lang.String) r2
            r8[r9] = r2
            java.lang.Object r2 = android.C2490.m594n(r6, r7, r8)
            java.lang.Integer r2 = (java.lang.Integer) r2
            int r6 = r2.intValue()
            r7 = 39369(0x99c9, float:5.5168E-41)
            r8 = 0
            r2 = 1
            java.lang.Object[] r9 = new java.lang.Object[r2]
            r10 = 0
            r2 = 71914(0x118ea, float:1.00773E-40)
            java.lang.Object r2 = android.C2491.m601n(r2)
            java.lang.String r2 = (java.lang.String) r2
            r9[r10] = r2
            java.lang.Object r2 = android.C2490.m594n(r7, r8, r9)
            java.lang.Integer r2 = (java.lang.Integer) r2
            int r2 = r2.intValue()
            r7 = 28608(0x6fc0, float:4.0088E-41)
            r8 = 0
            r9 = 4
            java.lang.Object[] r9 = new java.lang.Object[r9]
            r10 = 0
            r9[r10] = r1
            r1 = 1
            r10 = -1749577(0xffffffffffe54db7, float:NaN)
            r10 = r10 & r6
            r6 = r6 ^ -1
            r11 = 1749576(0x1ab248, float:2.451678E-39)
            r6 = r6 & r11
            r6 = r6 | r10
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)
            r9[r1] = r6
            r1 = 2
            r6 = -1747651(0xffffffffffe5553d, float:NaN)
            r6 = r6 & r2
            r2 = r2 ^ -1
            r10 = 1747650(0x1aaac2, float:2.448979E-39)
            r2 = r2 & r10
            r2 = r2 | r6
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            r9[r1] = r2
            r1 = 3
            r2 = -1754901(0xffffffffffe538eb, float:NaN)
            r2 = r2 & r3
            r3 = r3 ^ -1
            r6 = 1754900(0x1ac714, float:2.459139E-39)
            r3 = r3 & r6
            r2 = r2 | r3
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            r9[r1] = r2
            java.lang.Object r1 = android.C2492.m612n(r7, r8, r9)
            java.lang.String r1 = (java.lang.String) r1
            r2 = 50689(0xc601, float:7.103E-41)
        L_0x03c1:
            r3 = 50706(0xc612, float:7.1054E-41)
            r2 = r2 ^ r3
            switch(r2) {
                case 19: goto L_0x03c9;
                case 50: goto L_0x03cd;
                default: goto L_0x03c8;
            }
        L_0x03c8:
            goto L_0x03c1
        L_0x03c9:
            r2 = 50720(0xc620, float:7.1074E-41)
            goto L_0x03c1
        L_0x03cd:
            r2 = r1
            goto L_0x0140
        L_0x03d0:
            byte r7 = r0[r2]
            r1 = 28217(0x6e39, float:3.954E-41)
            r8 = 1
            java.lang.Object[] r8 = new java.lang.Object[r8]
            r9 = 0
            int r10 = r2 % r6
            java.lang.Integer r10 = java.lang.Integer.valueOf(r10)
            r8[r9] = r10
            java.lang.Object r1 = android.C2491.m603n(r1, r4, r8)
            java.lang.Character r1 = (java.lang.Character) r1
            char r1 = r1.charValue()
            r8 = r7 ^ -1
            r8 = r8 & r1
            r1 = r1 ^ -1
            r1 = r1 & r7
            r1 = r1 | r8
            byte r1 = (byte) r1
            byte r1 = (byte) r1
            r0[r2] = r1
            int r1 = r2 + 1
            r2 = 50813(0xc67d, float:7.1204E-41)
        L_0x03fa:
            r7 = 50830(0xc68e, float:7.1228E-41)
            r2 = r2 ^ r7
            switch(r2) {
                case 18: goto L_0x0402;
                case 243: goto L_0x0405;
                default: goto L_0x0401;
            }
        L_0x0401:
            goto L_0x03fa
        L_0x0402:
            r2 = r1
            goto L_0x0184
        L_0x0405:
            r2 = 50844(0xc69c, float:7.1248E-41)
            goto L_0x03fa
        L_0x0409:
            r2 = 93024(0x16b60, float:1.30354E-40)
            r1 = 25614(0x640e, float:3.5893E-41)
            java.lang.Object r1 = android.C2491.m601n(r1)
            java.lang.String r1 = (java.lang.String) r1
            r3 = 0
            java.lang.Object[] r3 = new java.lang.Object[r3]
            java.lang.Object r1 = android.C2491.m603n(r2, r1, r3)
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            int r1 = r1 + 28
            int r1 = r1 + 1
            int r1 = r1 + -28
            r2 = 51588(0xc984, float:7.229E-41)
        L_0x042a:
            r3 = 51605(0xc995, float:7.2314E-41)
            r2 = r2 ^ r3
            switch(r2) {
                case 17: goto L_0x0432;
                case 54: goto L_0x019a;
                default: goto L_0x0431;
            }
        L_0x0431:
            goto L_0x042a
        L_0x0432:
            r2 = 51619(0xc9a3, float:7.2334E-41)
            goto L_0x042a
        L_0x0436:
            r2 = r1
            goto L_0x0140
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p001v4.appcompat.library.C2484.m17383(java.lang.String):java.lang.String");
    }

    /* renamed from: ۟ۢۥۨ۠  reason: not valid java name and contains not printable characters */
    public static String m17384(short[] sArr, int i, int i2, int i3) {
        char[] cArr = new char[i2];
        int i4 = 0;
        while (true) {
            char c = 1616;
            while (true) {
                c ^= 1633;
                switch (c) {
                    case '1':
                        if (i4 < i2) {
                            c = 1709;
                            break;
                        }
                    case 14:
                        c = 1678;
                        break;
                    case 204:
                        short s = sArr[(i - 32) + i4 + 32];
                        cArr[i4] = (char) ((char) ((s & (i3 ^ -1)) | ((s ^ -1) & i3)));
                        i4 = 1 - (0 - i4);
                        char c2 = 1740;
                        while (true) {
                            c2 ^= 1757;
                            switch (c2) {
                                case 17:
                                    c2 = 1771;
                                    break;
                                case '6':
                            }
                        }
                        break;
                    case 239:
                        return new String(cArr);
                }
            }
        }
    }
}
