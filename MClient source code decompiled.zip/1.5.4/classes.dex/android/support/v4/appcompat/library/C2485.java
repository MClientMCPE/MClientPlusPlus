package android.support.p001v4.appcompat.library;

import android.C2490;
import android.C2491;

/* renamed from: android.support.v4.appcompat.library.ۣ۟۟۠ۢ  reason: contains not printable characters */
public class C2485 {

    /* renamed from: ۧۦۣۣ  reason: not valid java name and contains not printable characters */
    public static int f18632 = -91;

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ۟۟ۥۤۧ  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String m17385(java.lang.String r15) {
        /*
            r14 = 25614(0x640e, float:3.5893E-41)
            r13 = 3076(0xc04, float:4.31E-42)
            r12 = 93024(0x16b60, float:1.30354E-40)
            r11 = 1
            r4 = 0
            java.lang.Integer r5 = new java.lang.Integer
            r0 = 4361831(0x428e67, float:6.112227E-39)
            r5.<init>(r0)
            java.lang.Object r0 = android.C2491.m601n(r14)
            java.lang.String r0 = (java.lang.String) r0
            java.lang.Object r1 = android.C2491.m601n(r14)
            java.lang.String r1 = (java.lang.String) r1
            r3 = r4
            r2 = r1
            r1 = r0
        L_0x0020:
            r0 = 1616(0x650, float:2.264E-42)
        L_0x0022:
            r0 = r0 ^ 1633(0x661, float:2.288E-42)
            switch(r0) {
                case 14: goto L_0x0028;
                case 49: goto L_0x002b;
                case 204: goto L_0x0032;
                case 239: goto L_0x00cc;
                default: goto L_0x0027;
            }
        L_0x0027:
            goto L_0x0022
        L_0x0028:
            r0 = 1678(0x68e, float:2.351E-42)
            goto L_0x0022
        L_0x002b:
            r0 = 15
            if (r3 < r0) goto L_0x0028
            r0 = 1709(0x6ad, float:2.395E-42)
            goto L_0x0022
        L_0x0032:
            java.lang.Object[] r0 = new java.lang.Object[r4]
            java.lang.Object r0 = android.C2491.m603n(r12, r15, r0)
            java.lang.Integer r0 = (java.lang.Integer) r0
            int r3 = r0.intValue()
            r6 = 86268(0x150fc, float:1.20887E-40)
            java.lang.Object[] r0 = new java.lang.Object[r11]
            r0[r4] = r5
            r0 = r0[r4]
            java.lang.Integer r0 = (java.lang.Integer) r0
            java.lang.Object[] r5 = new java.lang.Object[r4]
            java.lang.Object r0 = android.C2490.m594n(r6, r0, r5)
            java.lang.Integer r0 = (java.lang.Integer) r0
            int r0 = r0.intValue()
            java.io.ByteArrayOutputStream r5 = new java.io.ByteArrayOutputStream
            r6 = r0 ^ -1
            r7 = 4361829(0x428e65, float:6.112224E-39)
            r6 = r6 & r7
            r7 = -4361830(0xffffffffffbd719a, float:NaN)
            r0 = r0 & r7
            r0 = r0 | r6
            int r0 = r3 / r0
            r5.<init>(r0)
            r3 = r4
        L_0x0068:
            java.lang.Object[] r0 = new java.lang.Object[r4]
            java.lang.Object r0 = android.C2491.m603n(r12, r15, r0)
            java.lang.Integer r0 = (java.lang.Integer) r0
            int r6 = r0.intValue()
            r0 = 1740(0x6cc, float:2.438E-42)
        L_0x0076:
            r0 = r0 ^ 1757(0x6dd, float:2.462E-42)
            switch(r0) {
                case 17: goto L_0x007c;
                case 54: goto L_0x0081;
                case 471: goto L_0x0162;
                case 500: goto L_0x0084;
                default: goto L_0x007b;
            }
        L_0x007b:
            goto L_0x0076
        L_0x007c:
            if (r3 < r6) goto L_0x0081
            r0 = 1833(0x729, float:2.569E-42)
            goto L_0x0076
        L_0x0081:
            r0 = 1802(0x70a, float:2.525E-42)
            goto L_0x0076
        L_0x0084:
            r0 = 82775(0x14357, float:1.15992E-40)
            java.lang.Object[] r1 = new java.lang.Object[r4]
            java.lang.Object r0 = android.C2491.m603n(r0, r5, r1)
            byte[] r0 = (byte[]) r0
            int r5 = r0.length
            java.lang.Object[] r1 = new java.lang.Object[r4]
            java.lang.Object r1 = android.C2491.m603n(r12, r2, r1)
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r6 = r1.intValue()
            r3 = r4
        L_0x009d:
            r1 = 1864(0x748, float:2.612E-42)
        L_0x009f:
            r1 = r1 ^ 1881(0x759, float:2.636E-42)
            switch(r1) {
                case 17: goto L_0x00a5;
                case 47384: goto L_0x01e5;
                case 47417: goto L_0x00af;
                case 47483: goto L_0x00ab;
                default: goto L_0x00a4;
            }
        L_0x00a4:
            goto L_0x009f
        L_0x00a5:
            if (r3 < r5) goto L_0x00ab
            r1 = 48736(0xbe60, float:6.8294E-41)
            goto L_0x009f
        L_0x00ab:
            r1 = 48705(0xbe41, float:6.825E-41)
            goto L_0x009f
        L_0x00af:
            r1 = r4
        L_0x00b0:
            int r3 = r0.length
            r2 = 48767(0xbe7f, float:6.8337E-41)
        L_0x00b4:
            r5 = 48784(0xbe90, float:6.8361E-41)
            r2 = r2 ^ r5
            switch(r2) {
                case 14: goto L_0x00bc;
                case 45: goto L_0x0220;
                case 76: goto L_0x00c6;
                case 239: goto L_0x00c0;
                default: goto L_0x00bb;
            }
        L_0x00bb:
            goto L_0x00b4
        L_0x00bc:
            r2 = 48829(0xbebd, float:6.8424E-41)
            goto L_0x00b4
        L_0x00c0:
            if (r1 < r3) goto L_0x00bc
            r2 = 48860(0xbedc, float:6.8467E-41)
            goto L_0x00b4
        L_0x00c6:
            java.lang.String r1 = new java.lang.String
            r1.<init>(r0)
            return r1
        L_0x00cc:
            r6 = 70144(0x11200, float:9.8293E-41)
            java.lang.StringBuffer r0 = new java.lang.StringBuffer
            r0.<init>()
            java.lang.Object[] r7 = new java.lang.Object[r11]
            r7[r4] = r1
            java.lang.Object r0 = android.C2491.m603n(r13, r0, r7)
            java.lang.StringBuffer r0 = (java.lang.StringBuffer) r0
            java.lang.Object[] r7 = new java.lang.Object[r11]
            r1 = 39014(0x9866, float:5.467E-41)
            r8 = 0
            java.lang.Object[] r9 = new java.lang.Object[r11]
            java.lang.Integer r10 = java.lang.Integer.valueOf(r3)
            r9[r4] = r10
            java.lang.Object r1 = android.C2491.m603n(r1, r8, r9)
            java.lang.String r1 = (java.lang.String) r1
            r7[r4] = r1
            java.lang.Object r0 = android.C2491.m603n(r13, r0, r7)
            java.lang.StringBuffer r0 = (java.lang.StringBuffer) r0
            java.lang.Object[] r1 = new java.lang.Object[r4]
            java.lang.Object r0 = android.C2491.m603n(r6, r0, r1)
            java.lang.String r0 = (java.lang.String) r0
            java.lang.StringBuffer r1 = new java.lang.StringBuffer
            r1.<init>()
            java.lang.Object[] r6 = new java.lang.Object[r11]
            r6[r4] = r2
            java.lang.Object r1 = android.C2491.m603n(r13, r1, r6)
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            r2 = 14369(0x3821, float:2.0135E-41)
            r6 = 0
            java.lang.Object[] r7 = new java.lang.Object[r4]
            java.lang.Object r2 = android.C2491.m603n(r2, r6, r7)
            java.lang.Double r2 = (java.lang.Double) r2
            double r6 = r2.doubleValue()
            r2 = 10
            double r8 = (double) r2
            double r6 = r6 * r8
            int r2 = (int) r6
            r6 = 70144(0x11200, float:9.8293E-41)
            r7 = 49679(0xc20f, float:6.9615E-41)
            java.lang.Object[] r8 = new java.lang.Object[r11]
            r9 = r2 ^ -1
            r9 = r9 & r3
            r10 = r3 ^ -1
            r2 = r2 & r10
            r2 = r2 | r9
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            r8[r4] = r2
            java.lang.Object r1 = android.C2491.m603n(r7, r1, r8)
            java.lang.StringBuffer r1 = (java.lang.StringBuffer) r1
            java.lang.Object[] r2 = new java.lang.Object[r4]
            java.lang.Object r1 = android.C2491.m603n(r6, r1, r2)
            java.lang.String r1 = (java.lang.String) r1
            int r2 = 0 - r3
            int r2 = r2 + -1
            int r2 = 0 - r2
            r3 = 48891(0xbefb, float:6.8511E-41)
        L_0x0151:
            r6 = 48908(0xbf0c, float:6.8535E-41)
            r3 = r3 ^ r6
            switch(r3) {
                case 22: goto L_0x0159;
                case 503: goto L_0x015e;
                default: goto L_0x0158;
            }
        L_0x0158:
            goto L_0x0151
        L_0x0159:
            r3 = r2
            r2 = r1
            r1 = r0
            goto L_0x0020
        L_0x015e:
            r3 = 48922(0xbf1a, float:6.8554E-41)
            goto L_0x0151
        L_0x0162:
            r6 = 33291(0x820b, float:4.665E-41)
            java.lang.Object[] r7 = new java.lang.Object[r11]
            r0 = 28217(0x6e39, float:3.954E-41)
            java.lang.Object[] r8 = new java.lang.Object[r11]
            java.lang.Integer r9 = java.lang.Integer.valueOf(r3)
            r8[r4] = r9
            java.lang.Object r0 = android.C2491.m603n(r0, r15, r8)
            java.lang.Character r0 = (java.lang.Character) r0
            char r0 = r0.charValue()
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)
            r7[r4] = r0
            java.lang.Object r0 = android.C2491.m603n(r6, r1, r7)
            java.lang.Integer r0 = (java.lang.Integer) r0
            int r0 = r0.intValue()
            int r6 = r0 << 4
            r7 = 33291(0x820b, float:4.665E-41)
            java.lang.Object[] r8 = new java.lang.Object[r11]
            r0 = 28217(0x6e39, float:3.954E-41)
            java.lang.Object[] r9 = new java.lang.Object[r11]
            int r10 = r3 + 7
            int r10 = r10 + 1
            int r10 = r10 + -7
            java.lang.Integer r10 = java.lang.Integer.valueOf(r10)
            r9[r4] = r10
            java.lang.Object r0 = android.C2491.m603n(r0, r15, r9)
            java.lang.Character r0 = (java.lang.Character) r0
            char r0 = r0.charValue()
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)
            r8[r4] = r0
            java.lang.Object r0 = android.C2491.m603n(r7, r1, r8)
            java.lang.Integer r0 = (java.lang.Integer) r0
            int r0 = r0.intValue()
            r7 = 3899(0xf3b, float:5.464E-42)
            java.lang.Object[] r8 = new java.lang.Object[r11]
            r9 = r6 ^ r0
            r0 = r0 & r6
            r0 = r0 | r9
            java.lang.Integer r0 = java.lang.Integer.valueOf(r0)
            r8[r4] = r0
            android.C2491.m603n(r7, r5, r8)
            int r0 = r3 + -26
            int r0 = r0 + 2
            int r0 = r0 + 26
            r3 = 49666(0xc202, float:6.9597E-41)
        L_0x01d6:
            r6 = 49683(0xc213, float:6.9621E-41)
            r3 = r3 ^ r6
            switch(r3) {
                case 17: goto L_0x01de;
                case 50: goto L_0x01e2;
                default: goto L_0x01dd;
            }
        L_0x01dd:
            goto L_0x01d6
        L_0x01de:
            r3 = 49697(0xc221, float:6.964E-41)
            goto L_0x01d6
        L_0x01e2:
            r3 = r0
            goto L_0x0068
        L_0x01e5:
            byte r7 = r0[r3]
            r1 = 28217(0x6e39, float:3.954E-41)
            java.lang.Object[] r8 = new java.lang.Object[r11]
            int r9 = r3 % r6
            java.lang.Integer r9 = java.lang.Integer.valueOf(r9)
            r8[r4] = r9
            java.lang.Object r1 = android.C2491.m603n(r1, r2, r8)
            java.lang.Character r1 = (java.lang.Character) r1
            char r1 = r1.charValue()
            r8 = r7 ^ -1
            r8 = r8 & r1
            r1 = r1 ^ -1
            r1 = r1 & r7
            r1 = r1 | r8
            byte r1 = (byte) r1
            byte r1 = (byte) r1
            r0[r3] = r1
            int r1 = r3 + -16
            int r1 = r1 + 1
            int r1 = r1 + 16
            r3 = 49790(0xc27e, float:6.977E-41)
        L_0x0211:
            r7 = 49807(0xc28f, float:6.9794E-41)
            r3 = r3 ^ r7
            switch(r3) {
                case 18: goto L_0x0219;
                case 241: goto L_0x021c;
                default: goto L_0x0218;
            }
        L_0x0218:
            goto L_0x0211
        L_0x0219:
            r3 = r1
            goto L_0x009d
        L_0x021c:
            r3 = 49821(0xc29d, float:6.9814E-41)
            goto L_0x0211
        L_0x0220:
            java.lang.Object r1 = android.C2491.m601n(r14)
            java.lang.String r1 = (java.lang.String) r1
            java.lang.Object[] r2 = new java.lang.Object[r4]
            java.lang.Object r1 = android.C2491.m603n(r12, r1, r2)
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            int r1 = 0 - r1
            int r1 = 1 - r1
            r2 = 49914(0xc2fa, float:6.9944E-41)
        L_0x0239:
            r3 = 49931(0xc30b, float:6.9968E-41)
            r2 = r2 ^ r3
            switch(r2) {
                case 497: goto L_0x0241;
                case 1711: goto L_0x00b0;
                default: goto L_0x0240;
            }
        L_0x0240:
            goto L_0x0239
        L_0x0241:
            r2 = 50596(0xc5a4, float:7.09E-41)
            goto L_0x0239
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p001v4.appcompat.library.C2485.m17385(java.lang.String):java.lang.String");
    }

    /* renamed from: ۣ۟ۤۥ۟  reason: not valid java name and contains not printable characters */
    public static String m17386(short[] sArr, int i, int i2, int i3) {
        char[] cArr = new char[i2];
        int i4 = 0;
        while (true) {
            char c = 1616;
            while (true) {
                c ^= 1633;
                switch (c) {
                    case '1':
                        if (i4 < i2) {
                            c = 1709;
                            break;
                        }
                    case 14:
                        c = 1678;
                        break;
                    case 204:
                        short s = sArr[(i - 25) + i4 + 25];
                        cArr[i4] = (char) ((char) ((s & (i3 ^ -1)) | ((s ^ -1) & i3)));
                        i4 = ((i4 + 8) + 1) - 8;
                        char c2 = 1740;
                        while (true) {
                            c2 ^= 1757;
                            switch (c2) {
                                case 17:
                                    c2 = 1771;
                                    break;
                                case '6':
                            }
                        }
                        break;
                    case 239:
                        return new String(cArr);
                }
            }
        }
    }

    /* renamed from: ۟ۤۢۥ  reason: not valid java name and contains not printable characters */
    public static int m17387() {
        String str = "ۣۥۤ";
        int i = 0;
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        Integer num = null;
        Object[] objArr = null;
        String str2 = null;
        Object obj = null;
        while (true) {
            switch (C2486.m17391((Object) str)) {
                case 56289:
                    objArr[0] = str2;
                    str = "۠ۨ۟";
                    break;
                case 1747652:
                    str = "ۧۦۤ";
                    i = i3 & i4;
                    break;
                case 1747927:
                    obj = C2490.m594n(39369, (Object) null, objArr);
                    str = "ۥۦۨ";
                    break;
                case 1748609:
                    str = "ۣ۠۟";
                    i3 = -1780;
                    break;
                case 1748677:
                    str = "ۨۨ۟";
                    i3 = i4 ^ -1;
                    break;
                case 1748863:
                    str = "۟۠";
                    objArr = new Object[1];
                    break;
                case 1750722:
                    obj = C2491.m601n(58866);
                    str = "ۦۥۡ";
                    break;
                case 1752679:
                    num = obj;
                    str = "ۧۨۨ";
                    break;
                case 1753602:
                    str2 = (String) obj;
                    str = "ۡۧۥ";
                    break;
                case 1754597:
                    str = "ۡۦ۟";
                    i3 = i | i2;
                    break;
                case 1754663:
                    str = "ۡۡۥ";
                    i4 = num.intValue();
                    break;
                case 1755615:
                    str = "ۡ۟۟";
                    i2 = i3 & 1779;
                    break;
                default:
                    return i3;
            }
        }
    }
}
