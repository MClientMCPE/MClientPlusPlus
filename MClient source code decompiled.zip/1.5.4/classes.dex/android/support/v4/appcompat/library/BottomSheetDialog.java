package android.support.p001v4.appcompat.library;

import android.C2490;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import java.io.PrintStream;

/* renamed from: android.support.v4.appcompat.library.BottomSheetDialog */
public class BottomSheetDialog {

    /* renamed from: a */
    private static AlertDialog f621a;
    private static Activity act;
    private static Context con;

    /* renamed from: short  reason: not valid java name */
    private static final short[] f18629short;

    /* renamed from: sp */
    private static SharedPreferences f622sp;

    static {
        int intValue = ((Integer) C2490.m594n(86268, (Integer) new Object[]{new Integer(4429492)}[0], new Object[0])).intValue();
        short[] sArr = new short[((intValue & -4429639) | ((intValue ^ -1) & 4429638))];
        sArr[0] = 3272;
        sArr[1] = 3276;
        sArr[2] = 3270;
        sArr[3] = 3294;
        sArr[4] = 3197;
        sArr[5] = 3174;
        sArr[6] = 3174;
        sArr[7] = 3174;
        sArr[8] = 3174;
        sArr[9] = 3174;
        sArr[10] = 3174;
        sArr[11] = 439;
        sArr[12] = 416;
        sArr[13] = 416;
        sArr[14] = 416;
        sArr[15] = 416;
        sArr[16] = 416;
        sArr[17] = 416;
        sArr[18] = 626;
        sArr[19] = 535;
        sArr[20] = 535;
        sArr[21] = 535;
        sArr[22] = 535;
        sArr[23] = 535;
        sArr[24] = 535;
        sArr[25] = 451;
        sArr[26] = 386;
        sArr[27] = 386;
        sArr[28] = 386;
        sArr[29] = 386;
        sArr[30] = 386;
        sArr[31] = 386;
        sArr[32] = 990;
        sArr[33] = 1005;
        sArr[34] = 1020;
        sArr[35] = 1015;
        sArr[36] = 389;
        sArr[37] = 424;
        sArr[38] = 424;
        sArr[39] = 426;
        sArr[40] = 2022;
        sArr[41] = 2023;
        sArr[42] = 2022;
        sArr[43] = 2023;
        sArr[44] = 2022;
        sArr[45] = 2023;
        sArr[46] = 536;
        sArr[47] = 547;
        sArr[48] = 547;
        sArr[49] = 544;
        sArr[50] = 520;
        sArr[51] = 574;
        sArr[52] = 547;
        sArr[53] = 549;
        sArr[54] = 552;
        sArr[55] = 1903;
        sArr[56] = 1869;
        sArr[57] = 1862;
        sArr[58] = 1862;
        sArr[59] = 1863;
        sArr[60] = 1862;
        sArr[61] = 1794;
        sArr[62] = 1856;
        sArr[63] = 1883;
        sArr[64] = 1794;
        sArr[65] = 1910;
        sArr[66] = 1869;
        sArr[67] = 1869;
        sArr[68] = 1870;
        sArr[69] = 1894;
        sArr[70] = 1872;
        sArr[71] = 1869;
        sArr[72] = 1867;
        sArr[73] = 1862;
        sArr[74] = 1832;
        sArr[75] = 1866;
        sArr[76] = 1878;
        sArr[77] = 1878;
        sArr[78] = 1874;
        sArr[79] = 1873;
        sArr[80] = 1816;
        sArr[81] = 1805;
        sArr[82] = 1883;
        sArr[83] = 1869;
        sArr[84] = 1879;
        sArr[85] = 1878;
        sArr[86] = 1879;
        sArr[87] = 1856;
        sArr[88] = 1863;
        sArr[89] = 1804;
        sArr[90] = 1857;
        sArr[91] = 1869;
        sArr[92] = 1871;
        sArr[93] = 1805;
        sArr[94] = 1910;
        sArr[95] = 1869;
        sArr[96] = 1869;
        sArr[97] = 1870;
        sArr[98] = 1894;
        sArr[99] = 1872;
        sArr[100] = 1869;
        sArr[101] = 1867;
        sArr[102] = 1862;
        sArr[103] = 2998;
        sArr[104] = 2957;
        sArr[105] = 2957;
        sArr[106] = 2958;
        sArr[107] = 2982;
        sArr[108] = 2960;
        sArr[109] = 2957;
        sArr[110] = 2955;
        sArr[111] = 2950;
        sArr[112] = 3010;
        sArr[113] = 2987;
        sArr[114] = 2956;
        sArr[115] = 2948;
        sArr[116] = 2955;
        sArr[117] = 2956;
        sArr[118] = 2955;
        sArr[119] = 2966;
        sArr[120] = 2951;
        sArr[121] = 3010;
        sArr[122] = 2998;
        sArr[123] = 2955;
        sArr[124] = 2959;
        sArr[125] = 2951;
        sArr[126] = 3048;
        sArr[127] = 3048;
        sArr[128] = 11343;
        sArr[129] = 3010;
        sArr[130] = 2989;
        sArr[131] = 2956;
        sArr[132] = 2958;
        sArr[133] = 2971;
        sArr[134] = 3010;
        sArr[135] = 2948;
        sArr[136] = 2957;
        sArr[137] = 2960;
        sArr[138] = 3010;
        sArr[139] = 3028;
        sArr[140] = 3030;
        sArr[141] = 3023;
        sArr[142] = 2944;
        sArr[143] = 2955;
        sArr[144] = 2966;
        sArr[145] = 3010;
        sArr[146] = 2950;
        sArr[147] = 2951;
        sArr[148] = 2964;
        sArr[149] = 2955;
        sArr[150] = 2945;
        sArr[151] = 2951;
        sArr[152] = 2961;
        sArr[153] = 3010;
        sArr[154] = 2965;
        sArr[155] = 2955;
        sArr[156] = 2966;
        sArr[157] = 2954;
        sArr[158] = 3010;
        sArr[159] = 3028;
        sArr[160] = 3030;
        sArr[161] = 3023;
        sArr[162] = 2944;
        sArr[163] = 2955;
        sArr[164] = 2966;
        sArr[165] = 3010;
        sArr[166] = 2991;
        sArr[167] = 2955;
        sArr[168] = 2956;
        sArr[169] = 2951;
        sArr[170] = 2945;
        sArr[171] = 2960;
        sArr[172] = 2947;
        sArr[173] = 2948;
        sArr[174] = 2966;
        sArr[175] = 3010;
        sArr[176] = 2955;
        sArr[177] = 2956;
        sArr[178] = 2961;
        sArr[179] = 2966;
        sArr[180] = 2947;
        sArr[181] = 2958;
        sArr[182] = 2958;
        sArr[183] = 2951;
        sArr[184] = 2950;
        sArr[185] = 3048;
        sArr[186] = 3048;
        sArr[187] = 2998;
        sArr[188] = 2957;
        sArr[189] = 3010;
        sArr[190] = 2947;
        sArr[191] = 2945;
        sArr[192] = 2966;
        sArr[193] = 2955;
        sArr[194] = 2964;
        sArr[195] = 2947;
        sArr[196] = 2966;
        sArr[197] = 2951;
        sArr[198] = 3010;
        sArr[199] = 2987;
        sArr[200] = 2956;
        sArr[201] = 2948;
        sArr[202] = 2955;
        sArr[203] = 2956;
        sArr[204] = 2955;
        sArr[205] = 2966;
        sArr[206] = 2951;
        sArr[207] = 3010;
        sArr[208] = 2998;
        sArr[209] = 2955;
        sArr[210] = 2959;
        sArr[211] = 2951;
        sArr[212] = 3048;
        sArr[213] = 11329;
        sArr[214] = 3010;
        sArr[215] = 2997;
        sArr[216] = 2947;
        sArr[217] = 2955;
        sArr[218] = 2966;
        sArr[219] = 3010;
        sArr[220] = 2948;
        sArr[221] = 2957;
        sArr[222] = 2960;
        sArr[223] = 3010;
        sArr[224] = 2966;
        sArr[225] = 2954;
        sArr[226] = 2951;
        sArr[227] = 3010;
        sArr[228] = 2947;
        sArr[229] = 2962;
        sArr[230] = 2962;
        sArr[231] = 3010;
        sArr[232] = 2966;
        sArr[233] = 2957;
        sArr[234] = 3010;
        sArr[235] = 2948;
        sArr[236] = 2955;
        sArr[237] = 2956;
        sArr[238] = 2955;
        sArr[239] = 2961;
        sArr[240] = 2954;
        sArr[241] = 3010;
        sArr[242] = 2958;
        sArr[243] = 2957;
        sArr[244] = 2947;
        sArr[245] = 2950;
        sArr[246] = 2955;
        sArr[247] = 2956;
        sArr[248] = 2949;
        sArr[249] = 3048;
        sArr[250] = 11329;
        sArr[251] = 3010;
        sArr[252] = 2989;
        sArr[253] = 2962;
        sArr[254] = 2951;
        sArr[255] = 2956;
        sArr[256] = 3010;
        sArr[257] = 2966;
        sArr[258] = 2954;
        sArr[259] = 2951;
        sArr[260] = 3010;
        sArr[261] = 2959;
        sArr[262] = 2951;
        sArr[263] = 2956;
        sArr[264] = 2967;
        sArr[265] = 3010;
        sArr[266] = 2947;
        sArr[267] = 2956;
        sArr[268] = 2950;
        sArr[269] = 3010;
        sArr[270] = 2966;
        sArr[271] = 2947;
        sArr[272] = 2962;
        sArr[273] = 3010;
        sArr[274] = 2957;
        sArr[275] = 2956;
        sArr[276] = 3010;
        sArr[277] = 3008;
        sArr[278] = 2994;
        sArr[279] = 2960;
        sArr[280] = 2951;
        sArr[281] = 2959;
        sArr[282] = 2955;
        sArr[283] = 2967;
        sArr[284] = 2959;
        sArr[285] = 3010;
        sArr[286] = 2951;
        sArr[287] = 2970;
        sArr[288] = 2962;
        sArr[289] = 2955;
        sArr[290] = 2960;
        sArr[291] = 2955;
        sArr[292] = 2956;
        sArr[293] = 2949;
        sArr[294] = 3010;
        sArr[295] = 2955;
        sArr[296] = 2956;
        sArr[297] = 3010;
        sArr[298] = 3023;
        sArr[299] = 3023;
        sArr[300] = 3032;
        sArr[301] = 3023;
        sArr[302] = 3023;
        sArr[303] = 3008;
        sArr[304] = 3048;
        sArr[305] = 11329;
        sArr[306] = 3010;
        sArr[307] = 2983;
        sArr[308] = 2988;
        sArr[309] = 2984;
        sArr[310] = 2989;
        sArr[311] = 3003;
        sArr[312] = 3048;
        sArr[313] = 3048;
        sArr[314] = 3048;
        sArr[315] = 2977;
        sArr[316] = 2947;
        sArr[317] = 2967;
        sArr[318] = 2966;
        sArr[319] = 2955;
        sArr[320] = 2957;
        sArr[321] = 2956;
        sArr[322] = 3032;
        sArr[323] = 3010;
        sArr[324] = 2982;
        sArr[325] = 2957;
        sArr[326] = 3010;
        sArr[327] = 2956;
        sArr[328] = 2957;
        sArr[329] = 2966;
        sArr[330] = 3010;
        sArr[331] = 2950;
        sArr[332] = 2957;
        sArr[333] = 3010;
        sArr[334] = 2947;
        sArr[335] = 2956;
        sArr[336] = 2971;
        sArr[337] = 2966;
        sArr[338] = 2954;
        sArr[339] = 2955;
        sArr[340] = 2956;
        sArr[341] = 2949;
        sArr[342] = 3010;
        sArr[343] = 2967;
        sArr[344] = 2956;
        sArr[345] = 2966;
        sArr[346] = 2955;
        sArr[347] = 2958;
        sArr[348] = 3010;
        sArr[349] = 2966;
        sArr[350] = 2954;
        sArr[351] = 2951;
        sArr[352] = 3010;
        sArr[353] = 2991;
        sArr[354] = 2955;
        sArr[355] = 2956;
        sArr[356] = 2951;
        sArr[357] = 2945;
        sArr[358] = 2960;
        sArr[359] = 2947;
        sArr[360] = 2948;
        sArr[361] = 2966;
        sArr[362] = 3010;
        sArr[363] = 2961;
        sArr[364] = 2945;
        sArr[365] = 2960;
        sArr[366] = 2951;
        sArr[367] = 2951;
        sArr[368] = 2956;
        sArr[369] = 3010;
        sArr[370] = 2961;
        sArr[371] = 2954;
        sArr[372] = 2957;
        sArr[373] = 2965;
        sArr[374] = 2961;
        sArr[375] = 3010;
        sArr[376] = 2957;
        sArr[377] = 2960;
        sArr[378] = 3010;
        sArr[379] = 2962;
        sArr[380] = 2960;
        sArr[381] = 2951;
        sArr[382] = 2959;
        sArr[383] = 2955;
        sArr[384] = 2967;
        sArr[385] = 2959;
        sArr[386] = 3010;
        sArr[387] = 2965;
        sArr[388] = 2955;
        sArr[389] = 2958;
        sArr[390] = 2958;
        sArr[391] = 3010;
        sArr[392] = 2956;
        sArr[393] = 2957;
        sArr[394] = 2966;
        sArr[395] = 3010;
        sArr[396] = 2965;
        sArr[397] = 2957;
        sArr[398] = 2960;
        sArr[399] = 2953;
        sArr[400] = 3048;
        sArr[401] = 3048;
        sArr[402] = 2981;
        sArr[403] = 2955;
        sArr[404] = 2964;
        sArr[405] = 2951;
        sArr[406] = 3010;
        sArr[407] = 2955;
        sArr[408] = 2966;
        sArr[409] = 2951;
        sArr[410] = 2959;
        sArr[411] = 3010;
        sArr[412] = 2955;
        sArr[413] = 2961;
        sArr[414] = 3010;
        sArr[415] = 2944;
        sArr[416] = 2960;
        sArr[417] = 2957;
        sArr[418] = 2953;
        sArr[419] = 2951;
        sArr[420] = 2956;
        sArr[421] = 3010;
        sArr[422] = 2944;
        sArr[423] = 2967;
        sArr[424] = 2966;
        sArr[425] = 3010;
        sArr[426] = 2961;
        sArr[427] = 2966;
        sArr[428] = 2955;
        sArr[429] = 2958;
        sArr[430] = 2958;
        sArr[431] = 3010;
        sArr[432] = 2965;
        sArr[433] = 2957;
        sArr[434] = 2960;
        sArr[435] = 2953;
        sArr[436] = 2961;
        sArr[437] = 3048;
        sArr[438] = 2979;
        sArr[439] = 3010;
        sArr[440] = 2958;
        sArr[441] = 2957;
        sArr[442] = 2966;
        sArr[443] = 3010;
        sArr[444] = 2957;
        sArr[445] = 2948;
        sArr[446] = 3010;
        sArr[447] = 2961;
        sArr[448] = 2966;
        sArr[449] = 2967;
        sArr[450] = 2948;
        sArr[451] = 2948;
        sArr[452] = 3010;
        sArr[453] = 2955;
        sArr[454] = 2961;
        sArr[455] = 3010;
        sArr[456] = 2944;
        sArr[457] = 2960;
        sArr[458] = 2957;
        sArr[459] = 2953;
        sArr[460] = 2951;
        sArr[461] = 2956;
        sArr[462] = 3010;
        sArr[463] = 2955;
        sArr[464] = 2956;
        sArr[465] = 3010;
        sArr[466] = 2966;
        sArr[467] = 2954;
        sArr[468] = 2955;
        sArr[469] = 2961;
        sArr[470] = 3010;
        sArr[471] = 2967;
        sArr[472] = 2962;
        sArr[473] = 2950;
        sArr[474] = 2947;
        sArr[475] = 2966;
        sArr[476] = 2951;
        sArr[477] = 3048;
        sArr[478] = 2983;
        sArr[479] = 2956;
        sArr[480] = 2945;
        sArr[481] = 2954;
        sArr[482] = 2947;
        sArr[483] = 2956;
        sArr[484] = 2966;
        sArr[485] = 3010;
        sArr[486] = 2959;
        sArr[487] = 2947;
        sArr[488] = 2971;
        sArr[489] = 3010;
        sArr[490] = 2945;
        sArr[491] = 2960;
        sArr[492] = 2947;
        sArr[493] = 2961;
        sArr[494] = 2954;
        sArr[495] = 3048;
        sArr[496] = 3032;
        sArr[497] = 3019;
        f18629short = sArr;
    }

    public BottomSheetDialog() {
        int intValue = ((Integer) C2490.m594n(56008, (Object) null, new Object[0])).intValue();
        char c = 1616;
        while (true) {
            c ^= 1633;
            switch (c) {
                case '1':
                    if (intValue <= 0) {
                        c = 1709;
                        break;
                    }
                case 14:
                    c = 1678;
                    break;
                case 204:
                    C2490.m594n(46274, (PrintStream) C2490.m592n(3740), new Object[]{Double.valueOf(((Double) C2490.m594n(94672, (Object) null, new Object[]{(String) C2490.m594n(50197, (Object) null, new Object[]{(String) C2490.m592n(32208)})})).doubleValue())});
                    return;
                case 239:
                    return;
            }
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v16, resolved type: java.lang.Object[]} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static void MessageBox(java.lang.String r20, java.lang.String r21) {
        /*
            r1 = 13
            java.lang.Object[] r4 = new java.lang.Object[r1]
            r1 = 4
            java.lang.Integer r2 = new java.lang.Integer
            r3 = 4830031(0x49b34f, float:6.768315E-39)
            r2.<init>(r3)
            r4[r1] = r2
            r1 = 12
            java.lang.Integer r2 = new java.lang.Integer
            r3 = 4889346(0x4a9b02, float:6.851433E-39)
            r2.<init>(r3)
            r4[r1] = r2
            r1 = 0
            java.lang.Integer r2 = new java.lang.Integer
            r3 = 1598119(0x1862a7, float:2.239442E-39)
            r2.<init>(r3)
            r4[r1] = r2
            r1 = 10
            java.lang.Integer r2 = new java.lang.Integer
            r3 = 1771679(0x1b089f, float:2.482651E-39)
            r2.<init>(r3)
            r4[r1] = r2
            r1 = 6
            java.lang.Integer r2 = new java.lang.Integer
            r3 = 8289693(0x7e7d9d, float:1.1616334E-38)
            r2.<init>(r3)
            r4[r1] = r2
            r1 = 1
            java.lang.Integer r2 = new java.lang.Integer
            r3 = 5795185(0x586d71, float:8.120784E-39)
            r2.<init>(r3)
            r4[r1] = r2
            r1 = 2
            java.lang.Integer r2 = new java.lang.Integer
            r3 = 723712(0xb0b00, float:1.014137E-39)
            r2.<init>(r3)
            r4[r1] = r2
            r1 = 9
            java.lang.Integer r2 = new java.lang.Integer
            r3 = 8013318(0x7a4606, float:1.122905E-38)
            r2.<init>(r3)
            r4[r1] = r2
            r1 = 7
            java.lang.Float r2 = new java.lang.Float
            r3 = 1101004800(0x41a00000, float:20.0)
            r2.<init>(r3)
            r4[r1] = r2
            r1 = 11
            java.lang.Float r2 = new java.lang.Float
            r3 = 1059481190(0x3f266666, float:0.65)
            r2.<init>(r3)
            r4[r1] = r2
            r1 = 3
            java.lang.Integer r2 = new java.lang.Integer
            r3 = 2474880(0x25c380, float:3.468046E-39)
            r2.<init>(r3)
            r4[r1] = r2
            r1 = 5
            java.lang.Integer r2 = new java.lang.Integer
            r3 = 2187845(0x216245, float:3.065824E-39)
            r2.<init>(r3)
            r4[r1] = r2
            r1 = 8
            java.lang.Integer r2 = new java.lang.Integer
            r3 = -6730311(0xffffffffff994db9, float:NaN)
            r2.<init>(r3)
            r4[r1] = r2
            r2 = 86268(0x150fc, float:1.20887E-40)
            r1 = 4
            r1 = r4[r1]
            java.lang.Integer r1 = (java.lang.Integer) r1
            r3 = 0
            java.lang.Object[] r3 = new java.lang.Object[r3]
            java.lang.Object r1 = android.C2490.m594n(r2, r1, r3)
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r2 = r1 ^ -1
            r3 = 4830027(0x49b34b, float:6.76831E-39)
            r2 = r2 & r3
            r3 = -4830028(0xffffffffffb64cb4, float:NaN)
            r1 = r1 & r3
            r5 = r2 | r1
            android.app.AlertDialog$Builder r2 = new android.app.AlertDialog$Builder     // Catch:{ Exception -> 0x079d }
            r1 = 71611(0x117bb, float:1.00348E-40)
            java.lang.Object r1 = android.C2490.m592n(r1)     // Catch:{ Exception -> 0x079d }
            android.content.Context r1 = (android.content.Context) r1     // Catch:{ Exception -> 0x079d }
            r2.<init>(r1, r5)     // Catch:{ Exception -> 0x079d }
            r1 = 11012(0x2b04, float:1.5431E-41)
            r3 = 0
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x079d }
            java.lang.Object r1 = android.C2490.m594n(r1, r2, r3)     // Catch:{ Exception -> 0x079d }
            android.app.AlertDialog r1 = (android.app.AlertDialog) r1     // Catch:{ Exception -> 0x079d }
            f621a = r1     // Catch:{ Exception -> 0x079d }
            r2 = 27228(0x6a5c, float:3.8155E-41)
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x079d }
            r6 = 0
            r3[r6] = r20     // Catch:{ Exception -> 0x079d }
            android.C2490.m594n(r2, r1, r3)     // Catch:{ Exception -> 0x079d }
            r2 = 74432(0x122c0, float:1.04301E-40)
            r1 = 90810(0x162ba, float:1.27252E-40)
            java.lang.Object r1 = android.C2490.m592n(r1)     // Catch:{ Exception -> 0x079d }
            android.app.AlertDialog r1 = (android.app.AlertDialog) r1     // Catch:{ Exception -> 0x079d }
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x079d }
            r6 = 0
            r3[r6] = r21     // Catch:{ Exception -> 0x079d }
            android.C2490.m594n(r2, r1, r3)     // Catch:{ Exception -> 0x079d }
            r1 = 90810(0x162ba, float:1.27252E-40)
            java.lang.Object r1 = android.C2490.m592n(r1)     // Catch:{ Exception -> 0x079d }
            android.app.AlertDialog r1 = (android.app.AlertDialog) r1     // Catch:{ Exception -> 0x079d }
            r2 = 30899(0x78b3, float:4.3299E-41)
            java.lang.Object r2 = android.C2490.m592n(r2)     // Catch:{ Exception -> 0x079d }
            short[] r2 = (short[]) r2     // Catch:{ Exception -> 0x079d }
            r6 = 39369(0x99c9, float:5.5168E-41)
            r7 = 0
            r3 = 1
            java.lang.Object[] r8 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x079d }
            r9 = 0
            r3 = 97524(0x17cf4, float:1.3666E-40)
            java.lang.Object r3 = android.C2490.m592n(r3)     // Catch:{ Exception -> 0x079d }
            java.lang.String r3 = (java.lang.String) r3     // Catch:{ Exception -> 0x079d }
            r8[r9] = r3     // Catch:{ Exception -> 0x079d }
            java.lang.Object r3 = android.C2490.m594n(r6, r7, r8)     // Catch:{ Exception -> 0x079d }
            java.lang.Integer r3 = (java.lang.Integer) r3     // Catch:{ Exception -> 0x079d }
            int r6 = r3.intValue()     // Catch:{ Exception -> 0x079d }
            r7 = 39369(0x99c9, float:5.5168E-41)
            r8 = 0
            r3 = 1
            java.lang.Object[] r9 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x079d }
            r10 = 0
            r3 = 52800(0xce40, float:7.3989E-41)
            java.lang.Object r3 = android.C2490.m592n(r3)     // Catch:{ Exception -> 0x079d }
            java.lang.String r3 = (java.lang.String) r3     // Catch:{ Exception -> 0x079d }
            r9[r10] = r3     // Catch:{ Exception -> 0x079d }
            java.lang.Object r3 = android.C2490.m594n(r7, r8, r9)     // Catch:{ Exception -> 0x079d }
            java.lang.Integer r3 = (java.lang.Integer) r3     // Catch:{ Exception -> 0x079d }
            int r7 = r3.intValue()     // Catch:{ Exception -> 0x079d }
            r8 = 39369(0x99c9, float:5.5168E-41)
            r9 = 0
            r3 = 1
            java.lang.Object[] r10 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x079d }
            r11 = 0
            r3 = 86656(0x15280, float:1.21431E-40)
            java.lang.Object r3 = android.C2490.m592n(r3)     // Catch:{ Exception -> 0x079d }
            java.lang.String r3 = (java.lang.String) r3     // Catch:{ Exception -> 0x079d }
            r10[r11] = r3     // Catch:{ Exception -> 0x079d }
            java.lang.Object r3 = android.C2490.m594n(r8, r9, r10)     // Catch:{ Exception -> 0x079d }
            java.lang.Integer r3 = (java.lang.Integer) r3     // Catch:{ Exception -> 0x079d }
            int r3 = r3.intValue()     // Catch:{ Exception -> 0x079d }
            r8 = 80494(0x13a6e, float:1.12796E-40)
            r9 = 0
            r10 = 4
            java.lang.Object[] r10 = new java.lang.Object[r10]     // Catch:{ Exception -> 0x079d }
            r11 = 0
            r10[r11] = r2     // Catch:{ Exception -> 0x079d }
            r2 = 1
            r11 = -1753514(0xffffffffffe53e56, float:NaN)
            r11 = r11 & r7
            r7 = r7 ^ -1
            r12 = 1753513(0x1ac1a9, float:2.457195E-39)
            r7 = r7 & r12
            r7 = r7 | r11
            java.lang.Integer r7 = java.lang.Integer.valueOf(r7)     // Catch:{ Exception -> 0x079d }
            r10[r2] = r7     // Catch:{ Exception -> 0x079d }
            r2 = 2
            r7 = -1749670(0xffffffffffe54d5a, float:NaN)
            r7 = r7 & r3
            r3 = r3 ^ -1
            r11 = 1749669(0x1ab2a5, float:2.451808E-39)
            r3 = r3 & r11
            r3 = r3 | r7
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)     // Catch:{ Exception -> 0x079d }
            r10[r2] = r3     // Catch:{ Exception -> 0x079d }
            r2 = 3
            r3 = -1752996(0xffffffffffe5405c, float:NaN)
            r3 = r3 & r6
            r6 = r6 ^ -1
            r7 = 1752995(0x1abfa3, float:2.456469E-39)
            r6 = r6 & r7
            r3 = r3 | r6
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)     // Catch:{ Exception -> 0x079d }
            r10[r2] = r3     // Catch:{ Exception -> 0x079d }
            java.lang.Object r2 = android.C2490.m594n(r8, r9, r10)     // Catch:{ Exception -> 0x079d }
            java.lang.String r2 = (java.lang.String) r2     // Catch:{ Exception -> 0x079d }
            android.support.v4.appcompat.library.BottomSheetDialog$1 r3 = new android.support.v4.appcompat.library.BottomSheetDialog$1     // Catch:{ Exception -> 0x079d }
            r3.<init>()     // Catch:{ Exception -> 0x079d }
            r6 = 40524(0x9e4c, float:5.6786E-41)
            r7 = 2
            java.lang.Object[] r7 = new java.lang.Object[r7]     // Catch:{ Exception -> 0x079d }
            r8 = 0
            r7[r8] = r2     // Catch:{ Exception -> 0x079d }
            r2 = 1
            r7[r2] = r3     // Catch:{ Exception -> 0x079d }
            android.C2490.m594n(r6, r1, r7)     // Catch:{ Exception -> 0x079d }
            r2 = 47301(0xb8c5, float:6.6283E-41)
            r1 = 90810(0x162ba, float:1.27252E-40)
            java.lang.Object r1 = android.C2490.m592n(r1)     // Catch:{ Exception -> 0x079d }
            android.app.AlertDialog r1 = (android.app.AlertDialog) r1     // Catch:{ Exception -> 0x079d }
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x079d }
            r6 = 0
            r7 = 0
            java.lang.Boolean r7 = java.lang.Boolean.valueOf(r7)     // Catch:{ Exception -> 0x079d }
            r3[r6] = r7     // Catch:{ Exception -> 0x079d }
            android.C2490.m594n(r2, r1, r3)     // Catch:{ Exception -> 0x079d }
        L_0x01cf:
            r2 = 24557(0x5fed, float:3.4412E-41)
            r1 = 90810(0x162ba, float:1.27252E-40)
            java.lang.Object r1 = android.C2490.m592n(r1)     // Catch:{ Exception -> 0x07a9 }
            android.app.AlertDialog r1 = (android.app.AlertDialog) r1     // Catch:{ Exception -> 0x07a9 }
            r3 = 0
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r1 = android.C2490.m594n(r2, r1, r3)     // Catch:{ Exception -> 0x07a9 }
            r0 = r1
            android.view.Window r0 = (android.view.Window) r0     // Catch:{ Exception -> 0x07a9 }
            r3 = r0
            r2 = 86268(0x150fc, float:1.20887E-40)
            r1 = 12
            r1 = r4[r1]     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch:{ Exception -> 0x07a9 }
            r6 = 0
            java.lang.Object[] r6 = new java.lang.Object[r6]     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r1 = android.C2490.m594n(r2, r1, r6)     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch:{ Exception -> 0x07a9 }
            int r1 = r1.intValue()     // Catch:{ Exception -> 0x07a9 }
            r2 = r1 ^ -1
            r6 = 4889344(0x4a9b00, float:6.85143E-39)
            r2 = r2 & r6
            r6 = -4889345(0xffffffffffb564ff, float:NaN)
            r1 = r1 & r6
            r6 = r2 | r1
            int[] r7 = new int[r6]     // Catch:{ Exception -> 0x07a9 }
            r1 = 30899(0x78b3, float:4.3299E-41)
            java.lang.Object r1 = android.C2490.m592n(r1)     // Catch:{ Exception -> 0x07a9 }
            short[] r1 = (short[]) r1     // Catch:{ Exception -> 0x07a9 }
            r8 = 39369(0x99c9, float:5.5168E-41)
            r9 = 0
            r2 = 1
            java.lang.Object[] r10 = new java.lang.Object[r2]     // Catch:{ Exception -> 0x07a9 }
            r11 = 0
            r2 = 59714(0xe942, float:8.3677E-41)
            java.lang.Object r2 = android.C2490.m592n(r2)     // Catch:{ Exception -> 0x07a9 }
            java.lang.String r2 = (java.lang.String) r2     // Catch:{ Exception -> 0x07a9 }
            r10[r11] = r2     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r2 = android.C2490.m594n(r8, r9, r10)     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r2 = (java.lang.Integer) r2     // Catch:{ Exception -> 0x07a9 }
            int r8 = r2.intValue()     // Catch:{ Exception -> 0x07a9 }
            r9 = 39369(0x99c9, float:5.5168E-41)
            r10 = 0
            r2 = 1
            java.lang.Object[] r11 = new java.lang.Object[r2]     // Catch:{ Exception -> 0x07a9 }
            r12 = 0
            r2 = 81469(0x13e3d, float:1.14162E-40)
            java.lang.Object r2 = android.C2490.m592n(r2)     // Catch:{ Exception -> 0x07a9 }
            java.lang.String r2 = (java.lang.String) r2     // Catch:{ Exception -> 0x07a9 }
            r11[r12] = r2     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r2 = android.C2490.m594n(r9, r10, r11)     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r2 = (java.lang.Integer) r2     // Catch:{ Exception -> 0x07a9 }
            int r9 = r2.intValue()     // Catch:{ Exception -> 0x07a9 }
            r10 = 39369(0x99c9, float:5.5168E-41)
            r11 = 0
            r2 = 1
            java.lang.Object[] r12 = new java.lang.Object[r2]     // Catch:{ Exception -> 0x07a9 }
            r13 = 0
            r2 = 65421(0xff8d, float:9.1674E-41)
            java.lang.Object r2 = android.C2490.m592n(r2)     // Catch:{ Exception -> 0x07a9 }
            java.lang.String r2 = (java.lang.String) r2     // Catch:{ Exception -> 0x07a9 }
            r12[r13] = r2     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r2 = android.C2490.m594n(r10, r11, r12)     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r2 = (java.lang.Integer) r2     // Catch:{ Exception -> 0x07a9 }
            int r2 = r2.intValue()     // Catch:{ Exception -> 0x07a9 }
            r10 = 0
            r11 = 57290(0xdfca, float:8.028E-41)
            r12 = 0
            r13 = 1
            java.lang.Object[] r13 = new java.lang.Object[r13]     // Catch:{ Exception -> 0x07a9 }
            r14 = 0
            r15 = 80494(0x13a6e, float:1.12796E-40)
            r16 = 0
            r17 = 4
            r0 = r17
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch:{ Exception -> 0x07a9 }
            r17 = r0
            r18 = 0
            r17[r18] = r1     // Catch:{ Exception -> 0x07a9 }
            r1 = 1
            r18 = -56328(0xffffffffffff23f8, float:NaN)
            r18 = r18 & r9
            r9 = r9 ^ -1
            r19 = 56327(0xdc07, float:7.8931E-41)
            r9 = r9 & r19
            r9 = r9 | r18
            java.lang.Integer r9 = java.lang.Integer.valueOf(r9)     // Catch:{ Exception -> 0x07a9 }
            r17[r1] = r9     // Catch:{ Exception -> 0x07a9 }
            r1 = 2
            r9 = -1751770(0xffffffffffe54526, float:NaN)
            r9 = r9 & r2
            r2 = r2 ^ -1
            r18 = 1751769(0x1abad9, float:2.454751E-39)
            r2 = r2 & r18
            r2 = r2 | r9
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)     // Catch:{ Exception -> 0x07a9 }
            r17[r1] = r2     // Catch:{ Exception -> 0x07a9 }
            r1 = 3
            r2 = -1747806(0xffffffffffe554a2, float:NaN)
            r2 = r2 & r8
            r8 = r8 ^ -1
            r9 = 1747805(0x1aab5d, float:2.449196E-39)
            r8 = r8 & r9
            r2 = r2 | r8
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)     // Catch:{ Exception -> 0x07a9 }
            r17[r1] = r2     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r1 = android.C2490.m594n(r15, r16, r17)     // Catch:{ Exception -> 0x07a9 }
            java.lang.String r1 = (java.lang.String) r1     // Catch:{ Exception -> 0x07a9 }
            r13[r14] = r1     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r1 = android.C2490.m594n(r11, r12, r13)     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch:{ Exception -> 0x07a9 }
            int r1 = r1.intValue()     // Catch:{ Exception -> 0x07a9 }
            r7[r10] = r1     // Catch:{ Exception -> 0x07a9 }
            r1 = 30899(0x78b3, float:4.3299E-41)
            java.lang.Object r1 = android.C2490.m592n(r1)     // Catch:{ Exception -> 0x07a9 }
            short[] r1 = (short[]) r1     // Catch:{ Exception -> 0x07a9 }
            r8 = 39369(0x99c9, float:5.5168E-41)
            r9 = 0
            r2 = 1
            java.lang.Object[] r10 = new java.lang.Object[r2]     // Catch:{ Exception -> 0x07a9 }
            r11 = 0
            r2 = 93736(0x16e28, float:1.31352E-40)
            java.lang.Object r2 = android.C2490.m592n(r2)     // Catch:{ Exception -> 0x07a9 }
            java.lang.String r2 = (java.lang.String) r2     // Catch:{ Exception -> 0x07a9 }
            r10[r11] = r2     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r2 = android.C2490.m594n(r8, r9, r10)     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r2 = (java.lang.Integer) r2     // Catch:{ Exception -> 0x07a9 }
            int r8 = r2.intValue()     // Catch:{ Exception -> 0x07a9 }
            r9 = 39369(0x99c9, float:5.5168E-41)
            r10 = 0
            r2 = 1
            java.lang.Object[] r11 = new java.lang.Object[r2]     // Catch:{ Exception -> 0x07a9 }
            r12 = 0
            r2 = 15189(0x3b55, float:2.1284E-41)
            java.lang.Object r2 = android.C2490.m592n(r2)     // Catch:{ Exception -> 0x07a9 }
            java.lang.String r2 = (java.lang.String) r2     // Catch:{ Exception -> 0x07a9 }
            r11[r12] = r2     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r2 = android.C2490.m594n(r9, r10, r11)     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r2 = (java.lang.Integer) r2     // Catch:{ Exception -> 0x07a9 }
            int r9 = r2.intValue()     // Catch:{ Exception -> 0x07a9 }
            r10 = 39369(0x99c9, float:5.5168E-41)
            r11 = 0
            r2 = 1
            java.lang.Object[] r12 = new java.lang.Object[r2]     // Catch:{ Exception -> 0x07a9 }
            r13 = 0
            r2 = 71929(0x118f9, float:1.00794E-40)
            java.lang.Object r2 = android.C2490.m592n(r2)     // Catch:{ Exception -> 0x07a9 }
            java.lang.String r2 = (java.lang.String) r2     // Catch:{ Exception -> 0x07a9 }
            r12[r13] = r2     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r2 = android.C2490.m594n(r10, r11, r12)     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r2 = (java.lang.Integer) r2     // Catch:{ Exception -> 0x07a9 }
            int r2 = r2.intValue()     // Catch:{ Exception -> 0x07a9 }
            r10 = 57290(0xdfca, float:8.028E-41)
            r11 = 0
            r12 = 1
            java.lang.Object[] r12 = new java.lang.Object[r12]     // Catch:{ Exception -> 0x07a9 }
            r13 = 0
            r14 = 96419(0x178a3, float:1.35112E-40)
            r15 = 0
            r16 = 4
            r0 = r16
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch:{ Exception -> 0x07a9 }
            r16 = r0
            r17 = 0
            r16[r17] = r1     // Catch:{ Exception -> 0x07a9 }
            r1 = 1
            r17 = -1750660(0xffffffffffe5497c, float:NaN)
            r17 = r17 & r9
            r9 = r9 ^ -1
            r18 = 1750659(0x1ab683, float:2.453196E-39)
            r9 = r9 & r18
            r9 = r9 | r17
            java.lang.Integer r9 = java.lang.Integer.valueOf(r9)     // Catch:{ Exception -> 0x07a9 }
            r16[r1] = r9     // Catch:{ Exception -> 0x07a9 }
            r1 = 2
            r9 = -1751523(0xffffffffffe5461d, float:NaN)
            r9 = r9 & r2
            r2 = r2 ^ -1
            r17 = 1751522(0x1ab9e2, float:2.454405E-39)
            r2 = r2 & r17
            r2 = r2 | r9
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)     // Catch:{ Exception -> 0x07a9 }
            r16[r1] = r2     // Catch:{ Exception -> 0x07a9 }
            r1 = 3
            r2 = -1755222(0xffffffffffe537aa, float:NaN)
            r2 = r2 & r8
            r8 = r8 ^ -1
            r9 = 1755221(0x1ac855, float:2.459588E-39)
            r8 = r8 & r9
            r2 = r2 | r8
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)     // Catch:{ Exception -> 0x07a9 }
            r16[r1] = r2     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r1 = android.C2490.m594n(r14, r15, r16)     // Catch:{ Exception -> 0x07a9 }
            java.lang.String r1 = (java.lang.String) r1     // Catch:{ Exception -> 0x07a9 }
            r12[r13] = r1     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r1 = android.C2490.m594n(r10, r11, r12)     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch:{ Exception -> 0x07a9 }
            int r2 = r1.intValue()     // Catch:{ Exception -> 0x07a9 }
            r8 = 86268(0x150fc, float:1.20887E-40)
            r1 = 0
            r1 = r4[r1]     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch:{ Exception -> 0x07a9 }
            r9 = 0
            java.lang.Object[] r9 = new java.lang.Object[r9]     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r1 = android.C2490.m594n(r8, r1, r9)     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch:{ Exception -> 0x07a9 }
            int r1 = r1.intValue()     // Catch:{ Exception -> 0x07a9 }
            r8 = r1 ^ -1
            r9 = 1598118(0x1862a6, float:2.23944E-39)
            r8 = r8 & r9
            r9 = -1598119(0xffffffffffe79d59, float:NaN)
            r1 = r1 & r9
            r8 = r8 | r1
            r7[r8] = r2
            android.graphics.drawable.GradientDrawable r9 = new android.graphics.drawable.GradientDrawable     // Catch:{ Exception -> 0x07a9 }
            r1 = 62364(0xf39c, float:8.739E-41)
            java.lang.Object r1 = android.C2490.m592n(r1)     // Catch:{ Exception -> 0x07a9 }
            android.graphics.drawable.GradientDrawable$Orientation r1 = (android.graphics.drawable.GradientDrawable.Orientation) r1     // Catch:{ Exception -> 0x07a9 }
            r9.<init>(r1, r7)     // Catch:{ Exception -> 0x07a9 }
            r2 = 86268(0x150fc, float:1.20887E-40)
            r1 = 10
            r1 = r4[r1]     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch:{ Exception -> 0x07a9 }
            r7 = 0
            java.lang.Object[] r7 = new java.lang.Object[r7]     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r1 = android.C2490.m594n(r2, r1, r7)     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch:{ Exception -> 0x07a9 }
            int r1 = r1.intValue()     // Catch:{ Exception -> 0x07a9 }
            r2 = r1 ^ -1
            r7 = 1771671(0x1b0897, float:2.48264E-39)
            r2 = r2 & r7
            r7 = -1771672(0xffffffffffe4f768, float:NaN)
            r1 = r1 & r7
            r1 = r1 | r2
            float[] r2 = new float[r1]     // Catch:{ Exception -> 0x07a9 }
            r1 = 0
            r7 = 1102053376(0x41b00000, float:22.0)
            r2[r1] = r7
            r1 = 1102053376(0x41b00000, float:22.0)
            r2[r8] = r1
            r1 = 1102053376(0x41b00000, float:22.0)
            r2[r6] = r1
            r6 = 86268(0x150fc, float:1.20887E-40)
            r1 = 6
            r1 = r4[r1]     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch:{ Exception -> 0x07a9 }
            r7 = 0
            java.lang.Object[] r7 = new java.lang.Object[r7]     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r1 = android.C2490.m594n(r6, r1, r7)     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch:{ Exception -> 0x07a9 }
            int r1 = r1.intValue()     // Catch:{ Exception -> 0x07a9 }
            r6 = r1 ^ -1
            r7 = 8289694(0x7e7d9e, float:1.1616335E-38)
            r6 = r6 & r7
            r7 = -8289695(0xffffffffff818261, float:NaN)
            r1 = r1 & r7
            r6 = r6 | r1
            r1 = 1102053376(0x41b00000, float:22.0)
            r2[r6] = r1
            r1 = 1102053376(0x41b00000, float:22.0)
            r2[r5] = r1
            r5 = 86268(0x150fc, float:1.20887E-40)
            r1 = 1
            r1 = r4[r1]     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch:{ Exception -> 0x07a9 }
            r7 = 0
            java.lang.Object[] r7 = new java.lang.Object[r7]     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r1 = android.C2490.m594n(r5, r1, r7)     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch:{ Exception -> 0x07a9 }
            int r1 = r1.intValue()     // Catch:{ Exception -> 0x07a9 }
            r5 = r1 ^ -1
            r7 = 5795188(0x586d74, float:8.120788E-39)
            r5 = r5 & r7
            r7 = -5795189(0xffffffffffa7928b, float:NaN)
            r1 = r1 & r7
            r1 = r1 | r5
            r5 = 1102053376(0x41b00000, float:22.0)
            r2[r1] = r5
            r5 = 86268(0x150fc, float:1.20887E-40)
            r1 = 2
            r1 = r4[r1]     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch:{ Exception -> 0x07a9 }
            r7 = 0
            java.lang.Object[] r7 = new java.lang.Object[r7]     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r1 = android.C2490.m594n(r5, r1, r7)     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch:{ Exception -> 0x07a9 }
            int r1 = r1.intValue()     // Catch:{ Exception -> 0x07a9 }
            r5 = r1 ^ -1
            r7 = 723718(0xb0b06, float:1.014145E-39)
            r5 = r5 & r7
            r7 = -723719(0xfffffffffff4f4f9, float:NaN)
            r1 = r1 & r7
            r1 = r1 | r5
            r5 = 1102053376(0x41b00000, float:22.0)
            r2[r1] = r5
            r5 = 86268(0x150fc, float:1.20887E-40)
            r1 = 9
            r1 = r4[r1]     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch:{ Exception -> 0x07a9 }
            r7 = 0
            java.lang.Object[] r7 = new java.lang.Object[r7]     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r1 = android.C2490.m594n(r5, r1, r7)     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch:{ Exception -> 0x07a9 }
            int r1 = r1.intValue()     // Catch:{ Exception -> 0x07a9 }
            r5 = r1 ^ -1
            r7 = 8013313(0x7a4601, float:1.1229043E-38)
            r5 = r5 & r7
            r7 = -8013314(0xffffffffff85b9fe, float:NaN)
            r1 = r1 & r7
            r1 = r1 | r5
            r5 = 1102053376(0x41b00000, float:22.0)
            r2[r1] = r5
            r1 = 14341(0x3805, float:2.0096E-41)
            r5 = 1
            java.lang.Object[] r5 = new java.lang.Object[r5]     // Catch:{ Exception -> 0x07a9 }
            r7 = 0
            r5[r7] = r2     // Catch:{ Exception -> 0x07a9 }
            android.C2490.m594n(r1, r9, r5)     // Catch:{ Exception -> 0x07a9 }
            r1 = 30899(0x78b3, float:4.3299E-41)
            java.lang.Object r1 = android.C2490.m592n(r1)     // Catch:{ Exception -> 0x07a9 }
            short[] r1 = (short[]) r1     // Catch:{ Exception -> 0x07a9 }
            r5 = 39369(0x99c9, float:5.5168E-41)
            r7 = 0
            r2 = 1
            java.lang.Object[] r8 = new java.lang.Object[r2]     // Catch:{ Exception -> 0x07a9 }
            r10 = 0
            r2 = 44751(0xaecf, float:6.271E-41)
            java.lang.Object r2 = android.C2490.m592n(r2)     // Catch:{ Exception -> 0x07a9 }
            java.lang.String r2 = (java.lang.String) r2     // Catch:{ Exception -> 0x07a9 }
            r8[r10] = r2     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r2 = android.C2490.m594n(r5, r7, r8)     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r2 = (java.lang.Integer) r2     // Catch:{ Exception -> 0x07a9 }
            int r5 = r2.intValue()     // Catch:{ Exception -> 0x07a9 }
            r7 = 39369(0x99c9, float:5.5168E-41)
            r8 = 0
            r2 = 1
            java.lang.Object[] r10 = new java.lang.Object[r2]     // Catch:{ Exception -> 0x07a9 }
            r11 = 0
            r2 = 84904(0x14ba8, float:1.18976E-40)
            java.lang.Object r2 = android.C2490.m592n(r2)     // Catch:{ Exception -> 0x07a9 }
            java.lang.String r2 = (java.lang.String) r2     // Catch:{ Exception -> 0x07a9 }
            r10[r11] = r2     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r2 = android.C2490.m594n(r7, r8, r10)     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r2 = (java.lang.Integer) r2     // Catch:{ Exception -> 0x07a9 }
            int r7 = r2.intValue()     // Catch:{ Exception -> 0x07a9 }
            r8 = 39369(0x99c9, float:5.5168E-41)
            r10 = 0
            r2 = 1
            java.lang.Object[] r11 = new java.lang.Object[r2]     // Catch:{ Exception -> 0x07a9 }
            r12 = 0
            r2 = 32068(0x7d44, float:4.4937E-41)
            java.lang.Object r2 = android.C2490.m592n(r2)     // Catch:{ Exception -> 0x07a9 }
            java.lang.String r2 = (java.lang.String) r2     // Catch:{ Exception -> 0x07a9 }
            r11[r12] = r2     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r2 = android.C2490.m594n(r8, r10, r11)     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r2 = (java.lang.Integer) r2     // Catch:{ Exception -> 0x07a9 }
            int r2 = r2.intValue()     // Catch:{ Exception -> 0x07a9 }
            r8 = 14366(0x381e, float:2.0131E-41)
            r10 = 2
            java.lang.Object[] r10 = new java.lang.Object[r10]     // Catch:{ Exception -> 0x07a9 }
            r11 = 0
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch:{ Exception -> 0x07a9 }
            r10[r11] = r6     // Catch:{ Exception -> 0x07a9 }
            r6 = 1
            r11 = 57290(0xdfca, float:8.028E-41)
            r12 = 0
            r13 = 1
            java.lang.Object[] r13 = new java.lang.Object[r13]     // Catch:{ Exception -> 0x07a9 }
            r14 = 0
            r15 = 63607(0xf877, float:8.9132E-41)
            r16 = 0
            r17 = 4
            r0 = r17
            java.lang.Object[] r0 = new java.lang.Object[r0]     // Catch:{ Exception -> 0x07a9 }
            r17 = r0
            r18 = 0
            r17[r18] = r1     // Catch:{ Exception -> 0x07a9 }
            r1 = 1
            r18 = -1746803(0xffffffffffe5588d, float:NaN)
            r18 = r18 & r7
            r7 = r7 ^ -1
            r19 = 1746802(0x1aa772, float:2.447791E-39)
            r7 = r7 & r19
            r7 = r7 | r18
            java.lang.Integer r7 = java.lang.Integer.valueOf(r7)     // Catch:{ Exception -> 0x07a9 }
            r17[r1] = r7     // Catch:{ Exception -> 0x07a9 }
            r1 = 2
            r7 = -1755460(0xffffffffffe536bc, float:NaN)
            r7 = r7 & r2
            r2 = r2 ^ -1
            r18 = 1755459(0x1ac943, float:2.459922E-39)
            r2 = r2 & r18
            r2 = r2 | r7
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)     // Catch:{ Exception -> 0x07a9 }
            r17[r1] = r2     // Catch:{ Exception -> 0x07a9 }
            r1 = 3
            r2 = -1752987(0xffffffffffe54065, float:NaN)
            r2 = r2 & r5
            r5 = r5 ^ -1
            r7 = 1752986(0x1abf9a, float:2.456457E-39)
            r5 = r5 & r7
            r2 = r2 | r5
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)     // Catch:{ Exception -> 0x07a9 }
            r17[r1] = r2     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r1 = android.C2490.m594n(r15, r16, r17)     // Catch:{ Exception -> 0x07a9 }
            java.lang.String r1 = (java.lang.String) r1     // Catch:{ Exception -> 0x07a9 }
            r13[r14] = r1     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r1 = android.C2490.m594n(r11, r12, r13)     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch:{ Exception -> 0x07a9 }
            int r1 = r1.intValue()     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)     // Catch:{ Exception -> 0x07a9 }
            r10[r6] = r1     // Catch:{ Exception -> 0x07a9 }
            android.C2490.m594n(r8, r9, r10)     // Catch:{ Exception -> 0x07a9 }
            r1 = 69236(0x10e74, float:9.702E-41)
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch:{ Exception -> 0x07a9 }
            r5 = 0
            r2[r5] = r9     // Catch:{ Exception -> 0x07a9 }
            android.C2490.m594n(r1, r3, r2)     // Catch:{ Exception -> 0x07a9 }
            r2 = 23437(0x5b8d, float:3.2842E-41)
            r1 = 1
            java.lang.Object[] r5 = new java.lang.Object[r1]     // Catch:{ Exception -> 0x07a9 }
            r6 = 0
            r7 = 77881(0x13039, float:1.09135E-40)
            r1 = 7
            r1 = r4[r1]     // Catch:{ Exception -> 0x07a9 }
            java.lang.Float r1 = (java.lang.Float) r1     // Catch:{ Exception -> 0x07a9 }
            r8 = 0
            java.lang.Object[] r8 = new java.lang.Object[r8]     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r1 = android.C2490.m594n(r7, r1, r8)     // Catch:{ Exception -> 0x07a9 }
            java.lang.Float r1 = (java.lang.Float) r1     // Catch:{ Exception -> 0x07a9 }
            float r1 = r1.floatValue()     // Catch:{ Exception -> 0x07a9 }
            java.lang.Float r1 = java.lang.Float.valueOf(r1)     // Catch:{ Exception -> 0x07a9 }
            r5[r6] = r1     // Catch:{ Exception -> 0x07a9 }
            android.C2490.m594n(r2, r3, r5)     // Catch:{ Exception -> 0x07a9 }
            r2 = 99520(0x184c0, float:1.39457E-40)
            r1 = 1
            java.lang.Object[] r5 = new java.lang.Object[r1]     // Catch:{ Exception -> 0x07a9 }
            r6 = 0
            r7 = 77881(0x13039, float:1.09135E-40)
            r1 = 11
            r1 = r4[r1]     // Catch:{ Exception -> 0x07a9 }
            java.lang.Float r1 = (java.lang.Float) r1     // Catch:{ Exception -> 0x07a9 }
            r8 = 0
            java.lang.Object[] r8 = new java.lang.Object[r8]     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r1 = android.C2490.m594n(r7, r1, r8)     // Catch:{ Exception -> 0x07a9 }
            java.lang.Float r1 = (java.lang.Float) r1     // Catch:{ Exception -> 0x07a9 }
            float r1 = r1.floatValue()     // Catch:{ Exception -> 0x07a9 }
            java.lang.Float r1 = java.lang.Float.valueOf(r1)     // Catch:{ Exception -> 0x07a9 }
            r5[r6] = r1     // Catch:{ Exception -> 0x07a9 }
            android.C2490.m594n(r2, r3, r5)     // Catch:{ Exception -> 0x07a9 }
            r2 = 86268(0x150fc, float:1.20887E-40)
            r1 = 3
            r1 = r4[r1]     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch:{ Exception -> 0x07a9 }
            r5 = 0
            java.lang.Object[] r5 = new java.lang.Object[r5]     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r1 = android.C2490.m594n(r2, r1, r5)     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch:{ Exception -> 0x07a9 }
            int r1 = r1.intValue()     // Catch:{ Exception -> 0x07a9 }
            r2 = 35415(0x8a57, float:4.9627E-41)
            r5 = 1
            java.lang.Object[] r5 = new java.lang.Object[r5]     // Catch:{ Exception -> 0x07a9 }
            r6 = 0
            r7 = r1 ^ -1
            r8 = 2483072(0x25e380, float:3.479525E-39)
            r7 = r7 & r8
            r8 = -2483073(0xffffffffffda1c7f, float:NaN)
            r1 = r1 & r8
            r1 = r1 | r7
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)     // Catch:{ Exception -> 0x07a9 }
            r5[r6] = r1     // Catch:{ Exception -> 0x07a9 }
            android.C2492.m612n(r2, r3, r5)     // Catch:{ Exception -> 0x07a9 }
            r2 = 86268(0x150fc, float:1.20887E-40)
            r1 = 5
            r1 = r4[r1]     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch:{ Exception -> 0x07a9 }
            r5 = 0
            java.lang.Object[] r5 = new java.lang.Object[r5]     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r1 = android.C2490.m594n(r2, r1, r5)     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch:{ Exception -> 0x07a9 }
            int r1 = r1.intValue()     // Catch:{ Exception -> 0x07a9 }
            r2 = 35415(0x8a57, float:4.9627E-41)
            r5 = 1
            java.lang.Object[] r5 = new java.lang.Object[r5]     // Catch:{ Exception -> 0x07a9 }
            r6 = 0
            r7 = r1 ^ -1
            r8 = 2188869(0x216645, float:3.067259E-39)
            r7 = r7 & r8
            r8 = -2188870(0xffffffffffde99ba, float:NaN)
            r1 = r1 & r8
            r1 = r1 | r7
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)     // Catch:{ Exception -> 0x07a9 }
            r5[r6] = r1     // Catch:{ Exception -> 0x07a9 }
            android.C2492.m612n(r2, r3, r5)     // Catch:{ Exception -> 0x07a9 }
            r2 = 11104(0x2b60, float:1.556E-41)
            r1 = 90810(0x162ba, float:1.27252E-40)
            java.lang.Object r1 = android.C2490.m592n(r1)     // Catch:{ Exception -> 0x07b6 }
            android.app.AlertDialog r1 = (android.app.AlertDialog) r1     // Catch:{ Exception -> 0x07b6 }
            r3 = 0
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x07b6 }
            android.C2492.m612n(r2, r1, r3)     // Catch:{ Exception -> 0x07b6 }
        L_0x0632:
            r1 = 90810(0x162ba, float:1.27252E-40)
            java.lang.Object r1 = android.C2490.m592n(r1)     // Catch:{ Exception -> 0x07a9 }
            r0 = r1
            android.app.AlertDialog r0 = (android.app.AlertDialog) r0     // Catch:{ Exception -> 0x07a9 }
            r2 = r0
            r3 = 86268(0x150fc, float:1.20887E-40)
            r1 = 8
            r1 = r4[r1]     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch:{ Exception -> 0x07a9 }
            r4 = 0
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r1 = android.C2490.m594n(r3, r1, r4)     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch:{ Exception -> 0x07a9 }
            int r1 = r1.intValue()     // Catch:{ Exception -> 0x07a9 }
            r3 = r1 ^ -1
            r4 = 6730310(0x66b246, float:9.431173E-39)
            r3 = r3 & r4
            r4 = -6730311(0xffffffffff994db9, float:NaN)
            r1 = r1 & r4
            r3 = r3 | r1
            r1 = 5617(0x15f1, float:7.871E-42)
            r4 = 1
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch:{ Exception -> 0x07a9 }
            r5 = 0
            java.lang.Integer r6 = java.lang.Integer.valueOf(r3)     // Catch:{ Exception -> 0x07a9 }
            r4[r5] = r6     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r1 = android.C2492.m612n(r1, r2, r4)     // Catch:{ Exception -> 0x07a9 }
            android.widget.Button r1 = (android.widget.Button) r1     // Catch:{ Exception -> 0x07a9 }
            r2 = 72547(0x11b63, float:1.0166E-40)
            r4 = 1
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch:{ Exception -> 0x07a9 }
            r5 = 0
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)     // Catch:{ Exception -> 0x07a9 }
            r4[r5] = r3     // Catch:{ Exception -> 0x07a9 }
            android.C2492.m612n(r2, r1, r4)     // Catch:{ Exception -> 0x07a9 }
            r2 = 30899(0x78b3, float:4.3299E-41)
            java.lang.Object r2 = android.C2490.m592n(r2)     // Catch:{ Exception -> 0x07a9 }
            short[] r2 = (short[]) r2     // Catch:{ Exception -> 0x07a9 }
            r4 = 39369(0x99c9, float:5.5168E-41)
            r5 = 0
            r3 = 1
            java.lang.Object[] r6 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x07a9 }
            r7 = 0
            r3 = 89009(0x15bb1, float:1.24728E-40)
            java.lang.Object r3 = android.C2492.m610n(r3)     // Catch:{ Exception -> 0x07a9 }
            java.lang.String r3 = (java.lang.String) r3     // Catch:{ Exception -> 0x07a9 }
            r6[r7] = r3     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r3 = android.C2490.m594n(r4, r5, r6)     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r3 = (java.lang.Integer) r3     // Catch:{ Exception -> 0x07a9 }
            int r4 = r3.intValue()     // Catch:{ Exception -> 0x07a9 }
            r5 = 39369(0x99c9, float:5.5168E-41)
            r6 = 0
            r3 = 1
            java.lang.Object[] r7 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x07a9 }
            r8 = 0
            r3 = 66524(0x103dc, float:9.322E-41)
            java.lang.Object r3 = android.C2492.m610n(r3)     // Catch:{ Exception -> 0x07a9 }
            java.lang.String r3 = (java.lang.String) r3     // Catch:{ Exception -> 0x07a9 }
            r7[r8] = r3     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r3 = android.C2490.m594n(r5, r6, r7)     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r3 = (java.lang.Integer) r3     // Catch:{ Exception -> 0x07a9 }
            int r5 = r3.intValue()     // Catch:{ Exception -> 0x07a9 }
            r6 = 39369(0x99c9, float:5.5168E-41)
            r7 = 0
            r3 = 1
            java.lang.Object[] r8 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x07a9 }
            r9 = 0
            r3 = 89291(0x15ccb, float:1.25123E-40)
            java.lang.Object r3 = android.C2492.m610n(r3)     // Catch:{ Exception -> 0x07a9 }
            java.lang.String r3 = (java.lang.String) r3     // Catch:{ Exception -> 0x07a9 }
            r8[r9] = r3     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r3 = android.C2490.m594n(r6, r7, r8)     // Catch:{ Exception -> 0x07a9 }
            java.lang.Integer r3 = (java.lang.Integer) r3     // Catch:{ Exception -> 0x07a9 }
            int r3 = r3.intValue()     // Catch:{ Exception -> 0x07a9 }
            r6 = 1307(0x51b, float:1.831E-42)
            r7 = 0
            r8 = 4
            java.lang.Object[] r8 = new java.lang.Object[r8]     // Catch:{ Exception -> 0x07a9 }
            r9 = 0
            r8[r9] = r1     // Catch:{ Exception -> 0x07a9 }
            r1 = 1
            r9 = 0
            r8[r1] = r9     // Catch:{ Exception -> 0x07a9 }
            r9 = 2
            r1 = 80494(0x13a6e, float:1.12796E-40)
            r10 = 0
            r11 = 4
            java.lang.Object[] r11 = new java.lang.Object[r11]     // Catch:{ Exception -> 0x07a9 }
            r12 = 0
            r11[r12] = r2     // Catch:{ Exception -> 0x07a9 }
            r2 = 1
            r12 = -1753524(0xffffffffffe53e4c, float:NaN)
            r12 = r12 & r5
            r5 = r5 ^ -1
            r13 = 1753523(0x1ac1b3, float:2.457209E-39)
            r5 = r5 & r13
            r5 = r5 | r12
            java.lang.Integer r5 = java.lang.Integer.valueOf(r5)     // Catch:{ Exception -> 0x07a9 }
            r11[r2] = r5     // Catch:{ Exception -> 0x07a9 }
            r2 = 2
            r5 = -1752712(0xffffffffffe54178, float:NaN)
            r5 = r5 & r3
            r3 = r3 ^ -1
            r12 = 1752711(0x1abe87, float:2.456071E-39)
            r3 = r3 & r12
            r3 = r3 | r5
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)     // Catch:{ Exception -> 0x07a9 }
            r11[r2] = r3     // Catch:{ Exception -> 0x07a9 }
            r2 = 3
            r3 = -1754286(0xffffffffffe53b52, float:NaN)
            r3 = r3 & r4
            r4 = r4 ^ -1
            r5 = 1754285(0x1ac4ad, float:2.458277E-39)
            r4 = r4 & r5
            r3 = r3 | r4
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)     // Catch:{ Exception -> 0x07a9 }
            r11[r2] = r3     // Catch:{ Exception -> 0x07a9 }
            java.lang.Object r1 = android.C2490.m594n(r1, r10, r11)     // Catch:{ Exception -> 0x07a9 }
            java.lang.String r1 = (java.lang.String) r1     // Catch:{ Exception -> 0x07a9 }
            r8[r9] = r1     // Catch:{ Exception -> 0x07a9 }
            r1 = 3
            r2 = 0
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)     // Catch:{ Exception -> 0x07a9 }
            r8[r1] = r2     // Catch:{ Exception -> 0x07a9 }
            android.C2492.m612n(r6, r7, r8)     // Catch:{ Exception -> 0x07a9 }
        L_0x0740:
            r1 = 31736(0x7bf8, float:4.4472E-41)
            r2 = 0
            r3 = 0
            java.lang.Object[] r3 = new java.lang.Object[r3]
            java.lang.Object r1 = android.C2492.m612n(r1, r2, r3)
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r2 = r1.intValue()
            r1 = 1616(0x650, float:2.264E-42)
        L_0x0752:
            r1 = r1 ^ 1633(0x661, float:2.288E-42)
            switch(r1) {
                case 14: goto L_0x0758;
                case 49: goto L_0x075b;
                case 204: goto L_0x0760;
                case 239: goto L_0x079c;
                default: goto L_0x0757;
            }
        L_0x0757:
            goto L_0x0752
        L_0x0758:
            r1 = 1678(0x68e, float:2.351E-42)
            goto L_0x0752
        L_0x075b:
            if (r2 > 0) goto L_0x0758
            r1 = 1709(0x6ad, float:2.395E-42)
            goto L_0x0752
        L_0x0760:
            r2 = 76185(0x12999, float:1.06758E-40)
            r3 = 0
            r1 = 1
            java.lang.Object[] r4 = new java.lang.Object[r1]
            r5 = 0
            r6 = 67649(0x10841, float:9.4796E-41)
            r7 = 0
            r1 = 1
            java.lang.Object[] r8 = new java.lang.Object[r1]
            r9 = 0
            r1 = 24035(0x5de3, float:3.368E-41)
            java.lang.Object r1 = android.C2492.m610n(r1)
            java.lang.String r1 = (java.lang.String) r1
            r8[r9] = r1
            java.lang.Object r1 = android.C2492.m612n(r6, r7, r8)
            java.lang.String r1 = (java.lang.String) r1
            r4[r5] = r1
            java.lang.Object r1 = android.C2492.m612n(r2, r3, r4)
            java.lang.Long r1 = (java.lang.Long) r1
            r3 = 74243(0x12203, float:1.04037E-40)
            r2 = 3740(0xe9c, float:5.241E-42)
            java.lang.Object r2 = android.C2490.m592n(r2)
            java.io.PrintStream r2 = (java.io.PrintStream) r2
            r4 = 1
            java.lang.Object[] r4 = new java.lang.Object[r4]
            r5 = 0
            r4[r5] = r1
            android.C2492.m612n(r3, r2, r4)
        L_0x079c:
            return
        L_0x079d:
            r1 = move-exception
            r1 = 1740(0x6cc, float:2.438E-42)
        L_0x07a0:
            r1 = r1 ^ 1757(0x6dd, float:2.462E-42)
            switch(r1) {
                case 17: goto L_0x07a6;
                case 54: goto L_0x01cf;
                default: goto L_0x07a5;
            }
        L_0x07a5:
            goto L_0x07a0
        L_0x07a6:
            r1 = 1771(0x6eb, float:2.482E-42)
            goto L_0x07a0
        L_0x07a9:
            r1 = move-exception
            r1 = 1864(0x748, float:2.612E-42)
        L_0x07ac:
            r1 = r1 ^ 1881(0x759, float:2.636E-42)
            switch(r1) {
                case 17: goto L_0x07b2;
                case 47483: goto L_0x0740;
                default: goto L_0x07b1;
            }
        L_0x07b1:
            goto L_0x07ac
        L_0x07b2:
            r1 = 48674(0xbe22, float:6.8207E-41)
            goto L_0x07ac
        L_0x07b6:
            r1 = move-exception
            r1 = 48767(0xbe7f, float:6.8337E-41)
        L_0x07ba:
            r2 = 48784(0xbe90, float:6.8361E-41)
            r1 = r1 ^ r2
            switch(r1) {
                case 14: goto L_0x0632;
                case 239: goto L_0x07c2;
                default: goto L_0x07c1;
            }
        L_0x07c1:
            goto L_0x07ba
        L_0x07c2:
            r1 = 48798(0xbe9e, float:6.838E-41)
            goto L_0x07ba
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p001v4.appcompat.library.BottomSheetDialog.MessageBox(java.lang.String, java.lang.String):void");
    }

    static /* synthetic */ AlertDialog access$000() {
        return (AlertDialog) C2490.m592n(90810);
    }

    /* JADX WARNING: type inference failed for: r1v5, types: [int, boolean] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* renamed from: r */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static void m591r(android.view.View r9, android.graphics.drawable.GradientDrawable r10, java.lang.String r11, int r12) {
        /*
            r4 = 1
            r3 = 0
            r0 = 2
            java.lang.Object[] r1 = new java.lang.Object[r0]
            java.lang.Float r0 = new java.lang.Float
            r2 = 1097859072(0x41700000, float:15.0)
            r0.<init>(r2)
            r1[r3] = r0
            java.lang.Integer r0 = new java.lang.Integer
            r2 = 3480251(0x351abb, float:4.87687E-39)
            r0.<init>(r2)
            r1[r4] = r0
            r2 = 77881(0x13039, float:1.09135E-40)
            r0 = r1[r3]
            java.lang.Float r0 = (java.lang.Float) r0
            java.lang.Object[] r3 = new java.lang.Object[r3]
            java.lang.Object r0 = android.C2490.m594n(r2, r0, r3)
            java.lang.Float r0 = (java.lang.Float) r0
            float r0 = r0.floatValue()
            r2 = 90129(0x16011, float:1.26298E-40)
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x00d4 }
            r4 = 0
            java.lang.Float r0 = java.lang.Float.valueOf(r0)     // Catch:{ Exception -> 0x00d4 }
            r3[r4] = r0     // Catch:{ Exception -> 0x00d4 }
            android.C2492.m612n(r2, r9, r3)     // Catch:{ Exception -> 0x00d4 }
            android.content.res.ColorStateList r2 = new android.content.res.ColorStateList     // Catch:{ Exception -> 0x00d4 }
            r3 = 86268(0x150fc, float:1.20887E-40)
            r0 = 1
            r0 = r1[r0]     // Catch:{ Exception -> 0x00d4 }
            java.lang.Integer r0 = (java.lang.Integer) r0     // Catch:{ Exception -> 0x00d4 }
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch:{ Exception -> 0x00d4 }
            java.lang.Object r0 = android.C2490.m594n(r3, r0, r1)     // Catch:{ Exception -> 0x00d4 }
            java.lang.Integer r0 = (java.lang.Integer) r0     // Catch:{ Exception -> 0x00d4 }
            int r0 = r0.intValue()     // Catch:{ Exception -> 0x00d4 }
            r1 = r0 ^ -1
            r3 = 3480250(0x351aba, float:4.876869E-39)
            r1 = r1 & r3
            r3 = -3480251(0xffffffffffcae545, float:NaN)
            r0 = r0 & r3
            r1 = r1 | r0
            int[][] r3 = new int[r1][]     // Catch:{ Exception -> 0x00d4 }
            r0 = 0
            r4 = 0
            int[] r4 = new int[r4]     // Catch:{ Exception -> 0x00d4 }
            r3[r0] = r4     // Catch:{ Exception -> 0x00d4 }
            int[] r4 = new int[r1]     // Catch:{ Exception -> 0x00d4 }
            r5 = 0
            r0 = 57290(0xdfca, float:8.028E-41)
            r6 = 0
            r7 = 1
            java.lang.Object[] r7 = new java.lang.Object[r7]     // Catch:{ Exception -> 0x00d4 }
            r8 = 0
            r7[r8] = r11     // Catch:{ Exception -> 0x00d4 }
            java.lang.Object r0 = android.C2490.m594n(r0, r6, r7)     // Catch:{ Exception -> 0x00d4 }
            java.lang.Integer r0 = (java.lang.Integer) r0     // Catch:{ Exception -> 0x00d4 }
            int r0 = r0.intValue()     // Catch:{ Exception -> 0x00d4 }
            r4[r5] = r0     // Catch:{ Exception -> 0x00d4 }
            r2.<init>(r3, r4)     // Catch:{ Exception -> 0x00d4 }
            android.graphics.drawable.RippleDrawable r3 = new android.graphics.drawable.RippleDrawable     // Catch:{ Exception -> 0x00d4 }
            r0 = 0
            r3.<init>(r2, r10, r0)     // Catch:{ Exception -> 0x00d4 }
            r0 = 1616(0x650, float:2.264E-42)
        L_0x0089:
            r0 = r0 ^ 1633(0x661, float:2.288E-42)
            switch(r0) {
                case 14: goto L_0x008f;
                case 49: goto L_0x0092;
                case 204: goto L_0x0097;
                case 239: goto L_0x00a7;
                default: goto L_0x008e;
            }     // Catch:{ Exception -> 0x00d4 }
        L_0x008e:
            goto L_0x0089
        L_0x008f:
            r0 = 1678(0x68e, float:2.351E-42)
            goto L_0x0089
        L_0x0092:
            if (r12 == 0) goto L_0x008f
            r0 = 1709(0x6ad, float:2.395E-42)
            goto L_0x0089
        L_0x0097:
            r0 = 82257(0x14151, float:1.15267E-40)
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch:{ Exception -> 0x00d4 }
            r4 = 0
            java.lang.Integer r5 = java.lang.Integer.valueOf(r12)     // Catch:{ Exception -> 0x00d4 }
            r2[r4] = r5     // Catch:{ Exception -> 0x00d4 }
            android.C2492.m612n(r0, r3, r2)     // Catch:{ Exception -> 0x00d4 }
        L_0x00a7:
            r0 = 80902(0x13c06, float:1.13368E-40)
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch:{ Exception -> 0x00d4 }
            r4 = 0
            java.lang.Boolean r5 = java.lang.Boolean.valueOf(r1)     // Catch:{ Exception -> 0x00d4 }
            r2[r4] = r5     // Catch:{ Exception -> 0x00d4 }
            android.C2492.m612n(r0, r9, r2)     // Catch:{ Exception -> 0x00d4 }
            r0 = 70859(0x114cb, float:9.9295E-41)
            r2 = 1
            java.lang.Object[] r2 = new java.lang.Object[r2]     // Catch:{ Exception -> 0x00d4 }
            r4 = 0
            java.lang.Boolean r1 = java.lang.Boolean.valueOf(r1)     // Catch:{ Exception -> 0x00d4 }
            r2[r4] = r1     // Catch:{ Exception -> 0x00d4 }
            android.C2492.m612n(r0, r9, r2)     // Catch:{ Exception -> 0x00d4 }
            r0 = 35148(0x894c, float:4.9253E-41)
            r1 = 1
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch:{ Exception -> 0x00d4 }
            r2 = 0
            r1[r2] = r3     // Catch:{ Exception -> 0x00d4 }
            android.C2492.m612n(r0, r9, r1)     // Catch:{ Exception -> 0x00d4 }
        L_0x00d3:
            return
        L_0x00d4:
            r0 = move-exception
            r0 = 1740(0x6cc, float:2.438E-42)
        L_0x00d7:
            r0 = r0 ^ 1757(0x6dd, float:2.462E-42)
            switch(r0) {
                case 17: goto L_0x00dd;
                case 54: goto L_0x00d3;
                default: goto L_0x00dc;
            }
        L_0x00dc:
            goto L_0x00d7
        L_0x00dd:
            r0 = 1771(0x6eb, float:2.482E-42)
            goto L_0x00d7
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p001v4.appcompat.library.BottomSheetDialog.m591r(android.view.View, android.graphics.drawable.GradientDrawable, java.lang.String, int):void");
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void run(android.content.Context r15, android.app.Activity r16) {
        /*
            r0 = 30899(0x78b3, float:4.3299E-41)
            java.lang.Object r0 = android.C2490.m592n(r0)
            short[] r0 = (short[]) r0
            r2 = 39369(0x99c9, float:5.5168E-41)
            r3 = 0
            r1 = 1
            java.lang.Object[] r4 = new java.lang.Object[r1]
            r5 = 0
            r1 = 21569(0x5441, float:3.0225E-41)
            java.lang.Object r1 = android.C2492.m610n(r1)
            java.lang.String r1 = (java.lang.String) r1
            r4[r5] = r1
            java.lang.Object r1 = android.C2490.m594n(r2, r3, r4)
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r2 = r1.intValue()
            r3 = 39369(0x99c9, float:5.5168E-41)
            r4 = 0
            r1 = 1
            java.lang.Object[] r5 = new java.lang.Object[r1]
            r6 = 0
            r1 = 52081(0xcb71, float:7.2981E-41)
            java.lang.Object r1 = android.C2492.m610n(r1)
            java.lang.String r1 = (java.lang.String) r1
            r5[r6] = r1
            java.lang.Object r1 = android.C2490.m594n(r3, r4, r5)
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r3 = r1.intValue()
            r4 = 39369(0x99c9, float:5.5168E-41)
            r5 = 0
            r1 = 1
            java.lang.Object[] r6 = new java.lang.Object[r1]
            r7 = 0
            r1 = 25972(0x6574, float:3.6395E-41)
            java.lang.Object r1 = android.C2492.m610n(r1)
            java.lang.String r1 = (java.lang.String) r1
            r6[r7] = r1
            java.lang.Object r1 = android.C2490.m594n(r4, r5, r6)
            java.lang.Integer r1 = (java.lang.Integer) r1
            int r1 = r1.intValue()
            r4 = 28608(0x6fc0, float:4.0088E-41)
            r5 = 0
            r6 = 4
            java.lang.Object[] r6 = new java.lang.Object[r6]
            r7 = 0
            r6[r7] = r0
            r0 = 1
            r7 = -1749703(0xffffffffffe54d39, float:NaN)
            r7 = r7 & r3
            r3 = r3 ^ -1
            r8 = 1749702(0x1ab2c6, float:2.451855E-39)
            r3 = r3 & r8
            r3 = r3 | r7
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)
            r6[r0] = r3
            r0 = 2
            r3 = -1751777(0xffffffffffe5451f, float:NaN)
            r3 = r3 & r1
            r1 = r1 ^ -1
            r7 = 1751776(0x1abae0, float:2.454761E-39)
            r1 = r1 & r7
            r1 = r1 | r3
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)
            r6[r0] = r1
            r0 = 3
            r1 = -1754838(0xffffffffffe5392a, float:NaN)
            r1 = r1 & r2
            r2 = r2 ^ -1
            r3 = 1754837(0x1ac6d5, float:2.45905E-39)
            r2 = r2 & r3
            r1 = r1 | r2
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)
            r6[r0] = r1
            java.lang.Object r0 = android.C2492.m612n(r4, r5, r6)
            java.lang.String r0 = (java.lang.String) r0
            r1 = 30899(0x78b3, float:4.3299E-41)
            java.lang.Object r1 = android.C2490.m592n(r1)
            short[] r1 = (short[]) r1
            r3 = 39369(0x99c9, float:5.5168E-41)
            r4 = 0
            r2 = 1
            java.lang.Object[] r5 = new java.lang.Object[r2]
            r6 = 0
            r2 = 86540(0x1520c, float:1.21268E-40)
            java.lang.Object r2 = android.C2492.m610n(r2)
            java.lang.String r2 = (java.lang.String) r2
            r5[r6] = r2
            java.lang.Object r2 = android.C2490.m594n(r3, r4, r5)
            java.lang.Integer r2 = (java.lang.Integer) r2
            int r3 = r2.intValue()
            r4 = 39369(0x99c9, float:5.5168E-41)
            r5 = 0
            r2 = 1
            java.lang.Object[] r6 = new java.lang.Object[r2]
            r7 = 0
            r2 = 62007(0xf237, float:8.689E-41)
            java.lang.Object r2 = android.C2492.m610n(r2)
            java.lang.String r2 = (java.lang.String) r2
            r6[r7] = r2
            java.lang.Object r2 = android.C2490.m594n(r4, r5, r6)
            java.lang.Integer r2 = (java.lang.Integer) r2
            int r4 = r2.intValue()
            r5 = 39369(0x99c9, float:5.5168E-41)
            r6 = 0
            r2 = 1
            java.lang.Object[] r7 = new java.lang.Object[r2]
            r8 = 0
            r2 = 38278(0x9586, float:5.3639E-41)
            java.lang.Object r2 = android.C2492.m610n(r2)
            java.lang.String r2 = (java.lang.String) r2
            r7[r8] = r2
            java.lang.Object r2 = android.C2490.m594n(r5, r6, r7)
            java.lang.Integer r2 = (java.lang.Integer) r2
            int r2 = r2.intValue()
            r5 = 96419(0x178a3, float:1.35112E-40)
            r6 = 0
            r7 = 4
            java.lang.Object[] r7 = new java.lang.Object[r7]
            r8 = 0
            r7[r8] = r1
            r1 = 1
            r8 = -56348(0xffffffffffff23e4, float:NaN)
            r8 = r8 & r4
            r4 = r4 ^ -1
            r9 = 56347(0xdc1b, float:7.8959E-41)
            r4 = r4 & r9
            r4 = r4 | r8
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)
            r7[r1] = r4
            r1 = 2
            r4 = -1753633(0xffffffffffe53ddf, float:NaN)
            r4 = r4 & r2
            r2 = r2 ^ -1
            r8 = 1753632(0x1ac220, float:2.457362E-39)
            r2 = r2 & r8
            r2 = r2 | r4
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            r7[r1] = r2
            r1 = 3
            r2 = -1753017(0xffffffffffe54047, float:NaN)
            r2 = r2 & r3
            r3 = r3 ^ -1
            r4 = 1753016(0x1abfb8, float:2.456499E-39)
            r3 = r3 & r4
            r2 = r2 | r3
            java.lang.Integer r2 = java.lang.Integer.valueOf(r2)
            r7[r1] = r2
            java.lang.Object r1 = android.C2490.m594n(r5, r6, r7)
            java.lang.String r1 = (java.lang.String) r1
            con = r15     // Catch:{ Exception -> 0x05c3 }
            act = r16     // Catch:{ Exception -> 0x05c3 }
            r2 = 30899(0x78b3, float:4.3299E-41)
            java.lang.Object r2 = android.C2490.m592n(r2)     // Catch:{ Exception -> 0x05c3 }
            short[] r2 = (short[]) r2     // Catch:{ Exception -> 0x05c3 }
            r4 = 39369(0x99c9, float:5.5168E-41)
            r5 = 0
            r3 = 1
            java.lang.Object[] r6 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x05c3 }
            r7 = 0
            r3 = 33732(0x83c4, float:4.7269E-41)
            java.lang.Object r3 = android.C2492.m610n(r3)     // Catch:{ Exception -> 0x05c3 }
            java.lang.String r3 = (java.lang.String) r3     // Catch:{ Exception -> 0x05c3 }
            r6[r7] = r3     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r3 = android.C2490.m594n(r4, r5, r6)     // Catch:{ Exception -> 0x05c3 }
            java.lang.Integer r3 = (java.lang.Integer) r3     // Catch:{ Exception -> 0x05c3 }
            int r4 = r3.intValue()     // Catch:{ Exception -> 0x05c3 }
            r5 = 39369(0x99c9, float:5.5168E-41)
            r6 = 0
            r3 = 1
            java.lang.Object[] r7 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x05c3 }
            r8 = 0
            r3 = 25945(0x6559, float:3.6357E-41)
            java.lang.Object r3 = android.C2492.m610n(r3)     // Catch:{ Exception -> 0x05c3 }
            java.lang.String r3 = (java.lang.String) r3     // Catch:{ Exception -> 0x05c3 }
            r7[r8] = r3     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r3 = android.C2490.m594n(r5, r6, r7)     // Catch:{ Exception -> 0x05c3 }
            java.lang.Integer r3 = (java.lang.Integer) r3     // Catch:{ Exception -> 0x05c3 }
            int r5 = r3.intValue()     // Catch:{ Exception -> 0x05c3 }
            r6 = 39369(0x99c9, float:5.5168E-41)
            r7 = 0
            r3 = 1
            java.lang.Object[] r8 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x05c3 }
            r9 = 0
            r3 = 69704(0x11048, float:9.7676E-41)
            java.lang.Object r3 = android.C2492.m610n(r3)     // Catch:{ Exception -> 0x05c3 }
            java.lang.String r3 = (java.lang.String) r3     // Catch:{ Exception -> 0x05c3 }
            r8[r9] = r3     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r3 = android.C2490.m594n(r6, r7, r8)     // Catch:{ Exception -> 0x05c3 }
            java.lang.Integer r3 = (java.lang.Integer) r3     // Catch:{ Exception -> 0x05c3 }
            int r3 = r3.intValue()     // Catch:{ Exception -> 0x05c3 }
            r6 = 10036(0x2734, float:1.4063E-41)
            r7 = 2
            java.lang.Object[] r7 = new java.lang.Object[r7]     // Catch:{ Exception -> 0x05c3 }
            r8 = 0
            r9 = 28608(0x6fc0, float:4.0088E-41)
            r10 = 0
            r11 = 4
            java.lang.Object[] r11 = new java.lang.Object[r11]     // Catch:{ Exception -> 0x05c3 }
            r12 = 0
            r11[r12] = r2     // Catch:{ Exception -> 0x05c3 }
            r2 = 1
            r12 = -1746798(0xffffffffffe55892, float:NaN)
            r12 = r12 & r5
            r5 = r5 ^ -1
            r13 = 1746797(0x1aa76d, float:2.447784E-39)
            r5 = r5 & r13
            r5 = r5 | r12
            java.lang.Integer r5 = java.lang.Integer.valueOf(r5)     // Catch:{ Exception -> 0x05c3 }
            r11[r2] = r5     // Catch:{ Exception -> 0x05c3 }
            r2 = 2
            r5 = -1754401(0xffffffffffe53adf, float:NaN)
            r5 = r5 & r3
            r3 = r3 ^ -1
            r12 = 1754400(0x1ac520, float:2.458438E-39)
            r3 = r3 & r12
            r3 = r3 | r5
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)     // Catch:{ Exception -> 0x05c3 }
            r11[r2] = r3     // Catch:{ Exception -> 0x05c3 }
            r2 = 3
            r3 = -56287(0xffffffffffff2421, float:NaN)
            r3 = r3 & r4
            r4 = r4 ^ -1
            r5 = 56286(0xdbde, float:7.8873E-41)
            r4 = r4 & r5
            r3 = r3 | r4
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)     // Catch:{ Exception -> 0x05c3 }
            r11[r2] = r3     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r2 = android.C2492.m612n(r9, r10, r11)     // Catch:{ Exception -> 0x05c3 }
            java.lang.String r2 = (java.lang.String) r2     // Catch:{ Exception -> 0x05c3 }
            r7[r8] = r2     // Catch:{ Exception -> 0x05c3 }
            r2 = 1
            r3 = 0
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)     // Catch:{ Exception -> 0x05c3 }
            r7[r2] = r3     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r2 = android.C2492.m612n(r6, r15, r7)     // Catch:{ Exception -> 0x05c3 }
            android.content.SharedPreferences r2 = (android.content.SharedPreferences) r2     // Catch:{ Exception -> 0x05c3 }
            f622sp = r2     // Catch:{ Exception -> 0x05c3 }
            r4 = 4670(0x123e, float:6.544E-42)
            r5 = 61521(0xf051, float:8.6209E-41)
            r3 = 27323(0x6abb, float:3.8288E-41)
            r6 = 49532(0xc17c, float:6.9409E-41)
            r2 = 71611(0x117bb, float:1.00348E-40)
            java.lang.Object r2 = android.C2490.m592n(r2)     // Catch:{ Exception -> 0x05c3 }
            android.content.Context r2 = (android.content.Context) r2     // Catch:{ Exception -> 0x05c3 }
            r7 = 0
            java.lang.Object[] r7 = new java.lang.Object[r7]     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r2 = android.C2492.m612n(r6, r2, r7)     // Catch:{ Exception -> 0x05c3 }
            android.content.Context r2 = (android.content.Context) r2     // Catch:{ Exception -> 0x05c3 }
            r6 = 0
            java.lang.Object[] r6 = new java.lang.Object[r6]     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r2 = android.C2492.m612n(r3, r2, r6)     // Catch:{ Exception -> 0x05c3 }
            android.content.pm.ApplicationInfo r2 = (android.content.pm.ApplicationInfo) r2     // Catch:{ Exception -> 0x05c3 }
            r3 = 1
            java.lang.Object[] r6 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x05c3 }
            r7 = 0
            r8 = 94562(0x17162, float:1.3251E-40)
            r3 = 71611(0x117bb, float:1.00348E-40)
            java.lang.Object r3 = android.C2490.m592n(r3)     // Catch:{ Exception -> 0x05c3 }
            android.content.Context r3 = (android.content.Context) r3     // Catch:{ Exception -> 0x05c3 }
            r9 = 0
            java.lang.Object[] r9 = new java.lang.Object[r9]     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r3 = android.C2492.m612n(r8, r3, r9)     // Catch:{ Exception -> 0x05c3 }
            android.content.pm.PackageManager r3 = (android.content.pm.PackageManager) r3     // Catch:{ Exception -> 0x05c3 }
            r6[r7] = r3     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r2 = android.C2492.m612n(r5, r2, r6)     // Catch:{ Exception -> 0x05c3 }
            java.lang.CharSequence r2 = (java.lang.CharSequence) r2     // Catch:{ Exception -> 0x05c3 }
            r3 = 0
            java.lang.Object[] r3 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r2 = android.C2492.m612n(r4, r2, r3)     // Catch:{ Exception -> 0x05c3 }
            java.lang.String r2 = (java.lang.String) r2     // Catch:{ Exception -> 0x05c3 }
            r3 = 30899(0x78b3, float:4.3299E-41)
            java.lang.Object r3 = android.C2490.m592n(r3)     // Catch:{ Exception -> 0x05c3 }
            short[] r3 = (short[]) r3     // Catch:{ Exception -> 0x05c3 }
            r5 = 39369(0x99c9, float:5.5168E-41)
            r6 = 0
            r4 = 1
            java.lang.Object[] r7 = new java.lang.Object[r4]     // Catch:{ Exception -> 0x05c3 }
            r8 = 0
            r4 = 9187(0x23e3, float:1.2874E-41)
            java.lang.Object r4 = android.C2492.m610n(r4)     // Catch:{ Exception -> 0x05c3 }
            java.lang.String r4 = (java.lang.String) r4     // Catch:{ Exception -> 0x05c3 }
            r7[r8] = r4     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r4 = android.C2490.m594n(r5, r6, r7)     // Catch:{ Exception -> 0x05c3 }
            java.lang.Integer r4 = (java.lang.Integer) r4     // Catch:{ Exception -> 0x05c3 }
            int r5 = r4.intValue()     // Catch:{ Exception -> 0x05c3 }
            r6 = 39369(0x99c9, float:5.5168E-41)
            r7 = 0
            r4 = 1
            java.lang.Object[] r8 = new java.lang.Object[r4]     // Catch:{ Exception -> 0x05c3 }
            r9 = 0
            r4 = 47375(0xb90f, float:6.6387E-41)
            java.lang.Object r4 = android.C2492.m610n(r4)     // Catch:{ Exception -> 0x05c3 }
            java.lang.String r4 = (java.lang.String) r4     // Catch:{ Exception -> 0x05c3 }
            r8[r9] = r4     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r4 = android.C2490.m594n(r6, r7, r8)     // Catch:{ Exception -> 0x05c3 }
            java.lang.Integer r4 = (java.lang.Integer) r4     // Catch:{ Exception -> 0x05c3 }
            int r6 = r4.intValue()     // Catch:{ Exception -> 0x05c3 }
            r7 = 39369(0x99c9, float:5.5168E-41)
            r8 = 0
            r4 = 1
            java.lang.Object[] r9 = new java.lang.Object[r4]     // Catch:{ Exception -> 0x05c3 }
            r10 = 0
            r4 = 27981(0x6d4d, float:3.921E-41)
            java.lang.Object r4 = android.C2492.m610n(r4)     // Catch:{ Exception -> 0x05c3 }
            java.lang.String r4 = (java.lang.String) r4     // Catch:{ Exception -> 0x05c3 }
            r9[r10] = r4     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r4 = android.C2490.m594n(r7, r8, r9)     // Catch:{ Exception -> 0x05c3 }
            java.lang.Integer r4 = (java.lang.Integer) r4     // Catch:{ Exception -> 0x05c3 }
            int r4 = r4.intValue()     // Catch:{ Exception -> 0x05c3 }
            r7 = 88474(0x1599a, float:1.23978E-40)
            r8 = 1
            java.lang.Object[] r8 = new java.lang.Object[r8]     // Catch:{ Exception -> 0x05c3 }
            r9 = 0
            r10 = 80494(0x13a6e, float:1.12796E-40)
            r11 = 0
            r12 = 4
            java.lang.Object[] r12 = new java.lang.Object[r12]     // Catch:{ Exception -> 0x05c3 }
            r13 = 0
            r12[r13] = r3     // Catch:{ Exception -> 0x05c3 }
            r3 = 1
            r13 = -1750541(0xffffffffffe549f3, float:NaN)
            r13 = r13 & r6
            r6 = r6 ^ -1
            r14 = 1750540(0x1ab60c, float:2.453029E-39)
            r6 = r6 & r14
            r6 = r6 | r13
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)     // Catch:{ Exception -> 0x05c3 }
            r12[r3] = r6     // Catch:{ Exception -> 0x05c3 }
            r3 = 2
            r6 = -1746764(0xffffffffffe558b4, float:NaN)
            r6 = r6 & r4
            r4 = r4 ^ -1
            r13 = 1746763(0x1aa74b, float:2.447736E-39)
            r4 = r4 & r13
            r4 = r4 | r6
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)     // Catch:{ Exception -> 0x05c3 }
            r12[r3] = r4     // Catch:{ Exception -> 0x05c3 }
            r3 = 3
            r4 = -1749189(0xffffffffffe54f3b, float:NaN)
            r4 = r4 & r5
            r5 = r5 ^ -1
            r6 = 1749188(0x1ab0c4, float:2.451134E-39)
            r5 = r5 & r6
            r4 = r4 | r5
            java.lang.Integer r4 = java.lang.Integer.valueOf(r4)     // Catch:{ Exception -> 0x05c3 }
            r12[r3] = r4     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r3 = android.C2490.m594n(r10, r11, r12)     // Catch:{ Exception -> 0x05c3 }
            java.lang.String r3 = (java.lang.String) r3     // Catch:{ Exception -> 0x05c3 }
            r8[r9] = r3     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r3 = android.C2492.m612n(r7, r2, r8)     // Catch:{ Exception -> 0x05c3 }
            java.lang.Boolean r3 = (java.lang.Boolean) r3     // Catch:{ Exception -> 0x05c3 }
            boolean r4 = r3.booleanValue()     // Catch:{ Exception -> 0x05c3 }
            r3 = 1616(0x650, float:2.264E-42)
        L_0x030d:
            r3 = r3 ^ 1633(0x661, float:2.288E-42)
            switch(r3) {
                case 14: goto L_0x0313;
                case 49: goto L_0x0316;
                case 204: goto L_0x031b;
                case 239: goto L_0x0441;
                default: goto L_0x0312;
            }     // Catch:{ Exception -> 0x05c3 }
        L_0x0312:
            goto L_0x030d
        L_0x0313:
            r3 = 1678(0x68e, float:2.351E-42)
            goto L_0x030d
        L_0x0316:
            if (r4 != 0) goto L_0x0313
            r3 = 1709(0x6ad, float:2.395E-42)
            goto L_0x030d
        L_0x031b:
            r3 = 13855(0x361f, float:1.9415E-41)
            r1 = 10940(0x2abc, float:1.533E-41)
            java.lang.Object r1 = android.C2492.m610n(r1)     // Catch:{ Exception -> 0x05c3 }
            android.content.SharedPreferences r1 = (android.content.SharedPreferences) r1     // Catch:{ Exception -> 0x05c3 }
            r4 = 2
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch:{ Exception -> 0x05c3 }
            r5 = 0
            r4[r5] = r0     // Catch:{ Exception -> 0x05c3 }
            r5 = 1
            r6 = 0
            java.lang.Boolean r6 = java.lang.Boolean.valueOf(r6)     // Catch:{ Exception -> 0x05c3 }
            r4[r5] = r6     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r1 = android.C2492.m612n(r3, r1, r4)     // Catch:{ Exception -> 0x05c3 }
            java.lang.Boolean r1 = (java.lang.Boolean) r1     // Catch:{ Exception -> 0x05c3 }
            boolean r3 = r1.booleanValue()     // Catch:{ Exception -> 0x05c3 }
            r1 = 1740(0x6cc, float:2.438E-42)
        L_0x033f:
            r1 = r1 ^ 1757(0x6dd, float:2.462E-42)
            switch(r1) {
                case 17: goto L_0x0345;
                case 54: goto L_0x034b;
                case 471: goto L_0x0561;
                case 500: goto L_0x034e;
                default: goto L_0x0344;
            }     // Catch:{ Exception -> 0x05c3 }
        L_0x0344:
            goto L_0x033f
        L_0x0345:
            r1 = 1
            if (r3 == r1) goto L_0x034b
            r1 = 1833(0x729, float:2.569E-42)
            goto L_0x033f
        L_0x034b:
            r1 = 1802(0x70a, float:2.525E-42)
            goto L_0x033f
        L_0x034e:
            r1 = 30899(0x78b3, float:4.3299E-41)
            java.lang.Object r1 = android.C2490.m592n(r1)     // Catch:{ Exception -> 0x05c3 }
            short[] r1 = (short[]) r1     // Catch:{ Exception -> 0x05c3 }
            r4 = 39369(0x99c9, float:5.5168E-41)
            r5 = 0
            r3 = 1
            java.lang.Object[] r6 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x05c3 }
            r7 = 0
            r3 = 5042(0x13b2, float:7.065E-42)
            java.lang.Object r3 = android.C2492.m610n(r3)     // Catch:{ Exception -> 0x05c3 }
            java.lang.String r3 = (java.lang.String) r3     // Catch:{ Exception -> 0x05c3 }
            r6[r7] = r3     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r3 = android.C2490.m594n(r4, r5, r6)     // Catch:{ Exception -> 0x05c3 }
            java.lang.Integer r3 = (java.lang.Integer) r3     // Catch:{ Exception -> 0x05c3 }
            int r4 = r3.intValue()     // Catch:{ Exception -> 0x05c3 }
            r5 = 39369(0x99c9, float:5.5168E-41)
            r6 = 0
            r3 = 1
            java.lang.Object[] r7 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x05c3 }
            r8 = 0
            r3 = 86640(0x15270, float:1.21408E-40)
            java.lang.Object r3 = android.C2492.m610n(r3)     // Catch:{ Exception -> 0x05c3 }
            java.lang.String r3 = (java.lang.String) r3     // Catch:{ Exception -> 0x05c3 }
            r7[r8] = r3     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r3 = android.C2490.m594n(r5, r6, r7)     // Catch:{ Exception -> 0x05c3 }
            java.lang.Integer r3 = (java.lang.Integer) r3     // Catch:{ Exception -> 0x05c3 }
            int r5 = r3.intValue()     // Catch:{ Exception -> 0x05c3 }
            r6 = 39369(0x99c9, float:5.5168E-41)
            r7 = 0
            r3 = 1
            java.lang.Object[] r8 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x05c3 }
            r9 = 0
            r3 = 33123(0x8163, float:4.6415E-41)
            java.lang.Object r3 = android.C2492.m610n(r3)     // Catch:{ Exception -> 0x05c3 }
            java.lang.String r3 = (java.lang.String) r3     // Catch:{ Exception -> 0x05c3 }
            r8[r9] = r3     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r3 = android.C2490.m594n(r6, r7, r8)     // Catch:{ Exception -> 0x05c3 }
            java.lang.Integer r3 = (java.lang.Integer) r3     // Catch:{ Exception -> 0x05c3 }
            int r3 = r3.intValue()     // Catch:{ Exception -> 0x05c3 }
            r6 = 80237(0x1396d, float:1.12436E-40)
            r7 = 0
            r8 = 2
            java.lang.Object[] r8 = new java.lang.Object[r8]     // Catch:{ Exception -> 0x05c3 }
            r9 = 0
            r8[r9] = r2     // Catch:{ Exception -> 0x05c3 }
            r2 = 1
            r9 = 28608(0x6fc0, float:4.0088E-41)
            r10 = 0
            r11 = 4
            java.lang.Object[] r11 = new java.lang.Object[r11]     // Catch:{ Exception -> 0x05c3 }
            r12 = 0
            r11[r12] = r1     // Catch:{ Exception -> 0x05c3 }
            r1 = 1
            r12 = -1748723(0xffffffffffe5510d, float:NaN)
            r12 = r12 & r5
            r5 = r5 ^ -1
            r13 = 1748722(0x1aaef2, float:2.450481E-39)
            r5 = r5 & r13
            r5 = r5 | r12
            java.lang.Integer r5 = java.lang.Integer.valueOf(r5)     // Catch:{ Exception -> 0x05c3 }
            r11[r1] = r5     // Catch:{ Exception -> 0x05c3 }
            r1 = 2
            r5 = -1752626(0xffffffffffe541ce, float:NaN)
            r5 = r5 & r3
            r3 = r3 ^ -1
            r12 = 1752625(0x1abe31, float:2.455951E-39)
            r3 = r3 & r12
            r3 = r3 | r5
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)     // Catch:{ Exception -> 0x05c3 }
            r11[r1] = r3     // Catch:{ Exception -> 0x05c3 }
            r1 = 3
            r3 = -1753679(0xffffffffffe53db1, float:NaN)
            r3 = r3 & r4
            r4 = r4 ^ -1
            r5 = 1753678(0x1ac24e, float:2.457426E-39)
            r4 = r4 & r5
            r3 = r3 | r4
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)     // Catch:{ Exception -> 0x05c3 }
            r11[r1] = r3     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r1 = android.C2492.m612n(r9, r10, r11)     // Catch:{ Exception -> 0x05c3 }
            java.lang.String r1 = (java.lang.String) r1     // Catch:{ Exception -> 0x05c3 }
            r8[r2] = r1     // Catch:{ Exception -> 0x05c3 }
            android.C2492.m612n(r6, r7, r8)     // Catch:{ Exception -> 0x05c3 }
            r2 = 47747(0xba83, float:6.6908E-41)
            r3 = 99471(0x1848f, float:1.39389E-40)
            r4 = 85148(0x14c9c, float:1.19318E-40)
            r1 = 10940(0x2abc, float:1.533E-41)
            java.lang.Object r1 = android.C2492.m610n(r1)     // Catch:{ Exception -> 0x05c3 }
            android.content.SharedPreferences r1 = (android.content.SharedPreferences) r1     // Catch:{ Exception -> 0x05c3 }
            r5 = 0
            java.lang.Object[] r5 = new java.lang.Object[r5]     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r1 = android.C2492.m612n(r4, r1, r5)     // Catch:{ Exception -> 0x05c3 }
            android.content.SharedPreferences$Editor r1 = (android.content.SharedPreferences.Editor) r1     // Catch:{ Exception -> 0x05c3 }
            r4 = 2
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch:{ Exception -> 0x05c3 }
            r5 = 0
            r4[r5] = r0     // Catch:{ Exception -> 0x05c3 }
            r0 = 1
            r5 = 1
            java.lang.Boolean r5 = java.lang.Boolean.valueOf(r5)     // Catch:{ Exception -> 0x05c3 }
            r4[r0] = r5     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r0 = android.C2492.m612n(r3, r1, r4)     // Catch:{ Exception -> 0x05c3 }
            android.content.SharedPreferences$Editor r0 = (android.content.SharedPreferences.Editor) r0     // Catch:{ Exception -> 0x05c3 }
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch:{ Exception -> 0x05c3 }
            android.C2492.m612n(r2, r0, r1)     // Catch:{ Exception -> 0x05c3 }
            r0 = 1864(0x748, float:2.612E-42)
        L_0x0437:
            r0 = r0 ^ 1881(0x759, float:2.636E-42)
            switch(r0) {
                case 17: goto L_0x043d;
                case 47483: goto L_0x0561;
                default: goto L_0x043c;
            }     // Catch:{ Exception -> 0x05c3 }
        L_0x043c:
            goto L_0x0437
        L_0x043d:
            r0 = 48674(0xbe22, float:6.8207E-41)
            goto L_0x0437
        L_0x0441:
            r3 = 13855(0x361f, float:1.9415E-41)
            r0 = 10940(0x2abc, float:1.533E-41)
            java.lang.Object r0 = android.C2492.m610n(r0)     // Catch:{ Exception -> 0x05c3 }
            android.content.SharedPreferences r0 = (android.content.SharedPreferences) r0     // Catch:{ Exception -> 0x05c3 }
            r4 = 2
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch:{ Exception -> 0x05c3 }
            r5 = 0
            r4[r5] = r1     // Catch:{ Exception -> 0x05c3 }
            r5 = 1
            r6 = 0
            java.lang.Boolean r6 = java.lang.Boolean.valueOf(r6)     // Catch:{ Exception -> 0x05c3 }
            r4[r5] = r6     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r0 = android.C2492.m612n(r3, r0, r4)     // Catch:{ Exception -> 0x05c3 }
            java.lang.Boolean r0 = (java.lang.Boolean) r0     // Catch:{ Exception -> 0x05c3 }
            boolean r3 = r0.booleanValue()     // Catch:{ Exception -> 0x05c3 }
            r0 = 48767(0xbe7f, float:6.8337E-41)
        L_0x0466:
            r4 = 48784(0xbe90, float:6.8361E-41)
            r0 = r0 ^ r4
            switch(r0) {
                case 14: goto L_0x046e;
                case 45: goto L_0x0561;
                case 76: goto L_0x0479;
                case 239: goto L_0x0472;
                default: goto L_0x046d;
            }     // Catch:{ Exception -> 0x05c3 }
        L_0x046d:
            goto L_0x0466
        L_0x046e:
            r0 = 48829(0xbebd, float:6.8424E-41)
            goto L_0x0466
        L_0x0472:
            r0 = 1
            if (r3 == r0) goto L_0x046e
            r0 = 48860(0xbedc, float:6.8467E-41)
            goto L_0x0466
        L_0x0479:
            r0 = 30899(0x78b3, float:4.3299E-41)
            java.lang.Object r0 = android.C2490.m592n(r0)     // Catch:{ Exception -> 0x05c3 }
            short[] r0 = (short[]) r0     // Catch:{ Exception -> 0x05c3 }
            r4 = 39369(0x99c9, float:5.5168E-41)
            r5 = 0
            r3 = 1
            java.lang.Object[] r6 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x05c3 }
            r7 = 0
            r3 = 57509(0xe0a5, float:8.0587E-41)
            java.lang.Object r3 = android.C2492.m610n(r3)     // Catch:{ Exception -> 0x05c3 }
            java.lang.String r3 = (java.lang.String) r3     // Catch:{ Exception -> 0x05c3 }
            r6[r7] = r3     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r3 = android.C2490.m594n(r4, r5, r6)     // Catch:{ Exception -> 0x05c3 }
            java.lang.Integer r3 = (java.lang.Integer) r3     // Catch:{ Exception -> 0x05c3 }
            int r4 = r3.intValue()     // Catch:{ Exception -> 0x05c3 }
            r5 = 39369(0x99c9, float:5.5168E-41)
            r6 = 0
            r3 = 1
            java.lang.Object[] r7 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x05c3 }
            r8 = 0
            r3 = 75454(0x126be, float:1.05734E-40)
            java.lang.Object r3 = android.C2492.m610n(r3)     // Catch:{ Exception -> 0x05c3 }
            java.lang.String r3 = (java.lang.String) r3     // Catch:{ Exception -> 0x05c3 }
            r7[r8] = r3     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r3 = android.C2490.m594n(r5, r6, r7)     // Catch:{ Exception -> 0x05c3 }
            java.lang.Integer r3 = (java.lang.Integer) r3     // Catch:{ Exception -> 0x05c3 }
            int r5 = r3.intValue()     // Catch:{ Exception -> 0x05c3 }
            r6 = 39369(0x99c9, float:5.5168E-41)
            r7 = 0
            r3 = 1
            java.lang.Object[] r8 = new java.lang.Object[r3]     // Catch:{ Exception -> 0x05c3 }
            r9 = 0
            r3 = 90888(0x16308, float:1.27361E-40)
            java.lang.Object r3 = android.C2492.m610n(r3)     // Catch:{ Exception -> 0x05c3 }
            java.lang.String r3 = (java.lang.String) r3     // Catch:{ Exception -> 0x05c3 }
            r8[r9] = r3     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r3 = android.C2490.m594n(r6, r7, r8)     // Catch:{ Exception -> 0x05c3 }
            java.lang.Integer r3 = (java.lang.Integer) r3     // Catch:{ Exception -> 0x05c3 }
            int r3 = r3.intValue()     // Catch:{ Exception -> 0x05c3 }
            r6 = 80237(0x1396d, float:1.12436E-40)
            r7 = 0
            r8 = 2
            java.lang.Object[] r8 = new java.lang.Object[r8]     // Catch:{ Exception -> 0x05c3 }
            r9 = 0
            r8[r9] = r2     // Catch:{ Exception -> 0x05c3 }
            r2 = 1
            r9 = 28608(0x6fc0, float:4.0088E-41)
            r10 = 0
            r11 = 4
            java.lang.Object[] r11 = new java.lang.Object[r11]     // Catch:{ Exception -> 0x05c3 }
            r12 = 0
            r11[r12] = r0     // Catch:{ Exception -> 0x05c3 }
            r0 = 1
            r12 = -1751620(0xffffffffffe545bc, float:NaN)
            r12 = r12 & r5
            r5 = r5 ^ -1
            r13 = 1751619(0x1aba43, float:2.454541E-39)
            r5 = r5 & r13
            r5 = r5 | r12
            java.lang.Integer r5 = java.lang.Integer.valueOf(r5)     // Catch:{ Exception -> 0x05c3 }
            r11[r0] = r5     // Catch:{ Exception -> 0x05c3 }
            r0 = 2
            r5 = -1755368(0xffffffffffe53718, float:NaN)
            r5 = r5 & r3
            r3 = r3 ^ -1
            r12 = 1755367(0x1ac8e7, float:2.459793E-39)
            r3 = r3 & r12
            r3 = r3 | r5
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)     // Catch:{ Exception -> 0x05c3 }
            r11[r0] = r3     // Catch:{ Exception -> 0x05c3 }
            r0 = 3
            r3 = -1751299(0xffffffffffe546fd, float:NaN)
            r3 = r3 & r4
            r4 = r4 ^ -1
            r5 = 1751298(0x1ab902, float:2.454091E-39)
            r4 = r4 & r5
            r3 = r3 | r4
            java.lang.Integer r3 = java.lang.Integer.valueOf(r3)     // Catch:{ Exception -> 0x05c3 }
            r11[r0] = r3     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r0 = android.C2492.m612n(r9, r10, r11)     // Catch:{ Exception -> 0x05c3 }
            java.lang.String r0 = (java.lang.String) r0     // Catch:{ Exception -> 0x05c3 }
            r8[r2] = r0     // Catch:{ Exception -> 0x05c3 }
            android.C2492.m612n(r6, r7, r8)     // Catch:{ Exception -> 0x05c3 }
            r2 = 47747(0xba83, float:6.6908E-41)
            r3 = 99471(0x1848f, float:1.39389E-40)
            r4 = 85148(0x14c9c, float:1.19318E-40)
            r0 = 10940(0x2abc, float:1.533E-41)
            java.lang.Object r0 = android.C2492.m610n(r0)     // Catch:{ Exception -> 0x05c3 }
            android.content.SharedPreferences r0 = (android.content.SharedPreferences) r0     // Catch:{ Exception -> 0x05c3 }
            r5 = 0
            java.lang.Object[] r5 = new java.lang.Object[r5]     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r0 = android.C2492.m612n(r4, r0, r5)     // Catch:{ Exception -> 0x05c3 }
            android.content.SharedPreferences$Editor r0 = (android.content.SharedPreferences.Editor) r0     // Catch:{ Exception -> 0x05c3 }
            r4 = 2
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch:{ Exception -> 0x05c3 }
            r5 = 0
            r4[r5] = r1     // Catch:{ Exception -> 0x05c3 }
            r1 = 1
            r5 = 1
            java.lang.Boolean r5 = java.lang.Boolean.valueOf(r5)     // Catch:{ Exception -> 0x05c3 }
            r4[r1] = r5     // Catch:{ Exception -> 0x05c3 }
            java.lang.Object r0 = android.C2492.m612n(r3, r0, r4)     // Catch:{ Exception -> 0x05c3 }
            android.content.SharedPreferences$Editor r0 = (android.content.SharedPreferences.Editor) r0     // Catch:{ Exception -> 0x05c3 }
            r1 = 0
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch:{ Exception -> 0x05c3 }
            android.C2492.m612n(r2, r0, r1)     // Catch:{ Exception -> 0x05c3 }
        L_0x0561:
            r0 = 31736(0x7bf8, float:4.4472E-41)
            r1 = 0
            r2 = 0
            java.lang.Object[] r2 = new java.lang.Object[r2]
            java.lang.Object r0 = android.C2492.m612n(r0, r1, r2)
            java.lang.Integer r0 = (java.lang.Integer) r0
            int r1 = r0.intValue()
            r0 = 48891(0xbefb, float:6.8511E-41)
        L_0x0574:
            r2 = 48908(0xbf0c, float:6.8535E-41)
            r0 = r0 ^ r2
            switch(r0) {
                case 22: goto L_0x057c;
                case 53: goto L_0x05c2;
                case 503: goto L_0x0580;
                case 32495: goto L_0x0586;
                default: goto L_0x057b;
            }
        L_0x057b:
            goto L_0x0574
        L_0x057c:
            r0 = 48953(0xbf39, float:6.8598E-41)
            goto L_0x0574
        L_0x0580:
            if (r1 > 0) goto L_0x057c
            r0 = 49635(0xc1e3, float:6.9553E-41)
            goto L_0x0574
        L_0x0586:
            r1 = 34760(0x87c8, float:4.8709E-41)
            r2 = 0
            r0 = 1
            java.lang.Object[] r3 = new java.lang.Object[r0]
            r4 = 0
            r5 = 50197(0xc415, float:7.0341E-41)
            r6 = 0
            r0 = 1
            java.lang.Object[] r7 = new java.lang.Object[r0]
            r8 = 0
            r0 = 12406(0x3076, float:1.7385E-41)
            java.lang.Object r0 = android.C2492.m610n(r0)
            java.lang.String r0 = (java.lang.String) r0
            r7[r8] = r0
            java.lang.Object r0 = android.C2490.m594n(r5, r6, r7)
            java.lang.String r0 = (java.lang.String) r0
            r3[r4] = r0
            java.lang.Object r0 = android.C2492.m612n(r1, r2, r3)
            java.lang.Double r0 = (java.lang.Double) r0
            r2 = 74243(0x12203, float:1.04037E-40)
            r1 = 3740(0xe9c, float:5.241E-42)
            java.lang.Object r1 = android.C2490.m592n(r1)
            java.io.PrintStream r1 = (java.io.PrintStream) r1
            r3 = 1
            java.lang.Object[] r3 = new java.lang.Object[r3]
            r4 = 0
            r3[r4] = r0
            android.C2492.m612n(r2, r1, r3)
        L_0x05c2:
            return
        L_0x05c3:
            r0 = move-exception
            r0 = 49666(0xc202, float:6.9597E-41)
        L_0x05c7:
            r1 = 49683(0xc213, float:6.9621E-41)
            r0 = r0 ^ r1
            switch(r0) {
                case 17: goto L_0x05cf;
                case 50: goto L_0x0561;
                default: goto L_0x05ce;
            }
        L_0x05ce:
            goto L_0x05c7
        L_0x05cf:
            r0 = 49697(0xc221, float:6.964E-41)
            goto L_0x05c7
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.p001v4.appcompat.library.BottomSheetDialog.run(android.content.Context, android.app.Activity):void");
    }
}
