package android;

import java.lang.reflect.Method;

/* renamed from: android.⁣⁣⁣⁣⁣⁠⁤⁤⁠⁤⁠⁤⁠⁤⁠  reason: contains not printable characters */
public class C2495 {

    /* renamed from: ⁣⁤⁠⁠⁠⁣⁤⁤⁣⁤⁤⁤⁣⁣⁤⁤⁣⁠  reason: not valid java name and contains not printable characters */
    public static int f18640 = 92;

    /* renamed from: ⁠⁣⁣⁠⁣⁣  reason: not valid java name and contains not printable characters */
    public static Method[] m17448(Object obj) {
        int r1 = C2489.m17433();
        char c = 30801;
        while (true) {
            c ^= 30818;
            switch (c) {
                case '3':
                    if (r1 <= 0) {
                        c = 30894;
                        break;
                    }
                case 18:
                    c = 30863;
                    break;
                case 204:
                    return ((Class) obj).getDeclaredMethods();
                case 237:
                    char c2 = 30925;
                    while (true) {
                        c2 ^= 30942;
                        switch (c2) {
                            case 19:
                                c2 = 30956;
                                break;
                            case '2':
                                return null;
                        }
                    }
                    break;
            }
        }
    }

    /* renamed from: ⁠⁣⁤⁣⁤⁠⁣⁣⁣⁣⁤⁤⁤⁠⁤⁠  reason: not valid java name and contains not printable characters */
    public static Object m17449(Object obj, Object obj2, Object obj3) {
        int r1 = m17455();
        char c = 31700;
        while (true) {
            c ^= 31717;
            switch (c) {
                case '1':
                    if (r1 < 0) {
                        c = 31793;
                        break;
                    }
                case 22:
                    c = 31762;
                    break;
                case 2004:
                    return ((Method) obj).invoke(obj2, (Object[]) obj3);
                case 2039:
                    char c2 = 31824;
                    while (true) {
                        c2 ^= 31841;
                        switch (c2) {
                            case 14:
                                return null;
                            case '1':
                                c2 = 31855;
                                break;
                        }
                    }
                    break;
            }
        }
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ⁠⁣⁤⁣⁤⁠⁣⁣⁤⁤⁣⁠⁣⁤⁣⁠⁣⁤⁤  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String m17450(java.lang.Object r3) {
        /*
            int r1 = android.C2489.m17433()
            r0 = 1604812(0x187ccc, float:2.24882E-39)
        L_0x0007:
            r2 = 1604829(0x187cdd, float:2.248844E-39)
            r0 = r0 ^ r2
            switch(r0) {
                case 17: goto L_0x000f;
                case 840: goto L_0x0020;
                case 873: goto L_0x0019;
                case 939: goto L_0x0015;
                default: goto L_0x000e;
            }
        L_0x000e:
            goto L_0x0007
        L_0x000f:
            if (r1 >= 0) goto L_0x0015
            r0 = 1605556(0x187fb4, float:2.249863E-39)
            goto L_0x0007
        L_0x0015:
            r0 = 1605525(0x187f95, float:2.24982E-39)
            goto L_0x0007
        L_0x0019:
            java.lang.Class r3 = (java.lang.Class) r3
            java.lang.String r0 = r3.getName()
        L_0x001f:
            return r0
        L_0x0020:
            r0 = 0
            r1 = 1605587(0x187fd3, float:2.249907E-39)
        L_0x0024:
            r2 = 1605604(0x187fe4, float:2.24993E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 22: goto L_0x001f;
                case 55: goto L_0x002c;
                default: goto L_0x002b;
            }
        L_0x002b:
            goto L_0x0024
        L_0x002c:
            r1 = 1605618(0x187ff2, float:2.24995E-39)
            goto L_0x0024
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2495.m17450(java.lang.Object):java.lang.String");
    }

    /* renamed from: ⁣⁣⁣⁣⁣⁠⁣⁠⁠⁤⁠⁣⁣⁤⁠⁠⁣  reason: not valid java name and contains not printable characters */
    public static Method[] m17451(Object obj) {
        int r1 = C2493.m17445();
        char c = 32847;
        while (true) {
            c ^= 32864;
            switch (c) {
                case '/':
                    if (r1 > 0) {
                        c = 53772;
                        break;
                    }
                case 14:
                    c = 32909;
                    break;
                case 237:
                    char c2 = 53803;
                    while (true) {
                        c2 ^= 53820;
                        switch (c2) {
                            case 23:
                                c2 = 53834;
                                break;
                            case 'v':
                                return null;
                        }
                    }
                    break;
                case 21100:
                    return ((Class) obj).getMethods();
            }
        }
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ⁣⁣⁣⁣⁣⁠⁣⁤⁠⁠⁣⁣⁤⁤⁣⁤⁤⁤  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.reflect.Method m17452(java.lang.Object r3, java.lang.Object r4, java.lang.Object r5, java.lang.Object r6, java.lang.Object r7) {
        /*
            int r1 = android.C2494.m17446()
            r0 = 1626791(0x18d2a7, float:2.27962E-39)
        L_0x0007:
            r2 = 1626808(0x18d2b8, float:2.279644E-39)
            r0 = r0 ^ r2
            switch(r0) {
                case 31: goto L_0x000f;
                case 93: goto L_0x0028;
                case 126: goto L_0x0015;
                case 444: goto L_0x0019;
                default: goto L_0x000e;
            }
        L_0x000e:
            goto L_0x0007
        L_0x000f:
            if (r1 > 0) goto L_0x0015
            r0 = 1626884(0x18d304, float:2.27975E-39)
            goto L_0x0007
        L_0x0015:
            r0 = 1626853(0x18d2e5, float:2.279707E-39)
            goto L_0x0007
        L_0x0019:
            java.lang.String r3 = (java.lang.String) r3
            java.lang.reflect.Method[] r4 = (java.lang.reflect.Method[]) r4
            java.lang.String r5 = (java.lang.String) r5
            java.lang.String r6 = (java.lang.String) r6
            java.lang.String[] r7 = (java.lang.String[]) r7
            java.lang.reflect.Method r0 = android.C2489.m17413(r3, r4, r5, r6, r7)
        L_0x0027:
            return r0
        L_0x0028:
            r0 = 0
            r1 = 1626915(0x18d323, float:2.279793E-39)
        L_0x002c:
            r2 = 1626932(0x18d334, float:2.279817E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 23: goto L_0x0034;
                case 1785: goto L_0x0027;
                default: goto L_0x0033;
            }
        L_0x0033:
            goto L_0x002c
        L_0x0034:
            r1 = 1627597(0x18d5cd, float:2.280749E-39)
            goto L_0x002c
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2495.m17452(java.lang.Object, java.lang.Object, java.lang.Object, java.lang.Object, java.lang.Object):java.lang.reflect.Method");
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ⁣⁣⁣⁣⁣⁠⁣⁤⁣⁠⁣⁤⁣⁣⁤⁠⁠⁣  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String m17453() {
        /*
            int r1 = android.C2494.m17446()
            r0 = 1627690(0x18d62a, float:2.28088E-39)
        L_0x0007:
            r2 = 1627707(0x18d63b, float:2.280903E-39)
            r0 = r0 ^ r2
            switch(r0) {
                case 17: goto L_0x000f;
                case 83: goto L_0x001c;
                case 114: goto L_0x0015;
                case 188: goto L_0x0019;
                default: goto L_0x000e;
            }
        L_0x000e:
            goto L_0x0007
        L_0x000f:
            if (r1 >= 0) goto L_0x0015
            r0 = 1627783(0x18d687, float:2.28101E-39)
            goto L_0x0007
        L_0x0015:
            r0 = 1627752(0x18d668, float:2.280966E-39)
            goto L_0x0007
        L_0x0019:
            java.lang.String r0 = "۟ۦۙ"
        L_0x001b:
            return r0
        L_0x001c:
            r0 = 0
            r1 = 1627814(0x18d6a6, float:2.281053E-39)
        L_0x0020:
            r2 = 1627831(0x18d6b7, float:2.281077E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 17: goto L_0x0028;
                case 114: goto L_0x001b;
                default: goto L_0x0027;
            }
        L_0x0027:
            goto L_0x0020
        L_0x0028:
            r1 = 1627845(0x18d6c5, float:2.281097E-39)
            goto L_0x0020
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2495.m17453():java.lang.String");
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ⁣⁣⁣⁣⁣⁤⁠⁤⁣⁠⁤⁤  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String m17454() {
        /*
            int r1 = android.C2493.m17445()
            r0 = 1628589(0x18d9ad, float:2.282139E-39)
        L_0x0007:
            r2 = 1628606(0x18d9be, float:2.282163E-39)
            r0 = r0 ^ r2
            switch(r0) {
                case 19: goto L_0x000f;
                case 85: goto L_0x001c;
                case 114: goto L_0x0015;
                case 948: goto L_0x0019;
                default: goto L_0x000e;
            }
        L_0x000e:
            goto L_0x0007
        L_0x000f:
            if (r1 <= 0) goto L_0x0015
            r0 = 1628682(0x18da0a, float:2.28227E-39)
            goto L_0x0007
        L_0x0015:
            r0 = 1628651(0x18d9eb, float:2.282226E-39)
            goto L_0x0007
        L_0x0019:
            java.lang.String r0 = "۫ۗۡ"
        L_0x001b:
            return r0
        L_0x001c:
            r0 = 0
            r1 = 1628713(0x18da29, float:2.282313E-39)
        L_0x0020:
            r2 = 1628730(0x18da3a, float:2.282337E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 19: goto L_0x0028;
                case 114: goto L_0x001b;
                default: goto L_0x0027;
            }
        L_0x0027:
            goto L_0x0020
        L_0x0028:
            r1 = 1628744(0x18da48, float:2.282356E-39)
            goto L_0x0020
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2495.m17454():java.lang.String");
    }

    /* renamed from: ⁣⁤⁠⁠⁠⁣⁤⁣⁠⁣⁤⁤⁠⁠⁠⁣⁣⁣  reason: not valid java name and contains not printable characters */
    public static int m17455() {
        int i = 0;
        String str = "ۗۚۦ";
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        while (true) {
            switch (C2489.m17426((Object) str)) {
                case 1738851:
                    i4 = C2489.m17426((Object) "ۜ۟۟");
                    str = "ۨۡۜ";
                    break;
                case 1739053:
                    i2 = i3 & -1743790;
                    str = "ۗۨۚ";
                    break;
                case 1739273:
                    i3 = 1743789;
                    str = "۠ۢ۫";
                    break;
                case 1740958:
                    i3 = i | i2;
                    str = "ۢ۠ۜ";
                    break;
                case 1749598:
                    return i3;
                case 1755395:
                    i3 = i4 ^ -1;
                    str = "ۗۡۗ";
                    break;
                default:
                    i = i3 & i4;
                    str = "ۙ۠ۥ";
                    break;
            }
        }
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ⁣⁤⁣⁠⁣⁤⁤⁣⁤⁠⁠⁤  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.Object m17456(java.lang.Object r3, java.lang.Object r4, java.lang.Object r5) {
        /*
            int r1 = android.C2489.m17433()
            r0 = 1628837(0x18daa5, float:2.282487E-39)
        L_0x0007:
            r2 = 1628854(0x18dab6, float:2.28251E-39)
            r0 = r0 ^ r2
            switch(r0) {
                case 19: goto L_0x000f;
                case 1851: goto L_0x0019;
                case 2008: goto L_0x0024;
                case 2041: goto L_0x0015;
                default: goto L_0x000e;
            }
        L_0x000e:
            goto L_0x0007
        L_0x000f:
            if (r1 > 0) goto L_0x0015
            r0 = 1629581(0x18dd8d, float:2.28353E-39)
            goto L_0x0007
        L_0x0015:
            r0 = 1629550(0x18dd6e, float:2.283486E-39)
            goto L_0x0007
        L_0x0019:
            java.lang.String r3 = (java.lang.String) r3
            java.lang.String r4 = (java.lang.String) r4
            java.lang.reflect.Field[] r5 = (java.lang.reflect.Field[]) r5
            java.lang.Object r0 = android.C2489.m17408((java.lang.String) r3, (java.lang.String) r4, (java.lang.reflect.Field[]) r5)
        L_0x0023:
            return r0
        L_0x0024:
            r0 = 0
            r1 = 1629612(0x18ddac, float:2.283573E-39)
        L_0x0028:
            r2 = 1629629(0x18ddbd, float:2.283597E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 17: goto L_0x0030;
                case 118: goto L_0x0023;
                default: goto L_0x002f;
            }
        L_0x002f:
            goto L_0x0028
        L_0x0030:
            r1 = 1629643(0x18ddcb, float:2.283616E-39)
            goto L_0x0028
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2495.m17456(java.lang.Object, java.lang.Object, java.lang.Object):java.lang.Object");
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ⁤⁠⁤⁤⁤⁠⁤⁣⁣⁣⁣⁣⁤⁤  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String m17457(short[] r5, int r6, int r7, int r8) {
        /*
            char[] r2 = new char[r7]
            r0 = 0
        L_0x0003:
            r1 = 1629736(0x18de28, float:2.283747E-39)
        L_0x0006:
            r3 = 1629753(0x18de39, float:2.28377E-39)
            r1 = r1 ^ r3
            switch(r1) {
                case 17: goto L_0x000e;
                case 95: goto L_0x003b;
                case 126: goto L_0x0014;
                case 16169: goto L_0x0018;
                default: goto L_0x000d;
            }
        L_0x000d:
            goto L_0x0006
        L_0x000e:
            if (r0 >= r7) goto L_0x0014
            r1 = 1630480(0x18e110, float:2.284789E-39)
            goto L_0x0006
        L_0x0014:
            r1 = 1629798(0x18de66, float:2.283833E-39)
            goto L_0x0006
        L_0x0018:
            int r1 = r6 + 5
            int r1 = r1 + r0
            int r1 = r1 + -5
            short r1 = r5[r1]
            r3 = r1 ^ -1
            r3 = r3 & r8
            r4 = r8 ^ -1
            r1 = r1 & r4
            r1 = r1 | r3
            char r1 = (char) r1
            char r1 = (char) r1
            r2[r0] = r1
            int r0 = r0 + 1
            r1 = 1630511(0x18e12f, float:2.284833E-39)
        L_0x002f:
            r3 = 1630528(0x18e140, float:2.284856E-39)
            r1 = r1 ^ r3
            switch(r1) {
                case 14: goto L_0x0003;
                case 111: goto L_0x0037;
                default: goto L_0x0036;
            }
        L_0x0036:
            goto L_0x002f
        L_0x0037:
            r1 = 1630542(0x18e14e, float:2.284876E-39)
            goto L_0x002f
        L_0x003b:
            java.lang.String r0 = new java.lang.String
            r0.<init>(r2)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2495.m17457(short[], int, int, int):java.lang.String");
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ⁤⁤⁠⁤⁤⁠⁠⁠⁣⁣⁠⁣⁣⁣⁣⁤⁤  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.Class m17458(java.lang.Object r3) {
        /*
            int r1 = android.C2494.m17446()
            r0 = 1630635(0x18e1ab, float:2.285006E-39)
        L_0x0007:
            r2 = 1630652(0x18e1bc, float:2.28503E-39)
            r0 = r0 ^ r2
            switch(r0) {
                case 23: goto L_0x000f;
                case 85: goto L_0x0020;
                case 118: goto L_0x0015;
                case 948: goto L_0x0019;
                default: goto L_0x000e;
            }
        L_0x000e:
            goto L_0x0007
        L_0x000f:
            if (r1 > 0) goto L_0x0015
            r0 = 1630728(0x18e208, float:2.285137E-39)
            goto L_0x0007
        L_0x0015:
            r0 = 1630697(0x18e1e9, float:2.285093E-39)
            goto L_0x0007
        L_0x0019:
            java.lang.reflect.Field r3 = (java.lang.reflect.Field) r3
            java.lang.Class r0 = r3.getType()
        L_0x001f:
            return r0
        L_0x0020:
            r0 = 0
            r1 = 1630759(0x18e227, float:2.28518E-39)
        L_0x0024:
            r2 = 1630776(0x18e238, float:2.285204E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 31: goto L_0x002c;
                case 1769: goto L_0x001f;
                default: goto L_0x002b;
            }
        L_0x002b:
            goto L_0x0024
        L_0x002c:
            r1 = 1631441(0x18e4d1, float:2.286136E-39)
            goto L_0x0024
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2495.m17458(java.lang.Object):java.lang.Class");
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ⁤⁤⁠⁤⁤⁠⁣⁤⁣⁤⁣⁠⁠⁣  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String m17459() {
        /*
            int r1 = android.C2494.m17446()
            r0 = 1631534(0x18e52e, float:2.286266E-39)
        L_0x0007:
            r2 = 1631551(0x18e53f, float:2.28629E-39)
            r0 = r0 ^ r2
            switch(r0) {
                case 17: goto L_0x000f;
                case 83: goto L_0x001c;
                case 114: goto L_0x0015;
                case 180: goto L_0x0019;
                default: goto L_0x000e;
            }
        L_0x000e:
            goto L_0x0007
        L_0x000f:
            if (r1 > 0) goto L_0x0015
            r0 = 1631627(0x18e58b, float:2.286396E-39)
            goto L_0x0007
        L_0x0015:
            r0 = 1631596(0x18e56c, float:2.286353E-39)
            goto L_0x0007
        L_0x0019:
            java.lang.String r0 = "ۢۢ۟"
        L_0x001b:
            return r0
        L_0x001c:
            r0 = 0
            r1 = 1631658(0x18e5aa, float:2.28644E-39)
        L_0x0020:
            r2 = 1631675(0x18e5bb, float:2.286464E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 17: goto L_0x0028;
                case 114: goto L_0x001b;
                default: goto L_0x0027;
            }
        L_0x0027:
            goto L_0x0020
        L_0x0028:
            r1 = 1631689(0x18e5c9, float:2.286483E-39)
            goto L_0x0020
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2495.m17459():java.lang.String");
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ⁤⁤⁠⁤⁤⁤⁠⁤⁠⁣⁣⁣⁣⁣⁠  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.Object m17460(java.lang.Object r3, int r4) {
        /*
            int r1 = android.C2493.m17445()
            r0 = 1632433(0x18e8b1, float:2.287526E-39)
        L_0x0007:
            r2 = 1632450(0x18e8c2, float:2.28755E-39)
            r0 = r0 ^ r2
            switch(r0) {
                case 18: goto L_0x000f;
                case 45: goto L_0x0020;
                case 115: goto L_0x0013;
                case 460: goto L_0x0019;
                default: goto L_0x000e;
            }
        L_0x000e:
            goto L_0x0007
        L_0x000f:
            r0 = 1632495(0x18e8ef, float:2.287613E-39)
            goto L_0x0007
        L_0x0013:
            if (r1 <= 0) goto L_0x000f
            r0 = 1632526(0x18e90e, float:2.287656E-39)
            goto L_0x0007
        L_0x0019:
            java.util.List r3 = (java.util.List) r3
            java.lang.Object r0 = r3.get(r4)
        L_0x001f:
            return r0
        L_0x0020:
            r0 = 0
            r1 = 1632557(0x18e92d, float:2.2877E-39)
        L_0x0024:
            r2 = 1632574(0x18e93e, float:2.287723E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 19: goto L_0x002c;
                case 114: goto L_0x001f;
                default: goto L_0x002b;
            }
        L_0x002b:
            goto L_0x0024
        L_0x002c:
            r1 = 1632588(0x18e94c, float:2.287743E-39)
            goto L_0x0024
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2495.m17460(java.lang.Object, int):java.lang.Object");
    }
}
