package android;

import java.lang.reflect.Field;
import java.util.List;

/* renamed from: android.ۢۤۨۨ  reason: contains not printable characters */
public class C2489 {

    /* renamed from: short  reason: not valid java name */
    private static final short[] f18636short = {2606, 2258, 2270, 3144, 3155, 3146, 3146, 2915, 527};

    /* renamed from: ⁠⁣⁤⁣⁤⁠⁠⁠⁣⁠⁠⁣  reason: not valid java name and contains not printable characters */
    public static boolean f18637 = true;

    /* renamed from: ۥۣۧۥ  reason: contains not printable characters */
    public static Class m17400(String str) {
        try {
            return m17432(str);
        } catch (Exception e) {
            char c = 1616;
            while (true) {
                c ^= 1633;
                switch (c) {
                    case 14:
                        return null;
                    case '1':
                        c = 1647;
                        break;
                }
            }
        } catch (Error e2) {
            char c2 = 1740;
            while (true) {
                c2 ^= 1757;
                switch (c2) {
                    case 17:
                        c2 = 1771;
                        break;
                    case '6':
                        return null;
                }
            }
        }
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x0092  */
    /* JADX WARNING: Removed duplicated region for block: B:85:0x0074 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:86:0x008a A[SYNTHETIC] */
    /* renamed from: ۥۣۧۥ  reason: contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.Object m17401(java.lang.Class r5, java.lang.String r6, java.lang.String r7) {
        /*
            r1 = 0
            java.lang.reflect.Field[] r0 = android.C2496.m17463(r5)     // Catch:{ Exception -> 0x0096, Error -> 0x0085 }
            java.lang.Object r0 = android.C2495.m17456(r6, r7, r0)     // Catch:{ Exception -> 0x0096, Error -> 0x0085 }
            r2 = 1864(0x748, float:2.612E-42)
        L_0x000b:
            r2 = r2 ^ 1881(0x759, float:2.636E-42)
            switch(r2) {
                case 17: goto L_0x0011;
                case 47384: goto L_0x0023;
                case 47417: goto L_0x001b;
                case 47483: goto L_0x0017;
                default: goto L_0x0010;
            }     // Catch:{ Exception -> 0x0096, Error -> 0x0085 }
        L_0x0010:
            goto L_0x000b
        L_0x0011:
            if (r0 != 0) goto L_0x0017
            r2 = 48736(0xbe60, float:6.8294E-41)
            goto L_0x000b
        L_0x0017:
            r2 = 48705(0xbe41, float:6.825E-41)
            goto L_0x000b
        L_0x001b:
            java.lang.reflect.Field[] r0 = android.C2497.m17470(r5)     // Catch:{ Exception -> 0x0096, Error -> 0x0085 }
            java.lang.Object r0 = android.C2495.m17456(r6, r7, r0)     // Catch:{ Exception -> 0x0096, Error -> 0x0085 }
        L_0x0023:
            r2 = 48767(0xbe7f, float:6.8337E-41)
        L_0x0026:
            r3 = 48784(0xbe90, float:6.8361E-41)
            r2 = r2 ^ r3
            switch(r2) {
                case 14: goto L_0x002e;
                case 45: goto L_0x0059;
                case 76: goto L_0x0038;
                case 239: goto L_0x0032;
                default: goto L_0x002d;
            }     // Catch:{ Exception -> 0x0096, Error -> 0x0085 }
        L_0x002d:
            goto L_0x0026
        L_0x002e:
            r2 = 48829(0xbebd, float:6.8424E-41)
            goto L_0x0026
        L_0x0032:
            if (r0 != 0) goto L_0x002e
            r2 = 48860(0xbedc, float:6.8467E-41)
            goto L_0x0026
        L_0x0038:
            java.lang.Class r3 = android.C2497.m17475(r5)     // Catch:{ Exception -> 0x0096, Error -> 0x0085 }
            r2 = 48891(0xbefb, float:6.8511E-41)
        L_0x003f:
            r4 = 48908(0xbf0c, float:6.8535E-41)
            r2 = r2 ^ r4
            switch(r2) {
                case 22: goto L_0x0047;
                case 53: goto L_0x0059;
                case 503: goto L_0x004b;
                case 32495: goto L_0x0051;
                default: goto L_0x0046;
            }     // Catch:{ Exception -> 0x0096, Error -> 0x0085 }
        L_0x0046:
            goto L_0x003f
        L_0x0047:
            r2 = 48953(0xbf39, float:6.8598E-41)
            goto L_0x003f
        L_0x004b:
            if (r3 == 0) goto L_0x0047
            r2 = 49635(0xc1e3, float:6.9553E-41)
            goto L_0x003f
        L_0x0051:
            java.lang.Class r0 = android.C2497.m17475(r5)     // Catch:{ Exception -> 0x0096, Error -> 0x0085 }
            java.lang.Object r0 = android.C2497.m17479(r0, r6, r7)     // Catch:{ Exception -> 0x0096, Error -> 0x0085 }
        L_0x0059:
            r2 = 49666(0xc202, float:6.9597E-41)
        L_0x005c:
            r3 = 49683(0xc213, float:6.9621E-41)
            r2 = r2 ^ r3
            switch(r2) {
                case 17: goto L_0x0064;
                case 50: goto L_0x006a;
                case 76: goto L_0x006e;
                case 83: goto L_0x00aa;
                default: goto L_0x0063;
            }     // Catch:{ Exception -> 0x0096, Error -> 0x0085 }
        L_0x0063:
            goto L_0x005c
        L_0x0064:
            if (r0 == 0) goto L_0x006a
            r2 = 49759(0xc25f, float:6.9727E-41)
            goto L_0x005c
        L_0x006a:
            r2 = 49728(0xc240, float:6.9684E-41)
            goto L_0x005c
        L_0x006e:
            java.lang.reflect.Field r0 = (java.lang.reflect.Field) r0     // Catch:{ Exception -> 0x0096, Error -> 0x0085 }
        L_0x0070:
            r1 = 1
            android.C2497.m17477(r0, r1)     // Catch:{ Exception -> 0x0075, Error -> 0x00a8 }
        L_0x0074:
            return r0
        L_0x0075:
            r1 = move-exception
            r1 = 49790(0xc27e, float:6.977E-41)
        L_0x0079:
            r2 = 49807(0xc28f, float:6.9794E-41)
            r1 = r1 ^ r2
            switch(r1) {
                case 18: goto L_0x0074;
                case 241: goto L_0x0081;
                default: goto L_0x0080;
            }
        L_0x0080:
            goto L_0x0079
        L_0x0081:
            r1 = 49821(0xc29d, float:6.9814E-41)
            goto L_0x0079
        L_0x0085:
            r0 = move-exception
            r0 = r1
        L_0x0087:
            r1 = 49914(0xc2fa, float:6.9944E-41)
        L_0x008a:
            r2 = 49931(0xc30b, float:6.9968E-41)
            r1 = r1 ^ r2
            switch(r1) {
                case 497: goto L_0x0092;
                case 1711: goto L_0x0074;
                default: goto L_0x0091;
            }
        L_0x0091:
            goto L_0x008a
        L_0x0092:
            r1 = 50596(0xc5a4, float:7.09E-41)
            goto L_0x008a
        L_0x0096:
            r0 = move-exception
            r0 = 50689(0xc601, float:7.103E-41)
        L_0x009a:
            r2 = 50706(0xc612, float:7.1054E-41)
            r0 = r0 ^ r2
            switch(r0) {
                case 19: goto L_0x00a2;
                case 50: goto L_0x00a6;
                default: goto L_0x00a1;
            }
        L_0x00a1:
            goto L_0x009a
        L_0x00a2:
            r0 = 50720(0xc620, float:7.1074E-41)
            goto L_0x009a
        L_0x00a6:
            r0 = r1
            goto L_0x0070
        L_0x00a8:
            r1 = move-exception
            goto L_0x0087
        L_0x00aa:
            r0 = r1
            goto L_0x0070
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2489.m17401(java.lang.Class, java.lang.String, java.lang.String):java.lang.Object");
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Code restructure failed: missing block: B:150:0x0118, code lost:
        continue;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:69:0x00f3, code lost:
        r0 = null;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:81:0x0115, code lost:
        r0 = 55556;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:82:0x0118, code lost:
        r0 = r0 ^ 55573;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:83:0x011c, code lost:
        switch(r0) {
            case 17: goto L_0x0120;
            case 54: goto L_0x0076;
            default: goto L_0x011f;
        };
     */
    /* JADX WARNING: Code restructure failed: missing block: B:84:0x0120, code lost:
        r0 = 55587;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Removed duplicated region for block: B:132:0x0017 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:133:0x00ca A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:140:0x00c7 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:141:0x00f7 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:144:0x00c7 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:145:0x0108 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:60:0x00d2  */
    /* JADX WARNING: Removed duplicated region for block: B:68:0x00f2 A[ExcHandler: Error (e java.lang.Error), Splitter:B:8:0x0019] */
    /* JADX WARNING: Removed duplicated region for block: B:73:0x00ff  */
    /* JADX WARNING: Removed duplicated region for block: B:79:0x0110  */
    /* JADX WARNING: Removed duplicated region for block: B:8:0x0019 A[LOOP_START, PHI: r0 
      PHI: (r0v4 int) = (r0v3 int), (r0v45 int) binds: [B:7:0x0018, B:29:0x0062] A[DONT_GENERATE, DONT_INLINE], SYNTHETIC, Splitter:B:8:0x0019] */
    /* renamed from: ۥۣۧۥ  reason: contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.Object m17402(java.lang.Class r5, java.lang.String r6, java.lang.String r7, java.lang.String... r8) {
        /*
            r1 = 0
            r0 = 50813(0xc67d, float:7.1204E-41)
        L_0x0004:
            r2 = 50830(0xc68e, float:7.1228E-41)
            r0 = r0 ^ r2
            switch(r0) {
                case 18: goto L_0x000c;
                case 53: goto L_0x0018;
                case 243: goto L_0x0010;
                case 4075: goto L_0x0016;
                default: goto L_0x000b;
            }
        L_0x000b:
            goto L_0x0004
        L_0x000c:
            r0 = 50875(0xc6bb, float:7.1291E-41)
            goto L_0x0004
        L_0x0010:
            if (r5 != 0) goto L_0x000c
            r0 = 51557(0xc965, float:7.2247E-41)
            goto L_0x0004
        L_0x0016:
            r0 = r1
        L_0x0017:
            return r0
        L_0x0018:
            r0 = 0
        L_0x0019:
            int r3 = r8.length     // Catch:{ Exception -> 0x00d6, Error -> 0x00f2 }
            r2 = 51588(0xc984, float:7.229E-41)
        L_0x001d:
            r4 = 51605(0xc995, float:7.2314E-41)
            r2 = r2 ^ r4
            switch(r2) {
                case 17: goto L_0x0025;
                case 54: goto L_0x002b;
                case 87: goto L_0x006a;
                case 116: goto L_0x002f;
                default: goto L_0x0024;
            }
        L_0x0024:
            goto L_0x001d
        L_0x0025:
            if (r0 >= r3) goto L_0x002b
            r2 = 51681(0xc9e1, float:7.242E-41)
            goto L_0x001d
        L_0x002b:
            r2 = 51650(0xc9c2, float:7.2377E-41)
            goto L_0x001d
        L_0x002f:
            r3 = r8[r0]
            r2 = 51712(0xca00, float:7.2464E-41)
        L_0x0034:
            r4 = 51729(0xca11, float:7.2488E-41)
            r2 = r2 ^ r4
            switch(r2) {
                case 14: goto L_0x003c;
                case 17: goto L_0x0040;
                case 47: goto L_0x0057;
                case 76: goto L_0x0046;
                default: goto L_0x003b;
            }
        L_0x003b:
            goto L_0x0034
        L_0x003c:
            r2 = 51774(0xca3e, float:7.2551E-41)
            goto L_0x0034
        L_0x0040:
            if (r3 != 0) goto L_0x003c
            r2 = 51805(0xca5d, float:7.2594E-41)
            goto L_0x0034
        L_0x0046:
            r0 = 51836(0xca7c, float:7.2638E-41)
        L_0x0049:
            r2 = 51853(0xca8d, float:7.2662E-41)
            r0 = r0 ^ r2
            switch(r0) {
                case 241: goto L_0x0051;
                case 1963: goto L_0x0055;
                default: goto L_0x0050;
            }
        L_0x0050:
            goto L_0x0049
        L_0x0051:
            r0 = 52518(0xcd26, float:7.3593E-41)
            goto L_0x0049
        L_0x0055:
            r0 = r1
            goto L_0x0017
        L_0x0057:
            int r0 = 0 - r0
            int r0 = 1 - r0
            r2 = 52611(0xcd83, float:7.3724E-41)
        L_0x005e:
            r3 = 52628(0xcd94, float:7.3748E-41)
            r2 = r2 ^ r3
            switch(r2) {
                case 23: goto L_0x0066;
                case 54: goto L_0x0019;
                default: goto L_0x0065;
            }
        L_0x0065:
            goto L_0x005e
        L_0x0066:
            r2 = 52642(0xcda2, float:7.3767E-41)
            goto L_0x005e
        L_0x006a:
            java.lang.String r0 = android.C2495.m17450(r5)     // Catch:{ Exception -> 0x00d6, Error -> 0x00f2 }
            java.lang.reflect.Method[] r2 = android.C2495.m17448(r5)     // Catch:{ Exception -> 0x00d6, Error -> 0x00f2 }
            java.lang.reflect.Method r1 = android.C2495.m17452(r0, r2, r6, r7, r8)     // Catch:{ Exception -> 0x00d6, Error -> 0x00f2 }
        L_0x0076:
            r0 = 52735(0xcdff, float:7.3897E-41)
        L_0x0079:
            r2 = 52752(0xce10, float:7.3921E-41)
            r0 = r0 ^ r2
            switch(r0) {
                case 14: goto L_0x0081;
                case 45: goto L_0x012b;
                case 1007: goto L_0x0085;
                case 7927: goto L_0x008b;
                default: goto L_0x0080;
            }
        L_0x0080:
            goto L_0x0079
        L_0x0081:
            r0 = 52797(0xce3d, float:7.3984E-41)
            goto L_0x0079
        L_0x0085:
            if (r1 != 0) goto L_0x0081
            r0 = 53479(0xd0e7, float:7.494E-41)
            goto L_0x0079
        L_0x008b:
            java.lang.Class r2 = android.C2497.m17475(r5)     // Catch:{ Exception -> 0x0103, Error -> 0x0126 }
            r0 = 53510(0xd106, float:7.4983E-41)
        L_0x0092:
            r3 = 53527(0xd117, float:7.5007E-41)
            r0 = r0 ^ r3
            switch(r0) {
                case 17: goto L_0x009a;
                case 50: goto L_0x00a0;
                case 83: goto L_0x012b;
                case 116: goto L_0x00a4;
                default: goto L_0x0099;
            }     // Catch:{ Exception -> 0x0103, Error -> 0x0126 }
        L_0x0099:
            goto L_0x0092
        L_0x009a:
            if (r2 == 0) goto L_0x00a0
            r0 = 53603(0xd163, float:7.5114E-41)
            goto L_0x0092
        L_0x00a0:
            r0 = 53572(0xd144, float:7.507E-41)
            goto L_0x0092
        L_0x00a4:
            java.lang.Class r0 = android.C2497.m17475(r5)     // Catch:{ Exception -> 0x0103, Error -> 0x0126 }
            java.lang.Object r0 = android.C2493.m17439(r0, r6, r7, r8)     // Catch:{ Exception -> 0x0103, Error -> 0x0126 }
            java.lang.reflect.Method r0 = (java.lang.reflect.Method) r0     // Catch:{ Exception -> 0x0103, Error -> 0x0126 }
        L_0x00ae:
            r1 = 53634(0xd182, float:7.5157E-41)
        L_0x00b1:
            r2 = 53651(0xd193, float:7.5181E-41)
            r1 = r1 ^ r2
            switch(r1) {
                case 17: goto L_0x00b9;
                case 50: goto L_0x00bf;
                case 76: goto L_0x00c3;
                case 83: goto L_0x00c7;
                default: goto L_0x00b8;
            }
        L_0x00b8:
            goto L_0x00b1
        L_0x00b9:
            if (r0 == 0) goto L_0x00bf
            r1 = 53727(0xd1df, float:7.5288E-41)
            goto L_0x00b1
        L_0x00bf:
            r1 = 53696(0xd1c0, float:7.5244E-41)
            goto L_0x00b1
        L_0x00c3:
            r1 = 1
            android.C2497.m17471(r0, r1)     // Catch:{ Exception -> 0x0124, Error -> 0x0129 }
        L_0x00c7:
            r1 = 53758(0xd1fe, float:7.5331E-41)
        L_0x00ca:
            r2 = 53775(0xd20f, float:7.5355E-41)
            r1 = r1 ^ r2
            switch(r1) {
                case 1009: goto L_0x00d2;
                case 1703: goto L_0x0017;
                default: goto L_0x00d1;
            }
        L_0x00d1:
            goto L_0x00ca
        L_0x00d2:
            r1 = 54440(0xd4a8, float:7.6287E-41)
            goto L_0x00ca
        L_0x00d6:
            r0 = move-exception
            java.lang.String r0 = android.C2495.m17450(r5)     // Catch:{ Exception -> 0x0114, Error -> 0x00f2 }
            java.lang.reflect.Method[] r2 = android.C2495.m17451(r5)     // Catch:{ Exception -> 0x0114, Error -> 0x00f2 }
            java.lang.reflect.Method r1 = android.C2495.m17452(r0, r2, r6, r7, r8)     // Catch:{ Exception -> 0x0114, Error -> 0x00f2 }
            r0 = 54533(0xd505, float:7.6417E-41)
        L_0x00e6:
            r2 = 54550(0xd516, float:7.6441E-41)
            r0 = r0 ^ r2
            switch(r0) {
                case 19: goto L_0x00ee;
                case 50: goto L_0x0076;
                default: goto L_0x00ed;
            }
        L_0x00ed:
            goto L_0x00e6
        L_0x00ee:
            r0 = 54564(0xd524, float:7.646E-41)
            goto L_0x00e6
        L_0x00f2:
            r0 = move-exception
            r0 = r1
        L_0x00f4:
            r1 = 54657(0xd581, float:7.6591E-41)
        L_0x00f7:
            r2 = 54674(0xd592, float:7.6615E-41)
            r1 = r1 ^ r2
            switch(r1) {
                case 19: goto L_0x00ff;
                case 50: goto L_0x00c7;
                default: goto L_0x00fe;
            }
        L_0x00fe:
            goto L_0x00f7
        L_0x00ff:
            r1 = 54688(0xd5a0, float:7.6634E-41)
            goto L_0x00f7
        L_0x0103:
            r0 = move-exception
            r0 = r1
        L_0x0105:
            r1 = 55432(0xd888, float:7.7677E-41)
        L_0x0108:
            r2 = 55449(0xd899, float:7.77E-41)
            r1 = r1 ^ r2
            switch(r1) {
                case 17: goto L_0x0110;
                case 62: goto L_0x00c7;
                default: goto L_0x010f;
            }
        L_0x010f:
            goto L_0x0108
        L_0x0110:
            r1 = 55463(0xd8a7, float:7.772E-41)
            goto L_0x0108
        L_0x0114:
            r0 = move-exception
            r0 = 55556(0xd904, float:7.785E-41)
        L_0x0118:
            r2 = 55573(0xd915, float:7.7874E-41)
            r0 = r0 ^ r2
            switch(r0) {
                case 17: goto L_0x0120;
                case 54: goto L_0x0076;
                default: goto L_0x011f;
            }
        L_0x011f:
            goto L_0x0118
        L_0x0120:
            r0 = 55587(0xd923, float:7.7894E-41)
            goto L_0x0118
        L_0x0124:
            r1 = move-exception
            goto L_0x0105
        L_0x0126:
            r0 = move-exception
            r0 = r1
            goto L_0x00f4
        L_0x0129:
            r1 = move-exception
            goto L_0x00f4
        L_0x012b:
            r0 = r1
            goto L_0x00ae
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2489.m17402(java.lang.Class, java.lang.String, java.lang.String, java.lang.String[]):java.lang.Object");
    }

    /* renamed from: ۥۣۧۥ  reason: contains not printable characters */
    public static Object m17403(Object obj) {
        try {
            boolean z = obj instanceof String;
            char c = 55680;
            while (true) {
                c ^= 55697;
                switch (c) {
                    case 17:
                        if (z) {
                            c = 56424;
                            continue;
                        }
                    case 1467:
                        c = 56393;
                        continue;
                    case 1496:
                        Field field = (Field) obj;
                        obj = C2497.m17476(field, C2493.m17443(field));
                        char c2 = 56455;
                        while (true) {
                            c2 ^= 56472;
                            switch (c2) {
                                case 31:
                                    c2 = 56486;
                                    continue;
                                case '>':
                                    break;
                            }
                        }
                        break;
                    case 1529:
                        break;
                    default:
                        continue;
                }
            }
        } catch (Exception e) {
            obj = null;
            char c3 = 56579;
            while (true) {
                c3 ^= 56596;
                switch (c3) {
                    case 23:
                        c3 = 56610;
                        continue;
                    case '6':
                        break;
                }
            }
        }
        return obj;
    }

    /* renamed from: ۥۣۧۥ  reason: contains not printable characters */
    public static Object m17404(Object obj, Object obj2) {
        try {
            return C2497.m17476((Field) obj, obj2);
        } catch (Exception e) {
            char c = 175;
            while (true) {
                c ^= 192;
                switch (c) {
                    case 14:
                        return null;
                    case 'o':
                        c = 206;
                        break;
                }
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:16:0x0006 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x0012 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:9:0x001a  */
    /* renamed from: ۥۣۧۥ  reason: contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.Object m17405(java.lang.Object r3, java.lang.Object r4, java.lang.Object[] r5) throws java.lang.Throwable {
        /*
            java.lang.reflect.Method r3 = (java.lang.reflect.Method) r3     // Catch:{ InvocationTargetException -> 0x0007, IllegalAccessException -> 0x001e, IllegalArgumentException -> 0x000d }
            java.lang.Object r0 = android.C2495.m17449(r3, r4, r5)     // Catch:{ InvocationTargetException -> 0x0007, IllegalAccessException -> 0x001e, IllegalArgumentException -> 0x000d }
        L_0x0006:
            return r0
        L_0x0007:
            r0 = move-exception
            java.lang.Throwable r0 = android.C2493.m17441(r0)
            throw r0
        L_0x000d:
            r0 = move-exception
        L_0x000e:
            r0 = 0
            r1 = 1507627(0x17012b, float:2.112635E-39)
        L_0x0012:
            r2 = 1507644(0x17013c, float:2.112659E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 23: goto L_0x001a;
                case 118: goto L_0x0006;
                default: goto L_0x0019;
            }
        L_0x0019:
            goto L_0x0012
        L_0x001a:
            r1 = 1507658(0x17014a, float:2.112679E-39)
            goto L_0x0012
        L_0x001e:
            r0 = move-exception
            r0 = 1507751(0x1701a7, float:2.112809E-39)
        L_0x0022:
            r1 = 1507768(0x1701b8, float:2.112833E-39)
            r0 = r0 ^ r1
            switch(r0) {
                case 31: goto L_0x002a;
                case 1513: goto L_0x000e;
                default: goto L_0x0029;
            }
        L_0x0029:
            goto L_0x0022
        L_0x002a:
            r0 = 1508433(0x170451, float:2.113765E-39)
            goto L_0x0022
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2489.m17405(java.lang.Object, java.lang.Object, java.lang.Object[]):java.lang.Object");
    }

    /* renamed from: ۥۣۧۥ  reason: contains not printable characters */
    public static Object m17406(String str, String str2, String str3) {
        Object obj = null;
        String str4 = "۫ۚۚ";
        Class cls = null;
        while (true) {
            switch (m17426((Object) str4)) {
                case 1740169:
                    return obj;
                case 1754645:
                    obj = C2497.m17479(cls, str2, str3);
                    str4 = "ۘۦۗ";
                    break;
                default:
                    cls = C2497.m17469(str);
                    str4 = "ۧۨۖ";
                    break;
            }
        }
    }

    /* renamed from: ۥۣۧۥ  reason: contains not printable characters */
    public static Object m17407(String str, String str2, String str3, String... strArr) {
        Object obj = null;
        String str4 = "ۖۢ۬";
        Class cls = null;
        while (true) {
            switch (m17426((Object) str4)) {
                case 1738144:
                    cls = C2497.m17469(str);
                    str4 = "۠۠ۨ";
                    break;
                case 1747688:
                    obj = C2493.m17439(cls, str2, str3, strArr);
                    str4 = "ۚۡۢ";
                    break;
                default:
                    return obj;
            }
        }
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ۥۣۧۥ  reason: contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.Object m17408(java.lang.String r5, java.lang.String r6, java.lang.reflect.Field[] r7) {
        /*
            r0 = 0
        L_0x0001:
            int r2 = r7.length
            r1 = 1508526(0x1704ae, float:2.113895E-39)
        L_0x0005:
            r3 = 1508543(0x1704bf, float:2.113919E-39)
            r1 = r1 ^ r3
            switch(r1) {
                case 17: goto L_0x000d;
                case 83: goto L_0x006e;
                case 114: goto L_0x0013;
                case 436: goto L_0x0017;
                default: goto L_0x000c;
            }
        L_0x000c:
            goto L_0x0005
        L_0x000d:
            if (r0 >= r2) goto L_0x0013
            r1 = 1508619(0x17050b, float:2.114025E-39)
            goto L_0x0005
        L_0x0013:
            r1 = 1508588(0x1704ec, float:2.113982E-39)
            goto L_0x0005
        L_0x0017:
            r1 = r7[r0]
            java.lang.String r2 = android.C2493.m17440(r1)
            boolean r3 = android.C2496.m17465(r2, r5)
            r2 = 1508650(0x17052a, float:2.114069E-39)
        L_0x0024:
            r4 = 1508667(0x17053b, float:2.114093E-39)
            r2 = r2 ^ r4
            switch(r2) {
                case 17: goto L_0x002c;
                case 83: goto L_0x0059;
                case 114: goto L_0x0032;
                case 3369: goto L_0x0036;
                default: goto L_0x002b;
            }
        L_0x002b:
            goto L_0x0024
        L_0x002c:
            if (r3 == 0) goto L_0x0032
            r2 = 1509394(0x170812, float:2.115111E-39)
            goto L_0x0024
        L_0x0032:
            r2 = 1508712(0x170568, float:2.114156E-39)
            goto L_0x0024
        L_0x0036:
            java.lang.Class r2 = android.C2495.m17458(r1)
            java.lang.String r2 = android.C2495.m17450(r2)
            boolean r3 = android.C2496.m17465(r2, r6)
            r2 = 1509425(0x170831, float:2.115155E-39)
        L_0x0045:
            r4 = 1509442(0x170842, float:2.115179E-39)
            r2 = r2 ^ r4
            switch(r2) {
                case 18: goto L_0x004d;
                case 45: goto L_0x0059;
                case 115: goto L_0x0051;
                case 204: goto L_0x0057;
                default: goto L_0x004c;
            }
        L_0x004c:
            goto L_0x0045
        L_0x004d:
            r2 = 1509487(0x17086f, float:2.115242E-39)
            goto L_0x0045
        L_0x0051:
            if (r3 == 0) goto L_0x004d
            r2 = 1509518(0x17088e, float:2.115285E-39)
            goto L_0x0045
        L_0x0057:
            r0 = r1
        L_0x0058:
            return r0
        L_0x0059:
            int r0 = 0 - r0
            int r0 = r0 + -1
            int r0 = 0 - r0
            r1 = 1509549(0x1708ad, float:2.115329E-39)
        L_0x0062:
            r2 = 1509566(0x1708be, float:2.115353E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 19: goto L_0x006a;
                case 114: goto L_0x0001;
                default: goto L_0x0069;
            }
        L_0x0069:
            goto L_0x0062
        L_0x006a:
            r1 = 1509580(0x1708cc, float:2.115372E-39)
            goto L_0x0062
        L_0x006e:
            r0 = 0
            r1 = 1509673(0x170929, float:2.115502E-39)
        L_0x0072:
            r2 = 1509690(0x17093a, float:2.115526E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 19: goto L_0x007a;
                case 745: goto L_0x0058;
                default: goto L_0x0079;
            }
        L_0x0079:
            goto L_0x0072
        L_0x007a:
            r1 = 1510355(0x170bd3, float:2.116458E-39)
            goto L_0x0072
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2489.m17408(java.lang.String, java.lang.String, java.lang.reflect.Field[]):java.lang.Object");
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ۥۣۧۥ  reason: contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.Object m17409(java.util.List r3, int r4) {
        /*
            java.lang.Object r0 = android.C2495.m17460(r3, r4)     // Catch:{ Exception -> 0x003d }
            boolean r1 = r0 instanceof java.lang.String     // Catch:{ Exception -> 0x003d }
            r0 = 1510448(0x170c30, float:2.116588E-39)
        L_0x0009:
            r2 = 1510465(0x170c41, float:2.116612E-39)
            r0 = r0 ^ r2
            switch(r0) {
                case 14: goto L_0x0011;
                case 47: goto L_0x0020;
                case 113: goto L_0x0015;
                case 204: goto L_0x001b;
                default: goto L_0x0010;
            }     // Catch:{ Exception -> 0x003d }
        L_0x0010:
            goto L_0x0009
        L_0x0011:
            r0 = 1510510(0x170c6e, float:2.116675E-39)
            goto L_0x0009
        L_0x0015:
            if (r1 == 0) goto L_0x0011
            r0 = 1510541(0x170c8d, float:2.116719E-39)
            goto L_0x0009
        L_0x001b:
            java.lang.Object r0 = android.C2495.m17460(r3, r4)     // Catch:{ Exception -> 0x003d }
        L_0x001f:
            return r0
        L_0x0020:
            java.lang.Object r0 = android.C2495.m17460(r3, r4)     // Catch:{ Exception -> 0x003d }
            java.lang.reflect.Field r0 = (java.lang.reflect.Field) r0     // Catch:{ Exception -> 0x003d }
            java.lang.Class r1 = android.C2493.m17443(r0)     // Catch:{ Exception -> 0x003d }
            java.lang.Object r0 = android.C2497.m17476(r0, r1)     // Catch:{ Exception -> 0x003d }
            r1 = 1510572(0x170cac, float:2.116762E-39)
        L_0x0031:
            r2 = 1510589(0x170cbd, float:2.116786E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 17: goto L_0x0039;
                case 118: goto L_0x001f;
                default: goto L_0x0038;
            }
        L_0x0038:
            goto L_0x0031
        L_0x0039:
            r1 = 1510603(0x170ccb, float:2.116806E-39)
            goto L_0x0031
        L_0x003d:
            r0 = move-exception
            r0 = 0
            r1 = 1511347(0x170fb3, float:2.117848E-39)
        L_0x0042:
            r2 = 1511364(0x170fc4, float:2.117872E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 22: goto L_0x001f;
                case 119: goto L_0x004a;
                default: goto L_0x0049;
            }
        L_0x0049:
            goto L_0x0042
        L_0x004a:
            r1 = 1511378(0x170fd2, float:2.117892E-39)
            goto L_0x0042
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2489.m17409(java.util.List, int):java.lang.Object");
    }

    /* renamed from: ۥۣۧۥ  reason: contains not printable characters */
    public static Object m17410(List list, int i, Object obj) {
        try {
            return C2497.m17476((Field) C2495.m17460(list, i), obj);
        } catch (Exception e) {
            char c = 4143;
            while (true) {
                c ^= 4160;
                switch (c) {
                    case 14:
                        return null;
                    case 'o':
                        c = 4174;
                        break;
                }
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:16:0x000a A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x0016 A[SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:9:0x001e  */
    /* renamed from: ۥۣۧۥ  reason: contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.Object m17411(java.util.List r3, int r4, java.lang.Object r5, java.lang.Object[] r6) throws java.lang.Throwable {
        /*
            java.lang.Object r0 = android.C2495.m17460(r3, r4)     // Catch:{ InvocationTargetException -> 0x000b, IllegalAccessException -> 0x0022, IllegalArgumentException -> 0x0011 }
            java.lang.reflect.Method r0 = (java.lang.reflect.Method) r0     // Catch:{ InvocationTargetException -> 0x000b, IllegalAccessException -> 0x0022, IllegalArgumentException -> 0x0011 }
            java.lang.Object r0 = android.C2495.m17449(r0, r5, r6)     // Catch:{ InvocationTargetException -> 0x000b, IllegalAccessException -> 0x0022, IllegalArgumentException -> 0x0011 }
        L_0x000a:
            return r0
        L_0x000b:
            r0 = move-exception
            java.lang.Throwable r0 = android.C2493.m17441(r0)
            throw r0
        L_0x0011:
            r0 = move-exception
        L_0x0012:
            r0 = 0
            r1 = 1511595(0x1710ab, float:2.118196E-39)
        L_0x0016:
            r2 = 1511612(0x1710bc, float:2.11822E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 23: goto L_0x001e;
                case 1001: goto L_0x000a;
                default: goto L_0x001d;
            }
        L_0x001d:
            goto L_0x0016
        L_0x001e:
            r1 = 1512277(0x171355, float:2.119151E-39)
            goto L_0x0016
        L_0x0022:
            r0 = move-exception
            r0 = 1512370(0x1713b2, float:2.119282E-39)
        L_0x0026:
            r1 = 1512387(0x1713c3, float:2.119306E-39)
            r0 = r0 ^ r1
            switch(r0) {
                case 18: goto L_0x0012;
                case 113: goto L_0x002e;
                default: goto L_0x002d;
            }
        L_0x002d:
            goto L_0x0026
        L_0x002e:
            r0 = 1512401(0x1713d1, float:2.119325E-39)
            goto L_0x0026
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2489.m17411(java.util.List, int, java.lang.Object, java.lang.Object[]):java.lang.Object");
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ۥۣۧۥ  reason: contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static java.lang.String m17412(java.lang.String[] r8) {
        /*
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            short[] r0 = m17436()
            java.lang.String r1 = m17435()
            int r1 = m17418(r1)
            java.lang.String r2 = m17415()
            int r2 = m17418(r2)
            java.lang.String r4 = android.C2495.m17453()
            int r4 = m17418(r4)
            r5 = -1738247(0xffffffffffe579f9, float:NaN)
            r5 = r5 & r2
            r2 = r2 ^ -1
            r6 = 1738246(0x1a8606, float:2.435801E-39)
            r2 = r2 & r6
            r2 = r2 | r5
            r5 = -1746900(0xffffffffffe5582c, float:NaN)
            r5 = r5 & r4
            r4 = r4 ^ -1
            r6 = 1746899(0x1aa7d3, float:2.447927E-39)
            r4 = r4 & r6
            r4 = r4 | r5
            r5 = -1755984(0xffffffffffe534b0, float:NaN)
            r5 = r5 & r1
            r1 = r1 ^ -1
            r6 = 1755983(0x1acb4f, float:2.460656E-39)
            r1 = r1 & r6
            r1 = r1 | r5
            java.lang.String r0 = m17431(r0, r2, r4, r1)
            m17424(r3, r0)
            r0 = 1512494(0x17142e, float:2.119456E-39)
        L_0x004c:
            r1 = 1512511(0x17143f, float:2.11948E-39)
            r0 = r0 ^ r1
            switch(r0) {
                case 17: goto L_0x0054;
                case 83: goto L_0x0142;
                case 114: goto L_0x005a;
                case 809: goto L_0x005e;
                default: goto L_0x0053;
            }
        L_0x0053:
            goto L_0x004c
        L_0x0054:
            if (r8 == 0) goto L_0x005a
            r0 = 1513238(0x171716, float:2.120498E-39)
            goto L_0x004c
        L_0x005a:
            r0 = 1512556(0x17146c, float:2.119542E-39)
            goto L_0x004c
        L_0x005e:
            r0 = 0
            r1 = r0
        L_0x0060:
            int r2 = r8.length
            r0 = 1513269(0x171735, float:2.120542E-39)
        L_0x0064:
            r4 = 1513286(0x171746, float:2.120565E-39)
            r0 = r0 ^ r4
            switch(r0) {
                case 18: goto L_0x006c;
                case 53: goto L_0x0142;
                case 115: goto L_0x0070;
                case 212: goto L_0x0076;
                default: goto L_0x006b;
            }
        L_0x006b:
            goto L_0x0064
        L_0x006c:
            r0 = 1513331(0x171773, float:2.120628E-39)
            goto L_0x0064
        L_0x0070:
            if (r1 >= r2) goto L_0x006c
            r0 = 1513362(0x171792, float:2.120672E-39)
            goto L_0x0064
        L_0x0076:
            r0 = 1513393(0x1717b1, float:2.120715E-39)
        L_0x0079:
            r2 = 1513410(0x1717c2, float:2.120739E-39)
            r0 = r0 ^ r2
            switch(r0) {
                case 18: goto L_0x0081;
                case 45: goto L_0x00cf;
                case 115: goto L_0x0085;
                case 4044: goto L_0x008b;
                default: goto L_0x0080;
            }
        L_0x0080:
            goto L_0x0079
        L_0x0081:
            r0 = 1513455(0x1717ef, float:2.120802E-39)
            goto L_0x0079
        L_0x0085:
            if (r1 <= 0) goto L_0x0081
            r0 = 1513486(0x17180e, float:2.120846E-39)
            goto L_0x0079
        L_0x008b:
            short[] r0 = m17436()
            java.lang.String r2 = android.C2497.m17472()
            int r2 = m17418(r2)
            java.lang.String r4 = android.C2496.m17466()
            int r4 = m17418(r4)
            java.lang.String r5 = m17434()
            int r5 = m17418(r5)
            r6 = -1749978(0xffffffffffe54c26, float:NaN)
            r6 = r6 & r4
            r4 = r4 ^ -1
            r7 = 1749977(0x1ab3d9, float:2.45224E-39)
            r4 = r4 & r7
            r4 = r4 | r6
            r6 = -1740209(0xffffffffffe5724f, float:NaN)
            r6 = r6 & r5
            r5 = r5 ^ -1
            r7 = 1740208(0x1a8db0, float:2.438551E-39)
            r5 = r5 & r7
            r5 = r5 | r6
            r6 = -1751507(0xffffffffffe5462d, float:NaN)
            r6 = r6 & r2
            r2 = r2 ^ -1
            r7 = 1751506(0x1ab9d2, float:2.454383E-39)
            r2 = r2 & r7
            r2 = r2 | r6
            java.lang.String r0 = m17431(r0, r4, r5, r2)
            m17424(r3, r0)
        L_0x00cf:
            r0 = r8[r1]
            r2 = 1513517(0x17182d, float:2.120889E-39)
        L_0x00d4:
            r4 = 1513534(0x17183e, float:2.120913E-39)
            r2 = r2 ^ r4
            switch(r2) {
                case 19: goto L_0x00dc;
                case 712: goto L_0x0127;
                case 745: goto L_0x00e2;
                case 811: goto L_0x00e6;
                default: goto L_0x00db;
            }
        L_0x00db:
            goto L_0x00d4
        L_0x00dc:
            if (r0 != 0) goto L_0x00e2
            r2 = 1514261(0x171b15, float:2.121932E-39)
            goto L_0x00d4
        L_0x00e2:
            r2 = 1514230(0x171af6, float:2.121888E-39)
            goto L_0x00d4
        L_0x00e6:
            short[] r0 = m17436()
            java.lang.String r2 = android.C2493.m17442()
            int r2 = m17418(r2)
            java.lang.String r4 = android.C2495.m17454()
            int r4 = m17418(r4)
            java.lang.String r5 = android.C2493.m17437()
            int r5 = m17418(r5)
            r6 = -1757975(0xffffffffffe52ce9, float:NaN)
            r6 = r6 & r4
            r4 = r4 ^ -1
            r7 = 1757974(0x1ad316, float:2.463446E-39)
            r4 = r4 & r7
            r4 = r4 | r6
            r6 = -1755736(0xffffffffffe535a8, float:NaN)
            r6 = r6 & r5
            r5 = r5 ^ -1
            r7 = 1755735(0x1aca57, float:2.460309E-39)
            r5 = r5 & r7
            r5 = r5 | r6
            r6 = -1745865(0xffffffffffe55c37, float:NaN)
            r6 = r6 & r2
            r2 = r2 ^ -1
            r7 = 1745864(0x1aa3c8, float:2.446477E-39)
            r2 = r2 & r7
            r2 = r2 | r6
            java.lang.String r0 = m17430(r0, r4, r5, r2)
        L_0x0127:
            m17424(r3, r0)
            int r0 = 0 - r1
            int r0 = r0 + -1
            int r0 = 0 - r0
            r1 = 1514292(0x171b34, float:2.121975E-39)
        L_0x0133:
            r2 = 1514309(0x171b45, float:2.121999E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 22: goto L_0x013b;
                case 113: goto L_0x013e;
                default: goto L_0x013a;
            }
        L_0x013a:
            goto L_0x0133
        L_0x013b:
            r1 = r0
            goto L_0x0060
        L_0x013e:
            r1 = 1514323(0x171b53, float:2.122018E-39)
            goto L_0x0133
        L_0x0142:
            short[] r0 = m17436()
            java.lang.String r1 = android.C2497.m17473()
            int r1 = m17418(r1)
            java.lang.String r2 = android.C2493.m17444()
            int r2 = m17418(r2)
            java.lang.String r4 = android.C2495.m17459()
            int r4 = m17418(r4)
            r5 = -1738289(0xffffffffffe579cf, float:NaN)
            r5 = r5 & r2
            r2 = r2 ^ -1
            r6 = 1738288(0x1a8630, float:2.43586E-39)
            r2 = r2 & r6
            r2 = r2 | r5
            r5 = -1749663(0xffffffffffe54d61, float:NaN)
            r5 = r5 & r4
            r4 = r4 ^ -1
            r6 = 1749662(0x1ab29e, float:2.451799E-39)
            r4 = r4 & r6
            r4 = r4 | r5
            r5 = -1745571(0xffffffffffe55d5d, float:NaN)
            r5 = r5 & r1
            r1 = r1 ^ -1
            r6 = 1745570(0x1aa2a2, float:2.446065E-39)
            r1 = r1 & r6
            r1 = r1 | r5
            java.lang.String r0 = m17417(r0, r2, r4, r1)
            m17424(r3, r0)
            java.lang.String r0 = android.C2496.m17467(r3)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2489.m17412(java.lang.String[]):java.lang.String");
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ۥۣۧۥ  reason: contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.reflect.Method m17413(java.lang.String r8, java.lang.reflect.Method[] r9, java.lang.String r10, java.lang.String r11, java.lang.String[] r12) throws java.lang.NoSuchMethodException {
        /*
            r2 = 0
            r0 = 0
        L_0x0002:
            int r3 = r9.length
            r1 = 1514416(0x171bb0, float:2.122149E-39)
        L_0x0006:
            r4 = 1514433(0x171bc1, float:2.122173E-39)
            r1 = r1 ^ r4
            switch(r1) {
                case 14: goto L_0x000e;
                case 47: goto L_0x0107;
                case 113: goto L_0x0012;
                case 1369: goto L_0x0018;
                default: goto L_0x000d;
            }
        L_0x000d:
            goto L_0x0006
        L_0x000e:
            r1 = 1514478(0x171bee, float:2.122236E-39)
            goto L_0x0006
        L_0x0012:
            if (r0 >= r3) goto L_0x000e
            r1 = 1515160(0x171e98, float:2.123191E-39)
            goto L_0x0006
        L_0x0018:
            r1 = r9[r0]
            java.lang.String r3 = android.C2496.m17461(r1)
            boolean r4 = android.C2496.m17465(r3, r10)
            r3 = 1515191(0x171eb7, float:2.123235E-39)
        L_0x0025:
            r5 = 1515208(0x171ec8, float:2.123259E-39)
            r3 = r3 ^ r5
            switch(r3) {
                case 30: goto L_0x002d;
                case 61: goto L_0x00f3;
                case 127: goto L_0x0031;
                case 476: goto L_0x0037;
                default: goto L_0x002c;
            }
        L_0x002c:
            goto L_0x0025
        L_0x002d:
            r3 = 1515253(0x171ef5, float:2.123322E-39)
            goto L_0x0025
        L_0x0031:
            if (r4 == 0) goto L_0x002d
            r3 = 1515284(0x171f14, float:2.123365E-39)
            goto L_0x0025
        L_0x0037:
            java.lang.Class[] r3 = m17422(r1)
            boolean r4 = m17425(r12, r3)
            r3 = 1515315(0x171f33, float:2.123409E-39)
        L_0x0042:
            r5 = 1515332(0x171f44, float:2.123432E-39)
            r3 = r3 ^ r5
            switch(r3) {
                case 22: goto L_0x004a;
                case 53: goto L_0x00f3;
                case 119: goto L_0x004e;
                case 212: goto L_0x0054;
                default: goto L_0x0049;
            }
        L_0x0049:
            goto L_0x0042
        L_0x004a:
            r3 = 1515377(0x171f71, float:2.123495E-39)
            goto L_0x0042
        L_0x004e:
            if (r4 == 0) goto L_0x004a
            r3 = 1515408(0x171f90, float:2.123539E-39)
            goto L_0x0042
        L_0x0054:
            java.lang.Class r3 = android.C2496.m17468(r1)
            java.lang.String r3 = android.C2495.m17450(r3)
            boolean r4 = android.C2496.m17465(r3, r11)
            r3 = 1515439(0x171faf, float:2.123582E-39)
        L_0x0063:
            r5 = 1515456(0x171fc0, float:2.123606E-39)
            r3 = r3 ^ r5
            switch(r3) {
                case 111: goto L_0x006b;
                case 15703: goto L_0x0075;
                case 15769: goto L_0x0071;
                case 15800: goto L_0x00f3;
                default: goto L_0x006a;
            }
        L_0x006a:
            goto L_0x0063
        L_0x006b:
            if (r4 == 0) goto L_0x0071
            r3 = 1516183(0x172297, float:2.124625E-39)
            goto L_0x0063
        L_0x0071:
            r3 = 1516152(0x172278, float:2.124581E-39)
            goto L_0x0063
        L_0x0075:
            r0 = r1
        L_0x0076:
            r1 = 1516214(0x1722b6, float:2.124668E-39)
        L_0x0079:
            r2 = 1516231(0x1722c7, float:2.124692E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 18: goto L_0x0081;
                case 51: goto L_0x0106;
                case 113: goto L_0x0085;
                case 468: goto L_0x008b;
                default: goto L_0x0080;
            }
        L_0x0080:
            goto L_0x0079
        L_0x0081:
            r1 = 1516276(0x1722f4, float:2.124755E-39)
            goto L_0x0079
        L_0x0085:
            if (r0 != 0) goto L_0x0081
            r1 = 1516307(0x172313, float:2.124799E-39)
            goto L_0x0079
        L_0x008b:
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.StringBuilder r0 = m17424(r0, r8)
            short[] r1 = m17436()
            java.lang.String r2 = m17423()
            int r2 = m17418(r2)
            java.lang.String r3 = m17419()
            int r3 = m17418(r3)
            java.lang.String r4 = android.C2497.m17474()
            int r4 = m17418(r4)
            java.lang.NoSuchMethodException r5 = new java.lang.NoSuchMethodException
            r6 = -1752454(0xffffffffffe5427a, float:NaN)
            r6 = r6 & r3
            r3 = r3 ^ -1
            r7 = 1752453(0x1abd85, float:2.45571E-39)
            r3 = r3 & r7
            r3 = r3 | r6
            r6 = -1749003(0xffffffffffe54ff5, float:NaN)
            r6 = r6 & r4
            r4 = r4 ^ -1
            r7 = 1749002(0x1ab00a, float:2.450874E-39)
            r4 = r4 & r7
            r4 = r4 | r6
            r6 = -1753191(0xffffffffffe53f99, float:NaN)
            r6 = r6 & r2
            r2 = r2 ^ -1
            r7 = 1753190(0x1ac066, float:2.456742E-39)
            r2 = r2 & r7
            r2 = r2 | r6
            java.lang.String r1 = m17421(r1, r3, r4, r2)
            java.lang.StringBuilder r0 = m17424(r0, r1)
            java.lang.StringBuilder r0 = m17424(r0, r10)
            java.lang.String r1 = m17420(r12)
            java.lang.StringBuilder r0 = m17424(r0, r1)
            java.lang.StringBuilder r0 = m17424(r0, r11)
            java.lang.String r0 = android.C2496.m17467(r0)
            r5.<init>(r0)
            throw r5
        L_0x00f3:
            int r0 = 0 - r0
            int r0 = 1 - r0
            r1 = 1516338(0x172332, float:2.124842E-39)
        L_0x00fa:
            r3 = 1516355(0x172343, float:2.124866E-39)
            r1 = r1 ^ r3
            switch(r1) {
                case 18: goto L_0x0002;
                case 113: goto L_0x0102;
                default: goto L_0x0101;
            }
        L_0x0101:
            goto L_0x00fa
        L_0x0102:
            r1 = 1516369(0x172351, float:2.124886E-39)
            goto L_0x00fa
        L_0x0106:
            return r0
        L_0x0107:
            r0 = r2
            goto L_0x0076
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2489.m17413(java.lang.String, java.lang.reflect.Method[], java.lang.String, java.lang.String, java.lang.String[]):java.lang.reflect.Method");
    }

    /* renamed from: ۥۣۧۥ  reason: contains not printable characters */
    private static boolean m17414(Object[] objArr, Class[] clsArr) {
        boolean z = false;
        char c = 29966;
        while (true) {
            c ^= 29983;
            switch (c) {
                case 17:
                    if (objArr == null) {
                        c = 30059;
                        break;
                    }
                case '2':
                    c = 30028;
                    break;
                case 'S':
                    char c2 = 30989;
                    while (true) {
                        c2 ^= 31006;
                        switch (c2) {
                            case 19:
                                if (clsArr == null) {
                                    c2 = 31082;
                                    break;
                                }
                            case '2':
                                c2 = 31051;
                                break;
                            case 'U':
                                int length = objArr.length;
                                int length2 = clsArr.length;
                                char c3 = 32136;
                                while (true) {
                                    c3 ^= 32153;
                                    switch (c3) {
                                        case 17:
                                            if (length == length2) {
                                                c3 = 32880;
                                                break;
                                            }
                                        case 64939:
                                            c3 = 32849;
                                            break;
                                        case 64968:
                                            return false;
                                        case 65001:
                                            int i = 0;
                                            while (true) {
                                                int length3 = objArr.length;
                                                char c4 = 32911;
                                                while (true) {
                                                    c4 ^= 32928;
                                                    switch (c4) {
                                                        case '/':
                                                            if (i < length3) {
                                                                c4 = 33004;
                                                                break;
                                                            }
                                                        case 14:
                                                            c4 = 32973;
                                                            break;
                                                        case 'L':
                                                            boolean r4 = m17429(objArr[i], C2495.m17450(clsArr[i]));
                                                            char c5 = 33035;
                                                            while (true) {
                                                                c5 ^= 33052;
                                                                switch (c5) {
                                                                    case 23:
                                                                        if (r4) {
                                                                            c5 = 33779;
                                                                            break;
                                                                        }
                                                                    case '6':
                                                                        c5 = 33097;
                                                                        break;
                                                                    case 'U':
                                                                        return false;
                                                                    case 751:
                                                                        i = 0 - ((0 - i) - 1);
                                                                        char c6 = 33810;
                                                                        while (true) {
                                                                            c6 ^= 33827;
                                                                            switch (c6) {
                                                                                case 18:
                                                                                case '1':
                                                                                    c6 = 33841;
                                                                                    break;
                                                                            }
                                                                        }
                                                                        break;
                                                                }
                                                            }
                                                            break;
                                                        case 'm':
                                                            char c7 = 33934;
                                                            while (true) {
                                                                c7 ^= 33951;
                                                                switch (c7) {
                                                                    case 17:
                                                                        c7 = 33965;
                                                                        break;
                                                                    case '2':
                                                                        return true;
                                                                }
                                                            }
                                                            break;
                                                    }
                                                }
                                            }
                                            break;
                                    }
                                }
                                break;
                            case 't':
                                int length4 = objArr.length;
                                char c8 = 31113;
                                while (true) {
                                    c8 ^= 31130;
                                    switch (c8) {
                                        case 19:
                                            if (length4 == 0) {
                                                c8 = 31857;
                                                continue;
                                            }
                                        case '2':
                                            c8 = 31175;
                                            continue;
                                        case ']':
                                            char c9 = 32012;
                                            while (true) {
                                                c9 ^= 32029;
                                                switch (c9) {
                                                    case 17:
                                                        c9 = 32043;
                                                        continue;
                                                    case '6':
                                                        break;
                                                }
                                            }
                                            break;
                                        case 1515:
                                            z = true;
                                            break;
                                    }
                                }
                                char c10 = 31888;
                                while (true) {
                                    c10 ^= 31905;
                                    switch (c10) {
                                        case 14:
                                            return z;
                                        case '1':
                                            c10 = 31919;
                                            break;
                                    }
                                }
                                break;
                        }
                    }
                    break;
                case 't':
                    char c11 = 30090;
                    while (true) {
                        c11 ^= 30107;
                        switch (c11) {
                            case 17:
                                if (clsArr != null) {
                                    c11 = 30183;
                                    continue;
                                }
                            case '2':
                                c11 = 30152;
                                continue;
                            case 'S':
                                break;
                            case '|':
                                int length5 = clsArr.length;
                                char c12 = 30214;
                                while (true) {
                                    c12 ^= 30231;
                                    switch (c12) {
                                        case 17:
                                            if (length5 == 0) {
                                                c12 = 30958;
                                                continue;
                                            }
                                        case 3751:
                                            c12 = 30927;
                                            continue;
                                        case 3800:
                                            return false;
                                        case 3833:
                                            break;
                                    }
                                }
                                break;
                        }
                    }
                    return true;
            }
        }
    }

    /* renamed from: ⁠⁠⁣⁣⁠⁠⁤⁠⁠  reason: not valid java name and contains not printable characters */
    public static String m17415() {
        int r1 = C2494.m17446();
        char c = 34058;
        while (true) {
            c ^= 34075;
            switch (c) {
                case 17:
                    if (r1 <= 0) {
                        c = 34802;
                        break;
                    }
                case 687:
                    c = 34771;
                    break;
                case 712:
                    char c2 = 34833;
                    while (true) {
                        c2 ^= 34850;
                        switch (c2) {
                            case 18:
                                return null;
                            case '3':
                                c2 = 34864;
                                break;
                        }
                    }
                    break;
                case 745:
                    return "ۖۦۖ";
            }
        }
    }

    /* renamed from: ⁠⁣⁤⁣⁤⁠⁣⁣⁣⁣⁤⁤⁣⁤⁤⁣⁤⁤⁤  reason: not valid java name and contains not printable characters */
    public static String m17416(short[] sArr, int i, int i2, int i3) {
        char[] cArr = new char[i2];
        int i4 = 0;
        while (true) {
            char c = 34957;
            while (true) {
                c ^= 34974;
                switch (c) {
                    case 19:
                        if (i4 < i2) {
                            c = 35701;
                            break;
                        }
                    case '2':
                        c = 35019;
                        break;
                    case 'U':
                        return new String(cArr);
                    case 1003:
                        short s = sArr[i - (0 - i4)];
                        cArr[i4] = (char) ((char) ((s & (i3 ^ -1)) | ((s ^ -1) & i3)));
                        i4 = 0 - ((0 - i4) - 1);
                        char c2 = 35732;
                        while (true) {
                            c2 ^= 35749;
                            switch (c2) {
                                case 22:
                                case '1':
                                    c2 = 35763;
                                    break;
                            }
                        }
                        break;
                }
            }
        }
    }

    /* renamed from: ⁣⁣⁣⁣⁣⁠⁠⁣⁤⁣⁤⁠⁣⁤⁣⁠⁣⁤⁠  reason: not valid java name and contains not printable characters */
    public static String m17417(Object obj, int i, int i2, int i3) {
        int r1 = C2494.m17446();
        char c = 35856;
        while (true) {
            c ^= 35873;
            switch (c) {
                case '1':
                    if (r1 <= 0) {
                        c = 35949;
                        break;
                    }
                case 14:
                    c = 35918;
                    break;
                case 'L':
                    return C2495.m17457((short[]) obj, i, i2, i3);
                case 'o':
                    char c2 = 35980;
                    while (true) {
                        c2 ^= 35997;
                        switch (c2) {
                            case 17:
                                c2 = 36662;
                                break;
                            case 939:
                                return null;
                        }
                    }
                    break;
            }
        }
    }

    /* renamed from: ⁣⁣⁣⁣⁣⁠⁣⁣⁣⁣⁣⁠⁠⁠⁠⁣⁣⁠  reason: not valid java name and contains not printable characters */
    public static int m17418(Object obj) {
        int r1 = m17433();
        char c = 36755;
        while (true) {
            c ^= 36772;
            switch (c) {
                case '7':
                    if (r1 < 0) {
                        c = 36848;
                        break;
                    }
                case 22:
                    c = 36817;
                    break;
                case 'T':
                    return m17426(obj);
                case 'u':
                    char c2 = 36879;
                    while (true) {
                        c2 ^= 36896;
                        switch (c2) {
                            case 14:
                                return 0;
                            case '/':
                                c2 = 36910;
                                break;
                        }
                    }
                    break;
            }
        }
    }

    /* renamed from: ⁣⁣⁣⁣⁣⁠⁣⁣⁣⁣⁣⁠⁤⁠⁤⁣  reason: not valid java name and contains not printable characters */
    public static String m17419() {
        int r1 = C2495.m17455();
        char c = 37654;
        while (true) {
            c ^= 37671;
            switch (c) {
                case '1':
                    if (r1 < 0) {
                        c = 37747;
                        break;
                    }
                case 18:
                    c = 37716;
                    break;
                case 'T':
                    return "ۥ۟ۧ";
                case 's':
                    char c2 = 37778;
                    while (true) {
                        c2 ^= 37795;
                        switch (c2) {
                            case 18:
                                return null;
                            case '1':
                                c2 = 37809;
                                break;
                        }
                    }
                    break;
            }
        }
    }

    /* renamed from: ⁣⁣⁣⁣⁣⁠⁣⁣⁤⁤⁣⁠⁠⁣⁣⁠⁠⁣  reason: not valid java name and contains not printable characters */
    public static String m17420(Object obj) {
        int r1 = C2495.m17455();
        char c = 37902;
        while (true) {
            c ^= 37919;
            switch (c) {
                case 17:
                    if (r1 < 0) {
                        c = 38646;
                        break;
                    }
                case 679:
                    c = 38615;
                    break;
                case 712:
                    char c2 = 38677;
                    while (true) {
                        c2 ^= 38694;
                        switch (c2) {
                            case 18:
                                return null;
                            case '3':
                                c2 = 38708;
                                break;
                        }
                    }
                    break;
                case 745:
                    return m17412((String[]) obj);
            }
        }
    }

    /* renamed from: ⁣⁣⁣⁣⁣⁠⁣⁤⁠⁠⁠⁠⁠⁠⁣⁣⁠  reason: not valid java name and contains not printable characters */
    public static String m17421(Object obj, int i, int i2, int i3) {
        int r1 = C2493.m17445();
        char c = 38801;
        while (true) {
            c ^= 38818;
            switch (c) {
                case '3':
                    if (r1 > 0) {
                        c = 59726;
                        break;
                    }
                case 18:
                    c = 38863;
                    break;
                case 'm':
                    char c2 = 59757;
                    while (true) {
                        c2 ^= 59774;
                        switch (c2) {
                            case 19:
                                c2 = 59788;
                                break;
                            case 242:
                                return null;
                        }
                    }
                    break;
                case 32492:
                    return C2497.m17478((short[]) obj, i, i2, i3);
            }
        }
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ⁣⁣⁤⁤⁣⁠⁣⁤⁣⁠⁣⁤⁣  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.Class[] m17422(java.lang.Object r3) {
        /*
            int r1 = m17433()
            r0 = 1567209(0x17e9e9, float:2.196128E-39)
        L_0x0007:
            r2 = 1567226(0x17e9fa, float:2.196151E-39)
            r0 = r0 ^ r2
            switch(r0) {
                case 19: goto L_0x000f;
                case 956: goto L_0x0019;
                case 989: goto L_0x0020;
                case 1010: goto L_0x0015;
                default: goto L_0x000e;
            }
        L_0x000e:
            goto L_0x0007
        L_0x000f:
            if (r1 >= 0) goto L_0x0015
            r0 = 1567302(0x17ea46, float:2.196258E-39)
            goto L_0x0007
        L_0x0015:
            r0 = 1567271(0x17ea27, float:2.196214E-39)
            goto L_0x0007
        L_0x0019:
            java.lang.reflect.Method r3 = (java.lang.reflect.Method) r3
            java.lang.Class[] r0 = r3.getParameterTypes()
        L_0x001f:
            return r0
        L_0x0020:
            r0 = 0
            r1 = 1567333(0x17ea65, float:2.196301E-39)
        L_0x0024:
            r2 = 1567350(0x17ea76, float:2.196325E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 19: goto L_0x002c;
                case 1913: goto L_0x001f;
                default: goto L_0x002b;
            }
        L_0x002b:
            goto L_0x0024
        L_0x002c:
            r1 = 1568015(0x17ed0f, float:2.197257E-39)
            goto L_0x0024
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2489.m17422(java.lang.Object):java.lang.Class[]");
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ⁣⁤⁠⁠⁠⁣⁤⁣⁠⁣⁤⁠⁠⁤⁣⁠⁤⁤  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String m17423() {
        /*
            int r1 = m17433()
            r0 = 1568108(0x17ed6c, float:2.197387E-39)
        L_0x0007:
            r2 = 1568125(0x17ed7d, float:2.197411E-39)
            r0 = r0 ^ r2
            switch(r0) {
                case 17: goto L_0x000f;
                case 180: goto L_0x0019;
                case 215: goto L_0x001c;
                case 246: goto L_0x0015;
                default: goto L_0x000e;
            }
        L_0x000e:
            goto L_0x0007
        L_0x000f:
            if (r1 >= 0) goto L_0x0015
            r0 = 1568201(0x17edc9, float:2.197518E-39)
            goto L_0x0007
        L_0x0015:
            r0 = 1568170(0x17edaa, float:2.197474E-39)
            goto L_0x0007
        L_0x0019:
            java.lang.String r0 = "ۦۧۨ"
        L_0x001b:
            return r0
        L_0x001c:
            r0 = 0
            r1 = 1568232(0x17ede8, float:2.197561E-39)
        L_0x0020:
            r2 = 1568249(0x17edf9, float:2.197585E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 17: goto L_0x0028;
                case 1022: goto L_0x001b;
                default: goto L_0x0027;
            }
        L_0x0027:
            goto L_0x0020
        L_0x0028:
            r1 = 1568263(0x17ee07, float:2.197605E-39)
            goto L_0x0020
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2489.m17423():java.lang.String");
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ⁣⁤⁣⁠⁣⁤⁤⁣⁤⁠⁠⁤  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.StringBuilder m17424(java.lang.Object r3, java.lang.Object r4) {
        /*
            int r1 = android.C2495.m17455()
            r0 = 1569007(0x17f0ef, float:2.198647E-39)
        L_0x0007:
            r2 = 1569024(0x17f100, float:2.198671E-39)
            r0 = r0 ^ r2
            switch(r0) {
                case 14: goto L_0x000f;
                case 45: goto L_0x0022;
                case 76: goto L_0x0019;
                case 495: goto L_0x0013;
                default: goto L_0x000e;
            }
        L_0x000e:
            goto L_0x0007
        L_0x000f:
            r0 = 1569069(0x17f12d, float:2.198734E-39)
            goto L_0x0007
        L_0x0013:
            if (r1 > 0) goto L_0x000f
            r0 = 1569100(0x17f14c, float:2.198777E-39)
            goto L_0x0007
        L_0x0019:
            java.lang.StringBuilder r3 = (java.lang.StringBuilder) r3
            java.lang.String r4 = (java.lang.String) r4
            java.lang.StringBuilder r0 = r3.append(r4)
        L_0x0021:
            return r0
        L_0x0022:
            r0 = 0
            r1 = 1569131(0x17f16b, float:2.198821E-39)
        L_0x0026:
            r2 = 1569148(0x17f17c, float:2.198845E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 23: goto L_0x002e;
                case 246: goto L_0x0021;
                default: goto L_0x002d;
            }
        L_0x002d:
            goto L_0x0026
        L_0x002e:
            r1 = 1569162(0x17f18a, float:2.198864E-39)
            goto L_0x0026
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2489.m17424(java.lang.Object, java.lang.Object):java.lang.StringBuilder");
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ⁤⁠⁤⁣⁣⁠⁠⁤⁠⁠  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean m17425(java.lang.Object r3, java.lang.Object r4) {
        /*
            int r1 = m17433()
            r0 = 1569255(0x17f1e7, float:2.198995E-39)
        L_0x0007:
            r2 = 1569272(0x17f1f8, float:2.199018E-39)
            r0 = r0 ^ r2
            switch(r0) {
                case 31: goto L_0x000f;
                case 1335: goto L_0x0019;
                case 1352: goto L_0x0022;
                case 1385: goto L_0x0015;
                default: goto L_0x000e;
            }
        L_0x000e:
            goto L_0x0007
        L_0x000f:
            if (r1 >= 0) goto L_0x0015
            r0 = 1569999(0x17f4cf, float:2.200037E-39)
            goto L_0x0007
        L_0x0015:
            r0 = 1569968(0x17f4b0, float:2.199994E-39)
            goto L_0x0007
        L_0x0019:
            java.lang.Object[] r3 = (java.lang.Object[]) r3
            java.lang.Class[] r4 = (java.lang.Class[]) r4
            boolean r0 = m17414((java.lang.Object[]) r3, (java.lang.Class[]) r4)
        L_0x0021:
            return r0
        L_0x0022:
            r0 = 0
            r1 = 1570030(0x17f4ee, float:2.20008E-39)
        L_0x0026:
            r2 = 1570047(0x17f4ff, float:2.200104E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 17: goto L_0x002e;
                case 498: goto L_0x0021;
                default: goto L_0x002d;
            }
        L_0x002d:
            goto L_0x0026
        L_0x002e:
            r1 = 1570061(0x17f50d, float:2.200124E-39)
            goto L_0x0026
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2489.m17425(java.lang.Object, java.lang.Object):boolean");
    }

    /* renamed from: ⁤⁠⁤⁤⁠⁣⁤⁣⁤⁠⁣⁤⁣⁠⁣⁤⁠  reason: not valid java name and contains not printable characters */
    public static int m17426(Object obj) {
        return obj.hashCode();
    }

    /* renamed from: ⁤⁠⁤⁤⁠⁣⁤⁣⁤⁠⁣⁤⁣⁠⁣⁤⁠  reason: not valid java name and contains not printable characters */
    public static Class<?> m17427(String str) throws ClassNotFoundException {
        return Class.forName(str);
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ⁤⁠⁤⁤⁠⁣⁤⁣⁤⁠⁣⁤⁣⁠⁣⁤⁠  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String m17428(short[] r5, int r6, int r7, int r8) {
        /*
            char[] r2 = new char[r7]
            r0 = 0
        L_0x0003:
            r1 = 1570154(0x17f56a, float:2.200254E-39)
        L_0x0006:
            r3 = 1570171(0x17f57b, float:2.200278E-39)
            r1 = r1 ^ r3
            switch(r1) {
                case 17: goto L_0x000e;
                case 211: goto L_0x003f;
                case 242: goto L_0x0014;
                case 3369: goto L_0x0018;
                default: goto L_0x000d;
            }
        L_0x000d:
            goto L_0x0006
        L_0x000e:
            if (r0 >= r7) goto L_0x0014
            r1 = 1570898(0x17f852, float:2.201297E-39)
            goto L_0x0006
        L_0x0014:
            r1 = 1570216(0x17f5a8, float:2.200341E-39)
            goto L_0x0006
        L_0x0018:
            int r1 = 0 - r6
            int r1 = r1 - r0
            int r1 = 0 - r1
            short r1 = r5[r1]
            r3 = r1 ^ -1
            r3 = r3 & r8
            r4 = r8 ^ -1
            r1 = r1 & r4
            r1 = r1 | r3
            char r1 = (char) r1
            char r1 = (char) r1
            r2[r0] = r1
            int r0 = 0 - r0
            int r0 = r0 + -1
            int r0 = 0 - r0
            r1 = 1570929(0x17f871, float:2.20134E-39)
        L_0x0033:
            r3 = 1570946(0x17f882, float:2.201364E-39)
            r1 = r1 ^ r3
            switch(r1) {
                case 18: goto L_0x0003;
                case 243: goto L_0x003b;
                default: goto L_0x003a;
            }
        L_0x003a:
            goto L_0x0033
        L_0x003b:
            r1 = 1570960(0x17f890, float:2.201384E-39)
            goto L_0x0033
        L_0x003f:
            java.lang.String r0 = new java.lang.String
            r0.<init>(r2)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2489.m17428(short[], int, int, int):java.lang.String");
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ⁤⁤⁠⁤⁤⁣⁣⁤⁤⁣⁠⁠⁤⁣⁠⁤⁤  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean m17429(java.lang.Object r3, java.lang.Object r4) {
        /*
            int r1 = android.C2495.m17455()
            r0 = 1571053(0x17f8ed, float:2.201514E-39)
        L_0x0007:
            r2 = 1571070(0x17f8fe, float:2.201538E-39)
            r0 = r0 ^ r2
            switch(r0) {
                case 19: goto L_0x000f;
                case 436: goto L_0x0019;
                case 469: goto L_0x001e;
                case 498: goto L_0x0015;
                default: goto L_0x000e;
            }
        L_0x000e:
            goto L_0x0007
        L_0x000f:
            if (r1 > 0) goto L_0x0015
            r0 = 1571146(0x17f94a, float:2.201644E-39)
            goto L_0x0007
        L_0x0015:
            r0 = 1571115(0x17f92b, float:2.201601E-39)
            goto L_0x0007
        L_0x0019:
            boolean r0 = r3.equals(r4)
        L_0x001d:
            return r0
        L_0x001e:
            r0 = 0
            r1 = 1571177(0x17f969, float:2.201688E-39)
        L_0x0022:
            r2 = 1571194(0x17f97a, float:2.201712E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 19: goto L_0x002a;
                case 1385: goto L_0x001d;
                default: goto L_0x0029;
            }
        L_0x0029:
            goto L_0x0022
        L_0x002a:
            r1 = 1571859(0x17fc13, float:2.202644E-39)
            goto L_0x0022
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2489.m17429(java.lang.Object, java.lang.Object):boolean");
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ⁤⁤⁠⁤⁤⁣⁤⁠⁠⁠⁣⁣⁣⁣⁤⁤  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String m17430(java.lang.Object r3, int r4, int r5, int r6) {
        /*
            int r1 = m17433()
            r0 = 1571952(0x17fc70, float:2.202774E-39)
        L_0x0007:
            r2 = 1571969(0x17fc81, float:2.202798E-39)
            r0 = r0 ^ r2
            switch(r0) {
                case 14: goto L_0x000f;
                case 47: goto L_0x0020;
                case 76: goto L_0x0019;
                case 241: goto L_0x0013;
                default: goto L_0x000e;
            }
        L_0x000e:
            goto L_0x0007
        L_0x000f:
            r0 = 1572014(0x17fcae, float:2.202861E-39)
            goto L_0x0007
        L_0x0013:
            if (r1 > 0) goto L_0x000f
            r0 = 1572045(0x17fccd, float:2.202904E-39)
            goto L_0x0007
        L_0x0019:
            short[] r3 = (short[]) r3
            java.lang.String r0 = m17416(r3, r4, r5, r6)
        L_0x001f:
            return r0
        L_0x0020:
            r0 = 0
            r1 = 1572076(0x17fcec, float:2.202948E-39)
        L_0x0024:
            r2 = 1572093(0x17fcfd, float:2.202972E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 17: goto L_0x002c;
                case 502: goto L_0x001f;
                default: goto L_0x002b;
            }
        L_0x002b:
            goto L_0x0024
        L_0x002c:
            r1 = 1572107(0x17fd0b, float:2.202991E-39)
            goto L_0x0024
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2489.m17430(java.lang.Object, int, int, int):java.lang.String");
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ⁤⁤⁠⁤⁤⁣⁤⁠⁠⁣⁠⁤⁣⁠⁤⁣  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String m17431(java.lang.Object r3, int r4, int r5, int r6) {
        /*
            int r1 = android.C2493.m17445()
            r0 = 1572851(0x17fff3, float:2.204034E-39)
        L_0x0007:
            r2 = 1572868(0x180004, float:2.204058E-39)
            r0 = r0 ^ r2
            switch(r0) {
                case 22: goto L_0x000f;
                case 53: goto L_0x0020;
                case 84: goto L_0x0019;
                case 1048567: goto L_0x0013;
                default: goto L_0x000e;
            }
        L_0x000e:
            goto L_0x0007
        L_0x000f:
            r0 = 1572913(0x180031, float:2.20412E-39)
            goto L_0x0007
        L_0x0013:
            if (r1 <= 0) goto L_0x000f
            r0 = 1572944(0x180050, float:2.204164E-39)
            goto L_0x0007
        L_0x0019:
            short[] r3 = (short[]) r3
            java.lang.String r0 = android.C2496.m17464(r3, r4, r5, r6)
        L_0x001f:
            return r0
        L_0x0020:
            r0 = 0
            r1 = 1572975(0x18006f, float:2.204207E-39)
        L_0x0024:
            r2 = 1572992(0x180080, float:2.204231E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 14: goto L_0x001f;
                case 239: goto L_0x002c;
                default: goto L_0x002b;
            }
        L_0x002b:
            goto L_0x0024
        L_0x002c:
            r1 = 1573006(0x18008e, float:2.204251E-39)
            goto L_0x0024
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2489.m17431(java.lang.Object, int, int, int):java.lang.String");
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ⁤⁤⁠⁤⁤⁤⁠⁤⁣⁣⁣⁣⁣⁤⁤  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.Class m17432(java.lang.Object r3) {
        /*
            int r1 = android.C2494.m17446()
            r0 = 1573099(0x1800eb, float:2.204381E-39)
        L_0x0007:
            r2 = 1573116(0x1800fc, float:2.204405E-39)
            r0 = r0 ^ r2
            switch(r0) {
                case 23: goto L_0x000f;
                case 815: goto L_0x0019;
                case 840: goto L_0x0020;
                case 873: goto L_0x0015;
                default: goto L_0x000e;
            }
        L_0x000e:
            goto L_0x0007
        L_0x000f:
            if (r1 > 0) goto L_0x0015
            r0 = 1573843(0x1803d3, float:2.205424E-39)
            goto L_0x0007
        L_0x0015:
            r0 = 1573812(0x1803b4, float:2.20538E-39)
            goto L_0x0007
        L_0x0019:
            java.lang.String r3 = (java.lang.String) r3
            java.lang.Class r0 = m17427((java.lang.String) r3)
        L_0x001f:
            return r0
        L_0x0020:
            r0 = 0
            r1 = 1573874(0x1803f2, float:2.205467E-39)
        L_0x0024:
            r2 = 1573891(0x180403, float:2.205491E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 18: goto L_0x001f;
                case 2033: goto L_0x002c;
                default: goto L_0x002b;
            }
        L_0x002b:
            goto L_0x0024
        L_0x002c:
            r1 = 1573905(0x180411, float:2.20551E-39)
            goto L_0x0024
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2489.m17432(java.lang.Object):java.lang.Class");
    }

    /* renamed from: ⁤⁤⁠⁤⁤⁤⁠⁤⁤⁣⁤⁠⁠⁠  reason: not valid java name and contains not printable characters */
    public static int m17433() {
        int i = 0;
        String str = "ۖ۠ۧ";
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        while (true) {
            switch (m17426((Object) str)) {
                case 1739224:
                    i3 = i | i2;
                    str = "ۚۤۡ";
                    break;
                case 1741884:
                    i2 = i3 & -1743725;
                    str = "ۦۤۥ";
                    break;
                case 1742039:
                    return i3;
                case 1749759:
                    i3 = i4 ^ -1;
                    str = "ۚ۟ۡ";
                    break;
                case 1752642:
                    i = i3 & i4;
                    str = "ۗۦۧ";
                    break;
                case 1753575:
                    i3 = 1743724;
                    str = "ۥۥۢ";
                    break;
                default:
                    i4 = m17426((Object) "ۜۚۤ");
                    str = "ۢۥۢ";
                    break;
            }
        }
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ⁤⁤⁠⁤⁤⁤⁤⁠⁤⁠⁠⁣⁤⁣⁤⁠  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String m17434() {
        /*
            int r1 = android.C2494.m17446()
            r0 = 1573998(0x18046e, float:2.205641E-39)
        L_0x0007:
            r2 = 1574015(0x18047f, float:2.205665E-39)
            r0 = r0 ^ r2
            switch(r0) {
                case 17: goto L_0x000f;
                case 211: goto L_0x001c;
                case 242: goto L_0x0015;
                case 809: goto L_0x0019;
                default: goto L_0x000e;
            }
        L_0x000e:
            goto L_0x0007
        L_0x000f:
            if (r1 >= 0) goto L_0x0015
            r0 = 1574742(0x180756, float:2.206684E-39)
            goto L_0x0007
        L_0x0015:
            r0 = 1574060(0x1804ac, float:2.205728E-39)
            goto L_0x0007
        L_0x0019:
            java.lang.String r0 = "ۘۧۡ"
        L_0x001b:
            return r0
        L_0x001c:
            r0 = 0
            r1 = 1574773(0x180775, float:2.206727E-39)
        L_0x0020:
            r2 = 1574790(0x180786, float:2.206751E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 18: goto L_0x001b;
                case 243: goto L_0x0028;
                default: goto L_0x0027;
            }
        L_0x0027:
            goto L_0x0020
        L_0x0028:
            r1 = 1574804(0x180794, float:2.20677E-39)
            goto L_0x0020
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2489.m17434():java.lang.String");
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ⁤⁤⁠⁤⁤⁤⁤⁠⁤⁣⁠⁠⁠⁣⁣⁣  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String m17435() {
        /*
            int r1 = android.C2495.m17455()
            r0 = 1574897(0x1807f1, float:2.206901E-39)
        L_0x0007:
            r2 = 1574914(0x180802, float:2.206925E-39)
            r0 = r0 ^ r2
            switch(r0) {
                case 18: goto L_0x000f;
                case 45: goto L_0x001c;
                case 76: goto L_0x0019;
                case 4083: goto L_0x0013;
                default: goto L_0x000e;
            }
        L_0x000e:
            goto L_0x0007
        L_0x000f:
            r0 = 1574959(0x18082f, float:2.206988E-39)
            goto L_0x0007
        L_0x0013:
            if (r1 >= 0) goto L_0x000f
            r0 = 1574990(0x18084e, float:2.207031E-39)
            goto L_0x0007
        L_0x0019:
            java.lang.String r0 = "ۦ۟ۢ"
        L_0x001b:
            return r0
        L_0x001c:
            r0 = 0
            r1 = 1575021(0x18086d, float:2.207075E-39)
        L_0x0020:
            r2 = 1575038(0x18087e, float:2.207098E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 19: goto L_0x0028;
                case 873: goto L_0x001b;
                default: goto L_0x0027;
            }
        L_0x0027:
            goto L_0x0020
        L_0x0028:
            r1 = 1575703(0x180b17, float:2.20803E-39)
            goto L_0x0020
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2489.m17435():java.lang.String");
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ⁤⁤⁠⁤⁤⁤⁤⁠⁤⁣⁤⁤⁠⁤⁤  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static short[] m17436() {
        /*
            int r1 = android.C2495.m17455()
            r0 = 1575796(0x180b74, float:2.20816E-39)
        L_0x0007:
            r2 = 1575813(0x180b85, float:2.208184E-39)
            r0 = r0 ^ r2
            switch(r0) {
                case 22: goto L_0x000f;
                case 55: goto L_0x001c;
                case 84: goto L_0x0019;
                case 241: goto L_0x0013;
                default: goto L_0x000e;
            }
        L_0x000e:
            goto L_0x0007
        L_0x000f:
            r0 = 1575858(0x180bb2, float:2.208247E-39)
            goto L_0x0007
        L_0x0013:
            if (r1 >= 0) goto L_0x000f
            r0 = 1575889(0x180bd1, float:2.208291E-39)
            goto L_0x0007
        L_0x0019:
            short[] r0 = f18636short
        L_0x001b:
            return r0
        L_0x001c:
            r0 = 0
            r1 = 1575920(0x180bf0, float:2.208334E-39)
        L_0x0020:
            r2 = 1575937(0x180c01, float:2.208358E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 14: goto L_0x001b;
                case 2033: goto L_0x0028;
                default: goto L_0x0027;
            }
        L_0x0027:
            goto L_0x0020
        L_0x0028:
            r1 = 1575951(0x180c0f, float:2.208378E-39)
            goto L_0x0020
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2489.m17436():short[]");
    }
}
