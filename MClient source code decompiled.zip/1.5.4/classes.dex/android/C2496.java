package android;

import java.lang.reflect.Method;

/* renamed from: android.⁤⁠⁤⁤⁣⁤⁠⁠⁠⁠⁣⁣⁠⁠⁣  reason: contains not printable characters */
public class C2496 {

    /* renamed from: ⁤⁠⁤⁠⁠⁠⁣  reason: not valid java name and contains not printable characters */
    public static boolean f18641;

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ⁠⁣⁤⁣⁤⁠⁤⁠⁤⁤⁣⁣⁣⁣⁣⁠  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String m17461(java.lang.Object r3) {
        /*
            int r1 = android.C2489.m17433()
            r0 = 1632681(0x18e9a9, float:2.287873E-39)
        L_0x0007:
            r2 = 1632698(0x18e9ba, float:2.287897E-39)
            r0 = r0 ^ r2
            switch(r0) {
                case 19: goto L_0x000f;
                case 1323: goto L_0x0019;
                case 1480: goto L_0x0020;
                case 1513: goto L_0x0015;
                default: goto L_0x000e;
            }
        L_0x000e:
            goto L_0x0007
        L_0x000f:
            if (r1 >= 0) goto L_0x0015
            r0 = 1633425(0x18ec91, float:2.288916E-39)
            goto L_0x0007
        L_0x0015:
            r0 = 1633394(0x18ec72, float:2.288873E-39)
            goto L_0x0007
        L_0x0019:
            java.lang.reflect.Method r3 = (java.lang.reflect.Method) r3
            java.lang.String r0 = r3.getName()
        L_0x001f:
            return r0
        L_0x0020:
            r0 = 0
            r1 = 1633456(0x18ecb0, float:2.28896E-39)
        L_0x0024:
            r2 = 1633473(0x18ecc1, float:2.288983E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 14: goto L_0x001f;
                case 113: goto L_0x002c;
                default: goto L_0x002b;
            }
        L_0x002b:
            goto L_0x0024
        L_0x002c:
            r1 = 1633487(0x18eccf, float:2.289003E-39)
            goto L_0x0024
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2496.m17461(java.lang.Object):java.lang.String");
    }

    /* renamed from: ⁣⁣⁣⁣⁣⁠⁠⁠⁣⁣⁤⁣⁠⁣⁤⁤  reason: not valid java name and contains not printable characters */
    public static int m17462() {
        int i = 0;
        String str = "ۖۥ۠";
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        while (true) {
            switch (C2489.m17426((Object) str)) {
                case 1738225:
                    i4 = C2489.m17426((Object) "ۙ۠۫");
                    str = "۬ۗ۠";
                    break;
                case 1741705:
                    return i3;
                case 1742157:
                    i2 = i3 & -1740929;
                    str = "ۦ۠۠";
                    break;
                case 1747841:
                    i = i3 & i4;
                    str = "ۥۜۦ";
                    break;
                case 1752367:
                    i3 = i | i2;
                    str = "ۚۙۨ";
                    break;
                case 1753446:
                    i3 = 1740928;
                    str = "۠ۥۦ";
                    break;
                default:
                    i3 = i4 ^ -1;
                    str = "ۚۨۛ";
                    break;
            }
        }
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ⁣⁣⁣⁣⁣⁠⁠⁣⁤⁣⁤⁠⁣⁣⁣⁣⁣⁠  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.reflect.Field[] m17463(java.lang.Object r3) {
        /*
            int r1 = android.C2495.m17455()
            r0 = 1633580(0x18ed2c, float:2.289133E-39)
        L_0x0007:
            r2 = 1633597(0x18ed3d, float:2.289157E-39)
            r0 = r0 ^ r2
            switch(r0) {
                case 17: goto L_0x000f;
                case 87: goto L_0x0020;
                case 118: goto L_0x0015;
                case 7465: goto L_0x0019;
                default: goto L_0x000e;
            }
        L_0x000e:
            goto L_0x0007
        L_0x000f:
            if (r1 > 0) goto L_0x0015
            r0 = 1634324(0x18f014, float:2.290176E-39)
            goto L_0x0007
        L_0x0015:
            r0 = 1633642(0x18ed6a, float:2.28922E-39)
            goto L_0x0007
        L_0x0019:
            java.lang.Class r3 = (java.lang.Class) r3
            java.lang.reflect.Field[] r0 = r3.getDeclaredFields()
        L_0x001f:
            return r0
        L_0x0020:
            r0 = 0
            r1 = 1634355(0x18f033, float:2.290219E-39)
        L_0x0024:
            r2 = 1634372(0x18f044, float:2.290243E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 22: goto L_0x001f;
                case 119: goto L_0x002c;
                default: goto L_0x002b;
            }
        L_0x002b:
            goto L_0x0024
        L_0x002c:
            r1 = 1634386(0x18f052, float:2.290263E-39)
            goto L_0x0024
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2496.m17463(java.lang.Object):java.lang.reflect.Field[]");
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ⁣⁣⁣⁣⁣⁠⁤⁤⁠⁤⁠⁠⁣⁤⁣⁤⁣  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String m17464(short[] r5, int r6, int r7, int r8) {
        /*
            char[] r2 = new char[r7]
            r0 = 0
        L_0x0003:
            r1 = 1634479(0x18f0af, float:2.290393E-39)
        L_0x0006:
            r3 = 1634496(0x18f0c0, float:2.290417E-39)
            r1 = r1 ^ r3
            switch(r1) {
                case 14: goto L_0x000e;
                case 45: goto L_0x003c;
                case 111: goto L_0x0012;
                case 460: goto L_0x0018;
                default: goto L_0x000d;
            }
        L_0x000d:
            goto L_0x0006
        L_0x000e:
            r1 = 1634541(0x18f0ed, float:2.29048E-39)
            goto L_0x0006
        L_0x0012:
            if (r0 >= r7) goto L_0x000e
            r1 = 1634572(0x18f10c, float:2.290523E-39)
            goto L_0x0006
        L_0x0018:
            int r1 = 0 - r6
            int r1 = r0 - r1
            short r1 = r5[r1]
            r3 = r1 ^ -1
            r3 = r3 & r8
            r4 = r8 ^ -1
            r1 = r1 & r4
            r1 = r1 | r3
            char r1 = (char) r1
            char r1 = (char) r1
            r2[r0] = r1
            int r0 = 0 - r0
            int r0 = 1 - r0
            r1 = 1634603(0x18f12b, float:2.290567E-39)
        L_0x0030:
            r3 = 1634620(0x18f13c, float:2.29059E-39)
            r1 = r1 ^ r3
            switch(r1) {
                case 23: goto L_0x0038;
                case 745: goto L_0x0003;
                default: goto L_0x0037;
            }
        L_0x0037:
            goto L_0x0030
        L_0x0038:
            r1 = 1635285(0x18f3d5, float:2.291522E-39)
            goto L_0x0030
        L_0x003c:
            java.lang.String r0 = new java.lang.String
            r0.<init>(r2)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2496.m17464(short[], int, int, int):java.lang.String");
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ⁣⁤⁠⁠⁠⁣⁣⁤⁤⁣⁠⁣⁣⁣⁣⁤⁤  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean m17465(java.lang.Object r3, java.lang.Object r4) {
        /*
            int r1 = android.C2493.m17445()
            r0 = 1635378(0x18f432, float:2.291653E-39)
        L_0x0007:
            r2 = 1635395(0x18f443, float:2.291677E-39)
            r0 = r0 ^ r2
            switch(r0) {
                case 18: goto L_0x000f;
                case 51: goto L_0x0020;
                case 113: goto L_0x0013;
                case 204: goto L_0x0019;
                default: goto L_0x000e;
            }
        L_0x000e:
            goto L_0x0007
        L_0x000f:
            r0 = 1635440(0x18f470, float:2.29174E-39)
            goto L_0x0007
        L_0x0013:
            if (r1 <= 0) goto L_0x000f
            r0 = 1635471(0x18f48f, float:2.291783E-39)
            goto L_0x0007
        L_0x0019:
            java.lang.String r3 = (java.lang.String) r3
            boolean r0 = r3.equals(r4)
        L_0x001f:
            return r0
        L_0x0020:
            r0 = 0
            r1 = 1635502(0x18f4ae, float:2.291826E-39)
        L_0x0024:
            r2 = 1635519(0x18f4bf, float:2.29185E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 17: goto L_0x002c;
                case 114: goto L_0x001f;
                default: goto L_0x002b;
            }
        L_0x002b:
            goto L_0x0024
        L_0x002c:
            r1 = 1635533(0x18f4cd, float:2.29187E-39)
            goto L_0x0024
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2496.m17465(java.lang.Object, java.lang.Object):boolean");
    }

    /* renamed from: ⁤⁠⁤⁠⁠⁠⁠⁣⁣⁤  reason: not valid java name and contains not printable characters */
    public static String m17466() {
        int r1 = C2495.m17455();
        char c = 18058;
        while (true) {
            c ^= 18075;
            switch (c) {
                case 17:
                    if (r1 <= 0) {
                        c = 18151;
                        break;
                    }
                case '2':
                    c = 18120;
                    break;
                case 'S':
                    char c2 = 18182;
                    while (true) {
                        c2 ^= 18199;
                        switch (c2) {
                            case 17:
                                c2 = 18213;
                                break;
                            case '2':
                                return null;
                        }
                    }
                    break;
                case '|':
                    return "ۢ۬ۢ";
            }
        }
    }

    /* renamed from: ⁤⁤⁠⁤⁤⁠⁣⁣⁣⁣⁣⁣⁣⁠  reason: not valid java name and contains not printable characters */
    public static String m17467(Object obj) {
        int r1 = C2493.m17445();
        char c = 18306;
        while (true) {
            c ^= 18323;
            switch (c) {
                case 17:
                    if (r1 > 0) {
                        c = 19050;
                        break;
                    }
                case 3519:
                    c = 19019;
                    break;
                case 3544:
                    char c2 = 19081;
                    while (true) {
                        c2 ^= 19098;
                        switch (c2) {
                            case 19:
                                c2 = 19112;
                                break;
                            case '2':
                                return null;
                        }
                    }
                    break;
                case 3577:
                    return ((StringBuilder) obj).toString();
            }
        }
    }

    /* renamed from: ⁤⁤⁠⁤⁤⁣⁣⁣⁣⁣⁤⁤⁠⁤⁠  reason: not valid java name and contains not printable characters */
    public static Class m17468(Object obj) {
        int r1 = C2493.m17445();
        char c = 19205;
        while (true) {
            c ^= 19222;
            switch (c) {
                case 19:
                    if (r1 > 0) {
                        c = 19949;
                        break;
                    }
                case '2':
                    c = 19267;
                    break;
                case 'U':
                    char c2 = 19980;
                    while (true) {
                        c2 ^= 19997;
                        switch (c2) {
                            case 17:
                                c2 = 20011;
                                break;
                            case '6':
                                return null;
                        }
                    }
                    break;
                case 1787:
                    return ((Method) obj).getReturnType();
            }
        }
    }
}
