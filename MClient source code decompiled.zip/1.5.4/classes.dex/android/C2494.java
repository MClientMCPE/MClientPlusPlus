package android;

/* renamed from: android.⁣⁣⁣⁣⁣⁠⁣⁤⁠⁠⁠⁣⁣⁣⁣⁣⁤  reason: contains not printable characters */
public class C2494 {

    /* renamed from: ⁣⁤⁠⁠⁠⁤⁠⁤⁠⁠⁣⁣  reason: not valid java name and contains not printable characters */
    public static boolean f18639 = true;

    /* renamed from: ⁣⁣⁣⁣⁣⁠⁠⁠⁠⁣⁣⁠  reason: not valid java name and contains not printable characters */
    public static int m17446() {
        int i = 0;
        String str = "۬ۛۤ";
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        while (true) {
            switch (C2489.m17426((Object) str)) {
                case 1738407:
                    i3 = i4 ^ -1;
                    str = "ۜۚۖ";
                    break;
                case 1743640:
                    i2 = i3 & -1742092;
                    str = "ۧۨۨ";
                    break;
                case 1744167:
                    return i3;
                case 1751547:
                    i = i3 & i4;
                    str = "۬ۗۚ";
                    break;
                case 1754663:
                    i3 = 1742091;
                    str = "ۤۡۘ";
                    break;
                case 1759061:
                    i4 = C2489.m17426((Object) "ۚۨۙ");
                    str = "ۖ۫ۜ";
                    break;
                default:
                    i3 = i | i2;
                    str = "ۜ۫ۖ";
                    break;
            }
        }
    }

    /* renamed from: ⁣⁣⁣⁣⁣⁠⁣⁤⁣⁠⁣⁤⁠⁠⁠⁠⁣⁣⁣  reason: not valid java name and contains not printable characters */
    public static String m17447(short[] sArr, int i, int i2, int i3) {
        char[] cArr = new char[i2];
        int i4 = 0;
        while (true) {
            char c = 29902;
            while (true) {
                c ^= 29919;
                switch (c) {
                    case 17:
                        if (i4 < i2) {
                            c = 29995;
                            break;
                        }
                    case '2':
                        c = 29964;
                        break;
                    case 467:
                        return new String(cArr);
                    case 500:
                        short s = sArr[i - (0 - i4)];
                        cArr[i4] = (char) ((char) ((s & (i3 ^ -1)) | ((s ^ -1) & i3)));
                        i4 = (i4 - 10) + 1 + 10;
                        char c2 = 30026;
                        while (true) {
                            c2 ^= 30043;
                            switch (c2) {
                                case 17:
                                    c2 = 30708;
                                    break;
                                case 687:
                            }
                        }
                        break;
                }
            }
        }
    }
}
