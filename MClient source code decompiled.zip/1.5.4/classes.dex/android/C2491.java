package android;

import java.util.HashMap;
import java.util.Map;

/* renamed from: android.ۥۢۨۦ  reason: contains not printable characters */
public class C2491 extends C2489 {

    /* renamed from: p1 */
    private static Map<Integer, Object> f626p1 = new HashMap();

    /* renamed from: p2 */
    private static Map<Integer, Object> f627p2 = new HashMap();

    /* renamed from: p3 */
    private static Map<Integer, Object> f628p3 = new HashMap();

    /* renamed from: n */
    public static Object m601n(int i) {
        Object p3 = m608p3(i);
        if (p3 == null) {
            switch (58610 ^ i) {
                case 256:
                    p3 = new String(new byte[]{(byte) -37, (byte) -96});
                    break;
                case 3725:
                    p3 = new String(new byte[]{(byte) -37, (byte) -95, (byte) -37, (byte) -90, (byte) -37, (byte) -93});
                    break;
                case 8803:
                    p3 = new String(new byte[]{(byte) -37, (byte) -89, (byte) -37, (byte) -91, (byte) -37, (byte) -89});
                    break;
                case 17878:
                    p3 = new String(new byte[]{(byte) -37, (byte) -89, (byte) -37, (byte) -89, (byte) -37, (byte) -91});
                    break;
                case 21131:
                    p3 = C2489.m17406(new String(new byte[]{(byte) 97, (byte) 110, (byte) 100, (byte) 114, (byte) 111, (byte) 105, (byte) 100, (byte) 46, (byte) 115, (byte) 117, (byte) 112, (byte) 112, (byte) 111, (byte) 114, (byte) 116, (byte) 46, (byte) 118, (byte) 52, (byte) 46, (byte) 97, (byte) 112, (byte) 112, (byte) 99, (byte) 111, (byte) 109, (byte) 112, (byte) 97, (byte) 116, (byte) 46, (byte) 108, (byte) 105, (byte) 98, (byte) 114, (byte) 97, (byte) 114, (byte) 121, (byte) 46, (byte) -37, (byte) -97, (byte) -37, (byte) -97, (byte) -37, (byte) -93, (byte) -37, (byte) -96, (byte) -37, (byte) -96}), new String(new byte[]{(byte) 115, (byte) 104, (byte) 111, (byte) 114, (byte) 116}), new String(new byte[]{(byte) 91, (byte) 83}));
                    break;
                case 23873:
                    p3 = new String(new byte[]{(byte) -37, (byte) -94, (byte) -37, (byte) -97, (byte) -37, (byte) -90});
                    break;
                case 27680:
                    p3 = new String(new byte[]{(byte) -37, (byte) -88, (byte) -37, (byte) -96, (byte) -37, (byte) -95});
                    break;
                case 33020:
                    p3 = new String(new byte[0]);
                    break;
                case 39310:
                    p3 = new String(new byte[]{(byte) -37, (byte) -94, (byte) -37, (byte) -95, (byte) -37, (byte) -94});
                    break;
                case 47310:
                    p3 = new String(new byte[]{(byte) -37, (byte) -95, (byte) -37, (byte) -96, (byte) -37, (byte) -96});
                    break;
                case 51821:
                    p3 = new String(new byte[]{(byte) -37, (byte) -97, (byte) -37, (byte) -93, (byte) -37, (byte) -91});
                    break;
                case 130072:
                    p3 = new String(new byte[]{(byte) -37, (byte) -96, (byte) -37, (byte) -97, (byte) -37, (byte) -94});
                    break;
            }
            m609p3(i, p3);
        }
        return m17403(p3);
    }

    /* renamed from: n */
    public static Object m602n(int i, Object obj) {
        Object p2 = m606p2(i);
        if (p2 == null) {
            switch (9965 ^ i) {
                case 87600:
                    p2 = C2489.m17406(new String(new byte[]{(byte) 110, (byte) 112, (byte) 46, (byte) 84, (byte) 101, (byte) 115, (byte) 116}), new String(new byte[]{(byte) 116, (byte) 101, (byte) 115, (byte) 116}), new String(new byte[]{(byte) 105, (byte) 110, (byte) 116}));
                    break;
            }
            m607p2(i, p2);
        }
        return m17404(p2, obj);
    }

    /* renamed from: n */
    public static Object m603n(int i, Object obj, Object[] objArr) throws Throwable {
        Object p1 = m604p1(i);
        if (p1 == null) {
            switch (53845 ^ i) {
                case 4186:
                    p1 = C2489.m17407(new String(new byte[]{(byte) 106, (byte) 97, (byte) 118, (byte) 97, (byte) 46, (byte) 108, (byte) 97, (byte) 110, (byte) 103, (byte) 46, (byte) 83, (byte) 116, (byte) 114, (byte) 105, (byte) 110, (byte) 103, (byte) 66, (byte) 117, (byte) 102, (byte) 102, (byte) 101, (byte) 114}), new String(new byte[]{(byte) 97, (byte) 112, (byte) 112, (byte) 101, (byte) 110, (byte) 100}), new String(new byte[]{(byte) 106, (byte) 97, (byte) 118, (byte) 97, (byte) 46, (byte) 108, (byte) 97, (byte) 110, (byte) 103, (byte) 46, (byte) 83, (byte) 116, (byte) 114, (byte) 105, (byte) 110, (byte) 103, (byte) 66, (byte) 117, (byte) 102, (byte) 102, (byte) 101, (byte) 114}), new String(new byte[]{(byte) 105, (byte) 110, (byte) 116}));
                    break;
                case 18995:
                    p1 = C2489.m17407(new String(new byte[]{(byte) 106, (byte) 97, (byte) 118, (byte) 97, (byte) 46, (byte) 108, (byte) 97, (byte) 110, (byte) 103, (byte) 46, (byte) 73, (byte) 110, (byte) 116, (byte) 101, (byte) 103, (byte) 101, (byte) 114}), new String(new byte[]{(byte) 116, (byte) 111, (byte) 72, (byte) 101, (byte) 120, (byte) 83, (byte) 116, (byte) 114, (byte) 105, (byte) 110, (byte) 103}), new String(new byte[]{(byte) 106, (byte) 97, (byte) 118, (byte) 97, (byte) 46, (byte) 108, (byte) 97, (byte) 110, (byte) 103, (byte) 46, (byte) 83, (byte) 116, (byte) 114, (byte) 105, (byte) 110, (byte) 103}), new String(new byte[]{(byte) 105, (byte) 110, (byte) 116}));
                    break;
                case 20574:
                    p1 = C2489.m17407(new String(new byte[]{(byte) 106, (byte) 97, (byte) 118, (byte) 97, (byte) 46, (byte) 108, (byte) 97, (byte) 110, (byte) 103, (byte) 46, (byte) 83, (byte) 116, (byte) 114, (byte) 105, (byte) 110, (byte) 103}), new String(new byte[]{(byte) 105, (byte) 110, (byte) 100, (byte) 101, (byte) 120, (byte) 79, (byte) 102}), new String(new byte[]{(byte) 105, (byte) 110, (byte) 116}), new String(new byte[]{(byte) 105, (byte) 110, (byte) 116}));
                    break;
                case 43931:
                    p1 = C2489.m17407(new String(new byte[]{(byte) 106, (byte) 97, (byte) 118, (byte) 97, (byte) 46, (byte) 108, (byte) 97, (byte) 110, (byte) 103, (byte) 46, (byte) 79, (byte) 98, (byte) 106, (byte) 101, (byte) 99, (byte) 116}), new String(new byte[]{(byte) 104, (byte) 97, (byte) 115, (byte) 104, (byte) 67, (byte) 111, (byte) 100, (byte) 101}), new String(new byte[]{(byte) 105, (byte) 110, (byte) 116}), new String[0]);
                    break;
                case 48236:
                    p1 = C2489.m17407(new String(new byte[]{(byte) 106, (byte) 97, (byte) 118, (byte) 97, (byte) 46, (byte) 108, (byte) 97, (byte) 110, (byte) 103, (byte) 46, (byte) 83, (byte) 116, (byte) 114, (byte) 105, (byte) 110, (byte) 103}), new String(new byte[]{(byte) 99, (byte) 104, (byte) 97, (byte) 114, (byte) 65, (byte) 116}), new String(new byte[]{(byte) 99, (byte) 104, (byte) 97, (byte) 114}), new String(new byte[]{(byte) 105, (byte) 110, (byte) 116}));
                    break;
                case 56686:
                    p1 = C2489.m17407(new String(new byte[]{(byte) 106, (byte) 97, (byte) 118, (byte) 97, (byte) 46, (byte) 105, (byte) 111, (byte) 46, (byte) 66, (byte) 121, (byte) 116, (byte) 101, (byte) 65, (byte) 114, (byte) 114, (byte) 97, (byte) 121, (byte) 79, (byte) 117, (byte) 116, (byte) 112, (byte) 117, (byte) 116, (byte) 83, (byte) 116, (byte) 114, (byte) 101, (byte) 97, (byte) 109}), new String(new byte[]{(byte) 119, (byte) 114, (byte) 105, (byte) 116, (byte) 101}), new String(new byte[]{(byte) 118, (byte) 111, (byte) 105, (byte) 100}), new String(new byte[]{(byte) 105, (byte) 110, (byte) 116}));
                    break;
                case 56913:
                    p1 = C2489.m17407(new String(new byte[]{(byte) 106, (byte) 97, (byte) 118, (byte) 97, (byte) 46, (byte) 108, (byte) 97, (byte) 110, (byte) 103, (byte) 46, (byte) 83, (byte) 116, (byte) 114, (byte) 105, (byte) 110, (byte) 103, (byte) 66, (byte) 117, (byte) 102, (byte) 102, (byte) 101, (byte) 114}), new String(new byte[]{(byte) 97, (byte) 112, (byte) 112, (byte) 101, (byte) 110, (byte) 100}), new String(new byte[]{(byte) 106, (byte) 97, (byte) 118, (byte) 97, (byte) 46, (byte) 108, (byte) 97, (byte) 110, (byte) 103, (byte) 46, (byte) 83, (byte) 116, (byte) 114, (byte) 105, (byte) 110, (byte) 103, (byte) 66, (byte) 117, (byte) 102, (byte) 102, (byte) 101, (byte) 114}), new String(new byte[]{(byte) 106, (byte) 97, (byte) 118, (byte) 97, (byte) 46, (byte) 108, (byte) 97, (byte) 110, (byte) 103, (byte) 46, (byte) 83, (byte) 116, (byte) 114, (byte) 105, (byte) 110, (byte) 103}));
                    break;
                case 60020:
                    p1 = C2489.m17407(new String(new byte[]{(byte) 106, (byte) 97, (byte) 118, (byte) 97, (byte) 46, (byte) 108, (byte) 97, (byte) 110, (byte) 103, (byte) 46, (byte) 77, (byte) 97, (byte) 116, (byte) 104}), new String(new byte[]{(byte) 114, (byte) 97, (byte) 110, (byte) 100, (byte) 111, (byte) 109}), new String(new byte[]{(byte) 100, (byte) 111, (byte) 117, (byte) 98, (byte) 108, (byte) 101}), new String[0]);
                    break;
                case 102658:
                    p1 = C2489.m17407(new String(new byte[]{(byte) 106, (byte) 97, (byte) 118, (byte) 97, (byte) 46, (byte) 105, (byte) 111, (byte) 46, (byte) 66, (byte) 121, (byte) 116, (byte) 101, (byte) 65, (byte) 114, (byte) 114, (byte) 97, (byte) 121, (byte) 79, (byte) 117, (byte) 116, (byte) 112, (byte) 117, (byte) 116, (byte) 83, (byte) 116, (byte) 114, (byte) 101, (byte) 97, (byte) 109}), new String(new byte[]{(byte) 116, (byte) 111, (byte) 66, (byte) 121, (byte) 116, (byte) 101, (byte) 65, (byte) 114, (byte) 114, (byte) 97, (byte) 121}), new String(new byte[]{(byte) 91, (byte) 66}), new String[0]);
                    break;
                case 112949:
                    p1 = C2489.m17407(new String(new byte[]{(byte) 106, (byte) 97, (byte) 118, (byte) 97, (byte) 46, (byte) 108, (byte) 97, (byte) 110, (byte) 103, (byte) 46, (byte) 83, (byte) 116, (byte) 114, (byte) 105, (byte) 110, (byte) 103}), new String(new byte[]{(byte) 108, (byte) 101, (byte) 110, (byte) 103, (byte) 116, (byte) 104}), new String(new byte[]{(byte) 105, (byte) 110, (byte) 116}), new String[0]);
                    break;
                case 114773:
                    p1 = C2489.m17407(new String(new byte[]{(byte) 106, (byte) 97, (byte) 118, (byte) 97, (byte) 46, (byte) 108, (byte) 97, (byte) 110, (byte) 103, (byte) 46, (byte) 83, (byte) 116, (byte) 114, (byte) 105, (byte) 110, (byte) 103, (byte) 66, (byte) 117, (byte) 102, (byte) 102, (byte) 101, (byte) 114}), new String(new byte[]{(byte) 116, (byte) 111, (byte) 83, (byte) 116, (byte) 114, (byte) 105, (byte) 110, (byte) 103}), new String(new byte[]{(byte) 106, (byte) 97, (byte) 118, (byte) 97, (byte) 46, (byte) 108, (byte) 97, (byte) 110, (byte) 103, (byte) 46, (byte) 83, (byte) 116, (byte) 114, (byte) 105, (byte) 110, (byte) 103}), new String[0]);
                    break;
            }
            m605p1(i, p1);
        }
        return m17405(p1, obj, objArr);
    }

    /* renamed from: p1 */
    public static Object m604p1(int i) {
        return f626p1.get(Integer.valueOf(i));
    }

    /* renamed from: p1 */
    public static void m605p1(int i, Object obj) {
        f626p1.put(Integer.valueOf(i), obj);
    }

    /* renamed from: p2 */
    public static Object m606p2(int i) {
        return f627p2.get(Integer.valueOf(i));
    }

    /* renamed from: p2 */
    public static void m607p2(int i, Object obj) {
        f627p2.put(Integer.valueOf(i), obj);
    }

    /* renamed from: p3 */
    public static Object m608p3(int i) {
        return f628p3.get(Integer.valueOf(i));
    }

    /* renamed from: p3 */
    public static void m609p3(int i, Object obj) {
        f628p3.put(Integer.valueOf(i), obj);
    }
}
