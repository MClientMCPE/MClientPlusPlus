package android;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;

/* renamed from: android.⁣⁣⁣⁣⁣⁠⁣⁣⁣⁣⁤⁤⁠⁤⁣⁠⁤⁤  reason: contains not printable characters */
public class C2493 {

    /* renamed from: ⁣⁤⁠⁠⁠⁤⁠⁤⁠⁣⁤⁤⁣⁤⁤⁤  reason: not valid java name and contains not printable characters */
    public static boolean f18638 = true;

    /* renamed from: ⁠⁠⁠⁣⁣⁠⁣⁤⁤⁣⁤⁤⁤  reason: not valid java name and contains not printable characters */
    public static String m17437() {
        int r1 = C2494.m17446();
        char c = 24012;
        while (true) {
            c ^= 24029;
            switch (c) {
                case 17:
                    if (r1 < 0) {
                        c = 24105;
                        break;
                    }
                case '6':
                    c = 24074;
                    break;
                case 983:
                    char c2 = 24136;
                    while (true) {
                        c2 ^= 24153;
                        switch (c2) {
                            case 17:
                                c2 = 24167;
                                break;
                            case '>':
                                return null;
                        }
                    }
                    break;
                case 1012:
                    return "ۨ۬ۗ";
            }
        }
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ⁠⁠⁠⁣⁣⁤⁣⁤⁣⁠⁣⁤⁤  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String m17438(short[] r5, int r6, int r7, int r8) {
        /*
            char[] r2 = new char[r7]
            r0 = 0
        L_0x0003:
            r1 = 1597124(0x185ec4, float:2.238047E-39)
        L_0x0006:
            r3 = 1597141(0x185ed5, float:2.238071E-39)
            r1 = r1 ^ r3
            switch(r1) {
                case 17: goto L_0x000e;
                case 16216: goto L_0x003f;
                case 16249: goto L_0x0018;
                case 16315: goto L_0x0014;
                default: goto L_0x000d;
            }
        L_0x000d:
            goto L_0x0006
        L_0x000e:
            if (r0 >= r7) goto L_0x0014
            r1 = 1597868(0x1861ac, float:2.23909E-39)
            goto L_0x0006
        L_0x0014:
            r1 = 1597837(0x18618d, float:2.239047E-39)
            goto L_0x0006
        L_0x0018:
            int r1 = r6 + 8
            int r1 = r1 + r0
            int r1 = r1 + -8
            short r1 = r5[r1]
            r3 = r1 ^ -1
            r3 = r3 & r8
            r4 = r8 ^ -1
            r1 = r1 & r4
            r1 = r1 | r3
            char r1 = (char) r1
            char r1 = (char) r1
            r2[r0] = r1
            int r0 = 0 - r0
            int r0 = r0 + -1
            int r0 = 0 - r0
            r1 = 1597899(0x1861cb, float:2.239133E-39)
        L_0x0033:
            r3 = 1597916(0x1861dc, float:2.239157E-39)
            r1 = r1 ^ r3
            switch(r1) {
                case 23: goto L_0x003b;
                case 54: goto L_0x0003;
                default: goto L_0x003a;
            }
        L_0x003a:
            goto L_0x0033
        L_0x003b:
            r1 = 1597930(0x1861ea, float:2.239177E-39)
            goto L_0x0033
        L_0x003f:
            java.lang.String r0 = new java.lang.String
            r0.<init>(r2)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2493.m17438(short[], int, int, int):java.lang.String");
    }

    /* renamed from: ⁣⁠⁠⁤⁠⁣⁤⁠⁤⁠  reason: not valid java name and contains not printable characters */
    public static Object m17439(Object obj, Object obj2, Object obj3, Object obj4) {
        int r1 = m17445();
        char c = 25159;
        while (true) {
            c ^= 25176;
            switch (c) {
                case 31:
                    if (r1 >= 0) {
                        c = 25903;
                        break;
                    }
                case '>':
                    c = 25221;
                    break;
                case 221:
                    char c2 = 25934;
                    while (true) {
                        c2 ^= 25951;
                        switch (c2) {
                            case 17:
                                c2 = 25965;
                                break;
                            case '2':
                                return null;
                        }
                    }
                    break;
                case 1911:
                    return C2489.m17402((Class) obj, (String) obj2, (String) obj3, (String[]) obj4);
            }
        }
    }

    /* renamed from: ⁣⁣⁣⁣⁣⁠⁠⁤⁣⁠⁤⁣⁠⁠⁠⁣⁣⁣  reason: not valid java name and contains not printable characters */
    public static String m17440(Object obj) {
        int r1 = C2496.m17462();
        char c = 26058;
        while (true) {
            c ^= 26075;
            switch (c) {
                case 17:
                    if (r1 <= 0) {
                        c = 26151;
                        break;
                    }
                case '2':
                    c = 26120;
                    break;
                case 979:
                    char c2 = 26182;
                    while (true) {
                        c2 ^= 26199;
                        switch (c2) {
                            case 17:
                                c2 = 26864;
                                break;
                            case 3751:
                                return null;
                        }
                    }
                    break;
                case 1020:
                    return ((Field) obj).getName();
            }
        }
    }

    /* renamed from: ⁣⁣⁤⁤⁣⁠⁣⁣⁤⁤⁣⁠  reason: not valid java name and contains not printable characters */
    public static Throwable m17441(Object obj) {
        int r1 = C2496.m17462();
        char c = 26957;
        while (true) {
            c ^= 26974;
            switch (c) {
                case 19:
                    if (r1 < 0) {
                        c = 27050;
                        break;
                    }
                case '2':
                    c = 27019;
                    break;
                case 213:
                    char c2 = 27081;
                    while (true) {
                        c2 ^= 27098;
                        switch (c2) {
                            case 19:
                                c2 = 27112;
                                break;
                            case '2':
                                return null;
                        }
                    }
                    break;
                case 244:
                    return ((InvocationTargetException) obj).getTargetException();
            }
        }
    }

    /* renamed from: ⁤⁠⁤⁤⁣⁤⁤⁣⁤⁤⁤⁣⁤⁠⁠⁤  reason: not valid java name and contains not printable characters */
    public static String m17442() {
        int r1 = C2496.m17462();
        char c = 27856;
        while (true) {
            c ^= 27873;
            switch (c) {
                case '1':
                    if (r1 <= 0) {
                        c = 27949;
                        break;
                    }
                case 14:
                    c = 27918;
                    break;
                case 460:
                    return "ۡ۫ۘ";
                case 495:
                    char c2 = 27980;
                    while (true) {
                        c2 ^= 27997;
                        switch (c2) {
                            case 17:
                                c2 = 28011;
                                break;
                            case '6':
                                return null;
                        }
                    }
                    break;
            }
        }
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* renamed from: ⁤⁤⁠⁤⁣⁠⁠⁣  reason: not valid java name and contains not printable characters */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.Class m17443(java.lang.Object r3) {
        /*
            int r1 = android.C2489.m17433()
            r0 = 1600968(0x186dc8, float:2.243434E-39)
        L_0x0007:
            r2 = 1600985(0x186dd9, float:2.243458E-39)
            r0 = r0 ^ r2
            switch(r0) {
                case 17: goto L_0x000f;
                case 7496: goto L_0x0020;
                case 7529: goto L_0x0019;
                case 7595: goto L_0x0015;
                default: goto L_0x000e;
            }
        L_0x000e:
            goto L_0x0007
        L_0x000f:
            if (r1 >= 0) goto L_0x0015
            r0 = 1601712(0x1870b0, float:2.244477E-39)
            goto L_0x0007
        L_0x0015:
            r0 = 1601681(0x187091, float:2.244433E-39)
            goto L_0x0007
        L_0x0019:
            java.lang.reflect.Field r3 = (java.lang.reflect.Field) r3
            java.lang.Class r0 = r3.getDeclaringClass()
        L_0x001f:
            return r0
        L_0x0020:
            r0 = 0
            r1 = 1601743(0x1870cf, float:2.24452E-39)
        L_0x0024:
            r2 = 1601760(0x1870e0, float:2.244544E-39)
            r1 = r1 ^ r2
            switch(r1) {
                case 14: goto L_0x001f;
                case 47: goto L_0x002c;
                default: goto L_0x002b;
            }
        L_0x002b:
            goto L_0x0024
        L_0x002c:
            r1 = 1601774(0x1870ee, float:2.244563E-39)
            goto L_0x0024
        */
        throw new UnsupportedOperationException("Method not decompiled: android.C2493.m17443(java.lang.Object):java.lang.Class");
    }

    /* renamed from: ⁤⁤⁠⁤⁤⁠⁤⁣⁠⁤⁤⁣⁤⁣⁠⁣⁤⁣  reason: not valid java name and contains not printable characters */
    public static String m17444() {
        int r1 = C2489.m17433();
        char c = 29003;
        while (true) {
            c ^= 29020;
            switch (c) {
                case 23:
                    if (r1 <= 0) {
                        c = 29747;
                        break;
                    }
                case '6':
                    c = 29065;
                    break;
                case 213:
                    char c2 = 29778;
                    while (true) {
                        c2 ^= 29795;
                        switch (c2) {
                            case 18:
                                return null;
                            case '1':
                                c2 = 29809;
                                break;
                        }
                    }
                    break;
                case 1391:
                    return "ۖۧۨ";
            }
        }
    }

    /* renamed from: ⁤⁤⁠⁤⁤⁤⁠⁤⁠  reason: not valid java name and contains not printable characters */
    public static int m17445() {
        int i = 0;
        String str = "ۙۥ۬";
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        while (true) {
            switch (C2489.m17426((Object) str)) {
                case 1741103:
                    i3 = -1737911;
                    str = "ۧ۟ۨ";
                    break;
                case 1741120:
                    i4 = C2489.m17426((Object) "ۖۜۦ");
                    str = "ۜ۠ۡ";
                    break;
                case 1743837:
                    i3 = i4 ^ -1;
                    str = "ۜ۫ۥ";
                    break;
                case 1744182:
                    i2 = i3 & 1737910;
                    str = "ۙۥۛ";
                    break;
                case 1749359:
                    i3 = i | i2;
                    str = "ۢ۬ۚ";
                    break;
                case 1749968:
                    return i3;
                default:
                    i = i3 & i4;
                    str = "ۢۘۥ";
                    break;
            }
        }
    }
}
