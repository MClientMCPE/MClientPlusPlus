package crashlog.log;

import android.app.Application;

/* renamed from: np.log.NPCrashApplication */
public class NPCrashApplication extends Application {
    public void onCreate() {
        super.onCreate();
        NPCrashHandler.getInstance().init(getApplicationContext());
    }
}
