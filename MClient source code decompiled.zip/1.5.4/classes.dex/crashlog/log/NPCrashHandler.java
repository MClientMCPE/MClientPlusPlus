package crashlog.log;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.os.Looper;
import android.os.Process;
import android.util.Log;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.Thread;
import java.lang.reflect.Field;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/* renamed from: np.log.NPCrashHandler */
public class NPCrashHandler implements Thread.UncaughtExceptionHandler {
    private static NPCrashHandler INSTANCE = new NPCrashHandler();
    public static final String TAG = "NPCrashHandler";
    private DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");
    private Map<String, String> infos = new HashMap();
    /* access modifiers changed from: private */
    public Context mContext;
    private Thread.UncaughtExceptionHandler mDefaultHandler;

    NPCrashHandler() {
    }

    public static NPCrashHandler getInstance() {
        return INSTANCE;
    }

    public void init(Context var1) {
        this.mContext = var1;
        this.mDefaultHandler = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(this);
    }

    public void uncaughtException(Thread var1, Throwable var2) {
        if (handleException(var2) || this.mDefaultHandler == null) {
            try {
                Thread.sleep(3000);
            } catch (InterruptedException var6) {
                Log.e("CrashHandler", "error : ", var6);
            }
            Process.killProcess(Process.myPid());
            System.exit(1);
            return;
        }
        this.mDefaultHandler.uncaughtException(var1, var2);
    }

    private boolean handleException(Throwable var1) {
        if (var1 == null) {
            return false;
        }
        new Thread() {
            public void run() {
                Looper.prepare();
                Toast.makeText(NPCrashHandler.this.mContext, "MClientProtect has detected something Unusual. Please go to games/com.mclient for logs", 1).show();
                Looper.loop();
            }
        }.start();
        collectDeviceInfo(this.mContext);
        saveCrashInfo2File(var1);
        return true;
    }

    public void collectDeviceInfo(Context var1) {
        try {
            PackageInfo var4 = var1.getPackageManager().getPackageInfo(var1.getPackageName(), 1);
            if (var4 != null) {
                this.infos.put("versionName", var4.versionName == null ? "null" : var4.versionName);
                this.infos.put("versionCode", var4.versionCode + "");
            }
        } catch (PackageManager.NameNotFoundException var12) {
            Log.e("CrashHandler", "an error occured when collect package info", var12);
        }
        try {
            Field[] var14 = Class.forName("android.os.Build").getDeclaredFields();
            for (Field var7 : var14) {
                try {
                    var7.setAccessible(true);
                    this.infos.put(var7.getName(), var7.get((Object) null).toString());
                    Log.d("CrashHandler", var7.getName() + " : " + var7.get((Object) null));
                } catch (Exception var10) {
                    Log.e("CrashHandler", "an error occured when collect crash info", var10);
                }
            }
        } catch (ClassNotFoundException var11) {
            throw new NoClassDefFoundError(var11.getMessage());
        }
    }

    private String saveCrashInfo2File(Throwable var1) {
        StringBuffer var3 = new StringBuffer();
        for (Map.Entry var6 : this.infos.entrySet()) {
            var3.append(((String) var6.getKey()) + "=" + ((String) var6.getValue()) + "\n");
        }
        StringWriter var19 = new StringWriter();
        PrintWriter var20 = new PrintWriter(var19);
        var1.printStackTrace(var20);
        for (Throwable var21 = var1.getCause(); var21 != null; var21 = var21.getCause()) {
            var21.printStackTrace(var20);
        }
        var20.close();
        var3.append(var19.toString());
        try {
            long var10 = System.currentTimeMillis();
            String var13 = "mclientprotect-crash" + this.formatter.format(new Date()) + "-" + var10 + ".log";
            if (Environment.getExternalStorageState().equals("mounted")) {
                File var15 = new File("/sdcard/games/com.mclient/crash-logs");
                if (!var15.exists()) {
                    var15.mkdirs();
                }
                FileOutputStream var16 = new FileOutputStream("/sdcard/games/com.mclient/crash-logs" + var13);
                var16.write(var3.toString().getBytes());
                var16.close();
            }
            return var13;
        } catch (Exception var18) {
            Log.e("CrashHandler", "an error occured while writing file...", var18);
            return null;
        }
    }
}
