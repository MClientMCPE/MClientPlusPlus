package p000;

import java.util.Map;

/* renamed from: fy */
public final class C0727fy implements C1373my<wj0> {
    /* renamed from: a */
    public final /* synthetic */ void mo2197a(Object obj, Map map) {
        wj0 wj0 = (wj0) obj;
        if (wj0.mo6649x() != null) {
            ((ht1) wj0.mo6649x()).mo6706m1();
        }
        C1709qm F = wj0.mo6583F();
        if (F != null) {
            F.mo10413m1();
            return;
        }
        C1709qm y = wj0.mo6650y();
        if (y != null) {
            y.mo10413m1();
        } else {
            C0680fe.m4893p("A GMSG tried to close something that wasn't an overlay.");
        }
    }
}
