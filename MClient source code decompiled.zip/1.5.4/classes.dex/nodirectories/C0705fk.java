package p000;

import java.util.concurrent.Callable;
import p000.C1461nj;

/* renamed from: fk */
public final class C0705fk implements Callable<C1461nj.C1462a> {

    /* renamed from: a */
    public final /* synthetic */ String f5424a;

    /* renamed from: b */
    public final /* synthetic */ C1065jj f5425b;

    public C0705fk(C1065jj jjVar, String str) {
        this.f5425b = jjVar;
        this.f5424a = str;
    }

    /* JADX WARNING: Removed duplicated region for block: B:39:0x0142  */
    /* JADX WARNING: Removed duplicated region for block: B:64:0x013a A[SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final java.lang.Object call() {
        /*
            r17 = this;
            r1 = r17
            jj r0 = r1.f5425b
            java.lang.String r2 = r1.f5424a
            java.lang.String r3 = java.lang.String.valueOf(r2)
            int r4 = r3.length()
            java.lang.String r5 = "Querying owned items, item type: "
            if (r4 == 0) goto L_0x0017
            java.lang.String r3 = r5.concat(r3)
            goto L_0x001c
        L_0x0017:
            java.lang.String r3 = new java.lang.String
            r3.<init>(r5)
        L_0x001c:
            java.lang.String r4 = "BillingClient"
            p000.k23.m7991a((java.lang.String) r4, (java.lang.String) r3)
            java.util.ArrayList r3 = new java.util.ArrayList
            r3.<init>()
            boolean r5 = r0.f8494m
            boolean r6 = r0.f8500s
            java.lang.String r7 = r0.f8483b
            android.os.Bundle r8 = new android.os.Bundle
            r8.<init>()
            java.lang.String r9 = "playBillingLibraryVersion"
            r8.putString(r9, r7)
            r7 = 1
            if (r5 == 0) goto L_0x0040
            if (r6 == 0) goto L_0x0040
            java.lang.String r5 = "enablePendingPurchases"
            r8.putBoolean(r5, r7)
        L_0x0040:
            r6 = 0
        L_0x0041:
            boolean r9 = r0.f8494m     // Catch:{ Exception -> 0x01f8 }
            if (r9 == 0) goto L_0x0076
            n23 r9 = r0.f8487f     // Catch:{ Exception -> 0x01f8 }
            android.content.Context r10 = r0.f8486e     // Catch:{ Exception -> 0x01f8 }
            java.lang.String r10 = r10.getPackageName()     // Catch:{ Exception -> 0x01f8 }
            l23 r9 = (p000.l23) r9     // Catch:{ Exception -> 0x01f8 }
            android.os.Parcel r11 = r9.mo9430a()     // Catch:{ Exception -> 0x01f8 }
            r12 = 9
            r11.writeInt(r12)     // Catch:{ Exception -> 0x01f8 }
            r11.writeString(r10)     // Catch:{ Exception -> 0x01f8 }
            r11.writeString(r2)     // Catch:{ Exception -> 0x01f8 }
            r11.writeString(r6)     // Catch:{ Exception -> 0x01f8 }
            p000.q23.m11407a((android.os.Parcel) r11, (android.os.Parcelable) r8)     // Catch:{ Exception -> 0x01f8 }
            r6 = 11
            android.os.Parcel r6 = r9.mo9431a(r6, r11)     // Catch:{ Exception -> 0x01f8 }
            android.os.Parcelable$Creator r9 = android.os.Bundle.CREATOR     // Catch:{ Exception -> 0x01f8 }
            android.os.Parcelable r9 = p000.q23.m11406a((android.os.Parcel) r6, r9)     // Catch:{ Exception -> 0x01f8 }
            android.os.Bundle r9 = (android.os.Bundle) r9     // Catch:{ Exception -> 0x01f8 }
            r6.recycle()     // Catch:{ Exception -> 0x01f8 }
            goto L_0x00a1
        L_0x0076:
            n23 r9 = r0.f8487f     // Catch:{ Exception -> 0x01f8 }
            android.content.Context r10 = r0.f8486e     // Catch:{ Exception -> 0x01f8 }
            java.lang.String r10 = r10.getPackageName()     // Catch:{ Exception -> 0x01f8 }
            l23 r9 = (p000.l23) r9     // Catch:{ Exception -> 0x01f8 }
            android.os.Parcel r11 = r9.mo9430a()     // Catch:{ Exception -> 0x01f8 }
            r12 = 3
            r11.writeInt(r12)     // Catch:{ Exception -> 0x01f8 }
            r11.writeString(r10)     // Catch:{ Exception -> 0x01f8 }
            r11.writeString(r2)     // Catch:{ Exception -> 0x01f8 }
            r11.writeString(r6)     // Catch:{ Exception -> 0x01f8 }
            r6 = 4
            android.os.Parcel r6 = r9.mo9431a(r6, r11)     // Catch:{ Exception -> 0x01f8 }
            android.os.Parcelable$Creator r9 = android.os.Bundle.CREATOR     // Catch:{ Exception -> 0x01f8 }
            android.os.Parcelable r9 = p000.q23.m11406a((android.os.Parcel) r6, r9)     // Catch:{ Exception -> 0x01f8 }
            android.os.Bundle r9 = (android.os.Bundle) r9     // Catch:{ Exception -> 0x01f8 }
            r6.recycle()     // Catch:{ Exception -> 0x01f8 }
        L_0x00a1:
            java.lang.String r6 = "getPurchase()"
            mj r10 = p000.C2151vj.f16141h
            java.lang.String r11 = "INAPP_DATA_SIGNATURE_LIST"
            java.lang.String r12 = "INAPP_PURCHASE_DATA_LIST"
            java.lang.String r13 = "INAPP_PURCHASE_ITEM_LIST"
            r14 = 0
            if (r9 != 0) goto L_0x00ba
            java.lang.Object[] r15 = new java.lang.Object[r7]
            r15[r14] = r6
            java.lang.String r6 = "%s got null owned items list"
            java.lang.String r6 = java.lang.String.format(r6, r15)
            goto L_0x0133
        L_0x00ba:
            int r15 = p000.k23.m7988a((android.os.Bundle) r9, (java.lang.String) r4)
            p000.k23.m7992b((android.os.Bundle) r9, (java.lang.String) r4)
            mj r5 = new mj
            r5.<init>()
            r5.f10285a = r15
            if (r15 == 0) goto L_0x00e0
            r10 = 2
            java.lang.Object[] r10 = new java.lang.Object[r10]
            r10[r14] = r6
            java.lang.Integer r6 = java.lang.Integer.valueOf(r15)
            r10[r7] = r6
            java.lang.String r6 = "%s failed. Response code: %s"
            java.lang.String r6 = java.lang.String.format(r6, r10)
            p000.k23.m7993b((java.lang.String) r4, (java.lang.String) r6)
            r10 = r5
            goto L_0x0136
        L_0x00e0:
            boolean r5 = r9.containsKey(r13)
            if (r5 == 0) goto L_0x0129
            boolean r5 = r9.containsKey(r12)
            if (r5 == 0) goto L_0x0129
            boolean r5 = r9.containsKey(r11)
            if (r5 != 0) goto L_0x00f3
            goto L_0x0129
        L_0x00f3:
            java.util.ArrayList r5 = r9.getStringArrayList(r13)
            java.util.ArrayList r15 = r9.getStringArrayList(r12)
            java.util.ArrayList r16 = r9.getStringArrayList(r11)
            if (r5 != 0) goto L_0x010c
            java.lang.Object[] r5 = new java.lang.Object[r7]
            r5[r14] = r6
            java.lang.String r6 = "Bundle returned from %s contains null SKUs list."
            java.lang.String r6 = java.lang.String.format(r6, r5)
            goto L_0x0133
        L_0x010c:
            if (r15 != 0) goto L_0x0119
            java.lang.Object[] r5 = new java.lang.Object[r7]
            r5[r14] = r6
            java.lang.String r6 = "Bundle returned from %s contains null purchases list."
            java.lang.String r6 = java.lang.String.format(r6, r5)
            goto L_0x0133
        L_0x0119:
            if (r16 != 0) goto L_0x0126
            java.lang.Object[] r5 = new java.lang.Object[r7]
            r5[r14] = r6
            java.lang.String r6 = "Bundle returned from %s contains null signatures list."
            java.lang.String r6 = java.lang.String.format(r6, r5)
            goto L_0x0133
        L_0x0126:
            mj r10 = p000.C2151vj.f16142i
            goto L_0x0136
        L_0x0129:
            java.lang.Object[] r5 = new java.lang.Object[r7]
            r5[r14] = r6
            java.lang.String r6 = "Bundle returned from %s doesn't contain required fields."
            java.lang.String r6 = java.lang.String.format(r6, r5)
        L_0x0133:
            p000.k23.m7993b((java.lang.String) r4, (java.lang.String) r6)
        L_0x0136:
            mj r5 = p000.C2151vj.f16142i
            if (r10 == r5) goto L_0x0142
            nj$a r0 = new nj$a
            r2 = 0
            r0.<init>(r10, r2)
            goto L_0x0224
        L_0x0142:
            java.util.ArrayList r5 = r9.getStringArrayList(r13)
            java.util.ArrayList r6 = r9.getStringArrayList(r12)
            java.util.ArrayList r10 = r9.getStringArrayList(r11)
        L_0x014e:
            int r11 = r6.size()
            if (r14 >= r11) goto L_0x01cb
            java.lang.Object r11 = r6.get(r14)
            java.lang.String r11 = (java.lang.String) r11
            java.lang.Object r12 = r10.get(r14)
            java.lang.String r12 = (java.lang.String) r12
            java.lang.Object r13 = r5.get(r14)
            java.lang.String r13 = (java.lang.String) r13
            java.lang.String r13 = java.lang.String.valueOf(r13)
            java.lang.String r15 = "Sku is owned: "
            int r16 = r13.length()
            if (r16 == 0) goto L_0x0177
            java.lang.String r13 = r15.concat(r13)
            goto L_0x017c
        L_0x0177:
            java.lang.String r13 = new java.lang.String
            r13.<init>(r15)
        L_0x017c:
            p000.k23.m7991a((java.lang.String) r4, (java.lang.String) r13)
            nj r13 = new nj     // Catch:{ JSONException -> 0x01a3 }
            r13.<init>(r11, r12)     // Catch:{ JSONException -> 0x01a3 }
            org.json.JSONObject r11 = r13.f11178c
            java.lang.String r12 = "purchaseToken"
            java.lang.String r12 = r11.optString(r12)
            java.lang.String r15 = "token"
            java.lang.String r11 = r11.optString(r15, r12)
            boolean r11 = android.text.TextUtils.isEmpty(r11)
            if (r11 == 0) goto L_0x019d
            java.lang.String r11 = "BUG: empty/null token!"
            p000.k23.m7993b((java.lang.String) r4, (java.lang.String) r11)
        L_0x019d:
            r3.add(r13)
            int r14 = r14 + 1
            goto L_0x014e
        L_0x01a3:
            r0 = move-exception
            java.lang.String r0 = java.lang.String.valueOf(r0)
            int r2 = r0.length()
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            int r2 = r2 + 48
            r3.<init>(r2)
            java.lang.String r2 = "Got an exception trying to decode the purchase: "
            r3.append(r2)
            r3.append(r0)
            java.lang.String r0 = r3.toString()
            p000.k23.m7993b((java.lang.String) r4, (java.lang.String) r0)
            nj$a r0 = new nj$a
            mj r2 = p000.C2151vj.f16141h
            r3 = 0
            r0.<init>(r2, r3)
            goto L_0x0224
        L_0x01cb:
            java.lang.String r5 = "INAPP_CONTINUATION_TOKEN"
            java.lang.String r6 = r9.getString(r5)
            java.lang.String r5 = java.lang.String.valueOf(r6)
            java.lang.String r9 = "Continuation token: "
            int r10 = r5.length()
            if (r10 == 0) goto L_0x01e2
            java.lang.String r5 = r9.concat(r5)
            goto L_0x01e7
        L_0x01e2:
            java.lang.String r5 = new java.lang.String
            r5.<init>(r9)
        L_0x01e7:
            p000.k23.m7991a((java.lang.String) r4, (java.lang.String) r5)
            boolean r5 = android.text.TextUtils.isEmpty(r6)
            if (r5 == 0) goto L_0x0041
            nj$a r0 = new nj$a
            mj r2 = p000.C2151vj.f16142i
            r0.<init>(r2, r3)
            goto L_0x0224
        L_0x01f8:
            r0 = move-exception
            java.lang.String r0 = java.lang.String.valueOf(r0)
            int r2 = r0.length()
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            int r2 = r2 + 57
            r3.<init>(r2)
            java.lang.String r2 = "Got exception trying to get purchases: "
            r3.append(r2)
            r3.append(r0)
            java.lang.String r0 = "; try to reconnect"
            r3.append(r0)
            java.lang.String r0 = r3.toString()
            p000.k23.m7993b((java.lang.String) r4, (java.lang.String) r0)
            nj$a r0 = new nj$a
            mj r2 = p000.C2151vj.f16143j
            r3 = 0
            r0.<init>(r2, r3)
        L_0x0224:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0705fk.call():java.lang.Object");
    }
}
