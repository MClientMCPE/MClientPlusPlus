package p000;

import androidx.recyclerview.widget.RecyclerView;

/* renamed from: ed */
public class C0599ed {

    /* renamed from: a */
    public final C0754g5<RecyclerView.C0218d0, C0600a> f4405a = new C0754g5<>();

    /* renamed from: b */
    public final C0516d5<RecyclerView.C0218d0> f4406b = new C0516d5<>();

    /* renamed from: ed$a */
    public static class C0600a {

        /* renamed from: d */
        public static C0590e7<C0600a> f4407d = new C0590e7<>(20);

        /* renamed from: a */
        public int f4408a;

        /* renamed from: b */
        public RecyclerView.C0226l.C0229c f4409b;

        /* renamed from: c */
        public RecyclerView.C0226l.C0229c f4410c;

        /* renamed from: a */
        public static C0600a m4027a() {
            C0600a a = f4407d.mo5048a();
            return a == null ? new C0600a() : a;
        }

        /* renamed from: a */
        public static void m4028a(C0600a aVar) {
            aVar.f4408a = 0;
            aVar.f4409b = null;
            aVar.f4410c = null;
            f4407d.mo5049a(aVar);
        }
    }

    /* renamed from: ed$b */
    public interface C0601b {
    }

    /* renamed from: a */
    public final RecyclerView.C0226l.C0229c mo5091a(RecyclerView.C0218d0 d0Var, int i) {
        C0600a e;
        RecyclerView.C0226l.C0229c cVar;
        int a = this.f4405a.mo5971a((Object) d0Var);
        if (a >= 0 && (e = this.f4405a.mo5982e(a)) != null) {
            int i2 = e.f4408a;
            if ((i2 & i) != 0) {
                e.f4408a = (i ^ -1) & i2;
                if (i == 4) {
                    cVar = e.f4409b;
                } else if (i == 8) {
                    cVar = e.f4410c;
                } else {
                    throw new IllegalArgumentException("Must provide flag PRE or POST");
                }
                if ((e.f4408a & 12) == 0) {
                    this.f4405a.mo5981d(a);
                    C0600a.m4028a(e);
                }
                return cVar;
            }
        }
        return null;
    }

    /* renamed from: a */
    public void mo5093a(RecyclerView.C0218d0 d0Var) {
        C0600a orDefault = this.f4405a.getOrDefault(d0Var, null);
        if (orDefault == null) {
            orDefault = C0600a.m4027a();
            this.f4405a.put(d0Var, orDefault);
        }
        orDefault.f4408a |= 1;
    }

    /* renamed from: b */
    public void mo5095b(RecyclerView.C0218d0 d0Var, RecyclerView.C0226l.C0229c cVar) {
        C0600a orDefault = this.f4405a.getOrDefault(d0Var, null);
        if (orDefault == null) {
            orDefault = C0600a.m4027a();
            this.f4405a.put(d0Var, orDefault);
        }
        orDefault.f4409b = cVar;
        orDefault.f4408a |= 4;
    }

    /* renamed from: c */
    public void mo5097c(RecyclerView.C0218d0 d0Var) {
        C0600a orDefault = this.f4405a.getOrDefault(d0Var, null);
        if (orDefault != null) {
            orDefault.f4408a &= -2;
        }
    }

    /* renamed from: d */
    public void mo5098d(RecyclerView.C0218d0 d0Var) {
        int c = this.f4406b.mo4667c() - 1;
        while (true) {
            if (c < 0) {
                break;
            } else if (d0Var == this.f4406b.mo4664b(c)) {
                C0516d5<RecyclerView.C0218d0> d5Var = this.f4406b;
                Object[] objArr = d5Var.f3727Z;
                Object obj = objArr[c];
                Object obj2 = C0516d5.f3724b0;
                if (obj != obj2) {
                    objArr[c] = obj2;
                    d5Var.f3725X = true;
                }
            } else {
                c--;
            }
        }
        C0600a remove = this.f4405a.remove(d0Var);
        if (remove != null) {
            C0600a.m4028a(remove);
        }
    }

    /* renamed from: a */
    public void mo5094a(RecyclerView.C0218d0 d0Var, RecyclerView.C0226l.C0229c cVar) {
        C0600a orDefault = this.f4405a.getOrDefault(d0Var, null);
        if (orDefault == null) {
            orDefault = C0600a.m4027a();
            this.f4405a.put(d0Var, orDefault);
        }
        orDefault.f4410c = cVar;
        orDefault.f4408a |= 8;
    }

    /* renamed from: b */
    public boolean mo5096b(RecyclerView.C0218d0 d0Var) {
        C0600a orDefault = this.f4405a.getOrDefault(d0Var, null);
        return (orDefault == null || (orDefault.f4408a & 1) == 0) ? false : true;
    }

    /* renamed from: a */
    public void mo5092a() {
        do {
        } while (C0600a.f4407d.mo5048a() != null);
    }
}
