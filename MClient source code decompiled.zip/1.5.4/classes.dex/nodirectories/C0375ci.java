package p000;

/* renamed from: ci */
public class C0375ci implements C1617pg {

    /* renamed from: a */
    public final /* synthetic */ C0868hi f2740a;

    public C0375ci(C0868hi hiVar) {
        this.f2740a = hiVar;
    }

    /* renamed from: a */
    public void mo532a(C1249lg lgVar) {
        if (this.f2740a.mo6550c(lgVar)) {
            this.f2740a.mo6554g(lgVar);
        }
    }
}
