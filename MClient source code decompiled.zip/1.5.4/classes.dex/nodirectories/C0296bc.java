package p000;

/* renamed from: bc */
public interface C0296bc {
    /* renamed from: d */
    C0091ac mo638d();
}
