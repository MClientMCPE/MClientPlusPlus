package p000;

import android.os.IInterface;

/* renamed from: fw */
public interface C0725fw extends IInterface {
    /* renamed from: d1 */
    C2232wr mo5804d1();

    /* renamed from: y */
    boolean mo5805y(C2232wr wrVar);

    /* renamed from: y0 */
    String mo5806y0();
}
