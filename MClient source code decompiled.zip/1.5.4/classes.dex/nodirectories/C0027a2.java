package p000;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.widget.ActionMenuView;
import java.util.ArrayList;
import p000.C0816h1;
import p000.C0831h7;
import p000.C1581p1;
import p000.C1655q1;

/* renamed from: a2 */
public class C0027a2 extends C0333c1 implements C0831h7.C0832a {

    /* renamed from: f0 */
    public C0031d f109f0;

    /* renamed from: g0 */
    public Drawable f110g0;

    /* renamed from: h0 */
    public boolean f111h0;

    /* renamed from: i0 */
    public boolean f112i0;

    /* renamed from: j0 */
    public boolean f113j0;

    /* renamed from: k0 */
    public int f114k0;

    /* renamed from: l0 */
    public int f115l0;

    /* renamed from: m0 */
    public int f116m0;

    /* renamed from: n0 */
    public boolean f117n0;

    /* renamed from: o0 */
    public boolean f118o0;

    /* renamed from: p0 */
    public boolean f119p0;

    /* renamed from: q0 */
    public boolean f120q0;

    /* renamed from: r0 */
    public int f121r0;

    /* renamed from: s0 */
    public final SparseBooleanArray f122s0 = new SparseBooleanArray();

    /* renamed from: t0 */
    public C0033e f123t0;

    /* renamed from: u0 */
    public C0028a f124u0;

    /* renamed from: v0 */
    public C0030c f125v0;

    /* renamed from: w0 */
    public C0029b f126w0;

    /* renamed from: x0 */
    public final C0034f f127x0 = new C0034f();

    /* renamed from: y0 */
    public int f128y0;

    /* renamed from: a2$a */
    public class C0028a extends C1385n1 {
        public C0028a(Context context, C2081v1 v1Var, View view) {
            super(context, v1Var, view, false, C0502d.actionOverflowMenuStyle, 0);
            if (!v1Var.f15798C.mo7792d()) {
                View view2 = C0027a2.this.f109f0;
                this.f10830f = view2 == null ? (View) C0027a2.this.f2419e0 : view2;
            }
            mo8983a((C1581p1.C1582a) C0027a2.this.f127x0);
        }

        /* renamed from: c */
        public void mo140c() {
            C0027a2 a2Var = C0027a2.this;
            a2Var.f124u0 = null;
            a2Var.f128y0 = 0;
            super.mo140c();
        }
    }

    /* renamed from: a2$b */
    public class C0029b extends ActionMenuItemView.C0131b {
        public C0029b() {
        }
    }

    /* renamed from: a2$c */
    public class C0030c implements Runnable {

        /* renamed from: X */
        public C0033e f131X;

        public C0030c(C0033e eVar) {
            this.f131X = eVar;
        }

        public void run() {
            C0816h1.C0817a aVar;
            C0816h1 h1Var = C0027a2.this.f2414Z;
            if (!(h1Var == null || (aVar = h1Var.f6498e) == null)) {
                aVar.mo19a(h1Var);
            }
            View view = (View) C0027a2.this.f2419e0;
            if (!(view == null || view.getWindowToken() == null || !this.f131X.mo8987d())) {
                C0027a2.this.f123t0 = this.f131X;
            }
            C0027a2.this.f125v0 = null;
        }
    }

    /* renamed from: a2$d */
    public class C0031d extends C1216l2 implements ActionMenuView.C0138a {

        /* renamed from: a2$d$a */
        public class C0032a extends C0577e3 {
            public C0032a(View view, C0027a2 a2Var) {
                super(view);
            }

            /* renamed from: j */
            public C1788s1 mo146j() {
                C0033e eVar = C0027a2.this.f123t0;
                if (eVar == null) {
                    return null;
                }
                return eVar.mo8981a();
            }

            /* renamed from: k */
            public boolean mo147k() {
                C0027a2.this.mo139f();
                return true;
            }

            /* renamed from: l */
            public boolean mo148l() {
                C0027a2 a2Var = C0027a2.this;
                if (a2Var.f125v0 != null) {
                    return false;
                }
                a2Var.mo136c();
                return true;
            }
        }

        public C0031d(Context context) {
            super(context, (AttributeSet) null, C0502d.actionOverflowButtonStyle);
            setClickable(true);
            setFocusable(true);
            setVisibility(0);
            setEnabled(true);
            C0815h0.m5806a((View) this, getContentDescription());
            setOnTouchListener(new C0032a(this, C0027a2.this));
        }

        /* renamed from: j */
        public boolean mo142j() {
            return false;
        }

        /* renamed from: k */
        public boolean mo143k() {
            return false;
        }

        public boolean performClick() {
            if (super.performClick()) {
                return true;
            }
            playSoundEffect(0);
            C0027a2.this.mo139f();
            return true;
        }

        public boolean setFrame(int i, int i2, int i3, int i4) {
            boolean frame = super.setFrame(i, i2, i3, i4);
            Drawable drawable = getDrawable();
            Drawable background = getBackground();
            if (!(drawable == null || background == null)) {
                int width = getWidth();
                int height = getHeight();
                int max = Math.max(width, height) / 2;
                int paddingLeft = (width + (getPaddingLeft() - getPaddingRight())) / 2;
                int paddingTop = (height + (getPaddingTop() - getPaddingBottom())) / 2;
                C0815h0.m5801a(background, paddingLeft - max, paddingTop - max, paddingLeft + max, paddingTop + max);
            }
            return frame;
        }
    }

    /* renamed from: a2$e */
    public class C0033e extends C1385n1 {
        public C0033e(Context context, C0816h1 h1Var, View view, boolean z) {
            super(context, h1Var, view, z, C0502d.actionOverflowMenuStyle, 0);
            this.f10831g = 8388613;
            mo8983a((C1581p1.C1582a) C0027a2.this.f127x0);
        }

        /* renamed from: c */
        public void mo140c() {
            C0816h1 h1Var = C0027a2.this.f2414Z;
            if (h1Var != null) {
                h1Var.mo6288a(true);
            }
            C0027a2.this.f123t0 = null;
            super.mo140c();
        }
    }

    public C0027a2(Context context) {
        super(context, C0978j.abc_action_menu_layout, C0978j.abc_action_menu_item_layout);
    }

    /* renamed from: a */
    public void mo130a(C0816h1 h1Var, boolean z) {
        mo135b();
        super.mo130a(h1Var, z);
    }

    /* JADX WARNING: Removed duplicated region for block: B:79:0x00fb  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo132a() {
        /*
            r19 = this;
            r0 = r19
            h1 r1 = r0.f2414Z
            r2 = 0
            r3 = 0
            if (r1 == 0) goto L_0x0011
            java.util.ArrayList r1 = r1.mo6310d()
            int r4 = r1.size()
            goto L_0x0013
        L_0x0011:
            r1 = r2
            r4 = 0
        L_0x0013:
            int r5 = r0.f116m0
            int r6 = r0.f115l0
            int r7 = android.view.View.MeasureSpec.makeMeasureSpec(r3, r3)
            q1 r8 = r0.f2419e0
            android.view.ViewGroup r8 = (android.view.ViewGroup) r8
            r12 = r5
            r5 = 0
            r9 = 0
            r10 = 0
            r11 = 0
        L_0x0024:
            r13 = 2
            r14 = 1
            if (r5 >= r4) goto L_0x0056
            java.lang.Object r15 = r1.get(r5)
            k1 r15 = (p000.C1115k1) r15
            int r3 = r15.f8808z
            r3 = r3 & r13
            if (r3 != r13) goto L_0x0035
            r3 = 1
            goto L_0x0036
        L_0x0035:
            r3 = 0
        L_0x0036:
            if (r3 == 0) goto L_0x003b
            int r10 = r10 + 1
            goto L_0x0049
        L_0x003b:
            int r3 = r15.f8808z
            r3 = r3 & r14
            if (r3 != r14) goto L_0x0042
            r3 = 1
            goto L_0x0043
        L_0x0042:
            r3 = 0
        L_0x0043:
            if (r3 == 0) goto L_0x0048
            int r11 = r11 + 1
            goto L_0x0049
        L_0x0048:
            r9 = 1
        L_0x0049:
            boolean r3 = r0.f120q0
            if (r3 == 0) goto L_0x0052
            boolean r3 = r15.f8781D
            if (r3 == 0) goto L_0x0052
            r12 = 0
        L_0x0052:
            int r5 = r5 + 1
            r3 = 0
            goto L_0x0024
        L_0x0056:
            boolean r3 = r0.f112i0
            if (r3 == 0) goto L_0x0061
            if (r9 != 0) goto L_0x005f
            int r11 = r11 + r10
            if (r11 <= r12) goto L_0x0061
        L_0x005f:
            int r12 = r12 + -1
        L_0x0061:
            int r12 = r12 - r10
            android.util.SparseBooleanArray r3 = r0.f122s0
            r3.clear()
            boolean r5 = r0.f118o0
            if (r5 == 0) goto L_0x0074
            int r5 = r0.f121r0
            int r9 = r6 / r5
            int r10 = r6 % r5
            int r10 = r10 / r9
            int r5 = r5 + r10
            goto L_0x0076
        L_0x0074:
            r5 = 0
            r9 = 0
        L_0x0076:
            r10 = r6
            r6 = 0
            r11 = 0
        L_0x0079:
            if (r6 >= r4) goto L_0x0152
            java.lang.Object r15 = r1.get(r6)
            k1 r15 = (p000.C1115k1) r15
            int r14 = r15.f8808z
            r14 = r14 & r13
            if (r14 != r13) goto L_0x0088
            r14 = 1
            goto L_0x0089
        L_0x0088:
            r14 = 0
        L_0x0089:
            if (r14 == 0) goto L_0x00b5
            android.view.View r14 = r0.mo128a(r15, r2, r8)
            boolean r13 = r0.f118o0
            if (r13 == 0) goto L_0x009b
            r13 = 0
            int r16 = androidx.appcompat.widget.ActionMenuView.m702b(r14, r5, r9, r7, r13)
            int r9 = r9 - r16
            goto L_0x009e
        L_0x009b:
            r14.measure(r7, r7)
        L_0x009e:
            int r13 = r14.getMeasuredWidth()
            int r10 = r10 - r13
            if (r11 != 0) goto L_0x00a6
            r11 = r13
        L_0x00a6:
            int r13 = r15.f8784b
            r14 = 1
            if (r13 == 0) goto L_0x00ae
            r3.put(r13, r14)
        L_0x00ae:
            r15.mo7789b(r14)
            r16 = r4
            goto L_0x013f
        L_0x00b5:
            r14 = 1
            int r13 = r15.f8808z
            r13 = r13 & r14
            if (r13 != r14) goto L_0x00bd
            r13 = 1
            goto L_0x00be
        L_0x00bd:
            r13 = 0
        L_0x00be:
            if (r13 == 0) goto L_0x0141
            int r13 = r15.f8784b
            boolean r14 = r3.get(r13)
            if (r12 > 0) goto L_0x00ca
            if (r14 == 0) goto L_0x00d4
        L_0x00ca:
            if (r10 <= 0) goto L_0x00d4
            boolean r2 = r0.f118o0
            if (r2 == 0) goto L_0x00d2
            if (r9 <= 0) goto L_0x00d4
        L_0x00d2:
            r2 = 1
            goto L_0x00d5
        L_0x00d4:
            r2 = 0
        L_0x00d5:
            r17 = r2
            r16 = r4
            if (r2 == 0) goto L_0x010b
            r2 = 0
            android.view.View r4 = r0.mo128a(r15, r2, r8)
            boolean r2 = r0.f118o0
            if (r2 == 0) goto L_0x00ef
            r2 = 0
            int r18 = androidx.appcompat.widget.ActionMenuView.m702b(r4, r5, r9, r7, r2)
            int r9 = r9 - r18
            if (r18 != 0) goto L_0x00f2
            r2 = 0
            goto L_0x00f4
        L_0x00ef:
            r4.measure(r7, r7)
        L_0x00f2:
            r2 = r17
        L_0x00f4:
            int r4 = r4.getMeasuredWidth()
            int r10 = r10 - r4
            if (r11 != 0) goto L_0x00fc
            r11 = r4
        L_0x00fc:
            boolean r4 = r0.f118o0
            if (r4 == 0) goto L_0x0103
            if (r10 < 0) goto L_0x0109
            goto L_0x0107
        L_0x0103:
            int r4 = r10 + r11
            if (r4 <= 0) goto L_0x0109
        L_0x0107:
            r4 = 1
            goto L_0x010a
        L_0x0109:
            r4 = 0
        L_0x010a:
            r2 = r2 & r4
        L_0x010b:
            if (r2 == 0) goto L_0x0114
            if (r13 == 0) goto L_0x0114
            r4 = 1
            r3.put(r13, r4)
            goto L_0x0138
        L_0x0114:
            if (r14 == 0) goto L_0x0138
            r4 = 0
            r3.put(r13, r4)
            r4 = 0
        L_0x011b:
            if (r4 >= r6) goto L_0x0138
            java.lang.Object r14 = r1.get(r4)
            k1 r14 = (p000.C1115k1) r14
            int r0 = r14.f8784b
            if (r0 != r13) goto L_0x0133
            boolean r0 = r14.mo7792d()
            if (r0 == 0) goto L_0x012f
            int r12 = r12 + 1
        L_0x012f:
            r0 = 0
            r14.mo7789b(r0)
        L_0x0133:
            int r4 = r4 + 1
            r0 = r19
            goto L_0x011b
        L_0x0138:
            if (r2 == 0) goto L_0x013c
            int r12 = r12 + -1
        L_0x013c:
            r15.mo7789b(r2)
        L_0x013f:
            r0 = 0
            goto L_0x0147
        L_0x0141:
            r16 = r4
            r0 = 0
            r15.mo7789b(r0)
        L_0x0147:
            int r6 = r6 + 1
            r2 = 0
            r13 = 2
            r14 = 1
            r0 = r19
            r4 = r16
            goto L_0x0079
        L_0x0152:
            r2 = 1
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0027a2.mo132a():boolean");
    }

    /* renamed from: a */
    public boolean mo133a(ViewGroup viewGroup, int i) {
        if (viewGroup.getChildAt(i) == this.f109f0) {
            return false;
        }
        super.mo133a(viewGroup, i);
        return true;
    }

    /* renamed from: b */
    public boolean mo135b() {
        return mo136c() | mo137d();
    }

    /* renamed from: c */
    public boolean mo136c() {
        C1655q1 q1Var;
        C0030c cVar = this.f125v0;
        if (cVar == null || (q1Var = this.f2419e0) == null) {
            C0033e eVar = this.f123t0;
            if (eVar == null) {
                return false;
            }
            if (eVar.mo8986b()) {
                eVar.f10834j.dismiss();
            }
            return true;
        }
        ((View) q1Var).removeCallbacks(cVar);
        this.f125v0 = null;
        return true;
    }

    /* renamed from: d */
    public boolean mo137d() {
        C0028a aVar = this.f124u0;
        if (aVar == null) {
            return false;
        }
        if (!aVar.mo8986b()) {
            return true;
        }
        aVar.f10834j.dismiss();
        return true;
    }

    /* renamed from: e */
    public boolean mo138e() {
        C0033e eVar = this.f123t0;
        return eVar != null && eVar.mo8986b();
    }

    /* renamed from: f */
    public boolean mo139f() {
        C0816h1 h1Var;
        if (!this.f112i0 || mo138e() || (h1Var = this.f2414Z) == null || this.f2419e0 == null || this.f125v0 != null) {
            return false;
        }
        h1Var.mo6279a();
        if (h1Var.f6503j.isEmpty()) {
            return false;
        }
        this.f125v0 = new C0030c(new C0033e(this.f2413Y, this.f2414Z, this.f109f0, true));
        ((View) this.f2419e0).post(this.f125v0);
        super.mo134a((C2081v1) null);
        return true;
    }

    /* renamed from: a2$f */
    public class C0034f implements C1581p1.C1582a {
        public C0034f() {
        }

        /* renamed from: a */
        public void mo55a(C0816h1 h1Var, boolean z) {
            if (h1Var instanceof C2081v1) {
                h1Var.mo6306c().mo6288a(false);
            }
            C1581p1.C1582a aVar = C0027a2.this.f2416b0;
            if (aVar != null) {
                aVar.mo55a(h1Var, z);
            }
        }

        /* renamed from: a */
        public boolean mo56a(C0816h1 h1Var) {
            if (h1Var == null) {
                return false;
            }
            C0027a2.this.f128y0 = ((C2081v1) h1Var).f15798C.getItemId();
            C1581p1.C1582a aVar = C0027a2.this.f2416b0;
            if (aVar != null) {
                return aVar.mo56a(h1Var);
            }
            return false;
        }
    }

    /* renamed from: a */
    public View mo128a(C1115k1 k1Var, View view, ViewGroup viewGroup) {
        View actionView = k1Var.getActionView();
        if (actionView == null || k1Var.mo7790c()) {
            actionView = super.mo128a(k1Var, view, viewGroup);
        }
        actionView.setVisibility(k1Var.f8781D ? 8 : 0);
        ActionMenuView actionMenuView = (ActionMenuView) viewGroup;
        ViewGroup.LayoutParams layoutParams = actionView.getLayoutParams();
        if (!actionMenuView.checkLayoutParams(layoutParams)) {
            actionView.setLayoutParams(actionMenuView.generateLayoutParams(layoutParams));
        }
        return actionView;
    }

    /* renamed from: a */
    public void mo129a(Context context, C0816h1 h1Var) {
        super.mo129a(context, h1Var);
        Resources resources = context.getResources();
        if (!this.f113j0) {
            int i = Build.VERSION.SDK_INT;
            this.f112i0 = true;
        }
        int i2 = 2;
        if (!this.f119p0) {
            this.f114k0 = context.getResources().getDisplayMetrics().widthPixels / 2;
        }
        if (!this.f117n0) {
            Configuration configuration = context.getResources().getConfiguration();
            int i3 = configuration.screenWidthDp;
            int i4 = configuration.screenHeightDp;
            if (configuration.smallestScreenWidthDp > 600 || i3 > 600 || ((i3 > 960 && i4 > 720) || (i3 > 720 && i4 > 960))) {
                i2 = 5;
            } else if (i3 >= 500 || ((i3 > 640 && i4 > 480) || (i3 > 480 && i4 > 640))) {
                i2 = 4;
            } else if (i3 >= 360) {
                i2 = 3;
            }
            this.f116m0 = i2;
        }
        int i5 = this.f114k0;
        if (this.f112i0) {
            if (this.f109f0 == null) {
                this.f109f0 = new C0031d(this.f2412X);
                if (this.f111h0) {
                    this.f109f0.setImageDrawable(this.f110g0);
                    this.f110g0 = null;
                    this.f111h0 = false;
                }
                int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                this.f109f0.measure(makeMeasureSpec, makeMeasureSpec);
            }
            i5 -= this.f109f0.getMeasuredWidth();
        } else {
            this.f109f0 = null;
        }
        this.f115l0 = i5;
        this.f121r0 = (int) (resources.getDisplayMetrics().density * 56.0f);
    }

    /* renamed from: a */
    public boolean mo134a(C2081v1 v1Var) {
        boolean z = false;
        if (!v1Var.hasVisibleItems()) {
            return false;
        }
        C2081v1 v1Var2 = v1Var;
        while (true) {
            C0816h1 h1Var = v1Var2.f15797B;
            if (h1Var == this.f2414Z) {
                break;
            }
            v1Var2 = h1Var;
        }
        C1115k1 k1Var = v1Var2.f15798C;
        ViewGroup viewGroup = (ViewGroup) this.f2419e0;
        View view = null;
        if (viewGroup != null) {
            int childCount = viewGroup.getChildCount();
            int i = 0;
            while (true) {
                if (i >= childCount) {
                    break;
                }
                View childAt = viewGroup.getChildAt(i);
                if ((childAt instanceof C1655q1.C1656a) && ((C1655q1.C1656a) childAt).getItemData() == k1Var) {
                    view = childAt;
                    break;
                }
                i++;
            }
        }
        if (view == null) {
            return false;
        }
        v1Var.f15798C.getItemId();
        int size = v1Var.size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                break;
            }
            MenuItem item = v1Var.getItem(i2);
            if (item.isVisible() && item.getIcon() != null) {
                z = true;
                break;
            }
            i2++;
        }
        this.f124u0 = new C0028a(this.f2413Y, v1Var, view);
        this.f124u0.mo8984a(z);
        if (this.f124u0.mo8987d()) {
            C1581p1.C1582a aVar = this.f2416b0;
            if (aVar != null) {
                aVar.mo56a(v1Var);
            }
            return true;
        }
        throw new IllegalStateException("MenuPopupHelper cannot be used without an anchor");
    }

    /* renamed from: a */
    public void mo131a(boolean z) {
        ArrayList<C1115k1> arrayList;
        C1655q1 q1Var;
        super.mo131a(z);
        ((View) this.f2419e0).requestLayout();
        C0816h1 h1Var = this.f2414Z;
        boolean z2 = false;
        if (h1Var != null) {
            h1Var.mo6279a();
            ArrayList<C1115k1> arrayList2 = h1Var.f6502i;
            int size = arrayList2.size();
            for (int i = 0; i < size; i++) {
                C0831h7 h7Var = arrayList2.get(i).f8779B;
            }
        }
        C0816h1 h1Var2 = this.f2414Z;
        if (h1Var2 != null) {
            h1Var2.mo6279a();
            arrayList = h1Var2.f6503j;
        } else {
            arrayList = null;
        }
        if (this.f112i0 && arrayList != null) {
            int size2 = arrayList.size();
            if (size2 == 1) {
                z2 = !arrayList.get(0).f8781D;
            } else if (size2 > 0) {
                z2 = true;
            }
        }
        C0031d dVar = this.f109f0;
        if (z2) {
            if (dVar == null) {
                this.f109f0 = new C0031d(this.f2412X);
            }
            ViewGroup viewGroup = (ViewGroup) this.f109f0.getParent();
            if (viewGroup != this.f2419e0) {
                if (viewGroup != null) {
                    viewGroup.removeView(this.f109f0);
                }
                ActionMenuView actionMenuView = (ActionMenuView) this.f2419e0;
                actionMenuView.addView(this.f109f0, actionMenuView.mo870h());
            }
        } else if (dVar != null && dVar.getParent() == (q1Var = this.f2419e0)) {
            ((ViewGroup) q1Var).removeView(this.f109f0);
        }
        ((ActionMenuView) this.f2419e0).setOverflowReserved(this.f112i0);
    }
}
