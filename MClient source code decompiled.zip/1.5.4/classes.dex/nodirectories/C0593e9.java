package p000;

/* renamed from: e9 */
public interface C0593e9 {
}
