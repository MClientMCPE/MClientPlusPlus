package p000;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.Keyframe;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import android.os.StrictMode;
import android.os.Trace;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Base64;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import android.view.InflateException;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.AnticipateInterpolator;
import android.view.animation.AnticipateOvershootInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.CycleInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import com.google.android.gms.dynamite.DynamiteModule;
import com.google.android.gms.dynamite.descriptors.com.google.android.gms.ads.dynamite.ModuleDescriptor;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.security.GeneralSecurityException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.spec.ECField;
import java.security.spec.ECFieldFp;
import java.security.spec.ECParameterSpec;
import java.security.spec.ECPoint;
import java.security.spec.EllipticCurve;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import p000.h82;
import p000.j22;
import p000.p82;
import p000.u43;

/* renamed from: fe */
public class C0680fe {
    @SuppressLint({"StaticFieldLeak"})

    /* renamed from: a */
    public static Context f5238a;

    /* renamed from: b */
    public static C2120vg f5239b;

    /* renamed from: c */
    public static boolean f5240c;

    /* renamed from: d */
    public static boolean f5241d;

    /* renamed from: e */
    public static Boolean f5242e;

    /* renamed from: f */
    public static Boolean f5243f;

    /* renamed from: g */
    public static Boolean f5244g;

    /* renamed from: h */
    public static Boolean f5245h;

    /* renamed from: i */
    public static Context f5246i;

    /* renamed from: j */
    public static Boolean f5247j;

    /* renamed from: k */
    public static String f5248k;

    /* renamed from: l */
    public static volatile gv2[] f5249l;

    /* renamed from: a */
    public static int m4652a(int i, int i2) {
        if (i >= 0 && i < i2) {
            return i;
        }
        throw new IndexOutOfBoundsException();
    }

    /* renamed from: a */
    public static int m4654a(int i, String str) {
        if (i >= 0) {
            return i;
        }
        StringBuilder sb = new StringBuilder(C0789gk.m5548a(str, 40));
        sb.append(str);
        sb.append(" cannot be negative but was: ");
        sb.append(i);
        throw new IllegalArgumentException(sb.toString());
    }

    /* renamed from: a */
    public static int m4655a(int i, byte[] bArr, int i2, int i3, db2 db2) {
        if ((i >>> 3) != 0) {
            int i4 = i & 7;
            if (i4 == 0) {
                return m4798b(bArr, i2, db2);
            }
            if (i4 == 1) {
                return i2 + 8;
            }
            if (i4 == 2) {
                return m4668a(bArr, i2, db2) + db2.f3782a;
            }
            if (i4 == 3) {
                int i5 = (i & -8) | 4;
                int i6 = 0;
                while (i2 < i3) {
                    i2 = m4668a(bArr, i2, db2);
                    i6 = db2.f3782a;
                    if (i6 == i5) {
                        break;
                    }
                    i2 = m4655a(i6, bArr, i2, i3, db2);
                }
                if (i2 <= i3 && i6 == i5) {
                    return i2;
                }
                throw zc2.m17017g();
            } else if (i4 == 5) {
                return i2 + 4;
            } else {
                throw zc2.m17014d();
            }
        } else {
            throw zc2.m17014d();
        }
    }

    /* renamed from: a */
    public static int m4656a(int i, byte[] bArr, int i2, int i3, ff2 ff2, db2 db2) {
        if ((i >>> 3) != 0) {
            int i4 = i & 7;
            if (i4 == 0) {
                int b = m4798b(bArr, i2, db2);
                ff2.mo5638a(i, Long.valueOf(db2.f3783b));
                return b;
            } else if (i4 == 1) {
                ff2.mo5638a(i, Long.valueOf(m4823c(bArr, i2)));
                return i2 + 8;
            } else if (i4 == 2) {
                int a = m4668a(bArr, i2, db2);
                int i5 = db2.f3782a;
                if (i5 < 0) {
                    throw zc2.m17012b();
                } else if (i5 <= bArr.length - a) {
                    ff2.mo5638a(i, i5 == 0 ? hb2.f6691Y : hb2.m6130a(bArr, a, i5));
                    return a + i5;
                } else {
                    throw zc2.m17011a();
                }
            } else if (i4 == 3) {
                ff2 b2 = ff2.m4951b();
                int i6 = (i & -8) | 4;
                int i7 = 0;
                while (true) {
                    if (i2 >= i3) {
                        break;
                    }
                    int a2 = m4668a(bArr, i2, db2);
                    int i8 = db2.f3782a;
                    i7 = i8;
                    if (i8 == i6) {
                        i2 = a2;
                        break;
                    }
                    int a3 = m4656a(i7, bArr, a2, i3, b2, db2);
                    i7 = i8;
                    i2 = a3;
                }
                if (i2 > i3 || i7 != i6) {
                    throw zc2.m17017g();
                }
                ff2.mo5638a(i, b2);
                return i2;
            } else if (i4 == 5) {
                ff2.mo5638a(i, Integer.valueOf(m4797b(bArr, i2)));
                return i2 + 4;
            } else {
                throw zc2.m17014d();
            }
        } else {
            throw zc2.m17014d();
        }
    }

    /* renamed from: a */
    public static int m4657a(int i, byte[] bArr, int i2, int i3, wc2<?> wc2, db2 db2) {
        rc2 rc2 = (rc2) wc2;
        int a = m4668a(bArr, i2, db2);
        while (true) {
            rc2.mo10612g(db2.f3782a);
            if (a >= i3) {
                break;
            }
            int a2 = m4668a(bArr, a, db2);
            if (i != db2.f3782a) {
                break;
            }
            a = m4668a(bArr, a2, db2);
        }
        return a;
    }

    /* renamed from: a */
    public static int m4658a(int i, byte[] bArr, int i2, db2 db2) {
        int i3;
        int i4;
        int i5 = i & 127;
        int i6 = i2 + 1;
        byte b = bArr[i2];
        if (b >= 0) {
            i4 = b << 7;
        } else {
            int i7 = i5 | ((b & Byte.MAX_VALUE) << 7);
            int i8 = i6 + 1;
            byte b2 = bArr[i6];
            if (b2 >= 0) {
                i3 = b2 << 14;
            } else {
                i5 = i7 | ((b2 & Byte.MAX_VALUE) << 14);
                i6 = i8 + 1;
                byte b3 = bArr[i8];
                if (b3 >= 0) {
                    i4 = b3 << 21;
                } else {
                    i7 = i5 | ((b3 & Byte.MAX_VALUE) << 21);
                    i8 = i6 + 1;
                    byte b4 = bArr[i6];
                    if (b4 >= 0) {
                        i3 = b4 << 28;
                    } else {
                        int i9 = i7 | ((b4 & Byte.MAX_VALUE) << 28);
                        while (true) {
                            int i10 = i8 + 1;
                            if (bArr[i8] >= 0) {
                                db2.f3782a = i9;
                                return i10;
                            }
                            i8 = i10;
                        }
                    }
                }
            }
            db2.f3782a = i7 | i3;
            return i8;
        }
        db2.f3782a = i5 | i4;
        return i6;
    }

    /* renamed from: a */
    public static int m4659a(Context context, int i, int i2) {
        TypedValue b = t53.m13123b(context, i);
        return b != null ? b.data : i2;
    }

    /* renamed from: a */
    public static int m4660a(SQLiteDatabase sQLiteDatabase, int i) {
        int i2 = 0;
        if (i == 2) {
            return 0;
        }
        Cursor b = m4799b(sQLiteDatabase, i);
        if (b.getCount() > 0) {
            b.moveToNext();
            i2 = 0 + b.getInt(b.getColumnIndexOrThrow("value"));
        }
        b.close();
        return i2;
    }

    /* renamed from: a */
    public static int m4661a(Parcel parcel) {
        return m4889n(parcel, 20293);
    }

    /* renamed from: a */
    public static int m4663a(C0870hk hkVar) {
        int i = a50.f189b[hkVar.ordinal()];
        if (i == 2) {
            return 1;
        }
        if (i != 3) {
            return i != 4 ? 0 : 3;
        }
        return 2;
    }

    /* renamed from: a */
    public static int m4664a(Set<?> set) {
        Iterator<?> it = set.iterator();
        int i = 0;
        while (it.hasNext()) {
            Object next = it.next();
            i = ((i + (next != null ? next.hashCode() : 0)) ^ -1) ^ -1;
        }
        return i;
    }

    /* renamed from: a */
    public static int m4665a(se2<?> se2, int i, byte[] bArr, int i2, int i3, wc2<?> wc2, db2 db2) {
        int a = m4667a((se2) se2, bArr, i2, i3, db2);
        while (true) {
            wc2.add(db2.f3784c);
            if (a >= i3) {
                break;
            }
            int a2 = m4668a(bArr, a, db2);
            if (i != db2.f3782a) {
                break;
            }
            a = m4667a((se2) se2, bArr, a2, i3, db2);
        }
        return a;
    }

    /* renamed from: a */
    public static int m4666a(se2 se2, byte[] bArr, int i, int i2, int i3, db2 db2) {
        be2 be2 = (be2) se2;
        Object a = be2.mo2456a();
        int a2 = be2.mo2455a(a, bArr, i, i2, i3, db2);
        be2.mo2470b(a);
        db2.f3784c = a;
        return a2;
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v2, resolved type: byte} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v0, resolved type: byte} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v5, resolved type: byte} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r8v6, resolved type: byte} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static int m4667a(p000.se2 r6, byte[] r7, int r8, int r9, p000.db2 r10) {
        /*
            int r0 = r8 + 1
            byte r8 = r7[r8]
            if (r8 >= 0) goto L_0x000c
            int r0 = m4658a((int) r8, (byte[]) r7, (int) r0, (p000.db2) r10)
            int r8 = r10.f3782a
        L_0x000c:
            r3 = r0
            if (r8 < 0) goto L_0x0025
            int r9 = r9 - r3
            if (r8 > r9) goto L_0x0025
            java.lang.Object r9 = r6.mo2456a()
            int r8 = r8 + r3
            r0 = r6
            r1 = r9
            r2 = r7
            r4 = r8
            r5 = r10
            r0.mo2463a(r1, r2, r3, r4, r5)
            r6.mo2470b(r9)
            r10.f3784c = r9
            return r8
        L_0x0025:
            zc2 r6 = p000.zc2.m17011a()
            throw r6
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0680fe.m4667a(se2, byte[], int, int, db2):int");
    }

    /* renamed from: a */
    public static int m4668a(byte[] bArr, int i, db2 db2) {
        int i2 = i + 1;
        byte b = bArr[i];
        if (b < 0) {
            return m4658a((int) b, bArr, i2, db2);
        }
        db2.f3782a = b;
        return i2;
    }

    /* renamed from: a */
    public static int m4669a(byte[] bArr, int i, wc2<?> wc2, db2 db2) {
        rc2 rc2 = (rc2) wc2;
        int a = m4668a(bArr, i, db2);
        int i2 = db2.f3782a + a;
        while (a < i2) {
            a = m4668a(bArr, a, db2);
            rc2.mo10612g(db2.f3782a);
        }
        if (a == i2) {
            return a;
        }
        throw zc2.m17011a();
    }

    /* renamed from: a */
    public static long m4671a(ByteBuffer byteBuffer) {
        long j = (long) byteBuffer.getInt();
        return j < 0 ? j + 4294967296L : j;
    }

    /* renamed from: a */
    public static long m4672a(byte[] bArr, int i) {
        return ((long) (((bArr[i + 3] & 255) << 24) | (bArr[i] & 255) | ((bArr[i + 1] & 255) << 8) | ((bArr[i + 2] & 255) << 16))) & 4294967295L;
    }

    /* renamed from: a */
    public static long m4673a(byte[] bArr, int i, int i2) {
        return (m4672a(bArr, i) >> i2) & 67108863;
    }

    /* renamed from: a */
    public static Animator m4675a(u43 u43, float f, float f2, float f3) {
        ObjectAnimator ofObject = ObjectAnimator.ofObject(u43, u43.C1977c.f15327a, u43.C1976b.f15325b, new u43.C1979e[]{new u43.C1979e(f, f2, f3)});
        if (Build.VERSION.SDK_INT < 21) {
            return ofObject;
        }
        u43.C1979e revealInfo = u43.getRevealInfo();
        if (revealInfo != null) {
            Animator createCircularReveal = ViewAnimationUtils.createCircularReveal((View) u43, (int) f, (int) f2, revealInfo.f15331c, f3);
            AnimatorSet animatorSet = new AnimatorSet();
            animatorSet.playTogether(new Animator[]{ofObject, createCircularReveal});
            return animatorSet;
        }
        throw new IllegalStateException("Caller must set a non-null RevealInfo before calling this.");
    }

    /* renamed from: a */
    public static Keyframe m4676a(Keyframe keyframe, float f) {
        return keyframe.getType() == Float.TYPE ? Keyframe.ofFloat(f) : keyframe.getType() == Integer.TYPE ? Keyframe.ofInt(f) : Keyframe.ofObject(f);
    }

    /* renamed from: a */
    public static Uri m4679a(String str, String str2, String str3) {
        int indexOf = str.indexOf("&adurl");
        if (indexOf == -1) {
            indexOf = str.indexOf("?adurl");
        }
        if (indexOf == -1) {
            return Uri.parse(str).buildUpon().appendQueryParameter(str2, str3).build();
        }
        int i = indexOf + 1;
        return Uri.parse(str.substring(0, i) + str2 + "=" + str3 + "&" + str.substring(i));
    }

    /* renamed from: a */
    public static Bundle m4680a(Bundle bundle, String str) {
        Bundle bundle2 = bundle.getBundle(str);
        return bundle2 == null ? new Bundle() : bundle2;
    }

    /* renamed from: a */
    public static Bundle m4681a(Parcel parcel, int i) {
        int l = m4885l(parcel, i);
        int dataPosition = parcel.dataPosition();
        if (l == 0) {
            return null;
        }
        Bundle readBundle = parcel.readBundle();
        parcel.setDataPosition(dataPosition + l);
        return readBundle;
    }

    /* renamed from: a */
    public static <T extends Parcelable> T m4682a(Parcel parcel, int i, Parcelable.Creator<T> creator) {
        int l = m4885l(parcel, i);
        int dataPosition = parcel.dataPosition();
        if (l == 0) {
            return null;
        }
        T t = (Parcelable) creator.createFromParcel(parcel);
        parcel.setDataPosition(dataPosition + l);
        return t;
    }

    /* renamed from: a */
    public static Interpolator m4683a(Context context, int i) {
        if (Build.VERSION.SDK_INT >= 21) {
            return AnimationUtils.loadInterpolator(context, i);
        }
        XmlResourceParser xmlResourceParser = null;
        if (i == 17563663) {
            try {
                return new C0526db();
            } catch (XmlPullParserException e) {
                Resources.NotFoundException notFoundException = new Resources.NotFoundException("Can't load animation resource ID #0x" + Integer.toHexString(i));
                notFoundException.initCause(e);
                throw notFoundException;
            } catch (IOException e2) {
                Resources.NotFoundException notFoundException2 = new Resources.NotFoundException("Can't load animation resource ID #0x" + Integer.toHexString(i));
                notFoundException2.initCause(e2);
                throw notFoundException2;
            } catch (Throwable th) {
                if (xmlResourceParser != null) {
                    xmlResourceParser.close();
                }
                throw th;
            }
        } else if (i == 17563661) {
            return new C0595eb();
        } else {
            if (i == 17563662) {
                return new C0674fb();
            }
            XmlResourceParser animation = context.getResources().getAnimation(i);
            context.getResources();
            context.getTheme();
            Interpolator a = m4684a(context, (XmlPullParser) animation);
            animation.close();
            return a;
        }
    }

    /* renamed from: a */
    public static Interpolator m4684a(Context context, XmlPullParser xmlPullParser) {
        Interpolator yeVar;
        int depth = xmlPullParser.getDepth();
        Interpolator interpolator = null;
        while (true) {
            int next = xmlPullParser.next();
            if ((next != 3 || xmlPullParser.getDepth() > depth) && next != 1) {
                if (next == 2) {
                    AttributeSet asAttributeSet = Xml.asAttributeSet(xmlPullParser);
                    String name = xmlPullParser.getName();
                    if (name.equals("linearInterpolator")) {
                        interpolator = new LinearInterpolator();
                    } else {
                        if (name.equals("accelerateInterpolator")) {
                            yeVar = new AccelerateInterpolator(context, asAttributeSet);
                        } else if (name.equals("decelerateInterpolator")) {
                            yeVar = new DecelerateInterpolator(context, asAttributeSet);
                        } else if (name.equals("accelerateDecelerateInterpolator")) {
                            interpolator = new AccelerateDecelerateInterpolator();
                        } else if (name.equals("cycleInterpolator")) {
                            yeVar = new CycleInterpolator(context, asAttributeSet);
                        } else if (name.equals("anticipateInterpolator")) {
                            yeVar = new AnticipateInterpolator(context, asAttributeSet);
                        } else if (name.equals("overshootInterpolator")) {
                            yeVar = new OvershootInterpolator(context, asAttributeSet);
                        } else if (name.equals("anticipateOvershootInterpolator")) {
                            yeVar = new AnticipateOvershootInterpolator(context, asAttributeSet);
                        } else if (name.equals("bounceInterpolator")) {
                            interpolator = new BounceInterpolator();
                        } else if (name.equals("pathInterpolator")) {
                            yeVar = new C2348ye(context, asAttributeSet, xmlPullParser);
                        } else {
                            StringBuilder a = C0789gk.m5562a("Unknown interpolator name: ");
                            a.append(xmlPullParser.getName());
                            throw new RuntimeException(a.toString());
                        }
                        interpolator = yeVar;
                    }
                }
            }
        }
        return interpolator;
    }

    /* renamed from: a */
    public static dw1 m4685a(mq2 mq2) {
        boolean z;
        long j;
        long j2;
        long j3;
        long j4;
        mq2 mq22 = mq2;
        long currentTimeMillis = System.currentTimeMillis();
        Map<String, String> map = mq22.f10635c;
        String str = map.get("Date");
        long q = str != null ? m4894q(str) : 0;
        String str2 = map.get("Cache-Control");
        int i = 0;
        if (str2 != null) {
            String[] split = str2.split(",", 0);
            int i2 = 0;
            j2 = 0;
            j = 0;
            while (i < split.length) {
                String trim = split[i].trim();
                if (trim.equals("no-cache") || trim.equals("no-store")) {
                    return null;
                }
                if (trim.startsWith("max-age=")) {
                    try {
                        j2 = Long.parseLong(trim.substring(8));
                    } catch (Exception unused) {
                    }
                } else if (trim.startsWith("stale-while-revalidate=")) {
                    j = Long.parseLong(trim.substring(23));
                } else if (trim.equals("must-revalidate") || trim.equals("proxy-revalidate")) {
                    i2 = 1;
                }
                i++;
            }
            i = i2;
            z = true;
        } else {
            j2 = 0;
            j = 0;
            z = false;
        }
        String str3 = map.get("Expires");
        long q2 = str3 != null ? m4894q(str3) : 0;
        String str4 = map.get("Last-Modified");
        long q3 = str4 != null ? m4894q(str4) : 0;
        String str5 = map.get("ETag");
        if (z) {
            j4 = currentTimeMillis + (j2 * 1000);
            if (i == 0) {
                Long.signum(j);
                j3 = (j * 1000) + j4;
                dw1 dw1 = new dw1();
                dw1.f4150a = mq22.f10634b;
                dw1.f4151b = str5;
                dw1.f4155f = j4;
                dw1.f4154e = j3;
                dw1.f4152c = q;
                dw1.f4153d = q3;
                dw1.f4156g = map;
                dw1.f4157h = mq22.f10636d;
                return dw1;
            }
        } else {
            j4 = (q <= 0 || q2 < q) ? 0 : currentTimeMillis + (q2 - q);
        }
        j3 = j4;
        dw1 dw12 = new dw1();
        dw12.f4150a = mq22.f10634b;
        dw12.f4151b = str5;
        dw12.f4155f = j4;
        dw12.f4154e = j3;
        dw12.f4152c = q;
        dw12.f4153d = q3;
        dw12.f4156g = map;
        dw12.f4157h = mq22.f10636d;
        return dw12;
    }

    /* renamed from: a */
    public static <T> gt0<T> m4686a(kc1 kc1, rc1 rc1, rh2<p22<a80>> rh2, yv1 yv1, uy1 uy1, uo0 uo0, hi1<T> hi1, px0 px0, xv1 xv1, gd1 gd1) {
        return new gt0(kc1, rc1, rh2, yv1, uy1, uo0, hi1, px0, xv1, gd1);
    }

    /* renamed from: a */
    public static <AdT> hi1<AdT> m4687a(uy1 uy1, ci1 ci1, dv0 dv0, ez1 ez1, ps0<AdT> ps0, Executor executor, ScheduledExecutorService scheduledExecutorService) {
        return new hi1(uy1, ci1, dv0, ez1, ps0, executor, scheduledExecutorService);
    }

    /* renamed from: a */
    public static <V> i22<V> m4688a(Iterable<? extends p22<? extends V>> iterable) {
        return new i22<>(true, k02.m7945a(iterable), (h22) null);
    }

    /* renamed from: a */
    public static File m4689a(File file, boolean z) {
        if (z && file.exists() && !file.isDirectory()) {
            file.delete();
        }
        if (!file.exists()) {
            file.mkdirs();
        }
        return file;
    }

    /* renamed from: a */
    public static File m4690a(String str, File file) {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        File file2 = new File(file, str);
        m4689a(file2, false);
        return file2;
    }

    /* renamed from: a */
    public static File m4691a(String str, String str2, File file) {
        if (TextUtils.isEmpty(str) || TextUtils.isEmpty(str2)) {
            return null;
        }
        return new File(m4690a(str, file), str2);
    }

    /* renamed from: a */
    public static <T> T m4692a(Context context, String str, if0<IBinder, T> if0) {
        try {
            return if0.mo6473a(m4853e(context).mo3271a(str));
        } catch (Exception e) {
            throw new kf0(e);
        }
    }

    /* JADX INFO: finally extract failed */
    /* renamed from: a */
    public static <T> T m4694a(g02<T> g02) {
        StrictMode.ThreadPolicy threadPolicy = StrictMode.getThreadPolicy();
        try {
            StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder(threadPolicy).permitDiskReads().permitDiskWrites().build());
            T t = g02.get();
            StrictMode.setThreadPolicy(threadPolicy);
            return t;
        } catch (Throwable th) {
            StrictMode.setThreadPolicy(threadPolicy);
            throw th;
        }
    }

    /* renamed from: a */
    public static <T> T m4695a(T t) {
        if (t != null) {
            return t;
        }
        throw new NullPointerException("null reference");
    }

    /* renamed from: a */
    public static Object m4696a(Object obj, int i) {
        if (obj != null) {
            return obj;
        }
        throw new NullPointerException(C0789gk.m5551a(20, "at index ", i));
    }

    /* renamed from: a */
    public static <T> T m4697a(T t, Object obj) {
        if (t != null) {
            return t;
        }
        throw new NullPointerException(String.valueOf(obj));
    }

    /* renamed from: a */
    public static <T> T m4698a(T t, String str) {
        if (t != null) {
            return t;
        }
        throw new NullPointerException(str);
    }

    /* renamed from: a */
    public static <T> T m4699a(T t, String str, Object obj) {
        if (t != null) {
            return t;
        }
        throw new NullPointerException(m4704a(str, obj));
    }

    /* renamed from: a */
    public static <V> V m4700a(Future<V> future) {
        V v;
        boolean z = false;
        while (true) {
            try {
                v = future.get();
                break;
            } catch (InterruptedException unused) {
                z = true;
            } catch (Throwable th) {
                if (z) {
                    Thread.currentThread().interrupt();
                }
                throw th;
            }
        }
        if (z) {
            Thread.currentThread().interrupt();
        }
        return v;
    }

    /* renamed from: a */
    public static String m4701a(int i, int i2, String str) {
        if (i < 0) {
            return m4704a("%s (%s) must not be negative", str, Integer.valueOf(i));
        } else if (i2 >= 0) {
            return m4704a("%s (%s) must not be greater than size (%s)", str, Integer.valueOf(i), Integer.valueOf(i2));
        } else {
            throw new IllegalArgumentException(C0789gk.m5551a(26, "negative size: ", i2));
        }
    }

    /* renamed from: a */
    public static String m4705a(z72 z72) {
        int i = u52.f15343a[z72.ordinal()];
        if (i == 1) {
            return "HmacSha1";
        }
        if (i == 2) {
            return "HmacSha256";
        }
        if (i == 3) {
            return "HmacSha512";
        }
        String valueOf = String.valueOf(z72);
        StringBuilder sb = new StringBuilder(valueOf.length() + 27);
        sb.append("hash unsupported for HMAC: ");
        sb.append(valueOf);
        throw new NoSuchAlgorithmException(sb.toString());
    }

    /* renamed from: a */
    public static String m4706a(byte[] bArr, boolean z) {
        return Base64.encodeToString(bArr, z ? 11 : 2);
    }

    /* renamed from: a */
    public static BigInteger m4707a(EllipticCurve ellipticCurve) {
        ECField field = ellipticCurve.getField();
        if (field instanceof ECFieldFp) {
            return ((ECFieldFp) field).getP();
        }
        throw new GeneralSecurityException("Only curves over prime order fields are supported");
    }

    /* renamed from: a */
    public static KeyPair m4708a(ECParameterSpec eCParameterSpec) {
        KeyPairGenerator a = y92.f17676i.mo12834a("EC");
        a.initialize(eCParameterSpec);
        return a.generateKeyPair();
    }

    /* renamed from: a */
    public static ECParameterSpec m4709a(String str, String str2, String str3, String str4, String str5) {
        BigInteger bigInteger = new BigInteger(str);
        return new ECParameterSpec(new EllipticCurve(new ECFieldFp(bigInteger), bigInteger.subtract(new BigInteger("3")), new BigInteger(str3, 16)), new ECPoint(new BigInteger(str4, 16), new BigInteger(str5, 16)), new BigInteger(str2), 1);
    }

    /* renamed from: a */
    public static ECParameterSpec m4710a(x92 x92) {
        String str;
        String str2;
        String str3;
        String str4;
        String str5;
        int i = v92.f15931b[x92.ordinal()];
        if (i == 1) {
            str = "115792089210356248762697446949407573530086143415290314195533631308867097853951";
            str2 = "115792089210356248762697446949407573529996955224135760342422259061068512044369";
            str3 = "5ac635d8aa3a93e7b3ebbd55769886bc651d06b0cc53b0f63bce3c3e27d2604b";
            str4 = "6b17d1f2e12c4247f8bce6e563a440f277037d812deb33a0f4a13945d898c296";
            str5 = "4fe342e2fe1a7f9b8ee7eb4a7c0f9e162bce33576b315ececbb6406837bf51f5";
        } else if (i == 2) {
            str = "39402006196394479212279040100143613805079739270465446667948293404245721771496870329047266088258938001861606973112319";
            str2 = "39402006196394479212279040100143613805079739270465446667946905279627659399113263569398956308152294913554433653942643";
            str3 = "b3312fa7e23ee7e4988e056be3f82d19181d9c6efe8141120314088f5013875ac656398d8a2ed19d2a85c8edd3ec2aef";
            str4 = "aa87ca22be8b05378eb1c71ef320ad746e1d3b628ba79b9859f741e082542a385502f25dbf55296c3a545e3872760ab7";
            str5 = "3617de4a96262c6f5d9e98bf9292dc29f8f41dbd289a147ce9da3113b5f0b8c00a60b1ce1d7e819d7a431d7c90ea0e5f";
        } else if (i == 3) {
            str = "6864797660130609714981900799081393217269435300143305409394463459185543183397656052122559640661454554977296311391480858037121987999716643812574028291115057151";
            str2 = "6864797660130609714981900799081393217269435300143305409394463459185543183397655394245057746333217197532963996371363321113864768612440380340372808892707005449";
            str3 = "051953eb9618e1c9a1f929a21a0b68540eea2da725b99b315f3b8b489918ef109e156193951ec7e937b1652c0bd3bb1bf073573df883d2c34f1ef451fd46b503f00";
            str4 = "c6858e06b70404e9cd9e3ecb662395b4429c648139053fb521f828af606b4d3dbaa14b5e77efe75928fe1dc127a2ffa8de3348b3c1856a429bf97e7e31c2e5bd66";
            str5 = "11839296a789a3bc0045c8a5fb42c7d1bd998f54449579b446817afbd17273e662c97ee72995ef42640c550b9013fad0761353c7086a272c24088be94769fd16650";
        } else {
            String valueOf = String.valueOf(x92);
            StringBuilder sb = new StringBuilder(valueOf.length() + 22);
            sb.append("curve not implemented:");
            sb.append(valueOf);
            throw new NoSuchAlgorithmException(sb.toString());
        }
        return m4709a(str, str2, str3, str4, str5);
    }

    /* renamed from: a */
    public static Date m4711a(long j) {
        return new Date((j - 2082844800) * 1000);
    }

    /* renamed from: a */
    public static <T> Set<T> m4712a(int i, boolean z) {
        return i <= (z ? 128 : 256) ? new C0283b5(i) : new HashSet(i, z ? 0.75f : 1.0f);
    }

    /* renamed from: a */
    public static kc1 m4716a(bx0 bx0, yv1 yv1, tb1 tb1, o22 o22, ScheduledExecutorService scheduledExecutorService, le1 le1) {
        return new kc1(bx0, yv1, tb1, o22, scheduledExecutorService, le1);
    }

    /* renamed from: a */
    public static C1165kk m4717a(qv2 qv2, boolean z) {
        List<String> list = qv2.f13242b0;
        HashSet hashSet = list != null ? new HashSet(list) : null;
        Date date = new Date(qv2.f13239Y);
        int i = qv2.f13241a0;
        return new C1165kk(date, i != 1 ? i != 2 ? C0945ik.UNKNOWN : C0945ik.FEMALE : C0945ik.MALE, hashSet, z, qv2.f13248h0);
    }

    /* renamed from: a */
    public static kz0 m4718a(qt0 qt0) {
        kz0 kz0 = new kz0(qt0, pf0.f12418f);
        m4698a(kz0, "Cannot return null from a non-@Nullable @Provides method");
        return kz0;
    }

    /* renamed from: a */
    public static JSONObject m4720a(String str) {
        return m4721a(str, (String) null);
    }

    /* renamed from: a */
    public static JSONObject m4721a(String str, String str2) {
        String str3;
        try {
            return new JSONObject(str);
        } catch (JSONException e) {
            if (str2 == null) {
                str3 = "";
            } else {
                StringBuilder b = C0789gk.m5569b(str2, ": ");
                b.append(e.toString());
                str3 = b.toString();
            }
            C0869hj.f6827i.mo6566a(C0789gk.m5562a(str3).toString());
            return new JSONObject();
        }
    }

    /* renamed from: a */
    public static JSONObject m4722a(JSONObject... jSONObjectArr) {
        try {
            JSONObject jSONObject = new JSONObject();
            for (JSONObject jSONObject2 : jSONObjectArr) {
                if (jSONObject2 != null) {
                    Iterator<String> keys = jSONObject2.keys();
                    while (keys.hasNext()) {
                        String next = keys.next();
                        jSONObject.put(next, jSONObject2.get(next));
                    }
                }
            }
            return jSONObject;
        } catch (JSONException unused) {
            return jSONObjectArr.length > 0 ? jSONObjectArr[0] : new JSONObject();
        }
    }

    /* renamed from: a */
    public static ov1 m4723a(tv2 tv2) {
        return tv2.f15195f0 ? new ov1(-3, 0, true) : new ov1(tv2.f15191b0, tv2.f15188Y, false);
    }

    /* renamed from: a */
    public static <O> p22<O> m4726a(s12<O> s12, Executor executor) {
        c32 c32 = new c32(s12);
        executor.execute(c32);
        return c32;
    }

    /* renamed from: a */
    public static C1617pg m4727a(String str, C1617pg pgVar) {
        m4730a().mo11970k().mo9678a(str, pgVar);
        return pgVar;
    }

    /* renamed from: a */
    public static tv2 m4729a(Context context, List<ov1> list) {
        ArrayList arrayList = new ArrayList();
        for (ov1 next : list) {
            if (next.f12136c) {
                arrayList.add(C0790gl.f6211n);
            } else {
                arrayList.add(new C0790gl(next.f12134a, next.f12135b));
            }
        }
        return new tv2(context, (C0790gl[]) arrayList.toArray(new C0790gl[arrayList.size()]));
    }

    /* renamed from: a */
    public static w92 m4731a(l72 l72) {
        int i = u52.f15345c[l72.ordinal()];
        if (i == 1) {
            return w92.UNCOMPRESSED;
        }
        if (i == 2) {
            return w92.DO_NOT_USE_CRUNCHY_UNCOMPRESSED;
        }
        if (i == 3) {
            return w92.COMPRESSED;
        }
        String valueOf = String.valueOf(l72);
        StringBuilder sb = new StringBuilder(valueOf.length() + 22);
        sb.append("unknown point format: ");
        sb.append(valueOf);
        throw new GeneralSecurityException(sb.toString());
    }

    /* renamed from: a */
    public static x92 m4732a(y72 y72) {
        int i = u52.f15344b[y72.ordinal()];
        if (i == 1) {
            return x92.NIST_P256;
        }
        if (i == 2) {
            return x92.NIST_P384;
        }
        if (i == 3) {
            return x92.NIST_P521;
        }
        String valueOf = String.valueOf(y72);
        StringBuilder sb = new StringBuilder(valueOf.length() + 20);
        sb.append("unknown curve type: ");
        sb.append(valueOf);
        throw new GeneralSecurityException(sb.toString());
    }

    /* renamed from: a */
    public static void m4736a(int i, int i2, int i3) {
        String str;
        if (i < 0 || i2 < i || i2 > i3) {
            if (i < 0 || i > i3) {
                str = m4701a(i, i3, "start index");
            } else if (i2 < 0 || i2 > i3) {
                str = m4701a(i2, i3, "end index");
            } else {
                str = m4704a("end index (%s) must not be less than start index (%s)", Integer.valueOf(i2), Integer.valueOf(i));
            }
            throw new IndexOutOfBoundsException(str);
        }
    }

    /* renamed from: a */
    public static void m4737a(AnimatorSet animatorSet, List<Animator> list) {
        int size = list.size();
        long j = 0;
        for (int i = 0; i < size; i++) {
            Animator animator = list.get(i);
            j = Math.max(j, animator.getDuration() + animator.getStartDelay());
        }
        ValueAnimator ofInt = ValueAnimator.ofInt(new int[]{0, 0});
        ofInt.setDuration(j);
        list.add(0, ofInt);
        animatorSet.playTogether(list);
    }

    @Deprecated
    /* renamed from: a */
    public static void m4738a(Context context, SharedPreferences.Editor editor, String str) {
        File file = new File(context.getApplicationInfo().dataDir, "shared_prefs");
        File parentFile = file.getParentFile();
        if (parentFile != null) {
            parentFile.setExecutable(true, false);
        }
        file.setExecutable(true, false);
        editor.commit();
        new File(file, String.valueOf(str).concat(".xml")).setReadable(true, false);
    }

    /* renamed from: a */
    public static void m4741a(Bundle bundle, String str, Integer num, boolean z) {
        if (z) {
            bundle.putInt(str, num.intValue());
        }
    }

    /* renamed from: a */
    public static void m4742a(Bundle bundle, String str, List<String> list) {
        if (list != null) {
            bundle.putStringArrayList(str, new ArrayList(list));
        }
    }

    /* renamed from: a */
    public static void m4743a(Parcel parcel, int i, float f) {
        m4829c(parcel, i, 4);
        parcel.writeFloat(f);
    }

    /* renamed from: a */
    public static void m4744a(Parcel parcel, int i, int i2) {
        m4829c(parcel, i, 4);
        parcel.writeInt(i2);
    }

    /* renamed from: a */
    public static void m4745a(Parcel parcel, int i, long j) {
        m4829c(parcel, i, 8);
        parcel.writeLong(j);
    }

    /* renamed from: a */
    public static void m4746a(Parcel parcel, int i, Bundle bundle, boolean z) {
        if (bundle != null) {
            int n = m4889n(parcel, i);
            parcel.writeBundle(bundle);
            m4891o(parcel, n);
        } else if (z) {
            m4829c(parcel, i, 0);
        }
    }

    /* renamed from: a */
    public static void m4747a(Parcel parcel, int i, IBinder iBinder, boolean z) {
        if (iBinder != null) {
            int n = m4889n(parcel, i);
            parcel.writeStrongBinder(iBinder);
            m4891o(parcel, n);
        } else if (z) {
            m4829c(parcel, i, 0);
        }
    }

    /* renamed from: a */
    public static void m4748a(Parcel parcel, int i, Parcelable parcelable, int i2, boolean z) {
        if (parcelable != null) {
            int n = m4889n(parcel, i);
            parcelable.writeToParcel(parcel, i2);
            m4891o(parcel, n);
        } else if (z) {
            m4829c(parcel, i, 0);
        }
    }

    /* renamed from: a */
    public static void m4749a(Parcel parcel, int i, String str, boolean z) {
        if (str != null) {
            int n = m4889n(parcel, i);
            parcel.writeString(str);
            m4891o(parcel, n);
        } else if (z) {
            m4829c(parcel, i, 0);
        }
    }

    /* renamed from: a */
    public static void m4750a(Parcel parcel, int i, List<String> list, boolean z) {
        if (list != null) {
            int n = m4889n(parcel, i);
            parcel.writeStringList(list);
            m4891o(parcel, n);
        } else if (z) {
            m4829c(parcel, i, 0);
        }
    }

    /* renamed from: a */
    public static void m4751a(Parcel parcel, int i, boolean z) {
        m4829c(parcel, i, 4);
        parcel.writeInt(z ? 1 : 0);
    }

    /* renamed from: a */
    public static void m4752a(Parcel parcel, int i, byte[] bArr, boolean z) {
        if (bArr != null) {
            int n = m4889n(parcel, i);
            parcel.writeByteArray(bArr);
            m4891o(parcel, n);
        } else if (z) {
            m4829c(parcel, i, 0);
        }
    }

    /* renamed from: a */
    public static void m4754a(Parcel parcel, int i, String[] strArr, boolean z) {
        if (strArr != null) {
            int n = m4889n(parcel, i);
            parcel.writeStringArray(strArr);
            m4891o(parcel, n);
        } else if (z) {
            m4829c(parcel, i, 0);
        }
    }

    /* renamed from: a */
    public static <T> void m4755a(T t, Class<T> cls) {
        if (t == null) {
            throw new IllegalStateException(String.valueOf(cls.getCanonicalName()).concat(" must be set"));
        }
    }

    /* renamed from: a */
    public static void m4757a(String str, Object obj, StringBuffer stringBuffer, StringBuffer stringBuffer2) {
        if (obj == null) {
            return;
        }
        if (obj instanceof gg2) {
            int length = stringBuffer.length();
            if (str != null) {
                stringBuffer2.append(stringBuffer);
                stringBuffer2.append(m4897t(str));
                stringBuffer2.append(" <\n");
                stringBuffer.append("  ");
            }
            Class<?> cls = obj.getClass();
            for (Field field : cls.getFields()) {
                int modifiers = field.getModifiers();
                String name = field.getName();
                if (!"cachedSize".equals(name) && (modifiers & 1) == 1 && (modifiers & 8) != 8 && !name.startsWith("_") && !name.endsWith("_")) {
                    Class<?> type = field.getType();
                    Object obj2 = field.get(obj);
                    if (!type.isArray() || type.getComponentType() == Byte.TYPE) {
                        m4757a(name, obj2, stringBuffer, stringBuffer2);
                    } else {
                        int length2 = obj2 == null ? 0 : Array.getLength(obj2);
                        for (int i = 0; i < length2; i++) {
                            m4757a(name, Array.get(obj2, i), stringBuffer, stringBuffer2);
                        }
                    }
                }
            }
            for (Method name2 : cls.getMethods()) {
                String name3 = name2.getName();
                if (name3.startsWith("set")) {
                    String substring = name3.substring(3);
                    try {
                        String valueOf = String.valueOf(substring);
                        if (((Boolean) cls.getMethod(valueOf.length() != 0 ? "has".concat(valueOf) : new String("has"), new Class[0]).invoke(obj, new Object[0])).booleanValue()) {
                            String valueOf2 = String.valueOf(substring);
                            m4757a(substring, cls.getMethod(valueOf2.length() != 0 ? "get".concat(valueOf2) : new String("get"), new Class[0]).invoke(obj, new Object[0]), stringBuffer, stringBuffer2);
                        }
                    } catch (NoSuchMethodException unused) {
                    }
                }
            }
            if (str != null) {
                stringBuffer.setLength(length);
                stringBuffer2.append(stringBuffer);
                stringBuffer2.append(">\n");
                return;
            }
            return;
        }
        String t = m4897t(str);
        stringBuffer2.append(stringBuffer);
        stringBuffer2.append(t);
        stringBuffer2.append(": ");
        if (obj instanceof String) {
            String str2 = (String) obj;
            if (!str2.startsWith("http") && str2.length() > 200) {
                str2 = String.valueOf(str2.substring(0, 200)).concat("[...]");
            }
            int length3 = str2.length();
            StringBuilder sb = new StringBuilder(length3);
            for (int i2 = 0; i2 < length3; i2++) {
                char charAt = str2.charAt(i2);
                if (charAt < ' ' || charAt > '~' || charAt == '\"' || charAt == '\'') {
                    sb.append(String.format("\\u%04x", new Object[]{Integer.valueOf(charAt)}));
                } else {
                    sb.append(charAt);
                }
            }
            String sb2 = sb.toString();
            stringBuffer2.append("\"");
            stringBuffer2.append(sb2);
            stringBuffer2.append("\"");
        } else if (obj instanceof byte[]) {
            byte[] bArr = (byte[]) obj;
            stringBuffer2.append('\"');
            for (byte b : bArr) {
                byte b2 = b & 255;
                if (b2 == 92 || b2 == 34) {
                    stringBuffer2.append('\\');
                } else if (b2 < 32 || b2 >= Byte.MAX_VALUE) {
                    stringBuffer2.append(String.format("\\%03o", new Object[]{Integer.valueOf(b2)}));
                }
                stringBuffer2.append((char) b2);
            }
            stringBuffer2.append('\"');
        } else {
            stringBuffer2.append(obj);
        }
        stringBuffer2.append("\n");
    }

    /* renamed from: a */
    public static void m4758a(String str, Throwable th) {
        if (m4884k()) {
            Log.v("Ads", str, th);
        }
    }

    /* renamed from: a */
    public static void m4759a(String str, C1617pg pgVar) {
        m4730a().mo11970k().mo9678a(str, pgVar);
    }

    /* renamed from: a */
    public static final void m4760a(StringBuilder sb, int i, String str, Object obj) {
        if (obj instanceof List) {
            for (Object a : (List) obj) {
                m4760a(sb, i, str, a);
            }
        } else if (obj instanceof Map) {
            for (Map.Entry a2 : ((Map) obj).entrySet()) {
                m4760a(sb, i, str, (Object) a2);
            }
        } else {
            sb.append(10);
            int i2 = 0;
            for (int i3 = 0; i3 < i; i3++) {
                sb.append(' ');
            }
            sb.append(str);
            if (obj instanceof String) {
                sb.append(": \"");
                sb.append(m4702a(hb2.m6127a((String) obj)));
                sb.append('\"');
            } else if (obj instanceof hb2) {
                sb.append(": \"");
                sb.append(m4702a((hb2) obj));
                sb.append('\"');
            } else if (obj instanceof oc2) {
                sb.append(" {");
                m4772a((zd2) (oc2) obj, sb, i + 2);
                sb.append("\n");
                while (i2 < i) {
                    sb.append(' ');
                    i2++;
                }
                sb.append("}");
            } else if (obj instanceof Map.Entry) {
                sb.append(" {");
                Map.Entry entry = (Map.Entry) obj;
                int i4 = i + 2;
                m4760a(sb, i4, "key", entry.getKey());
                m4760a(sb, i4, "value", entry.getValue());
                sb.append("\n");
                while (i2 < i) {
                    sb.append(' ');
                    i2++;
                }
                sb.append("}");
            } else {
                sb.append(": ");
                sb.append(obj.toString());
            }
        }
    }

    /* renamed from: a */
    public static final void m4762a(ByteBuffer byteBuffer, ByteBuffer byteBuffer2, ByteBuffer byteBuffer3, int i) {
        if (i < 0 || byteBuffer2.remaining() < i || byteBuffer3.remaining() < i || byteBuffer.remaining() < i) {
            throw new IllegalArgumentException("That combination of buffers, offsets and length to xor result in out-of-bond accesses.");
        }
        for (int i2 = 0; i2 < i; i2++) {
            byteBuffer.put((byte) (byteBuffer2.get() ^ byteBuffer3.get()));
        }
    }

    /* renamed from: a */
    public static void m4763a(ECPoint eCPoint, EllipticCurve ellipticCurve) {
        BigInteger a = m4707a(ellipticCurve);
        BigInteger affineX = eCPoint.getAffineX();
        BigInteger affineY = eCPoint.getAffineY();
        if (affineX == null || affineY == null) {
            throw new GeneralSecurityException("point is at infinity");
        } else if (affineX.signum() == -1 || affineX.compareTo(a) >= 0) {
            throw new GeneralSecurityException("x is out of range");
        } else if (affineY.signum() == -1 || affineY.compareTo(a) >= 0) {
            throw new GeneralSecurityException("y is out of range");
        } else if (!affineY.multiply(affineY).mod(a).equals(affineX.multiply(affineX).add(ellipticCurve.getA()).multiply(affineX).add(ellipticCurve.getB()).mod(a))) {
            throw new GeneralSecurityException("Point is not on curve");
        }
    }

    /* renamed from: a */
    public static void m4764a(List<String> list, C1878st<String> stVar) {
        String a = stVar.mo11055a();
        if (!TextUtils.isEmpty(a)) {
            list.add(a);
        }
    }

    /* renamed from: a */
    public static <T> void m4765a(AtomicReference<T> atomicReference, au1<T> au1) {
        T t = atomicReference.get();
        if (t != null) {
            try {
                au1.mo2144a(t);
            } catch (RemoteException e) {
                m4859e("#007 Could not call remote method.", (Throwable) e);
            }
        }
    }

    /* renamed from: a */
    public static void m4767a(p22<?> p22, String str) {
        m4766a(p22, new sf0(str), (Executor) pf0.f12418f);
    }

    /* renamed from: a */
    public static void m4768a(r72 r72) {
        m4710a(m4732a(r72.mo10543j().mo12150j()));
        m4705a(r72.mo10543j().mo12151k());
        if (r72.mo10545l() != l72.UNKNOWN_FORMAT) {
            a42.m192a(r72.mo10544k().mo9118j());
            return;
        }
        throw new GeneralSecurityException("unknown EC point format");
    }

    /* renamed from: a */
    public static void m4769a(s00 s00, String str, String str2) {
        StringBuilder sb = new StringBuilder(C0789gk.m5548a(str2, C0789gk.m5548a(str, 3)));
        sb.append(str);
        sb.append("(");
        sb.append(str2);
        sb.append(");");
        s00.mo4991a(sb.toString());
    }

    /* renamed from: a */
    public static void m4771a(s00 s00, String str, JSONObject jSONObject) {
        if (jSONObject == null) {
            jSONObject = new JSONObject();
        }
        s00.mo6363a(str, jSONObject.toString());
    }

    /* renamed from: a */
    public static void m4773a(boolean z) {
        if (!z) {
            throw new IllegalArgumentException();
        }
    }

    /* renamed from: a */
    public static void m4774a(boolean z, Object obj) {
        if (!z) {
            throw new IllegalArgumentException(String.valueOf(obj));
        }
    }

    /* renamed from: a */
    public static void m4775a(byte[] bArr, long j, int i) {
        int i2 = 0;
        while (i2 < 4) {
            bArr[i + i2] = (byte) ((int) (255 & j));
            i2++;
            j >>= 8;
        }
    }

    /* renamed from: a */
    public static boolean m4776a(byte b) {
        return b > -65;
    }

    /* renamed from: a */
    public static boolean m4777a(int i) {
        return i >= 28 && i <= 31;
    }

    /* renamed from: a */
    public static synchronized boolean m4778a(Context context) {
        boolean z;
        synchronized (C1185kr.class) {
            Context applicationContext = context.getApplicationContext();
            if (f5246i == null || f5247j == null || f5246i != applicationContext) {
                f5247j = null;
                if (m4868g()) {
                    z = Boolean.valueOf(applicationContext.getPackageManager().isInstantApp());
                } else {
                    try {
                        context.getClassLoader().loadClass("com.google.android.instantapps.supervisor.InstantAppsRuntime");
                        f5247j = true;
                    } catch (ClassNotFoundException unused) {
                        z = false;
                    }
                    f5246i = applicationContext;
                    boolean booleanValue = f5247j.booleanValue();
                    return booleanValue;
                }
                f5247j = z;
                f5246i = applicationContext;
                boolean booleanValue2 = f5247j.booleanValue();
                return booleanValue2;
            }
            boolean booleanValue3 = f5247j.booleanValue();
            return booleanValue3;
        }
    }

    /* renamed from: a */
    public static boolean m4779a(File file) {
        if (!file.exists()) {
            return true;
        }
        if (file.isDirectory()) {
            for (File a : file.listFiles()) {
                m4779a(a);
            }
        }
        return file.delete();
    }

    /* renamed from: a */
    public static boolean m4782a(JSONObject jSONObject, String str) {
        Iterator<String> keys = jSONObject.keys();
        while (keys.hasNext()) {
            if (str.equals(keys.next())) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: a */
    public static byte[] m4789a(String str, boolean z) {
        byte[] decode = Base64.decode(str, z ? 11 : 2);
        if (decode.length != 0 || str.length() <= 0) {
            return decode;
        }
        throw new IllegalArgumentException(str.length() != 0 ? "Unable to decode ".concat(str) : new String("Unable to decode "));
    }

    /* renamed from: a */
    public static final byte[] m4790a(byte[] bArr, int i, byte[] bArr2, int i2, int i3) {
        if (i3 < 0 || bArr.length - i3 < i || bArr2.length - i3 < i2) {
            throw new IllegalArgumentException("That combination of buffers, offsets and length to xor result in out-of-bond accesses.");
        }
        byte[] bArr3 = new byte[i3];
        for (int i4 = 0; i4 < i3; i4++) {
            bArr3[i4] = (byte) (bArr[i4 + i] ^ bArr2[i4 + i2]);
        }
        return bArr3;
    }

    /* renamed from: a */
    public static final byte[] m4791a(byte[] bArr, byte[] bArr2) {
        if (bArr.length == bArr2.length) {
            return m4790a(bArr, 0, bArr2, 0, bArr.length);
        }
        throw new IllegalArgumentException("The lengths of x and y should match.");
    }

    /* renamed from: a */
    public static byte[] m4792a(byte[]... bArr) {
        int length = bArr.length;
        int i = 0;
        int i2 = 0;
        while (i < length) {
            byte[] bArr2 = bArr[i];
            if (i2 <= Integer.MAX_VALUE - bArr2.length) {
                i2 += bArr2.length;
                i++;
            } else {
                throw new GeneralSecurityException("exceeded size limit");
            }
        }
        byte[] bArr3 = new byte[i2];
        int i3 = 0;
        for (byte[] bArr4 : bArr) {
            System.arraycopy(bArr4, 0, bArr3, i3, bArr4.length);
            i3 += bArr4.length;
        }
        return bArr3;
    }

    /* renamed from: b */
    public static int m4794b(int i, int i2) {
        String str;
        if (i >= 0 && i < i2) {
            return i;
        }
        if (i < 0) {
            str = m4704a("%s (%s) must not be negative", "index", Integer.valueOf(i));
        } else if (i2 < 0) {
            throw new IllegalArgumentException(C0789gk.m5551a(26, "negative size: ", i2));
        } else {
            str = m4704a("%s (%s) must be less than size (%s)", "index", Integer.valueOf(i), Integer.valueOf(i2));
        }
        throw new IndexOutOfBoundsException(str);
    }

    /* renamed from: b */
    public static int m4796b(ByteBuffer byteBuffer) {
        int i = byteBuffer.get();
        if (i < 0) {
            i += 256;
        }
        int i2 = (i << 8) + 0;
        int i3 = byteBuffer.get();
        if (i3 < 0) {
            i3 += 256;
        }
        return i2 + i3;
    }

    /* renamed from: b */
    public static int m4797b(byte[] bArr, int i) {
        return ((bArr[i + 3] & 255) << 24) | (bArr[i] & 255) | ((bArr[i + 1] & 255) << 8) | ((bArr[i + 2] & 255) << 16);
    }

    /* renamed from: b */
    public static int m4798b(byte[] bArr, int i, db2 db2) {
        int i2 = i + 1;
        long j = (long) bArr[i];
        if (j >= 0) {
            db2.f3783b = j;
            return i2;
        }
        int i3 = i2 + 1;
        byte b = bArr[i2];
        long j2 = (j & 127) | (((long) (b & Byte.MAX_VALUE)) << 7);
        int i4 = 7;
        while (b < 0) {
            int i5 = i3 + 1;
            byte b2 = bArr[i3];
            i4 += 7;
            j2 |= ((long) (b2 & Byte.MAX_VALUE)) << i4;
            int i6 = i5;
            b = b2;
            i3 = i6;
        }
        db2.f3783b = j2;
        return i3;
    }

    /* renamed from: b */
    public static Cursor m4799b(SQLiteDatabase sQLiteDatabase, int i) {
        String[] strArr = {"value"};
        String[] strArr2 = new String[1];
        if (i == 0) {
            strArr2[0] = "failed_requests";
        } else if (i == 1) {
            strArr2[0] = "total_requests";
        } else if (i == 2) {
            strArr2[0] = "last_successful_request_time";
        }
        return sQLiteDatabase.query("offline_signal_statistics", strArr, "statistic_name = ?", strArr2, (String) null, (String) null, (String) null);
    }

    /* renamed from: b */
    public static <T> T m4800b(T t) {
        if (t != null) {
            return t;
        }
        throw new NullPointerException();
    }

    /* renamed from: b */
    public static <T> T m4801b(T t, Object obj) {
        if (t != null) {
            return t;
        }
        throw new NullPointerException(String.valueOf(obj));
    }

    /* renamed from: b */
    public static <V> V m4802b(Future<V> future) {
        if (future.isDone()) {
            return m4700a(future);
        }
        throw new IllegalStateException(m4704a("Future was expected to be done: %s", future));
    }

    /* renamed from: b */
    public static JSONArray m4803b(JSONObject jSONObject, String str) {
        JSONArray optJSONArray = jSONObject.optJSONArray(str);
        return optJSONArray == null ? new JSONArray() : optJSONArray;
    }

    /* renamed from: b */
    public static void m4804b(Parcel parcel, int i, int i2) {
        int l = m4885l(parcel, i);
        if (l != i2) {
            String hexString = Integer.toHexString(l);
            StringBuilder sb = new StringBuilder(C0789gk.m5548a(hexString, 46));
            sb.append("Expected size ");
            sb.append(i2);
            sb.append(" got ");
            sb.append(l);
            sb.append(" (0x");
            sb.append(hexString);
            sb.append(")");
            throw new C1941tq(sb.toString(), parcel);
        }
    }

    /* renamed from: b */
    public static void m4805b(String str) {
        if (zq2.f18517a >= 18) {
            Trace.beginSection(str);
        }
    }

    /* renamed from: b */
    public static void m4806b(String str, Throwable th) {
        if (m4812b(3)) {
            Log.d("Ads", str, th);
        }
    }

    /* renamed from: b */
    public static void m4807b(s00 s00, String str, JSONObject jSONObject) {
        if (jSONObject == null) {
            jSONObject = new JSONObject();
        }
        String jSONObject2 = jSONObject.toString();
        StringBuilder sb = new StringBuilder();
        sb.append("(window.AFMA_ReceiveMessage || function() {})('");
        sb.append(str);
        sb.append("'");
        sb.append(",");
        sb.append(jSONObject2);
        sb.append(");");
        String valueOf = String.valueOf(sb.toString());
        m4886l(valueOf.length() != 0 ? "Dispatching AFMA event: ".concat(valueOf) : new String("Dispatching AFMA event: "));
        s00.mo4991a(sb.toString());
    }

    /* renamed from: b */
    public static void m4808b(boolean z) {
        if (!z) {
            throw new IllegalArgumentException();
        }
    }

    /* renamed from: b */
    public static void m4809b(boolean z, Object obj) {
        if (!z) {
            throw new IllegalStateException(String.valueOf(obj));
        }
    }

    /* renamed from: b */
    public static boolean m4810b() {
        return f5238a != null;
    }

    /* renamed from: b */
    public static /* synthetic */ boolean m4811b(byte b) {
        return b >= 0;
    }

    /* renamed from: b */
    public static boolean m4812b(int i) {
        return i >= 5 || Log.isLoggable("Ads", i);
    }

    /* renamed from: b */
    public static boolean m4813b(Context context) {
        if (f5244g == null) {
            PackageManager packageManager = context.getPackageManager();
            f5244g = Boolean.valueOf(packageManager.hasSystemFeature("com.google.android.feature.services_updater") && packageManager.hasSystemFeature("cn.google.services"));
        }
        return f5244g.booleanValue();
    }

    /* renamed from: b */
    public static byte[] m4814b(Parcel parcel, int i) {
        int l = m4885l(parcel, i);
        int dataPosition = parcel.dataPosition();
        if (l == 0) {
            return null;
        }
        byte[] createByteArray = parcel.createByteArray();
        parcel.setDataPosition(dataPosition + l);
        return createByteArray;
    }

    /* renamed from: b */
    public static byte[] m4815b(byte[] bArr) {
        if (bArr.length == 16) {
            byte[] bArr2 = new byte[16];
            for (int i = 0; i < 16; i++) {
                bArr2[i] = (byte) ((bArr[i] << 1) & 254);
                if (i < 15) {
                    bArr2[i] = (byte) (bArr2[i] | ((byte) ((bArr[i + 1] >> 7) & 1)));
                }
            }
            bArr2[15] = (byte) (((byte) ((bArr[0] >> 7) & 135)) ^ bArr2[15]);
            return bArr2;
        }
        throw new IllegalArgumentException("value must be a block.");
    }

    /* renamed from: b */
    public static <T> T[] m4816b(Parcel parcel, int i, Parcelable.Creator<T> creator) {
        int l = m4885l(parcel, i);
        int dataPosition = parcel.dataPosition();
        if (l == 0) {
            return null;
        }
        T[] createTypedArray = parcel.createTypedArray(creator);
        parcel.setDataPosition(dataPosition + l);
        return createTypedArray;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:47:0x007f, code lost:
        if (((r6 >= 65382 && r6 <= 65437) || (r6 >= 65441 && r6 <= 65500)) != false) goto L_0x0081;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:66:0x00c4, code lost:
        if (r4 == false) goto L_0x00d3;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:69:0x00d1, code lost:
        if (r4 == false) goto L_0x00d3;
     */
    /* JADX WARNING: Removed duplicated region for block: B:51:0x0086  */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x009c  */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String[] m4817b(java.lang.String r11, boolean r12) {
        /*
            if (r11 != 0) goto L_0x0004
            r11 = 0
            return r11
        L_0x0004:
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            char[] r1 = r11.toCharArray()
            int r11 = r11.length()
            r2 = 0
            r3 = 0
            r4 = 0
            r5 = 0
        L_0x0015:
            if (r3 >= r11) goto L_0x00d8
            int r6 = java.lang.Character.codePointAt(r1, r3)
            int r7 = java.lang.Character.charCount(r6)
            boolean r8 = java.lang.Character.isLetter(r6)
            r9 = 1
            if (r8 == 0) goto L_0x0083
            java.lang.Character$UnicodeBlock r8 = java.lang.Character.UnicodeBlock.of(r6)
            java.lang.Character$UnicodeBlock r10 = java.lang.Character.UnicodeBlock.BOPOMOFO
            if (r8 == r10) goto L_0x0065
            java.lang.Character$UnicodeBlock r10 = java.lang.Character.UnicodeBlock.BOPOMOFO_EXTENDED
            if (r8 == r10) goto L_0x0065
            java.lang.Character$UnicodeBlock r10 = java.lang.Character.UnicodeBlock.CJK_COMPATIBILITY
            if (r8 == r10) goto L_0x0065
            java.lang.Character$UnicodeBlock r10 = java.lang.Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS
            if (r8 == r10) goto L_0x0065
            java.lang.Character$UnicodeBlock r10 = java.lang.Character.UnicodeBlock.CJK_COMPATIBILITY_IDEOGRAPHS_SUPPLEMENT
            if (r8 == r10) goto L_0x0065
            java.lang.Character$UnicodeBlock r10 = java.lang.Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS
            if (r8 == r10) goto L_0x0065
            java.lang.Character$UnicodeBlock r10 = java.lang.Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_A
            if (r8 == r10) goto L_0x0065
            java.lang.Character$UnicodeBlock r10 = java.lang.Character.UnicodeBlock.CJK_UNIFIED_IDEOGRAPHS_EXTENSION_B
            if (r8 == r10) goto L_0x0065
            java.lang.Character$UnicodeBlock r10 = java.lang.Character.UnicodeBlock.ENCLOSED_CJK_LETTERS_AND_MONTHS
            if (r8 == r10) goto L_0x0065
            java.lang.Character$UnicodeBlock r10 = java.lang.Character.UnicodeBlock.HANGUL_JAMO
            if (r8 == r10) goto L_0x0065
            java.lang.Character$UnicodeBlock r10 = java.lang.Character.UnicodeBlock.HANGUL_SYLLABLES
            if (r8 == r10) goto L_0x0065
            java.lang.Character$UnicodeBlock r10 = java.lang.Character.UnicodeBlock.HIRAGANA
            if (r8 == r10) goto L_0x0065
            java.lang.Character$UnicodeBlock r10 = java.lang.Character.UnicodeBlock.KATAKANA
            if (r8 == r10) goto L_0x0065
            java.lang.Character$UnicodeBlock r10 = java.lang.Character.UnicodeBlock.KATAKANA_PHONETIC_EXTENSIONS
            if (r8 != r10) goto L_0x0063
            goto L_0x0065
        L_0x0063:
            r8 = 0
            goto L_0x0066
        L_0x0065:
            r8 = 1
        L_0x0066:
            if (r8 != 0) goto L_0x0081
            r8 = 65382(0xff66, float:9.162E-41)
            if (r6 < r8) goto L_0x0072
            r8 = 65437(0xff9d, float:9.1697E-41)
            if (r6 <= r8) goto L_0x007c
        L_0x0072:
            r8 = 65441(0xffa1, float:9.1702E-41)
            if (r6 < r8) goto L_0x007e
            r8 = 65500(0xffdc, float:9.1785E-41)
            if (r6 > r8) goto L_0x007e
        L_0x007c:
            r8 = 1
            goto L_0x007f
        L_0x007e:
            r8 = 0
        L_0x007f:
            if (r8 == 0) goto L_0x0083
        L_0x0081:
            r8 = 1
            goto L_0x0084
        L_0x0083:
            r8 = 0
        L_0x0084:
            if (r8 == 0) goto L_0x009c
            if (r4 == 0) goto L_0x0092
            java.lang.String r4 = new java.lang.String
            int r6 = r3 - r5
            r4.<init>(r1, r5, r6)
            r0.add(r4)
        L_0x0092:
            java.lang.String r4 = new java.lang.String
            r4.<init>(r1, r3, r7)
        L_0x0097:
            r0.add(r4)
            r4 = 0
            goto L_0x00d5
        L_0x009c:
            boolean r8 = java.lang.Character.isLetterOrDigit(r6)
            if (r8 != 0) goto L_0x00d1
            int r8 = java.lang.Character.getType(r6)
            r10 = 6
            if (r8 == r10) goto L_0x00d1
            int r8 = java.lang.Character.getType(r6)
            r10 = 8
            if (r8 != r10) goto L_0x00b2
            goto L_0x00d1
        L_0x00b2:
            if (r12 == 0) goto L_0x00c7
            int r8 = java.lang.Character.charCount(r6)
            if (r8 != r9) goto L_0x00c7
            char[] r6 = java.lang.Character.toChars(r6)
            char r6 = r6[r2]
            r8 = 39
            if (r6 != r8) goto L_0x00c7
            if (r4 != 0) goto L_0x00d4
            goto L_0x00d3
        L_0x00c7:
            if (r4 == 0) goto L_0x00d5
            java.lang.String r4 = new java.lang.String
            int r6 = r3 - r5
            r4.<init>(r1, r5, r6)
            goto L_0x0097
        L_0x00d1:
            if (r4 != 0) goto L_0x00d4
        L_0x00d3:
            r5 = r3
        L_0x00d4:
            r4 = 1
        L_0x00d5:
            int r3 = r3 + r7
            goto L_0x0015
        L_0x00d8:
            if (r4 == 0) goto L_0x00e3
            java.lang.String r11 = new java.lang.String
            int r3 = r3 - r5
            r11.<init>(r1, r5, r3)
            r0.add(r11)
        L_0x00e3:
            int r11 = r0.size()
            java.lang.String[] r11 = new java.lang.String[r11]
            java.lang.Object[] r11 = r0.toArray(r11)
            java.lang.String[] r11 = (java.lang.String[]) r11
            return r11
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0680fe.m4817b(java.lang.String, boolean):java.lang.String[]");
    }

    /* renamed from: b */
    public static JSONObject[] m4818b(JSONArray jSONArray) {
        JSONObject[] jSONObjectArr = new JSONObject[jSONArray.length()];
        for (int i = 0; i < jSONArray.length(); i++) {
            JSONObject optJSONObject = jSONArray.optJSONObject(i);
            if (optJSONObject == null) {
                optJSONObject = new JSONObject();
            }
            jSONObjectArr[i] = optJSONObject;
        }
        return jSONObjectArr;
    }

    /* renamed from: c */
    public static double m4819c(JSONObject jSONObject, String str) {
        return jSONObject.optDouble(str, 0.0d);
    }

    /* renamed from: c */
    public static int m4820c(int i, int i2) {
        if (i >= 0 && i <= i2) {
            return i;
        }
        throw new IndexOutOfBoundsException(m4701a(i, i2, "index"));
    }

    /* renamed from: c */
    public static int m4821c(byte[] bArr, int i, db2 db2) {
        int a = m4668a(bArr, i, db2);
        int i2 = db2.f3782a;
        if (i2 < 0) {
            throw zc2.m17012b();
        } else if (i2 == 0) {
            db2.f3784c = "";
            return a;
        } else {
            db2.f3784c = new String(bArr, a, i2, qc2.f13000a);
            return a + i2;
        }
    }

    /* renamed from: c */
    public static long m4822c(ByteBuffer byteBuffer) {
        long a = (m4671a(byteBuffer) << 32) + 0;
        if (a >= 0) {
            return m4671a(byteBuffer) + a;
        }
        throw new RuntimeException("I don't know how to deal with UInt64! long is not sufficient and I don't want to use BigInt");
    }

    /* renamed from: c */
    public static long m4823c(byte[] bArr, int i) {
        return ((((long) bArr[i + 7]) & 255) << 56) | (((long) bArr[i]) & 255) | ((((long) bArr[i + 1]) & 255) << 8) | ((((long) bArr[i + 2]) & 255) << 16) | ((((long) bArr[i + 3]) & 255) << 24) | ((((long) bArr[i + 4]) & 255) << 32) | ((((long) bArr[i + 5]) & 255) << 40) | ((((long) bArr[i + 6]) & 255) << 48);
    }

    /* renamed from: c */
    public static <T> T m4824c(T t) {
        if (t != null) {
            return t;
        }
        throw new NullPointerException();
    }

    /* renamed from: c */
    public static String m4826c(Parcel parcel, int i) {
        int l = m4885l(parcel, i);
        int dataPosition = parcel.dataPosition();
        if (l == 0) {
            return null;
        }
        String readString = parcel.readString();
        parcel.setDataPosition(dataPosition + l);
        return readString;
    }

    /* renamed from: c */
    public static <K, V> Map m4827c(int i) {
        return i <= 256 ? new C2399z4(i) : new HashMap(i, 1.0f);
    }

    /* renamed from: c */
    public static JSONObject m4828c(String str) {
        try {
            String sb = m4730a().mo11968i().mo11678a(str, false).toString();
            return m4721a(sb, "loadObject from filepath " + str);
        } catch (IOException e) {
            C0869hj.f6827i.mo6566a("IOException in ADCJSON's loadObject: " + e.toString());
            return new JSONObject();
        }
    }

    /* renamed from: c */
    public static void m4829c(Parcel parcel, int i, int i2) {
        if (i2 >= 65535) {
            parcel.writeInt(i | -65536);
            parcel.writeInt(i2);
            return;
        }
        parcel.writeInt(i | (i2 << 16));
    }

    /* renamed from: c */
    public static void m4830c(String str, Throwable th) {
        if (m4812b(6)) {
            Log.e("Ads", str, th);
        }
    }

    /* renamed from: c */
    public static void m4831c(boolean z) {
        if (!z) {
            throw new IllegalStateException();
        }
    }

    /* renamed from: c */
    public static void m4832c(boolean z, Object obj) {
        if (!z) {
            throw new IllegalStateException(String.valueOf(obj));
        }
    }

    /* renamed from: c */
    public static boolean m4833c() {
        return f5239b != null;
    }

    @TargetApi(21)
    /* renamed from: c */
    public static boolean m4834c(Context context) {
        if (f5243f == null) {
            f5243f = Boolean.valueOf(m4865f() && context.getPackageManager().hasSystemFeature("cn.google"));
        }
        return f5243f.booleanValue();
    }

    /* renamed from: c */
    public static boolean m4835c(Object obj, Object obj2) {
        if (obj != obj2) {
            return obj != null && obj.equals(obj2);
        }
        return true;
    }

    /* renamed from: d */
    public static double m4836d(ByteBuffer byteBuffer) {
        byte[] bArr = new byte[4];
        byteBuffer.get(bArr);
        double d = (double) (0 | ((bArr[0] << 24) & -16777216) | ((bArr[1] << 16) & 16711680) | ((bArr[2] << 8) & 65280) | (bArr[3] & 255));
        Double.isNaN(d);
        return d / 65536.0d;
    }

    /* renamed from: d */
    public static double m4837d(byte[] bArr, int i) {
        return Double.longBitsToDouble(m4823c(bArr, i));
    }

    /* renamed from: d */
    public static int m4838d(byte[] bArr, int i, db2 db2) {
        int a = m4668a(bArr, i, db2);
        int i2 = db2.f3782a;
        if (i2 < 0) {
            throw zc2.m17012b();
        } else if (i2 == 0) {
            db2.f3784c = "";
            return a;
        } else {
            db2.f3784c = of2.m10489b(bArr, a, i2);
            return a + i2;
        }
    }

    /* renamed from: d */
    public static JSONObject m4839d(JSONObject jSONObject, String str) {
        JSONObject optJSONObject = jSONObject.optJSONObject(str);
        return optJSONObject == null ? new JSONObject() : optJSONObject;
    }

    /* renamed from: d */
    public static C1770rq m4840d(Object obj) {
        return new C1770rq(obj, (C0554dr) null);
    }

    /* renamed from: d */
    public static void m4841d() {
        if (zq2.f18517a >= 18) {
            Trace.endSection();
        }
    }

    /* renamed from: d */
    public static void m4842d(Context context) {
        if (ef0.m4074a(context) && !ef0.m4077c()) {
            p22<?> b = new oc0(context).mo8352b();
            m4892o("Updating ad debug logging enablement.");
            m4767a(b, "AdDebugLogUpdater.updateEnablement");
        }
    }

    /* renamed from: d */
    public static void m4843d(String str) {
        if (!(Looper.getMainLooper() == Looper.myLooper())) {
            throw new IllegalStateException(str);
        }
    }

    /* renamed from: d */
    public static void m4844d(String str, Throwable th) {
        if (m4812b(5)) {
            Log.w("Ads", str, th);
        }
    }

    /* renamed from: d */
    public static void m4845d(boolean z) {
        if (!z) {
            throw new IllegalStateException();
        }
    }

    /* renamed from: d */
    public static boolean m4847d(Object obj, Object obj2) {
        if (obj != obj2) {
            return obj != null && obj.equals(obj2);
        }
        return true;
    }

    /* renamed from: d */
    public static String[] m4848d(Parcel parcel, int i) {
        int l = m4885l(parcel, i);
        int dataPosition = parcel.dataPosition();
        if (l == 0) {
            return null;
        }
        String[] createStringArray = parcel.createStringArray();
        parcel.setDataPosition(dataPosition + l);
        return createStringArray;
    }

    /* renamed from: e */
    public static double m4849e(ByteBuffer byteBuffer) {
        byte[] bArr = new byte[4];
        byteBuffer.get(bArr);
        double d = (double) (0 | ((bArr[0] << 24) & -16777216) | ((bArr[1] << 16) & 16711680) | ((bArr[2] << 8) & 65280) | (bArr[3] & 255));
        Double.isNaN(d);
        return d / 1.073741824E9d;
    }

    /* renamed from: e */
    public static float m4850e(byte[] bArr, int i) {
        return Float.intBitsToFloat(m4797b(bArr, i));
    }

    /* renamed from: e */
    public static int m4851e(int i) {
        return (int) (((long) Integer.rotateLeft((int) (((long) i) * -862048943), 15)) * 461845907);
    }

    /* renamed from: e */
    public static int m4852e(byte[] bArr, int i, db2 db2) {
        int a = m4668a(bArr, i, db2);
        int i2 = db2.f3782a;
        if (i2 < 0) {
            throw zc2.m17012b();
        } else if (i2 > bArr.length - a) {
            throw zc2.m17011a();
        } else if (i2 == 0) {
            db2.f3784c = hb2.f6691Y;
            return a;
        } else {
            db2.f3784c = hb2.m6130a(bArr, a, i2);
            return a + i2;
        }
    }

    /* renamed from: e */
    public static DynamiteModule m4853e(Context context) {
        try {
            return DynamiteModule.m2831a(context, DynamiteModule.f2969i, ModuleDescriptor.MODULE_ID);
        } catch (Exception e) {
            throw new kf0(e);
        }
    }

    /* renamed from: e */
    public static String m4854e(String str) {
        if (!TextUtils.isEmpty(str)) {
            return str;
        }
        throw new IllegalArgumentException("Given String is empty or null");
    }

    /* renamed from: e */
    public static ArrayList<String> m4855e(Parcel parcel, int i) {
        int l = m4885l(parcel, i);
        int dataPosition = parcel.dataPosition();
        if (l == 0) {
            return null;
        }
        ArrayList<String> createStringArrayList = parcel.createStringArrayList();
        parcel.setDataPosition(dataPosition + l);
        return createStringArrayList;
    }

    /* renamed from: e */
    public static <V> p22<V> m4856e(V v) {
        return v == null ? j22.f8064Y : new j22(v);
    }

    /* renamed from: e */
    public static void m4857e() {
        m4730a().mo11970k().mo9682c();
    }

    /* renamed from: e */
    public static void m4858e(Object obj, Object obj2) {
        if (obj == null) {
            String valueOf = String.valueOf(obj2);
            StringBuilder sb = new StringBuilder(valueOf.length() + 24);
            sb.append("null key in entry: null=");
            sb.append(valueOf);
            throw new NullPointerException(sb.toString());
        } else if (obj2 == null) {
            String valueOf2 = String.valueOf(obj);
            throw new NullPointerException(C0789gk.m5553a(valueOf2.length() + 26, "null value in entry: ", valueOf2, "=null"));
        }
    }

    /* renamed from: e */
    public static void m4859e(String str, Throwable th) {
        if (m4812b(5)) {
            String r = m4895r(str);
            if (th != null) {
                m4844d(r, th);
            } else {
                m4893p(r);
            }
        }
    }

    /* renamed from: e */
    public static boolean m4860e(JSONObject jSONObject, String str) {
        try {
            m4730a().mo11968i().mo11680a(str, jSONObject.toString(), false);
            return true;
        } catch (IOException e) {
            C0869hj.f6827i.mo6566a("IOException in ADCJSON's saveObject: " + e.toString());
            return false;
        }
    }

    /* renamed from: f */
    public static <T> List<T> m4861f(int i) {
        return i == 0 ? Collections.emptyList() : new ArrayList(i);
    }

    /* renamed from: f */
    public static vc1 m4862f(Context context) {
        vc1 vc1 = new vc1(context);
        m4698a(vc1, "Cannot return null from a non-@Nullable @Provides method");
        return vc1;
    }

    /* renamed from: f */
    public static void m4863f(Parcel parcel, int i) {
        if (parcel.dataPosition() != i) {
            throw new C1941tq(C0789gk.m5551a(37, "Overread allowed size end=", i), parcel);
        }
    }

    /* renamed from: f */
    public static void m4864f(String str) {
        if (Looper.getMainLooper() == Looper.myLooper()) {
            throw new IllegalStateException(str);
        }
    }

    /* renamed from: f */
    public static boolean m4865f() {
        return Build.VERSION.SDK_INT >= 21;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:53:0x00e9, code lost:
        if (r6.contains(r10) != false) goto L_0x0073;
     */
    /* renamed from: g */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String m4866g(android.content.Context r10) {
        /*
            java.lang.String r0 = f5248k
            if (r0 == 0) goto L_0x0005
            return r0
        L_0x0005:
            android.content.pm.PackageManager r0 = r10.getPackageManager()
            android.content.Intent r1 = new android.content.Intent
            java.lang.String r2 = "http://www.example.com"
            android.net.Uri r2 = android.net.Uri.parse(r2)
            java.lang.String r3 = "android.intent.action.VIEW"
            r1.<init>(r3, r2)
            r2 = 0
            android.content.pm.ResolveInfo r3 = r0.resolveActivity(r1, r2)
            r4 = 0
            if (r3 == 0) goto L_0x0023
            android.content.pm.ActivityInfo r3 = r3.activityInfo
            java.lang.String r3 = r3.packageName
            goto L_0x0024
        L_0x0023:
            r3 = r4
        L_0x0024:
            java.util.List r5 = r0.queryIntentActivities(r1, r2)
            java.util.ArrayList r6 = new java.util.ArrayList
            r6.<init>()
            java.util.Iterator r5 = r5.iterator()
        L_0x0031:
            boolean r7 = r5.hasNext()
            if (r7 == 0) goto L_0x005c
            java.lang.Object r7 = r5.next()
            android.content.pm.ResolveInfo r7 = (android.content.pm.ResolveInfo) r7
            android.content.Intent r8 = new android.content.Intent
            r8.<init>()
            java.lang.String r9 = "android.support.customtabs.action.CustomTabsService"
            r8.setAction(r9)
            android.content.pm.ActivityInfo r9 = r7.activityInfo
            java.lang.String r9 = r9.packageName
            r8.setPackage(r9)
            android.content.pm.ResolveInfo r8 = r0.resolveService(r8, r2)
            if (r8 == 0) goto L_0x0031
            android.content.pm.ActivityInfo r7 = r7.activityInfo
            java.lang.String r7 = r7.packageName
            r6.add(r7)
            goto L_0x0031
        L_0x005c:
            boolean r0 = r6.isEmpty()
            if (r0 == 0) goto L_0x0066
            f5248k = r4
            goto L_0x00ec
        L_0x0066:
            int r0 = r6.size()
            r4 = 1
            if (r0 != r4) goto L_0x0077
            java.lang.Object r10 = r6.get(r2)
            java.lang.String r10 = (java.lang.String) r10
        L_0x0073:
            f5248k = r10
            goto L_0x00ec
        L_0x0077:
            boolean r0 = android.text.TextUtils.isEmpty(r3)
            if (r0 != 0) goto L_0x00c8
            android.content.pm.PackageManager r10 = r10.getPackageManager()     // Catch:{ RuntimeException -> 0x00b6 }
            r0 = 64
            java.util.List r10 = r10.queryIntentActivities(r1, r0)     // Catch:{ RuntimeException -> 0x00b6 }
            if (r10 == 0) goto L_0x00bd
            int r0 = r10.size()     // Catch:{ RuntimeException -> 0x00b6 }
            if (r0 != 0) goto L_0x0090
            goto L_0x00bd
        L_0x0090:
            java.util.Iterator r10 = r10.iterator()     // Catch:{ RuntimeException -> 0x00b6 }
        L_0x0094:
            boolean r0 = r10.hasNext()     // Catch:{ RuntimeException -> 0x00b6 }
            if (r0 == 0) goto L_0x00bd
            java.lang.Object r0 = r10.next()     // Catch:{ RuntimeException -> 0x00b6 }
            android.content.pm.ResolveInfo r0 = (android.content.pm.ResolveInfo) r0     // Catch:{ RuntimeException -> 0x00b6 }
            android.content.IntentFilter r1 = r0.filter     // Catch:{ RuntimeException -> 0x00b6 }
            if (r1 == 0) goto L_0x0094
            int r5 = r1.countDataAuthorities()     // Catch:{ RuntimeException -> 0x00b6 }
            if (r5 == 0) goto L_0x0094
            int r1 = r1.countDataPaths()     // Catch:{ RuntimeException -> 0x00b6 }
            if (r1 == 0) goto L_0x0094
            android.content.pm.ActivityInfo r0 = r0.activityInfo     // Catch:{ RuntimeException -> 0x00b6 }
            if (r0 == 0) goto L_0x0094
            r2 = 1
            goto L_0x00bd
        L_0x00b6:
            java.lang.String r10 = "CustomTabsHelper"
            java.lang.String r0 = "Runtime exception while getting specialized handlers"
            android.util.Log.e(r10, r0)
        L_0x00bd:
            if (r2 != 0) goto L_0x00c8
            boolean r10 = r6.contains(r3)
            if (r10 == 0) goto L_0x00c8
            f5248k = r3
            goto L_0x00ec
        L_0x00c8:
            java.lang.String r10 = "com.android.chrome"
            boolean r0 = r6.contains(r10)
            if (r0 == 0) goto L_0x00d1
        L_0x00d0:
            goto L_0x0073
        L_0x00d1:
            java.lang.String r10 = "com.chrome.beta"
            boolean r0 = r6.contains(r10)
            if (r0 == 0) goto L_0x00da
            goto L_0x00d0
        L_0x00da:
            java.lang.String r10 = "com.chrome.dev"
            boolean r0 = r6.contains(r10)
            if (r0 == 0) goto L_0x00e3
            goto L_0x00d0
        L_0x00e3:
            java.lang.String r10 = "com.google.android.apps.chrome"
            boolean r0 = r6.contains(r10)
            if (r0 == 0) goto L_0x00ec
            goto L_0x00d0
        L_0x00ec:
            java.lang.String r10 = f5248k
            return r10
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0680fe.m4866g(android.content.Context):java.lang.String");
    }

    /* renamed from: g */
    public static <K, V> LinkedHashMap<K, V> m4867g(int i) {
        return new LinkedHashMap<>(m4872h(i));
    }

    /* renamed from: g */
    public static boolean m4868g() {
        return Build.VERSION.SDK_INT >= 26;
    }

    /* renamed from: g */
    public static boolean m4869g(Parcel parcel, int i) {
        m4804b(parcel, i, 4);
        return parcel.readInt() != 0;
    }

    /* renamed from: g */
    public static boolean m4870g(String str) {
        return "audio".equals(m4877i(str));
    }

    /* renamed from: h */
    public static float m4871h(Parcel parcel, int i) {
        m4804b(parcel, i, 4);
        return parcel.readFloat();
    }

    /* renamed from: h */
    public static int m4872h(int i) {
        if (i < 3) {
            return i + 1;
        }
        if (i < 1073741824) {
            return (int) ((((float) i) / 0.75f) + 1.0f);
        }
        return Integer.MAX_VALUE;
    }

    /* renamed from: h */
    public static boolean m4873h() {
        try {
            Class.forName("android.app.Application", false, (ClassLoader) null);
            return true;
        } catch (Exception unused) {
            return false;
        }
    }

    /* renamed from: h */
    public static boolean m4874h(Context context) {
        PackageManager packageManager = context.getPackageManager();
        if (packageManager == null) {
            return false;
        }
        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("http://www.example.com"));
        ResolveInfo resolveActivity = packageManager.resolveActivity(intent, 0);
        List<ResolveInfo> queryIntentActivities = packageManager.queryIntentActivities(intent, 65536);
        if (!(queryIntentActivities == null || resolveActivity == null)) {
            for (int i = 0; i < queryIntentActivities.size(); i++) {
                if (resolveActivity.activityInfo.name.equals(queryIntentActivities.get(i).activityInfo.name)) {
                    return resolveActivity.activityInfo.packageName.equals(m4866g(context));
                }
            }
        }
        return false;
    }

    /* renamed from: h */
    public static boolean m4875h(String str) {
        return "video".equals(m4877i(str));
    }

    /* renamed from: i */
    public static IBinder m4876i(Parcel parcel, int i) {
        int l = m4885l(parcel, i);
        int dataPosition = parcel.dataPosition();
        if (l == 0) {
            return null;
        }
        IBinder readStrongBinder = parcel.readStrongBinder();
        parcel.setDataPosition(dataPosition + l);
        return readStrongBinder;
    }

    /* renamed from: i */
    public static String m4877i(String str) {
        if (str == null) {
            return null;
        }
        int indexOf = str.indexOf(47);
        if (indexOf != -1) {
            return str.substring(0, indexOf);
        }
        throw new IllegalArgumentException(str.length() != 0 ? "Invalid mime type: ".concat(str) : new String("Invalid mime type: "));
    }

    /* renamed from: i */
    public static gv2[] m4878i() {
        if (f5249l == null) {
            synchronized (hg2.f6765a) {
                if (f5249l == null) {
                    f5249l = new gv2[0];
                }
            }
        }
        return f5249l;
    }

    /* renamed from: j */
    public static int m4879j(Parcel parcel, int i) {
        m4804b(parcel, i, 4);
        return parcel.readInt();
    }

    /* renamed from: j */
    public static int m4880j(String str) {
        byte[] bArr;
        try {
            bArr = str.getBytes("UTF-8");
        } catch (UnsupportedEncodingException unused) {
            bArr = str.getBytes();
        }
        int length = bArr.length;
        int i = 0;
        int i2 = (length & -4) + 0;
        int i3 = 0;
        for (int i4 = 0; i4 < i2; i4 += 4) {
            int i5 = ((bArr[i4] & 255) | ((bArr[i4 + 1] & 255) << 8) | ((bArr[i4 + 2] & 255) << 16) | (bArr[i4 + 3] << 24)) * -862048943;
            int i6 = i3 ^ (((i5 << 15) | (i5 >>> 17)) * 461845907);
            i3 = (((i6 >>> 19) | (i6 << 13)) * 5) - 430675100;
        }
        int i7 = length & 3;
        if (i7 != 1) {
            if (i7 != 2) {
                if (i7 == 3) {
                    i = (bArr[i2 + 2] & 255) << 16;
                }
                int i8 = i3 ^ length;
                int i9 = (i8 ^ (i8 >>> 16)) * -2048144789;
                int i10 = (i9 ^ (i9 >>> 13)) * -1028477387;
                return i10 ^ (i10 >>> 16);
            }
            i |= (bArr[i2 + 1] & 255) << 8;
        }
        int i11 = ((bArr[i2] & 255) | i) * -862048943;
        i3 ^= ((i11 >>> 17) | (i11 << 15)) * 461845907;
        int i82 = i3 ^ length;
        int i92 = (i82 ^ (i82 >>> 16)) * -2048144789;
        int i102 = (i92 ^ (i92 >>> 13)) * -1028477387;
        return i102 ^ (i102 >>> 16);
    }

    /* renamed from: j */
    public static SimpleDateFormat m4881j() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US);
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        return simpleDateFormat;
    }

    /* renamed from: k */
    public static long m4882k(Parcel parcel, int i) {
        m4804b(parcel, i, 8);
        return parcel.readLong();
    }

    /* renamed from: k */
    public static void m4883k(String str) {
        if (C1189ku.f9290a.mo11055a().booleanValue()) {
            m4886l(str);
        }
    }

    /* renamed from: k */
    public static boolean m4884k() {
        return m4812b(2) && C0880hu.f6996a.mo11055a().booleanValue();
    }

    /* renamed from: l */
    public static int m4885l(Parcel parcel, int i) {
        return (i & -65536) != -65536 ? (i >> 16) & 65535 : parcel.readInt();
    }

    /* renamed from: l */
    public static void m4886l(String str) {
        if (m4812b(3)) {
            Log.d("Ads", str);
        }
    }

    /* renamed from: m */
    public static void m4887m(Parcel parcel, int i) {
        parcel.setDataPosition(parcel.dataPosition() + m4885l(parcel, i));
    }

    /* renamed from: m */
    public static void m4888m(String str) {
        if (m4884k()) {
            Log.v("Ads", str);
        }
    }

    /* renamed from: n */
    public static int m4889n(Parcel parcel, int i) {
        parcel.writeInt(i | -65536);
        parcel.writeInt(0);
        return parcel.dataPosition();
    }

    /* renamed from: n */
    public static void m4890n(String str) {
        if (m4812b(6)) {
            Log.e("Ads", str);
        }
    }

    /* renamed from: o */
    public static void m4891o(Parcel parcel, int i) {
        int dataPosition = parcel.dataPosition();
        parcel.setDataPosition(i - 4);
        parcel.writeInt(dataPosition - i);
        parcel.setDataPosition(dataPosition);
    }

    /* renamed from: o */
    public static void m4892o(String str) {
        if (m4812b(4)) {
            Log.i("Ads", str);
        }
    }

    /* renamed from: p */
    public static void m4893p(String str) {
        if (m4812b(5)) {
            Log.w("Ads", str);
        }
    }

    /* renamed from: q */
    public static long m4894q(String str) {
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US);
            simpleDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
            return simpleDateFormat.parse(str).getTime();
        } catch (ParseException e) {
            Log.e("Volley", C2477zy.m17361d("Unable to parse dateStr: %s, falling back to 0", str), e);
            return 0;
        }
    }

    /* renamed from: r */
    public static String m4895r(String str) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        if (stackTrace.length < 4) {
            return str;
        }
        int lineNumber = stackTrace[3].getLineNumber();
        StringBuilder sb = new StringBuilder(C0789gk.m5548a(str, 13));
        sb.append(str);
        sb.append(" @");
        sb.append(lineNumber);
        return sb.toString();
    }

    /* renamed from: s */
    public static final String m4896s(String str) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < str.length(); i++) {
            char charAt = str.charAt(i);
            if (Character.isUpperCase(charAt)) {
                sb.append("_");
            }
            sb.append(Character.toLowerCase(charAt));
        }
        return sb.toString();
    }

    /* renamed from: t */
    public static String m4897t(String str) {
        StringBuffer stringBuffer = new StringBuffer();
        for (int i = 0; i < str.length(); i++) {
            char charAt = str.charAt(i);
            if (i != 0) {
                if (Character.isUpperCase(charAt)) {
                    stringBuffer.append('_');
                }
                stringBuffer.append(charAt);
            }
            charAt = Character.toLowerCase(charAt);
            stringBuffer.append(charAt);
        }
        return stringBuffer.toString();
    }

    /* renamed from: b */
    public static int m4795b(Parcel parcel) {
        int readInt = parcel.readInt();
        int l = m4885l(parcel, readInt);
        int dataPosition = parcel.dataPosition();
        if ((65535 & readInt) != 20293) {
            String valueOf = String.valueOf(Integer.toHexString(readInt));
            throw new C1941tq(valueOf.length() != 0 ? "Expected object header. Got 0x".concat(valueOf) : new String("Expected object header. Got 0x"), parcel);
        }
        int i = l + dataPosition;
        if (i >= dataPosition && i <= parcel.dataSize()) {
            return i;
        }
        throw new C1941tq(C0789gk.m5552a(54, "Size read is invalid start=", dataPosition, " end=", i), parcel);
    }

    /* renamed from: d */
    public static boolean m4846d(int i) {
        if (!((Boolean) kw2.f9317j.f9323f.mo4518a(g03.f5771i1)).booleanValue()) {
            return true;
        }
        return ((Boolean) kw2.f9317j.f9323f.mo4518a(g03.f5776j1)).booleanValue() || i <= 15299999;
    }

    /* renamed from: a */
    public static void m4739a(Context context, C1421nf nfVar, boolean z) {
        f5238a = context;
        f5241d = true;
        if (f5239b == null) {
            f5239b = new C2120vg();
            nfVar.mo9237a(context);
            f5239b.mo11955a(nfVar, z);
        } else {
            nfVar.mo9237a(context);
            f5239b.mo11954a(nfVar);
        }
        try {
            C1062ji.f8458a.execute(new C2216wf(context));
        } catch (RejectedExecutionException e) {
            StringBuilder sb = new StringBuilder();
            StringBuilder a = C0789gk.m5562a("ADC.configure queryAdvertisingId failed with error: ");
            a.append(e.toString());
            sb.append(a.toString());
            C0869hj.f6827i.mo6566a(sb.toString());
        }
        C0869hj.f6822d.mo6566a(C0789gk.m5562a("Configuring AdColony").toString());
        C2120vg vgVar = f5239b;
        vgVar.f16018B = false;
        vgVar.mo11974o().f10263e0 = true;
        f5239b.mo11974o().f10264f0 = true;
        f5239b.mo11974o().f10271m0 = false;
        C2120vg vgVar2 = f5239b;
        vgVar2.f16021E = true;
        vgVar2.mo11974o().mo8746c(false);
    }

    /* renamed from: c */
    public static <V> V m4825c(Future<V> future) {
        if (future != null) {
            try {
                return m4700a(future);
            } catch (ExecutionException e) {
                Throwable cause = e.getCause();
                if (cause instanceof Error) {
                    throw new y12((Error) cause);
                }
                throw new d32(cause);
            }
        } else {
            throw new NullPointerException();
        }
    }

    /* renamed from: a */
    public static void m4756a(String str, ContentValues contentValues, SQLiteDatabase sQLiteDatabase) {
        try {
            sQLiteDatabase.beginTransaction();
            sQLiteDatabase.insertOrThrow(str, (String) null, contentValues);
            sQLiteDatabase.setTransactionSuccessful();
        } catch (SQLException e) {
            StringBuilder sb = new StringBuilder();
            sb.append("Exception on insert to " + str + ", db version:");
            sb.append(sQLiteDatabase.getVersion());
            sb.append(". Values: " + contentValues.toString() + " caused: ");
            sb.append(e.toString());
            C0869hj.f6825g.mo6566a(sb.toString());
        } catch (Throwable th) {
            sQLiteDatabase.endTransaction();
            throw th;
        }
        sQLiteDatabase.endTransaction();
    }

    /* renamed from: a */
    public static boolean m4783a(JSONObject jSONObject, String str, double d) {
        try {
            jSONObject.put(str, d);
            return true;
        } catch (JSONException unused) {
            StringBuilder a = C0789gk.m5562a("JSON error in ADCJSON putDouble(): ");
            a.append(" with key: " + str);
            a.append(" and value: " + d);
            C0869hj.f6827i.mo6566a(a.toString());
            return false;
        }
    }

    /* renamed from: a */
    public static boolean m4785a(JSONObject jSONObject, String str, String str2) {
        try {
            jSONObject.put(str, str2);
            return true;
        } catch (JSONException e) {
            StringBuilder a = C0789gk.m5562a("JSON error in ADCJSON putString(): ");
            a.append(e.toString());
            a.append(" with key: " + str);
            a.append(" and value: " + str2);
            C0869hj.f6827i.mo6566a(a.toString());
            return false;
        }
    }

    /* renamed from: a */
    public static boolean m4786a(JSONObject jSONObject, String str, JSONArray jSONArray) {
        try {
            jSONObject.put(str, jSONArray);
            return true;
        } catch (JSONException e) {
            StringBuilder a = C0789gk.m5562a("JSON error in ADCJSON putArray(): ");
            a.append(e.toString());
            a.append(" with key: " + str);
            a.append(" and value: " + jSONArray);
            C0869hj.f6827i.mo6566a(a.toString());
            return false;
        }
    }

    /* renamed from: a */
    public static boolean m4787a(JSONObject jSONObject, String str, JSONObject jSONObject2) {
        try {
            jSONObject.put(str, jSONObject2);
            return true;
        } catch (JSONException e) {
            StringBuilder a = C0789gk.m5562a("JSON error in ADCJSON putObject(): ");
            a.append(e.toString());
            a.append(" with key: " + str);
            a.append(" and value: " + jSONObject2);
            C0869hj.f6827i.mo6566a(a.toString());
            return false;
        }
    }

    /* renamed from: a */
    public static String[] m4793a(JSONArray jSONArray) {
        String[] strArr = new String[jSONArray.length()];
        for (int i = 0; i < jSONArray.length(); i++) {
            strArr[i] = jSONArray.optString(i);
        }
        return strArr;
    }

    /* renamed from: a */
    public static boolean m4784a(JSONObject jSONObject, String str, int i) {
        try {
            jSONObject.put(str, i);
            return true;
        } catch (JSONException e) {
            StringBuilder a = C0789gk.m5562a("JSON error in ADCJSON putInteger(): ");
            a.append(e.toString());
            a.append(" with key: " + str);
            a.append(" and value: " + i);
            C0869hj.f6827i.mo6566a(a.toString());
            return false;
        }
    }

    /* renamed from: a */
    public static boolean m4788a(JSONObject jSONObject, String str, boolean z) {
        try {
            jSONObject.put(str, z);
            return true;
        } catch (JSONException e) {
            StringBuilder a = C0789gk.m5562a("JSON error in ADCJSON putBoolean(): ");
            a.append(e.toString());
            a.append(" with key: " + str);
            a.append(" and value: " + z);
            C0869hj.f6827i.mo6566a(a.toString());
            return false;
        }
    }

    /* renamed from: a */
    public static C2120vg m4730a() {
        if (!m4833c()) {
            Context context = f5238a;
            if (context == null) {
                return new C2120vg();
            }
            f5239b = new C2120vg();
            JSONObject c = m4828c(context.getFilesDir().getAbsolutePath() + "/adc3/AppInfo");
            JSONArray b = m4803b(c, "zoneIds");
            String optString = c.optString("appId");
            C1421nf nfVar = new C1421nf();
            nfVar.mo9233a(optString);
            nfVar.mo9235a(m4793a(b));
            f5239b.mo11955a(nfVar, false);
        }
        return f5239b;
    }

    /* JADX WARNING: Removed duplicated region for block: B:146:0x02f0  */
    /* JADX WARNING: Removed duplicated region for block: B:77:0x0187  */
    /* JADX WARNING: Removed duplicated region for block: B:80:0x0193  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static android.animation.Animator m4674a(android.content.Context r22, android.content.res.Resources r23, android.content.res.Resources.Theme r24, org.xmlpull.v1.XmlPullParser r25, android.util.AttributeSet r26, android.animation.AnimatorSet r27, int r28, float r29) {
        /*
            r8 = r23
            r9 = r24
            r10 = r25
            r11 = r27
            int r12 = r25.getDepth()
            r0 = 0
            r1 = 0
            r13 = r1
        L_0x000f:
            int r1 = r25.next()
            r2 = 3
            r14 = 0
            if (r1 != r2) goto L_0x001d
            int r3 = r25.getDepth()
            if (r3 <= r12) goto L_0x0317
        L_0x001d:
            r3 = 1
            if (r1 == r3) goto L_0x0317
            r4 = 2
            if (r1 == r4) goto L_0x0024
            goto L_0x000f
        L_0x0024:
            java.lang.String r1 = r25.getName()
            java.lang.String r5 = "objectAnimator"
            boolean r5 = r1.equals(r5)
            if (r5 == 0) goto L_0x0046
            android.animation.ObjectAnimator r7 = new android.animation.ObjectAnimator
            r7.<init>()
            r0 = r22
            r1 = r23
            r2 = r24
            r3 = r26
            r4 = r7
            r5 = r29
            r6 = r25
            m4678a((android.content.Context) r0, (android.content.res.Resources) r1, (android.content.res.Resources.Theme) r2, (android.util.AttributeSet) r3, (android.animation.ValueAnimator) r4, (float) r5, (org.xmlpull.v1.XmlPullParser) r6)
            goto L_0x005f
        L_0x0046:
            java.lang.String r5 = "animator"
            boolean r5 = r1.equals(r5)
            if (r5 == 0) goto L_0x0064
            r4 = 0
            r0 = r22
            r1 = r23
            r2 = r24
            r3 = r26
            r5 = r29
            r6 = r25
            android.animation.ValueAnimator r7 = m4678a((android.content.Context) r0, (android.content.res.Resources) r1, (android.content.res.Resources.Theme) r2, (android.util.AttributeSet) r3, (android.animation.ValueAnimator) r4, (float) r5, (org.xmlpull.v1.XmlPullParser) r6)
        L_0x005f:
            r0 = r7
            r19 = r12
            goto L_0x02ea
        L_0x0064:
            java.lang.String r5 = "set"
            boolean r5 = r1.equals(r5)
            if (r5 == 0) goto L_0x009b
            android.animation.AnimatorSet r15 = new android.animation.AnimatorSet
            r15.<init>()
            int[] r0 = p000.C1916te.f14849h
            r7 = r26
            android.content.res.TypedArray r6 = p000.C0815h0.m5783a((android.content.res.Resources) r8, (android.content.res.Resources.Theme) r9, (android.util.AttributeSet) r7, (int[]) r0)
            java.lang.String r0 = "ordering"
            int r16 = p000.C0815h0.m5835b(r6, r10, r0, r14, r14)
            r0 = r22
            r1 = r23
            r2 = r24
            r3 = r25
            r4 = r26
            r5 = r15
            r17 = r6
            r6 = r16
            r7 = r29
            m4674a(r0, r1, r2, r3, r4, r5, r6, r7)
            r17.recycle()
            r19 = r12
            r0 = r15
            goto L_0x02ea
        L_0x009b:
            java.lang.String r5 = "propertyValuesHolder"
            boolean r1 = r1.equals(r5)
            if (r1 == 0) goto L_0x0300
            android.util.AttributeSet r1 = android.util.Xml.asAttributeSet(r25)
            r6 = 0
        L_0x00a8:
            int r7 = r25.getEventType()
            if (r7 == r2) goto L_0x02c5
            if (r7 == r3) goto L_0x02c5
            if (r7 == r4) goto L_0x00b6
            r25.next()
            goto L_0x00a8
        L_0x00b6:
            java.lang.String r3 = r25.getName()
            boolean r3 = r3.equals(r5)
            if (r3 == 0) goto L_0x02ae
            int[] r3 = p000.C1916te.f14850i
            android.content.res.TypedArray r3 = p000.C0815h0.m5783a((android.content.res.Resources) r8, (android.content.res.Resources.Theme) r9, (android.util.AttributeSet) r1, (int[]) r3)
            java.lang.String r7 = "propertyName"
            java.lang.String r7 = p000.C0815h0.m5791a((android.content.res.TypedArray) r3, (org.xmlpull.v1.XmlPullParser) r10, (java.lang.String) r7, (int) r2)
            r14 = 4
            java.lang.String r15 = "valueType"
            int r4 = p000.C0815h0.m5835b(r3, r10, r15, r4, r14)
            r14 = 0
            r16 = r1
            r15 = r4
        L_0x00d7:
            int r1 = r25.next()
            if (r1 == r2) goto L_0x01b5
            r17 = r2
            r2 = 1
            if (r1 == r2) goto L_0x01b5
            java.lang.String r1 = r25.getName()
            java.lang.String r2 = "keyframe"
            boolean r1 = r1.equals(r2)
            if (r1 == 0) goto L_0x01ab
            java.lang.String r1 = "value"
            r2 = 4
            if (r15 != r2) goto L_0x0119
            android.util.AttributeSet r2 = android.util.Xml.asAttributeSet(r25)
            int[] r15 = p000.C1916te.f14851j
            android.content.res.TypedArray r2 = p000.C0815h0.m5783a((android.content.res.Resources) r8, (android.content.res.Resources.Theme) r9, (android.util.AttributeSet) r2, (int[]) r15)
            r15 = 0
            android.util.TypedValue r15 = p000.C0815h0.m5843b(r2, r10, r1, r15)
            if (r15 == 0) goto L_0x0107
            r17 = 1
            goto L_0x0109
        L_0x0107:
            r17 = 0
        L_0x0109:
            if (r17 == 0) goto L_0x0115
            int r15 = r15.type
            boolean r15 = m4777a((int) r15)
            if (r15 == 0) goto L_0x0115
            r15 = 3
            goto L_0x0116
        L_0x0115:
            r15 = 0
        L_0x0116:
            r2.recycle()
        L_0x0119:
            android.util.AttributeSet r2 = android.util.Xml.asAttributeSet(r25)
            r18 = r5
            int[] r5 = p000.C1916te.f14851j
            android.content.res.TypedArray r2 = p000.C0815h0.m5783a((android.content.res.Resources) r8, (android.content.res.Resources.Theme) r9, (android.util.AttributeSet) r2, (int[]) r5)
            r5 = -1082130432(0xffffffffbf800000, float:-1.0)
            java.lang.String r8 = "fraction"
            r9 = 3
            float r5 = p000.C0815h0.m5768a((android.content.res.TypedArray) r2, (org.xmlpull.v1.XmlPullParser) r10, (java.lang.String) r8, (int) r9, (float) r5)
            r8 = 0
            android.util.TypedValue r8 = p000.C0815h0.m5843b(r2, r10, r1, r8)
            if (r8 == 0) goto L_0x0137
            r9 = 1
            goto L_0x0138
        L_0x0137:
            r9 = 0
        L_0x0138:
            r19 = r12
            r12 = 4
            if (r15 != r12) goto L_0x014b
            if (r9 == 0) goto L_0x0149
            int r8 = r8.type
            boolean r8 = m4777a((int) r8)
            if (r8 == 0) goto L_0x0149
            r8 = 3
            goto L_0x014c
        L_0x0149:
            r8 = 0
            goto L_0x014c
        L_0x014b:
            r8 = r15
        L_0x014c:
            if (r9 == 0) goto L_0x016e
            if (r8 == 0) goto L_0x0163
            r9 = 1
            if (r8 == r9) goto L_0x0159
            r9 = 3
            if (r8 == r9) goto L_0x0159
            r1 = 0
            r5 = 0
            goto L_0x017b
        L_0x0159:
            r8 = 0
            int r1 = p000.C0815h0.m5835b(r2, r10, r1, r8, r8)
            android.animation.Keyframe r1 = android.animation.Keyframe.ofInt(r5, r1)
            goto L_0x017c
        L_0x0163:
            r8 = 0
            r9 = 0
            float r1 = p000.C0815h0.m5768a((android.content.res.TypedArray) r2, (org.xmlpull.v1.XmlPullParser) r10, (java.lang.String) r1, (int) r8, (float) r9)
            android.animation.Keyframe r1 = android.animation.Keyframe.ofFloat(r5, r1)
            goto L_0x017c
        L_0x016e:
            r1 = 0
            if (r8 != 0) goto L_0x0176
            android.animation.Keyframe r5 = android.animation.Keyframe.ofFloat(r5)
            goto L_0x017a
        L_0x0176:
            android.animation.Keyframe r5 = android.animation.Keyframe.ofInt(r5)
        L_0x017a:
            r1 = r5
        L_0x017b:
            r8 = 0
        L_0x017c:
            java.lang.String r5 = "interpolator"
            r9 = 1
            int r5 = p000.C0815h0.m5851c(r2, r10, r5, r9, r8)
            r8 = r22
            if (r5 <= 0) goto L_0x018e
            android.view.animation.Interpolator r5 = m4683a((android.content.Context) r8, (int) r5)
            r1.setInterpolator(r5)
        L_0x018e:
            r2.recycle()
            if (r1 == 0) goto L_0x019d
            if (r14 != 0) goto L_0x019a
            java.util.ArrayList r14 = new java.util.ArrayList
            r14.<init>()
        L_0x019a:
            r14.add(r1)
        L_0x019d:
            r25.next()
            r2 = 3
            r8 = r23
            r9 = r24
            r5 = r18
            r12 = r19
            goto L_0x00d7
        L_0x01ab:
            r8 = r22
            r8 = r23
            r9 = r24
            r2 = r17
            goto L_0x00d7
        L_0x01b5:
            r8 = r22
            r18 = r5
            r19 = r12
            if (r14 == 0) goto L_0x0292
            int r1 = r14.size()
            if (r1 <= 0) goto L_0x0292
            r2 = 0
            java.lang.Object r2 = r14.get(r2)
            android.animation.Keyframe r2 = (android.animation.Keyframe) r2
            int r5 = r1 + -1
            java.lang.Object r5 = r14.get(r5)
            android.animation.Keyframe r5 = (android.animation.Keyframe) r5
            float r9 = r5.getFraction()
            r12 = 1065353216(0x3f800000, float:1.0)
            int r17 = (r9 > r12 ? 1 : (r9 == r12 ? 0 : -1))
            if (r17 >= 0) goto L_0x01f3
            r17 = 0
            int r9 = (r9 > r17 ? 1 : (r9 == r17 ? 0 : -1))
            if (r9 >= 0) goto L_0x01e6
            r5.setFraction(r12)
            goto L_0x01f3
        L_0x01e6:
            int r9 = r14.size()
            android.animation.Keyframe r5 = m4676a((android.animation.Keyframe) r5, (float) r12)
            r14.add(r9, r5)
            int r1 = r1 + 1
        L_0x01f3:
            float r5 = r2.getFraction()
            r9 = 0
            int r12 = (r5 > r9 ? 1 : (r5 == r9 ? 0 : -1))
            if (r12 == 0) goto L_0x020e
            int r5 = (r5 > r9 ? 1 : (r5 == r9 ? 0 : -1))
            if (r5 >= 0) goto L_0x0204
            r2.setFraction(r9)
            goto L_0x020e
        L_0x0204:
            android.animation.Keyframe r2 = m4676a((android.animation.Keyframe) r2, (float) r9)
            r5 = 0
            r14.add(r5, r2)
            int r1 = r1 + 1
        L_0x020e:
            android.animation.Keyframe[] r2 = new android.animation.Keyframe[r1]
            r14.toArray(r2)
            r5 = 0
        L_0x0214:
            if (r5 >= r1) goto L_0x0283
            r9 = r2[r5]
            float r12 = r9.getFraction()
            r14 = 0
            int r12 = (r12 > r14 ? 1 : (r12 == r14 ? 0 : -1))
            if (r12 >= 0) goto L_0x027a
            if (r5 != 0) goto L_0x0224
            goto L_0x022a
        L_0x0224:
            int r12 = r1 + -1
            r14 = 1065353216(0x3f800000, float:1.0)
            if (r5 != r12) goto L_0x022e
        L_0x022a:
            r9.setFraction(r14)
            goto L_0x027a
        L_0x022e:
            int r9 = r5 + 1
            r14 = r5
        L_0x0231:
            if (r9 >= r12) goto L_0x0248
            r17 = r2[r9]
            float r17 = r17.getFraction()
            r20 = 0
            int r17 = (r17 > r20 ? 1 : (r17 == r20 ? 0 : -1))
            if (r17 < 0) goto L_0x0240
            goto L_0x0248
        L_0x0240:
            int r14 = r9 + 1
            r21 = r14
            r14 = r9
            r9 = r21
            goto L_0x0231
        L_0x0248:
            int r9 = r14 + 1
            r9 = r2[r9]
            float r9 = r9.getFraction()
            int r12 = r5 + -1
            r12 = r2[r12]
            float r12 = r12.getFraction()
            float r9 = r9 - r12
            int r12 = r14 - r5
            int r12 = r12 + 2
            float r12 = (float) r12
            float r9 = r9 / r12
            r12 = r5
        L_0x0260:
            if (r12 > r14) goto L_0x027a
            r17 = r1
            r1 = r2[r12]
            int r20 = r12 + -1
            r20 = r2[r20]
            float r20 = r20.getFraction()
            float r8 = r20 + r9
            r1.setFraction(r8)
            int r12 = r12 + 1
            r8 = r22
            r1 = r17
            goto L_0x0260
        L_0x027a:
            r17 = r1
            int r5 = r5 + 1
            r8 = r22
            r1 = r17
            goto L_0x0214
        L_0x0283:
            android.animation.PropertyValuesHolder r1 = android.animation.PropertyValuesHolder.ofKeyframe(r7, r2)
            r2 = 3
            if (r15 != r2) goto L_0x0294
            xe r5 = p000.C2268xe.m15698a()
            r1.setEvaluator(r5)
            goto L_0x0294
        L_0x0292:
            r2 = 3
            r1 = 0
        L_0x0294:
            r5 = 1
            r8 = 0
            if (r1 != 0) goto L_0x029c
            android.animation.PropertyValuesHolder r1 = m4677a((android.content.res.TypedArray) r3, (int) r4, (int) r8, (int) r5, (java.lang.String) r7)
        L_0x029c:
            if (r1 == 0) goto L_0x02a9
            if (r6 != 0) goto L_0x02a6
            java.util.ArrayList r4 = new java.util.ArrayList
            r4.<init>()
            r6 = r4
        L_0x02a6:
            r6.add(r1)
        L_0x02a9:
            r3.recycle()
            r14 = 0
            goto L_0x02b4
        L_0x02ae:
            r16 = r1
            r18 = r5
            r19 = r12
        L_0x02b4:
            r25.next()
            r3 = 1
            r4 = 2
            r8 = r23
            r9 = r24
            r1 = r16
            r5 = r18
            r12 = r19
            goto L_0x00a8
        L_0x02c5:
            r19 = r12
            if (r6 == 0) goto L_0x02dc
            int r1 = r6.size()
            android.animation.PropertyValuesHolder[] r2 = new android.animation.PropertyValuesHolder[r1]
        L_0x02cf:
            if (r14 >= r1) goto L_0x02dd
            java.lang.Object r3 = r6.get(r14)
            android.animation.PropertyValuesHolder r3 = (android.animation.PropertyValuesHolder) r3
            r2[r14] = r3
            int r14 = r14 + 1
            goto L_0x02cf
        L_0x02dc:
            r2 = 0
        L_0x02dd:
            if (r2 == 0) goto L_0x02e9
            boolean r1 = r0 instanceof android.animation.ValueAnimator
            if (r1 == 0) goto L_0x02e9
            r1 = r0
            android.animation.ValueAnimator r1 = (android.animation.ValueAnimator) r1
            r1.setValues(r2)
        L_0x02e9:
            r14 = 1
        L_0x02ea:
            if (r11 == 0) goto L_0x02f8
            if (r14 != 0) goto L_0x02f8
            if (r13 != 0) goto L_0x02f5
            java.util.ArrayList r13 = new java.util.ArrayList
            r13.<init>()
        L_0x02f5:
            r13.add(r0)
        L_0x02f8:
            r8 = r23
            r9 = r24
            r12 = r19
            goto L_0x000f
        L_0x0300:
            java.lang.RuntimeException r0 = new java.lang.RuntimeException
            java.lang.String r1 = "Unknown animator name: "
            java.lang.StringBuilder r1 = p000.C0789gk.m5562a((java.lang.String) r1)
            java.lang.String r2 = r25.getName()
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x0317:
            if (r11 == 0) goto L_0x0340
            if (r13 == 0) goto L_0x0340
            int r1 = r13.size()
            android.animation.Animator[] r1 = new android.animation.Animator[r1]
            java.util.Iterator r2 = r13.iterator()
        L_0x0325:
            boolean r3 = r2.hasNext()
            if (r3 == 0) goto L_0x0337
            java.lang.Object r3 = r2.next()
            android.animation.Animator r3 = (android.animation.Animator) r3
            int r4 = r14 + 1
            r1[r14] = r3
            r14 = r4
            goto L_0x0325
        L_0x0337:
            if (r28 != 0) goto L_0x033d
            r11.playTogether(r1)
            goto L_0x0340
        L_0x033d:
            r11.playSequentially(r1)
        L_0x0340:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0680fe.m4674a(android.content.Context, android.content.res.Resources, android.content.res.Resources$Theme, org.xmlpull.v1.XmlPullParser, android.util.AttributeSet, android.animation.AnimatorSet, int, float):android.animation.Animator");
    }

    /* renamed from: a */
    public static int m4662a(View view, int i) {
        return t53.m13071a(view.getContext(), i, view.getClass().getCanonicalName());
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r12v6, resolved type: java.lang.Object[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v29, resolved type: java.lang.Object[]} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v32, resolved type: java.lang.Object[]} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static android.animation.PropertyValuesHolder m4677a(android.content.res.TypedArray r11, int r12, int r13, int r14, java.lang.String r15) {
        /*
            android.util.TypedValue r0 = r11.peekValue(r13)
            r1 = 1
            r2 = 0
            if (r0 == 0) goto L_0x000a
            r3 = 1
            goto L_0x000b
        L_0x000a:
            r3 = 0
        L_0x000b:
            if (r3 == 0) goto L_0x0010
            int r0 = r0.type
            goto L_0x0011
        L_0x0010:
            r0 = 0
        L_0x0011:
            android.util.TypedValue r4 = r11.peekValue(r14)
            if (r4 == 0) goto L_0x0019
            r5 = 1
            goto L_0x001a
        L_0x0019:
            r5 = 0
        L_0x001a:
            if (r5 == 0) goto L_0x001f
            int r4 = r4.type
            goto L_0x0020
        L_0x001f:
            r4 = 0
        L_0x0020:
            r6 = 4
            r7 = 3
            if (r12 != r6) goto L_0x0037
            if (r3 == 0) goto L_0x002c
            boolean r12 = m4777a((int) r0)
            if (r12 != 0) goto L_0x0034
        L_0x002c:
            if (r5 == 0) goto L_0x0036
            boolean r12 = m4777a((int) r4)
            if (r12 == 0) goto L_0x0036
        L_0x0034:
            r12 = 3
            goto L_0x0037
        L_0x0036:
            r12 = 0
        L_0x0037:
            if (r12 != 0) goto L_0x003b
            r6 = 1
            goto L_0x003c
        L_0x003b:
            r6 = 0
        L_0x003c:
            r8 = 0
            r9 = 2
            if (r12 != r9) goto L_0x00a9
            java.lang.String r12 = r11.getString(r13)
            java.lang.String r11 = r11.getString(r14)
            f6[] r13 = p000.C0815h0.m5831a((java.lang.String) r12)
            f6[] r14 = p000.C0815h0.m5831a((java.lang.String) r11)
            if (r13 != 0) goto L_0x0054
            if (r14 == 0) goto L_0x0167
        L_0x0054:
            if (r13 == 0) goto L_0x0098
            we r0 = new we
            r0.<init>()
            if (r14 == 0) goto L_0x008d
            boolean r3 = p000.C0815h0.m5828a((p000.C0664f6[]) r13, (p000.C0664f6[]) r14)
            if (r3 == 0) goto L_0x006e
            java.lang.Object[] r11 = new java.lang.Object[r9]
            r11[r2] = r13
            r11[r1] = r14
            android.animation.PropertyValuesHolder r11 = android.animation.PropertyValuesHolder.ofObject(r15, r0, r11)
            goto L_0x0095
        L_0x006e:
            android.view.InflateException r13 = new android.view.InflateException
            java.lang.StringBuilder r14 = new java.lang.StringBuilder
            r14.<init>()
            java.lang.String r15 = " Can't morph from "
            r14.append(r15)
            r14.append(r12)
            java.lang.String r12 = " to "
            r14.append(r12)
            r14.append(r11)
            java.lang.String r11 = r14.toString()
            r13.<init>(r11)
            throw r13
        L_0x008d:
            java.lang.Object[] r11 = new java.lang.Object[r1]
            r11[r2] = r13
            android.animation.PropertyValuesHolder r11 = android.animation.PropertyValuesHolder.ofObject(r15, r0, r11)
        L_0x0095:
            r8 = r11
            goto L_0x0167
        L_0x0098:
            if (r14 == 0) goto L_0x0167
            we r11 = new we
            r11.<init>()
            java.lang.Object[] r12 = new java.lang.Object[r1]
            r12[r2] = r14
            android.animation.PropertyValuesHolder r8 = android.animation.PropertyValuesHolder.ofObject(r15, r11, r12)
            goto L_0x0167
        L_0x00a9:
            if (r12 != r7) goto L_0x00ae
            xe r12 = p000.C2268xe.f17137a
            goto L_0x00af
        L_0x00ae:
            r12 = r8
        L_0x00af:
            r7 = 5
            r10 = 0
            if (r6 == 0) goto L_0x00f8
            if (r3 == 0) goto L_0x00e3
            if (r0 != r7) goto L_0x00bc
            float r13 = r11.getDimension(r13, r10)
            goto L_0x00c0
        L_0x00bc:
            float r13 = r11.getFloat(r13, r10)
        L_0x00c0:
            if (r5 == 0) goto L_0x00d9
            if (r4 != r7) goto L_0x00c9
            float r11 = r11.getDimension(r14, r10)
            goto L_0x00cd
        L_0x00c9:
            float r11 = r11.getFloat(r14, r10)
        L_0x00cd:
            float[] r14 = new float[r9]
            r14[r2] = r13
            r14[r1] = r11
            android.animation.PropertyValuesHolder r11 = android.animation.PropertyValuesHolder.ofFloat(r15, r14)
            goto L_0x015f
        L_0x00d9:
            float[] r11 = new float[r1]
            r11[r2] = r13
            android.animation.PropertyValuesHolder r11 = android.animation.PropertyValuesHolder.ofFloat(r15, r11)
            goto L_0x015f
        L_0x00e3:
            if (r4 != r7) goto L_0x00ea
            float r11 = r11.getDimension(r14, r10)
            goto L_0x00ee
        L_0x00ea:
            float r11 = r11.getFloat(r14, r10)
        L_0x00ee:
            float[] r13 = new float[r1]
            r13[r2] = r11
            android.animation.PropertyValuesHolder r11 = android.animation.PropertyValuesHolder.ofFloat(r15, r13)
            goto L_0x015f
        L_0x00f8:
            if (r3 == 0) goto L_0x013e
            if (r0 != r7) goto L_0x0102
            float r13 = r11.getDimension(r13, r10)
            int r13 = (int) r13
            goto L_0x0111
        L_0x0102:
            boolean r0 = m4777a((int) r0)
            if (r0 == 0) goto L_0x010d
            int r13 = r11.getColor(r13, r2)
            goto L_0x0111
        L_0x010d:
            int r13 = r11.getInt(r13, r2)
        L_0x0111:
            if (r5 == 0) goto L_0x0135
            if (r4 != r7) goto L_0x011b
            float r11 = r11.getDimension(r14, r10)
            int r11 = (int) r11
            goto L_0x012a
        L_0x011b:
            boolean r0 = m4777a((int) r4)
            if (r0 == 0) goto L_0x0126
            int r11 = r11.getColor(r14, r2)
            goto L_0x012a
        L_0x0126:
            int r11 = r11.getInt(r14, r2)
        L_0x012a:
            int[] r14 = new int[r9]
            r14[r2] = r13
            r14[r1] = r11
            android.animation.PropertyValuesHolder r11 = android.animation.PropertyValuesHolder.ofInt(r15, r14)
            goto L_0x015f
        L_0x0135:
            int[] r11 = new int[r1]
            r11[r2] = r13
            android.animation.PropertyValuesHolder r11 = android.animation.PropertyValuesHolder.ofInt(r15, r11)
            goto L_0x015f
        L_0x013e:
            if (r5 == 0) goto L_0x0160
            if (r4 != r7) goto L_0x0148
            float r11 = r11.getDimension(r14, r10)
            int r11 = (int) r11
            goto L_0x0157
        L_0x0148:
            boolean r13 = m4777a((int) r4)
            if (r13 == 0) goto L_0x0153
            int r11 = r11.getColor(r14, r2)
            goto L_0x0157
        L_0x0153:
            int r11 = r11.getInt(r14, r2)
        L_0x0157:
            int[] r13 = new int[r1]
            r13[r2] = r11
            android.animation.PropertyValuesHolder r11 = android.animation.PropertyValuesHolder.ofInt(r15, r13)
        L_0x015f:
            r8 = r11
        L_0x0160:
            if (r8 == 0) goto L_0x0167
            if (r12 == 0) goto L_0x0167
            r8.setEvaluator(r12)
        L_0x0167:
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0680fe.m4677a(android.content.res.TypedArray, int, int, int, java.lang.String):android.animation.PropertyValuesHolder");
    }

    /* renamed from: a */
    public static int m4653a(int i, int i2, float f) {
        return C0588e6.m3951a(C0588e6.m3954b(i2, Math.round(((float) Color.alpha(i2)) * f)), i);
    }

    /* renamed from: a */
    public static ValueAnimator m4678a(Context context, Resources resources, Resources.Theme theme, AttributeSet attributeSet, ValueAnimator valueAnimator, float f, XmlPullParser xmlPullParser) {
        ValueAnimator valueAnimator2;
        int i;
        ValueAnimator valueAnimator3;
        PropertyValuesHolder propertyValuesHolder;
        Resources resources2 = resources;
        Resources.Theme theme2 = theme;
        AttributeSet attributeSet2 = attributeSet;
        XmlPullParser xmlPullParser2 = xmlPullParser;
        TypedArray a = C0815h0.m5783a(resources2, theme2, attributeSet2, C1916te.f14848g);
        TypedArray a2 = C0815h0.m5783a(resources2, theme2, attributeSet2, C1916te.f14852k);
        ValueAnimator valueAnimator4 = valueAnimator == null ? new ValueAnimator() : valueAnimator;
        long b = (long) C0815h0.m5835b(a, xmlPullParser2, "duration", 1, 300);
        int i2 = 0;
        long b2 = (long) C0815h0.m5835b(a, xmlPullParser2, "startOffset", 2, 0);
        int b3 = C0815h0.m5835b(a, xmlPullParser2, "valueType", 7, 4);
        if (C0815h0.m5827a(xmlPullParser2, "valueFrom") && C0815h0.m5827a(xmlPullParser2, "valueTo")) {
            if (b3 == 4) {
                TypedValue peekValue = a.peekValue(5);
                boolean z = peekValue != null;
                int i3 = z ? peekValue.type : 0;
                TypedValue peekValue2 = a.peekValue(6);
                boolean z2 = peekValue2 != null;
                b3 = ((!z || !m4777a(i3)) && (!z2 || !m4777a(z2 ? peekValue2.type : 0))) ? 0 : 3;
            }
            PropertyValuesHolder a3 = m4677a(a, b3, 5, 6, "");
            if (a3 != null) {
                valueAnimator4.setValues(new PropertyValuesHolder[]{a3});
            }
        }
        valueAnimator4.setDuration(b);
        valueAnimator4.setStartDelay(b2);
        valueAnimator4.setRepeatCount(C0815h0.m5835b(a, xmlPullParser2, "repeatCount", 3, 0));
        valueAnimator4.setRepeatMode(C0815h0.m5835b(a, xmlPullParser2, "repeatMode", 4, 1));
        if (a2 != null) {
            ObjectAnimator objectAnimator = (ObjectAnimator) valueAnimator4;
            String a4 = C0815h0.m5791a(a2, xmlPullParser2, "pathData", 1);
            if (a4 != null) {
                String a5 = C0815h0.m5791a(a2, xmlPullParser2, "propertyXName", 2);
                String a6 = C0815h0.m5791a(a2, xmlPullParser2, "propertyYName", 3);
                if (a5 == null && a6 == null) {
                    throw new InflateException(a2.getPositionDescription() + " propertyXName or propertyYName is needed for PathData");
                }
                Path b4 = C0815h0.m5841b(a4);
                float f2 = 0.5f * f;
                PathMeasure pathMeasure = new PathMeasure(b4, false);
                ArrayList arrayList = new ArrayList();
                arrayList.add(Float.valueOf(0.0f));
                float f3 = 0.0f;
                while (true) {
                    f3 += pathMeasure.getLength();
                    arrayList.add(Float.valueOf(f3));
                    if (!pathMeasure.nextContour()) {
                        break;
                    }
                }
                PathMeasure pathMeasure2 = new PathMeasure(b4, false);
                int min = Math.min(100, ((int) (f3 / f2)) + 1);
                float[] fArr = new float[min];
                float[] fArr2 = new float[min];
                float[] fArr3 = new float[2];
                float f4 = f3 / ((float) (min - 1));
                valueAnimator2 = valueAnimator4;
                int i4 = 0;
                float f5 = 0.0f;
                while (true) {
                    propertyValuesHolder = null;
                    if (i4 >= min) {
                        break;
                    }
                    int i5 = min;
                    pathMeasure2.getPosTan(f5 - ((Float) arrayList.get(i2)).floatValue(), fArr3, (float[]) null);
                    fArr[i4] = fArr3[0];
                    fArr2[i4] = fArr3[1];
                    f5 += f4;
                    int i6 = i2 + 1;
                    if (i6 < arrayList.size() && f5 > ((Float) arrayList.get(i6)).floatValue()) {
                        pathMeasure2.nextContour();
                        i2 = i6;
                    }
                    i4++;
                    min = i5;
                }
                PropertyValuesHolder ofFloat = a5 != null ? PropertyValuesHolder.ofFloat(a5, fArr) : null;
                if (a6 != null) {
                    propertyValuesHolder = PropertyValuesHolder.ofFloat(a6, fArr2);
                }
                if (ofFloat == null) {
                    i = 0;
                    objectAnimator.setValues(new PropertyValuesHolder[]{propertyValuesHolder});
                } else {
                    i = 0;
                    if (propertyValuesHolder == null) {
                        objectAnimator.setValues(new PropertyValuesHolder[]{ofFloat});
                    } else {
                        objectAnimator.setValues(new PropertyValuesHolder[]{ofFloat, propertyValuesHolder});
                    }
                }
            } else {
                valueAnimator2 = valueAnimator4;
                i = 0;
                objectAnimator.setPropertyName(C0815h0.m5791a(a2, xmlPullParser2, "propertyName", 0));
            }
        } else {
            valueAnimator2 = valueAnimator4;
            i = 0;
        }
        if (C0815h0.m5827a(xmlPullParser2, "interpolator")) {
            i = a.getResourceId(i, i);
        }
        if (i > 0) {
            valueAnimator3 = valueAnimator2;
            valueAnimator3.setInterpolator(m4683a(context, i));
        } else {
            valueAnimator3 = valueAnimator2;
        }
        a.recycle();
        if (a2 != null) {
            a2.recycle();
        }
        return valueAnimator3;
    }

    /* renamed from: a */
    public static <T extends Parcelable> void m4753a(Parcel parcel, int i, T[] tArr, int i2, boolean z) {
        if (tArr != null) {
            int n = m4889n(parcel, i);
            parcel.writeInt(r9);
            for (T t : tArr) {
                if (t == null) {
                    parcel.writeInt(0);
                } else {
                    int dataPosition = parcel.dataPosition();
                    parcel.writeInt(1);
                    int dataPosition2 = parcel.dataPosition();
                    t.writeToParcel(parcel, i2);
                    int dataPosition3 = parcel.dataPosition();
                    parcel.setDataPosition(dataPosition);
                    parcel.writeInt(dataPosition3 - dataPosition2);
                    parcel.setDataPosition(dataPosition3);
                }
            }
            m4891o(parcel, n);
        } else if (z) {
            m4829c(parcel, i, 0);
        }
    }

    @Deprecated
    /* renamed from: a */
    public static long m4670a(InputStream inputStream, OutputStream outputStream, boolean z) {
        byte[] bArr = new byte[1024];
        long j = 0;
        while (true) {
            try {
                int read = inputStream.read(bArr, 0, 1024);
                if (read == -1) {
                    break;
                }
                j += (long) read;
                outputStream.write(bArr, 0, read);
            } catch (Throwable th) {
                if (z) {
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        } catch (IOException unused) {
                        }
                    }
                    if (outputStream != null) {
                        try {
                            outputStream.close();
                        } catch (IOException unused2) {
                        }
                    }
                }
                throw th;
            }
        }
        if (z) {
            try {
                inputStream.close();
            } catch (IOException unused3) {
            }
            if (outputStream != null) {
                try {
                    outputStream.close();
                } catch (IOException unused4) {
                }
            }
        }
        return j;
    }

    /* renamed from: a */
    public static <V> p22<V> m4725a(p22<V> p22, long j, TimeUnit timeUnit, ScheduledExecutorService scheduledExecutorService) {
        if (p22.isDone()) {
            return p22;
        }
        y22 y22 = new y22(p22);
        a32 a32 = new a32(y22);
        y22.f17533f0 = scheduledExecutorService.schedule(a32, j, timeUnit);
        p22.mo4952a(a32, z12.f18124X);
        return y22;
    }

    /* JADX WARNING: Removed duplicated region for block: B:23:0x00c4  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x00e4  */
    /* JADX WARNING: Removed duplicated region for block: B:57:0x001e A[SYNTHETIC] */
    @java.lang.Deprecated
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static p000.n32 m4719a(p000.r32 r10) {
        /*
            r52 r0 = new r52
            r0.<init>()
            p000.a42.m200a(r0)
            java.lang.Class<n32> r0 = p000.n32.class
            p82 r1 = r10.f13390a
            p000.g42.m5283b(r1)
            x32 r1 = new x32
            r1.<init>(r0)
            p82 r2 = r10.f13390a
            java.util.List r2 = r2.mo9905k()
            java.util.Iterator r2 = r2.iterator()
        L_0x001e:
            boolean r3 = r2.hasNext()
            if (r3 == 0) goto L_0x0126
            java.lang.Object r3 = r2.next()
            p82$a r3 = (p000.p82.C1597a) r3
            j82 r4 = r3.mo9907j()
            j82 r5 = p000.j82.ENABLED
            if (r4 != r5) goto L_0x001e
            h82 r4 = r3.mo9910m()
            java.lang.String r4 = r4.mo6456j()
            h82 r5 = r3.mo9910m()
            hb2 r5 = r5.mo6457k()
            m32 r4 = p000.a42.m195a((java.lang.String) r4, r0)
            o32 r4 = (p000.o32) r4
            java.lang.Object r4 = r4.mo9486a((p000.hb2) r5)
            j82 r5 = r3.mo9907j()
            j82 r6 = p000.j82.ENABLED
            if (r5 != r6) goto L_0x011e
            w32 r5 = new w32
            int[] r6 = p000.l32.f9452a
            a92 r7 = r3.mo9908k()
            int r7 = r7.ordinal()
            r6 = r6[r7]
            r7 = 5
            r8 = 1
            if (r6 == r8) goto L_0x0083
            r9 = 2
            if (r6 == r9) goto L_0x0083
            r9 = 3
            if (r6 == r9) goto L_0x007a
            r7 = 4
            if (r6 != r7) goto L_0x0072
            byte[] r6 = p000.h32.f6569a
            goto L_0x0098
        L_0x0072:
            java.security.GeneralSecurityException r10 = new java.security.GeneralSecurityException
            java.lang.String r0 = "unknown output prefix type"
            r10.<init>(r0)
            throw r10
        L_0x007a:
            java.nio.ByteBuffer r6 = java.nio.ByteBuffer.allocate(r7)
            java.nio.ByteBuffer r6 = r6.put(r8)
            goto L_0x008c
        L_0x0083:
            java.nio.ByteBuffer r6 = java.nio.ByteBuffer.allocate(r7)
            r7 = 0
            java.nio.ByteBuffer r6 = r6.put(r7)
        L_0x008c:
            int r7 = r3.mo9911n()
            java.nio.ByteBuffer r6 = r6.putInt(r7)
            byte[] r6 = r6.array()
        L_0x0098:
            j82 r7 = r3.mo9907j()
            a92 r8 = r3.mo9908k()
            r5.<init>(r4, r6, r7, r8)
            java.util.ArrayList r4 = new java.util.ArrayList
            r4.<init>()
            r4.add(r5)
            java.lang.String r6 = new java.lang.String
            byte[] r7 = r5.mo12101a()
            java.nio.charset.Charset r8 = p000.x32.f16999d
            r6.<init>(r7, r8)
            java.util.concurrent.ConcurrentMap<java.lang.String, java.util.List<w32<P>>> r7 = r1.f17000a
            java.util.List r4 = java.util.Collections.unmodifiableList(r4)
            java.lang.Object r4 = r7.put(r6, r4)
            java.util.List r4 = (java.util.List) r4
            if (r4 == 0) goto L_0x00d8
            java.util.ArrayList r7 = new java.util.ArrayList
            r7.<init>()
            r7.addAll(r4)
            r7.add(r5)
            java.util.concurrent.ConcurrentMap<java.lang.String, java.util.List<w32<P>>> r4 = r1.f17000a
            java.util.List r7 = java.util.Collections.unmodifiableList(r7)
            r4.put(r6, r7)
        L_0x00d8:
            int r3 = r3.mo9911n()
            p82 r4 = r10.f13390a
            int r4 = r4.mo9904j()
            if (r3 != r4) goto L_0x001e
            j82 r3 = r5.f16526c
            j82 r4 = p000.j82.ENABLED
            if (r3 != r4) goto L_0x0116
            byte[] r3 = r5.mo12101a()
            java.util.concurrent.ConcurrentMap<java.lang.String, java.util.List<w32<P>>> r4 = r1.f17000a
            java.lang.String r6 = new java.lang.String
            java.nio.charset.Charset r7 = p000.x32.f16999d
            r6.<init>(r3, r7)
            java.lang.Object r3 = r4.get(r6)
            java.util.List r3 = (java.util.List) r3
            if (r3 == 0) goto L_0x0100
            goto L_0x0104
        L_0x0100:
            java.util.List r3 = java.util.Collections.emptyList()
        L_0x0104:
            boolean r3 = r3.isEmpty()
            if (r3 != 0) goto L_0x010e
            r1.f17001b = r5
            goto L_0x001e
        L_0x010e:
            java.lang.IllegalArgumentException r10 = new java.lang.IllegalArgumentException
            java.lang.String r0 = "the primary entry cannot be set to an entry which is not held by this primitive set"
            r10.<init>(r0)
            throw r10
        L_0x0116:
            java.lang.IllegalArgumentException r10 = new java.lang.IllegalArgumentException
            java.lang.String r0 = "the primary entry has to be ENABLED"
            r10.<init>(r0)
            throw r10
        L_0x011e:
            java.security.GeneralSecurityException r10 = new java.security.GeneralSecurityException
            java.lang.String r0 = "only ENABLED key is allowed"
            r10.<init>(r0)
            throw r10
        L_0x0126:
            java.util.concurrent.ConcurrentMap<java.lang.Class<?>, z32<?>> r10 = p000.a42.f174e
            java.lang.Class<P> r0 = r1.f17002c
            java.lang.Object r10 = r10.get(r0)
            z32 r10 = (p000.z32) r10
            if (r10 != 0) goto L_0x0151
            java.security.GeneralSecurityException r10 = new java.security.GeneralSecurityException
            java.lang.String r0 = "No wrapper found for "
            java.lang.Class<P> r1 = r1.f17002c
            java.lang.String r1 = r1.getName()
            int r2 = r1.length()
            if (r2 == 0) goto L_0x0147
            java.lang.String r0 = r0.concat(r1)
            goto L_0x014d
        L_0x0147:
            java.lang.String r1 = new java.lang.String
            r1.<init>(r0)
            r0 = r1
        L_0x014d:
            r10.<init>(r0)
            throw r10
        L_0x0151:
            java.lang.Object r10 = r10.mo5045a(r1)
            n32 r10 = (p000.n32) r10
            return r10
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0680fe.m4719a(r32):n32");
    }

    @Deprecated
    /* renamed from: a */
    public static <T> T m4693a(Context context, Callable<T> callable) {
        StrictMode.ThreadPolicy threadPolicy;
        try {
            threadPolicy = StrictMode.getThreadPolicy();
            StrictMode.setThreadPolicy(new StrictMode.ThreadPolicy.Builder(threadPolicy).permitDiskReads().permitDiskWrites().build());
            T call = callable.call();
            StrictMode.setThreadPolicy(threadPolicy);
            return call;
        } catch (Throwable th) {
            m4830c("Unexpected exception.", th);
            f70.m4533a(context).mo5463a(th, "StrictModeUtil.runWithLaxStrictMode");
            return null;
        }
    }

    /* renamed from: a */
    public static Set m4713a(cb1 cb1, Executor executor) {
        Set a = ta1.m13216a(cb1, executor);
        m4698a(a, "Cannot return null from a non-@Nullable @Provides method");
        return a;
    }

    /* renamed from: a */
    public static Executor m4714a(Executor executor, g12<?> g12) {
        if (executor == null) {
            throw new NullPointerException();
        } else if (g12 != null) {
            return executor == z12.f18124X ? executor : new q22(executor, g12);
        } else {
            throw new NullPointerException();
        }
    }

    /* renamed from: a */
    public static void m4770a(s00 s00, String str, Map map) {
        try {
            s00.mo6365a(str, C0619eo.f4708B.f4712c.mo12496a((Map<String, ?>) map));
        } catch (JSONException unused) {
            m4893p("Could not convert parameters to JSON.");
        }
    }

    /* renamed from: a */
    public static <V> void m4766a(p22<V> p22, f22<? super V> f22, Executor executor) {
        if (f22 != null) {
            p22.mo4952a(new g22(p22, f22), executor);
            return;
        }
        throw new NullPointerException();
    }

    /* JADX WARNING: Code restructure failed: missing block: B:77:0x01e6, code lost:
        if (((java.lang.Boolean) r11).booleanValue() == false) goto L_0x01e8;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:83:0x01f7, code lost:
        if (((java.lang.Integer) r11).intValue() == 0) goto L_0x01e8;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:87:0x0208, code lost:
        if (((java.lang.Float) r11).floatValue() == 0.0f) goto L_0x01e8;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:91:0x021a, code lost:
        if (((java.lang.Double) r11).doubleValue() == 0.0d) goto L_0x01e8;
     */
    /* JADX WARNING: Removed duplicated region for block: B:107:0x024c  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void m4772a(p000.zd2 r18, java.lang.StringBuilder r19, int r20) {
        /*
            r0 = r18
            r1 = r19
            r2 = r20
            java.util.HashMap r3 = new java.util.HashMap
            r3.<init>()
            java.util.HashMap r4 = new java.util.HashMap
            r4.<init>()
            java.util.TreeSet r5 = new java.util.TreeSet
            r5.<init>()
            java.lang.Class r6 = r18.getClass()
            java.lang.reflect.Method[] r6 = r6.getDeclaredMethods()
            int r7 = r6.length
            r8 = 0
            r9 = 0
        L_0x0020:
            java.lang.String r10 = "get"
            if (r9 >= r7) goto L_0x004f
            r11 = r6[r9]
            java.lang.String r12 = r11.getName()
            r4.put(r12, r11)
            java.lang.Class[] r12 = r11.getParameterTypes()
            int r12 = r12.length
            if (r12 != 0) goto L_0x004c
            java.lang.String r12 = r11.getName()
            r3.put(r12, r11)
            java.lang.String r12 = r11.getName()
            boolean r10 = r12.startsWith(r10)
            if (r10 == 0) goto L_0x004c
            java.lang.String r10 = r11.getName()
            r5.add(r10)
        L_0x004c:
            int r9 = r9 + 1
            goto L_0x0020
        L_0x004f:
            java.util.Iterator r5 = r5.iterator()
        L_0x0053:
            boolean r6 = r5.hasNext()
            if (r6 == 0) goto L_0x0266
            java.lang.Object r6 = r5.next()
            java.lang.String r6 = (java.lang.String) r6
            java.lang.String r7 = ""
            java.lang.String r9 = r6.replaceFirst(r10, r7)
            java.lang.String r11 = "List"
            boolean r12 = r9.endsWith(r11)
            r13 = 1
            if (r12 == 0) goto L_0x00c9
            java.lang.String r12 = "OrBuilderList"
            boolean r12 = r9.endsWith(r12)
            if (r12 != 0) goto L_0x00c9
            boolean r11 = r9.equals(r11)
            if (r11 != 0) goto L_0x00c9
            java.lang.String r11 = r9.substring(r8, r13)
            java.lang.String r11 = r11.toLowerCase()
            java.lang.String r11 = java.lang.String.valueOf(r11)
            int r12 = r9.length()
            int r12 = r12 + -4
            java.lang.String r12 = r9.substring(r13, r12)
            java.lang.String r12 = java.lang.String.valueOf(r12)
            int r14 = r12.length()
            if (r14 == 0) goto L_0x00a1
            java.lang.String r11 = r11.concat(r12)
            goto L_0x00a7
        L_0x00a1:
            java.lang.String r12 = new java.lang.String
            r12.<init>(r11)
            r11 = r12
        L_0x00a7:
            java.lang.Object r12 = r3.get(r6)
            java.lang.reflect.Method r12 = (java.lang.reflect.Method) r12
            if (r12 == 0) goto L_0x00c9
            java.lang.Class r14 = r12.getReturnType()
            java.lang.Class<java.util.List> r15 = java.util.List.class
            boolean r14 = r14.equals(r15)
            if (r14 == 0) goto L_0x00c9
            java.lang.String r6 = m4896s(r11)
            java.lang.Object[] r7 = new java.lang.Object[r8]
            java.lang.Object r7 = p000.oc2.m10396a((java.lang.reflect.Method) r12, (java.lang.Object) r0, (java.lang.Object[]) r7)
            m4760a((java.lang.StringBuilder) r1, (int) r2, (java.lang.String) r6, (java.lang.Object) r7)
            goto L_0x0053
        L_0x00c9:
            java.lang.String r11 = "Map"
            boolean r12 = r9.endsWith(r11)
            if (r12 == 0) goto L_0x0137
            boolean r11 = r9.equals(r11)
            if (r11 != 0) goto L_0x0137
            java.lang.String r11 = r9.substring(r8, r13)
            java.lang.String r11 = r11.toLowerCase()
            java.lang.String r11 = java.lang.String.valueOf(r11)
            int r12 = r9.length()
            int r12 = r12 + -3
            java.lang.String r12 = r9.substring(r13, r12)
            java.lang.String r12 = java.lang.String.valueOf(r12)
            int r14 = r12.length()
            if (r14 == 0) goto L_0x00fc
            java.lang.String r11 = r11.concat(r12)
            goto L_0x0102
        L_0x00fc:
            java.lang.String r12 = new java.lang.String
            r12.<init>(r11)
            r11 = r12
        L_0x0102:
            java.lang.Object r6 = r3.get(r6)
            java.lang.reflect.Method r6 = (java.lang.reflect.Method) r6
            if (r6 == 0) goto L_0x0137
            java.lang.Class r12 = r6.getReturnType()
            java.lang.Class<java.util.Map> r14 = java.util.Map.class
            boolean r12 = r12.equals(r14)
            if (r12 == 0) goto L_0x0137
            java.lang.Class<java.lang.Deprecated> r12 = java.lang.Deprecated.class
            boolean r12 = r6.isAnnotationPresent(r12)
            if (r12 != 0) goto L_0x0137
            int r12 = r6.getModifiers()
            boolean r12 = java.lang.reflect.Modifier.isPublic(r12)
            if (r12 == 0) goto L_0x0137
            java.lang.String r7 = m4896s(r11)
            java.lang.Object[] r9 = new java.lang.Object[r8]
            java.lang.Object r6 = p000.oc2.m10396a((java.lang.reflect.Method) r6, (java.lang.Object) r0, (java.lang.Object[]) r9)
            m4760a((java.lang.StringBuilder) r1, (int) r2, (java.lang.String) r7, (java.lang.Object) r6)
            goto L_0x0053
        L_0x0137:
            java.lang.String r6 = "set"
            int r11 = r9.length()
            if (r11 == 0) goto L_0x0144
            java.lang.String r6 = r6.concat(r9)
            goto L_0x014a
        L_0x0144:
            java.lang.String r11 = new java.lang.String
            r11.<init>(r6)
            r6 = r11
        L_0x014a:
            java.lang.Object r6 = r4.get(r6)
            java.lang.reflect.Method r6 = (java.lang.reflect.Method) r6
            if (r6 == 0) goto L_0x0053
            java.lang.String r6 = "Bytes"
            boolean r6 = r9.endsWith(r6)
            if (r6 == 0) goto L_0x017e
            int r6 = r9.length()
            int r6 = r6 + -5
            java.lang.String r6 = r9.substring(r8, r6)
            java.lang.String r6 = java.lang.String.valueOf(r6)
            int r11 = r6.length()
            if (r11 == 0) goto L_0x0173
            java.lang.String r6 = r10.concat(r6)
            goto L_0x0178
        L_0x0173:
            java.lang.String r6 = new java.lang.String
            r6.<init>(r10)
        L_0x0178:
            boolean r6 = r3.containsKey(r6)
            if (r6 != 0) goto L_0x0053
        L_0x017e:
            java.lang.String r6 = r9.substring(r8, r13)
            java.lang.String r6 = r6.toLowerCase()
            java.lang.String r6 = java.lang.String.valueOf(r6)
            java.lang.String r11 = r9.substring(r13)
            java.lang.String r11 = java.lang.String.valueOf(r11)
            int r12 = r11.length()
            if (r12 == 0) goto L_0x019d
            java.lang.String r6 = r6.concat(r11)
            goto L_0x01a3
        L_0x019d:
            java.lang.String r11 = new java.lang.String
            r11.<init>(r6)
            r6 = r11
        L_0x01a3:
            int r11 = r9.length()
            if (r11 == 0) goto L_0x01ae
            java.lang.String r11 = r10.concat(r9)
            goto L_0x01b3
        L_0x01ae:
            java.lang.String r11 = new java.lang.String
            r11.<init>(r10)
        L_0x01b3:
            java.lang.Object r11 = r3.get(r11)
            java.lang.reflect.Method r11 = (java.lang.reflect.Method) r11
            java.lang.String r12 = "has"
            int r14 = r9.length()
            if (r14 == 0) goto L_0x01c6
            java.lang.String r9 = r12.concat(r9)
            goto L_0x01cb
        L_0x01c6:
            java.lang.String r9 = new java.lang.String
            r9.<init>(r12)
        L_0x01cb:
            java.lang.Object r9 = r3.get(r9)
            java.lang.reflect.Method r9 = (java.lang.reflect.Method) r9
            if (r11 == 0) goto L_0x0053
            java.lang.Object[] r12 = new java.lang.Object[r8]
            java.lang.Object r11 = p000.oc2.m10396a((java.lang.reflect.Method) r11, (java.lang.Object) r0, (java.lang.Object[]) r12)
            if (r9 != 0) goto L_0x024e
            boolean r9 = r11 instanceof java.lang.Boolean
            if (r9 == 0) goto L_0x01ec
            r7 = r11
            java.lang.Boolean r7 = (java.lang.Boolean) r7
            boolean r7 = r7.booleanValue()
            if (r7 != 0) goto L_0x01ea
        L_0x01e8:
            r7 = 1
            goto L_0x0249
        L_0x01ea:
            r7 = 0
            goto L_0x0249
        L_0x01ec:
            boolean r9 = r11 instanceof java.lang.Integer
            if (r9 == 0) goto L_0x01fa
            r7 = r11
            java.lang.Integer r7 = (java.lang.Integer) r7
            int r7 = r7.intValue()
            if (r7 != 0) goto L_0x01ea
            goto L_0x01e8
        L_0x01fa:
            boolean r9 = r11 instanceof java.lang.Float
            if (r9 == 0) goto L_0x020b
            r7 = r11
            java.lang.Float r7 = (java.lang.Float) r7
            float r7 = r7.floatValue()
            r9 = 0
            int r7 = (r7 > r9 ? 1 : (r7 == r9 ? 0 : -1))
            if (r7 != 0) goto L_0x01ea
            goto L_0x01e8
        L_0x020b:
            boolean r9 = r11 instanceof java.lang.Double
            if (r9 == 0) goto L_0x021d
            r7 = r11
            java.lang.Double r7 = (java.lang.Double) r7
            double r14 = r7.doubleValue()
            r16 = 0
            int r7 = (r14 > r16 ? 1 : (r14 == r16 ? 0 : -1))
            if (r7 != 0) goto L_0x01ea
            goto L_0x01e8
        L_0x021d:
            boolean r9 = r11 instanceof java.lang.String
            if (r9 == 0) goto L_0x0226
        L_0x0221:
            boolean r7 = r11.equals(r7)
            goto L_0x0249
        L_0x0226:
            boolean r7 = r11 instanceof p000.hb2
            if (r7 == 0) goto L_0x022d
            hb2 r7 = p000.hb2.f6691Y
            goto L_0x0221
        L_0x022d:
            boolean r7 = r11 instanceof p000.zd2
            if (r7 == 0) goto L_0x023b
            r7 = r11
            zd2 r7 = (p000.zd2) r7
            zd2 r7 = r7.mo411a()
            if (r11 != r7) goto L_0x01ea
            goto L_0x01e8
        L_0x023b:
            boolean r7 = r11 instanceof java.lang.Enum
            if (r7 == 0) goto L_0x01ea
            r7 = r11
            java.lang.Enum r7 = (java.lang.Enum) r7
            int r7 = r7.ordinal()
            if (r7 != 0) goto L_0x01ea
            goto L_0x01e8
        L_0x0249:
            if (r7 != 0) goto L_0x024c
            goto L_0x025b
        L_0x024c:
            r13 = 0
            goto L_0x025b
        L_0x024e:
            java.lang.Object[] r7 = new java.lang.Object[r8]
            java.lang.Object r7 = p000.oc2.m10396a((java.lang.reflect.Method) r9, (java.lang.Object) r0, (java.lang.Object[]) r7)
            java.lang.Boolean r7 = (java.lang.Boolean) r7
            boolean r7 = r7.booleanValue()
            r13 = r7
        L_0x025b:
            if (r13 == 0) goto L_0x0053
            java.lang.String r6 = m4896s(r6)
            m4760a((java.lang.StringBuilder) r1, (int) r2, (java.lang.String) r6, (java.lang.Object) r11)
            goto L_0x0053
        L_0x0266:
            boolean r3 = r0 instanceof p000.oc2.C1520d
            if (r3 == 0) goto L_0x028c
            r3 = r0
            oc2$d r3 = (p000.oc2.C1520d) r3
            hc2<oc2$c> r3 = r3.zzhmr
            java.util.Iterator r3 = r3.mo6512b()
            boolean r4 = r3.hasNext()
            if (r4 != 0) goto L_0x027a
            goto L_0x028c
        L_0x027a:
            java.lang.Object r0 = r3.next()
            java.util.Map$Entry r0 = (java.util.Map.Entry) r0
            java.lang.Object r0 = r0.getKey()
            oc2$c r0 = (p000.oc2.C1519c) r0
            java.lang.NoSuchMethodError r0 = new java.lang.NoSuchMethodError
            r0.<init>()
            throw r0
        L_0x028c:
            oc2 r0 = (p000.oc2) r0
            ff2 r0 = r0.zzhmk
            if (r0 == 0) goto L_0x02aa
        L_0x0292:
            int r3 = r0.f5328a
            if (r8 >= r3) goto L_0x02aa
            int[] r3 = r0.f5329b
            r3 = r3[r8]
            int r3 = r3 >>> 3
            java.lang.String r3 = java.lang.String.valueOf(r3)
            java.lang.Object[] r4 = r0.f5330c
            r4 = r4[r8]
            m4760a((java.lang.StringBuilder) r1, (int) r2, (java.lang.String) r3, (java.lang.Object) r4)
            int r8 = r8 + 1
            goto L_0x0292
        L_0x02aa:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0680fe.m4772a(zd2, java.lang.StringBuilder, int):void");
    }

    /* renamed from: a */
    public static boolean m4781a(C1271lt ltVar, C1095jt jtVar, String... strArr) {
        if (ltVar == null || jtVar == null || !ltVar.f9803a) {
            return false;
        }
        ltVar.mo8486a(jtVar, ((C0877hr) C0619eo.f4708B.f4719j).mo6697b(), strArr);
        return true;
    }

    /* JADX WARNING: Removed duplicated region for block: B:14:0x0019 A[SYNTHETIC, Splitter:B:14:0x0019] */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x001f A[SYNTHETIC, Splitter:B:20:0x001f] */
    /* JADX WARNING: Removed duplicated region for block: B:27:? A[RETURN, SYNTHETIC] */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static boolean m4780a(java.io.File r2, byte[] r3) {
        /*
            r0 = 0
            java.io.FileOutputStream r1 = new java.io.FileOutputStream     // Catch:{ IOException -> 0x001d, all -> 0x0016 }
            r1.<init>(r2)     // Catch:{ IOException -> 0x001d, all -> 0x0016 }
            r1.write(r3)     // Catch:{ IOException -> 0x0014, all -> 0x0011 }
            r1.flush()     // Catch:{ IOException -> 0x0014, all -> 0x0011 }
            r1.close()     // Catch:{ IOException -> 0x000f }
        L_0x000f:
            r2 = 1
            return r2
        L_0x0011:
            r2 = move-exception
            r0 = r1
            goto L_0x0017
        L_0x0014:
            r0 = r1
            goto L_0x001d
        L_0x0016:
            r2 = move-exception
        L_0x0017:
            if (r0 == 0) goto L_0x001c
            r0.close()     // Catch:{ IOException -> 0x001c }
        L_0x001c:
            throw r2
        L_0x001d:
            if (r0 == 0) goto L_0x0022
            r0.close()     // Catch:{ IOException -> 0x0022 }
        L_0x0022:
            r2 = 0
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0680fe.m4780a(java.io.File, byte[]):boolean");
    }

    /* renamed from: a */
    public static C1095jt m4715a(C1271lt ltVar) {
        if (ltVar == null) {
            return null;
        }
        return ltVar.mo8483a(((C0877hr) C0619eo.f4708B.f4719j).mo6697b());
    }

    /* renamed from: a */
    public static String m4703a(String str, Context context, boolean z) {
        String e;
        if ((((Boolean) kw2.f9317j.f9323f.mo4518a(g03.f5735b0)).booleanValue() && !z) || !C0619eo.f4708B.f4733x.mo334c(context) || TextUtils.isEmpty(str) || (e = C0619eo.f4708B.f4733x.mo336e(context)) == null) {
            return str;
        }
        if (((Boolean) kw2.f9317j.f9323f.mo4518a(g03.f5701T)).booleanValue()) {
            String str2 = (String) kw2.f9317j.f9323f.mo4518a(g03.f5705U);
            if (!str.contains(str2)) {
                return str;
            }
            if (xc0.m15640a(str, C0619eo.f4708B.f4712c.f17111a, (String) kw2.f9317j.f9323f.mo4518a(g03.f5693R))) {
                C0619eo.f4708B.f4733x.mo325a(context, "_ac", e, (Bundle) null);
                return str.replace(str2, e);
            }
            if (!xc0.m15640a(str, C0619eo.f4708B.f4712c.f17112b, (String) kw2.f9317j.f9323f.mo4518a(g03.f5697S))) {
                return str;
            }
            C0619eo.f4708B.f4733x.mo325a(context, "_ai", e, (Bundle) null);
            return str.replace(str2, e);
        } else if (str.contains("fbs_aeid")) {
            return str;
        } else {
            if (xc0.m15640a(str, C0619eo.f4708B.f4712c.f17111a, (String) kw2.f9317j.f9323f.mo4518a(g03.f5693R))) {
                C0619eo.f4708B.f4733x.mo325a(context, "_ac", e, (Bundle) null);
            } else {
                if (!xc0.m15640a(str, C0619eo.f4708B.f4712c.f17112b, (String) kw2.f9317j.f9323f.mo4518a(g03.f5697S))) {
                    return str;
                }
                C0619eo.f4708B.f4733x.mo325a(context, "_ai", e, (Bundle) null);
            }
            return m4679a(str, "fbs_aeid", e).toString();
        }
    }

    /* renamed from: a */
    public static String m4704a(String str, Object... objArr) {
        int indexOf;
        String str2;
        String valueOf = String.valueOf(str);
        int i = 0;
        for (int i2 = 0; i2 < objArr.length; i2++) {
            Object obj = objArr[i2];
            try {
                str2 = String.valueOf(obj);
            } catch (Exception e) {
                String name = obj.getClass().getName();
                String hexString = Integer.toHexString(System.identityHashCode(obj));
                StringBuilder sb = new StringBuilder(C0789gk.m5548a(hexString, name.length() + 1));
                sb.append(name);
                sb.append('@');
                sb.append(hexString);
                String sb2 = sb.toString();
                Logger logger = Logger.getLogger("com.google.common.base.Strings");
                Level level = Level.WARNING;
                String valueOf2 = String.valueOf(sb2);
                logger.logp(level, "com.google.common.base.Strings", "lenientToString", valueOf2.length() != 0 ? "Exception during lenientFormat for ".concat(valueOf2) : new String("Exception during lenientFormat for "), e);
                String name2 = e.getClass().getName();
                StringBuilder a = C0789gk.m5561a(name2.length() + C0789gk.m5548a(sb2, 9), "<", sb2, " threw ", name2);
                a.append(">");
                str2 = a.toString();
            }
            objArr[i2] = str2;
        }
        StringBuilder sb3 = new StringBuilder((objArr.length * 16) + valueOf.length());
        int i3 = 0;
        while (i < objArr.length && (indexOf = valueOf.indexOf("%s", i3)) != -1) {
            sb3.append(valueOf, i3, indexOf);
            sb3.append(objArr[i]);
            i3 = indexOf + 2;
            i++;
        }
        sb3.append(valueOf, i3, valueOf.length());
        if (i < objArr.length) {
            sb3.append(" [");
            sb3.append(objArr[i]);
            for (int i4 = i + 1; i4 < objArr.length; i4++) {
                sb3.append(", ");
                sb3.append(objArr[i4]);
            }
            sb3.append(']');
        }
        return sb3.toString();
    }

    /* renamed from: a */
    public static /* synthetic */ void m4733a(byte b, byte b2, byte b3, byte b4, char[] cArr, int i) {
        if (!m4776a(b2)) {
            if ((((b2 + 112) + (b << 28)) >> 30) == 0 && !m4776a(b3) && !m4776a(b4)) {
                byte b5 = ((b & 7) << 18) | ((b2 & 63) << 12) | ((b3 & 63) << 6) | (b4 & 63);
                cArr[i] = (char) ((b5 >>> 10) + 55232);
                cArr[i + 1] = (char) ((b5 & 1023) + 56320);
                return;
            }
        }
        throw zc2.m17018h();
    }

    /* renamed from: a */
    public static /* synthetic */ void m4734a(byte b, byte b2, byte b3, char[] cArr, int i) {
        if (m4776a(b2) || ((b == -32 && b2 < -96) || ((b == -19 && b2 >= -96) || m4776a(b3)))) {
            throw zc2.m17018h();
        }
        cArr[i] = (char) (((b & 15) << 12) | ((b2 & 63) << 6) | (b3 & 63));
    }

    /* renamed from: a */
    public static /* synthetic */ void m4735a(byte b, byte b2, char[] cArr, int i) {
        if (b < -62 || m4776a(b2)) {
            throw zc2.m17018h();
        }
        cArr[i] = (char) (((b & 31) << 6) | (b2 & 63));
    }

    /* renamed from: a */
    public static String m4702a(hb2 hb2) {
        String str;
        df2 df2 = new df2(hb2);
        StringBuilder sb = new StringBuilder(df2.f3831a.size());
        for (int i = 0; i < df2.f3831a.size(); i++) {
            int c = df2.f3831a.mo6489c(i);
            if (c == 34) {
                str = "\\\"";
            } else if (c == 39) {
                str = "\\'";
            } else if (c != 92) {
                switch (c) {
                    case 7:
                        str = "\\a";
                        break;
                    case 8:
                        str = "\\b";
                        break;
                    case 9:
                        str = "\\t";
                        break;
                    case 10:
                        str = "\\n";
                        break;
                    case 11:
                        str = "\\v";
                        break;
                    case 12:
                        str = "\\f";
                        break;
                    case 13:
                        str = "\\r";
                        break;
                    default:
                        if (c < 32 || c > 126) {
                            sb.append('\\');
                            sb.append((char) (((c >>> 6) & 3) + 48));
                            sb.append((char) (((c >>> 3) & 7) + 48));
                            c = (c & 7) + 48;
                        }
                        sb.append((char) c);
                        continue;
                }
            } else {
                str = "\\\\";
            }
            sb.append(str);
        }
        return sb.toString();
    }

    /* renamed from: a */
    public static void m4761a(Throwable th, String str) {
        int a = qb1.m11598a(th);
        StringBuilder sb = new StringBuilder(31);
        sb.append("Ad failed to load : ");
        sb.append(a);
        m4892o(sb.toString());
        m4758a(str, th);
        if (qb1.m11598a(th) != 3) {
            C0619eo.f4708B.f4716g.mo4731b(th, str);
        }
    }

    /* renamed from: a */
    public static void m4740a(Context context, boolean z) {
        String str;
        if (z) {
            str = "This request is sent from a test device.";
        } else {
            af0 af0 = kw2.f9317j.f9318a;
            String a = af0.m468a(context);
            str = C0789gk.m5553a(C0789gk.m5548a(a, 71), "Use AdRequest.Builder.addTestDevice(\"", a, "\") to get test ads on this device.");
        }
        m4892o(str);
    }

    /* renamed from: a */
    public static <V> p22<V> m4724a(Throwable th) {
        if (th != null) {
            return new j22.C0984a(th);
        }
        throw new NullPointerException();
    }

    @Deprecated
    /* renamed from: a */
    public static final r32 m4728a(byte[] bArr) {
        try {
            p82 p82 = (p82) oc2.m10402a(p82.zzhds, bArr);
            for (p82.C1597a next : p82.mo9905k()) {
                if (next.mo9910m().mo6458l() == h82.C0839b.UNKNOWN_KEYMATERIAL || next.mo9910m().mo6458l() == h82.C0839b.SYMMETRIC || next.mo9910m().mo6458l() == h82.C0839b.ASYMMETRIC_PRIVATE) {
                    throw new GeneralSecurityException("keyset contains secret key material");
                }
            }
            if (p82.mo9906l() > 0) {
                return new r32(p82);
            }
            throw new GeneralSecurityException("empty keyset");
        } catch (zc2 unused) {
            throw new GeneralSecurityException("invalid keyset");
        }
    }
}
