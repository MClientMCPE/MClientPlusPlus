package p000;

/* renamed from: eu */
public interface C0625eu<T> {
}
