package p000;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import androidx.appcompat.view.menu.ListMenuItemView;
import java.util.ArrayList;
import p000.C1655q1;

/* renamed from: g1 */
public class C0732g1 extends BaseAdapter {

    /* renamed from: X */
    public C0816h1 f5854X;

    /* renamed from: Y */
    public int f5855Y = -1;

    /* renamed from: Z */
    public boolean f5856Z;

    /* renamed from: a0 */
    public final boolean f5857a0;

    /* renamed from: b0 */
    public final LayoutInflater f5858b0;

    /* renamed from: c0 */
    public final int f5859c0;

    public C0732g1(C0816h1 h1Var, LayoutInflater layoutInflater, boolean z, int i) {
        this.f5857a0 = z;
        this.f5858b0 = layoutInflater;
        this.f5854X = h1Var;
        this.f5859c0 = i;
        mo5826a();
    }

    /* renamed from: a */
    public void mo5826a() {
        C0816h1 h1Var = this.f5854X;
        C1115k1 k1Var = h1Var.f6517x;
        if (k1Var != null) {
            h1Var.mo6279a();
            ArrayList<C1115k1> arrayList = h1Var.f6503j;
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                if (arrayList.get(i) == k1Var) {
                    this.f5855Y = i;
                    return;
                }
            }
        }
        this.f5855Y = -1;
    }

    public int getCount() {
        ArrayList<C1115k1> arrayList;
        if (this.f5857a0) {
            C0816h1 h1Var = this.f5854X;
            h1Var.mo6279a();
            arrayList = h1Var.f6503j;
        } else {
            arrayList = this.f5854X.mo6310d();
        }
        int i = this.f5855Y;
        int size = arrayList.size();
        return i < 0 ? size : size - 1;
    }

    public C1115k1 getItem(int i) {
        ArrayList<C1115k1> arrayList;
        if (this.f5857a0) {
            C0816h1 h1Var = this.f5854X;
            h1Var.mo6279a();
            arrayList = h1Var.f6503j;
        } else {
            arrayList = this.f5854X.mo6310d();
        }
        int i2 = this.f5855Y;
        if (i2 >= 0 && i >= i2) {
            i++;
        }
        return arrayList.get(i);
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = this.f5858b0.inflate(this.f5859c0, viewGroup, false);
        }
        int i2 = getItem(i).f8784b;
        int i3 = i - 1;
        ListMenuItemView listMenuItemView = (ListMenuItemView) view;
        listMenuItemView.setGroupDividerEnabled(this.f5854X.mo6311e() && i2 != (i3 >= 0 ? getItem(i3).f8784b : i2));
        C1655q1.C1656a aVar = (C1655q1.C1656a) view;
        if (this.f5856Z) {
            listMenuItemView.setForceShowIcon(true);
        }
        aVar.mo716a(getItem(i), 0);
        return view;
    }

    public void notifyDataSetChanged() {
        mo5826a();
        super.notifyDataSetChanged();
    }
}
