package p000;

/* renamed from: cp */
public interface C0490cp {
    void onDestroy();

    void onPause();

    void onResume();
}
