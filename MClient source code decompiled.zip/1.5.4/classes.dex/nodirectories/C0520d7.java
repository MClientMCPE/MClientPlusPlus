package p000;

/* renamed from: d7 */
public class C0520d7<F, S> {

    /* renamed from: a */
    public final F f3748a;

    /* renamed from: b */
    public final S f3749b;

    public boolean equals(Object obj) {
        if (!(obj instanceof C0520d7)) {
            return false;
        }
        C0520d7 d7Var = (C0520d7) obj;
        return C0815h0.m5849b((Object) d7Var.f3748a, (Object) this.f3748a) && C0815h0.m5849b((Object) d7Var.f3749b, (Object) this.f3749b);
    }

    public int hashCode() {
        F f = this.f3748a;
        int i = 0;
        int hashCode = f == null ? 0 : f.hashCode();
        S s = this.f3749b;
        if (s != null) {
            i = s.hashCode();
        }
        return hashCode ^ i;
    }

    public String toString() {
        StringBuilder a = C0789gk.m5562a("Pair{");
        a.append(String.valueOf(this.f3748a));
        a.append(" ");
        a.append(String.valueOf(this.f3749b));
        a.append("}");
        return a.toString();
    }
}
