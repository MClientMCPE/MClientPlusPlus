package p000;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.concurrent.Callable;

/* renamed from: ek */
public final /* synthetic */ class C0615ek implements Callable {

    /* renamed from: a */
    public final /* synthetic */ C1065jj f4545a;

    /* renamed from: b */
    public final /* synthetic */ int f4546b;

    /* renamed from: c */
    public final /* synthetic */ C1626pj f4547c;

    /* renamed from: d */
    public final /* synthetic */ String f4548d;

    /* renamed from: e */
    public final /* synthetic */ C1255lj f4549e;

    /* renamed from: f */
    public final /* synthetic */ Bundle f4550f;

    public /* synthetic */ C0615ek(C1065jj jjVar, int i, C1626pj pjVar, String str, C1255lj ljVar, Bundle bundle) {
        this.f4545a = jjVar;
        this.f4546b = i;
        this.f4547c = pjVar;
        this.f4548d = str;
        this.f4549e = ljVar;
        this.f4550f = bundle;
    }

    public final Object call() {
        C1065jj jjVar = this.f4545a;
        int i = this.f4546b;
        C1626pj pjVar = this.f4547c;
        String str = this.f4548d;
        Bundle bundle = this.f4550f;
        n23 n23 = jjVar.f8487f;
        String packageName = jjVar.f8486e.getPackageName();
        String a = pjVar.mo10062a();
        l23 l23 = (l23) n23;
        Parcel a2 = l23.mo9430a();
        a2.writeInt(i);
        a2.writeString(packageName);
        a2.writeString(a);
        a2.writeString(str);
        a2.writeString((String) null);
        q23.m11407a(a2, (Parcelable) bundle);
        Parcel a3 = l23.mo9431a(8, a2);
        Bundle bundle2 = (Bundle) q23.m11406a(a3, Bundle.CREATOR);
        a3.recycle();
        return bundle2;
    }
}
