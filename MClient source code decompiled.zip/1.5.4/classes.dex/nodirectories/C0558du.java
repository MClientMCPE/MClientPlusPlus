package p000;

/* renamed from: du */
public final class C0558du {

    /* renamed from: a */
    public static C1878st<Boolean> f4104a = C1878st.m12905a("gads:js_flags:mf", false);

    /* renamed from: b */
    public static C1878st<Long> f4105b = C1878st.m12903a("gads:js_flags:update_interval", 43200000);
}
