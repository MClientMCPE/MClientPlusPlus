package p000;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;

/* renamed from: c2 */
public class C0334c2 {

    /* renamed from: a */
    public final View f2426a;

    /* renamed from: b */
    public final C0820h2 f2427b;

    /* renamed from: c */
    public int f2428c = -1;

    /* renamed from: d */
    public C2179w3 f2429d;

    /* renamed from: e */
    public C2179w3 f2430e;

    /* renamed from: f */
    public C2179w3 f2431f;

    public C0334c2(View view) {
        this.f2426a = view;
        this.f2427b = C0820h2.m5929a();
    }

    /* renamed from: a */
    public void mo2713a() {
        Drawable background = this.f2426a.getBackground();
        if (background != null) {
            int i = Build.VERSION.SDK_INT;
            boolean z = true;
            if (i <= 21 ? i == 21 : this.f2429d != null) {
                if (this.f2431f == null) {
                    this.f2431f = new C2179w3();
                }
                C2179w3 w3Var = this.f2431f;
                w3Var.mo12099a();
                ColorStateList f = C2189w7.m15008f(this.f2426a);
                if (f != null) {
                    w3Var.f16522d = true;
                    w3Var.f16519a = f;
                }
                View view = this.f2426a;
                PorterDuff.Mode backgroundTintMode = Build.VERSION.SDK_INT >= 21 ? view.getBackgroundTintMode() : view instanceof C2097v7 ? ((C2097v7) view).getSupportBackgroundTintMode() : null;
                if (backgroundTintMode != null) {
                    w3Var.f16521c = true;
                    w3Var.f16520b = backgroundTintMode;
                }
                if (w3Var.f16522d || w3Var.f16521c) {
                    C0820h2.m5930a(background, w3Var, this.f2426a.getDrawableState());
                } else {
                    z = false;
                }
                if (z) {
                    return;
                }
            }
            C2179w3 w3Var2 = this.f2430e;
            if (w3Var2 != null) {
                C0820h2.m5930a(background, w3Var2, this.f2426a.getDrawableState());
                return;
            }
            C2179w3 w3Var3 = this.f2429d;
            if (w3Var3 != null) {
                C0820h2.m5930a(background, w3Var3, this.f2426a.getDrawableState());
            }
        }
    }

    /* renamed from: a */
    public void mo2714a(int i) {
        this.f2428c = i;
        C0820h2 h2Var = this.f2427b;
        mo2715a(h2Var != null ? h2Var.mo6354b(this.f2426a.getContext(), i) : null);
        mo2713a();
    }

    /* renamed from: a */
    public void mo2715a(ColorStateList colorStateList) {
        if (colorStateList != null) {
            if (this.f2429d == null) {
                this.f2429d = new C2179w3();
            }
            C2179w3 w3Var = this.f2429d;
            w3Var.f16519a = colorStateList;
            w3Var.f16522d = true;
        } else {
            this.f2429d = null;
        }
        mo2713a();
    }

    /* renamed from: a */
    public void mo2716a(PorterDuff.Mode mode) {
        if (this.f2430e == null) {
            this.f2430e = new C2179w3();
        }
        C2179w3 w3Var = this.f2430e;
        w3Var.f16520b = mode;
        w3Var.f16521c = true;
        mo2713a();
    }

    /* renamed from: b */
    public ColorStateList mo2718b() {
        C2179w3 w3Var = this.f2430e;
        if (w3Var != null) {
            return w3Var.f16519a;
        }
        return null;
    }

    /* renamed from: b */
    public void mo2719b(ColorStateList colorStateList) {
        if (this.f2430e == null) {
            this.f2430e = new C2179w3();
        }
        C2179w3 w3Var = this.f2430e;
        w3Var.f16519a = colorStateList;
        w3Var.f16522d = true;
        mo2713a();
    }

    /* renamed from: c */
    public PorterDuff.Mode mo2720c() {
        C2179w3 w3Var = this.f2430e;
        if (w3Var != null) {
            return w3Var.f16520b;
        }
        return null;
    }

    /* renamed from: d */
    public void mo2721d() {
        this.f2428c = -1;
        mo2715a((ColorStateList) null);
        mo2713a();
    }

    /* renamed from: a */
    public void mo2717a(AttributeSet attributeSet, int i) {
        C2322y3 a = C2322y3.m16057a(this.f2426a.getContext(), attributeSet, C1292m.ViewBackgroundHelper, i, 0);
        try {
            if (a.mo12745f(C1292m.ViewBackgroundHelper_android_background)) {
                this.f2428c = a.mo12744f(C1292m.ViewBackgroundHelper_android_background, -1);
                ColorStateList b = this.f2427b.mo6354b(this.f2426a.getContext(), this.f2428c);
                if (b != null) {
                    mo2715a(b);
                }
            }
            if (a.mo12745f(C1292m.ViewBackgroundHelper_backgroundTint)) {
                C2189w7.m14984a(this.f2426a, a.mo12733a(C1292m.ViewBackgroundHelper_backgroundTint));
            }
            if (a.mo12745f(C1292m.ViewBackgroundHelper_backgroundTintMode)) {
                C2189w7.m14985a(this.f2426a, C0279b3.m1705a(a.mo12740d(C1292m.ViewBackgroundHelper_backgroundTintMode, -1), (PorterDuff.Mode) null));
            }
        } finally {
            a.f17544b.recycle();
        }
    }
}
