package p000;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.databinding.ViewDataBinding;

/* renamed from: f9 */
public class C0672f9 {

    /* renamed from: a */
    public static C0362c9 f5192a = new C0523d9();

    /* renamed from: b */
    public static C0593e9 f5193b = null;

    /* renamed from: a */
    public static <T extends ViewDataBinding> T m4597a(View view) {
        C0593e9 e9Var = f5193b;
        T a = ViewDataBinding.m920a(view);
        if (a != null) {
            return a;
        }
        Object tag = view.getTag();
        if (tag instanceof String) {
            int a2 = f5192a.mo2867a((String) tag);
            if (a2 != 0) {
                return f5192a.mo2868a(e9Var, view, a2);
            }
            throw new IllegalArgumentException(C0789gk.m5556a("View is not a binding layout. Tag: ", tag));
        }
        throw new IllegalArgumentException("View is not a binding layout");
    }

    /* renamed from: a */
    public static <T extends ViewDataBinding> T m4598a(C0593e9 e9Var, View view, int i) {
        return f5192a.mo2868a(e9Var, view, i);
    }

    /* renamed from: a */
    public static <T extends ViewDataBinding> T m4599a(C0593e9 e9Var, ViewGroup viewGroup, int i, int i2) {
        int childCount = viewGroup.getChildCount();
        int i3 = childCount - i;
        if (i3 == 1) {
            return m4598a(e9Var, viewGroup.getChildAt(childCount - 1), i2);
        }
        View[] viewArr = new View[i3];
        for (int i4 = 0; i4 < i3; i4++) {
            viewArr[i4] = viewGroup.getChildAt(i4 + i);
        }
        return m4600a(e9Var, viewArr, i2);
    }

    /* renamed from: a */
    public static <T extends ViewDataBinding> T m4600a(C0593e9 e9Var, View[] viewArr, int i) {
        return f5192a.mo2869a(e9Var, viewArr, i);
    }

    /* renamed from: a */
    public static <T extends ViewDataBinding> T m4596a(LayoutInflater layoutInflater, int i, ViewGroup viewGroup, boolean z) {
        C0593e9 e9Var = f5193b;
        int i2 = 0;
        boolean z2 = viewGroup != null && z;
        if (z2) {
            i2 = viewGroup.getChildCount();
        }
        return z2 ? m4599a(e9Var, viewGroup, i2, i) : m4598a(e9Var, layoutInflater.inflate(i, viewGroup, z), i);
    }

    /* renamed from: a */
    public static <T extends ViewDataBinding> T m4595a(Activity activity, int i) {
        C0593e9 e9Var = f5193b;
        activity.setContentView(i);
        return m4599a(e9Var, (ViewGroup) activity.getWindow().getDecorView().findViewById(16908290), 0, i);
    }
}
