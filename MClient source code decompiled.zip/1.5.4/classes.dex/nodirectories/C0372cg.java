package p000;

/* renamed from: cg */
public class C0372cg implements C1617pg {

    /* renamed from: a */
    public final /* synthetic */ C1335mg f2696a;

    public C0372cg(C1335mg mgVar) {
        this.f2696a = mgVar;
    }

    /* renamed from: a */
    public void mo532a(C1249lg lgVar) {
        if (this.f2696a.mo8736i(lgVar)) {
            C1335mg mgVar = this.f2696a;
            C1703qi c = mgVar.mo8730c(lgVar);
            ic3 ic3 = ic3.OTHER;
            dc3 dc3 = mgVar.f10234x0;
            if (dc3 != null) {
                try {
                    dc3.mo4737a(c, ic3, (String) null);
                } catch (RuntimeException unused) {
                }
            }
        }
    }
}
