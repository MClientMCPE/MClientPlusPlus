package p000;

/* renamed from: cu */
public final class C0495cu {

    /* renamed from: a */
    public static C1878st<Boolean> f3541a = C1878st.m12905a("gad:force_dynamite_loading_enabled", false);

    /* renamed from: b */
    public static C1878st<Boolean> f3542b = C1878st.m12905a("gads:uri_query_to_map_rewrite:enabled", false);

    /* renamed from: c */
    public static C1878st<Boolean> f3543c = C1878st.m12905a("gads:sdk_csi_write_to_file", false);
}
