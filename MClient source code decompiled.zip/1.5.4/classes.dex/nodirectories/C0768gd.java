package p000;

import android.os.Bundle;
import androidx.savedstate.Recreator;
import androidx.savedstate.SavedStateRegistry$1;
import p000.C1234lb;

/* renamed from: gd */
public final class C0768gd {

    /* renamed from: a */
    public final C0857hd f6092a;

    /* renamed from: b */
    public final C0677fd f6093b = new C0677fd();

    public C0768gd(C0857hd hdVar) {
        this.f6092a = hdVar;
    }

    /* renamed from: a */
    public void mo6069a(Bundle bundle) {
        C1234lb a = this.f6092a.mo635a();
        if (((C1607pb) a).f12333b == C1234lb.C1236b.INITIALIZED) {
            a.mo8347a(new Recreator(this.f6092a));
            C0677fd fdVar = this.f6093b;
            if (!fdVar.f5230c) {
                if (bundle != null) {
                    fdVar.f5229b = bundle.getBundle("androidx.lifecycle.BundlableSavedStateRegistry.key");
                }
                a.mo8347a(new SavedStateRegistry$1(fdVar));
                fdVar.f5230c = true;
                return;
            }
            throw new IllegalStateException("SavedStateRegistry was already restored.");
        }
        throw new IllegalStateException("Restarter must be created only during owner's initialization stage");
    }

    /* renamed from: b */
    public void mo6070b(Bundle bundle) {
        this.f6093b.mo5549a(bundle);
    }
}
