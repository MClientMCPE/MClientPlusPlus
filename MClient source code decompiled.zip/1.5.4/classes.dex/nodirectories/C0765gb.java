package p000;

import android.view.animation.Interpolator;

/* renamed from: gb */
public abstract class C0765gb implements Interpolator {

    /* renamed from: a */
    public final float[] f6076a;

    /* renamed from: b */
    public final float f6077b = (1.0f / ((float) (this.f6076a.length - 1)));

    public C0765gb(float[] fArr) {
        this.f6076a = fArr;
    }

    public float getInterpolation(float f) {
        if (f >= 1.0f) {
            return 1.0f;
        }
        if (f <= 0.0f) {
            return 0.0f;
        }
        float[] fArr = this.f6076a;
        int min = Math.min((int) (((float) (fArr.length - 1)) * f), fArr.length - 2);
        float f2 = this.f6077b;
        float f3 = (f - (((float) min) * f2)) / f2;
        float[] fArr2 = this.f6076a;
        return ((fArr2[min + 1] - fArr2[min]) * f3) + fArr2[min];
    }
}
