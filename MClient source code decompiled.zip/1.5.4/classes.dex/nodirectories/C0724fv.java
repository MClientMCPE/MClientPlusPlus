package p000;

import android.os.IInterface;
import java.util.List;

/* renamed from: fv */
public interface C0724fv extends IInterface {
    /* renamed from: l0 */
    List<C1274lv> mo5787l0();

    /* renamed from: n0 */
    String mo5788n0();
}
