package p000;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView;

/* renamed from: cd */
public class C0369cd extends C1913tc {

    /* renamed from: q */
    public final /* synthetic */ C0297bd f2658q;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public C0369cd(C0297bd bdVar, Context context) {
        super(context);
        this.f2658q = bdVar;
    }

    /* renamed from: a */
    public float mo2901a(DisplayMetrics displayMetrics) {
        return 100.0f / ((float) displayMetrics.densityDpi);
    }

    /* renamed from: a */
    public void mo2007a(View view, RecyclerView.C0212a0 a0Var, RecyclerView.C0249z.C0250a aVar) {
        C0297bd bdVar = this.f2658q;
        RecyclerView recyclerView = bdVar.f1816a;
        if (recyclerView != null) {
            int[] a = bdVar.mo2447a(recyclerView.getLayoutManager(), view);
            int i = a[0];
            int i2 = a[1];
            double b = (double) mo11240b(Math.max(Math.abs(i), Math.abs(i2)));
            Double.isNaN(b);
            Double.isNaN(b);
            int ceil = (int) Math.ceil(b / 0.3356d);
            if (ceil > 0) {
                aVar.mo2009a(i, i2, ceil, this.f14813j);
            }
        }
    }
}
