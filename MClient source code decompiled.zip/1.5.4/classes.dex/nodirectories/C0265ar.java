package p000;

/* renamed from: ar */
public final class C0265ar {

    /* renamed from: a */
    public final String f1518a;

    /* renamed from: b */
    public final String f1519b;

    /* renamed from: c */
    public final int f1520c = 129;

    public C0265ar(String str, String str2, boolean z) {
        this.f1519b = str;
        this.f1518a = str2;
    }
}
