package p000;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.Scroller;
import com.google.android.material.tabs.TabLayout;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/* renamed from: ff */
public class C0681ff extends ViewGroup {

    /* renamed from: V0 */
    public static final int[] f5259V0 = {16842931};

    /* renamed from: W0 */
    public static final Comparator<C0685d> f5260W0 = new C0682a();

    /* renamed from: X0 */
    public static final C0691i f5261X0 = new C0691i();

    /* renamed from: A0 */
    public float f5262A0;

    /* renamed from: B0 */
    public float f5263B0;

    /* renamed from: C0 */
    public float f5264C0;

    /* renamed from: D0 */
    public float f5265D0;

    /* renamed from: E0 */
    public int f5266E0;

    /* renamed from: F0 */
    public VelocityTracker f5267F0;

    /* renamed from: G0 */
    public int f5268G0;

    /* renamed from: H0 */
    public boolean f5269H0;

    /* renamed from: I0 */
    public EdgeEffect f5270I0;

    /* renamed from: J0 */
    public EdgeEffect f5271J0;

    /* renamed from: K0 */
    public boolean f5272K0;

    /* renamed from: L0 */
    public boolean f5273L0;

    /* renamed from: M0 */
    public int f5274M0;

    /* renamed from: N0 */
    public List<C0688g> f5275N0;

    /* renamed from: O0 */
    public C0688g f5276O0;

    /* renamed from: P0 */
    public C0688g f5277P0;

    /* renamed from: Q0 */
    public List<C0687f> f5278Q0;

    /* renamed from: R0 */
    public int f5279R0;

    /* renamed from: S0 */
    public ArrayList<View> f5280S0;

    /* renamed from: T0 */
    public final Runnable f5281T0;

    /* renamed from: U0 */
    public int f5282U0;

    /* renamed from: a0 */
    public int f5283a0;

    /* renamed from: b0 */
    public final ArrayList<C0685d> f5284b0;

    /* renamed from: c0 */
    public final C0685d f5285c0;

    /* renamed from: d0 */
    public final Rect f5286d0;

    /* renamed from: e0 */
    public int f5287e0;

    /* renamed from: f0 */
    public int f5288f0;

    /* renamed from: g0 */
    public Parcelable f5289g0;

    /* renamed from: h0 */
    public ClassLoader f5290h0;

    /* renamed from: i0 */
    public Scroller f5291i0;

    /* renamed from: j0 */
    public boolean f5292j0;

    /* renamed from: k0 */
    public int f5293k0;

    /* renamed from: l0 */
    public Drawable f5294l0;

    /* renamed from: m0 */
    public int f5295m0;

    /* renamed from: n0 */
    public int f5296n0;

    /* renamed from: o0 */
    public float f5297o0;

    /* renamed from: p0 */
    public float f5298p0;

    /* renamed from: q0 */
    public int f5299q0;

    /* renamed from: r0 */
    public boolean f5300r0;

    /* renamed from: s0 */
    public boolean f5301s0;

    /* renamed from: t0 */
    public boolean f5302t0;

    /* renamed from: u0 */
    public int f5303u0;

    /* renamed from: v0 */
    public boolean f5304v0;

    /* renamed from: w0 */
    public boolean f5305w0;

    /* renamed from: x0 */
    public int f5306x0;

    /* renamed from: y0 */
    public int f5307y0;

    /* renamed from: z0 */
    public int f5308z0;

    /* renamed from: ff$a */
    public static class C0682a implements Comparator<C0685d> {
        public int compare(Object obj, Object obj2) {
            return ((C0685d) obj).f5310b - ((C0685d) obj2).f5310b;
        }
    }

    /* renamed from: ff$b */
    public static class C0683b implements Interpolator {
        public float getInterpolation(float f) {
            float f2 = f - 1.0f;
            return (f2 * f2 * f2 * f2 * f2) + 1.0f;
        }
    }

    @Inherited
    @Target({ElementType.TYPE})
    @Retention(RetentionPolicy.RUNTIME)
    /* renamed from: ff$c */
    public @interface C0684c {
    }

    /* renamed from: ff$d */
    public static class C0685d {

        /* renamed from: a */
        public Object f5309a;

        /* renamed from: b */
        public int f5310b;

        /* renamed from: c */
        public boolean f5311c;

        /* renamed from: d */
        public float f5312d;

        /* renamed from: e */
        public float f5313e;
    }

    /* renamed from: ff$e */
    public static class C0686e extends ViewGroup.LayoutParams {

        /* renamed from: a */
        public boolean f5314a;

        /* renamed from: b */
        public int f5315b;

        /* renamed from: c */
        public float f5316c = 0.0f;

        /* renamed from: d */
        public boolean f5317d;

        /* renamed from: e */
        public int f5318e;

        /* renamed from: f */
        public int f5319f;

        public C0686e() {
            super(-1, -1);
        }

        public C0686e(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0681ff.f5259V0);
            this.f5315b = obtainStyledAttributes.getInteger(0, 48);
            obtainStyledAttributes.recycle();
        }
    }

    /* renamed from: ff$f */
    public interface C0687f {
    }

    /* renamed from: ff$g */
    public interface C0688g {
    }

    /* renamed from: ff$h */
    public static class C0689h extends C1904t8 {
        public static final Parcelable.Creator<C0689h> CREATOR = new C0690a();

        /* renamed from: Z */
        public int f5320Z;

        /* renamed from: a0 */
        public Parcelable f5321a0;

        /* renamed from: b0 */
        public ClassLoader f5322b0;

        /* renamed from: ff$h$a */
        public static class C0690a implements Parcelable.ClassLoaderCreator<C0689h> {
            public Object createFromParcel(Parcel parcel) {
                return new C0689h(parcel, (ClassLoader) null);
            }

            public Object[] newArray(int i) {
                return new C0689h[i];
            }

            public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new C0689h(parcel, classLoader);
            }
        }

        public C0689h(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            classLoader = classLoader == null ? C0689h.class.getClassLoader() : classLoader;
            this.f5320Z = parcel.readInt();
            this.f5321a0 = parcel.readParcelable(classLoader);
            this.f5322b0 = classLoader;
        }

        public C0689h(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            StringBuilder a = C0789gk.m5562a("FragmentPager.SavedState{");
            a.append(Integer.toHexString(System.identityHashCode(this)));
            a.append(" position=");
            a.append(this.f5320Z);
            a.append("}");
            return a.toString();
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeParcelable(this.f14707X, i);
            parcel.writeInt(this.f5320Z);
            parcel.writeParcelable(this.f5321a0, i);
        }
    }

    /* renamed from: ff$i */
    public static class C0691i implements Comparator<View> {
        public int compare(Object obj, Object obj2) {
            C0686e eVar = (C0686e) ((View) obj).getLayoutParams();
            C0686e eVar2 = (C0686e) ((View) obj2).getLayoutParams();
            boolean z = eVar.f5314a;
            if (z != eVar2.f5314a) {
                return z ? 1 : -1;
            }
            return eVar.f5318e - eVar2.f5318e;
        }
    }

    private int getClientWidth() {
        return (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
    }

    private void setScrollingCacheEnabled(boolean z) {
        if (this.f5301s0 != z) {
            this.f5301s0 = z;
        }
    }

    /* renamed from: a */
    public float mo5560a(float f) {
        return (float) Math.sin((double) ((f - 0.5f) * 0.47123894f));
    }

    /* renamed from: a */
    public final Rect mo5561a(Rect rect, View view) {
        if (rect == null) {
            rect = new Rect();
        }
        if (view == null) {
            rect.set(0, 0, 0, 0);
            return rect;
        }
        rect.left = view.getLeft();
        rect.right = view.getRight();
        rect.top = view.getTop();
        rect.bottom = view.getBottom();
        ViewParent parent = view.getParent();
        while ((parent instanceof ViewGroup) && parent != this) {
            ViewGroup viewGroup = (ViewGroup) parent;
            rect.left = viewGroup.getLeft() + rect.left;
            rect.right = viewGroup.getRight() + rect.right;
            rect.top = viewGroup.getTop() + rect.top;
            rect.bottom = viewGroup.getBottom() + rect.bottom;
            parent = viewGroup.getParent();
        }
        return rect;
    }

    /* renamed from: a */
    public final C0685d mo5562a() {
        int i;
        int clientWidth = getClientWidth();
        float scrollX = clientWidth > 0 ? ((float) getScrollX()) / ((float) clientWidth) : 0.0f;
        float f = clientWidth > 0 ? ((float) this.f5293k0) / ((float) clientWidth) : 0.0f;
        C0685d dVar = null;
        int i2 = 0;
        boolean z = true;
        int i3 = -1;
        float f2 = 0.0f;
        float f3 = 0.0f;
        while (i2 < this.f5284b0.size()) {
            C0685d dVar2 = this.f5284b0.get(i2);
            if (z || dVar2.f5310b == (i = i3 + 1)) {
                f2 = dVar2.f5313e;
                float f4 = dVar2.f5312d + f2 + f;
                if (!z && scrollX < f2) {
                    return dVar;
                }
                if (scrollX < f4 || i2 == this.f5284b0.size() - 1) {
                    return dVar2;
                }
                i3 = dVar2.f5310b;
                f3 = dVar2.f5312d;
                i2++;
                dVar = dVar2;
                z = false;
            } else {
                C0685d dVar3 = this.f5285c0;
                dVar3.f5313e = f2 + f3 + f;
                dVar3.f5310b = i;
                int i4 = dVar3.f5310b;
                throw null;
            }
        }
        return dVar;
    }

    /* renamed from: a */
    public C0685d mo5563a(View view) {
        if (this.f5284b0.size() <= 0) {
            return null;
        }
        Object obj = this.f5284b0.get(0).f5309a;
        throw null;
    }

    /* JADX WARNING: Removed duplicated region for block: B:19:0x0066  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo5564a(int r13, float r14, int r15) {
        /*
            r12 = this;
            int r0 = r12.f5274M0
            r1 = 0
            r2 = 1
            if (r0 <= 0) goto L_0x006d
            int r0 = r12.getScrollX()
            int r3 = r12.getPaddingLeft()
            int r4 = r12.getPaddingRight()
            int r5 = r12.getWidth()
            int r6 = r12.getChildCount()
            r7 = r4
            r4 = r3
            r3 = 0
        L_0x001d:
            if (r3 >= r6) goto L_0x006d
            android.view.View r8 = r12.getChildAt(r3)
            android.view.ViewGroup$LayoutParams r9 = r8.getLayoutParams()
            ff$e r9 = (p000.C0681ff.C0686e) r9
            boolean r10 = r9.f5314a
            if (r10 != 0) goto L_0x002e
            goto L_0x006a
        L_0x002e:
            int r9 = r9.f5315b
            r9 = r9 & 7
            if (r9 == r2) goto L_0x004f
            r10 = 3
            if (r9 == r10) goto L_0x0049
            r10 = 5
            if (r9 == r10) goto L_0x003c
            r9 = r4
            goto L_0x005e
        L_0x003c:
            int r9 = r5 - r7
            int r10 = r8.getMeasuredWidth()
            int r9 = r9 - r10
            int r10 = r8.getMeasuredWidth()
            int r7 = r7 + r10
            goto L_0x005b
        L_0x0049:
            int r9 = r8.getWidth()
            int r9 = r9 + r4
            goto L_0x005e
        L_0x004f:
            int r9 = r8.getMeasuredWidth()
            int r9 = r5 - r9
            int r9 = r9 / 2
            int r9 = java.lang.Math.max(r9, r4)
        L_0x005b:
            r11 = r9
            r9 = r4
            r4 = r11
        L_0x005e:
            int r4 = r4 + r0
            int r10 = r8.getLeft()
            int r4 = r4 - r10
            if (r4 == 0) goto L_0x0069
            r8.offsetLeftAndRight(r4)
        L_0x0069:
            r4 = r9
        L_0x006a:
            int r3 = r3 + 1
            goto L_0x001d
        L_0x006d:
            ff$g r0 = r12.f5276O0
            if (r0 == 0) goto L_0x0076
            com.google.android.material.tabs.TabLayout$i r0 = (com.google.android.material.tabs.TabLayout.C0462i) r0
            r0.mo3929a(r13, r14, r15)
        L_0x0076:
            java.util.List<ff$g> r0 = r12.f5275N0
            if (r0 == 0) goto L_0x0092
            int r0 = r0.size()
        L_0x007e:
            if (r1 >= r0) goto L_0x0092
            java.util.List<ff$g> r3 = r12.f5275N0
            java.lang.Object r3 = r3.get(r1)
            ff$g r3 = (p000.C0681ff.C0688g) r3
            if (r3 == 0) goto L_0x008f
            com.google.android.material.tabs.TabLayout$i r3 = (com.google.android.material.tabs.TabLayout.C0462i) r3
            r3.mo3929a(r13, r14, r15)
        L_0x008f:
            int r1 = r1 + 1
            goto L_0x007e
        L_0x0092:
            ff$g r0 = r12.f5277P0
            if (r0 == 0) goto L_0x009b
            com.google.android.material.tabs.TabLayout$i r0 = (com.google.android.material.tabs.TabLayout.C0462i) r0
            r0.mo3929a(r13, r14, r15)
        L_0x009b:
            r12.f5273L0 = r2
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0681ff.mo5564a(int, float, int):void");
    }

    /* renamed from: a */
    public void mo5565a(int i, int i2, int i3) {
        int i4;
        if (getChildCount() == 0) {
            setScrollingCacheEnabled(false);
            return;
        }
        Scroller scroller = this.f5291i0;
        if (scroller != null && !scroller.isFinished()) {
            i4 = this.f5292j0 ? this.f5291i0.getCurrX() : this.f5291i0.getStartX();
            this.f5291i0.abortAnimation();
            setScrollingCacheEnabled(false);
        } else {
            i4 = getScrollX();
        }
        int i5 = i4;
        int scrollY = getScrollY();
        int i6 = i - i5;
        int i7 = i2 - scrollY;
        if (i6 == 0 && i7 == 0) {
            mo5574a(false);
            mo5592d();
            setScrollState(0);
            return;
        }
        setScrollingCacheEnabled(true);
        setScrollState(2);
        int clientWidth = getClientWidth();
        float f = (float) (clientWidth / 2);
        float a = (mo5560a(Math.min(1.0f, (((float) Math.abs(i6)) * 1.0f) / ((float) clientWidth))) * f) + f;
        int abs = Math.abs(i3);
        if (abs > 0) {
            int min = Math.min(Math.round(Math.abs(a / ((float) abs)) * 1000.0f) * 4, 600);
            this.f5292j0 = false;
            this.f5291i0.startScroll(i5, scrollY, i6, i7, min);
            C2189w7.m14972D(this);
            return;
        }
        throw null;
    }

    /* renamed from: a */
    public final void mo5566a(int i, int i2, int i3, int i4) {
        int min;
        if (i2 <= 0 || this.f5284b0.isEmpty()) {
            C0685d c = mo5587c(this.f5287e0);
            min = (int) ((c != null ? Math.min(c.f5313e, this.f5298p0) : 0.0f) * ((float) ((i - getPaddingLeft()) - getPaddingRight())));
            if (min != getScrollX()) {
                mo5574a(false);
            } else {
                return;
            }
        } else if (!this.f5291i0.isFinished()) {
            this.f5291i0.setFinalX(getCurrentItem() * getClientWidth());
            return;
        } else {
            min = (int) ((((float) getScrollX()) / ((float) (((i2 - getPaddingLeft()) - getPaddingRight()) + i4))) * ((float) (((i - getPaddingLeft()) - getPaddingRight()) + i3)));
        }
        scrollTo(min, getScrollY());
    }

    /* renamed from: a */
    public void mo5567a(int i, boolean z) {
        this.f5302t0 = false;
        mo5569a(i, z, false);
    }

    /* renamed from: a */
    public final void mo5568a(int i, boolean z, int i2, boolean z2) {
        int i3;
        C0685d c = mo5587c(i);
        if (c != null) {
            i3 = (int) (Math.max(this.f5297o0, Math.min(c.f5313e, this.f5298p0)) * ((float) getClientWidth()));
        } else {
            i3 = 0;
        }
        if (z) {
            mo5565a(i3, 0, i2);
            if (z2) {
                mo5581b(i);
                return;
            }
            return;
        }
        if (z2) {
            mo5581b(i);
        }
        mo5574a(false);
        scrollTo(i3, 0);
        mo5593d(i3);
    }

    /* renamed from: a */
    public void mo5569a(int i, boolean z, boolean z2) {
        mo5570a(i, z, z2, 0);
    }

    /* renamed from: a */
    public void mo5570a(int i, boolean z, boolean z2, int i2) {
        setScrollingCacheEnabled(false);
    }

    /* renamed from: a */
    public final void mo5571a(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.f5266E0) {
            int i = actionIndex == 0 ? 1 : 0;
            this.f5262A0 = motionEvent.getX(i);
            this.f5266E0 = motionEvent.getPointerId(i);
            VelocityTracker velocityTracker = this.f5267F0;
            if (velocityTracker != null) {
                velocityTracker.clear();
            }
        }
    }

    /* renamed from: a */
    public void mo5572a(C0687f fVar) {
        if (this.f5278Q0 == null) {
            this.f5278Q0 = new ArrayList();
        }
        this.f5278Q0.add(fVar);
    }

    /* renamed from: a */
    public void mo5573a(C0688g gVar) {
        if (this.f5275N0 == null) {
            this.f5275N0 = new ArrayList();
        }
        this.f5275N0.add(gVar);
    }

    /* renamed from: a */
    public final void mo5574a(boolean z) {
        boolean z2 = this.f5282U0 == 2;
        if (z2) {
            setScrollingCacheEnabled(false);
            if (!this.f5291i0.isFinished()) {
                this.f5291i0.abortAnimation();
                int scrollX = getScrollX();
                int scrollY = getScrollY();
                int currX = this.f5291i0.getCurrX();
                int currY = this.f5291i0.getCurrY();
                if (!(scrollX == currX && scrollY == currY)) {
                    scrollTo(currX, currY);
                    if (currX != scrollX) {
                        mo5593d(currX);
                    }
                }
            }
        }
        this.f5302t0 = false;
        boolean z3 = z2;
        for (int i = 0; i < this.f5284b0.size(); i++) {
            C0685d dVar = this.f5284b0.get(i);
            if (dVar.f5311c) {
                dVar.f5311c = false;
                z3 = true;
            }
        }
        if (!z3) {
            return;
        }
        if (z) {
            C2189w7.m14991a((View) this, this.f5281T0);
        } else {
            this.f5281T0.run();
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:40:0x00c5  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo5575a(int r7) {
        /*
            r6 = this;
            android.view.View r0 = r6.findFocus()
            r1 = 1
            r2 = 0
            r3 = 0
            if (r0 != r6) goto L_0x000a
            goto L_0x0063
        L_0x000a:
            if (r0 == 0) goto L_0x0064
            android.view.ViewParent r4 = r0.getParent()
        L_0x0010:
            boolean r5 = r4 instanceof android.view.ViewGroup
            if (r5 == 0) goto L_0x001d
            if (r4 != r6) goto L_0x0018
            r4 = 1
            goto L_0x001e
        L_0x0018:
            android.view.ViewParent r4 = r4.getParent()
            goto L_0x0010
        L_0x001d:
            r4 = 0
        L_0x001e:
            if (r4 != 0) goto L_0x0064
            java.lang.StringBuilder r4 = new java.lang.StringBuilder
            r4.<init>()
            java.lang.Class r5 = r0.getClass()
            java.lang.String r5 = r5.getSimpleName()
            r4.append(r5)
            android.view.ViewParent r0 = r0.getParent()
        L_0x0034:
            boolean r5 = r0 instanceof android.view.ViewGroup
            if (r5 == 0) goto L_0x004d
            java.lang.String r5 = " => "
            r4.append(r5)
            java.lang.Class r5 = r0.getClass()
            java.lang.String r5 = r5.getSimpleName()
            r4.append(r5)
            android.view.ViewParent r0 = r0.getParent()
            goto L_0x0034
        L_0x004d:
            java.lang.String r0 = "arrowScroll tried to find focus based on non-child current focused view "
            java.lang.StringBuilder r0 = p000.C0789gk.m5562a((java.lang.String) r0)
            java.lang.String r4 = r4.toString()
            r0.append(r4)
            java.lang.String r0 = r0.toString()
            java.lang.String r4 = "ViewPager"
            android.util.Log.e(r4, r0)
        L_0x0063:
            r0 = r3
        L_0x0064:
            android.view.FocusFinder r3 = android.view.FocusFinder.getInstance()
            android.view.View r3 = r3.findNextFocus(r6, r0, r7)
            r4 = 66
            r5 = 17
            if (r3 == 0) goto L_0x00b0
            if (r3 == r0) goto L_0x00b0
            if (r7 != r5) goto L_0x008f
            android.graphics.Rect r1 = r6.f5286d0
            android.graphics.Rect r1 = r6.mo5561a((android.graphics.Rect) r1, (android.view.View) r3)
            int r1 = r1.left
            android.graphics.Rect r2 = r6.f5286d0
            android.graphics.Rect r2 = r6.mo5561a((android.graphics.Rect) r2, (android.view.View) r0)
            int r2 = r2.left
            if (r0 == 0) goto L_0x00aa
            if (r1 < r2) goto L_0x00aa
            boolean r0 = r6.mo5585b()
            goto L_0x00ae
        L_0x008f:
            if (r7 != r4) goto L_0x00c3
            android.graphics.Rect r1 = r6.f5286d0
            android.graphics.Rect r1 = r6.mo5561a((android.graphics.Rect) r1, (android.view.View) r3)
            int r1 = r1.left
            android.graphics.Rect r2 = r6.f5286d0
            android.graphics.Rect r2 = r6.mo5561a((android.graphics.Rect) r2, (android.view.View) r0)
            int r2 = r2.left
            if (r0 == 0) goto L_0x00aa
            if (r1 > r2) goto L_0x00aa
            boolean r0 = r6.mo5588c()
            goto L_0x00ae
        L_0x00aa:
            boolean r0 = r3.requestFocus()
        L_0x00ae:
            r2 = r0
            goto L_0x00c3
        L_0x00b0:
            if (r7 == r5) goto L_0x00bf
            if (r7 != r1) goto L_0x00b5
            goto L_0x00bf
        L_0x00b5:
            if (r7 == r4) goto L_0x00ba
            r0 = 2
            if (r7 != r0) goto L_0x00c3
        L_0x00ba:
            boolean r2 = r6.mo5588c()
            goto L_0x00c3
        L_0x00bf:
            boolean r2 = r6.mo5585b()
        L_0x00c3:
            if (r2 == 0) goto L_0x00cc
            int r7 = android.view.SoundEffectConstants.getContantForFocusDirection(r7)
            r6.playSoundEffect(r7)
        L_0x00cc:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0681ff.mo5575a(int):boolean");
    }

    /* renamed from: a */
    public boolean mo5576a(KeyEvent keyEvent) {
        int i;
        if (keyEvent.getAction() == 0) {
            int keyCode = keyEvent.getKeyCode();
            if (keyCode != 21) {
                if (keyCode != 22) {
                    if (keyCode == 61) {
                        if (keyEvent.hasNoModifiers()) {
                            return mo5575a(2);
                        }
                        if (keyEvent.hasModifiers(1)) {
                            return mo5575a(1);
                        }
                    }
                } else if (keyEvent.hasModifiers(2)) {
                    return mo5588c();
                } else {
                    i = 66;
                }
            } else if (keyEvent.hasModifiers(2)) {
                return mo5585b();
            } else {
                i = 17;
            }
            return mo5575a(i);
        }
        return false;
    }

    /* renamed from: a */
    public boolean mo5577a(View view, boolean z, int i, int i2, int i3) {
        int i4;
        View view2 = view;
        if (view2 instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view2;
            int scrollX = view.getScrollX();
            int scrollY = view.getScrollY();
            for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                View childAt = viewGroup.getChildAt(childCount);
                int i5 = i2 + scrollX;
                if (i5 >= childAt.getLeft() && i5 < childAt.getRight() && (i4 = i3 + scrollY) >= childAt.getTop() && i4 < childAt.getBottom()) {
                    if (mo5577a(childAt, true, i, i5 - childAt.getLeft(), i4 - childAt.getTop())) {
                        return true;
                    }
                }
            }
        }
        return z && view.canScrollHorizontally(-i);
    }

    public void addFocusables(ArrayList<View> arrayList, int i, int i2) {
        C0685d a;
        int size = arrayList.size();
        int descendantFocusability = getDescendantFocusability();
        if (descendantFocusability != 393216) {
            for (int i3 = 0; i3 < getChildCount(); i3++) {
                View childAt = getChildAt(i3);
                if (childAt.getVisibility() == 0 && (a = mo5563a(childAt)) != null && a.f5310b == this.f5287e0) {
                    childAt.addFocusables(arrayList, i, i2);
                }
            }
        }
        if ((descendantFocusability == 262144 && size != arrayList.size()) || !isFocusable()) {
            return;
        }
        if ((i2 & 1) != 1 || !isInTouchMode() || isFocusableInTouchMode()) {
            arrayList.add(this);
        }
    }

    public void addTouchables(ArrayList<View> arrayList) {
        C0685d a;
        for (int i = 0; i < getChildCount(); i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() == 0 && (a = mo5563a(childAt)) != null && a.f5310b == this.f5287e0) {
                childAt.addTouchables(arrayList);
            }
        }
    }

    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        if (!checkLayoutParams(layoutParams)) {
            layoutParams = generateLayoutParams(layoutParams);
        }
        C0686e eVar = (C0686e) layoutParams;
        eVar.f5314a |= view.getClass().getAnnotation(C0684c.class) != null;
        if (!this.f5300r0) {
            super.addView(view, i, layoutParams);
        } else if (!eVar.f5314a) {
            eVar.f5317d = true;
            addViewInLayout(view, i, layoutParams);
        } else {
            throw new IllegalStateException("Cannot add pager decor view during layout");
        }
    }

    /* renamed from: b */
    public final void mo5581b(int i) {
        C0688g gVar = this.f5276O0;
        if (gVar != null) {
            ((TabLayout.C0462i) gVar).mo3928a(i);
        }
        List<C0688g> list = this.f5275N0;
        if (list != null) {
            int size = list.size();
            for (int i2 = 0; i2 < size; i2++) {
                C0688g gVar2 = this.f5275N0.get(i2);
                if (gVar2 != null) {
                    ((TabLayout.C0462i) gVar2).mo3928a(i);
                }
            }
        }
        C0688g gVar3 = this.f5277P0;
        if (gVar3 != null) {
            ((TabLayout.C0462i) gVar3).mo3928a(i);
        }
    }

    /* renamed from: b */
    public void mo5582b(C0687f fVar) {
        List<C0687f> list = this.f5278Q0;
        if (list != null) {
            list.remove(fVar);
        }
    }

    /* renamed from: b */
    public void mo5583b(C0688g gVar) {
        List<C0688g> list = this.f5275N0;
        if (list != null) {
            list.remove(gVar);
        }
    }

    /* renamed from: b */
    public final void mo5584b(boolean z) {
        ViewParent parent = getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(z);
        }
    }

    /* renamed from: b */
    public boolean mo5585b() {
        int i = this.f5287e0;
        if (i <= 0) {
            return false;
        }
        mo5567a(i - 1, true);
        return true;
    }

    /* renamed from: b */
    public final boolean mo5586b(float f) {
        this.f5262A0 = f;
        getScrollX();
        getClientWidth();
        C0685d dVar = this.f5284b0.get(0);
        ArrayList<C0685d> arrayList = this.f5284b0;
        C0685d dVar2 = arrayList.get(arrayList.size() - 1);
        if (dVar.f5310b != 0) {
            float f2 = dVar.f5313e;
        }
        int i = dVar2.f5310b;
        throw null;
    }

    /* renamed from: c */
    public C0685d mo5587c(int i) {
        for (int i2 = 0; i2 < this.f5284b0.size(); i2++) {
            C0685d dVar = this.f5284b0.get(i2);
            if (dVar.f5310b == i) {
                return dVar;
            }
        }
        return null;
    }

    /* renamed from: c */
    public boolean mo5588c() {
        return false;
    }

    public boolean canScrollHorizontally(int i) {
        return false;
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof C0686e) && super.checkLayoutParams(layoutParams);
    }

    public void computeScroll() {
        this.f5292j0 = true;
        if (this.f5291i0.isFinished() || !this.f5291i0.computeScrollOffset()) {
            mo5574a(true);
            return;
        }
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        int currX = this.f5291i0.getCurrX();
        int currY = this.f5291i0.getCurrY();
        if (!(scrollX == currX && scrollY == currY)) {
            scrollTo(currX, currY);
            if (!mo5593d(currX)) {
                this.f5291i0.abortAnimation();
                scrollTo(0, currY);
            }
        }
        C2189w7.m14972D(this);
    }

    /* renamed from: d */
    public void mo5592d() {
        mo5598e(this.f5287e0);
    }

    /* renamed from: d */
    public final boolean mo5593d(int i) {
        if (this.f5284b0.size() != 0) {
            C0685d a = mo5562a();
            int clientWidth = getClientWidth();
            int i2 = this.f5293k0;
            int i3 = clientWidth + i2;
            float f = (float) clientWidth;
            int i4 = a.f5310b;
            float f2 = ((((float) i) / f) - a.f5313e) / (a.f5312d + (((float) i2) / f));
            this.f5273L0 = false;
            mo5564a(i4, f2, (int) (((float) i3) * f2));
            if (this.f5273L0) {
                return true;
            }
            throw new IllegalStateException("onPageScrolled did not call superclass implementation");
        } else if (this.f5272K0) {
            return false;
        } else {
            this.f5273L0 = false;
            mo5564a(0, 0.0f, 0);
            if (this.f5273L0) {
                return false;
            }
            throw new IllegalStateException("onPageScrolled did not call superclass implementation");
        }
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent) || mo5576a(keyEvent);
    }

    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        C0685d a;
        if (accessibilityEvent.getEventType() == 4096) {
            return super.dispatchPopulateAccessibilityEvent(accessibilityEvent);
        }
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            if (childAt.getVisibility() == 0 && (a = mo5563a(childAt)) != null && a.f5310b == this.f5287e0 && childAt.dispatchPopulateAccessibilityEvent(accessibilityEvent)) {
                return true;
            }
        }
        return false;
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        boolean z = false;
        if (getOverScrollMode() != 0) {
            this.f5270I0.finish();
            this.f5271J0.finish();
        } else {
            if (!this.f5270I0.isFinished()) {
                int save = canvas.save();
                int height = (getHeight() - getPaddingTop()) - getPaddingBottom();
                int width = getWidth();
                canvas.rotate(270.0f);
                canvas.translate((float) (getPaddingTop() + (-height)), this.f5297o0 * ((float) width));
                this.f5270I0.setSize(height, width);
                z = false | this.f5270I0.draw(canvas);
                canvas.restoreToCount(save);
            }
            if (!this.f5271J0.isFinished()) {
                int save2 = canvas.save();
                int width2 = getWidth();
                int height2 = (getHeight() - getPaddingTop()) - getPaddingBottom();
                canvas.rotate(90.0f);
                canvas.translate((float) (-getPaddingTop()), (-(this.f5298p0 + 1.0f)) * ((float) width2));
                this.f5271J0.setSize(height2, width2);
                z |= this.f5271J0.draw(canvas);
                canvas.restoreToCount(save2);
            }
        }
        if (z) {
            C2189w7.m14972D(this);
        }
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.f5294l0;
        if (drawable != null && drawable.isStateful()) {
            drawable.setState(getDrawableState());
        }
    }

    /* renamed from: e */
    public void mo5598e(int i) {
        int i2 = this.f5287e0;
        if (i2 != i) {
            mo5587c(i2);
            this.f5287e0 = i;
        }
        mo5600f();
    }

    /* renamed from: e */
    public final boolean mo5599e() {
        this.f5266E0 = -1;
        this.f5304v0 = false;
        this.f5305w0 = false;
        VelocityTracker velocityTracker = this.f5267F0;
        if (velocityTracker != null) {
            velocityTracker.recycle();
            this.f5267F0 = null;
        }
        this.f5270I0.onRelease();
        this.f5271J0.onRelease();
        if (this.f5270I0.isFinished() || this.f5271J0.isFinished()) {
            return true;
        }
        return false;
    }

    /* renamed from: f */
    public final void mo5600f() {
        if (this.f5279R0 != 0) {
            ArrayList<View> arrayList = this.f5280S0;
            if (arrayList == null) {
                this.f5280S0 = new ArrayList<>();
            } else {
                arrayList.clear();
            }
            int childCount = getChildCount();
            for (int i = 0; i < childCount; i++) {
                this.f5280S0.add(getChildAt(i));
            }
            Collections.sort(this.f5280S0, f5261X0);
        }
    }

    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new C0686e();
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new C0686e(getContext(), attributeSet);
    }

    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return generateDefaultLayoutParams();
    }

    public C0603ef getAdapter() {
        return null;
    }

    public int getChildDrawingOrder(int i, int i2) {
        if (this.f5279R0 == 2) {
            i2 = (i - 1) - i2;
        }
        return ((C0686e) this.f5280S0.get(i2).getLayoutParams()).f5319f;
    }

    public int getCurrentItem() {
        return this.f5287e0;
    }

    public int getOffscreenPageLimit() {
        return this.f5303u0;
    }

    public int getPageMargin() {
        return this.f5293k0;
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f5272K0 = true;
    }

    public void onDetachedFromWindow() {
        removeCallbacks(this.f5281T0);
        Scroller scroller = this.f5291i0;
        if (scroller != null && !scroller.isFinished()) {
            this.f5291i0.abortAnimation();
        }
        super.onDetachedFromWindow();
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f5293k0 > 0 && this.f5294l0 != null) {
            int size = this.f5284b0.size();
        }
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        MotionEvent motionEvent2 = motionEvent;
        int action = motionEvent.getAction() & 255;
        if (action == 3 || action == 1) {
            mo5599e();
            return false;
        }
        if (action != 0) {
            if (this.f5304v0) {
                return true;
            }
            if (this.f5305w0) {
                return false;
            }
        }
        if (action == 0) {
            float x = motionEvent.getX();
            this.f5264C0 = x;
            this.f5262A0 = x;
            float y = motionEvent.getY();
            this.f5265D0 = y;
            this.f5263B0 = y;
            this.f5266E0 = motionEvent2.getPointerId(0);
            this.f5305w0 = false;
            this.f5292j0 = true;
            this.f5291i0.computeScrollOffset();
            if (this.f5282U0 != 2 || Math.abs(this.f5291i0.getFinalX() - this.f5291i0.getCurrX()) <= this.f5268G0) {
                mo5574a(false);
                this.f5304v0 = false;
            } else {
                this.f5291i0.abortAnimation();
                this.f5302t0 = false;
                mo5592d();
                this.f5304v0 = true;
                mo5584b(true);
                setScrollState(1);
            }
        } else if (action == 2) {
            int i = this.f5266E0;
            if (i != -1) {
                int findPointerIndex = motionEvent2.findPointerIndex(i);
                float x2 = motionEvent2.getX(findPointerIndex);
                float f = x2 - this.f5262A0;
                float abs = Math.abs(f);
                float y2 = motionEvent2.getY(findPointerIndex);
                float abs2 = Math.abs(y2 - this.f5265D0);
                if (f != 0.0f) {
                    float f2 = this.f5262A0;
                    if (!((f2 < ((float) this.f5307y0) && f > 0.0f) || (f2 > ((float) (getWidth() - this.f5307y0)) && f < 0.0f))) {
                        if (mo5577a(this, false, (int) f, (int) x2, (int) y2)) {
                            this.f5262A0 = x2;
                            this.f5263B0 = y2;
                            this.f5305w0 = true;
                            return false;
                        }
                    }
                }
                if (abs > ((float) this.f5308z0) && abs * 0.5f > abs2) {
                    this.f5304v0 = true;
                    mo5584b(true);
                    setScrollState(1);
                    this.f5262A0 = f > 0.0f ? this.f5264C0 + ((float) this.f5308z0) : this.f5264C0 - ((float) this.f5308z0);
                    this.f5263B0 = y2;
                    setScrollingCacheEnabled(true);
                } else if (abs2 > ((float) this.f5308z0)) {
                    this.f5305w0 = true;
                }
                if (this.f5304v0) {
                    mo5586b(x2);
                    throw null;
                }
            }
        } else if (action == 6) {
            mo5571a(motionEvent);
        }
        if (this.f5267F0 == null) {
            this.f5267F0 = VelocityTracker.obtain();
        }
        this.f5267F0.addMovement(motionEvent2);
        return this.f5304v0;
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        boolean z2;
        C0685d a;
        int i5;
        int i6;
        int childCount = getChildCount();
        int i7 = i3 - i;
        int i8 = i4 - i2;
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingRight = getPaddingRight();
        int paddingBottom = getPaddingBottom();
        int scrollX = getScrollX();
        int i9 = paddingBottom;
        int i10 = 0;
        int i11 = paddingTop;
        int i12 = paddingLeft;
        for (int i13 = 0; i13 < childCount; i13++) {
            View childAt = getChildAt(i13);
            if (childAt.getVisibility() != 8) {
                C0686e eVar = (C0686e) childAt.getLayoutParams();
                if (eVar.f5314a) {
                    int i14 = eVar.f5315b;
                    int i15 = i14 & 7;
                    int i16 = i14 & 112;
                    if (i15 == 1) {
                        i5 = Math.max((i7 - childAt.getMeasuredWidth()) / 2, i12);
                    } else if (i15 == 3) {
                        i5 = i12;
                        i12 = childAt.getMeasuredWidth() + i12;
                    } else if (i15 != 5) {
                        i5 = i12;
                    } else {
                        i5 = (i7 - paddingRight) - childAt.getMeasuredWidth();
                        paddingRight += childAt.getMeasuredWidth();
                    }
                    if (i16 == 16) {
                        i6 = Math.max((i8 - childAt.getMeasuredHeight()) / 2, i11);
                    } else if (i16 == 48) {
                        i6 = i11;
                        i11 = childAt.getMeasuredHeight() + i11;
                    } else if (i16 != 80) {
                        i6 = i11;
                    } else {
                        i6 = (i8 - i9) - childAt.getMeasuredHeight();
                        i9 += childAt.getMeasuredHeight();
                    }
                    int i17 = i5 + scrollX;
                    childAt.layout(i17, i6, childAt.getMeasuredWidth() + i17, childAt.getMeasuredHeight() + i6);
                    i10++;
                }
            }
        }
        int i18 = (i7 - i12) - paddingRight;
        for (int i19 = 0; i19 < childCount; i19++) {
            View childAt2 = getChildAt(i19);
            if (childAt2.getVisibility() != 8) {
                C0686e eVar2 = (C0686e) childAt2.getLayoutParams();
                if (!eVar2.f5314a && (a = mo5563a(childAt2)) != null) {
                    float f = (float) i18;
                    int i20 = ((int) (a.f5313e * f)) + i12;
                    if (eVar2.f5317d) {
                        eVar2.f5317d = false;
                        childAt2.measure(View.MeasureSpec.makeMeasureSpec((int) (f * eVar2.f5316c), 1073741824), View.MeasureSpec.makeMeasureSpec((i8 - i11) - i9, 1073741824));
                    }
                    childAt2.layout(i20, i11, childAt2.getMeasuredWidth() + i20, childAt2.getMeasuredHeight() + i11);
                }
            }
        }
        this.f5295m0 = i11;
        this.f5296n0 = i8 - i9;
        this.f5274M0 = i10;
        if (this.f5272K0) {
            z2 = false;
            mo5568a(this.f5287e0, false, 0, false);
        } else {
            z2 = false;
        }
        this.f5272K0 = z2;
    }

    /* JADX WARNING: Removed duplicated region for block: B:28:0x0084  */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x008b  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x0090  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x0095  */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x00a4  */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x00aa  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r14, int r15) {
        /*
            r13 = this;
            r0 = 0
            int r14 = android.view.ViewGroup.getDefaultSize(r0, r14)
            int r15 = android.view.ViewGroup.getDefaultSize(r0, r15)
            r13.setMeasuredDimension(r14, r15)
            int r14 = r13.getMeasuredWidth()
            int r15 = r14 / 10
            int r1 = r13.f5306x0
            int r15 = java.lang.Math.min(r15, r1)
            r13.f5307y0 = r15
            int r15 = r13.getPaddingLeft()
            int r14 = r14 - r15
            int r15 = r13.getPaddingRight()
            int r14 = r14 - r15
            int r15 = r13.getMeasuredHeight()
            int r1 = r13.getPaddingTop()
            int r15 = r15 - r1
            int r1 = r13.getPaddingBottom()
            int r15 = r15 - r1
            int r1 = r13.getChildCount()
            r2 = r15
            r15 = r14
            r14 = 0
        L_0x0039:
            r3 = 8
            r4 = 1
            r5 = 1073741824(0x40000000, float:2.0)
            if (r14 >= r1) goto L_0x00b4
            android.view.View r6 = r13.getChildAt(r14)
            int r7 = r6.getVisibility()
            if (r7 == r3) goto L_0x00b1
            android.view.ViewGroup$LayoutParams r3 = r6.getLayoutParams()
            ff$e r3 = (p000.C0681ff.C0686e) r3
            if (r3 == 0) goto L_0x00b1
            boolean r7 = r3.f5314a
            if (r7 == 0) goto L_0x00b1
            int r7 = r3.f5315b
            r8 = r7 & 7
            r7 = r7 & 112(0x70, float:1.57E-43)
            r9 = 48
            if (r7 == r9) goto L_0x0067
            r9 = 80
            if (r7 != r9) goto L_0x0065
            goto L_0x0067
        L_0x0065:
            r7 = 0
            goto L_0x0068
        L_0x0067:
            r7 = 1
        L_0x0068:
            r9 = 3
            if (r8 == r9) goto L_0x0070
            r9 = 5
            if (r8 != r9) goto L_0x006f
            goto L_0x0070
        L_0x006f:
            r4 = 0
        L_0x0070:
            r8 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r7 == 0) goto L_0x0077
            r8 = 1073741824(0x40000000, float:2.0)
            goto L_0x007c
        L_0x0077:
            if (r4 == 0) goto L_0x007c
            r9 = 1073741824(0x40000000, float:2.0)
            goto L_0x007e
        L_0x007c:
            r9 = -2147483648(0xffffffff80000000, float:-0.0)
        L_0x007e:
            int r10 = r3.width
            r11 = -1
            r12 = -2
            if (r10 == r12) goto L_0x008b
            if (r10 == r11) goto L_0x0087
            goto L_0x0088
        L_0x0087:
            r10 = r15
        L_0x0088:
            r8 = 1073741824(0x40000000, float:2.0)
            goto L_0x008c
        L_0x008b:
            r10 = r15
        L_0x008c:
            int r3 = r3.height
            if (r3 == r12) goto L_0x0095
            if (r3 == r11) goto L_0x0093
            goto L_0x0097
        L_0x0093:
            r3 = r2
            goto L_0x0097
        L_0x0095:
            r3 = r2
            r5 = r9
        L_0x0097:
            int r8 = android.view.View.MeasureSpec.makeMeasureSpec(r10, r8)
            int r3 = android.view.View.MeasureSpec.makeMeasureSpec(r3, r5)
            r6.measure(r8, r3)
            if (r7 == 0) goto L_0x00aa
            int r3 = r6.getMeasuredHeight()
            int r2 = r2 - r3
            goto L_0x00b1
        L_0x00aa:
            if (r4 == 0) goto L_0x00b1
            int r3 = r6.getMeasuredWidth()
            int r15 = r15 - r3
        L_0x00b1:
            int r14 = r14 + 1
            goto L_0x0039
        L_0x00b4:
            android.view.View.MeasureSpec.makeMeasureSpec(r15, r5)
            int r14 = android.view.View.MeasureSpec.makeMeasureSpec(r2, r5)
            r13.f5299q0 = r14
            r13.f5300r0 = r4
            r13.mo5592d()
            r13.f5300r0 = r0
            int r14 = r13.getChildCount()
        L_0x00c8:
            if (r0 >= r14) goto L_0x00f2
            android.view.View r1 = r13.getChildAt(r0)
            int r2 = r1.getVisibility()
            if (r2 == r3) goto L_0x00ef
            android.view.ViewGroup$LayoutParams r2 = r1.getLayoutParams()
            ff$e r2 = (p000.C0681ff.C0686e) r2
            if (r2 == 0) goto L_0x00e0
            boolean r4 = r2.f5314a
            if (r4 != 0) goto L_0x00ef
        L_0x00e0:
            float r4 = (float) r15
            float r2 = r2.f5316c
            float r4 = r4 * r2
            int r2 = (int) r4
            int r2 = android.view.View.MeasureSpec.makeMeasureSpec(r2, r5)
            int r4 = r13.f5299q0
            r1.measure(r2, r4)
        L_0x00ef:
            int r0 = r0 + 1
            goto L_0x00c8
        L_0x00f2:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0681ff.onMeasure(int, int):void");
    }

    public boolean onRequestFocusInDescendants(int i, Rect rect) {
        int i2;
        int i3;
        C0685d a;
        int childCount = getChildCount();
        int i4 = -1;
        if ((i & 2) != 0) {
            i4 = childCount;
            i3 = 0;
            i2 = 1;
        } else {
            i3 = childCount - 1;
            i2 = -1;
        }
        while (i3 != i4) {
            View childAt = getChildAt(i3);
            if (childAt.getVisibility() == 0 && (a = mo5563a(childAt)) != null && a.f5310b == this.f5287e0 && childAt.requestFocus(i, rect)) {
                return true;
            }
            i3 += i2;
        }
        return false;
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof C0689h)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        C0689h hVar = (C0689h) parcelable;
        super.onRestoreInstanceState(hVar.f14707X);
        this.f5288f0 = hVar.f5320Z;
        this.f5289g0 = hVar.f5321a0;
        this.f5290h0 = hVar.f5322b0;
    }

    public Parcelable onSaveInstanceState() {
        C0689h hVar = new C0689h(super.onSaveInstanceState());
        hVar.f5320Z = this.f5287e0;
        return hVar;
    }

    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        if (i != i3) {
            int i5 = this.f5293k0;
            mo5566a(i, i3, i5, i5);
        }
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (this.f5269H0) {
            return true;
        }
        if (!(motionEvent.getAction() == 0 && motionEvent.getEdgeFlags() == 0)) {
        }
        return false;
    }

    public void removeView(View view) {
        if (this.f5300r0) {
            removeViewInLayout(view);
        } else {
            super.removeView(view);
        }
    }

    public void setAdapter(C0603ef efVar) {
        this.f5283a0 = 0;
        List<C0687f> list = this.f5278Q0;
        if (list != null && !list.isEmpty()) {
            int size = this.f5278Q0.size();
            for (int i = 0; i < size; i++) {
                TabLayout.C0454c cVar = (TabLayout.C0454c) this.f5278Q0.get(i);
                TabLayout tabLayout = TabLayout.this;
                if (tabLayout.f3213H0 == this) {
                    tabLayout.mo3853a(efVar, cVar.f3246a);
                }
            }
        }
    }

    public void setCurrentItem(int i) {
        this.f5302t0 = false;
        mo5569a(i, !this.f5272K0, false);
    }

    public void setOffscreenPageLimit(int i) {
        if (i < 1) {
            Log.w("ViewPager", "Requested offscreen page limit " + i + " too small; defaulting to " + 1);
            i = 1;
        }
        if (i != this.f5303u0) {
            this.f5303u0 = i;
            mo5592d();
        }
    }

    @Deprecated
    public void setOnPageChangeListener(C0688g gVar) {
        this.f5276O0 = gVar;
    }

    public void setPageMargin(int i) {
        int i2 = this.f5293k0;
        this.f5293k0 = i;
        int width = getWidth();
        mo5566a(width, width, i, i2);
        requestLayout();
    }

    public void setPageMarginDrawable(int i) {
        setPageMarginDrawable(C2085v5.m14462c(getContext(), i));
    }

    public void setPageMarginDrawable(Drawable drawable) {
        this.f5294l0 = drawable;
        if (drawable != null) {
            refreshDrawableState();
        }
        setWillNotDraw(drawable == null);
        invalidate();
    }

    public void setScrollState(int i) {
        if (this.f5282U0 != i) {
            this.f5282U0 = i;
            C0688g gVar = this.f5276O0;
            if (gVar != null) {
                TabLayout.C0462i iVar = (TabLayout.C0462i) gVar;
                iVar.f3276b = iVar.f3277c;
                iVar.f3277c = i;
            }
            List<C0688g> list = this.f5275N0;
            if (list != null) {
                int size = list.size();
                for (int i2 = 0; i2 < size; i2++) {
                    C0688g gVar2 = this.f5275N0.get(i2);
                    if (gVar2 != null) {
                        TabLayout.C0462i iVar2 = (TabLayout.C0462i) gVar2;
                        iVar2.f3276b = iVar2.f3277c;
                        iVar2.f3277c = i;
                    }
                }
            }
            C0688g gVar3 = this.f5277P0;
            if (gVar3 != null) {
                TabLayout.C0462i iVar3 = (TabLayout.C0462i) gVar3;
                iVar3.f3276b = iVar3.f3277c;
                iVar3.f3277c = i;
            }
        }
    }

    public boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f5294l0;
    }
}
