package p000;

import android.annotation.SuppressLint;
import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@SuppressLint({"UnknownNullness"})
/* renamed from: ab */
public abstract class C0089ab {
    /* renamed from: a */
    public static void m338a(List<View> list, View view) {
        int size = list.size();
        if (!m340a(list, view, size)) {
            list.add(view);
            for (int i = size; i < list.size(); i++) {
                View view2 = list.get(i);
                if (view2 instanceof ViewGroup) {
                    ViewGroup viewGroup = (ViewGroup) view2;
                    int childCount = viewGroup.getChildCount();
                    for (int i2 = 0; i2 < childCount; i2++) {
                        View childAt = viewGroup.getChildAt(i2);
                        if (!m340a(list, childAt, size)) {
                            list.add(childAt);
                        }
                    }
                }
            }
        }
    }

    /* renamed from: a */
    public static boolean m339a(List list) {
        return list == null || list.isEmpty();
    }

    /* renamed from: a */
    public static boolean m340a(List<View> list, View view, int i) {
        for (int i2 = 0; i2 < i; i2++) {
            if (list.get(i2) == view) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: a */
    public abstract Object mo300a(Object obj, Object obj2, Object obj3);

    /* renamed from: a */
    public void mo301a(View view, Rect rect) {
        int[] iArr = new int[2];
        view.getLocationOnScreen(iArr);
        rect.set(iArr[0], iArr[1], view.getWidth() + iArr[0], view.getHeight() + iArr[1]);
    }

    /* renamed from: a */
    public abstract void mo302a(ViewGroup viewGroup, Object obj);

    /* renamed from: a */
    public abstract void mo303a(Object obj, Rect rect);

    /* renamed from: a */
    public abstract void mo304a(Object obj, View view);

    /* renamed from: a */
    public abstract void mo305a(Object obj, View view, ArrayList<View> arrayList);

    /* renamed from: a */
    public abstract void mo306a(Object obj, Object obj2, ArrayList<View> arrayList, Object obj3, ArrayList<View> arrayList2, Object obj4, ArrayList<View> arrayList3);

    /* renamed from: a */
    public abstract void mo307a(Object obj, ArrayList<View> arrayList);

    /* renamed from: a */
    public abstract void mo308a(Object obj, ArrayList<View> arrayList, ArrayList<View> arrayList2);

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v1, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v2, resolved type: android.view.ViewGroup} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r5v3, resolved type: android.view.ViewGroup} */
    /* JADX WARNING: Failed to insert additional move for type inference */
    /* JADX WARNING: Multi-variable type inference failed */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo309a(java.util.ArrayList<android.view.View> r4, android.view.View r5) {
        /*
            r3 = this;
            int r0 = r5.getVisibility()
            if (r0 != 0) goto L_0x004e
            boolean r0 = r5 instanceof android.view.ViewGroup
            if (r0 == 0) goto L_0x004b
            android.view.ViewGroup r5 = (android.view.ViewGroup) r5
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 21
            r2 = 0
            if (r0 < r1) goto L_0x0018
            boolean r0 = r5.isTransitionGroup()
            goto L_0x0038
        L_0x0018:
            int r0 = p000.C1498o5.tag_transition_group
            java.lang.Object r0 = r5.getTag(r0)
            java.lang.Boolean r0 = (java.lang.Boolean) r0
            if (r0 == 0) goto L_0x0028
            boolean r0 = r0.booleanValue()
            if (r0 != 0) goto L_0x0037
        L_0x0028:
            android.graphics.drawable.Drawable r0 = r5.getBackground()
            if (r0 != 0) goto L_0x0037
            java.lang.String r0 = p000.C2189w7.m15024s(r5)
            if (r0 == 0) goto L_0x0035
            goto L_0x0037
        L_0x0035:
            r0 = 0
            goto L_0x0038
        L_0x0037:
            r0 = 1
        L_0x0038:
            if (r0 == 0) goto L_0x003b
            goto L_0x004b
        L_0x003b:
            int r0 = r5.getChildCount()
        L_0x003f:
            if (r2 >= r0) goto L_0x004e
            android.view.View r1 = r5.getChildAt(r2)
            r3.mo309a((java.util.ArrayList<android.view.View>) r4, (android.view.View) r1)
            int r2 = r2 + 1
            goto L_0x003f
        L_0x004b:
            r4.add(r5)
        L_0x004e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0089ab.mo309a(java.util.ArrayList, android.view.View):void");
    }

    /* renamed from: a */
    public void mo310a(Map<String, View> map, View view) {
        if (view.getVisibility() == 0) {
            String s = C2189w7.m15024s(view);
            if (s != null) {
                map.put(s, view);
            }
            if (view instanceof ViewGroup) {
                ViewGroup viewGroup = (ViewGroup) view;
                int childCount = viewGroup.getChildCount();
                for (int i = 0; i < childCount; i++) {
                    mo310a(map, viewGroup.getChildAt(i));
                }
            }
        }
    }

    /* renamed from: a */
    public abstract boolean mo311a(Object obj);

    /* renamed from: b */
    public abstract Object mo312b(Object obj);

    /* renamed from: b */
    public abstract Object mo313b(Object obj, Object obj2, Object obj3);

    /* renamed from: b */
    public abstract void mo314b(Object obj, View view);

    /* renamed from: b */
    public abstract void mo315b(Object obj, View view, ArrayList<View> arrayList);

    /* renamed from: b */
    public abstract void mo316b(Object obj, ArrayList<View> arrayList, ArrayList<View> arrayList2);

    /* renamed from: c */
    public abstract Object mo317c(Object obj);

    /* renamed from: c */
    public abstract void mo318c(Object obj, View view);
}
