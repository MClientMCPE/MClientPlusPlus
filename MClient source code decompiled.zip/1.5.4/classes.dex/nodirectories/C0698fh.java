package p000;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.json.JSONArray;
import org.json.JSONObject;

/* renamed from: fh */
public class C0698fh {

    /* renamed from: a */
    public final int f5358a;

    /* renamed from: b */
    public final Map<String, ArrayList<C0699a>> f5359b = new ConcurrentHashMap();

    /* renamed from: fh$a */
    public static class C0699a {

        /* renamed from: a */
        public final String f5360a;

        /* renamed from: b */
        public final C0773gh f5361b;

        public /* synthetic */ C0699a(String str, C0773gh ghVar, C0612eh ehVar) {
            this.f5360a = str;
            this.f5361b = ghVar;
        }
    }

    public /* synthetic */ C0698fh(int i, C0612eh ehVar) {
        this.f5358a = i;
    }

    /* renamed from: a */
    public JSONObject mo5654a() {
        JSONObject jSONObject = new JSONObject();
        C0680fe.m4784a(jSONObject, "version", this.f5358a);
        for (Map.Entry next : this.f5359b.entrySet()) {
            JSONObject jSONObject2 = new JSONObject();
            Iterator it = ((ArrayList) next.getValue()).iterator();
            while (it.hasNext()) {
                C0699a aVar = (C0699a) it.next();
                JSONArray jSONArray = new JSONArray();
                for (String put : aVar.f5361b.mo6094a((Character) ',')) {
                    jSONArray.put(put);
                }
                C0680fe.m4786a(jSONObject2, aVar.f5360a, jSONArray);
            }
            C0680fe.m4787a(jSONObject, (String) next.getKey(), jSONObject2);
        }
        return jSONObject;
    }

    /* renamed from: a */
    public final void mo5655a(String str, String str2, C0773gh ghVar) {
        ArrayList arrayList;
        C0699a aVar = new C0699a(str2, ghVar, (C0612eh) null);
        if (!this.f5359b.containsKey(str) || (arrayList = this.f5359b.get(str)) == null) {
            this.f5359b.put(str, new ArrayList(Collections.singletonList(aVar)));
        } else {
            arrayList.add(aVar);
        }
    }
}
