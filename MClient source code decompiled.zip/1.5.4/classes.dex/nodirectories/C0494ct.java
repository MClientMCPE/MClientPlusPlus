package p000;

import android.content.Context;
import android.os.HandlerThread;
import java.util.concurrent.LinkedBlockingQueue;
import p000.C1173kq;
import p000.ky0;

/* renamed from: ct */
public final class C0494ct implements C1173kq.C1174a, C1173kq.C1175b {

    /* renamed from: a */
    public C1637ps f3530a;

    /* renamed from: b */
    public final String f3531b;

    /* renamed from: c */
    public final String f3532c;

    /* renamed from: d */
    public final LinkedBlockingQueue<ky0> f3533d;

    /* renamed from: e */
    public final HandlerThread f3534e = new HandlerThread("GassClient");

    public C0494ct(Context context, String str, String str2) {
        this.f3531b = str;
        this.f3532c = str2;
        this.f3534e.start();
        this.f3530a = new C1637ps(context, this.f3534e.getLooper(), this, this);
        this.f3533d = new LinkedBlockingQueue<>();
        this.f3530a.mo8069a();
    }

    /* renamed from: b */
    public static ky0 m3253b() {
        ky0.C1197b o = ky0.m8408o();
        o.mo8169d(32768);
        return (ky0) o.mo9639i();
    }

    /* renamed from: a */
    public final void mo4472a() {
        C1637ps psVar = this.f3530a;
        if (psVar == null) {
            return;
        }
        if (psVar.mo8081i() || this.f3530a.mo8082j()) {
            this.f3530a.mo8076b();
        }
    }

    /* renamed from: a */
    public final void mo4473a(int i) {
        try {
            this.f3533d.put(m3253b());
        } catch (InterruptedException unused) {
        }
    }

    /* JADX WARNING: Missing exception handler attribute for start block: B:21:0x0062 */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo395a(android.os.Bundle r6) {
        /*
            r5 = this;
            r6 = 0
            ps r0 = r5.f3530a     // Catch:{ DeadObjectException | IllegalStateException -> 0x0008 }
            ss r0 = r0.mo10109m()     // Catch:{ DeadObjectException | IllegalStateException -> 0x0008 }
            goto L_0x0009
        L_0x0008:
            r0 = r6
        L_0x0009:
            if (r0 == 0) goto L_0x0076
            os r1 = new os     // Catch:{ all -> 0x0062 }
            java.lang.String r2 = r5.f3531b     // Catch:{ all -> 0x0062 }
            java.lang.String r3 = r5.f3532c     // Catch:{ all -> 0x0062 }
            r4 = 1
            r1.<init>(r4, r2, r3)     // Catch:{ all -> 0x0062 }
            us r0 = (p000.C2068us) r0     // Catch:{ all -> 0x0062 }
            android.os.Parcel r2 = r0.mo10675a()     // Catch:{ all -> 0x0062 }
            p000.sj2.m12849a((android.os.Parcel) r2, (android.os.Parcelable) r1)     // Catch:{ all -> 0x0062 }
            android.os.Parcel r0 = r0.mo10676a(r4, r2)     // Catch:{ all -> 0x0062 }
            android.os.Parcelable$Creator<qs> r1 = p000.C1715qs.CREATOR     // Catch:{ all -> 0x0062 }
            android.os.Parcelable r1 = p000.sj2.m12847a((android.os.Parcel) r0, r1)     // Catch:{ all -> 0x0062 }
            qs r1 = (p000.C1715qs) r1     // Catch:{ all -> 0x0062 }
            r0.recycle()     // Catch:{ all -> 0x0062 }
            ky0 r0 = r1.f13219Y     // Catch:{ all -> 0x0062 }
            if (r0 == 0) goto L_0x0032
            goto L_0x0033
        L_0x0032:
            r4 = 0
        L_0x0033:
            if (r4 != 0) goto L_0x004f
            byte[] r0 = r1.f13220Z     // Catch:{ zc2 -> 0x0048 }
            cc2 r2 = p000.cc2.m2430b()     // Catch:{ zc2 -> 0x0048 }
            ky0 r3 = p000.ky0.zzht     // Catch:{ zc2 -> 0x0048 }
            oc2 r0 = p000.oc2.m10404a(r3, (byte[]) r0, (p000.cc2) r2)     // Catch:{ zc2 -> 0x0048 }
            ky0 r0 = (p000.ky0) r0     // Catch:{ zc2 -> 0x0048 }
            r1.f13219Y = r0     // Catch:{ zc2 -> 0x0048 }
            r1.f13220Z = r6     // Catch:{ zc2 -> 0x0048 }
            goto L_0x004f
        L_0x0048:
            r6 = move-exception
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException     // Catch:{ all -> 0x0062 }
            r0.<init>(r6)     // Catch:{ all -> 0x0062 }
            throw r0     // Catch:{ all -> 0x0062 }
        L_0x004f:
            r1.mo10439a()     // Catch:{ all -> 0x0062 }
            ky0 r6 = r1.f13219Y     // Catch:{ all -> 0x0062 }
            java.util.concurrent.LinkedBlockingQueue<ky0> r0 = r5.f3533d     // Catch:{ all -> 0x0062 }
            r0.put(r6)     // Catch:{ all -> 0x0062 }
        L_0x0059:
            r5.mo4472a()
            android.os.HandlerThread r6 = r5.f3534e
            r6.quit()
            return
        L_0x0062:
            java.util.concurrent.LinkedBlockingQueue<ky0> r6 = r5.f3533d     // Catch:{ InterruptedException -> 0x0059, all -> 0x006c }
            ky0 r0 = m3253b()     // Catch:{ InterruptedException -> 0x0059, all -> 0x006c }
            r6.put(r0)     // Catch:{ InterruptedException -> 0x0059, all -> 0x006c }
            goto L_0x0059
        L_0x006c:
            r6 = move-exception
            r5.mo4472a()
            android.os.HandlerThread r0 = r5.f3534e
            r0.quit()
            throw r6
        L_0x0076:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0494ct.mo395a(android.os.Bundle):void");
    }

    /* renamed from: a */
    public final void mo396a(C2230wp wpVar) {
        try {
            this.f3533d.put(m3253b());
        } catch (InterruptedException unused) {
        }
    }
}
