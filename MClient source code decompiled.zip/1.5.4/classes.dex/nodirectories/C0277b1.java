package p000;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.view.ActionProvider;
import android.view.ContextMenu;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

/* renamed from: b1 */
public class C0277b1 implements C1800s6 {

    /* renamed from: a */
    public final int f1613a;

    /* renamed from: b */
    public final int f1614b;

    /* renamed from: c */
    public final int f1615c;

    /* renamed from: d */
    public CharSequence f1616d;

    /* renamed from: e */
    public CharSequence f1617e;

    /* renamed from: f */
    public Intent f1618f;

    /* renamed from: g */
    public char f1619g;

    /* renamed from: h */
    public int f1620h = 4096;

    /* renamed from: i */
    public char f1621i;

    /* renamed from: j */
    public int f1622j = 4096;

    /* renamed from: k */
    public Drawable f1623k;

    /* renamed from: l */
    public Context f1624l;

    /* renamed from: m */
    public CharSequence f1625m;

    /* renamed from: n */
    public CharSequence f1626n;

    /* renamed from: o */
    public ColorStateList f1627o = null;

    /* renamed from: p */
    public PorterDuff.Mode f1628p = null;

    /* renamed from: q */
    public boolean f1629q = false;

    /* renamed from: r */
    public boolean f1630r = false;

    /* renamed from: s */
    public int f1631s = 16;

    public C0277b1(Context context, int i, int i2, int i3, int i4, CharSequence charSequence) {
        this.f1624l = context;
        this.f1613a = i2;
        this.f1614b = i;
        this.f1615c = i4;
        this.f1616d = charSequence;
    }

    /* renamed from: a */
    public C0831h7 mo2220a() {
        return null;
    }

    /* renamed from: a */
    public C1800s6 mo2221a(C0831h7 h7Var) {
        throw new UnsupportedOperationException();
    }

    /* renamed from: b */
    public final void mo2222b() {
        if (this.f1623k == null) {
            return;
        }
        if (this.f1629q || this.f1630r) {
            this.f1623k = C0815h0.m5858e(this.f1623k);
            this.f1623k = this.f1623k.mutate();
            if (this.f1629q) {
                C0815h0.m5802a(this.f1623k, this.f1627o);
            }
            if (this.f1630r) {
                C0815h0.m5803a(this.f1623k, this.f1628p);
            }
        }
    }

    public boolean collapseActionView() {
        return false;
    }

    public boolean expandActionView() {
        return false;
    }

    public ActionProvider getActionProvider() {
        throw new UnsupportedOperationException();
    }

    public View getActionView() {
        return null;
    }

    public int getAlphabeticModifiers() {
        return this.f1622j;
    }

    public char getAlphabeticShortcut() {
        return this.f1621i;
    }

    public CharSequence getContentDescription() {
        return this.f1625m;
    }

    public int getGroupId() {
        return this.f1614b;
    }

    public Drawable getIcon() {
        return this.f1623k;
    }

    public ColorStateList getIconTintList() {
        return this.f1627o;
    }

    public PorterDuff.Mode getIconTintMode() {
        return this.f1628p;
    }

    public Intent getIntent() {
        return this.f1618f;
    }

    public int getItemId() {
        return this.f1613a;
    }

    public ContextMenu.ContextMenuInfo getMenuInfo() {
        return null;
    }

    public int getNumericModifiers() {
        return this.f1620h;
    }

    public char getNumericShortcut() {
        return this.f1619g;
    }

    public int getOrder() {
        return this.f1615c;
    }

    public SubMenu getSubMenu() {
        return null;
    }

    public CharSequence getTitle() {
        return this.f1616d;
    }

    public CharSequence getTitleCondensed() {
        CharSequence charSequence = this.f1617e;
        return charSequence != null ? charSequence : this.f1616d;
    }

    public CharSequence getTooltipText() {
        return this.f1626n;
    }

    public boolean hasSubMenu() {
        return false;
    }

    public boolean isActionViewExpanded() {
        return false;
    }

    public boolean isCheckable() {
        return (this.f1631s & 1) != 0;
    }

    public boolean isChecked() {
        return (this.f1631s & 2) != 0;
    }

    public boolean isEnabled() {
        return (this.f1631s & 16) != 0;
    }

    public boolean isVisible() {
        return (this.f1631s & 8) == 0;
    }

    public MenuItem setActionProvider(ActionProvider actionProvider) {
        throw new UnsupportedOperationException();
    }

    public MenuItem setActionView(int i) {
        throw new UnsupportedOperationException();
    }

    public MenuItem setAlphabeticShortcut(char c) {
        this.f1621i = Character.toLowerCase(c);
        return this;
    }

    public MenuItem setAlphabeticShortcut(char c, int i) {
        this.f1621i = Character.toLowerCase(c);
        this.f1622j = KeyEvent.normalizeMetaState(i);
        return this;
    }

    public MenuItem setCheckable(boolean z) {
        this.f1631s = z | (this.f1631s & true) ? 1 : 0;
        return this;
    }

    public MenuItem setChecked(boolean z) {
        this.f1631s = (z ? 2 : 0) | (this.f1631s & -3);
        return this;
    }

    public MenuItem setContentDescription(CharSequence charSequence) {
        this.f1625m = charSequence;
        return this;
    }

    /* renamed from: setContentDescription  reason: collision with other method in class */
    public C1800s6 m17482setContentDescription(CharSequence charSequence) {
        this.f1625m = charSequence;
        return this;
    }

    public MenuItem setEnabled(boolean z) {
        this.f1631s = (z ? 16 : 0) | (this.f1631s & -17);
        return this;
    }

    public MenuItem setIcon(int i) {
        this.f1623k = C2085v5.m14462c(this.f1624l, i);
        mo2222b();
        return this;
    }

    public MenuItem setIcon(Drawable drawable) {
        this.f1623k = drawable;
        mo2222b();
        return this;
    }

    public MenuItem setIconTintList(ColorStateList colorStateList) {
        this.f1627o = colorStateList;
        this.f1629q = true;
        mo2222b();
        return this;
    }

    public MenuItem setIconTintMode(PorterDuff.Mode mode) {
        this.f1628p = mode;
        this.f1630r = true;
        mo2222b();
        return this;
    }

    public MenuItem setIntent(Intent intent) {
        this.f1618f = intent;
        return this;
    }

    public MenuItem setNumericShortcut(char c) {
        this.f1619g = c;
        return this;
    }

    public MenuItem setNumericShortcut(char c, int i) {
        this.f1619g = c;
        this.f1620h = KeyEvent.normalizeMetaState(i);
        return this;
    }

    public MenuItem setOnActionExpandListener(MenuItem.OnActionExpandListener onActionExpandListener) {
        throw new UnsupportedOperationException();
    }

    public MenuItem setOnMenuItemClickListener(MenuItem.OnMenuItemClickListener onMenuItemClickListener) {
        return this;
    }

    public MenuItem setShortcut(char c, char c2) {
        this.f1619g = c;
        this.f1621i = Character.toLowerCase(c2);
        return this;
    }

    public MenuItem setShortcut(char c, char c2, int i, int i2) {
        this.f1619g = c;
        this.f1620h = KeyEvent.normalizeMetaState(i);
        this.f1621i = Character.toLowerCase(c2);
        this.f1622j = KeyEvent.normalizeMetaState(i2);
        return this;
    }

    public void setShowAsAction(int i) {
    }

    public MenuItem setShowAsActionFlags(int i) {
        return this;
    }

    public MenuItem setTitle(int i) {
        this.f1616d = this.f1624l.getResources().getString(i);
        return this;
    }

    public MenuItem setTitle(CharSequence charSequence) {
        this.f1616d = charSequence;
        return this;
    }

    public MenuItem setTitleCondensed(CharSequence charSequence) {
        this.f1617e = charSequence;
        return this;
    }

    public MenuItem setTooltipText(CharSequence charSequence) {
        this.f1626n = charSequence;
        return this;
    }

    /* renamed from: setTooltipText  reason: collision with other method in class */
    public C1800s6 m17483setTooltipText(CharSequence charSequence) {
        this.f1626n = charSequence;
        return this;
    }

    public MenuItem setVisible(boolean z) {
        int i = 8;
        int i2 = this.f1631s & 8;
        if (z) {
            i = 0;
        }
        this.f1631s = i2 | i;
        return this;
    }

    public MenuItem setActionView(View view) {
        throw new UnsupportedOperationException();
    }
}
