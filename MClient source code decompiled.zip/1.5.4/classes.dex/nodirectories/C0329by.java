package p000;

import java.util.Map;

/* renamed from: by */
public final /* synthetic */ class C0329by implements C1373my {

    /* renamed from: a */
    public static final C1373my f2393a = new C0329by();

    /* renamed from: a */
    public final void mo2197a(Object obj, Map map) {
        C2476zx.m17354b((wk0) obj, map);
    }
}
