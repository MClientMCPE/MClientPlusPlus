package p000;

/* renamed from: a3 */
public interface C0035a3 {
}
