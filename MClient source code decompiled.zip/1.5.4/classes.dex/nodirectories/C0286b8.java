package p000;

import android.view.View;

/* renamed from: b8 */
public interface C0286b8 {
    /* renamed from: a */
    void mo172a(View view);

    /* renamed from: b */
    void mo61b(View view);

    /* renamed from: c */
    void mo173c(View view);
}
