package p000;

import android.content.Context;
import android.util.DisplayMetrics;

/* renamed from: gl */
public final class C0790gl {

    /* renamed from: g */
    public static final C0790gl f6204g = new C0790gl(320, 50, "320x50_mb");

    /* renamed from: h */
    public static final C0790gl f6205h = new C0790gl(468, 60, "468x60_as");

    /* renamed from: i */
    public static final C0790gl f6206i = new C0790gl(320, 100, "320x100_as");

    /* renamed from: j */
    public static final C0790gl f6207j = new C0790gl(728, 90, "728x90_as");

    /* renamed from: k */
    public static final C0790gl f6208k = new C0790gl(300, 250, "300x250_as");

    /* renamed from: l */
    public static final C0790gl f6209l = new C0790gl(160, 600, "160x600_as");

    /* renamed from: m */
    public static final C0790gl f6210m = new C0790gl(-1, -2, "smart_banner");

    /* renamed from: n */
    public static final C0790gl f6211n = new C0790gl(-3, -4, "fluid");

    /* renamed from: o */
    public static final C0790gl f6212o = new C0790gl(0, 0, "invalid");

    /* renamed from: p */
    public static final C0790gl f6213p = new C0790gl(50, 50, "50x50_mb");

    /* renamed from: a */
    public final int f6214a;

    /* renamed from: b */
    public final int f6215b;

    /* renamed from: c */
    public final String f6216c;

    /* renamed from: d */
    public boolean f6217d;

    /* renamed from: e */
    public boolean f6218e;

    /* renamed from: f */
    public int f6219f;

    static {
        new C0790gl(-3, 0, "search_v2");
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public C0790gl(int r5, int r6) {
        /*
            r4 = this;
            r0 = -1
            if (r5 != r0) goto L_0x0006
            java.lang.String r0 = "FULL"
            goto L_0x000a
        L_0x0006:
            java.lang.String r0 = java.lang.String.valueOf(r5)
        L_0x000a:
            r1 = -2
            if (r6 != r1) goto L_0x0010
            java.lang.String r1 = "AUTO"
            goto L_0x0014
        L_0x0010:
            java.lang.String r1 = java.lang.String.valueOf(r6)
        L_0x0014:
            r2 = 4
            int r2 = p000.C0789gk.m5548a((java.lang.String) r0, (int) r2)
            int r2 = p000.C0789gk.m5548a((java.lang.String) r1, (int) r2)
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>(r2)
            r3.append(r0)
            java.lang.String r0 = "x"
            r3.append(r0)
            r3.append(r1)
            java.lang.String r0 = "_as"
            r3.append(r0)
            java.lang.String r0 = r3.toString()
            r4.<init>(r5, r6, r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0790gl.<init>(int, int):void");
    }

    public C0790gl(int i, int i2, String str) {
        if (i < 0 && i != -1 && i != -3) {
            throw new IllegalArgumentException(C0789gk.m5551a(37, "Invalid width for AdSize: ", i));
        } else if (i2 >= 0 || i2 == -2 || i2 == -4) {
            this.f6214a = i;
            this.f6215b = i2;
            this.f6216c = str;
        } else {
            throw new IllegalArgumentException(C0789gk.m5551a(38, "Invalid height for AdSize: ", i2));
        }
    }

    /* renamed from: a */
    public final int mo6129a(Context context) {
        int i = this.f6215b;
        if (i == -4 || i == -3) {
            return -1;
        }
        if (i != -2) {
            af0 af0 = kw2.f9317j.f9318a;
            return af0.m467a(context.getResources().getDisplayMetrics(), i);
        }
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        return (int) (((float) tv2.m13628b(displayMetrics)) * displayMetrics.density);
    }

    /* renamed from: b */
    public final int mo6130b(Context context) {
        int i = this.f6214a;
        if (i == -4 || i == -3) {
            return -1;
        }
        if (i == -1) {
            return tv2.m13626a(context.getResources().getDisplayMetrics());
        }
        af0 af0 = kw2.f9317j.f9318a;
        return af0.m467a(context.getResources().getDisplayMetrics(), i);
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C0790gl)) {
            return false;
        }
        C0790gl glVar = (C0790gl) obj;
        return this.f6214a == glVar.f6214a && this.f6215b == glVar.f6215b && this.f6216c.equals(glVar.f6216c);
    }

    public final int hashCode() {
        return this.f6216c.hashCode();
    }

    public final String toString() {
        return this.f6216c;
    }
}
