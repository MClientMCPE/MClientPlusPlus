package p000;

/* renamed from: fu */
public final class C0720fu {

    /* renamed from: a */
    public static C1878st<String> f5564a = C1878st.m12904a("gads:afs:csa:experiment_id", "");

    /* renamed from: b */
    public static C1878st<String> f5565b = C1878st.m12904a("gads:app_index:experiment_id", "");

    /* renamed from: c */
    public static C1878st<String> f5566c = C1878st.m12904a("gads:block_autoclicks_experiment_id", "");

    /* renamed from: d */
    public static C1878st<String> f5567d = C1878st.m12904a("gads:sdk_core_experiment_id", "");

    /* renamed from: e */
    public static C1878st<String> f5568e = C1878st.m12904a("gads:spam_app_context:experiment_id", "");

    /* renamed from: f */
    public static C1878st<String> f5569f = C1878st.m12904a("gads:temporary_experiment_id:1", "");

    /* renamed from: g */
    public static C1878st<String> f5570g = C1878st.m12904a("gads:temporary_experiment_id:2", "");

    /* renamed from: h */
    public static C1878st<String> f5571h = C1878st.m12904a("gads:temporary_experiment_id:3", "");

    /* renamed from: i */
    public static C1878st<String> f5572i = C1878st.m12904a("gads:temporary_experiment_id:4", "");

    /* renamed from: j */
    public static C1878st<String> f5573j = C1878st.m12904a("gads:temporary_experiment_id:5", "");

    /* renamed from: k */
    public static C1878st<String> f5574k = C1878st.m12904a("gads:corewebview:experiment_id", "");
}
