package p000;

/* renamed from: bu */
public final class C0322bu {

    /* renamed from: a */
    public static C1878st<Boolean> f2346a = C1878st.m12905a("gads:debug_logging_feature:enable", false);

    /* renamed from: b */
    public static C1878st<Boolean> f2347b = C1878st.m12905a("gads:debug_logging_feature:intercept_web_view", false);
}
