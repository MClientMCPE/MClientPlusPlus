package p000;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.util.Log;

/* renamed from: g6 */
public class C0755g6 {

    /* renamed from: a */
    public static final C1221l6 f5986a;

    /* renamed from: b */
    public static final C0581e5<String, Typeface> f5987b = new C0581e5<>(16);

    static {
        C1221l6 l6Var;
        int i = Build.VERSION.SDK_INT;
        if (i >= 28) {
            l6Var = new C1129k6();
        } else if (i >= 26) {
            l6Var = new C0989j6();
        } else {
            if (i >= 24) {
                if (C0907i6.f7203d == null) {
                    Log.w("TypefaceCompatApi24Impl", "Unable to collect necessary private methods.Fallback to legacy implementation.");
                }
                if (C0907i6.f7203d != null) {
                    l6Var = new C0907i6();
                }
            }
            l6Var = Build.VERSION.SDK_INT >= 21 ? new C0830h6() : new C1221l6();
        }
        f5986a = l6Var;
    }

    /* renamed from: a */
    public static Typeface m5362a(Context context, Resources resources, int i, String str, int i2) {
        Typeface a = f5986a.mo7426a(context, resources, i, str, i2);
        if (a != null) {
            f5987b.mo5033a(m5365a(resources, i, i2), a);
        }
        return a;
    }

    /* renamed from: a */
    public static Typeface m5363a(Context context, Typeface typeface, int i) {
        if (context != null) {
            if (Build.VERSION.SDK_INT < 21) {
                C2326y5 a = f5986a.mo8298a(typeface);
                Typeface a2 = a == null ? null : f5986a.mo6428a(context, a, context.getResources(), i);
                if (a2 != null) {
                    return a2;
                }
            }
            return Typeface.create(typeface, i);
        }
        throw new IllegalArgumentException("Context cannot be null");
    }

    /* renamed from: a */
    public static String m5365a(Resources resources, int i, int i2) {
        return resources.getResourcePackageName(i) + "-" + i + "-" + i2;
    }

    /* renamed from: a */
    public static Typeface m5364a(Context context, C2255x5 x5Var, Resources resources, int i, int i2, C0517d6 d6Var, Handler handler, boolean z) {
        Typeface typeface;
        if (x5Var instanceof C0044a6) {
            C0044a6 a6Var = (C0044a6) x5Var;
            boolean z2 = false;
            if (!z ? d6Var == null : a6Var.f205c == 0) {
                z2 = true;
            }
            typeface = C2087v6.m14469a(context, a6Var.f203a, d6Var, handler, z2, z ? a6Var.f204b : -1, i2);
        } else {
            typeface = f5986a.mo6428a(context, (C2326y5) x5Var, resources, i2);
            if (d6Var != null) {
                if (typeface != null) {
                    d6Var.mo4681a(typeface, handler);
                } else {
                    d6Var.mo4679a(-3, handler);
                }
            }
        }
        if (typeface != null) {
            f5987b.mo5033a(m5365a(resources, i, i2), typeface);
        }
        return typeface;
    }
}
