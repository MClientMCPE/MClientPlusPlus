package p000;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.CheckBox;

/* renamed from: e2 */
public class C0576e2 extends CheckBox implements C1405n8, C2097v7 {

    /* renamed from: a0 */
    public final C0747g2 f4230a0;

    /* renamed from: b0 */
    public final C0334c2 f4231b0;

    /* renamed from: c0 */
    public final C2176w2 f4232c0;

    public C0576e2(Context context) {
        this(context, (AttributeSet) null);
    }

    public C0576e2(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0502d.checkboxStyle);
    }

    public C0576e2(Context context, AttributeSet attributeSet, int i) {
        super(C2083v3.m14434a(context), attributeSet, i);
        this.f4230a0 = new C0747g2(this);
        this.f4230a0.mo5862a(attributeSet, i);
        this.f4231b0 = new C0334c2(this);
        this.f4231b0.mo2717a(attributeSet, i);
        this.f4232c0 = new C2176w2(this);
        this.f4232c0.mo12087a(attributeSet, i);
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        C0334c2 c2Var = this.f4231b0;
        if (c2Var != null) {
            c2Var.mo2713a();
        }
        C2176w2 w2Var = this.f4232c0;
        if (w2Var != null) {
            w2Var.mo12081a();
        }
    }

    public int getCompoundPaddingLeft() {
        int compoundPaddingLeft = super.getCompoundPaddingLeft();
        if (this.f4230a0 != null) {
            int i = Build.VERSION.SDK_INT;
        }
        return compoundPaddingLeft;
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0334c2 c2Var = this.f4231b0;
        if (c2Var != null) {
            return c2Var.mo2718b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0334c2 c2Var = this.f4231b0;
        if (c2Var != null) {
            return c2Var.mo2720c();
        }
        return null;
    }

    public ColorStateList getSupportButtonTintList() {
        C0747g2 g2Var = this.f4230a0;
        if (g2Var != null) {
            return g2Var.f5904b;
        }
        return null;
    }

    public PorterDuff.Mode getSupportButtonTintMode() {
        C0747g2 g2Var = this.f4230a0;
        if (g2Var != null) {
            return g2Var.f5905c;
        }
        return null;
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0334c2 c2Var = this.f4231b0;
        if (c2Var != null) {
            c2Var.mo2721d();
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C0334c2 c2Var = this.f4231b0;
        if (c2Var != null) {
            c2Var.mo2714a(i);
        }
    }

    public void setButtonDrawable(int i) {
        setButtonDrawable(C1206l0.m8461c(getContext(), i));
    }

    public void setButtonDrawable(Drawable drawable) {
        super.setButtonDrawable(drawable);
        C0747g2 g2Var = this.f4230a0;
        if (g2Var == null) {
            return;
        }
        if (g2Var.f5908f) {
            g2Var.f5908f = false;
            return;
        }
        g2Var.f5908f = true;
        g2Var.mo5861a();
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0334c2 c2Var = this.f4231b0;
        if (c2Var != null) {
            c2Var.mo2719b(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0334c2 c2Var = this.f4231b0;
        if (c2Var != null) {
            c2Var.mo2716a(mode);
        }
    }

    public void setSupportButtonTintList(ColorStateList colorStateList) {
        C0747g2 g2Var = this.f4230a0;
        if (g2Var != null) {
            g2Var.f5904b = colorStateList;
            g2Var.f5906d = true;
            g2Var.mo5861a();
        }
    }

    public void setSupportButtonTintMode(PorterDuff.Mode mode) {
        C0747g2 g2Var = this.f4230a0;
        if (g2Var != null) {
            g2Var.f5905c = mode;
            g2Var.f5907e = true;
            g2Var.mo5861a();
        }
    }
}
