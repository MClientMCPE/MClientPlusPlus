package p000;

/* renamed from: df */
public interface C0535df {
}
