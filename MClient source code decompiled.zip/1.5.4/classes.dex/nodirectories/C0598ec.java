package p000;

/* renamed from: ec */
public interface C0598ec<D> {
}
