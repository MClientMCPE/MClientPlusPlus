package p000;

/* renamed from: d3 */
public interface C0508d3 {

    /* renamed from: d3$a */
    public interface C0509a {
    }

    void setOnFitSystemWindowsListener(C0509a aVar);
}
