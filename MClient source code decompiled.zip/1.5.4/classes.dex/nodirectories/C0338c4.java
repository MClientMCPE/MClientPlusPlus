package p000;

import android.content.Context;
import android.graphics.Rect;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;

/* renamed from: c4 */
public class C0338c4 {

    /* renamed from: a */
    public final Context f2489a;

    /* renamed from: b */
    public final View f2490b;

    /* renamed from: c */
    public final TextView f2491c;

    /* renamed from: d */
    public final WindowManager.LayoutParams f2492d = new WindowManager.LayoutParams();

    /* renamed from: e */
    public final Rect f2493e = new Rect();

    /* renamed from: f */
    public final int[] f2494f = new int[2];

    /* renamed from: g */
    public final int[] f2495g = new int[2];

    public C0338c4(Context context) {
        this.f2489a = context;
        this.f2490b = LayoutInflater.from(this.f2489a).inflate(C0978j.abc_tooltip, (ViewGroup) null);
        this.f2491c = (TextView) this.f2490b.findViewById(C0887i.message);
        this.f2492d.setTitle(C0338c4.class.getSimpleName());
        this.f2492d.packageName = this.f2489a.getPackageName();
        WindowManager.LayoutParams layoutParams = this.f2492d;
        layoutParams.type = 1002;
        layoutParams.width = -2;
        layoutParams.height = -2;
        layoutParams.format = -3;
        layoutParams.windowAnimations = C1205l.Animation_AppCompat_Tooltip;
        layoutParams.flags = 24;
    }

    /* renamed from: a */
    public void mo2789a() {
        if (this.f2490b.getParent() != null) {
            ((WindowManager) this.f2489a.getSystemService("window")).removeView(this.f2490b);
        }
    }

    /* renamed from: b */
    public boolean mo2790b() {
        return this.f2490b.getParent() != null;
    }
}
