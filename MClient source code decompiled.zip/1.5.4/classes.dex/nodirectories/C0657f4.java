package p000;

/* renamed from: f4 */
public interface C0657f4 {
    /* renamed from: a */
    CharSequence mo5370a();
}
