package p000;

import java.util.concurrent.Future;

/* renamed from: dk */
public final /* synthetic */ class C0547dk implements Runnable {

    /* renamed from: X */
    public final /* synthetic */ Future f3932X;

    /* renamed from: Y */
    public final /* synthetic */ Runnable f3933Y;

    public /* synthetic */ C0547dk(Future future, Runnable runnable) {
        this.f3932X = future;
        this.f3933Y = runnable;
    }

    public final void run() {
        Future future = this.f3932X;
        Runnable runnable = this.f3933Y;
        if (!future.isDone() && !future.isCancelled()) {
            future.cancel(true);
            k23.m7993b("BillingClient", "Async task is taking too long, cancel it!");
            if (runnable != null) {
                runnable.run();
            }
        }
    }
}
