package p000;

import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import p000.C0773gh;
import p000.C1919tg;

/* renamed from: eh */
public final class C0612eh implements Runnable {

    /* renamed from: X */
    public final /* synthetic */ C1919tg f4479X;

    /* renamed from: Y */
    public final /* synthetic */ SQLiteDatabase f4480Y;

    /* renamed from: Z */
    public final /* synthetic */ C0698fh f4481Z;

    /* renamed from: a0 */
    public final /* synthetic */ CountDownLatch f4482a0;

    public C0612eh(C1919tg tgVar, SQLiteDatabase sQLiteDatabase, C0698fh fhVar, CountDownLatch countDownLatch) {
        this.f4479X = tgVar;
        this.f4480Y = sQLiteDatabase;
        this.f4481Z = fhVar;
        this.f4482a0 = countDownLatch;
    }

    public void run() {
        Cursor rawQuery;
        loop0:
        for (C1919tg.C1920a next : this.f4479X.f14899b) {
            Iterator<Map.Entry<String, String>> it = next.f14908i.entrySet().iterator();
            while (true) {
                if (it.hasNext()) {
                    Map.Entry next2 = it.next();
                    C0773gh ghVar = null;
                    try {
                        rawQuery = this.f4480Y.rawQuery((String) next2.getValue(), (String[]) null);
                        if (rawQuery != null) {
                            try {
                                if (rawQuery.moveToFirst()) {
                                    C0773gh ghVar2 = new C0773gh();
                                    int i = 0;
                                    while (i < rawQuery.getColumnCount()) {
                                        try {
                                            ghVar2.f6116a.add(new C0773gh.C0774a(i, rawQuery.getColumnName(i), rawQuery.getType(i), (C0612eh) null));
                                            i++;
                                        } catch (Throwable th) {
                                            Throwable th2 = th;
                                            ghVar = ghVar2;
                                            th = th2;
                                            throw th;
                                        }
                                    }
                                    do {
                                        ghVar2.mo6095a(rawQuery);
                                    } while (rawQuery.moveToNext());
                                    ghVar = ghVar2;
                                }
                            } catch (Throwable th3) {
                                th = th3;
                                throw th;
                            }
                        }
                        if (rawQuery != null) {
                            rawQuery.close();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    } catch (Throwable th4) {
                        th.addSuppressed(th4);
                        break loop0;
                    }
                    if (ghVar != null) {
                        this.f4481Z.mo5655a(next.f14900a, (String) next2.getKey(), ghVar);
                    }
                }
            }
            throw th;
        }
        C2449zg b = C2449zg.m17093b();
        b.f18336c = this.f4481Z;
        b.f18337d = true;
        this.f4482a0.countDown();
    }
}
