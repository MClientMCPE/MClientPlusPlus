package p000;

import android.os.IBinder;
import android.os.IInterface;

/* renamed from: ax */
public abstract class C0272ax extends qj2 implements C0498cx {
    /* renamed from: a */
    public static C0498cx m1597a(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.formats.client.IShouldDelayBannerRenderingListener");
        return queryLocalInterface instanceof C0498cx ? (C0498cx) queryLocalInterface : new C0630ex(iBinder);
    }
}
