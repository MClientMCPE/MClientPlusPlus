package p000;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.AutoCompleteTextView;
import android.widget.TextView;

/* renamed from: b2 */
public class C0278b2 extends AutoCompleteTextView implements C2097v7 {

    /* renamed from: c0 */
    public static final int[] f1648c0 = {16843126};

    /* renamed from: a0 */
    public final C0334c2 f1649a0;

    /* renamed from: b0 */
    public final C2176w2 f1650b0;

    public C0278b2(Context context) {
        this(context, (AttributeSet) null);
    }

    public C0278b2(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0502d.autoCompleteTextViewStyle);
    }

    public C0278b2(Context context, AttributeSet attributeSet, int i) {
        super(C2083v3.m14434a(context), attributeSet, i);
        C2322y3 a = C2322y3.m16057a(getContext(), attributeSet, f1648c0, i, 0);
        if (a.mo12745f(0)) {
            setDropDownBackgroundDrawable(a.mo12737b(0));
        }
        a.f17544b.recycle();
        this.f1649a0 = new C0334c2(this);
        this.f1649a0.mo2717a(attributeSet, i);
        this.f1650b0 = new C2176w2(this);
        this.f1650b0.mo12087a(attributeSet, i);
        this.f1650b0.mo12081a();
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        C0334c2 c2Var = this.f1649a0;
        if (c2Var != null) {
            c2Var.mo2713a();
        }
        C2176w2 w2Var = this.f1650b0;
        if (w2Var != null) {
            w2Var.mo12081a();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0334c2 c2Var = this.f1649a0;
        if (c2Var != null) {
            return c2Var.mo2718b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0334c2 c2Var = this.f1649a0;
        if (c2Var != null) {
            return c2Var.mo2720c();
        }
        return null;
    }

    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        C0815h0.m5787a(onCreateInputConnection, editorInfo, (View) this);
        return onCreateInputConnection;
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0334c2 c2Var = this.f1649a0;
        if (c2Var != null) {
            c2Var.mo2721d();
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C0334c2 c2Var = this.f1649a0;
        if (c2Var != null) {
            c2Var.mo2714a(i);
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(C0815h0.m5786a((TextView) this, callback));
    }

    public void setDropDownBackgroundResource(int i) {
        setDropDownBackgroundDrawable(C1206l0.m8461c(getContext(), i));
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0334c2 c2Var = this.f1649a0;
        if (c2Var != null) {
            c2Var.mo2719b(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0334c2 c2Var = this.f1649a0;
        if (c2Var != null) {
            c2Var.mo2716a(mode);
        }
    }

    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        C2176w2 w2Var = this.f1650b0;
        if (w2Var != null) {
            w2Var.mo12084a(context, i);
        }
    }
}
