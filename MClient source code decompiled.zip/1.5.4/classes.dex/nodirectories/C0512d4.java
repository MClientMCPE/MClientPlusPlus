package p000;

import android.content.res.Resources;

/* renamed from: d4 */
public class C0512d4 extends Resources {
    /* renamed from: a */
    public static boolean m3429a() {
        return false;
    }
}
