package p000;

import android.util.AndroidRuntimeException;

/* renamed from: cb */
public final class C0365cb extends AndroidRuntimeException {
    public C0365cb(String str) {
        super(str);
    }
}
