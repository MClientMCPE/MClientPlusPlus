package p000;

import android.content.Context;
import android.os.RemoteException;

/* renamed from: el */
public class C0616el {

    /* renamed from: a */
    public final Context f4578a;

    /* renamed from: b */
    public final qw2 f4579b;

    public C0616el(Context context, qw2 qw2) {
        this.f4578a = context;
        this.f4579b = qw2;
    }

    /* renamed from: a */
    public void mo5204a(C0706fl flVar) {
        try {
            this.f4579b.mo2212a(rv2.m12342a(this.f4578a, flVar.f5464a));
        } catch (RemoteException e) {
            C0680fe.m4830c("Failed to load ad.", (Throwable) e);
        }
    }
}
