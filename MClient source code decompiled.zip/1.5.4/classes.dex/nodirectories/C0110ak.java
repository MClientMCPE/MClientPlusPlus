package p000;

import java.util.List;
import java.util.concurrent.Callable;

/* renamed from: ak */
public final /* synthetic */ class C0110ak implements Callable {

    /* renamed from: a */
    public final /* synthetic */ C1065jj f534a;

    /* renamed from: b */
    public final /* synthetic */ String f535b;

    /* renamed from: c */
    public final /* synthetic */ List f536c;

    /* renamed from: d */
    public final /* synthetic */ C1706qj f537d;

    public /* synthetic */ C0110ak(C1065jj jjVar, String str, List list, C1706qj qjVar) {
        this.f534a = jjVar;
        this.f535b = str;
        this.f536c = list;
        this.f537d = qjVar;
    }

    public final Object call() {
        this.f534a.mo7650a(this.f535b, this.f536c, (String) null, this.f537d);
        return null;
    }
}
