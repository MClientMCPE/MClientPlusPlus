package p000;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;

/* renamed from: cr */
public final class C0492cr {

    /* renamed from: a */
    public static Object f3502a = new Object();

    /* renamed from: b */
    public static boolean f3503b;

    /* renamed from: c */
    public static String f3504c;

    /* renamed from: d */
    public static int f3505d;

    /* renamed from: a */
    public static void m3245a(Context context) {
        synchronized (f3502a) {
            if (!f3503b) {
                f3503b = true;
                try {
                    Bundle bundle = C1351mr.m9516b(context).mo8471a(context.getPackageName(), 128).metaData;
                    if (bundle != null) {
                        f3504c = bundle.getString("com.google.app.id");
                        f3505d = bundle.getInt("com.google.android.gms.version");
                    }
                } catch (PackageManager.NameNotFoundException e) {
                    Log.wtf("MetadataValueReader", "This should never happen.", e);
                }
            }
        }
    }
}
