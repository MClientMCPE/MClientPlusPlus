package p000;

import android.view.View;

/* renamed from: f0 */
public class C0634f0 extends C0350c8 {

    /* renamed from: a */
    public final /* synthetic */ C0011a0 f4915a;

    public C0634f0(C0011a0 a0Var) {
        this.f4915a = a0Var;
    }

    /* renamed from: b */
    public void mo61b(View view) {
        this.f4915a.f44l0.setAlpha(1.0f);
        this.f4915a.f47o0.mo260a((C0286b8) null);
        this.f4915a.f47o0 = null;
    }

    /* renamed from: c */
    public void mo173c(View view) {
        this.f4915a.f44l0.setVisibility(0);
        this.f4915a.f44l0.sendAccessibilityEvent(32);
        if (this.f4915a.f44l0.getParent() instanceof View) {
            C2189w7.m14973E((View) this.f4915a.f44l0.getParent());
        }
    }
}
