package p000;

/* renamed from: e */
public final class C0565e {
    public static final int abc_action_bar_embed_tabs = 2131034112;
    public static final int abc_allow_stacked_button_bar = 2131034113;
    public static final int abc_config_actionMenuItemAllCaps = 2131034114;
}
