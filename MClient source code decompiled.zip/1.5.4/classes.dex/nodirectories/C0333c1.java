package p000;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.widget.ActionMenuView;
import java.util.ArrayList;
import p000.C0027a2;
import p000.C1581p1;
import p000.C1655q1;

/* renamed from: c1 */
public abstract class C0333c1 implements C1581p1 {

    /* renamed from: X */
    public Context f2412X;

    /* renamed from: Y */
    public Context f2413Y;

    /* renamed from: Z */
    public C0816h1 f2414Z;

    /* renamed from: a0 */
    public LayoutInflater f2415a0;

    /* renamed from: b0 */
    public C1581p1.C1582a f2416b0;

    /* renamed from: c0 */
    public int f2417c0;

    /* renamed from: d0 */
    public int f2418d0;

    /* renamed from: e0 */
    public C1655q1 f2419e0;

    public C0333c1(Context context, int i, int i2) {
        this.f2412X = context;
        this.f2415a0 = LayoutInflater.from(context);
        this.f2417c0 = i;
        this.f2418d0 = i2;
    }

    /* renamed from: a */
    public View mo128a(C1115k1 k1Var, View view, ViewGroup viewGroup) {
        C1655q1.C1656a aVar = view instanceof C1655q1.C1656a ? (C1655q1.C1656a) view : (C1655q1.C1656a) this.f2415a0.inflate(this.f2418d0, viewGroup, false);
        C0027a2 a2Var = (C0027a2) this;
        aVar.mo716a(k1Var, 0);
        ActionMenuItemView actionMenuItemView = (ActionMenuItemView) aVar;
        actionMenuItemView.setItemInvoker((ActionMenuView) a2Var.f2419e0);
        if (a2Var.f126w0 == null) {
            a2Var.f126w0 = new C0027a2.C0029b();
        }
        actionMenuItemView.setPopupCallback(a2Var.f126w0);
        return (View) aVar;
    }

    /* renamed from: a */
    public void mo2706a(int i) {
    }

    /* renamed from: a */
    public void mo129a(Context context, C0816h1 h1Var) {
        this.f2413Y = context;
        LayoutInflater.from(this.f2413Y);
        this.f2414Z = h1Var;
    }

    /* renamed from: a */
    public void mo130a(C0816h1 h1Var, boolean z) {
        C1581p1.C1582a aVar = this.f2416b0;
        if (aVar != null) {
            aVar.mo55a(h1Var, z);
        }
    }

    /* renamed from: a */
    public void mo2707a(C1581p1.C1582a aVar) {
        this.f2416b0 = aVar;
    }

    /* renamed from: a */
    public boolean mo133a(ViewGroup viewGroup, int i) {
        viewGroup.removeViewAt(i);
        return true;
    }

    /* renamed from: a */
    public boolean mo1149a(C0816h1 h1Var, C1115k1 k1Var) {
        return false;
    }

    /* renamed from: a */
    public boolean mo134a(C2081v1 v1Var) {
        C1581p1.C1582a aVar = this.f2416b0;
        if (aVar != null) {
            return aVar.mo56a(v1Var);
        }
        return false;
    }

    /* renamed from: b */
    public boolean mo1150b(C0816h1 h1Var, C1115k1 k1Var) {
        return false;
    }

    /* renamed from: a */
    public void mo131a(boolean z) {
        ViewGroup viewGroup = (ViewGroup) this.f2419e0;
        if (viewGroup != null) {
            C0816h1 h1Var = this.f2414Z;
            int i = 0;
            if (h1Var != null) {
                h1Var.mo6279a();
                ArrayList<C1115k1> d = this.f2414Z.mo6310d();
                int size = d.size();
                int i2 = 0;
                for (int i3 = 0; i3 < size; i3++) {
                    C1115k1 k1Var = d.get(i3);
                    C0027a2 a2Var = (C0027a2) this;
                    if (k1Var.mo7792d()) {
                        View childAt = viewGroup.getChildAt(i2);
                        C1115k1 itemData = childAt instanceof C1655q1.C1656a ? ((C1655q1.C1656a) childAt).getItemData() : null;
                        View a = mo128a(k1Var, childAt, viewGroup);
                        if (k1Var != itemData) {
                            a.setPressed(false);
                            a.jumpDrawablesToCurrentState();
                        }
                        if (a != childAt) {
                            ViewGroup viewGroup2 = (ViewGroup) a.getParent();
                            if (viewGroup2 != null) {
                                viewGroup2.removeView(a);
                            }
                            ((ViewGroup) this.f2419e0).addView(a, i2);
                        }
                        i2++;
                    }
                }
                i = i2;
            }
            while (i < viewGroup.getChildCount()) {
                if (!mo133a(viewGroup, i)) {
                    i++;
                }
            }
        }
    }
}
