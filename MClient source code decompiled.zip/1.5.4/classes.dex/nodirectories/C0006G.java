package p000;

import androidx.lifecycle.ViewModelProvider;

/* renamed from: G */
public class C0006G extends C0004E {
    public C0006G() {
    }

    /* renamed from: a */
    public ViewModelProvider.NewInstanceFactory mo1a() {
        return C0001B.m13h(new C0004E());
    }
}
