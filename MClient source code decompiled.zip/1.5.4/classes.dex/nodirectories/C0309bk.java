package p000;

import java.util.List;

/* renamed from: bk */
public final /* synthetic */ class C0309bk implements Runnable {

    /* renamed from: X */
    public final /* synthetic */ C1065jj f2022X;

    /* renamed from: Y */
    public final /* synthetic */ C1338mj f2023Y;

    public /* synthetic */ C0309bk(C1065jj jjVar, C1338mj mjVar) {
        this.f2022X = jjVar;
        this.f2023Y = mjVar;
    }

    public final void run() {
        C1065jj jjVar = this.f2022X;
        ((yf3) jjVar.f8485d.f17841b.f17261a).mo12926b(this.f2023Y, (List<C1461nj>) null);
    }
}
