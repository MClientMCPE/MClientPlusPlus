package p000;

import androidx.lifecycle.ViewModelProvider;

/* renamed from: E */
public class C0004E extends hu3 {
    public C0004E() {
    }

    /* renamed from: a */
    public ViewModelProvider.NewInstanceFactory mo1a() {
        C0001B.m11f(new hu3());
        return null;
    }
}
