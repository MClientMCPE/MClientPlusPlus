package p000;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import androidx.appcompat.app.AlertController;
import androidx.appcompat.view.menu.ExpandedMenuView;
import java.util.ArrayList;
import p000.C1581p1;
import p000.C1655q1;
import p000.C2247x;

/* renamed from: f1 */
public class C0635f1 implements C1581p1, AdapterView.OnItemClickListener {

    /* renamed from: X */
    public Context f4919X;

    /* renamed from: Y */
    public LayoutInflater f4920Y;

    /* renamed from: Z */
    public C0816h1 f4921Z;

    /* renamed from: a0 */
    public ExpandedMenuView f4922a0;

    /* renamed from: b0 */
    public int f4923b0;

    /* renamed from: c0 */
    public int f4924c0 = 0;

    /* renamed from: d0 */
    public int f4925d0;

    /* renamed from: e0 */
    public C1581p1.C1582a f4926e0;

    /* renamed from: f0 */
    public C0636a f4927f0;

    /* renamed from: f1$a */
    public class C0636a extends BaseAdapter {

        /* renamed from: X */
        public int f4928X = -1;

        public C0636a() {
            mo5272a();
        }

        /* renamed from: a */
        public void mo5272a() {
            C0816h1 h1Var = C0635f1.this.f4921Z;
            C1115k1 k1Var = h1Var.f6517x;
            if (k1Var != null) {
                h1Var.mo6279a();
                ArrayList<C1115k1> arrayList = h1Var.f6503j;
                int size = arrayList.size();
                for (int i = 0; i < size; i++) {
                    if (arrayList.get(i) == k1Var) {
                        this.f4928X = i;
                        return;
                    }
                }
            }
            this.f4928X = -1;
        }

        public int getCount() {
            C0816h1 h1Var = C0635f1.this.f4921Z;
            h1Var.mo6279a();
            int size = h1Var.f6503j.size() - C0635f1.this.f4923b0;
            return this.f4928X < 0 ? size : size - 1;
        }

        public C1115k1 getItem(int i) {
            C0816h1 h1Var = C0635f1.this.f4921Z;
            h1Var.mo6279a();
            ArrayList<C1115k1> arrayList = h1Var.f6503j;
            int i2 = i + C0635f1.this.f4923b0;
            int i3 = this.f4928X;
            if (i3 >= 0 && i2 >= i3) {
                i2++;
            }
            return arrayList.get(i2);
        }

        public long getItemId(int i) {
            return (long) i;
        }

        public View getView(int i, View view, ViewGroup viewGroup) {
            if (view == null) {
                C0635f1 f1Var = C0635f1.this;
                view = f1Var.f4920Y.inflate(f1Var.f4925d0, viewGroup, false);
            }
            ((C1655q1.C1656a) view).mo716a(getItem(i), 0);
            return view;
        }

        public void notifyDataSetChanged() {
            mo5272a();
            super.notifyDataSetChanged();
        }
    }

    public C0635f1(Context context, int i) {
        this.f4925d0 = i;
        this.f4919X = context;
        this.f4920Y = LayoutInflater.from(this.f4919X);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:7:0x001c, code lost:
        if (r2.f4920Y == null) goto L_0x000b;
     */
    /* JADX WARNING: Removed duplicated region for block: B:10:0x0025  */
    /* JADX WARNING: Removed duplicated region for block: B:12:? A[RETURN, SYNTHETIC] */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo129a(android.content.Context r3, p000.C0816h1 r4) {
        /*
            r2 = this;
            int r0 = r2.f4924c0
            if (r0 == 0) goto L_0x0014
            android.view.ContextThemeWrapper r1 = new android.view.ContextThemeWrapper
            r1.<init>(r3, r0)
            r2.f4919X = r1
        L_0x000b:
            android.content.Context r3 = r2.f4919X
            android.view.LayoutInflater r3 = android.view.LayoutInflater.from(r3)
            r2.f4920Y = r3
            goto L_0x001f
        L_0x0014:
            android.content.Context r0 = r2.f4919X
            if (r0 == 0) goto L_0x001f
            r2.f4919X = r3
            android.view.LayoutInflater r3 = r2.f4920Y
            if (r3 != 0) goto L_0x001f
            goto L_0x000b
        L_0x001f:
            r2.f4921Z = r4
            f1$a r3 = r2.f4927f0
            if (r3 == 0) goto L_0x0028
            r3.notifyDataSetChanged()
        L_0x0028:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0635f1.mo129a(android.content.Context, h1):void");
    }

    /* renamed from: a */
    public void mo130a(C0816h1 h1Var, boolean z) {
        C1581p1.C1582a aVar = this.f4926e0;
        if (aVar != null) {
            aVar.mo55a(h1Var, z);
        }
    }

    /* renamed from: a */
    public void mo2707a(C1581p1.C1582a aVar) {
        this.f4926e0 = aVar;
    }

    /* renamed from: a */
    public void mo131a(boolean z) {
        C0636a aVar = this.f4927f0;
        if (aVar != null) {
            aVar.notifyDataSetChanged();
        }
    }

    /* renamed from: a */
    public boolean mo132a() {
        return false;
    }

    /* renamed from: a */
    public boolean mo1149a(C0816h1 h1Var, C1115k1 k1Var) {
        return false;
    }

    /* renamed from: a */
    public boolean mo134a(C2081v1 v1Var) {
        if (!v1Var.hasVisibleItems()) {
            return false;
        }
        C0891i1 i1Var = new C0891i1(v1Var);
        C0816h1 h1Var = i1Var.f7054X;
        C2247x.C2248a aVar = new C2247x.C2248a(h1Var.f6494a);
        i1Var.f7056Z = new C0635f1(aVar.f16954a.f716a, C0978j.abc_list_menu_item_layout);
        C0635f1 f1Var = i1Var.f7056Z;
        f1Var.f4926e0 = i1Var;
        C0816h1 h1Var2 = i1Var.f7054X;
        h1Var2.mo6287a((C1581p1) f1Var, h1Var2.f6494a);
        ListAdapter b = i1Var.f7056Z.mo5270b();
        AlertController.C0126b bVar = aVar.f16954a;
        bVar.f738w = b;
        bVar.f739x = i1Var;
        View view = h1Var.f6509p;
        if (view != null) {
            bVar.f722g = view;
        } else {
            bVar.f719d = h1Var.f6508o;
            aVar.mo12388a(h1Var.f6507n);
        }
        aVar.f16954a.f736u = i1Var;
        i1Var.f7055Y = aVar.mo12389a();
        i1Var.f7055Y.setOnDismissListener(i1Var);
        WindowManager.LayoutParams attributes = i1Var.f7055Y.getWindow().getAttributes();
        attributes.type = 1003;
        attributes.flags |= 131072;
        i1Var.f7055Y.show();
        C1581p1.C1582a aVar2 = this.f4926e0;
        if (aVar2 == null) {
            return true;
        }
        aVar2.mo56a(v1Var);
        return true;
    }

    /* renamed from: b */
    public ListAdapter mo5270b() {
        if (this.f4927f0 == null) {
            this.f4927f0 = new C0636a();
        }
        return this.f4927f0;
    }

    /* renamed from: b */
    public boolean mo1150b(C0816h1 h1Var, C1115k1 k1Var) {
        return false;
    }

    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
        this.f4921Z.mo6290a((MenuItem) this.f4927f0.getItem(i), (C1581p1) this, 0);
    }
}
