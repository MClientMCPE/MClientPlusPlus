package p000;

import androidx.fragment.app.Fragment;
import java.io.PrintWriter;
import java.util.ArrayList;
import p000.C0921ia;
import p000.C1002ja;
import p000.C1689qa;

/* renamed from: aa */
public final class C0056aa extends C1689qa implements C0921ia.C0922a, C1002ja.C1010h {

    /* renamed from: r */
    public final C1002ja f280r;

    /* renamed from: s */
    public boolean f281s;

    /* renamed from: t */
    public int f282t = -1;

    public C0056aa(C1002ja jaVar) {
        this.f280r = jaVar;
    }

    /* renamed from: a */
    public void mo287a() {
        int size = this.f12952a.size();
        for (int i = 0; i < size; i++) {
            C1689qa.C1690a aVar = this.f12952a.get(i);
            Fragment fragment = aVar.f12970b;
            if (fragment != null) {
                int i2 = this.f12957f;
                int i3 = this.f12958g;
                if (!(fragment.f1136H0 == null && i2 == 0 && i3 == 0)) {
                    fragment.mo1425f();
                    Fragment.C0197c cVar = fragment.f1136H0;
                    cVar.f1184e = i2;
                    cVar.f1185f = i3;
                }
            }
            switch (aVar.f12969a) {
                case 1:
                    fragment.mo1408a(aVar.f12971c);
                    this.f280r.mo7503a(fragment, false);
                    break;
                case 3:
                    fragment.mo1408a(aVar.f12972d);
                    this.f280r.mo7544i(fragment);
                    break;
                case 4:
                    fragment.mo1408a(aVar.f12972d);
                    this.f280r.mo7529d(fragment);
                    break;
                case 5:
                    fragment.mo1408a(aVar.f12971c);
                    this.f280r.mo7550l(fragment);
                    break;
                case 6:
                    fragment.mo1408a(aVar.f12972d);
                    this.f280r.mo7513b(fragment);
                    break;
                case 7:
                    fragment.mo1408a(aVar.f12971c);
                    this.f280r.mo7497a(fragment);
                    break;
                case 8:
                    this.f280r.mo7549k(fragment);
                    break;
                case 9:
                    this.f280r.mo7549k((Fragment) null);
                    break;
                case 10:
                    this.f280r.mo7502a(fragment, aVar.f12976h);
                    break;
                default:
                    StringBuilder a = C0789gk.m5562a("Unknown cmd: ");
                    a.append(aVar.f12969a);
                    throw new IllegalArgumentException(a.toString());
            }
            if (!(this.f12967p || aVar.f12969a == 1 || fragment == null)) {
                this.f280r.mo7542h(fragment);
            }
        }
        if (!this.f12967p) {
            C1002ja jaVar = this.f280r;
            jaVar.mo7492a(jaVar.f8222m0, true);
        }
    }

    /* renamed from: a */
    public void mo288a(int i) {
        if (this.f12959h) {
            int size = this.f12952a.size();
            for (int i2 = 0; i2 < size; i2++) {
                Fragment fragment = this.f12952a.get(i2).f12970b;
                if (fragment != null) {
                    fragment.f1164n0 += i;
                }
            }
        }
    }

    /* renamed from: a */
    public void mo289a(String str, PrintWriter printWriter, boolean z) {
        String str2;
        if (z) {
            printWriter.print(str);
            printWriter.print("mName=");
            printWriter.print(this.f12960i);
            printWriter.print(" mIndex=");
            printWriter.print(this.f282t);
            printWriter.print(" mCommitted=");
            printWriter.println(this.f281s);
            if (this.f12957f != 0) {
                printWriter.print(str);
                printWriter.print("mTransition=#");
                printWriter.print(Integer.toHexString(this.f12957f));
                printWriter.print(" mTransitionStyle=#");
                printWriter.println(Integer.toHexString(this.f12958g));
            }
            if (!(this.f12953b == 0 && this.f12954c == 0)) {
                printWriter.print(str);
                printWriter.print("mEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f12953b));
                printWriter.print(" mExitAnim=#");
                printWriter.println(Integer.toHexString(this.f12954c));
            }
            if (!(this.f12955d == 0 && this.f12956e == 0)) {
                printWriter.print(str);
                printWriter.print("mPopEnterAnim=#");
                printWriter.print(Integer.toHexString(this.f12955d));
                printWriter.print(" mPopExitAnim=#");
                printWriter.println(Integer.toHexString(this.f12956e));
            }
            if (!(this.f12961j == 0 && this.f12962k == null)) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbTitleRes=#");
                printWriter.print(Integer.toHexString(this.f12961j));
                printWriter.print(" mBreadCrumbTitleText=");
                printWriter.println(this.f12962k);
            }
            if (!(this.f12963l == 0 && this.f12964m == null)) {
                printWriter.print(str);
                printWriter.print("mBreadCrumbShortTitleRes=#");
                printWriter.print(Integer.toHexString(this.f12963l));
                printWriter.print(" mBreadCrumbShortTitleText=");
                printWriter.println(this.f12964m);
            }
        }
        if (!this.f12952a.isEmpty()) {
            printWriter.print(str);
            printWriter.println("Operations:");
            int size = this.f12952a.size();
            for (int i = 0; i < size; i++) {
                C1689qa.C1690a aVar = this.f12952a.get(i);
                switch (aVar.f12969a) {
                    case 0:
                        str2 = "NULL";
                        break;
                    case 1:
                        str2 = "ADD";
                        break;
                    case 2:
                        str2 = "REPLACE";
                        break;
                    case 3:
                        str2 = "REMOVE";
                        break;
                    case 4:
                        str2 = "HIDE";
                        break;
                    case 5:
                        str2 = "SHOW";
                        break;
                    case 6:
                        str2 = "DETACH";
                        break;
                    case 7:
                        str2 = "ATTACH";
                        break;
                    case 8:
                        str2 = "SET_PRIMARY_NAV";
                        break;
                    case 9:
                        str2 = "UNSET_PRIMARY_NAV";
                        break;
                    case 10:
                        str2 = "OP_SET_MAX_LIFECYCLE";
                        break;
                    default:
                        StringBuilder a = C0789gk.m5562a("cmd=");
                        a.append(aVar.f12969a);
                        str2 = a.toString();
                        break;
                }
                printWriter.print(str);
                printWriter.print("  Op #");
                printWriter.print(i);
                printWriter.print(": ");
                printWriter.print(str2);
                printWriter.print(" ");
                printWriter.println(aVar.f12970b);
                if (z) {
                    if (!(aVar.f12971c == 0 && aVar.f12972d == 0)) {
                        printWriter.print(str);
                        printWriter.print("enterAnim=#");
                        printWriter.print(Integer.toHexString(aVar.f12971c));
                        printWriter.print(" exitAnim=#");
                        printWriter.println(Integer.toHexString(aVar.f12972d));
                    }
                    if (aVar.f12973e != 0 || aVar.f12974f != 0) {
                        printWriter.print(str);
                        printWriter.print("popEnterAnim=#");
                        printWriter.print(Integer.toHexString(aVar.f12973e));
                        printWriter.print(" popExitAnim=#");
                        printWriter.println(Integer.toHexString(aVar.f12974f));
                    }
                }
            }
        }
    }

    /* renamed from: a */
    public boolean mo291a(ArrayList<C0056aa> arrayList, int i, int i2) {
        if (i2 == i) {
            return false;
        }
        int size = this.f12952a.size();
        int i3 = -1;
        for (int i4 = 0; i4 < size; i4++) {
            Fragment fragment = this.f12952a.get(i4).f12970b;
            int i5 = fragment != null ? fragment.f1170t0 : 0;
            if (!(i5 == 0 || i5 == i3)) {
                for (int i6 = i; i6 < i2; i6++) {
                    C0056aa aaVar = arrayList.get(i6);
                    int size2 = aaVar.f12952a.size();
                    for (int i7 = 0; i7 < size2; i7++) {
                        Fragment fragment2 = aaVar.f12952a.get(i7).f12970b;
                        if ((fragment2 != null ? fragment2.f1170t0 : 0) == i5) {
                            return true;
                        }
                    }
                }
                i3 = i5;
            }
        }
        return false;
    }

    /* renamed from: b */
    public boolean mo293b(int i) {
        int size = this.f12952a.size();
        for (int i2 = 0; i2 < size; i2++) {
            Fragment fragment = this.f12952a.get(i2).f12970b;
            int i3 = fragment != null ? fragment.f1170t0 : 0;
            if (i3 != 0 && i3 == i) {
                return true;
            }
        }
        return false;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("BackStackEntry{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        if (this.f282t >= 0) {
            sb.append(" #");
            sb.append(this.f282t);
        }
        if (this.f12960i != null) {
            sb.append(" ");
            sb.append(this.f12960i);
        }
        sb.append("}");
        return sb.toString();
    }

    /* renamed from: a */
    public void mo290a(boolean z) {
        for (int size = this.f12952a.size() - 1; size >= 0; size--) {
            C1689qa.C1690a aVar = this.f12952a.get(size);
            Fragment fragment = aVar.f12970b;
            if (fragment != null) {
                int d = C1002ja.m7412d(this.f12957f);
                int i = this.f12958g;
                if (!(fragment.f1136H0 == null && d == 0 && i == 0)) {
                    fragment.mo1425f();
                    Fragment.C0197c cVar = fragment.f1136H0;
                    cVar.f1184e = d;
                    cVar.f1185f = i;
                }
            }
            switch (aVar.f12969a) {
                case 1:
                    fragment.mo1408a(aVar.f12974f);
                    this.f280r.mo7544i(fragment);
                    break;
                case 3:
                    fragment.mo1408a(aVar.f12973e);
                    this.f280r.mo7503a(fragment, false);
                    break;
                case 4:
                    fragment.mo1408a(aVar.f12973e);
                    this.f280r.mo7550l(fragment);
                    break;
                case 5:
                    fragment.mo1408a(aVar.f12974f);
                    this.f280r.mo7529d(fragment);
                    break;
                case 6:
                    fragment.mo1408a(aVar.f12973e);
                    this.f280r.mo7497a(fragment);
                    break;
                case 7:
                    fragment.mo1408a(aVar.f12974f);
                    this.f280r.mo7513b(fragment);
                    break;
                case 8:
                    this.f280r.mo7549k((Fragment) null);
                    break;
                case 9:
                    this.f280r.mo7549k(fragment);
                    break;
                case 10:
                    this.f280r.mo7502a(fragment, aVar.f12975g);
                    break;
                default:
                    StringBuilder a = C0789gk.m5562a("Unknown cmd: ");
                    a.append(aVar.f12969a);
                    throw new IllegalArgumentException(a.toString());
            }
            if (!(this.f12967p || aVar.f12969a == 3 || fragment == null)) {
                this.f280r.mo7542h(fragment);
            }
        }
        if (!this.f12967p && z) {
            C1002ja jaVar = this.f280r;
            jaVar.mo7492a(jaVar.f8222m0, true);
        }
    }

    /* renamed from: a */
    public boolean mo292a(ArrayList<C0056aa> arrayList, ArrayList<Boolean> arrayList2) {
        arrayList.add(this);
        arrayList2.add(false);
        if (!this.f12959h) {
            return true;
        }
        C1002ja jaVar = this.f280r;
        if (jaVar.f8214e0 == null) {
            jaVar.f8214e0 = new ArrayList<>();
        }
        jaVar.f8214e0.add(this);
        return true;
    }

    /* renamed from: a */
    public static boolean m290a(C1689qa.C1690a aVar) {
        Fragment fragment = aVar.f12970b;
        if (fragment == null || !fragment.f1158h0 || fragment.f1132D0 == null || fragment.f1173w0 || fragment.f1172v0) {
            return false;
        }
        Fragment.C0197c cVar = fragment.f1136H0;
        return cVar == null ? false : cVar.f1196q;
    }
}
