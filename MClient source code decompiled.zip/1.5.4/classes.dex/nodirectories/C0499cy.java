package p000;

import java.util.Map;

/* renamed from: cy */
public final /* synthetic */ class C0499cy implements C1373my {

    /* renamed from: a */
    public static final C1373my f3598a = new C0499cy();

    /* renamed from: a */
    public final void mo2197a(Object obj, Map map) {
        C2476zx.m17351a((dl0) obj, map);
    }
}
