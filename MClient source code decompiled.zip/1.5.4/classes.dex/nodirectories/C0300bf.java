package p000;

import android.os.Parcelable;
import android.text.TextUtils;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/* renamed from: bf */
public abstract class C0300bf {

    /* renamed from: a */
    public final C2399z4<String, Method> f1911a;

    /* renamed from: b */
    public final C2399z4<String, Method> f1912b;

    /* renamed from: c */
    public final C2399z4<String, Class> f1913c;

    public C0300bf(C2399z4<String, Method> z4Var, C2399z4<String, Method> z4Var2, C2399z4<String, Class> z4Var3) {
        this.f1911a = z4Var;
        this.f1912b = z4Var2;
        this.f1913c = z4Var3;
    }

    /* renamed from: a */
    public final Class mo2502a(Class<? extends C0535df> cls) {
        Class orDefault = this.f1913c.getOrDefault(cls.getName(), null);
        if (orDefault != null) {
            return orDefault;
        }
        Class<?> cls2 = Class.forName(String.format("%s.%sParcelizer", new Object[]{cls.getPackage().getName(), cls.getSimpleName()}), false, cls.getClassLoader());
        this.f1913c.put(cls.getName(), cls2);
        return cls2;
    }

    /* renamed from: a */
    public abstract void mo2504a();

    /* renamed from: a */
    public abstract boolean mo2506a(int i);

    /* renamed from: b */
    public abstract C0300bf mo2508b();

    /* renamed from: b */
    public final Method mo2509b(Class cls) {
        Method orDefault = this.f1912b.getOrDefault(cls.getName(), null);
        if (orDefault != null) {
            return orDefault;
        }
        Class a = mo2502a((Class<? extends C0535df>) cls);
        System.currentTimeMillis();
        Method declaredMethod = a.getDeclaredMethod("write", new Class[]{cls, C0300bf.class});
        this.f1912b.put(cls.getName(), declaredMethod);
        return declaredMethod;
    }

    /* renamed from: b */
    public abstract void mo2510b(int i);

    /* renamed from: c */
    public abstract String mo2513c();

    /* renamed from: d */
    public <T extends C0535df> T mo2514d() {
        String readString = ((C0371cf) this).f2686e.readString();
        if (readString == null) {
            return null;
        }
        C0300bf b = mo2508b();
        try {
            return (C0535df) mo2503a(readString).invoke((Object) null, new Object[]{b});
        } catch (IllegalAccessException e) {
            throw new RuntimeException("VersionedParcel encountered IllegalAccessException", e);
        } catch (InvocationTargetException e2) {
            if (e2.getCause() instanceof RuntimeException) {
                throw ((RuntimeException) e2.getCause());
            }
            throw new RuntimeException("VersionedParcel encountered InvocationTargetException", e2);
        } catch (NoSuchMethodException e3) {
            throw new RuntimeException("VersionedParcel encountered NoSuchMethodException", e3);
        } catch (ClassNotFoundException e4) {
            throw new RuntimeException("VersionedParcel encountered ClassNotFoundException", e4);
        }
    }

    /* renamed from: e */
    public void mo2515e() {
    }

    /* renamed from: a */
    public final Method mo2503a(String str) {
        Class<C0300bf> cls = C0300bf.class;
        Method orDefault = this.f1911a.getOrDefault(str, null);
        if (orDefault != null) {
            return orDefault;
        }
        System.currentTimeMillis();
        Method declaredMethod = Class.forName(str, true, cls.getClassLoader()).getDeclaredMethod("read", new Class[]{cls});
        this.f1911a.put(str, declaredMethod);
        return declaredMethod;
    }

    /* renamed from: b */
    public void mo2511b(int i, int i2) {
        mo2510b(i2);
        ((C0371cf) this).f2686e.writeInt(i);
    }

    /* renamed from: b */
    public void mo2512b(Parcelable parcelable, int i) {
        mo2510b(i);
        ((C0371cf) this).f2686e.writeParcelable(parcelable, 0);
    }

    /* renamed from: a */
    public boolean mo2507a(boolean z, int i) {
        if (!mo2506a(i)) {
            return z;
        }
        return ((C0371cf) this).f2686e.readInt() != 0;
    }

    /* renamed from: a */
    public CharSequence mo2501a(CharSequence charSequence, int i) {
        return !mo2506a(i) ? charSequence : (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((C0371cf) this).f2686e);
    }

    /* renamed from: a */
    public int mo2499a(int i, int i2) {
        return !mo2506a(i2) ? i : ((C0371cf) this).f2686e.readInt();
    }

    /* renamed from: a */
    public <T extends Parcelable> T mo2500a(T t, int i) {
        return !mo2506a(i) ? t : ((C0371cf) this).f2686e.readParcelable(C0371cf.class.getClassLoader());
    }

    /* renamed from: a */
    public void mo2505a(C0535df dfVar) {
        if (dfVar == null) {
            ((C0371cf) this).f2686e.writeString((String) null);
            return;
        }
        try {
            ((C0371cf) this).f2686e.writeString(mo2502a((Class<? extends C0535df>) dfVar.getClass()).getName());
            C0300bf b = mo2508b();
            try {
                mo2509b((Class) dfVar.getClass()).invoke((Object) null, new Object[]{dfVar, b});
                b.mo2504a();
            } catch (IllegalAccessException e) {
                throw new RuntimeException("VersionedParcel encountered IllegalAccessException", e);
            } catch (InvocationTargetException e2) {
                if (e2.getCause() instanceof RuntimeException) {
                    throw ((RuntimeException) e2.getCause());
                }
                throw new RuntimeException("VersionedParcel encountered InvocationTargetException", e2);
            } catch (NoSuchMethodException e3) {
                throw new RuntimeException("VersionedParcel encountered NoSuchMethodException", e3);
            } catch (ClassNotFoundException e4) {
                throw new RuntimeException("VersionedParcel encountered ClassNotFoundException", e4);
            }
        } catch (ClassNotFoundException e5) {
            throw new RuntimeException(dfVar.getClass().getSimpleName() + " does not have a Parcelizer", e5);
        }
    }
}
