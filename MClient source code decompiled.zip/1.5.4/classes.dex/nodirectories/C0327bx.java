package p000;

/* renamed from: bx */
public class C0327bx extends Exception {
    public C0327bx() {
    }

    public C0327bx(String str) {
        super(str);
    }

    public C0327bx(Throwable th) {
        super(th);
    }

    public C0327bx(mq2 mq2) {
    }
}
