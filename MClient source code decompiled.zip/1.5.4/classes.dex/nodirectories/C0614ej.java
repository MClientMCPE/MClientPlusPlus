package p000;

import android.content.Context;
import android.graphics.Point;
import android.os.Build;
import android.view.View;
import android.view.WindowManager;

/* renamed from: ej */
public class C0614ej {

    /* renamed from: a */
    public static int f4529a;

    /* renamed from: b */
    public static int f4530b;

    /* renamed from: c */
    public static int f4531c;

    /* renamed from: d */
    public static int f4532d;

    /* JADX WARNING: Code restructure failed: missing block: B:117:0x0202, code lost:
        r14 = r1.bottom;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:121:0x0219, code lost:
        r14 = r4.bottom;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:122:0x021b, code lost:
        r9.set(r11, r12, r13, r14);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:127:0x023a, code lost:
        r14 = r1.top;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x0065, code lost:
        return r19;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:66:0x0137, code lost:
        if (m4187b(r9) == false) goto L_0x0139;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:70:0x0145, code lost:
        if (r14.isEmpty() == false) goto L_0x0147;
     */
    /* JADX WARNING: Removed duplicated region for block: B:24:0x0073 A[RETURN] */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x0074  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static float m4184a(android.view.View r17, android.graphics.Rect r18, float r19, boolean r20) {
        /*
            r0 = r18
            java.util.LinkedList r1 = new java.util.LinkedList
            r1.<init>()
            java.util.LinkedList r2 = new java.util.LinkedList
            r2.<init>()
            java.util.LinkedList r3 = new java.util.LinkedList
            r3.<init>()
            java.util.LinkedList r4 = new java.util.LinkedList
            r4.<init>()
            java.util.ArrayList r5 = new java.util.ArrayList
            r5.<init>()
            r3.add(r0)
            android.view.ViewParent r6 = r17.getParent()
            android.view.ViewGroup r6 = (android.view.ViewGroup) r6
            android.view.View r7 = r17.getRootView()
            android.content.Context r9 = r17.getContext()     // Catch:{ Exception -> 0x0036 }
            android.app.Activity r9 = (android.app.Activity) r9     // Catch:{ Exception -> 0x0036 }
            r10 = 16908290(0x1020002, float:2.3877235E-38)
            android.view.View r9 = r9.findViewById(r10)     // Catch:{ Exception -> 0x0036 }
            goto L_0x0037
        L_0x0036:
            r9 = 0
        L_0x0037:
            r10 = 0
            if (r6 == 0) goto L_0x0071
            android.view.ViewParent r11 = r6.getParent()
            if (r11 == r7) goto L_0x0071
            int r11 = r6.getVisibility()
            if (r11 != 0) goto L_0x0070
            float r11 = m4183a((android.view.View) r6)
            int r10 = (r11 > r10 ? 1 : (r11 == r10 ? 0 : -1))
            if (r10 != 0) goto L_0x004f
            goto L_0x0070
        L_0x004f:
            if (r9 == 0) goto L_0x0066
            if (r20 == 0) goto L_0x0066
            if (r6 == r9) goto L_0x0066
            android.view.ViewGroup$LayoutParams r10 = r6.getLayoutParams()
            int r10 = r10.height
            if (r10 == 0) goto L_0x0065
            android.view.ViewGroup$LayoutParams r10 = r6.getLayoutParams()
            int r10 = r10.width
            if (r10 != 0) goto L_0x0066
        L_0x0065:
            return r19
        L_0x0066:
            r1.addFirst(r6)
            android.view.ViewParent r6 = r6.getParent()
            android.view.ViewGroup r6 = (android.view.ViewGroup) r6
            goto L_0x0037
        L_0x0070:
            return r19
        L_0x0071:
            if (r6 != 0) goto L_0x0074
            return r19
        L_0x0074:
            java.util.Iterator r1 = r1.iterator()
        L_0x0078:
            boolean r6 = r1.hasNext()
            r7 = 0
            r9 = 1
            if (r6 == 0) goto L_0x0150
            java.lang.Object r6 = r1.next()
            android.view.View r6 = (android.view.View) r6
            android.view.ViewParent r11 = r6.getParent()
            android.view.ViewGroup r11 = (android.view.ViewGroup) r11
            if (r11 != 0) goto L_0x008f
            return r19
        L_0x008f:
            java.lang.Class r12 = r11.getClass()
            java.lang.String r12 = r12.getSimpleName()
            java.lang.String r13 = "viewpager"
            boolean r12 = r13.equalsIgnoreCase(r12)
            if (r12 == 0) goto L_0x00a0
            goto L_0x0078
        L_0x00a0:
            int r6 = r11.indexOfChild(r6)
            int r12 = r11.getChildCount()
            int r12 = r12 - r9
            if (r6 >= r12) goto L_0x0078
        L_0x00ab:
            int r6 = r6 + r9
            int r12 = r11.getChildCount()
            if (r6 >= r12) goto L_0x0078
            android.view.View r12 = r11.getChildAt(r6)
            boolean r13 = m4187b((android.view.View) r12)
            if (r13 != 0) goto L_0x00cf
            int r13 = r12.getVisibility()
            if (r13 != 0) goto L_0x014c
            float r13 = m4183a((android.view.View) r12)
            int r13 = (r13 > r10 ? 1 : (r13 == r10 ? 0 : -1))
            if (r13 == 0) goto L_0x014c
            r4.addFirst(r12)
            goto L_0x014c
        L_0x00cf:
            boolean r13 = r12 instanceof android.view.ViewGroup
            if (r13 != 0) goto L_0x00d6
        L_0x00d3:
            r14 = 0
            goto L_0x0147
        L_0x00d6:
            int r13 = r12.getVisibility()
            if (r13 != 0) goto L_0x00d3
            float r13 = m4183a((android.view.View) r12)
            int r13 = (r13 > r10 ? 1 : (r13 == r10 ? 0 : -1))
            if (r13 != 0) goto L_0x00e5
            goto L_0x00d3
        L_0x00e5:
            java.util.LinkedList r13 = new java.util.LinkedList
            r13.<init>()
            java.util.ArrayList r14 = new java.util.ArrayList
            r14.<init>()
            android.view.ViewGroup r12 = (android.view.ViewGroup) r12
            r13.add(r12)
            java.util.ListIterator r12 = r13.listIterator()
        L_0x00f8:
            boolean r13 = r12.hasNext()
            if (r13 == 0) goto L_0x0141
            java.lang.Object r13 = r12.next()
            android.view.ViewGroup r13 = (android.view.ViewGroup) r13
            r12.remove()
            int r15 = r13.getChildCount()
            r8 = 0
        L_0x010c:
            if (r8 >= r15) goto L_0x00f8
            android.view.View r9 = r13.getChildAt(r8)
            int r16 = r9.getVisibility()
            if (r16 != 0) goto L_0x013c
            float r16 = m4183a((android.view.View) r9)
            int r16 = (r16 > r10 ? 1 : (r16 == r10 ? 0 : -1))
            if (r16 == 0) goto L_0x013c
            boolean r10 = r9 instanceof android.view.ViewGroup
            if (r10 == 0) goto L_0x0133
            boolean r10 = m4187b((android.view.View) r9)
            if (r10 == 0) goto L_0x0139
            android.view.ViewGroup r9 = (android.view.ViewGroup) r9
            r12.add(r9)
            r12.previous()
            goto L_0x013c
        L_0x0133:
            boolean r10 = m4187b((android.view.View) r9)
            if (r10 != 0) goto L_0x013c
        L_0x0139:
            r14.add(r9)
        L_0x013c:
            int r8 = r8 + 1
            r9 = 1
            r10 = 0
            goto L_0x010c
        L_0x0141:
            boolean r8 = r14.isEmpty()
            if (r8 != 0) goto L_0x00d3
        L_0x0147:
            if (r14 == 0) goto L_0x014c
            r4.addAll(r7, r14)
        L_0x014c:
            r9 = 1
            r10 = 0
            goto L_0x00ab
        L_0x0150:
            java.util.Iterator r1 = r4.iterator()
            r10 = 0
        L_0x0155:
            boolean r4 = r1.hasNext()
            if (r4 == 0) goto L_0x01ac
            java.lang.Object r4 = r1.next()
            android.view.View r4 = (android.view.View) r4
            int r6 = (r10 > r19 ? 1 : (r10 == r19 ? 0 : -1))
            if (r6 < 0) goto L_0x0166
            goto L_0x01ac
        L_0x0166:
            if (r4 == 0) goto L_0x017e
            java.lang.Object r6 = r4.getTag()     // Catch:{ Exception -> 0x017d }
            if (r6 == 0) goto L_0x017e
            java.lang.Object r6 = r4.getTag()     // Catch:{ Exception -> 0x017d }
            java.lang.String r6 = (java.lang.String) r6     // Catch:{ Exception -> 0x017d }
            java.lang.String r8 = "BTN_CLOSE"
            boolean r6 = r6.contains(r8)     // Catch:{ Exception -> 0x017d }
            if (r6 == 0) goto L_0x017e
            goto L_0x0155
        L_0x017d:
        L_0x017e:
            android.graphics.Rect r6 = new android.graphics.Rect
            r6.<init>()
            boolean r4 = r4.getGlobalVisibleRect(r6)
            if (r4 != 0) goto L_0x018a
            goto L_0x0155
        L_0x018a:
            if (r20 == 0) goto L_0x0192
            int r4 = r6.top
            r8 = 1
            int r4 = r4 + r8
            r6.top = r4
        L_0x0192:
            boolean r4 = r6.intersect(r0)
            if (r4 == 0) goto L_0x0155
            r2.add(r6)
            int r4 = r6.width()
            int r6 = r6.height()
            int r6 = r6 * r4
            float r10 = (float) r6
            int r4 = (r10 > r19 ? 1 : (r10 == r19 ? 0 : -1))
            if (r4 < 0) goto L_0x0155
            r0 = 1
            goto L_0x01ad
        L_0x01ac:
            r0 = 0
        L_0x01ad:
            if (r0 == 0) goto L_0x01b0
            return r19
        L_0x01b0:
            boolean r0 = r2.isEmpty()
            if (r0 != 0) goto L_0x027f
            int r0 = r2.size()
            r8 = 1
            if (r0 != r8) goto L_0x01be
            return r10
        L_0x01be:
            java.util.Iterator r0 = r2.iterator()
        L_0x01c2:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x0252
            java.lang.Object r1 = r0.next()
            android.graphics.Rect r1 = (android.graphics.Rect) r1
            r5.clear()
            r5.addAll(r3)
            r2 = 0
        L_0x01d5:
            int r4 = r5.size()
            if (r2 >= r4) goto L_0x01c2
            java.lang.Object r4 = r5.get(r2)
            android.graphics.Rect r4 = (android.graphics.Rect) r4
            boolean r6 = r1.intersect(r4)
            if (r6 == 0) goto L_0x024f
            java.lang.Object r6 = r5.get(r2)
            r3.remove(r6)
            r6 = 1
        L_0x01ef:
            r9 = 9
            if (r6 >= r9) goto L_0x024f
            android.graphics.Rect r9 = new android.graphics.Rect
            r9.<init>()
            switch(r6) {
                case 1: goto L_0x0234;
                case 2: goto L_0x022d;
                case 3: goto L_0x0226;
                case 4: goto L_0x021f;
                case 5: goto L_0x0213;
                case 6: goto L_0x020c;
                case 7: goto L_0x0205;
                case 8: goto L_0x01fc;
                default: goto L_0x01fb;
            }
        L_0x01fb:
            goto L_0x023d
        L_0x01fc:
            int r11 = r4.left
            int r12 = r1.top
            int r13 = r1.left
        L_0x0202:
            int r14 = r1.bottom
            goto L_0x021b
        L_0x0205:
            int r11 = r4.left
            int r12 = r1.bottom
            int r13 = r1.left
            goto L_0x0219
        L_0x020c:
            int r11 = r1.left
            int r12 = r1.bottom
            int r13 = r1.right
            goto L_0x0219
        L_0x0213:
            int r11 = r1.right
            int r12 = r1.bottom
            int r13 = r4.right
        L_0x0219:
            int r14 = r4.bottom
        L_0x021b:
            r9.set(r11, r12, r13, r14)
            goto L_0x023d
        L_0x021f:
            int r11 = r1.right
            int r12 = r1.top
            int r13 = r4.right
            goto L_0x0202
        L_0x0226:
            int r11 = r1.right
            int r12 = r4.top
            int r13 = r4.right
            goto L_0x023a
        L_0x022d:
            int r11 = r1.left
            int r12 = r4.top
            int r13 = r1.right
            goto L_0x023a
        L_0x0234:
            int r11 = r4.left
            int r12 = r4.top
            int r13 = r1.left
        L_0x023a:
            int r14 = r1.top
            goto L_0x021b
        L_0x023d:
            int r11 = r9.height()
            if (r11 <= 0) goto L_0x024c
            int r11 = r9.width()
            if (r11 <= 0) goto L_0x024c
            r3.add(r9)
        L_0x024c:
            int r6 = r6 + 1
            goto L_0x01ef
        L_0x024f:
            int r2 = r2 + 1
            goto L_0x01d5
        L_0x0252:
            boolean r0 = r3.isEmpty()
            if (r0 != 0) goto L_0x027f
            java.util.Iterator r0 = r3.iterator()
            r16 = 0
        L_0x025e:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L_0x0278
            java.lang.Object r1 = r0.next()
            android.graphics.Rect r1 = (android.graphics.Rect) r1
            int r2 = r1.width()
            int r1 = r1.height()
            int r1 = r1 * r2
            float r1 = (float) r1
            float r16 = r16 + r1
            goto L_0x025e
        L_0x0278:
            int r0 = (r16 > r19 ? 1 : (r16 == r19 ? 0 : -1))
            if (r0 >= 0) goto L_0x027f
            float r0 = r19 - r16
            return r0
        L_0x027f:
            return r10
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0614ej.m4184a(android.view.View, android.graphics.Rect, float, boolean):float");
    }

    /* renamed from: b */
    public static int m4186b(Context context) {
        int i;
        int i2;
        int i3;
        int i4 = context != null ? context.getResources().getConfiguration().orientation : -1;
        if (i4 == 2 && (i3 = f4530b) > 0) {
            return i3;
        }
        if (i4 == 1 && (i2 = f4532d) > 0) {
            return i2;
        }
        try {
            WindowManager windowManager = (WindowManager) context.getApplicationContext().getSystemService("window");
            if (Build.VERSION.SDK_INT >= 13) {
                Point point = new Point();
                windowManager.getDefaultDisplay().getSize(point);
                i = point.x;
            } else {
                i = windowManager.getDefaultDisplay().getWidth();
            }
            if (i4 == 2) {
                f4530b = i;
            } else if (i4 == 1) {
                f4532d = i;
            }
            return i;
        } catch (Exception unused) {
            return 0;
        }
    }

    /* renamed from: b */
    public static boolean m4187b(View view) {
        if (view == null) {
            return false;
        }
        if (view.getBackground() == null || (Build.VERSION.SDK_INT > 18 && view.getBackground().getAlpha() == 0)) {
            return true;
        }
        return false;
    }

    /* renamed from: a */
    public static int m4185a(Context context) {
        int i;
        int i2;
        int i3;
        int i4 = context != null ? context.getResources().getConfiguration().orientation : -1;
        if (i4 == 2 && (i3 = f4529a) > 0) {
            return i3;
        }
        if (i4 == 1 && (i2 = f4531c) > 0) {
            return i2;
        }
        try {
            WindowManager windowManager = (WindowManager) context.getApplicationContext().getSystemService("window");
            if (Build.VERSION.SDK_INT >= 13) {
                Point point = new Point();
                windowManager.getDefaultDisplay().getSize(point);
                i = point.y;
            } else {
                i = windowManager.getDefaultDisplay().getHeight();
            }
            if (i4 == 2) {
                f4529a = i;
            } else if (i4 == 1) {
                f4531c = i;
            }
            return i;
        } catch (Exception unused) {
            return 0;
        }
    }

    /* renamed from: a */
    public static float m4183a(View view) {
        if (view == null) {
            return 0.0f;
        }
        if (Build.VERSION.SDK_INT < 11) {
            return 1.0f;
        }
        return view.getAlpha();
    }
}
