package p000;

import android.annotation.SuppressLint;
import android.os.Bundle;
import java.util.Map;

@SuppressLint({"RestrictedApi"})
/* renamed from: fd */
public final class C0677fd {

    /* renamed from: a */
    public C1121k4<String, C0679b> f5228a = new C1121k4<>();

    /* renamed from: b */
    public Bundle f5229b;

    /* renamed from: c */
    public boolean f5230c;

    /* renamed from: d */
    public boolean f5231d;

    /* renamed from: fd$a */
    public interface C0678a {
        /* renamed from: a */
        void mo5550a(C0857hd hdVar);
    }

    /* renamed from: fd$b */
    public interface C0679b {
        /* renamed from: a */
        Bundle mo5551a();
    }

    /* renamed from: a */
    public void mo5549a(Bundle bundle) {
        Bundle bundle2 = new Bundle();
        Bundle bundle3 = this.f5229b;
        if (bundle3 != null) {
            bundle2.putAll(bundle3);
        }
        C1121k4<K, V>.C0502d c = this.f5228a.mo7862c();
        while (c.hasNext()) {
            Map.Entry entry = (Map.Entry) c.next();
            bundle2.putBundle((String) entry.getKey(), ((C0679b) entry.getValue()).mo5551a());
        }
        bundle.putBundle("androidx.lifecycle.BundlableSavedStateRegistry.key", bundle2);
    }
}
