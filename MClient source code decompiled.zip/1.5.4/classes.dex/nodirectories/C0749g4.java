package p000;

import java.util.concurrent.Executor;

/* renamed from: g4 */
public class C0749g4 extends C0905i4 {

    /* renamed from: c */
    public static volatile C0749g4 f5948c;

    /* renamed from: a */
    public C0905i4 f5949a = this.f5950b;

    /* renamed from: b */
    public C0905i4 f5950b = new C0827h4();

    /* renamed from: g4$a */
    public static class C0750a implements Executor {
        public void execute(Runnable runnable) {
            C0749g4.m5256b().mo5884b(runnable);
        }
    }

    /* renamed from: g4$b */
    public static class C0751b implements Executor {
        public void execute(Runnable runnable) {
            C0749g4.m5256b().mo5882a(runnable);
        }
    }

    /* renamed from: b */
    public static C0749g4 m5256b() {
        if (f5948c != null) {
            return f5948c;
        }
        synchronized (C0749g4.class) {
            if (f5948c == null) {
                f5948c = new C0749g4();
            }
        }
        return f5948c;
    }

    /* renamed from: a */
    public void mo5882a(Runnable runnable) {
        this.f5949a.mo5882a(runnable);
    }

    /* renamed from: a */
    public boolean mo5883a() {
        return this.f5949a.mo5883a();
    }

    /* renamed from: b */
    public void mo5884b(Runnable runnable) {
        this.f5949a.mo5884b(runnable);
    }
}
