package p000;

/* renamed from: a9 */
public abstract class C0055a9 extends C2407z8 {
}
