package p000;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.appcompat.widget.Toolbar;

/* renamed from: a4 */
public class C0036a4 implements C0035a3 {

    /* renamed from: a */
    public Toolbar f147a;

    /* renamed from: b */
    public int f148b;

    /* renamed from: c */
    public View f149c;

    /* renamed from: d */
    public View f150d;

    /* renamed from: e */
    public Drawable f151e;

    /* renamed from: f */
    public Drawable f152f;

    /* renamed from: g */
    public Drawable f153g;

    /* renamed from: h */
    public boolean f154h;

    /* renamed from: i */
    public CharSequence f155i;

    /* renamed from: j */
    public CharSequence f156j;

    /* renamed from: k */
    public CharSequence f157k;

    /* renamed from: l */
    public Window.Callback f158l;

    /* renamed from: m */
    public boolean f159m;

    /* renamed from: n */
    public C0027a2 f160n;

    /* renamed from: o */
    public int f161o = 0;

    /* renamed from: p */
    public int f162p = 0;

    /* renamed from: q */
    public Drawable f163q;

    /* renamed from: a4$a */
    public class C0037a extends C0350c8 {

        /* renamed from: a */
        public boolean f164a = false;

        /* renamed from: b */
        public final /* synthetic */ int f165b;

        public C0037a(int i) {
            this.f165b = i;
        }

        /* renamed from: a */
        public void mo172a(View view) {
            this.f164a = true;
        }

        /* renamed from: b */
        public void mo61b(View view) {
            if (!this.f164a) {
                C0036a4.this.f147a.setVisibility(this.f165b);
            }
        }

        /* renamed from: c */
        public void mo173c(View view) {
            C0036a4.this.f147a.setVisibility(0);
        }
    }

    public C0036a4(Toolbar toolbar, boolean z) {
        int i;
        Drawable drawable;
        int i2 = C1109k.abc_action_bar_up_description;
        this.f147a = toolbar;
        this.f155i = toolbar.getTitle();
        this.f156j = toolbar.getSubtitle();
        this.f154h = this.f155i != null;
        this.f153g = toolbar.getNavigationIcon();
        String str = null;
        C2322y3 a = C2322y3.m16057a(toolbar.getContext(), (AttributeSet) null, C1292m.ActionBar, C0502d.actionBarStyle, 0);
        this.f163q = a.mo12737b(C1292m.ActionBar_homeAsUpIndicator);
        if (z) {
            CharSequence e = a.mo12743e(C1292m.ActionBar_title);
            if (!TextUtils.isEmpty(e)) {
                this.f154h = true;
                mo163a(e);
            }
            CharSequence e2 = a.mo12743e(C1292m.ActionBar_subtitle);
            if (!TextUtils.isEmpty(e2)) {
                this.f156j = e2;
                if ((this.f148b & 8) != 0) {
                    this.f147a.setSubtitle(e2);
                }
            }
            Drawable b = a.mo12737b(C1292m.ActionBar_logo);
            if (b != null) {
                mo161a(b);
            }
            Drawable b2 = a.mo12737b(C1292m.ActionBar_icon);
            if (b2 != null) {
                this.f151e = b2;
                mo171f();
            }
            if (this.f153g == null && (drawable = this.f163q) != null) {
                this.f153g = drawable;
                mo170e();
            }
            mo160a(a.mo12740d(C1292m.ActionBar_displayOptions, 0));
            int f = a.mo12744f(C1292m.ActionBar_customNavigationLayout, 0);
            if (f != 0) {
                mo162a(LayoutInflater.from(this.f147a.getContext()).inflate(f, this.f147a, false));
                mo160a(this.f148b | 16);
            }
            int e3 = a.mo12742e(C1292m.ActionBar_height, 0);
            if (e3 > 0) {
                ViewGroup.LayoutParams layoutParams = this.f147a.getLayoutParams();
                layoutParams.height = e3;
                this.f147a.setLayoutParams(layoutParams);
            }
            int b3 = a.mo12736b(C1292m.ActionBar_contentInsetStart, -1);
            int b4 = a.mo12736b(C1292m.ActionBar_contentInsetEnd, -1);
            if (b3 >= 0 || b4 >= 0) {
                this.f147a.mo1048a(Math.max(b3, 0), Math.max(b4, 0));
            }
            int f2 = a.mo12744f(C1292m.ActionBar_titleTextStyle, 0);
            if (f2 != 0) {
                Toolbar toolbar2 = this.f147a;
                toolbar2.mo1057b(toolbar2.getContext(), f2);
            }
            int f3 = a.mo12744f(C1292m.ActionBar_subtitleTextStyle, 0);
            if (f3 != 0) {
                Toolbar toolbar3 = this.f147a;
                toolbar3.mo1049a(toolbar3.getContext(), f3);
            }
            int f4 = a.mo12744f(C1292m.ActionBar_popupTheme, 0);
            if (f4 != 0) {
                this.f147a.setPopupTheme(f4);
            }
        } else {
            if (this.f147a.getNavigationIcon() != null) {
                i = 15;
                this.f163q = this.f147a.getNavigationIcon();
            } else {
                i = 11;
            }
            this.f148b = i;
        }
        a.f17544b.recycle();
        if (i2 != this.f162p) {
            this.f162p = i2;
            if (TextUtils.isEmpty(this.f147a.getNavigationContentDescription())) {
                int i3 = this.f162p;
                this.f157k = i3 != 0 ? mo159a().getString(i3) : str;
                mo169d();
            }
        }
        this.f157k = this.f147a.getNavigationContentDescription();
        this.f147a.setNavigationOnClickListener(new C2398z3(this));
    }

    /* renamed from: a */
    public C0052a8 mo158a(int i, long j) {
        C0052a8 a = C2189w7.m14976a(this.f147a);
        a.mo258a(i == 0 ? 1.0f : 0.0f);
        a.mo259a(j);
        a.mo260a((C0286b8) new C0037a(i));
        return a;
    }

    /* renamed from: a */
    public Context mo159a() {
        return this.f147a.getContext();
    }

    /* renamed from: a */
    public void mo160a(int i) {
        View view;
        CharSequence charSequence;
        Toolbar toolbar;
        int i2 = this.f148b ^ i;
        this.f148b = i;
        if (i2 != 0) {
            if ((i2 & 4) != 0) {
                if ((i & 4) != 0) {
                    mo169d();
                }
                mo170e();
            }
            if ((i2 & 3) != 0) {
                mo171f();
            }
            if ((i2 & 8) != 0) {
                if ((i & 8) != 0) {
                    this.f147a.setTitle(this.f155i);
                    toolbar = this.f147a;
                    charSequence = this.f156j;
                } else {
                    charSequence = null;
                    this.f147a.setTitle((CharSequence) null);
                    toolbar = this.f147a;
                }
                toolbar.setSubtitle(charSequence);
            }
            if ((i2 & 16) != 0 && (view = this.f150d) != null) {
                if ((i & 16) != 0) {
                    this.f147a.addView(view);
                } else {
                    this.f147a.removeView(view);
                }
            }
        }
    }

    /* renamed from: a */
    public void mo161a(Drawable drawable) {
        this.f152f = drawable;
        mo171f();
    }

    /* renamed from: a */
    public void mo162a(View view) {
        View view2 = this.f150d;
        if (!(view2 == null || (this.f148b & 16) == 0)) {
            this.f147a.removeView(view2);
        }
        this.f150d = view;
        if (view != null && (this.f148b & 16) != 0) {
            this.f147a.addView(this.f150d);
        }
    }

    /* renamed from: a */
    public final void mo163a(CharSequence charSequence) {
        this.f155i = charSequence;
        if ((this.f148b & 8) != 0) {
            this.f147a.setTitle(charSequence);
        }
    }

    /* renamed from: a */
    public void mo164a(C1661q3 q3Var) {
        Toolbar toolbar;
        View view = this.f149c;
        if (view != null && view.getParent() == (toolbar = this.f147a)) {
            toolbar.removeView(this.f149c);
        }
        this.f149c = q3Var;
        if (q3Var != null && this.f161o == 2) {
            this.f147a.addView(this.f149c, 0);
            Toolbar.C0166e eVar = (Toolbar.C0166e) this.f149c.getLayoutParams();
            eVar.width = -2;
            eVar.height = -2;
            eVar.f10754a = 8388691;
            q3Var.setAllowCollapse(true);
        }
    }

    /* renamed from: a */
    public void mo165a(boolean z) {
    }

    /* renamed from: b */
    public void mo166b() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    /* renamed from: b */
    public void mo167b(CharSequence charSequence) {
        if (!this.f154h) {
            this.f155i = charSequence;
            if ((this.f148b & 8) != 0) {
                this.f147a.setTitle(charSequence);
            }
        }
    }

    /* renamed from: c */
    public void mo168c() {
        Log.i("ToolbarWidgetWrapper", "Progress display unsupported");
    }

    /* renamed from: d */
    public final void mo169d() {
        if ((this.f148b & 4) == 0) {
            return;
        }
        if (TextUtils.isEmpty(this.f157k)) {
            this.f147a.setNavigationContentDescription(this.f162p);
        } else {
            this.f147a.setNavigationContentDescription(this.f157k);
        }
    }

    /* renamed from: e */
    public final void mo170e() {
        Drawable drawable;
        Toolbar toolbar;
        if ((this.f148b & 4) != 0) {
            toolbar = this.f147a;
            drawable = this.f153g;
            if (drawable == null) {
                drawable = this.f163q;
            }
        } else {
            toolbar = this.f147a;
            drawable = null;
        }
        toolbar.setNavigationIcon(drawable);
    }

    /* renamed from: f */
    public final void mo171f() {
        Drawable drawable;
        int i = this.f148b;
        if ((i & 2) == 0) {
            drawable = null;
        } else if ((i & 1) == 0 || (drawable = this.f152f) == null) {
            drawable = this.f151e;
        }
        this.f147a.setLogo(drawable);
    }
}
