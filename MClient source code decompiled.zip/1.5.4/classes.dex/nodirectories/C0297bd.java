package p000;

import android.view.View;
import android.widget.Scroller;
import androidx.recyclerview.widget.RecyclerView;

/* renamed from: bd */
public abstract class C0297bd extends RecyclerView.C0239r {

    /* renamed from: a */
    public RecyclerView f1816a;

    /* renamed from: b */
    public Scroller f1817b;

    /* renamed from: c */
    public final RecyclerView.C0241t f1818c = new C0298a();

    /* renamed from: bd$a */
    public class C0298a extends RecyclerView.C0241t {

        /* renamed from: a */
        public boolean f1819a = false;

        public C0298a() {
        }

        /* renamed from: a */
        public void mo1975a(RecyclerView recyclerView, int i) {
            if (i == 0 && this.f1819a) {
                this.f1819a = false;
                C0297bd.this.mo2446a();
            }
        }

        /* renamed from: a */
        public void mo1976a(RecyclerView recyclerView, int i, int i2) {
            if (i != 0 || i2 != 0) {
                this.f1819a = true;
            }
        }
    }

    /* renamed from: a */
    public abstract View mo2445a(RecyclerView.C0232o oVar);

    /* renamed from: a */
    public void mo2446a() {
        RecyclerView.C0232o layoutManager;
        View a;
        RecyclerView recyclerView = this.f1816a;
        if (recyclerView != null && (layoutManager = recyclerView.getLayoutManager()) != null && (a = mo2445a(layoutManager)) != null) {
            int[] a2 = mo2447a(layoutManager, a);
            if (a2[0] != 0 || a2[1] != 0) {
                this.f1816a.smoothScrollBy(a2[0], a2[1]);
            }
        }
    }

    /* renamed from: a */
    public abstract int[] mo2447a(RecyclerView.C0232o oVar, View view);
}
