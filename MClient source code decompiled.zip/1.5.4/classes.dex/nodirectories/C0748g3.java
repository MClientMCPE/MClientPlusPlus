package p000;

import android.view.View;

/* renamed from: g3 */
public class C0748g3 implements Runnable {

    /* renamed from: X */
    public final /* synthetic */ C0896i3 f5934X;

    public C0748g3(C0896i3 i3Var) {
        this.f5934X = i3Var;
    }

    public void run() {
        View view = this.f5934X.f7134p0;
        if (view != null && view.getWindowToken() != null) {
            this.f5934X.mo4982q();
        }
    }
}
