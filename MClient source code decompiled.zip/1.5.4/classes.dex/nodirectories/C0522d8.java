package p000;

/* renamed from: d8 */
public interface C0522d8 {
}
