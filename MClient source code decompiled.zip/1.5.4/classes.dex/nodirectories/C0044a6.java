package p000;

/* renamed from: a6 */
public final class C0044a6 implements C2255x5 {

    /* renamed from: a */
    public final C1983u6 f203a;

    /* renamed from: b */
    public final int f204b;

    /* renamed from: c */
    public final int f205c;

    public C0044a6(C1983u6 u6Var, int i, int i2) {
        this.f203a = u6Var;
        this.f205c = i;
        this.f204b = i2;
    }
}
