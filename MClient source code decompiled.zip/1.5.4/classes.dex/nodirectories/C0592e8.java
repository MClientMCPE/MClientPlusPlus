package p000;

import android.os.Build;
import android.view.WindowInsets;

/* renamed from: e8 */
public class C0592e8 {

    /* renamed from: a */
    public final Object f4319a;

    public C0592e8(Object obj) {
        this.f4319a = obj;
    }

    /* renamed from: a */
    public static C0592e8 m3972a(Object obj) {
        if (obj == null) {
            return null;
        }
        return new C0592e8(obj);
    }

    /* renamed from: a */
    public int mo5054a() {
        if (Build.VERSION.SDK_INT >= 20) {
            return ((WindowInsets) this.f4319a).getSystemWindowInsetBottom();
        }
        return 0;
    }

    /* renamed from: b */
    public int mo5055b() {
        if (Build.VERSION.SDK_INT >= 20) {
            return ((WindowInsets) this.f4319a).getSystemWindowInsetLeft();
        }
        return 0;
    }

    /* renamed from: c */
    public int mo5056c() {
        if (Build.VERSION.SDK_INT >= 20) {
            return ((WindowInsets) this.f4319a).getSystemWindowInsetRight();
        }
        return 0;
    }

    /* renamed from: d */
    public int mo5057d() {
        if (Build.VERSION.SDK_INT >= 20) {
            return ((WindowInsets) this.f4319a).getSystemWindowInsetTop();
        }
        return 0;
    }

    /* renamed from: e */
    public boolean mo5058e() {
        if (Build.VERSION.SDK_INT >= 21) {
            return ((WindowInsets) this.f4319a).isConsumed();
        }
        return false;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || C0592e8.class != obj.getClass()) {
            return false;
        }
        Object obj2 = this.f4319a;
        Object obj3 = ((C0592e8) obj).f4319a;
        return obj2 == null ? obj3 == null : obj2.equals(obj3);
    }

    public int hashCode() {
        Object obj = this.f4319a;
        if (obj == null) {
            return 0;
        }
        return obj.hashCode();
    }
}
