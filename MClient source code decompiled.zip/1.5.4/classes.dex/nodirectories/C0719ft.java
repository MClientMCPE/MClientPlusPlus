package p000;

import android.content.Context;
import android.os.Binder;
import android.os.Looper;
import p000.C1173kq;

/* renamed from: ft */
public final class C0719ft implements C1173kq.C1174a, C1173kq.C1175b {

    /* renamed from: a */
    public final C1637ps f5555a;

    /* renamed from: b */
    public final qz1 f5556b;

    /* renamed from: c */
    public final Object f5557c = new Object();

    /* renamed from: d */
    public boolean f5558d = false;

    /* renamed from: e */
    public boolean f5559e = false;

    public C0719ft(Context context, Looper looper, qz1 qz1) {
        this.f5556b = qz1;
        this.f5555a = new C1637ps(context, looper, this, this);
    }

    /* renamed from: a */
    public final void mo5777a() {
        synchronized (this.f5557c) {
            if (this.f5555a.mo8081i() || this.f5555a.mo8082j()) {
                this.f5555a.mo8076b();
            }
            Binder.flushPendingCommands();
        }
    }

    /* renamed from: a */
    public final void mo4473a(int i) {
    }

    /* JADX WARNING: Missing exception handler attribute for start block: B:10:0x002a */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo395a(android.os.Bundle r5) {
        /*
            r4 = this;
            java.lang.Object r5 = r4.f5557c
            monitor-enter(r5)
            boolean r0 = r4.f5559e     // Catch:{ all -> 0x0035 }
            if (r0 == 0) goto L_0x0009
            monitor-exit(r5)     // Catch:{ all -> 0x0035 }
            return
        L_0x0009:
            r0 = 1
            r4.f5559e = r0     // Catch:{ all -> 0x0035 }
            ps r1 = r4.f5555a     // Catch:{ Exception -> 0x002a, all -> 0x002e }
            ss r1 = r1.mo10109m()     // Catch:{ Exception -> 0x002a, all -> 0x002e }
            ns r2 = new ns     // Catch:{ Exception -> 0x002a, all -> 0x002e }
            qz1 r3 = r4.f5556b     // Catch:{ Exception -> 0x002a, all -> 0x002e }
            byte[] r3 = r3.mo13112b()     // Catch:{ Exception -> 0x002a, all -> 0x002e }
            r2.<init>(r0, r3)     // Catch:{ Exception -> 0x002a, all -> 0x002e }
            us r1 = (p000.C2068us) r1     // Catch:{ Exception -> 0x002a, all -> 0x002e }
            android.os.Parcel r0 = r1.mo10675a()     // Catch:{ Exception -> 0x002a, all -> 0x002e }
            p000.sj2.m12849a((android.os.Parcel) r0, (android.os.Parcelable) r2)     // Catch:{ Exception -> 0x002a, all -> 0x002e }
            r2 = 2
            r1.mo10678b(r2, r0)     // Catch:{ Exception -> 0x002a, all -> 0x002e }
        L_0x002a:
            r4.mo5777a()     // Catch:{ all -> 0x0035 }
            goto L_0x0033
        L_0x002e:
            r0 = move-exception
            r4.mo5777a()     // Catch:{ all -> 0x0035 }
            throw r0     // Catch:{ all -> 0x0035 }
        L_0x0033:
            monitor-exit(r5)     // Catch:{ all -> 0x0035 }
            return
        L_0x0035:
            r0 = move-exception
            monitor-exit(r5)     // Catch:{ all -> 0x0035 }
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0719ft.mo395a(android.os.Bundle):void");
    }

    /* renamed from: a */
    public final void mo396a(C2230wp wpVar) {
    }

    /* renamed from: b */
    public final void mo5778b() {
        synchronized (this.f5557c) {
            if (!this.f5558d) {
                this.f5558d = true;
                this.f5555a.mo8069a();
            }
        }
    }
}
