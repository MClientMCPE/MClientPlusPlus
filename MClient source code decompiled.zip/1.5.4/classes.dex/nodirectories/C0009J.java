package p000;

/* renamed from: J */
class C0009J implements Runnable {
    final /* synthetic */ C0008I this$0;

    C0009J(C0008I i) {
        this.this$0 = i;
    }

    /* renamed from: c */
    public static C0008I m38c(Object obj) {
        if (C0002C.m20g() <= 0) {
            return ((C0009J) obj).this$0;
        }
        return null;
    }

    public void run() {
        C0003D.m26g(m38c(this));
    }
}
