package p000;

import android.view.View;
import androidx.fragment.app.Fragment;

/* renamed from: da */
public class C0525da extends C0594ea {

    /* renamed from: a */
    public final /* synthetic */ Fragment f3769a;

    public C0525da(Fragment fragment) {
        this.f3769a = fragment;
    }

    /* renamed from: a */
    public View mo1476a(int i) {
        View view = this.f3769a.f1132D0;
        if (view != null) {
            return view.findViewById(i);
        }
        throw new IllegalStateException("Fragment " + this + " does not have a view");
    }

    /* renamed from: c */
    public boolean mo1477c() {
        return this.f3769a.f1132D0 != null;
    }
}
