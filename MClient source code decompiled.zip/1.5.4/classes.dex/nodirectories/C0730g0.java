package p000;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import p000.C0908i7;
import p000.C1889t0;

/* renamed from: g0 */
public class C0730g0 extends Dialog implements C2314y {

    /* renamed from: X */
    public C2386z f5621X;

    /* renamed from: Y */
    public final C0908i7.C0909a f5622Y = new C0731a();

    /* renamed from: g0$a */
    public class C0731a implements C0908i7.C0909a {
        public C0731a() {
        }

        /* renamed from: a */
        public boolean mo1291a(KeyEvent keyEvent) {
            return C0730g0.this.mo5812a(keyEvent);
        }
    }

    public C0730g0(Context context, int i) {
        super(context, m5176a(context, i));
        C2386z a = mo1a();
        ((C0011a0) a).f20K0 = m5176a(context, i);
        a.mo15a((Bundle) null);
    }

    /* renamed from: a */
    public static int m5176a(Context context, int i) {
        if (i != 0) {
            return i;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(C0502d.dialogTheme, typedValue, true);
        return typedValue.resourceId;
    }

    /* renamed from: a */
    public C1889t0 mo659a(C1889t0.C1890a aVar) {
        return null;
    }

    /* renamed from: a */
    public C2386z mo1a() {
        if (this.f5621X == null) {
            this.f5621X = C2386z.m16741a((Dialog) this, (C2314y) this);
        }
        return this.f5621X;
    }

    /* renamed from: a */
    public void mo661a(C1889t0 t0Var) {
    }

    /* renamed from: a */
    public boolean mo5811a(int i) {
        return mo1a().mo21a(i);
    }

    /* renamed from: a */
    public boolean mo5812a(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent);
    }

    public void addContentView(View view, ViewGroup.LayoutParams layoutParams) {
        mo1a().mo17a(view, layoutParams);
    }

    /* renamed from: b */
    public void mo665b(C1889t0 t0Var) {
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        return C0908i7.m6729a(this.f5622Y, getWindow().getDecorView(), this, keyEvent);
    }

    public <T extends View> T findViewById(int i) {
        C0011a0 a0Var = (C0011a0) mo1a();
        a0Var.mo43h();
        return a0Var.f34b0.findViewById(i);
    }

    public void invalidateOptionsMenu() {
        mo1a().mo32c();
    }

    public void onCreate(Bundle bundle) {
        mo1a().mo26b();
        super.onCreate(bundle);
        mo1a().mo15a(bundle);
    }

    public void onStop() {
        super.onStop();
        mo1a().mo36e();
    }

    public void setContentView(int i) {
        mo1a().mo27b(i);
    }

    public void setContentView(View view) {
        mo1a().mo16a(view);
    }

    public void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        mo1a().mo29b(view, layoutParams);
    }

    public void setTitle(int i) {
        super.setTitle(i);
        mo1a().mo20a((CharSequence) getContext().getString(i));
    }

    public void setTitle(CharSequence charSequence) {
        super.setTitle(charSequence);
        mo1a().mo20a(charSequence);
    }
}
