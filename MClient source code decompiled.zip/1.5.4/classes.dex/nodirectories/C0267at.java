package p000;

import p000.gs0;

/* renamed from: at */
public final /* synthetic */ class C0267at {

    /* renamed from: a */
    public final gs0.C0799a f1534a;

    /* renamed from: b */
    public final int f1535b;

    public C0267at(gs0.C0799a aVar, int i) {
        this.f1534a = aVar;
        this.f1535b = i;
    }

    /* renamed from: a */
    public final Object mo2134a(t23 t23) {
        boolean z;
        gs0.C0799a aVar = this.f1534a;
        int i = this.f1535b;
        if (t23.mo11121b()) {
            ju2 a = ((gu2) t23.mo11119a()).mo6225a(((gs0) aVar.mo9639i()).mo13112b());
            a.f8672c = i;
            a.mo7707a();
            z = true;
        } else {
            z = false;
        }
        return Boolean.valueOf(z);
    }
}
