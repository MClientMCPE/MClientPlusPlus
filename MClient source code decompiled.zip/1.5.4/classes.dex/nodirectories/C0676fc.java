package p000;

/* renamed from: fc */
public final class C0676fc {
    public static final int alpha = 2130968621;
    public static final int fastScrollEnabled = 2130968866;
    public static final int fastScrollHorizontalThumbDrawable = 2130968867;
    public static final int fastScrollHorizontalTrackDrawable = 2130968868;
    public static final int fastScrollVerticalThumbDrawable = 2130968869;
    public static final int fastScrollVerticalTrackDrawable = 2130968870;
    public static final int font = 2130968875;
    public static final int fontProviderAuthority = 2130968877;
    public static final int fontProviderCerts = 2130968878;
    public static final int fontProviderFetchStrategy = 2130968879;
    public static final int fontProviderFetchTimeout = 2130968880;
    public static final int fontProviderPackage = 2130968881;
    public static final int fontProviderQuery = 2130968882;
    public static final int fontStyle = 2130968883;
    public static final int fontVariationSettings = 2130968884;
    public static final int fontWeight = 2130968885;
    public static final int layoutManager = 2130968987;
    public static final int recyclerViewStyle = 2130969142;
    public static final int reverseLayout = 2130969143;
    public static final int spanCount = 2130969174;
    public static final int stackFromEnd = 2130969180;
    public static final int ttcIndex = 2130969294;
}
