package p000;

import p000.C0508d3;

/* renamed from: c0 */
public class C0332c0 implements C0508d3.C0509a {

    /* renamed from: a */
    public final /* synthetic */ C0011a0 f2405a;

    public C0332c0(C0011a0 a0Var) {
        this.f2405a = a0Var;
    }
}
