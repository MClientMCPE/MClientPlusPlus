package p000;

import java.util.Map;

/* renamed from: ey */
public final class C0631ey implements C1373my<wj0> {
    /* renamed from: a */
    public final /* synthetic */ void mo2197a(Object obj, Map map) {
        ((wj0) obj).mo6615b("1".equals(map.get("custom_close")));
    }
}
