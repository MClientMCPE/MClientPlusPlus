package p000;

/* renamed from: dg */
public class C0538dg implements C1617pg {

    /* renamed from: a */
    public final /* synthetic */ C1335mg f3836a;

    public C0538dg(C1335mg mgVar) {
        this.f3836a = mgVar;
    }

    /* renamed from: a */
    public void mo532a(C1249lg lgVar) {
        if (this.f3836a.mo8736i(lgVar)) {
            this.f3836a.mo8734g(lgVar);
        }
    }
}
