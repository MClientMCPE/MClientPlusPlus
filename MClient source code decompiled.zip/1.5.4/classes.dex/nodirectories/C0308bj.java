package p000;

/* renamed from: bj */
public class C0308bj implements C1617pg {

    /* renamed from: a */
    public final /* synthetic */ C0546dj f1994a;

    public C0308bj(C0546dj djVar) {
        this.f1994a = djVar;
    }

    /* renamed from: a */
    public void mo532a(C1249lg lgVar) {
        if (this.f1994a.mo4806a(lgVar)) {
            this.f1994a.mo4807b(lgVar);
        }
    }
}
