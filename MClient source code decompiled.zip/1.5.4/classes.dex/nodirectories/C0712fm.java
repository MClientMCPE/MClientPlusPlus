package p000;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: fm */
public final class C0712fm implements Parcelable.Creator<C0312bm> {
    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int b = C0680fe.m4795b(parcel);
        IBinder iBinder = null;
        boolean z = false;
        IBinder iBinder2 = null;
        while (parcel.dataPosition() < b) {
            int readInt = parcel.readInt();
            int i = 65535 & readInt;
            if (i == 1) {
                z = C0680fe.m4869g(parcel, readInt);
            } else if (i == 2) {
                iBinder = C0680fe.m4876i(parcel, readInt);
            } else if (i != 3) {
                C0680fe.m4887m(parcel, readInt);
            } else {
                iBinder2 = C0680fe.m4876i(parcel, readInt);
            }
        }
        C0680fe.m4863f(parcel, b);
        return new C0312bm(z, iBinder, iBinder2);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new C0312bm[i];
    }
}
