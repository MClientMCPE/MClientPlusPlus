package p000;

/* renamed from: cn */
public interface C0382cn {
    /* renamed from: I */
    void mo2278I();

    /* renamed from: J */
    void mo2279J();

    void onPause();

    void onResume();
}
