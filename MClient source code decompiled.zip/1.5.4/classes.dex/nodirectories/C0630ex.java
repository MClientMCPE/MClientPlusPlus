package p000;

import android.os.IBinder;

/* renamed from: ex */
public final class C0630ex extends rj2 implements C0498cx {
    public C0630ex(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.formats.client.IShouldDelayBannerRenderingListener");
    }
}
