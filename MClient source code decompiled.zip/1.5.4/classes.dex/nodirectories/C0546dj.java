package p000;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Uri;
import android.view.MotionEvent;
import android.widget.FrameLayout;
import android.widget.ImageView;
import java.io.File;
import org.json.JSONException;
import org.json.JSONObject;

@SuppressLint({"AppCompatCustomView"})
/* renamed from: dj */
public class C0546dj extends ImageView {

    /* renamed from: a0 */
    public int f3906a0;

    /* renamed from: b0 */
    public int f3907b0;

    /* renamed from: c0 */
    public int f3908c0;

    /* renamed from: d0 */
    public int f3909d0;

    /* renamed from: e0 */
    public int f3910e0;

    /* renamed from: f0 */
    public boolean f3911f0;

    /* renamed from: g0 */
    public boolean f3912g0;

    /* renamed from: h0 */
    public boolean f3913h0;

    /* renamed from: i0 */
    public String f3914i0;

    /* renamed from: j0 */
    public String f3915j0;

    /* renamed from: k0 */
    public C1249lg f3916k0;

    /* renamed from: l0 */
    public C1335mg f3917l0;

    public C0546dj(Context context, C1249lg lgVar, int i, C1335mg mgVar) {
        super(context);
        this.f3906a0 = i;
        this.f3916k0 = lgVar;
        this.f3917l0 = mgVar;
    }

    /* renamed from: a */
    public final boolean mo4806a(C1249lg lgVar) {
        JSONObject jSONObject = lgVar.f9623b;
        return jSONObject.optInt("id") == this.f3906a0 && jSONObject.optInt("container_id") == this.f3917l0.f10220j0 && jSONObject.optString("ad_session_id").equals(this.f3917l0.f10222l0);
    }

    /* renamed from: b */
    public final void mo4807b(C1249lg lgVar) {
        JSONObject jSONObject = lgVar.f9623b;
        this.f3907b0 = jSONObject.optInt("x");
        this.f3908c0 = jSONObject.optInt("y");
        this.f3909d0 = jSONObject.optInt("width");
        this.f3910e0 = jSONObject.optInt("height");
        if (this.f3911f0) {
            float k = (((float) this.f3910e0) * C0680fe.m4730a().mo11966g().mo8006k()) / ((float) getDrawable().getIntrinsicHeight());
            this.f3910e0 = (int) (((float) getDrawable().getIntrinsicHeight()) * k);
            int intrinsicWidth = (int) (((float) getDrawable().getIntrinsicWidth()) * k);
            this.f3909d0 = intrinsicWidth;
            this.f3907b0 -= intrinsicWidth;
            this.f3908c0 -= this.f3910e0;
        }
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) getLayoutParams();
        layoutParams.setMargins(this.f3907b0, this.f3908c0, 0, 0);
        layoutParams.width = this.f3909d0;
        layoutParams.height = this.f3910e0;
        setLayoutParams(layoutParams);
    }

    /* renamed from: c */
    public final void mo4808c(C1249lg lgVar) {
        this.f3914i0 = lgVar.f9623b.optString("filepath");
        setImageURI(Uri.fromFile(new File(this.f3914i0)));
    }

    /* renamed from: d */
    public final void mo4809d(C1249lg lgVar) {
        setVisibility(lgVar.f9623b.optBoolean("visible") ? 0 : 4);
    }

    @SuppressLint({"ClickableViewAccessibility"})
    public boolean onTouchEvent(MotionEvent motionEvent) {
        String str;
        String str2;
        String str3;
        String str4;
        String str5;
        MotionEvent motionEvent2 = motionEvent;
        C2120vg a = C0680fe.m4730a();
        C1422ng f = a.mo11965f();
        int action = motionEvent.getAction() & 255;
        if (action != 0 && action != 1 && action != 3 && action != 2 && action != 5 && action != 6) {
            return false;
        }
        int x = (int) motionEvent.getX();
        int y = (int) motionEvent.getY();
        JSONObject jSONObject = new JSONObject();
        C0680fe.m4784a(jSONObject, "view_id", this.f3906a0);
        C0680fe.m4785a(jSONObject, "ad_session_id", this.f3915j0);
        C0680fe.m4784a(jSONObject, "container_x", this.f3907b0 + x);
        C0680fe.m4784a(jSONObject, "container_y", this.f3908c0 + y);
        C0680fe.m4784a(jSONObject, "view_x", x);
        C0680fe.m4784a(jSONObject, "view_y", y);
        C0680fe.m4784a(jSONObject, "id", this.f3917l0.getId());
        String str6 = "AdContainer.on_touch_began";
        if (action != 0) {
            String str7 = "AdContainer.on_touch_cancelled";
            if (action == 1) {
                str4 = "m_type";
                if (!this.f3917l0.f10231u0) {
                    a.f16048m = f.f11074d.get(this.f3915j0);
                }
                if (x <= 0 || x >= this.f3909d0 || y <= 0 || y >= this.f3910e0) {
                    str2 = str4;
                    try {
                        jSONObject.put("m_target", this.f3917l0.f10221k0);
                    } catch (JSONException e) {
                        JSONException jSONException = e;
                        StringBuilder a2 = C0789gk.m5562a("JSON Error in ADCMessage constructor: ");
                        a2.append(jSONException.toString());
                        C0869hj.f6827i.mo6566a(a2.toString());
                    }
                    if (jSONObject == null) {
                        jSONObject = new JSONObject();
                    }
                    str = str7;
                    C0680fe.m4785a(jSONObject, str2, str);
                    C0680fe.m4730a().mo11970k().mo9679a(jSONObject);
                    return true;
                }
                try {
                    jSONObject.put("m_target", this.f3917l0.f10221k0);
                } catch (JSONException e2) {
                    JSONException jSONException2 = e2;
                    StringBuilder a3 = C0789gk.m5562a("JSON Error in ADCMessage constructor: ");
                    a3.append(jSONException2.toString());
                    C0869hj.f6827i.mo6566a(a3.toString());
                }
                if (jSONObject == null) {
                    jSONObject = new JSONObject();
                }
                str5 = "AdContainer.on_touch_ended";
            } else if (action != 2) {
                if (action == 3) {
                    str4 = "m_type";
                    try {
                        jSONObject.put("m_target", this.f3917l0.f10221k0);
                    } catch (JSONException e3) {
                        JSONException jSONException3 = e3;
                        StringBuilder a4 = C0789gk.m5562a("JSON Error in ADCMessage constructor: ");
                        a4.append(jSONException3.toString());
                        C0869hj.f6827i.mo6566a(a4.toString());
                    }
                    if (jSONObject == null) {
                        jSONObject = new JSONObject();
                        str = str7;
                    } else {
                        str2 = str4;
                        str = str7;
                        C0680fe.m4785a(jSONObject, str2, str);
                        C0680fe.m4730a().mo11970k().mo9679a(jSONObject);
                        return true;
                    }
                } else if (action == 5) {
                    str4 = "m_type";
                    int action2 = (motionEvent.getAction() & 65280) >> 8;
                    C0680fe.m4784a(jSONObject, "container_x", ((int) motionEvent2.getX(action2)) + this.f3907b0);
                    C0680fe.m4784a(jSONObject, "container_y", ((int) motionEvent2.getY(action2)) + this.f3908c0);
                    C0680fe.m4784a(jSONObject, "view_x", (int) motionEvent2.getX(action2));
                    C0680fe.m4784a(jSONObject, "view_y", (int) motionEvent2.getY(action2));
                    try {
                        jSONObject.put("m_target", this.f3917l0.f10221k0);
                    } catch (JSONException e4) {
                        JSONException jSONException4 = e4;
                        StringBuilder a5 = C0789gk.m5562a("JSON Error in ADCMessage constructor: ");
                        a5.append(jSONException4.toString());
                        C0869hj.f6827i.mo6566a(a5.toString());
                    }
                    if (jSONObject == null) {
                        jSONObject = new JSONObject();
                        str = str6;
                    } else {
                        str3 = str4;
                    }
                } else if (action != 6) {
                    return true;
                } else {
                    int action3 = (motionEvent.getAction() & 65280) >> 8;
                    int x2 = (int) motionEvent2.getX(action3);
                    int y2 = (int) motionEvent2.getY(action3);
                    str4 = "m_type";
                    C0680fe.m4784a(jSONObject, "container_x", ((int) motionEvent2.getX(action3)) + this.f3907b0);
                    C0680fe.m4784a(jSONObject, "container_y", ((int) motionEvent2.getY(action3)) + this.f3908c0);
                    C0680fe.m4784a(jSONObject, "view_x", (int) motionEvent2.getX(action3));
                    C0680fe.m4784a(jSONObject, "view_y", (int) motionEvent2.getY(action3));
                    if (!this.f3917l0.f10231u0) {
                        a.f16048m = f.f11074d.get(this.f3915j0);
                    }
                    if (x2 <= 0 || x2 >= this.f3909d0 || y2 <= 0 || y2 >= this.f3910e0) {
                        try {
                            jSONObject.put("m_target", this.f3917l0.f10221k0);
                        } catch (JSONException e5) {
                            JSONException jSONException5 = e5;
                            StringBuilder a6 = C0789gk.m5562a("JSON Error in ADCMessage constructor: ");
                            a6.append(jSONException5.toString());
                            C0869hj.f6827i.mo6566a(a6.toString());
                        }
                        if (jSONObject == null) {
                            jSONObject = new JSONObject();
                        }
                        str = str7;
                    } else {
                        try {
                            jSONObject.put("m_target", this.f3917l0.f10221k0);
                        } catch (JSONException e6) {
                            JSONException jSONException6 = e6;
                            StringBuilder a7 = C0789gk.m5562a("JSON Error in ADCMessage constructor: ");
                            a7.append(jSONException6.toString());
                            C0869hj.f6827i.mo6566a(a7.toString());
                        }
                        if (jSONObject == null) {
                            jSONObject = new JSONObject();
                        }
                        str5 = "AdContainer.on_touch_ended";
                    }
                }
                str2 = str4;
                C0680fe.m4785a(jSONObject, str2, str);
                C0680fe.m4730a().mo11970k().mo9679a(jSONObject);
                return true;
            } else {
                str4 = "m_type";
                try {
                    jSONObject.put("m_target", this.f3917l0.f10221k0);
                } catch (JSONException e7) {
                    JSONException jSONException7 = e7;
                    StringBuilder a8 = C0789gk.m5562a("JSON Error in ADCMessage constructor: ");
                    a8.append(jSONException7.toString());
                    C0869hj.f6827i.mo6566a(a8.toString());
                }
                if (jSONObject == null) {
                    jSONObject = new JSONObject();
                }
                str5 = "AdContainer.on_touch_moved";
            }
            C0680fe.m4785a(jSONObject, str4, str5);
            C0680fe.m4730a().mo11970k().mo9679a(jSONObject);
            return true;
        }
        str3 = "m_type";
        try {
            jSONObject.put("m_target", this.f3917l0.f10221k0);
        } catch (JSONException e8) {
            JSONException jSONException8 = e8;
            StringBuilder a9 = C0789gk.m5562a("JSON Error in ADCMessage constructor: ");
            a9.append(jSONException8.toString());
            C0869hj.f6827i.mo6566a(a9.toString());
        }
        if (jSONObject == null) {
            jSONObject = new JSONObject();
        }
        str = str6;
        C0680fe.m4785a(jSONObject, str2, str);
        C0680fe.m4730a().mo11970k().mo9679a(jSONObject);
        return true;
    }
}
