package p000;

import android.view.View;
import androidx.databinding.ViewDataBinding;
import java.util.Collections;
import java.util.List;

/* renamed from: c9 */
public abstract class C0362c9 {
    /* renamed from: a */
    public abstract int mo2867a(String str);

    /* renamed from: a */
    public abstract ViewDataBinding mo2868a(C0593e9 e9Var, View view, int i);

    /* renamed from: a */
    public abstract ViewDataBinding mo2869a(C0593e9 e9Var, View[] viewArr, int i);

    /* renamed from: a */
    public List<C0362c9> mo2870a() {
        return Collections.emptyList();
    }
}
