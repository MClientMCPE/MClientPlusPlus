package p000;

import android.os.Parcelable;
import com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel;

/* renamed from: an */
public final class C0118an implements Parcelable.Creator<AdOverlayInfoParcel> {
    /* JADX WARNING: type inference failed for: r2v3, types: [android.os.Parcelable] */
    /* JADX WARNING: type inference failed for: r2v4, types: [android.os.Parcelable] */
    /* JADX WARNING: type inference failed for: r2v5, types: [android.os.Parcelable] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final /* synthetic */ java.lang.Object createFromParcel(android.os.Parcel r22) {
        /*
            r21 = this;
            r0 = r22
            int r1 = p000.C0680fe.m4795b((android.os.Parcel) r22)
            r2 = 0
            r3 = 0
            r5 = r3
            r6 = r5
            r7 = r6
            r8 = r7
            r9 = r8
            r10 = r9
            r12 = r10
            r13 = r12
            r16 = r13
            r17 = r16
            r18 = r17
            r19 = r18
            r20 = r19
            r11 = 0
            r14 = 0
            r15 = 0
        L_0x001d:
            int r2 = r22.dataPosition()
            if (r2 >= r1) goto L_0x0093
            int r2 = r22.readInt()
            r3 = 65535(0xffff, float:9.1834E-41)
            r3 = r3 & r2
            switch(r3) {
                case 2: goto L_0x0089;
                case 3: goto L_0x0084;
                case 4: goto L_0x007f;
                case 5: goto L_0x007a;
                case 6: goto L_0x0075;
                case 7: goto L_0x0070;
                case 8: goto L_0x006b;
                case 9: goto L_0x0066;
                case 10: goto L_0x0061;
                case 11: goto L_0x005c;
                case 12: goto L_0x0057;
                case 13: goto L_0x0052;
                case 14: goto L_0x0047;
                case 15: goto L_0x002e;
                case 16: goto L_0x0042;
                case 17: goto L_0x0037;
                case 18: goto L_0x0032;
                default: goto L_0x002e;
            }
        L_0x002e:
            p000.C0680fe.m4887m(r0, r2)
            goto L_0x001d
        L_0x0032:
            android.os.IBinder r20 = p000.C0680fe.m4876i(r0, r2)
            goto L_0x001d
        L_0x0037:
            android.os.Parcelable$Creator<un> r3 = p000.C2063un.CREATOR
            android.os.Parcelable r2 = p000.C0680fe.m4682a((android.os.Parcel) r0, (int) r2, r3)
            r19 = r2
            un r19 = (p000.C2063un) r19
            goto L_0x001d
        L_0x0042:
            java.lang.String r18 = p000.C0680fe.m4826c((android.os.Parcel) r0, (int) r2)
            goto L_0x001d
        L_0x0047:
            android.os.Parcelable$Creator<nf0> r3 = p000.nf0.CREATOR
            android.os.Parcelable r2 = p000.C0680fe.m4682a((android.os.Parcel) r0, (int) r2, r3)
            r17 = r2
            nf0 r17 = (p000.nf0) r17
            goto L_0x001d
        L_0x0052:
            java.lang.String r16 = p000.C0680fe.m4826c((android.os.Parcel) r0, (int) r2)
            goto L_0x001d
        L_0x0057:
            int r15 = p000.C0680fe.m4879j(r0, r2)
            goto L_0x001d
        L_0x005c:
            int r14 = p000.C0680fe.m4879j(r0, r2)
            goto L_0x001d
        L_0x0061:
            android.os.IBinder r13 = p000.C0680fe.m4876i(r0, r2)
            goto L_0x001d
        L_0x0066:
            java.lang.String r12 = p000.C0680fe.m4826c((android.os.Parcel) r0, (int) r2)
            goto L_0x001d
        L_0x006b:
            boolean r11 = p000.C0680fe.m4869g(r0, r2)
            goto L_0x001d
        L_0x0070:
            java.lang.String r10 = p000.C0680fe.m4826c((android.os.Parcel) r0, (int) r2)
            goto L_0x001d
        L_0x0075:
            android.os.IBinder r9 = p000.C0680fe.m4876i(r0, r2)
            goto L_0x001d
        L_0x007a:
            android.os.IBinder r8 = p000.C0680fe.m4876i(r0, r2)
            goto L_0x001d
        L_0x007f:
            android.os.IBinder r7 = p000.C0680fe.m4876i(r0, r2)
            goto L_0x001d
        L_0x0084:
            android.os.IBinder r6 = p000.C0680fe.m4876i(r0, r2)
            goto L_0x001d
        L_0x0089:
            android.os.Parcelable$Creator<rm> r3 = p000.C1766rm.CREATOR
            android.os.Parcelable r2 = p000.C0680fe.m4682a((android.os.Parcel) r0, (int) r2, r3)
            r5 = r2
            rm r5 = (p000.C1766rm) r5
            goto L_0x001d
        L_0x0093:
            p000.C0680fe.m4863f(r0, r1)
            com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel r0 = new com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel
            r4 = r0
            r4.<init>(r5, r6, r7, r8, r9, r10, r11, r12, r13, r14, r15, r16, r17, r18, r19, r20)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0118an.createFromParcel(android.os.Parcel):java.lang.Object");
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new AdOverlayInfoParcel[i];
    }
}
