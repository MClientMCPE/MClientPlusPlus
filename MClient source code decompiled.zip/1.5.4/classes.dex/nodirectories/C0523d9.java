package p000;

import android.util.Log;
import android.view.View;
import androidx.databinding.ViewDataBinding;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;

/* renamed from: d9 */
public class C0523d9 extends C0362c9 {

    /* renamed from: a */
    public Set<Class<? extends C0362c9>> f3763a = new HashSet();

    /* renamed from: b */
    public List<C0362c9> f3764b = new CopyOnWriteArrayList();

    /* renamed from: c */
    public List<String> f3765c = new CopyOnWriteArrayList();

    public C0523d9() {
        mo4699a((C0362c9) new tf3());
    }

    /* renamed from: a */
    public void mo4699a(C0362c9 c9Var) {
        if (this.f3763a.add(c9Var.getClass())) {
            this.f3764b.add(c9Var);
            for (C0362c9 a : c9Var.mo2870a()) {
                mo4699a(a);
            }
        }
    }

    /* renamed from: b */
    public final boolean mo4700b() {
        StringBuilder sb;
        boolean z = false;
        for (String next : this.f3765c) {
            try {
                Class<?> cls = Class.forName(next);
                if (C0362c9.class.isAssignableFrom(cls)) {
                    mo4699a((C0362c9) cls.newInstance());
                    this.f3765c.remove(next);
                    z = true;
                }
            } catch (ClassNotFoundException unused) {
            } catch (IllegalAccessException e) {
                e = e;
                sb = new StringBuilder();
                sb.append("unable to add feature mapper for ");
                sb.append(next);
                Log.e("MergedDataBinderMapper", sb.toString(), e);
            } catch (InstantiationException e2) {
                e = e2;
                sb = new StringBuilder();
                sb.append("unable to add feature mapper for ");
                sb.append(next);
                Log.e("MergedDataBinderMapper", sb.toString(), e);
            }
        }
        return z;
    }

    /* renamed from: a */
    public ViewDataBinding mo2868a(C0593e9 e9Var, View view, int i) {
        for (C0362c9 a : this.f3764b) {
            ViewDataBinding a2 = a.mo2868a(e9Var, view, i);
            if (a2 != null) {
                return a2;
            }
        }
        if (mo4700b()) {
            return mo2868a(e9Var, view, i);
        }
        return null;
    }

    /* renamed from: a */
    public ViewDataBinding mo2869a(C0593e9 e9Var, View[] viewArr, int i) {
        for (C0362c9 a : this.f3764b) {
            ViewDataBinding a2 = a.mo2869a(e9Var, viewArr, i);
            if (a2 != null) {
                return a2;
            }
        }
        if (mo4700b()) {
            return mo2869a(e9Var, viewArr, i);
        }
        return null;
    }

    /* renamed from: a */
    public int mo2867a(String str) {
        for (C0362c9 a : this.f3764b) {
            int a2 = a.mo2867a(str);
            if (a2 != 0) {
                return a2;
            }
        }
        if (mo4700b()) {
            return mo2867a(str);
        }
        return 0;
    }
}
