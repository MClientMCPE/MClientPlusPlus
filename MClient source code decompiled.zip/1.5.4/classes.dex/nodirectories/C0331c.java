package p000;

import androidx.activity.OnBackPressedDispatcher;

/* renamed from: c */
public interface C0331c extends C1509ob {
    /* renamed from: b */
    OnBackPressedDispatcher mo636b();
}
