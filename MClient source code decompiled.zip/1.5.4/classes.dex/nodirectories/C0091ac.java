package p000;

import java.util.HashMap;

/* renamed from: ac */
public class C0091ac {

    /* renamed from: a */
    public final HashMap<String, C2265xb> f345a = new HashMap<>();

    /* renamed from: a */
    public final void mo361a() {
        for (C2265xb a : this.f345a.values()) {
            a.mo12488a();
        }
        this.f345a.clear();
    }
}
