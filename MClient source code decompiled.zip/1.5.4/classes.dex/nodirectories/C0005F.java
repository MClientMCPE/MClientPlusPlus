package p000;

import java.io.ByteArrayOutputStream;

/* renamed from: F */
public class C0005F {

    /* renamed from: a */
    public static boolean f4a = true;

    /* renamed from: b */
    public static int m29b() {
        return -1752553 ^ m32e((Object) "");
    }

    /* renamed from: c */
    public static String m30c(String str) {
        String str2 = str;
        String f = C0003D.m25f();
        String f2 = C0003D.m25f();
        for (int i = 0; i < 15; i++) {
            f = C0000A.m4f(C0000A.m1c(C0000A.m1c(new StringBuffer(), f), C0001B.m9d(i)));
            f2 = C0000A.m4f(C0002C.m15b(C0000A.m1c(new StringBuffer(), f2), ((int) (C0001B.m14i() * ((double) 10))) ^ i));
        }
        do {
        } while (C0002C.m16c(f) > 0);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(C0002C.m16c(str2) / 2);
        for (int i2 = 0; i2 < C0002C.m16c(str2); i2 += 2) {
            C0000A.m6h(byteArrayOutputStream, (C0003D.m21b(f, C0003D.m23d(str2, i2)) << 4) | C0003D.m21b(f, C0003D.m23d(str2, i2 + 1)));
        }
        byte[] g = C0001B.m12g(byteArrayOutputStream);
        int length = g.length;
        int c = C0002C.m16c(f2);
        for (int i3 = 0; i3 < length; i3++) {
            g[i3] = (byte) (g[i3] ^ C0003D.m23d(f2, i3 % c));
        }
        return new String(g);
    }

    /* renamed from: e */
    public static int m32e(Object obj) {
        return obj.hashCode();
    }

    /* renamed from: e */
    public static Class<?> m33e(String str) throws ClassNotFoundException {
        return Class.forName(str);
    }

    /* JADX WARNING: type inference failed for: r57v0, types: [int] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* renamed from: d */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String m31d(short[] r54, int r55, int r56, int r57) {
        /*
            r6 = r57
            r5 = r56
            r4 = r55
            r3 = r54
            char[] r1 = new char[r5]
            r0 = 0
        L_0x000b:
            if (r0 >= r5) goto L_0x0018
            int r2 = r4 + r0
            short r2 = r3[r2]
            r2 = r2 ^ r6
            char r2 = (char) r2
            r1[r0] = r2
            int r0 = r0 + 1
            goto L_0x000b
        L_0x0018:
            java.lang.String r0 = new java.lang.String
            r0.<init>(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0005F.m31d(short[], int, int, int):java.lang.String");
    }

    /* JADX WARNING: type inference failed for: r57v0, types: [int] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* renamed from: e */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String m34e(short[] r54, int r55, int r56, int r57) {
        /*
            r6 = r57
            r5 = r56
            r4 = r55
            r3 = r54
            char[] r1 = new char[r5]
            r0 = 0
        L_0x000b:
            if (r0 >= r5) goto L_0x0018
            int r2 = r4 + r0
            short r2 = r3[r2]
            r2 = r2 ^ r6
            char r2 = (char) r2
            r1[r0] = r2
            int r0 = r0 + 1
            goto L_0x000b
        L_0x0018:
            java.lang.String r0 = new java.lang.String
            r0.<init>(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0005F.m34e(short[], int, int, int):java.lang.String");
    }
}
