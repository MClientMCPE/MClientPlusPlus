package p000;

/* renamed from: g9 */
public interface C0763g9 {
    /* renamed from: a */
    void mo2553a();
}
