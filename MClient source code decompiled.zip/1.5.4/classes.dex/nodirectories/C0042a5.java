package p000;

import java.util.Map;

/* renamed from: a5 */
public class C0042a5 extends C0658f5<E, E> {

    /* renamed from: d */
    public final /* synthetic */ C0283b5 f187d;

    public C0042a5(C0283b5 b5Var) {
        this.f187d = b5Var;
    }

    /* renamed from: a */
    public int mo209a(Object obj) {
        return this.f187d.indexOf(obj);
    }

    /* renamed from: a */
    public Object mo210a(int i, int i2) {
        return this.f187d.f1717Y[i];
    }

    /* renamed from: a */
    public E mo211a(int i, E e) {
        throw new UnsupportedOperationException("not a map");
    }

    /* renamed from: a */
    public void mo212a() {
        this.f187d.clear();
    }

    /* renamed from: a */
    public void mo213a(int i) {
        this.f187d.mo2336d(i);
    }

    /* renamed from: a */
    public void mo214a(E e, E e2) {
        this.f187d.add(e);
    }

    /* renamed from: b */
    public int mo215b(Object obj) {
        return this.f187d.indexOf(obj);
    }

    /* renamed from: b */
    public Map<E, E> mo216b() {
        throw new UnsupportedOperationException("not a map");
    }

    /* renamed from: c */
    public int mo217c() {
        return this.f187d.f1718Z;
    }
}
