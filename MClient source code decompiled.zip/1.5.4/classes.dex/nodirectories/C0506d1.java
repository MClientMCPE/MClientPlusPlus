package p000;

import android.content.Context;
import android.view.MenuItem;
import android.view.SubMenu;
import java.util.Map;

/* renamed from: d1 */
public abstract class C0506d1 {

    /* renamed from: a */
    public final Context f3625a;

    /* renamed from: b */
    public Map<C1800s6, MenuItem> f3626b;

    /* renamed from: c */
    public Map<C1901t6, SubMenu> f3627c;

    public C0506d1(Context context) {
        this.f3625a = context;
    }

    /* renamed from: a */
    public final MenuItem mo4542a(MenuItem menuItem) {
        if (!(menuItem instanceof C1800s6)) {
            return menuItem;
        }
        C1800s6 s6Var = (C1800s6) menuItem;
        if (this.f3626b == null) {
            this.f3626b = new C2399z4();
        }
        MenuItem menuItem2 = this.f3626b.get(menuItem);
        if (menuItem2 != null) {
            return menuItem2;
        }
        C1208l1 l1Var = new C1208l1(this.f3625a, s6Var);
        this.f3626b.put(s6Var, l1Var);
        return l1Var;
    }

    /* renamed from: a */
    public final SubMenu mo4543a(SubMenu subMenu) {
        if (!(subMenu instanceof C1901t6)) {
            return subMenu;
        }
        C1901t6 t6Var = (C1901t6) subMenu;
        if (this.f3627c == null) {
            this.f3627c = new C2399z4();
        }
        SubMenu subMenu2 = this.f3627c.get(t6Var);
        if (subMenu2 != null) {
            return subMenu2;
        }
        C2175w1 w1Var = new C2175w1(this.f3625a, t6Var);
        this.f3627c.put(t6Var, w1Var);
        return w1Var;
    }
}
