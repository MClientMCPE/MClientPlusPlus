package p000;

import java.net.URL;

/* renamed from: gj */
public class C0788gj {

    /* renamed from: a */
    public URL f6184a;

    public C0788gj(URL url) {
        this.f6184a = url;
    }

    /* JADX WARNING: Removed duplicated region for block: B:45:0x0081  */
    /* JADX WARNING: Removed duplicated region for block: B:47:0x0086  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int mo6120a(java.lang.String r7) {
        /*
            r6 = this;
            r0 = 1
            r1 = 0
            r2 = 0
            java.net.URL r3 = r6.f6184a     // Catch:{ IOException -> 0x0071, all -> 0x006d }
            java.net.URLConnection r3 = r3.openConnection()     // Catch:{ IOException -> 0x0071, all -> 0x006d }
            java.net.HttpURLConnection r3 = (java.net.HttpURLConnection) r3     // Catch:{ IOException -> 0x0071, all -> 0x006d }
            java.lang.String r4 = "POST"
            r3.setRequestMethod(r4)     // Catch:{ IOException -> 0x006b, all -> 0x0069 }
            java.lang.String r4 = "Content-Encoding"
            java.lang.String r5 = "gzip"
            r3.setRequestProperty(r4, r5)     // Catch:{ IOException -> 0x006b, all -> 0x0069 }
            java.lang.String r4 = "Content-Type"
            java.lang.String r5 = "application/json"
            r3.setRequestProperty(r4, r5)     // Catch:{ IOException -> 0x006b, all -> 0x0069 }
            r3.setDoInput(r0)     // Catch:{ IOException -> 0x006b, all -> 0x0069 }
            java.util.zip.GZIPOutputStream r4 = new java.util.zip.GZIPOutputStream     // Catch:{ IOException -> 0x006b, all -> 0x0069 }
            java.io.OutputStream r5 = r3.getOutputStream()     // Catch:{ IOException -> 0x006b, all -> 0x0069 }
            r4.<init>(r5)     // Catch:{ IOException -> 0x006b, all -> 0x0069 }
            java.io.DataOutputStream r5 = new java.io.DataOutputStream     // Catch:{ IOException -> 0x0067, all -> 0x0065 }
            r5.<init>(r4)     // Catch:{ IOException -> 0x0067, all -> 0x0065 }
            java.lang.String r1 = "UTF-8"
            java.nio.charset.Charset r1 = java.nio.charset.Charset.forName(r1)     // Catch:{ IOException -> 0x0061, all -> 0x005e }
            byte[] r7 = r7.getBytes(r1)     // Catch:{ IOException -> 0x0061, all -> 0x005e }
            r5.write(r7)     // Catch:{ IOException -> 0x0061, all -> 0x005e }
            r5.close()     // Catch:{ IOException -> 0x0061, all -> 0x005e }
            int r7 = r3.getResponseCode()     // Catch:{ IOException -> 0x005b, all -> 0x0057 }
            r4.close()
            java.io.InputStream r0 = r3.getInputStream()
            if (r0 == 0) goto L_0x0053
            java.io.InputStream r0 = r3.getInputStream()
            r0.close()
        L_0x0053:
            r3.disconnect()
            return r7
        L_0x0057:
            r7 = move-exception
            r1 = r5
            r2 = 1
            goto L_0x0078
        L_0x005b:
            r7 = move-exception
            r2 = 1
            goto L_0x0062
        L_0x005e:
            r7 = move-exception
            r1 = r5
            goto L_0x0078
        L_0x0061:
            r7 = move-exception
        L_0x0062:
            r0 = r2
            r1 = r5
            goto L_0x0075
        L_0x0065:
            r7 = move-exception
            goto L_0x0078
        L_0x0067:
            r7 = move-exception
            goto L_0x0074
        L_0x0069:
            r7 = move-exception
            goto L_0x006f
        L_0x006b:
            r7 = move-exception
            goto L_0x0073
        L_0x006d:
            r7 = move-exception
            r3 = r1
        L_0x006f:
            r4 = r1
            goto L_0x0078
        L_0x0071:
            r7 = move-exception
            r3 = r1
        L_0x0073:
            r4 = r1
        L_0x0074:
            r0 = 0
        L_0x0075:
            throw r7     // Catch:{ all -> 0x0076 }
        L_0x0076:
            r7 = move-exception
            r2 = r0
        L_0x0078:
            if (r1 == 0) goto L_0x007f
            if (r2 != 0) goto L_0x007f
            r1.close()
        L_0x007f:
            if (r4 == 0) goto L_0x0084
            r4.close()
        L_0x0084:
            if (r3 == 0) goto L_0x0096
            java.io.InputStream r0 = r3.getInputStream()
            if (r0 == 0) goto L_0x0093
            java.io.InputStream r0 = r3.getInputStream()
            r0.close()
        L_0x0093:
            r3.disconnect()
        L_0x0096:
            throw r7
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0788gj.mo6120a(java.lang.String):int");
    }
}
