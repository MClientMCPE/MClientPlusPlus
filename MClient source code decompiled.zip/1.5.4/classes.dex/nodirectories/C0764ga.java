package p000;

import androidx.fragment.app.Fragment;
import java.lang.reflect.InvocationTargetException;

/* renamed from: ga */
public class C0764ga {

    /* renamed from: a */
    public static final C0754g5<String, Class<?>> f6073a = new C0754g5<>();

    /* renamed from: b */
    public static boolean m5413b(ClassLoader classLoader, String str) {
        try {
            return Fragment.class.isAssignableFrom(m5414c(classLoader, str));
        } catch (ClassNotFoundException unused) {
            return false;
        }
    }

    /* renamed from: c */
    public static Class<?> m5414c(ClassLoader classLoader, String str) {
        Class<?> orDefault = f6073a.getOrDefault(str, null);
        if (orDefault != null) {
            return orDefault;
        }
        Class<?> cls = Class.forName(str, false, classLoader);
        f6073a.put(str, cls);
        return cls;
    }

    /* renamed from: d */
    public static Class<? extends Fragment> m5415d(ClassLoader classLoader, String str) {
        try {
            return m5414c(classLoader, str);
        } catch (ClassNotFoundException e) {
            throw new Fragment.C0198d(C0789gk.m5558a("Unable to instantiate fragment ", str, ": make sure class name exists"), e);
        } catch (ClassCastException e2) {
            throw new Fragment.C0198d(C0789gk.m5558a("Unable to instantiate fragment ", str, ": make sure class is a valid subclass of Fragment"), e2);
        }
    }

    /* renamed from: a */
    public Fragment mo6059a(ClassLoader classLoader, String str) {
        try {
            return (Fragment) m5415d(classLoader, str).getConstructor(new Class[0]).newInstance(new Object[0]);
        } catch (InstantiationException e) {
            throw new Fragment.C0198d(C0789gk.m5558a("Unable to instantiate fragment ", str, ": make sure class name exists, is public, and has an empty constructor that is public"), e);
        } catch (IllegalAccessException e2) {
            throw new Fragment.C0198d(C0789gk.m5558a("Unable to instantiate fragment ", str, ": make sure class name exists, is public, and has an empty constructor that is public"), e2);
        } catch (NoSuchMethodException e3) {
            throw new Fragment.C0198d(C0789gk.m5558a("Unable to instantiate fragment ", str, ": could not find Fragment constructor"), e3);
        } catch (InvocationTargetException e4) {
            throw new Fragment.C0198d(C0789gk.m5558a("Unable to instantiate fragment ", str, ": calling Fragment constructor caused an exception"), e4);
        }
    }
}
