package p000;

import android.os.Bundle;
import android.view.View;
import java.util.List;
import java.util.Map;
import p000.C2059ul;

/* renamed from: ap */
public class C0263ap {

    /* renamed from: a */
    public String f1476a;

    /* renamed from: b */
    public List<C2059ul.C2061b> f1477b;

    /* renamed from: c */
    public String f1478c;

    /* renamed from: d */
    public C2059ul.C2061b f1479d;

    /* renamed from: e */
    public String f1480e;

    /* renamed from: f */
    public String f1481f;

    /* renamed from: g */
    public Double f1482g;

    /* renamed from: h */
    public String f1483h;

    /* renamed from: i */
    public String f1484i;

    /* renamed from: j */
    public C1342ml f1485j;

    /* renamed from: k */
    public boolean f1486k;

    /* renamed from: l */
    public View f1487l;

    /* renamed from: m */
    public View f1488m;

    /* renamed from: n */
    public Object f1489n;

    /* renamed from: o */
    public Bundle f1490o = new Bundle();

    /* renamed from: p */
    public boolean f1491p;

    /* renamed from: q */
    public boolean f1492q;

    /* renamed from: r */
    public float f1493r;

    /* renamed from: a */
    public void mo2099a() {
    }

    /* renamed from: a */
    public void mo2100a(View view, Map<String, View> map, Map<String, View> map2) {
        throw null;
    }

    /* renamed from: b */
    public void mo2101b() {
    }

    /* renamed from: c */
    public void mo2102c() {
    }
}
