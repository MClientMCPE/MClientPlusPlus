package p000;

import android.os.Build;
import java.util.HashMap;
import java.util.LinkedList;

/* renamed from: eo */
public final class C0619eo {

    /* renamed from: B */
    public static C0619eo f4708B = new C0619eo();

    /* renamed from: A */
    public final eg0 f4709A;

    /* renamed from: a */
    public final C1631pm f4710a;

    /* renamed from: b */
    public final C0313bn f4711b;

    /* renamed from: c */
    public final xc0 f4712c;

    /* renamed from: d */
    public final fk0 f4713d;

    /* renamed from: e */
    public final dd0 f4714e;

    /* renamed from: f */
    public final fs2 f4715f;

    /* renamed from: g */
    public final dc0 f4716g;

    /* renamed from: h */
    public final ld0 f4717h;

    /* renamed from: i */
    public final ht2 f4718i;

    /* renamed from: j */
    public final C0717fr f4719j;

    /* renamed from: k */
    public final C1767rn f4720k;

    /* renamed from: l */
    public final l03 f4721l;

    /* renamed from: m */
    public final td0 f4722m;

    /* renamed from: n */
    public final i80 f4723n;

    /* renamed from: o */
    public final vf0 f4724o;

    /* renamed from: p */
    public final i20 f4725p;

    /* renamed from: q */
    public final oe0 f4726q;

    /* renamed from: r */
    public final C1170kn f4727r;

    /* renamed from: s */
    public final C1088jn f4728s;

    /* renamed from: t */
    public final p30 f4729t;

    /* renamed from: u */
    public final qe0 f4730u;

    /* renamed from: v */
    public final n60 f4731v;

    /* renamed from: w */
    public final du2 f4732w;

    /* renamed from: x */
    public final ab0 f4733x;

    /* renamed from: y */
    public final we0 f4734y;

    /* renamed from: z */
    public final xi0 f4735z;

    public C0619eo() {
        C1631pm pmVar = new C1631pm();
        C0313bn bnVar = new C0313bn();
        xc0 xc0 = new xc0();
        fk0 fk0 = new fk0();
        int i = Build.VERSION.SDK_INT;
        dd0 jd0 = i >= 28 ? new jd0() : i >= 26 ? new kd0() : i >= 24 ? new hd0() : i >= 21 ? new id0() : new fd0();
        fs2 fs2 = new fs2();
        dc0 dc0 = new dc0();
        ld0 ld0 = new ld0();
        ht2 ht2 = new ht2();
        C0877hr hrVar = C0877hr.f6965a;
        C1767rn rnVar = new C1767rn();
        l03 l03 = new l03();
        td0 td0 = new td0();
        i80 i80 = new i80();
        vf0 vf0 = new vf0();
        i20 i20 = new i20();
        oe0 oe0 = new oe0();
        C1170kn knVar = new C1170kn();
        C1088jn jnVar = new C1088jn();
        p30 p30 = new p30();
        qe0 qe0 = new qe0();
        n60 n60 = new n60();
        du2 du2 = new du2();
        ab0 ab0 = new ab0();
        we0 we0 = new we0();
        xi0 xi0 = new xi0();
        eg0 eg0 = new eg0();
        this.f4710a = pmVar;
        this.f4711b = bnVar;
        this.f4712c = xc0;
        this.f4713d = fk0;
        this.f4714e = jd0;
        this.f4715f = fs2;
        this.f4716g = dc0;
        this.f4717h = ld0;
        this.f4718i = ht2;
        this.f4719j = hrVar;
        this.f4720k = rnVar;
        this.f4721l = l03;
        this.f4722m = td0;
        this.f4723n = i80;
        this.f4724o = vf0;
        new HashMap();
        new LinkedList();
        this.f4725p = i20;
        this.f4726q = oe0;
        this.f4727r = knVar;
        this.f4728s = jnVar;
        this.f4729t = p30;
        this.f4730u = qe0;
        this.f4731v = n60;
        this.f4732w = du2;
        this.f4733x = ab0;
        this.f4734y = we0;
        this.f4735z = xi0;
        this.f4709A = eg0;
    }

    /* renamed from: a */
    public static dc0 m4252a() {
        return f4708B.f4716g;
    }

    /* renamed from: b */
    public static C0717fr m4253b() {
        return f4708B.f4719j;
    }

    /* renamed from: c */
    public static vf0 m4254c() {
        return f4708B.f4724o;
    }
}
