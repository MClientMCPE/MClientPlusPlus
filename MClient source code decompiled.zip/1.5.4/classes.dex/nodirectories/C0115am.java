package p000;

/* renamed from: am */
public interface C0115am {

    /* renamed from: am$a */
    public interface C0116a {
    }

    /* renamed from: am$b */
    public interface C0117b {
    }
}
