package p000;

/* renamed from: au */
public final class C0268au {

    /* renamed from: a */
    public static C1878st<Long> f1549a = C1878st.m12903a("gads:content_age_weight", 1);

    /* renamed from: b */
    public static C1878st<Boolean> f1550b = C1878st.m12905a("gads:enable_content_fetching", true);

    /* renamed from: c */
    public static C1878st<Long> f1551c = C1878st.m12903a("gads:fingerprint_number", 10);

    /* renamed from: d */
    public static C1878st<Long> f1552d = C1878st.m12903a("gads:content_length_weight", 1);

    /* renamed from: e */
    public static C1878st<Long> f1553e = C1878st.m12903a("gads:min_content_len", 11);

    /* renamed from: f */
    public static C1878st<Long> f1554f = C1878st.m12903a("gads:sleep_sec", 10);
}
