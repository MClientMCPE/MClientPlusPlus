package p000;

/* renamed from: dn */
public final class C0550dn {

    /* renamed from: a */
    public int f3976a = 0;

    /* renamed from: b */
    public int f3977b = 0;

    /* renamed from: c */
    public int f3978c = 0;

    /* renamed from: d */
    public int f3979d = 32;
}
