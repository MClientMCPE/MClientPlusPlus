package p000;

/* renamed from: gm */
public final /* synthetic */ class C0792gm implements C2473zu {

    /* renamed from: a */
    public final C0549dm f6231a;

    public C0792gm(C0549dm dmVar) {
        this.f6231a = dmVar;
    }
}
