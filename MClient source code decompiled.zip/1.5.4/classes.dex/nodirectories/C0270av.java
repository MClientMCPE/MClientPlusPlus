package p000;

import android.view.MotionEvent;

/* renamed from: av */
public interface C0270av {
    /* renamed from: a */
    void mo195a();

    /* renamed from: a */
    void mo196a(MotionEvent motionEvent);
}
