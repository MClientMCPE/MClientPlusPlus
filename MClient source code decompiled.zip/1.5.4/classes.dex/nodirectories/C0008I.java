package p000;

import android.os.Handler;

/* renamed from: I */
public class C0008I {
    public C0008I() {
    }

    /* renamed from: c */
    public static int m36c() {
        if (C0001B.m8c() < 0) {
            return C0007H.f6999f0;
        }
        return 0;
    }

    /* renamed from: b */
    public void mo3b() {
        C0007H.f6999f0 = m36c() + 1;
        C0000A.m0b(new Handler(), new C0009J(this), 9999999);
    }
}
