package p000;

import android.os.Parcel;
import android.util.SparseIntArray;
import java.lang.reflect.Method;

/* renamed from: cf */
public class C0371cf extends C0300bf {

    /* renamed from: d */
    public final SparseIntArray f2685d;

    /* renamed from: e */
    public final Parcel f2686e;

    /* renamed from: f */
    public final int f2687f;

    /* renamed from: g */
    public final int f2688g;

    /* renamed from: h */
    public final String f2689h;

    /* renamed from: i */
    public int f2690i;

    /* renamed from: j */
    public int f2691j;

    /* renamed from: k */
    public int f2692k;

    public C0371cf(Parcel parcel) {
        this(parcel, parcel.dataPosition(), parcel.dataSize(), "", new C2399z4(), new C2399z4(), new C2399z4());
    }

    public C0371cf(Parcel parcel, int i, int i2, String str, C2399z4<String, Method> z4Var, C2399z4<String, Method> z4Var2, C2399z4<String, Class> z4Var3) {
        super(z4Var, z4Var2, z4Var3);
        this.f2685d = new SparseIntArray();
        this.f2690i = -1;
        this.f2691j = 0;
        this.f2692k = -1;
        this.f2686e = parcel;
        this.f2687f = i;
        this.f2688g = i2;
        this.f2691j = this.f2687f;
        this.f2689h = str;
    }

    /* renamed from: a */
    public void mo2504a() {
        int i = this.f2690i;
        if (i >= 0) {
            int i2 = this.f2685d.get(i);
            int dataPosition = this.f2686e.dataPosition();
            this.f2686e.setDataPosition(i2);
            this.f2686e.writeInt(dataPosition - i2);
            this.f2686e.setDataPosition(dataPosition);
        }
    }

    /* renamed from: a */
    public boolean mo2506a(int i) {
        while (this.f2691j < this.f2688g) {
            int i2 = this.f2692k;
            if (i2 == i) {
                return true;
            }
            if (String.valueOf(i2).compareTo(String.valueOf(i)) > 0) {
                return false;
            }
            this.f2686e.setDataPosition(this.f2691j);
            int readInt = this.f2686e.readInt();
            this.f2692k = this.f2686e.readInt();
            this.f2691j += readInt;
        }
        return this.f2692k == i;
    }

    /* renamed from: b */
    public C0300bf mo2508b() {
        Parcel parcel = this.f2686e;
        int dataPosition = parcel.dataPosition();
        int i = this.f2691j;
        if (i == this.f2687f) {
            i = this.f2688g;
        }
        return new C0371cf(parcel, dataPosition, i, C0789gk.m5559a(new StringBuilder(), this.f2689h, "  "), this.f1911a, this.f1912b, this.f1913c);
    }

    /* renamed from: b */
    public void mo2510b(int i) {
        mo2504a();
        this.f2690i = i;
        this.f2685d.put(i, this.f2686e.dataPosition());
        this.f2686e.writeInt(0);
        this.f2686e.writeInt(i);
    }

    /* renamed from: c */
    public String mo2513c() {
        return this.f2686e.readString();
    }
}
