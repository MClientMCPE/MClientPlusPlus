package p000;

/* renamed from: fj */
public class C0703fj {

    /* renamed from: a */
    public String f5407a;

    /* renamed from: b */
    public String f5408b;

    /* renamed from: c */
    public String f5409c;

    public C0703fj(String str, String str2, String str3) {
        this.f5407a = str;
        this.f5408b = str2;
        this.f5409c = str3;
    }
}
