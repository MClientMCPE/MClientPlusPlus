package p000;

/* renamed from: cq */
public final class C0491cq {
    public static final int common_google_play_services_unknown_issue = 2131755075;
}
