package p000;

import android.content.Context;
import java.util.List;

/* renamed from: fo */
public abstract class C0714fo implements C1541oo {
    public abstract C0315bp getSDKVersionInfo();

    public abstract C0315bp getVersionInfo();

    public abstract void initialize(Context context, C0794go goVar, List<C1470no> list);

    public void loadBannerAd(C1264lo loVar, C0951io<Object, Object> ioVar) {
        ioVar.mo7092a(getClass().getSimpleName().concat(" does not support banner ads."));
    }

    public void loadInterstitialAd(C1633po poVar, C0951io<Object, Object> ioVar) {
        ioVar.mo7092a(getClass().getSimpleName().concat(" does not support interstitial ads."));
    }

    public void loadNativeAd(C1768ro roVar, C0951io<C0263ap, Object> ioVar) {
        ioVar.mo7092a(getClass().getSimpleName().concat(" does not support native ads."));
    }

    public void loadRewardedAd(C1939to toVar, C0951io<Object, Object> ioVar) {
        ioVar.mo7092a(getClass().getSimpleName().concat(" does not support rewarded ads."));
    }
}
