package p000;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Resources;
import android.graphics.Rect;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityManager;
import com.google.ads.consent.ConsentData;

/* renamed from: b4 */
public class C0280b4 implements View.OnLongClickListener, View.OnHoverListener, View.OnAttachStateChangeListener {

    /* renamed from: g0 */
    public static C0280b4 f1686g0;

    /* renamed from: h0 */
    public static C0280b4 f1687h0;

    /* renamed from: X */
    public final View f1688X;

    /* renamed from: Y */
    public final CharSequence f1689Y;

    /* renamed from: Z */
    public final int f1690Z;

    /* renamed from: a0 */
    public final Runnable f1691a0 = new C0281a();

    /* renamed from: b0 */
    public final Runnable f1692b0 = new C0282b();

    /* renamed from: c0 */
    public int f1693c0;

    /* renamed from: d0 */
    public int f1694d0;

    /* renamed from: e0 */
    public C0338c4 f1695e0;

    /* renamed from: f0 */
    public boolean f1696f0;

    /* renamed from: b4$a */
    public class C0281a implements Runnable {
        public C0281a() {
        }

        public void run() {
            C0280b4.this.mo2314a(false);
        }
    }

    /* renamed from: b4$b */
    public class C0282b implements Runnable {
        public C0282b() {
        }

        public void run() {
            C0280b4.this.mo2315b();
        }
    }

    public C0280b4(View view, CharSequence charSequence) {
        this.f1688X = view;
        this.f1689Y = charSequence;
        this.f1690Z = C2406z7.m16905a(ViewConfiguration.get(this.f1688X.getContext()));
        mo2313a();
        this.f1688X.setOnLongClickListener(this);
        this.f1688X.setOnHoverListener(this);
    }

    /* renamed from: a */
    public static void m1717a(C0280b4 b4Var) {
        C0280b4 b4Var2 = f1686g0;
        if (b4Var2 != null) {
            b4Var2.f1688X.removeCallbacks(b4Var2.f1691a0);
        }
        f1686g0 = b4Var;
        C0280b4 b4Var3 = f1686g0;
        if (b4Var3 != null) {
            b4Var3.f1688X.postDelayed(b4Var3.f1691a0, (long) ViewConfiguration.getLongPressTimeout());
        }
    }

    /* renamed from: a */
    public final void mo2313a() {
        this.f1693c0 = Integer.MAX_VALUE;
        this.f1694d0 = Integer.MAX_VALUE;
    }

    /* renamed from: b */
    public void mo2315b() {
        if (f1687h0 == this) {
            f1687h0 = null;
            C0338c4 c4Var = this.f1695e0;
            if (c4Var != null) {
                c4Var.mo2789a();
                this.f1695e0 = null;
                mo2313a();
                this.f1688X.removeOnAttachStateChangeListener(this);
            } else {
                Log.e("TooltipCompatHandler", "sActiveHandler.mPopup == null");
            }
        }
        if (f1686g0 == this) {
            m1717a((C0280b4) null);
        }
        this.f1688X.removeCallbacks(this.f1692b0);
    }

    public boolean onHover(View view, MotionEvent motionEvent) {
        boolean z;
        if (this.f1695e0 != null && this.f1696f0) {
            return false;
        }
        AccessibilityManager accessibilityManager = (AccessibilityManager) this.f1688X.getContext().getSystemService("accessibility");
        if (accessibilityManager.isEnabled() && accessibilityManager.isTouchExplorationEnabled()) {
            return false;
        }
        int action = motionEvent.getAction();
        if (action != 7) {
            if (action == 10) {
                mo2313a();
                mo2315b();
            }
        } else if (this.f1688X.isEnabled() && this.f1695e0 == null) {
            int x = (int) motionEvent.getX();
            int y = (int) motionEvent.getY();
            if (Math.abs(x - this.f1693c0) > this.f1690Z || Math.abs(y - this.f1694d0) > this.f1690Z) {
                this.f1693c0 = x;
                this.f1694d0 = y;
                z = true;
            } else {
                z = false;
            }
            if (z) {
                m1717a(this);
            }
        }
        return false;
    }

    public boolean onLongClick(View view) {
        this.f1693c0 = view.getWidth() / 2;
        this.f1694d0 = view.getHeight() / 2;
        mo2314a(true);
        return true;
    }

    public void onViewAttachedToWindow(View view) {
    }

    public void onViewDetachedFromWindow(View view) {
        mo2315b();
    }

    /* renamed from: a */
    public void mo2314a(boolean z) {
        int i;
        int i2;
        long j;
        if (C2189w7.m15030y(this.f1688X)) {
            m1717a((C0280b4) null);
            C0280b4 b4Var = f1687h0;
            if (b4Var != null) {
                b4Var.mo2315b();
            }
            f1687h0 = this;
            this.f1696f0 = z;
            this.f1695e0 = new C0338c4(this.f1688X.getContext());
            C0338c4 c4Var = this.f1695e0;
            View view = this.f1688X;
            int i3 = this.f1693c0;
            int i4 = this.f1694d0;
            boolean z2 = this.f1696f0;
            CharSequence charSequence = this.f1689Y;
            if (c4Var.mo2790b()) {
                c4Var.mo2789a();
            }
            c4Var.f2491c.setText(charSequence);
            WindowManager.LayoutParams layoutParams = c4Var.f2492d;
            layoutParams.token = view.getApplicationWindowToken();
            int dimensionPixelOffset = c4Var.f2489a.getResources().getDimensionPixelOffset(C0729g.tooltip_precise_anchor_threshold);
            if (view.getWidth() < dimensionPixelOffset) {
                i3 = view.getWidth() / 2;
            }
            if (view.getHeight() >= dimensionPixelOffset) {
                int dimensionPixelOffset2 = c4Var.f2489a.getResources().getDimensionPixelOffset(C0729g.tooltip_precise_anchor_extra_offset);
                i = i4 + dimensionPixelOffset2;
                i2 = i4 - dimensionPixelOffset2;
            } else {
                i = view.getHeight();
                i2 = 0;
            }
            layoutParams.gravity = 49;
            int dimensionPixelOffset3 = c4Var.f2489a.getResources().getDimensionPixelOffset(z2 ? C0729g.tooltip_y_offset_touch : C0729g.tooltip_y_offset_non_touch);
            View rootView = view.getRootView();
            ViewGroup.LayoutParams layoutParams2 = rootView.getLayoutParams();
            if (!(layoutParams2 instanceof WindowManager.LayoutParams) || ((WindowManager.LayoutParams) layoutParams2).type != 2) {
                Context context = view.getContext();
                while (true) {
                    if (!(context instanceof ContextWrapper)) {
                        break;
                    } else if (context instanceof Activity) {
                        rootView = ((Activity) context).getWindow().getDecorView();
                        break;
                    } else {
                        context = ((ContextWrapper) context).getBaseContext();
                    }
                }
            }
            if (rootView == null) {
                Log.e("TooltipPopup", "Cannot find app view");
            } else {
                rootView.getWindowVisibleDisplayFrame(c4Var.f2493e);
                Rect rect = c4Var.f2493e;
                if (rect.left < 0 && rect.top < 0) {
                    Resources resources = c4Var.f2489a.getResources();
                    int identifier = resources.getIdentifier("status_bar_height", "dimen", ConsentData.SDK_PLATFORM);
                    int dimensionPixelSize = identifier != 0 ? resources.getDimensionPixelSize(identifier) : 0;
                    DisplayMetrics displayMetrics = resources.getDisplayMetrics();
                    c4Var.f2493e.set(0, dimensionPixelSize, displayMetrics.widthPixels, displayMetrics.heightPixels);
                }
                rootView.getLocationOnScreen(c4Var.f2495g);
                view.getLocationOnScreen(c4Var.f2494f);
                int[] iArr = c4Var.f2494f;
                int i5 = iArr[0];
                int[] iArr2 = c4Var.f2495g;
                iArr[0] = i5 - iArr2[0];
                iArr[1] = iArr[1] - iArr2[1];
                layoutParams.x = (iArr[0] + i3) - (rootView.getWidth() / 2);
                int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                c4Var.f2490b.measure(makeMeasureSpec, makeMeasureSpec);
                int measuredHeight = c4Var.f2490b.getMeasuredHeight();
                int[] iArr3 = c4Var.f2494f;
                int i6 = ((iArr3[1] + i2) - dimensionPixelOffset3) - measuredHeight;
                int i7 = iArr3[1] + i + dimensionPixelOffset3;
                if (!z2 ? measuredHeight + i7 > c4Var.f2493e.height() : i6 >= 0) {
                    layoutParams.y = i6;
                } else {
                    layoutParams.y = i7;
                }
            }
            ((WindowManager) c4Var.f2489a.getSystemService("window")).addView(c4Var.f2490b, c4Var.f2492d);
            this.f1688X.addOnAttachStateChangeListener(this);
            if (this.f1696f0) {
                j = 2500;
            } else {
                j = ((C2189w7.m15025t(this.f1688X) & 1) == 1 ? 3000 : 15000) - ((long) ViewConfiguration.getLongPressTimeout());
            }
            this.f1688X.removeCallbacks(this.f1692b0);
            this.f1688X.postDelayed(this.f1692b0, j);
        }
    }
}
