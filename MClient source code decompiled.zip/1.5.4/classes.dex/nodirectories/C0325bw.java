package p000;

import android.os.IInterface;
import java.util.List;

/* renamed from: bw */
public interface C0325bw extends IInterface {
    /* renamed from: F */
    String mo2671F();

    /* renamed from: J */
    C2232wr mo2672J();

    /* renamed from: T */
    C1274lv mo2673T();

    cy2 getVideoController();

    /* renamed from: t */
    String mo2675t();

    /* renamed from: u */
    String mo2676u();

    /* renamed from: v */
    String mo2677v();

    /* renamed from: w */
    C0724fv mo2678w();

    /* renamed from: x */
    List mo2679x();
}
