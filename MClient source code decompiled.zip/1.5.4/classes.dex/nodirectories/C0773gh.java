package p000;

import android.content.ContentValues;
import android.database.Cursor;
import java.util.ArrayList;
import java.util.List;

/* renamed from: gh */
public class C0773gh {

    /* renamed from: a */
    public final List<C0774a> f6116a = new ArrayList();

    /* renamed from: b */
    public final List<ContentValues> f6117b = new ArrayList();

    /* renamed from: gh$a */
    public static class C0774a {

        /* renamed from: a */
        public final int f6118a;

        /* renamed from: b */
        public final String f6119b;

        /* renamed from: c */
        public final int f6120c;

        public /* synthetic */ C0774a(int i, String str, int i2, C0612eh ehVar) {
            this.f6118a = i;
            this.f6119b = str;
            this.f6120c = i2;
        }
    }

    /* renamed from: a */
    public String mo6093a(int i) {
        if (i < 0 || i >= this.f6116a.size()) {
            return null;
        }
        return this.f6116a.get(i).f6119b;
    }

    public String toString() {
        String str;
        String str2;
        StringBuilder sb = new StringBuilder();
        int i = 0;
        while (true) {
            str = "\n";
            if (i >= this.f6116a.size()) {
                break;
            }
            sb.append(this.f6116a.get(i).f6119b);
            if (i != this.f6116a.size() - 1) {
                str = " | ";
            }
            sb.append(str);
            i++;
        }
        for (ContentValues next : this.f6117b) {
            for (int i2 = 0; i2 < this.f6116a.size(); i2++) {
                sb.append(next.getAsString(mo6093a(i2)));
                if (i2 == this.f6116a.size() - 1) {
                    str2 = str;
                } else {
                    str2 = " | ";
                }
                sb.append(str2);
            }
        }
        return sb.toString();
    }

    /* renamed from: a */
    public List<String> mo6094a(Character ch) {
        String str;
        String str2;
        ArrayList arrayList = new ArrayList();
        for (int i = 0; i < this.f6117b.size(); i++) {
            if (i < 0 || i >= this.f6117b.size()) {
                str = null;
            } else {
                ContentValues contentValues = this.f6117b.get(i);
                StringBuilder sb = new StringBuilder();
                int i2 = 0;
                while (i2 < this.f6116a.size()) {
                    if (((i2 < 0 || i2 >= this.f6116a.size()) ? -1 : this.f6116a.get(i2).f6120c) == 3) {
                        str2 = "\"";
                        sb.append(str2);
                        sb.append(contentValues.get(mo6093a(i2)));
                    } else {
                        str2 = contentValues.getAsString(mo6093a(i2));
                    }
                    sb.append(str2);
                    sb.append(i2 == this.f6116a.size() + -1 ? "" : ch);
                    i2++;
                }
                str = sb.toString();
            }
            arrayList.add(str);
        }
        return arrayList;
    }

    /* renamed from: a */
    public final void mo6095a(Cursor cursor) {
        ContentValues contentValues = new ContentValues();
        for (C0774a next : this.f6116a) {
            int i = next.f6120c;
            if (i == 1) {
                contentValues.put(next.f6119b, Long.valueOf(cursor.getLong(next.f6118a)));
            } else if (i == 2) {
                contentValues.put(next.f6119b, Double.valueOf(cursor.getDouble(next.f6118a)));
            } else if (i != 4) {
                contentValues.put(next.f6119b, cursor.getString(next.f6118a));
            } else {
                contentValues.put(next.f6119b, cursor.getBlob(next.f6118a));
            }
        }
        this.f6117b.add(contentValues);
    }
}
