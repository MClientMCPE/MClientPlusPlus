package p000;

import android.view.View;

/* renamed from: e0 */
public class C0566e0 implements Runnable {

    /* renamed from: X */
    public final /* synthetic */ C0011a0 f4185X;

    /* renamed from: e0$a */
    public class C0567a extends C0350c8 {
        public C0567a() {
        }

        /* renamed from: b */
        public void mo61b(View view) {
            C0566e0.this.f4185X.f44l0.setAlpha(1.0f);
            C0566e0.this.f4185X.f47o0.mo260a((C0286b8) null);
            C0566e0.this.f4185X.f47o0 = null;
        }

        /* renamed from: c */
        public void mo173c(View view) {
            C0566e0.this.f4185X.f44l0.setVisibility(0);
        }
    }

    public C0566e0(C0011a0 a0Var) {
        this.f4185X = a0Var;
    }

    public void run() {
        C0011a0 a0Var = this.f4185X;
        a0Var.f45m0.showAtLocation(a0Var.f44l0, 55, 0, 0);
        this.f4185X.mo40g();
        if (this.f4185X.mo49n()) {
            this.f4185X.f44l0.setAlpha(0.0f);
            C0011a0 a0Var2 = this.f4185X;
            C0052a8 a = C2189w7.m14976a(a0Var2.f44l0);
            a.mo258a(1.0f);
            a0Var2.f47o0 = a;
            this.f4185X.f47o0.mo260a((C0286b8) new C0567a());
            return;
        }
        this.f4185X.f44l0.setAlpha(1.0f);
        this.f4185X.f44l0.setVisibility(0);
    }
}
