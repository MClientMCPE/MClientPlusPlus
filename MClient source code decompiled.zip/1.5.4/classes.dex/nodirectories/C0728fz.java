package p000;

import android.os.IInterface;

/* renamed from: fz */
public interface C0728fz extends IInterface {
}
