package p000;

import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewOverlay;

/* renamed from: ge */
public class C0769ge implements C0858he {

    /* renamed from: a */
    public final ViewOverlay f6097a;

    public C0769ge(View view) {
        this.f6097a = view.getOverlay();
    }

    /* renamed from: a */
    public void mo2906a(Drawable drawable) {
        this.f6097a.add(drawable);
    }

    /* renamed from: b */
    public void mo2908b(Drawable drawable) {
        this.f6097a.remove(drawable);
    }
}
