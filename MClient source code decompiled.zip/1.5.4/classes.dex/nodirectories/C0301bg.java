package p000;

/* renamed from: bg */
public class C0301bg implements Runnable {

    /* renamed from: X */
    public final /* synthetic */ Runnable f1924X;

    /* renamed from: Y */
    public final /* synthetic */ C1335mg f1925Y;

    public C0301bg(C1335mg mgVar, Runnable runnable) {
        this.f1925Y = mgVar;
        this.f1924X = runnable;
    }

    public void run() {
        while (!this.f1925Y.f10223m0) {
            C1062ji.m7720a(this.f1924X);
            try {
                Thread.sleep(200);
            } catch (InterruptedException unused) {
            }
        }
    }
}
