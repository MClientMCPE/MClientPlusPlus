package p000;

import android.app.Activity;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.ActionMode;
import android.view.KeyEvent;
import android.view.KeyboardShortcutGroup;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatViewInflater;
import androidx.appcompat.widget.ActionBarContextView;
import androidx.appcompat.widget.ContentFrameLayout;
import java.lang.Thread;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import p000.C0816h1;
import p000.C0979j0;
import p000.C1581p1;
import p000.C1889t0;
import p000.C2249x0;

/* renamed from: a0 */
public class C0011a0 extends C2386z implements C0816h1.C0817a, LayoutInflater.Factory2 {

    /* renamed from: W0 */
    public static final Map<Class<?>, Integer> f5W0 = new C2399z4();

    /* renamed from: X0 */
    public static final boolean f6X0 = (Build.VERSION.SDK_INT < 21);

    /* renamed from: Y0 */
    public static final int[] f7Y0 = {16842836};

    /* renamed from: Z0 */
    public static boolean f8Z0 = true;

    /* renamed from: a1 */
    public static final boolean f9a1;

    /* renamed from: A0 */
    public boolean f10A0;

    /* renamed from: B0 */
    public boolean f11B0;

    /* renamed from: C0 */
    public C0023j[] f12C0;

    /* renamed from: D0 */
    public C0023j f13D0;

    /* renamed from: E0 */
    public boolean f14E0;

    /* renamed from: F0 */
    public boolean f15F0;

    /* renamed from: G0 */
    public boolean f16G0;

    /* renamed from: H0 */
    public boolean f17H0;

    /* renamed from: I0 */
    public boolean f18I0;

    /* renamed from: J0 */
    public int f19J0 = -100;

    /* renamed from: K0 */
    public int f20K0;

    /* renamed from: L0 */
    public boolean f21L0;

    /* renamed from: M0 */
    public boolean f22M0;

    /* renamed from: N0 */
    public C0019g f23N0;

    /* renamed from: O0 */
    public C0019g f24O0;

    /* renamed from: P0 */
    public boolean f25P0;

    /* renamed from: Q0 */
    public int f26Q0;

    /* renamed from: R0 */
    public final Runnable f27R0 = new C0013b();

    /* renamed from: S0 */
    public boolean f28S0;

    /* renamed from: T0 */
    public Rect f29T0;

    /* renamed from: U0 */
    public Rect f30U0;

    /* renamed from: V0 */
    public AppCompatViewInflater f31V0;

    /* renamed from: Z */
    public final Object f32Z;

    /* renamed from: a0 */
    public final Context f33a0;

    /* renamed from: b0 */
    public Window f34b0;

    /* renamed from: c0 */
    public C0017e f35c0;

    /* renamed from: d0 */
    public final C2314y f36d0;

    /* renamed from: e0 */
    public C1377n f37e0;

    /* renamed from: f0 */
    public MenuInflater f38f0;

    /* renamed from: g0 */
    public CharSequence f39g0;

    /* renamed from: h0 */
    public C2390z2 f40h0;

    /* renamed from: i0 */
    public C0014c f41i0;

    /* renamed from: j0 */
    public C0024k f42j0;

    /* renamed from: k0 */
    public C1889t0 f43k0;

    /* renamed from: l0 */
    public ActionBarContextView f44l0;

    /* renamed from: m0 */
    public PopupWindow f45m0;

    /* renamed from: n0 */
    public Runnable f46n0;

    /* renamed from: o0 */
    public C0052a8 f47o0 = null;

    /* renamed from: p0 */
    public boolean f48p0 = true;

    /* renamed from: q0 */
    public boolean f49q0;

    /* renamed from: r0 */
    public ViewGroup f50r0;

    /* renamed from: s0 */
    public TextView f51s0;

    /* renamed from: t0 */
    public View f52t0;

    /* renamed from: u0 */
    public boolean f53u0;

    /* renamed from: v0 */
    public boolean f54v0;

    /* renamed from: w0 */
    public boolean f55w0;

    /* renamed from: x0 */
    public boolean f56x0;

    /* renamed from: y0 */
    public boolean f57y0;

    /* renamed from: z0 */
    public boolean f58z0;

    /* renamed from: a0$a */
    public static class C0012a implements Thread.UncaughtExceptionHandler {

        /* renamed from: a */
        public final /* synthetic */ Thread.UncaughtExceptionHandler f59a;

        public C0012a(Thread.UncaughtExceptionHandler uncaughtExceptionHandler) {
            this.f59a = uncaughtExceptionHandler;
        }

        public void uncaughtException(Thread thread, Throwable th) {
            String message;
            boolean z = false;
            if ((th instanceof Resources.NotFoundException) && (message = th.getMessage()) != null && (message.contains("drawable") || message.contains("Drawable"))) {
                z = true;
            }
            if (z) {
                Resources.NotFoundException notFoundException = new Resources.NotFoundException(th.getMessage() + ". If the resource you are trying to use is a vector resource, you may be referencing it in an unsupported way. See AppCompatDelegate.setCompatVectorFromResourcesEnabled() for more info.");
                notFoundException.initCause(th.getCause());
                notFoundException.setStackTrace(th.getStackTrace());
                this.f59a.uncaughtException(thread, notFoundException);
                return;
            }
            this.f59a.uncaughtException(thread, th);
        }
    }

    /* renamed from: a0$b */
    public class C0013b implements Runnable {
        public C0013b() {
        }

        public void run() {
            C0011a0 a0Var = C0011a0.this;
            if ((a0Var.f26Q0 & 1) != 0) {
                a0Var.mo33c(0);
            }
            C0011a0 a0Var2 = C0011a0.this;
            if ((a0Var2.f26Q0 & 4096) != 0) {
                a0Var2.mo33c(108);
            }
            C0011a0 a0Var3 = C0011a0.this;
            a0Var3.f25P0 = false;
            a0Var3.f26Q0 = 0;
        }
    }

    /* renamed from: a0$c */
    public final class C0014c implements C1581p1.C1582a {
        public C0014c() {
        }

        /* renamed from: a */
        public void mo55a(C0816h1 h1Var, boolean z) {
            C0011a0.this.mo30b(h1Var);
        }

        /* renamed from: a */
        public boolean mo56a(C0816h1 h1Var) {
            Window.Callback l = C0011a0.this.mo47l();
            if (l == null) {
                return true;
            }
            l.onMenuOpened(108, h1Var);
            return true;
        }
    }

    /* renamed from: a0$d */
    public class C0015d implements C1889t0.C1890a {

        /* renamed from: a */
        public C1889t0.C1890a f62a;

        /* renamed from: a0$d$a */
        public class C0016a extends C0350c8 {
            public C0016a() {
            }

            /* renamed from: b */
            public void mo61b(View view) {
                C0011a0.this.f44l0.setVisibility(8);
                C0011a0 a0Var = C0011a0.this;
                PopupWindow popupWindow = a0Var.f45m0;
                if (popupWindow != null) {
                    popupWindow.dismiss();
                } else if (a0Var.f44l0.getParent() instanceof View) {
                    C2189w7.m14973E((View) C0011a0.this.f44l0.getParent());
                }
                C0011a0.this.f44l0.removeAllViews();
                C0011a0.this.f47o0.mo260a((C0286b8) null);
                C0011a0.this.f47o0 = null;
            }
        }

        public C0015d(C1889t0.C1890a aVar) {
            this.f62a = aVar;
        }

        /* renamed from: a */
        public void mo57a(C1889t0 t0Var) {
            this.f62a.mo57a(t0Var);
            C0011a0 a0Var = C0011a0.this;
            if (a0Var.f45m0 != null) {
                a0Var.f34b0.getDecorView().removeCallbacks(C0011a0.this.f46n0);
            }
            C0011a0 a0Var2 = C0011a0.this;
            if (a0Var2.f44l0 != null) {
                a0Var2.mo40g();
                C0011a0 a0Var3 = C0011a0.this;
                C0052a8 a = C2189w7.m14976a(a0Var3.f44l0);
                a.mo258a(0.0f);
                a0Var3.f47o0 = a;
                C0011a0.this.f47o0.mo260a((C0286b8) new C0016a());
            }
            C0011a0 a0Var4 = C0011a0.this;
            C2314y yVar = a0Var4.f36d0;
            if (yVar != null) {
                yVar.mo665b(a0Var4.f43k0);
            }
            C0011a0.this.f43k0 = null;
        }

        /* renamed from: a */
        public boolean mo58a(C1889t0 t0Var, Menu menu) {
            return this.f62a.mo58a(t0Var, menu);
        }

        /* renamed from: a */
        public boolean mo59a(C1889t0 t0Var, MenuItem menuItem) {
            return this.f62a.mo59a(t0Var, menuItem);
        }

        /* renamed from: b */
        public boolean mo60b(C1889t0 t0Var, Menu menu) {
            return this.f62a.mo60b(t0Var, menu);
        }
    }

    /* renamed from: a0$f */
    public class C0018f extends C0019g {

        /* renamed from: c */
        public final PowerManager f66c;

        public C0018f(Context context) {
            super();
            this.f66c = (PowerManager) context.getSystemService("power");
        }

        /* renamed from: b */
        public IntentFilter mo73b() {
            if (Build.VERSION.SDK_INT < 21) {
                return null;
            }
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("android.os.action.POWER_SAVE_MODE_CHANGED");
            return intentFilter;
        }

        /* renamed from: c */
        public int mo74c() {
            return (Build.VERSION.SDK_INT < 21 || !this.f66c.isPowerSaveMode()) ? 1 : 2;
        }

        /* renamed from: d */
        public void mo75d() {
            C0011a0.this.mo39f();
        }
    }

    /* renamed from: a0$g */
    public abstract class C0019g {

        /* renamed from: a */
        public BroadcastReceiver f68a;

        /* renamed from: a0$g$a */
        public class C0020a extends BroadcastReceiver {
            public C0020a() {
            }

            public void onReceive(Context context, Intent intent) {
                C0019g.this.mo75d();
            }
        }

        public C0019g() {
        }

        /* renamed from: a */
        public void mo76a() {
            BroadcastReceiver broadcastReceiver = this.f68a;
            if (broadcastReceiver != null) {
                try {
                    C0011a0.this.f33a0.unregisterReceiver(broadcastReceiver);
                } catch (IllegalArgumentException unused) {
                }
                this.f68a = null;
            }
        }

        /* renamed from: b */
        public abstract IntentFilter mo73b();

        /* renamed from: c */
        public abstract int mo74c();

        /* renamed from: d */
        public abstract void mo75d();

        /* renamed from: e */
        public void mo77e() {
            mo76a();
            IntentFilter b = mo73b();
            if (b != null && b.countActions() != 0) {
                if (this.f68a == null) {
                    this.f68a = new C0020a();
                }
                C0011a0.this.f33a0.registerReceiver(this.f68a, b);
            }
        }
    }

    /* renamed from: a0$h */
    public class C0021h extends C0019g {

        /* renamed from: c */
        public final C0979j0 f71c;

        public C0021h(C0979j0 j0Var) {
            super();
            this.f71c = j0Var;
        }

        /* renamed from: b */
        public IntentFilter mo73b() {
            IntentFilter intentFilter = new IntentFilter();
            intentFilter.addAction("android.intent.action.TIME_SET");
            intentFilter.addAction("android.intent.action.TIMEZONE_CHANGED");
            intentFilter.addAction("android.intent.action.TIME_TICK");
            return intentFilter;
        }

        /* renamed from: c */
        public int mo74c() {
            boolean z;
            long j;
            C0979j0 j0Var = this.f71c;
            C0979j0.C0980a aVar = j0Var.f8030c;
            boolean z2 = false;
            if (aVar.f8036f > System.currentTimeMillis()) {
                z = aVar.f8031a;
            } else {
                Location location = null;
                Location a = C0815h0.m5772a(j0Var.f8028a, "android.permission.ACCESS_COARSE_LOCATION") == 0 ? j0Var.mo7332a("network") : null;
                if (C0815h0.m5772a(j0Var.f8028a, "android.permission.ACCESS_FINE_LOCATION") == 0) {
                    location = j0Var.mo7332a("gps");
                }
                if (location == null || a == null ? location != null : location.getTime() > a.getTime()) {
                    a = location;
                }
                if (a != null) {
                    C0979j0.C0980a aVar2 = j0Var.f8030c;
                    long currentTimeMillis = System.currentTimeMillis();
                    if (C0888i0.f7037d == null) {
                        C0888i0.f7037d = new C0888i0();
                    }
                    C0888i0 i0Var = C0888i0.f7037d;
                    C0888i0 i0Var2 = i0Var;
                    i0Var2.mo6749a(currentTimeMillis - 86400000, a.getLatitude(), a.getLongitude());
                    long j2 = i0Var.f7038a;
                    i0Var2.mo6749a(currentTimeMillis, a.getLatitude(), a.getLongitude());
                    if (i0Var.f7040c == 1) {
                        z2 = true;
                    }
                    long j3 = i0Var.f7039b;
                    long j4 = i0Var.f7038a;
                    C0979j0.C0980a aVar3 = aVar;
                    long j5 = j3;
                    i0Var.mo6749a(currentTimeMillis + 86400000, a.getLatitude(), a.getLongitude());
                    long j6 = i0Var.f7039b;
                    long j7 = j4;
                    if (j5 == -1 || j7 == -1) {
                        j = 43200000;
                    } else {
                        currentTimeMillis = currentTimeMillis > j7 ? j6 + 0 : currentTimeMillis > j5 ? j7 + 0 : j5 + 0;
                        j = 60000;
                    }
                    aVar2.f8031a = z2;
                    aVar2.f8032b = j2;
                    aVar2.f8033c = j5;
                    aVar2.f8034d = j7;
                    aVar2.f8035e = j6;
                    aVar2.f8036f = currentTimeMillis + j;
                    z = aVar3.f8031a;
                } else {
                    Log.i("TwilightManager", "Could not get last known location. This is probably because the app does not have any location permissions. Falling back to hardcoded sunrise/sunset values.");
                    int i = Calendar.getInstance().get(11);
                    z = i < 6 || i >= 22;
                }
            }
            return z ? 2 : 1;
        }

        /* renamed from: d */
        public void mo75d() {
            C0011a0.this.mo39f();
        }
    }

    /* renamed from: a0$i */
    public class C0022i extends ContentFrameLayout {
        public C0022i(Context context) {
            super(context);
        }

        public boolean dispatchKeyEvent(KeyEvent keyEvent) {
            return C0011a0.this.mo23a(keyEvent) || super.dispatchKeyEvent(keyEvent);
        }

        public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
            if (motionEvent.getAction() == 0) {
                int x = (int) motionEvent.getX();
                int y = (int) motionEvent.getY();
                if (x < -5 || y < -5 || x > getWidth() + 5 || y > getHeight() + 5) {
                    C0011a0 a0Var = C0011a0.this;
                    a0Var.mo13a(a0Var.mo34d(0), true);
                    return true;
                }
            }
            return super.onInterceptTouchEvent(motionEvent);
        }

        public void setBackgroundResource(int i) {
            setBackgroundDrawable(C1206l0.m8461c(getContext(), i));
        }
    }

    /* renamed from: a0$j */
    public static final class C0023j {

        /* renamed from: a */
        public int f74a;

        /* renamed from: b */
        public int f75b;

        /* renamed from: c */
        public int f76c;

        /* renamed from: d */
        public int f77d;

        /* renamed from: e */
        public int f78e;

        /* renamed from: f */
        public int f79f;

        /* renamed from: g */
        public ViewGroup f80g;

        /* renamed from: h */
        public View f81h;

        /* renamed from: i */
        public View f82i;

        /* renamed from: j */
        public C0816h1 f83j;

        /* renamed from: k */
        public C0635f1 f84k;

        /* renamed from: l */
        public Context f85l;

        /* renamed from: m */
        public boolean f86m;

        /* renamed from: n */
        public boolean f87n;

        /* renamed from: o */
        public boolean f88o;

        /* renamed from: p */
        public boolean f89p;

        /* renamed from: q */
        public boolean f90q = false;

        /* renamed from: r */
        public boolean f91r;

        /* renamed from: s */
        public Bundle f92s;

        public C0023j(int i) {
            this.f74a = i;
        }

        /* renamed from: a */
        public void mo82a(Context context) {
            TypedValue typedValue = new TypedValue();
            Resources.Theme newTheme = context.getResources().newTheme();
            newTheme.setTo(context.getTheme());
            newTheme.resolveAttribute(C0502d.actionBarPopupTheme, typedValue, true);
            int i = typedValue.resourceId;
            if (i != 0) {
                newTheme.applyStyle(i, true);
            }
            newTheme.resolveAttribute(C0502d.panelMenuListTheme, typedValue, true);
            int i2 = typedValue.resourceId;
            if (i2 == 0) {
                i2 = C1205l.Theme_AppCompat_CompactMenu;
            }
            newTheme.applyStyle(i2, true);
            C2080v0 v0Var = new C2080v0(context, 0);
            v0Var.getTheme().setTo(newTheme);
            this.f85l = v0Var;
            TypedArray obtainStyledAttributes = v0Var.obtainStyledAttributes(C1292m.AppCompatTheme);
            this.f75b = obtainStyledAttributes.getResourceId(C1292m.AppCompatTheme_panelBackground, 0);
            this.f79f = obtainStyledAttributes.getResourceId(C1292m.AppCompatTheme_android_windowAnimationStyle, 0);
            obtainStyledAttributes.recycle();
        }

        /* renamed from: a */
        public void mo83a(C0816h1 h1Var) {
            C0635f1 f1Var;
            C0816h1 h1Var2 = this.f83j;
            if (h1Var != h1Var2) {
                if (h1Var2 != null) {
                    h1Var2.mo6286a((C1581p1) this.f84k);
                }
                this.f83j = h1Var;
                if (h1Var != null && (f1Var = this.f84k) != null) {
                    h1Var.mo6287a((C1581p1) f1Var, h1Var.f6494a);
                }
            }
        }
    }

    /* renamed from: a0$k */
    public final class C0024k implements C1581p1.C1582a {
        public C0024k() {
        }

        /* renamed from: a */
        public void mo55a(C0816h1 h1Var, boolean z) {
            C0816h1 c = h1Var.mo6306c();
            boolean z2 = c != h1Var;
            C0011a0 a0Var = C0011a0.this;
            if (z2) {
                h1Var = c;
            }
            C0023j a = a0Var.mo8a((Menu) h1Var);
            if (a == null) {
                return;
            }
            if (z2) {
                C0011a0.this.mo11a(a.f74a, a, c);
                C0011a0.this.mo13a(a, true);
                return;
            }
            C0011a0.this.mo13a(a, z);
        }

        /* renamed from: a */
        public boolean mo56a(C0816h1 h1Var) {
            Window.Callback l;
            if (h1Var != null) {
                return true;
            }
            C0011a0 a0Var = C0011a0.this;
            if (!a0Var.f55w0 || (l = a0Var.mo47l()) == null || C0011a0.this.f18I0) {
                return true;
            }
            l.onMenuOpened(108, h1Var);
            return true;
        }
    }

    static {
        boolean z = false;
        int i = Build.VERSION.SDK_INT;
        if (i >= 21 && i <= 25) {
            z = true;
        }
        f9a1 = z;
        if (f6X0 && !f8Z0) {
            Thread.setDefaultUncaughtExceptionHandler(new C0012a(Thread.getDefaultUncaughtExceptionHandler()));
        }
    }

    public C0011a0(Context context, Window window, C2314y yVar, Object obj) {
        Integer num;
        AppCompatActivity appCompatActivity = null;
        this.f33a0 = context;
        this.f36d0 = yVar;
        this.f32Z = obj;
        if (this.f19J0 == -100 && (this.f32Z instanceof Dialog)) {
            Context context2 = this.f33a0;
            while (true) {
                if (context2 != null) {
                    if (!(context2 instanceof AppCompatActivity)) {
                        if (!(context2 instanceof ContextWrapper)) {
                            break;
                        }
                        context2 = ((ContextWrapper) context2).getBaseContext();
                    } else {
                        appCompatActivity = (AppCompatActivity) context2;
                        break;
                    }
                } else {
                    break;
                }
            }
            if (appCompatActivity != null) {
                this.f19J0 = ((C0011a0) appCompatActivity.mo676l()).f19J0;
            }
        }
        if (this.f19J0 == -100 && (num = f5W0.get(this.f32Z.getClass())) != null) {
            this.f19J0 = num.intValue();
            f5W0.remove(this.f32Z.getClass());
        }
        if (window != null) {
            mo18a(window);
        }
        C0820h2.m5931b();
    }

    /* renamed from: a */
    public C0023j mo8a(Menu menu) {
        C0023j[] jVarArr = this.f12C0;
        int length = jVarArr != null ? jVarArr.length : 0;
        for (int i = 0; i < length; i++) {
            C0023j jVar = jVarArr[i];
            if (jVar != null && jVar.f83j == menu) {
                return jVar;
            }
        }
        return null;
    }

    /* renamed from: a */
    public MenuInflater mo9a() {
        if (this.f38f0 == null) {
            mo48m();
            C1377n nVar = this.f37e0;
            this.f38f0 = new C2315y0(nVar != null ? nVar.mo7748c() : this.f33a0);
        }
        return this.f38f0;
    }

    /* renamed from: a */
    public void mo13a(C0023j jVar, boolean z) {
        ViewGroup viewGroup;
        C2390z2 z2Var;
        if (!z || jVar.f74a != 0 || (z2Var = this.f40h0) == null || !z2Var.mo806a()) {
            WindowManager windowManager = (WindowManager) this.f33a0.getSystemService("window");
            if (!(windowManager == null || !jVar.f88o || (viewGroup = jVar.f80g) == null)) {
                windowManager.removeView(viewGroup);
                if (z) {
                    mo11a(jVar.f74a, jVar, (Menu) null);
                }
            }
            jVar.f86m = false;
            jVar.f87n = false;
            jVar.f88o = false;
            jVar.f81h = null;
            jVar.f90q = true;
            if (this.f13D0 == jVar) {
                this.f13D0 = null;
                return;
            }
            return;
        }
        mo30b(jVar.f83j);
    }

    /* renamed from: a */
    public void mo17a(View view, ViewGroup.LayoutParams layoutParams) {
        mo43h();
        ((ViewGroup) this.f50r0.findViewById(16908290)).addView(view, layoutParams);
        this.f35c0.f96X.onContentChanged();
    }

    /* renamed from: a */
    public final boolean mo22a(C0023j jVar, int i, KeyEvent keyEvent, int i2) {
        C0816h1 h1Var;
        boolean z = false;
        if (keyEvent.isSystem()) {
            return false;
        }
        if ((jVar.f86m || mo31b(jVar, keyEvent)) && (h1Var = jVar.f83j) != null) {
            z = h1Var.performShortcut(i, keyEvent, i2);
        }
        if (z && (i2 & 1) == 0 && this.f40h0 == null) {
            mo13a(jVar, true);
        }
        return z;
    }

    /* renamed from: a */
    public boolean mo24a(C0816h1 h1Var, MenuItem menuItem) {
        C0023j a;
        Window.Callback l = mo47l();
        if (l == null || this.f18I0 || (a = mo8a((Menu) h1Var.mo6306c())) == null) {
            return false;
        }
        return l.onMenuItemSelected(a.f74a, menuItem);
    }

    /* renamed from: b */
    public void mo26b() {
        LayoutInflater from = LayoutInflater.from(this.f33a0);
        if (from.getFactory() == null) {
            C0815h0.m5846b(from, (LayoutInflater.Factory2) this);
        } else if (!(from.getFactory2() instanceof C0011a0)) {
            Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's");
        }
    }

    /* renamed from: b */
    public void mo28b(Bundle bundle) {
        if (this.f19J0 != -100) {
            f5W0.put(this.f32Z.getClass(), Integer.valueOf(this.f19J0));
        }
    }

    /* renamed from: b */
    public void mo30b(C0816h1 h1Var) {
        if (!this.f11B0) {
            this.f11B0 = true;
            this.f40h0.mo809b();
            Window.Callback l = mo47l();
            if (l != null && !this.f18I0) {
                l.onPanelClosed(108, h1Var);
            }
            this.f11B0 = false;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:49:0x00b8 A[RETURN] */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean mo31b(p000.C0011a0.C0023j r11, android.view.KeyEvent r12) {
        /*
            r10 = this;
            boolean r0 = r10.f18I0
            r1 = 0
            if (r0 == 0) goto L_0x0006
            return r1
        L_0x0006:
            boolean r0 = r11.f86m
            r2 = 1
            if (r0 == 0) goto L_0x000c
            return r2
        L_0x000c:
            a0$j r0 = r10.f13D0
            if (r0 == 0) goto L_0x0015
            if (r0 == r11) goto L_0x0015
            r10.mo13a((p000.C0011a0.C0023j) r0, (boolean) r1)
        L_0x0015:
            android.view.Window$Callback r0 = r10.mo47l()
            if (r0 == 0) goto L_0x0023
            int r3 = r11.f74a
            android.view.View r3 = r0.onCreatePanelView(r3)
            r11.f82i = r3
        L_0x0023:
            int r3 = r11.f74a
            r4 = 108(0x6c, float:1.51E-43)
            if (r3 == 0) goto L_0x002e
            if (r3 != r4) goto L_0x002c
            goto L_0x002e
        L_0x002c:
            r3 = 0
            goto L_0x002f
        L_0x002e:
            r3 = 1
        L_0x002f:
            if (r3 == 0) goto L_0x0038
            z2 r5 = r10.f40h0
            if (r5 == 0) goto L_0x0038
            r5.mo811c()
        L_0x0038:
            android.view.View r5 = r11.f82i
            if (r5 != 0) goto L_0x0141
            h1 r5 = r11.f83j
            r6 = 0
            if (r5 == 0) goto L_0x0045
            boolean r5 = r11.f91r
            if (r5 == 0) goto L_0x00f3
        L_0x0045:
            h1 r5 = r11.f83j
            if (r5 != 0) goto L_0x00b9
            android.content.Context r5 = r10.f33a0
            int r7 = r11.f74a
            if (r7 == 0) goto L_0x0051
            if (r7 != r4) goto L_0x00a8
        L_0x0051:
            z2 r4 = r10.f40h0
            if (r4 == 0) goto L_0x00a8
            android.util.TypedValue r4 = new android.util.TypedValue
            r4.<init>()
            android.content.res.Resources$Theme r7 = r5.getTheme()
            int r8 = p000.C0502d.actionBarTheme
            r7.resolveAttribute(r8, r4, r2)
            int r8 = r4.resourceId
            if (r8 == 0) goto L_0x007d
            android.content.res.Resources r8 = r5.getResources()
            android.content.res.Resources$Theme r8 = r8.newTheme()
            r8.setTo(r7)
            int r9 = r4.resourceId
            r8.applyStyle(r9, r2)
            int r9 = p000.C0502d.actionBarWidgetTheme
            r8.resolveAttribute(r9, r4, r2)
            goto L_0x0083
        L_0x007d:
            int r8 = p000.C0502d.actionBarWidgetTheme
            r7.resolveAttribute(r8, r4, r2)
            r8 = r6
        L_0x0083:
            int r9 = r4.resourceId
            if (r9 == 0) goto L_0x0099
            if (r8 != 0) goto L_0x0094
            android.content.res.Resources r8 = r5.getResources()
            android.content.res.Resources$Theme r8 = r8.newTheme()
            r8.setTo(r7)
        L_0x0094:
            int r4 = r4.resourceId
            r8.applyStyle(r4, r2)
        L_0x0099:
            if (r8 == 0) goto L_0x00a8
            v0 r4 = new v0
            r4.<init>(r5, r1)
            android.content.res.Resources$Theme r5 = r4.getTheme()
            r5.setTo(r8)
            goto L_0x00a9
        L_0x00a8:
            r4 = r5
        L_0x00a9:
            h1 r5 = new h1
            r5.<init>(r4)
            r5.mo6284a((p000.C0816h1.C0817a) r10)
            r11.mo83a((p000.C0816h1) r5)
            h1 r4 = r11.f83j
            if (r4 != 0) goto L_0x00b9
            return r1
        L_0x00b9:
            if (r3 == 0) goto L_0x00d3
            z2 r4 = r10.f40h0
            if (r4 == 0) goto L_0x00d3
            a0$c r4 = r10.f41i0
            if (r4 != 0) goto L_0x00ca
            a0$c r4 = new a0$c
            r4.<init>()
            r10.f41i0 = r4
        L_0x00ca:
            z2 r4 = r10.f40h0
            h1 r5 = r11.f83j
            a0$c r7 = r10.f41i0
            r4.mo800a(r5, r7)
        L_0x00d3:
            h1 r4 = r11.f83j
            r4.mo6321k()
            int r4 = r11.f74a
            h1 r5 = r11.f83j
            boolean r4 = r0.onCreatePanelMenu(r4, r5)
            if (r4 != 0) goto L_0x00f1
            r11.mo83a((p000.C0816h1) r6)
            if (r3 == 0) goto L_0x00f0
            z2 r11 = r10.f40h0
            if (r11 == 0) goto L_0x00f0
            a0$c r12 = r10.f41i0
            r11.mo800a(r6, r12)
        L_0x00f0:
            return r1
        L_0x00f1:
            r11.f91r = r1
        L_0x00f3:
            h1 r4 = r11.f83j
            r4.mo6321k()
            android.os.Bundle r4 = r11.f92s
            if (r4 == 0) goto L_0x0103
            h1 r5 = r11.f83j
            r5.mo6282a((android.os.Bundle) r4)
            r11.f92s = r6
        L_0x0103:
            android.view.View r4 = r11.f82i
            h1 r5 = r11.f83j
            boolean r0 = r0.onPreparePanel(r1, r4, r5)
            if (r0 != 0) goto L_0x011e
            if (r3 == 0) goto L_0x0118
            z2 r12 = r10.f40h0
            if (r12 == 0) goto L_0x0118
            a0$c r0 = r10.f41i0
            r12.mo800a(r6, r0)
        L_0x0118:
            h1 r11 = r11.f83j
            r11.mo6320j()
            return r1
        L_0x011e:
            if (r12 == 0) goto L_0x0125
            int r12 = r12.getDeviceId()
            goto L_0x0126
        L_0x0125:
            r12 = -1
        L_0x0126:
            android.view.KeyCharacterMap r12 = android.view.KeyCharacterMap.load(r12)
            int r12 = r12.getKeyboardType()
            if (r12 == r2) goto L_0x0132
            r12 = 1
            goto L_0x0133
        L_0x0132:
            r12 = 0
        L_0x0133:
            r11.f89p = r12
            h1 r12 = r11.f83j
            boolean r0 = r11.f89p
            r12.setQwertyMode(r0)
            h1 r12 = r11.f83j
            r12.mo6320j()
        L_0x0141:
            r11.f86m = r2
            r11.f87n = r1
            r10.f13D0 = r11
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0011a0.mo31b(a0$j, android.view.KeyEvent):boolean");
    }

    /* renamed from: c */
    public void mo32c() {
        mo48m();
        C1377n nVar = this.f37e0;
        mo37e(0);
    }

    /* renamed from: c */
    public void mo33c(int i) {
        C0023j d;
        C0023j d2 = mo34d(i);
        if (d2.f83j != null) {
            Bundle bundle = new Bundle();
            d2.f83j.mo6303b(bundle);
            if (bundle.size() > 0) {
                d2.f92s = bundle;
            }
            d2.f83j.mo6321k();
            d2.f83j.clear();
        }
        d2.f91r = true;
        d2.f90q = true;
        if ((i == 108 || i == 0) && this.f40h0 != null && (d = mo34d(0)) != null) {
            d.f86m = false;
            mo31b(d, (KeyEvent) null);
        }
    }

    /* renamed from: d */
    public C0023j mo34d(int i) {
        C0023j[] jVarArr = this.f12C0;
        if (jVarArr == null || jVarArr.length <= i) {
            C0023j[] jVarArr2 = new C0023j[(i + 1)];
            if (jVarArr != null) {
                System.arraycopy(jVarArr, 0, jVarArr2, 0, jVarArr.length);
            }
            this.f12C0 = jVarArr2;
            jVarArr = jVarArr2;
        }
        C0023j jVar = jVarArr[i];
        if (jVar != null) {
            return jVar;
        }
        C0023j jVar2 = new C0023j(i);
        jVarArr[i] = jVar2;
        return jVar2;
    }

    /* renamed from: d */
    public void mo35d() {
        C2386z.m16743b((C2386z) this);
        if (this.f25P0) {
            this.f34b0.getDecorView().removeCallbacks(this.f27R0);
        }
        this.f17H0 = false;
        this.f18I0 = true;
        C1377n nVar = this.f37e0;
        C0019g gVar = this.f23N0;
        if (gVar != null) {
            gVar.mo76a();
        }
        C0019g gVar2 = this.f24O0;
        if (gVar2 != null) {
            gVar2.mo76a();
        }
    }

    /* renamed from: e */
    public void mo36e() {
        this.f17H0 = false;
        C2386z.m16743b((C2386z) this);
        mo48m();
        C1377n nVar = this.f37e0;
        if (nVar != null) {
            nVar.mo7749c(false);
        }
        if (this.f32Z instanceof Dialog) {
            C0019g gVar = this.f23N0;
            if (gVar != null) {
                gVar.mo76a();
            }
            C0019g gVar2 = this.f24O0;
            if (gVar2 != null) {
                gVar2.mo76a();
            }
        }
    }

    /* renamed from: e */
    public final void mo37e(int i) {
        this.f26Q0 = (1 << i) | this.f26Q0;
        if (!this.f25P0) {
            C2189w7.m14991a(this.f34b0.getDecorView(), this.f27R0);
            this.f25P0 = true;
        }
    }

    /* renamed from: f */
    public void mo38f(int i) {
        if (i == 108) {
            mo48m();
            C1377n nVar = this.f37e0;
            if (nVar != null) {
                nVar.mo7742a(true);
            }
        }
    }

    /* renamed from: f */
    public boolean mo39f() {
        return mo25a(true);
    }

    /* renamed from: g */
    public void mo40g() {
        C0052a8 a8Var = this.f47o0;
        if (a8Var != null) {
            a8Var.mo262a();
        }
    }

    /* renamed from: g */
    public void mo41g(int i) {
        if (i == 108) {
            mo48m();
            C1377n nVar = this.f37e0;
            if (nVar != null) {
                nVar.mo7742a(false);
            }
        } else if (i == 0) {
            C0023j d = mo34d(i);
            if (d.f88o) {
                mo13a(d, false);
            }
        }
    }

    /* renamed from: h */
    public int mo42h(int i) {
        boolean z;
        boolean z2;
        boolean z3;
        ActionBarContextView actionBarContextView = this.f44l0;
        int i2 = 0;
        if (actionBarContextView == null || !(actionBarContextView.getLayoutParams() instanceof ViewGroup.MarginLayoutParams)) {
            z = false;
        } else {
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) this.f44l0.getLayoutParams();
            z = true;
            if (this.f44l0.isShown()) {
                if (this.f29T0 == null) {
                    this.f29T0 = new Rect();
                    this.f30U0 = new Rect();
                }
                Rect rect = this.f29T0;
                Rect rect2 = this.f30U0;
                rect.set(0, i, 0, 0);
                C0580e4.m3914a(this.f50r0, rect, rect2);
                if (marginLayoutParams.topMargin != (rect2.top == 0 ? i : 0)) {
                    marginLayoutParams.topMargin = i;
                    View view = this.f52t0;
                    if (view == null) {
                        this.f52t0 = new View(this.f33a0);
                        this.f52t0.setBackgroundColor(this.f33a0.getResources().getColor(C0633f.abc_input_method_navigation_guard));
                        this.f50r0.addView(this.f52t0, -1, new ViewGroup.LayoutParams(-1, i));
                    } else {
                        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
                        if (layoutParams.height != i) {
                            layoutParams.height = i;
                            this.f52t0.setLayoutParams(layoutParams);
                        }
                    }
                    z2 = true;
                } else {
                    z2 = false;
                }
                if (this.f52t0 == null) {
                    z = false;
                }
                if (!this.f57y0 && z) {
                    i = 0;
                }
            } else {
                if (marginLayoutParams.topMargin != 0) {
                    marginLayoutParams.topMargin = 0;
                    z3 = true;
                } else {
                    z3 = false;
                }
                z = false;
            }
            if (z2) {
                this.f44l0.setLayoutParams(marginLayoutParams);
            }
        }
        View view2 = this.f52t0;
        if (view2 != null) {
            if (!z) {
                i2 = 8;
            }
            view2.setVisibility(i2);
        }
        return i;
    }

    /* renamed from: h */
    public final void mo43h() {
        ViewGroup viewGroup;
        if (!this.f49q0) {
            TypedArray obtainStyledAttributes = this.f33a0.obtainStyledAttributes(C1292m.AppCompatTheme);
            if (obtainStyledAttributes.hasValue(C1292m.AppCompatTheme_windowActionBar)) {
                if (obtainStyledAttributes.getBoolean(C1292m.AppCompatTheme_windowNoTitle, false)) {
                    mo21a(1);
                } else if (obtainStyledAttributes.getBoolean(C1292m.AppCompatTheme_windowActionBar, false)) {
                    mo21a(108);
                }
                if (obtainStyledAttributes.getBoolean(C1292m.AppCompatTheme_windowActionBarOverlay, false)) {
                    mo21a(109);
                }
                if (obtainStyledAttributes.getBoolean(C1292m.AppCompatTheme_windowActionModeOverlay, false)) {
                    mo21a(10);
                }
                this.f58z0 = obtainStyledAttributes.getBoolean(C1292m.AppCompatTheme_android_windowIsFloating, false);
                obtainStyledAttributes.recycle();
                mo44i();
                this.f34b0.getDecorView();
                LayoutInflater from = LayoutInflater.from(this.f33a0);
                if (this.f10A0) {
                    viewGroup = (ViewGroup) from.inflate(this.f57y0 ? C0978j.abc_screen_simple_overlay_action_mode : C0978j.abc_screen_simple, (ViewGroup) null);
                    if (Build.VERSION.SDK_INT >= 21) {
                        C2189w7.m14994a((View) viewGroup, (C1746r7) new C0276b0(this));
                    } else {
                        ((C0508d3) viewGroup).setOnFitSystemWindowsListener(new C0332c0(this));
                    }
                } else if (this.f58z0) {
                    viewGroup = (ViewGroup) from.inflate(C0978j.abc_dialog_title_material, (ViewGroup) null);
                    this.f56x0 = false;
                    this.f55w0 = false;
                } else if (this.f55w0) {
                    TypedValue typedValue = new TypedValue();
                    this.f33a0.getTheme().resolveAttribute(C0502d.actionBarTheme, typedValue, true);
                    int i = typedValue.resourceId;
                    viewGroup = (ViewGroup) LayoutInflater.from(i != 0 ? new C2080v0(this.f33a0, i) : this.f33a0).inflate(C0978j.abc_screen_toolbar, (ViewGroup) null);
                    this.f40h0 = (C2390z2) viewGroup.findViewById(C0887i.decor_content_parent);
                    this.f40h0.setWindowCallback(mo47l());
                    if (this.f56x0) {
                        this.f40h0.mo798a(109);
                    }
                    if (this.f53u0) {
                        this.f40h0.mo798a(2);
                    }
                    if (this.f54v0) {
                        this.f40h0.mo798a(5);
                    }
                } else {
                    viewGroup = null;
                }
                if (viewGroup != null) {
                    if (this.f40h0 == null) {
                        this.f51s0 = (TextView) viewGroup.findViewById(C0887i.title);
                    }
                    C0580e4.m3916b(viewGroup);
                    ContentFrameLayout contentFrameLayout = (ContentFrameLayout) viewGroup.findViewById(C0887i.action_bar_activity_content);
                    ViewGroup viewGroup2 = (ViewGroup) this.f34b0.findViewById(16908290);
                    if (viewGroup2 != null) {
                        while (viewGroup2.getChildCount() > 0) {
                            View childAt = viewGroup2.getChildAt(0);
                            viewGroup2.removeViewAt(0);
                            contentFrameLayout.addView(childAt);
                        }
                        viewGroup2.setId(-1);
                        contentFrameLayout.setId(16908290);
                        if (viewGroup2 instanceof FrameLayout) {
                            ((FrameLayout) viewGroup2).setForeground((Drawable) null);
                        }
                    }
                    this.f34b0.setContentView(viewGroup);
                    contentFrameLayout.setAttachListener(new C0503d0(this));
                    this.f50r0 = viewGroup;
                    Object obj = this.f32Z;
                    CharSequence title = obj instanceof Activity ? ((Activity) obj).getTitle() : this.f39g0;
                    if (!TextUtils.isEmpty(title)) {
                        C2390z2 z2Var = this.f40h0;
                        if (z2Var != null) {
                            z2Var.setWindowTitle(title);
                        } else {
                            C1377n nVar = this.f37e0;
                            if (nVar != null) {
                                nVar.mo7741a(title);
                            } else {
                                TextView textView = this.f51s0;
                                if (textView != null) {
                                    textView.setText(title);
                                }
                            }
                        }
                    }
                    ContentFrameLayout contentFrameLayout2 = (ContentFrameLayout) this.f50r0.findViewById(16908290);
                    View decorView = this.f34b0.getDecorView();
                    contentFrameLayout2.mo936a(decorView.getPaddingLeft(), decorView.getPaddingTop(), decorView.getPaddingRight(), decorView.getPaddingBottom());
                    TypedArray obtainStyledAttributes2 = this.f33a0.obtainStyledAttributes(C1292m.AppCompatTheme);
                    obtainStyledAttributes2.getValue(C1292m.AppCompatTheme_windowMinWidthMajor, contentFrameLayout2.getMinWidthMajor());
                    obtainStyledAttributes2.getValue(C1292m.AppCompatTheme_windowMinWidthMinor, contentFrameLayout2.getMinWidthMinor());
                    if (obtainStyledAttributes2.hasValue(C1292m.AppCompatTheme_windowFixedWidthMajor)) {
                        obtainStyledAttributes2.getValue(C1292m.AppCompatTheme_windowFixedWidthMajor, contentFrameLayout2.getFixedWidthMajor());
                    }
                    if (obtainStyledAttributes2.hasValue(C1292m.AppCompatTheme_windowFixedWidthMinor)) {
                        obtainStyledAttributes2.getValue(C1292m.AppCompatTheme_windowFixedWidthMinor, contentFrameLayout2.getFixedWidthMinor());
                    }
                    if (obtainStyledAttributes2.hasValue(C1292m.AppCompatTheme_windowFixedHeightMajor)) {
                        obtainStyledAttributes2.getValue(C1292m.AppCompatTheme_windowFixedHeightMajor, contentFrameLayout2.getFixedHeightMajor());
                    }
                    if (obtainStyledAttributes2.hasValue(C1292m.AppCompatTheme_windowFixedHeightMinor)) {
                        obtainStyledAttributes2.getValue(C1292m.AppCompatTheme_windowFixedHeightMinor, contentFrameLayout2.getFixedHeightMinor());
                    }
                    obtainStyledAttributes2.recycle();
                    contentFrameLayout2.requestLayout();
                    this.f49q0 = true;
                    C0023j d = mo34d(0);
                    if (this.f18I0) {
                        return;
                    }
                    if (d == null || d.f83j == null) {
                        mo37e(108);
                        return;
                    }
                    return;
                }
                StringBuilder a = C0789gk.m5562a("AppCompat does not support the current theme features: { windowActionBar: ");
                a.append(this.f55w0);
                a.append(", windowActionBarOverlay: ");
                a.append(this.f56x0);
                a.append(", android:windowIsFloating: ");
                a.append(this.f58z0);
                a.append(", windowActionModeOverlay: ");
                a.append(this.f57y0);
                a.append(", windowNoTitle: ");
                a.append(this.f10A0);
                a.append(" }");
                throw new IllegalArgumentException(a.toString());
            }
            obtainStyledAttributes.recycle();
            throw new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
        }
    }

    /* renamed from: i */
    public final void mo44i() {
        if (this.f34b0 == null) {
            Object obj = this.f32Z;
            if (obj instanceof Activity) {
                mo18a(((Activity) obj).getWindow());
            }
        }
        if (this.f34b0 == null) {
            throw new IllegalStateException("We have not been given a Window");
        }
    }

    /* renamed from: j */
    public final Context mo45j() {
        mo48m();
        C1377n nVar = this.f37e0;
        Context c = nVar != null ? nVar.mo7748c() : null;
        return c == null ? this.f33a0 : c;
    }

    /* renamed from: k */
    public final C0019g mo46k() {
        if (this.f23N0 == null) {
            Context context = this.f33a0;
            if (C0979j0.f8027d == null) {
                Context applicationContext = context.getApplicationContext();
                C0979j0.f8027d = new C0979j0(applicationContext, (LocationManager) applicationContext.getSystemService("location"));
            }
            this.f23N0 = new C0021h(C0979j0.f8027d);
        }
        return this.f23N0;
    }

    /* renamed from: l */
    public final Window.Callback mo47l() {
        return this.f34b0.getCallback();
    }

    /* JADX WARNING: Removed duplicated region for block: B:13:0x002e  */
    /* JADX WARNING: Removed duplicated region for block: B:16:? A[RETURN, SYNTHETIC] */
    /* renamed from: m */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo48m() {
        /*
            r3 = this;
            r3.mo43h()
            boolean r0 = r3.f55w0
            if (r0 == 0) goto L_0x0033
            n r0 = r3.f37e0
            if (r0 == 0) goto L_0x000c
            goto L_0x0033
        L_0x000c:
            java.lang.Object r0 = r3.f32Z
            boolean r1 = r0 instanceof android.app.Activity
            if (r1 == 0) goto L_0x001e
            k0 r1 = new k0
            android.app.Activity r0 = (android.app.Activity) r0
            boolean r2 = r3.f56x0
            r1.<init>(r0, r2)
        L_0x001b:
            r3.f37e0 = r1
            goto L_0x002a
        L_0x001e:
            boolean r1 = r0 instanceof android.app.Dialog
            if (r1 == 0) goto L_0x002a
            k0 r1 = new k0
            android.app.Dialog r0 = (android.app.Dialog) r0
            r1.<init>(r0)
            goto L_0x001b
        L_0x002a:
            n r0 = r3.f37e0
            if (r0 == 0) goto L_0x0033
            boolean r1 = r3.f28S0
            r0.mo7747b((boolean) r1)
        L_0x0033:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0011a0.mo48m():void");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:2:0x0004, code lost:
        r0 = r1.f50r0;
     */
    /* renamed from: n */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean mo49n() {
        /*
            r1 = this;
            boolean r0 = r1.f49q0
            if (r0 == 0) goto L_0x0010
            android.view.ViewGroup r0 = r1.f50r0
            if (r0 == 0) goto L_0x0010
            boolean r0 = p000.C2189w7.m15031z(r0)
            if (r0 == 0) goto L_0x0010
            r0 = 1
            goto L_0x0011
        L_0x0010:
            r0 = 0
        L_0x0011:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0011a0.mo49n():boolean");
    }

    /* renamed from: o */
    public final void mo50o() {
        if (this.f49q0) {
            throw new AndroidRuntimeException("Window feature must be requested before adding content");
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:17:0x0070, code lost:
        if (((org.xmlpull.v1.XmlPullParser) r15).getDepth() > 1) goto L_0x0081;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.view.View onCreateView(android.view.View r12, java.lang.String r13, android.content.Context r14, android.util.AttributeSet r15) {
        /*
            r11 = this;
            androidx.appcompat.app.AppCompatViewInflater r0 = r11.f31V0
            r1 = 0
            if (r0 != 0) goto L_0x0060
            android.content.Context r0 = r11.f33a0
            int[] r2 = p000.C1292m.AppCompatTheme
            android.content.res.TypedArray r0 = r0.obtainStyledAttributes(r2)
            int r2 = p000.C1292m.AppCompatTheme_viewInflaterClass
            java.lang.String r0 = r0.getString(r2)
            if (r0 == 0) goto L_0x0059
            java.lang.Class<androidx.appcompat.app.AppCompatViewInflater> r2 = androidx.appcompat.app.AppCompatViewInflater.class
            java.lang.String r2 = r2.getName()
            boolean r2 = r2.equals(r0)
            if (r2 == 0) goto L_0x0022
            goto L_0x0059
        L_0x0022:
            java.lang.Class r2 = java.lang.Class.forName(r0)     // Catch:{ all -> 0x0037 }
            java.lang.Class[] r3 = new java.lang.Class[r1]     // Catch:{ all -> 0x0037 }
            java.lang.reflect.Constructor r2 = r2.getDeclaredConstructor(r3)     // Catch:{ all -> 0x0037 }
            java.lang.Object[] r3 = new java.lang.Object[r1]     // Catch:{ all -> 0x0037 }
            java.lang.Object r2 = r2.newInstance(r3)     // Catch:{ all -> 0x0037 }
            androidx.appcompat.app.AppCompatViewInflater r2 = (androidx.appcompat.app.AppCompatViewInflater) r2     // Catch:{ all -> 0x0037 }
            r11.f31V0 = r2     // Catch:{ all -> 0x0037 }
            goto L_0x0060
        L_0x0037:
            r2 = move-exception
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            java.lang.String r4 = "Failed to instantiate custom view inflater "
            r3.append(r4)
            r3.append(r0)
            java.lang.String r0 = ". Falling back to default."
            r3.append(r0)
            java.lang.String r0 = r3.toString()
            java.lang.String r3 = "AppCompatDelegate"
            android.util.Log.i(r3, r0, r2)
            androidx.appcompat.app.AppCompatViewInflater r0 = new androidx.appcompat.app.AppCompatViewInflater
            r0.<init>()
            goto L_0x005e
        L_0x0059:
            androidx.appcompat.app.AppCompatViewInflater r0 = new androidx.appcompat.app.AppCompatViewInflater
            r0.<init>()
        L_0x005e:
            r11.f31V0 = r0
        L_0x0060:
            boolean r0 = f6X0
            if (r0 == 0) goto L_0x009a
            boolean r0 = r15 instanceof org.xmlpull.v1.XmlPullParser
            r2 = 1
            if (r0 == 0) goto L_0x0073
            r0 = r15
            org.xmlpull.v1.XmlPullParser r0 = (org.xmlpull.v1.XmlPullParser) r0
            int r0 = r0.getDepth()
            if (r0 <= r2) goto L_0x0098
            goto L_0x0081
        L_0x0073:
            r0 = r12
            android.view.ViewParent r0 = (android.view.ViewParent) r0
            if (r0 != 0) goto L_0x0079
            goto L_0x0098
        L_0x0079:
            android.view.Window r3 = r11.f34b0
            android.view.View r3 = r3.getDecorView()
        L_0x007f:
            if (r0 != 0) goto L_0x0083
        L_0x0081:
            r1 = 1
            goto L_0x0098
        L_0x0083:
            if (r0 == r3) goto L_0x0098
            boolean r4 = r0 instanceof android.view.View
            if (r4 == 0) goto L_0x0098
            r4 = r0
            android.view.View r4 = (android.view.View) r4
            boolean r4 = p000.C2189w7.m15030y(r4)
            if (r4 == 0) goto L_0x0093
            goto L_0x0098
        L_0x0093:
            android.view.ViewParent r0 = r0.getParent()
            goto L_0x007f
        L_0x0098:
            r7 = r1
            goto L_0x009b
        L_0x009a:
            r7 = 0
        L_0x009b:
            androidx.appcompat.app.AppCompatViewInflater r2 = r11.f31V0
            boolean r8 = f6X0
            r9 = 1
            p000.C0512d4.m3429a()
            r10 = 0
            r3 = r12
            r4 = r13
            r5 = r14
            r6 = r15
            android.view.View r12 = r2.createView(r3, r4, r5, r6, r7, r8, r9, r10)
            return r12
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0011a0.onCreateView(android.view.View, java.lang.String, android.content.Context, android.util.AttributeSet):android.view.View");
    }

    public View onCreateView(String str, Context context, AttributeSet attributeSet) {
        return onCreateView((View) null, str, context, attributeSet);
    }

    /* renamed from: a0$e */
    public class C0017e extends C0025a1 {
        public C0017e(Window.Callback callback) {
            super(callback);
        }

        /* renamed from: a */
        public final ActionMode mo62a(ActionMode.Callback callback) {
            C2249x0.C2250a aVar = new C2249x0.C2250a(C0011a0.this.f33a0, callback);
            C1889t0 a = C0011a0.this.mo10a((C1889t0.C1890a) aVar);
            if (a != null) {
                return aVar.mo12408b(a);
            }
            return null;
        }

        public boolean dispatchKeyEvent(KeyEvent keyEvent) {
            return C0011a0.this.mo23a(keyEvent) || this.f96X.dispatchKeyEvent(keyEvent);
        }

        /* JADX WARNING: Code restructure failed: missing block: B:17:0x0049, code lost:
            if (r6 != false) goto L_0x001d;
         */
        /* JADX WARNING: Removed duplicated region for block: B:21:? A[RETURN, SYNTHETIC] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean dispatchKeyShortcutEvent(android.view.KeyEvent r6) {
            /*
                r5 = this;
                android.view.Window$Callback r0 = r5.f96X
                boolean r0 = r0.dispatchKeyShortcutEvent(r6)
                r1 = 0
                r2 = 1
                if (r0 != 0) goto L_0x004f
                a0 r0 = p000.C0011a0.this
                int r3 = r6.getKeyCode()
                r0.mo48m()
                n r4 = r0.f37e0
                if (r4 == 0) goto L_0x001f
                boolean r3 = r4.mo7744a(r3, r6)
                if (r3 == 0) goto L_0x001f
            L_0x001d:
                r6 = 1
                goto L_0x004d
            L_0x001f:
                a0$j r3 = r0.f13D0
                if (r3 == 0) goto L_0x0034
                int r4 = r6.getKeyCode()
                boolean r3 = r0.mo22a(r3, r4, r6, r2)
                if (r3 == 0) goto L_0x0034
                a0$j r6 = r0.f13D0
                if (r6 == 0) goto L_0x001d
                r6.f87n = r2
                goto L_0x001d
            L_0x0034:
                a0$j r3 = r0.f13D0
                if (r3 != 0) goto L_0x004c
                a0$j r3 = r0.mo34d(r1)
                r0.mo31b((p000.C0011a0.C0023j) r3, (android.view.KeyEvent) r6)
                int r4 = r6.getKeyCode()
                boolean r6 = r0.mo22a(r3, r4, r6, r2)
                r3.f86m = r1
                if (r6 == 0) goto L_0x004c
                goto L_0x001d
            L_0x004c:
                r6 = 0
            L_0x004d:
                if (r6 == 0) goto L_0x0050
            L_0x004f:
                r1 = 1
            L_0x0050:
                return r1
            */
            throw new UnsupportedOperationException("Method not decompiled: p000.C0011a0.C0017e.dispatchKeyShortcutEvent(android.view.KeyEvent):boolean");
        }

        public void onContentChanged() {
        }

        public boolean onCreatePanelMenu(int i, Menu menu) {
            if (i != 0 || (menu instanceof C0816h1)) {
                return this.f96X.onCreatePanelMenu(i, menu);
            }
            return false;
        }

        public boolean onMenuOpened(int i, Menu menu) {
            this.f96X.onMenuOpened(i, menu);
            C0011a0.this.mo38f(i);
            return true;
        }

        public void onPanelClosed(int i, Menu menu) {
            this.f96X.onPanelClosed(i, menu);
            C0011a0.this.mo41g(i);
        }

        public boolean onPreparePanel(int i, View view, Menu menu) {
            C0816h1 h1Var = menu instanceof C0816h1 ? (C0816h1) menu : null;
            if (i == 0 && h1Var == null) {
                return false;
            }
            if (h1Var != null) {
                h1Var.f6519z = true;
            }
            boolean onPreparePanel = this.f96X.onPreparePanel(i, view, menu);
            if (h1Var != null) {
                h1Var.f6519z = false;
            }
            return onPreparePanel;
        }

        public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> list, Menu menu, int i) {
            C0816h1 h1Var;
            C0023j d = C0011a0.this.mo34d(0);
            if (d == null || (h1Var = d.f83j) == null) {
                this.f96X.onProvideKeyboardShortcuts(list, menu, i);
            } else {
                this.f96X.onProvideKeyboardShortcuts(list, h1Var, i);
            }
        }

        public ActionMode onWindowStartingActionMode(ActionMode.Callback callback) {
            if (Build.VERSION.SDK_INT >= 23) {
                return null;
            }
            if (C0011a0.this.f48p0) {
                return mo62a(callback);
            }
            return this.f96X.onWindowStartingActionMode(callback);
        }

        public ActionMode onWindowStartingActionMode(ActionMode.Callback callback, int i) {
            if (!C0011a0.this.f48p0 || i != 0) {
                return this.f96X.onWindowStartingActionMode(callback, i);
            }
            return mo62a(callback);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:113:0x01a8  */
    /* JADX WARNING: Removed duplicated region for block: B:151:0x020f  */
    /* JADX WARNING: Removed duplicated region for block: B:155:0x0225  */
    /* JADX WARNING: Removed duplicated region for block: B:166:0x024f  */
    /* JADX WARNING: Removed duplicated region for block: B:170:0x025c  */
    /* JADX WARNING: Removed duplicated region for block: B:171:0x0264  */
    /* JADX WARNING: Removed duplicated region for block: B:175:0x026d  */
    /* JADX WARNING: Removed duplicated region for block: B:179:0x0280  */
    /* JADX WARNING: Removed duplicated region for block: B:29:0x006e  */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x0075  */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x008b  */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x008d A[SYNTHETIC, Splitter:B:40:0x008d] */
    /* JADX WARNING: Removed duplicated region for block: B:74:0x0109  */
    /* JADX WARNING: Removed duplicated region for block: B:83:0x0145  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean mo25a(boolean r14) {
        /*
            r13 = this;
            boolean r0 = r13.f18I0
            r1 = 0
            if (r0 == 0) goto L_0x0006
            return r1
        L_0x0006:
            int r0 = r13.f19J0
            r2 = -100
            if (r0 == r2) goto L_0x000d
            goto L_0x000f
        L_0x000d:
            r0 = -100
        L_0x000f:
            r3 = -1
            r4 = 3
            r5 = 2
            r6 = 23
            r7 = 1
            if (r0 == r2) goto L_0x0059
            if (r0 == r3) goto L_0x0057
            if (r0 == 0) goto L_0x0039
            if (r0 == r7) goto L_0x0057
            if (r0 == r5) goto L_0x0057
            if (r0 != r4) goto L_0x0031
            a0$g r2 = r13.f24O0
            if (r2 != 0) goto L_0x002e
            a0$f r2 = new a0$f
            android.content.Context r3 = r13.f33a0
            r2.<init>(r3)
            r13.f24O0 = r2
        L_0x002e:
            a0$g r2 = r13.f24O0
            goto L_0x0052
        L_0x0031:
            java.lang.IllegalStateException r14 = new java.lang.IllegalStateException
            java.lang.String r0 = "Unknown value set for night mode. Please use one of the MODE_NIGHT values from AppCompatDelegate."
            r14.<init>(r0)
            throw r14
        L_0x0039:
            int r2 = android.os.Build.VERSION.SDK_INT
            if (r2 < r6) goto L_0x004e
            android.content.Context r2 = r13.f33a0
            java.lang.Class<android.app.UiModeManager> r8 = android.app.UiModeManager.class
            java.lang.Object r2 = r2.getSystemService(r8)
            android.app.UiModeManager r2 = (android.app.UiModeManager) r2
            int r2 = r2.getNightMode()
            if (r2 != 0) goto L_0x004e
            goto L_0x0059
        L_0x004e:
            a0$g r2 = r13.mo46k()
        L_0x0052:
            int r2 = r2.mo74c()
            goto L_0x005a
        L_0x0057:
            r2 = r0
            goto L_0x005a
        L_0x0059:
            r2 = -1
        L_0x005a:
            android.content.Context r3 = r13.f33a0
            android.content.Context r3 = r3.getApplicationContext()
            android.content.res.Resources r3 = r3.getResources()
            android.content.res.Configuration r3 = r3.getConfiguration()
            int r3 = r3.uiMode
            r3 = r3 & 48
            if (r2 == r7) goto L_0x0075
            if (r2 == r5) goto L_0x0072
            r2 = r3
            goto L_0x0077
        L_0x0072:
            r2 = 32
            goto L_0x0077
        L_0x0075:
            r2 = 16
        L_0x0077:
            boolean r5 = r13.f22M0
            java.lang.String r8 = "AppCompatDelegate"
            if (r5 != 0) goto L_0x00b4
            java.lang.Object r5 = r13.f32Z
            boolean r5 = r5 instanceof android.app.Activity
            if (r5 == 0) goto L_0x00b4
            android.content.Context r5 = r13.f33a0
            android.content.pm.PackageManager r5 = r5.getPackageManager()
            if (r5 != 0) goto L_0x008d
            r5 = 0
            goto L_0x00b8
        L_0x008d:
            android.content.ComponentName r9 = new android.content.ComponentName     // Catch:{ NameNotFoundException -> 0x00ac }
            android.content.Context r10 = r13.f33a0     // Catch:{ NameNotFoundException -> 0x00ac }
            java.lang.Object r11 = r13.f32Z     // Catch:{ NameNotFoundException -> 0x00ac }
            java.lang.Class r11 = r11.getClass()     // Catch:{ NameNotFoundException -> 0x00ac }
            r9.<init>(r10, r11)     // Catch:{ NameNotFoundException -> 0x00ac }
            android.content.pm.ActivityInfo r5 = r5.getActivityInfo(r9, r1)     // Catch:{ NameNotFoundException -> 0x00ac }
            if (r5 == 0) goto L_0x00a8
            int r5 = r5.configChanges     // Catch:{ NameNotFoundException -> 0x00ac }
            r5 = r5 & 512(0x200, float:7.175E-43)
            if (r5 == 0) goto L_0x00a8
            r5 = 1
            goto L_0x00a9
        L_0x00a8:
            r5 = 0
        L_0x00a9:
            r13.f21L0 = r5     // Catch:{ NameNotFoundException -> 0x00ac }
            goto L_0x00b4
        L_0x00ac:
            r5 = move-exception
            java.lang.String r9 = "Exception while getting ActivityInfo"
            android.util.Log.d(r8, r9, r5)
            r13.f21L0 = r1
        L_0x00b4:
            r13.f22M0 = r7
            boolean r5 = r13.f21L0
        L_0x00b8:
            boolean r9 = f9a1
            if (r9 != 0) goto L_0x00be
            if (r2 == r3) goto L_0x00e7
        L_0x00be:
            if (r5 != 0) goto L_0x00e7
            int r3 = android.os.Build.VERSION.SDK_INT
            boolean r3 = r13.f15F0
            if (r3 != 0) goto L_0x00e7
            java.lang.Object r3 = r13.f32Z
            boolean r3 = r3 instanceof android.view.ContextThemeWrapper
            if (r3 == 0) goto L_0x00e7
            android.content.res.Configuration r3 = new android.content.res.Configuration
            r3.<init>()
            int r9 = r3.uiMode
            r9 = r9 & -49
            r9 = r9 | r2
            r3.uiMode = r9
            java.lang.Object r9 = r13.f32Z     // Catch:{ IllegalStateException -> 0x00e1 }
            android.view.ContextThemeWrapper r9 = (android.view.ContextThemeWrapper) r9     // Catch:{ IllegalStateException -> 0x00e1 }
            r9.applyOverrideConfiguration(r3)     // Catch:{ IllegalStateException -> 0x00e1 }
            r1 = 1
            goto L_0x00e7
        L_0x00e1:
            r3 = move-exception
            java.lang.String r9 = "updateForNightMode. Calling applyOverrideConfiguration() failed with an exception. Will fall back to using Resources.updateConfiguration()"
            android.util.Log.e(r8, r9, r3)
        L_0x00e7:
            android.content.Context r3 = r13.f33a0
            android.content.res.Resources r3 = r3.getResources()
            android.content.res.Configuration r3 = r3.getConfiguration()
            int r3 = r3.uiMode
            r3 = r3 & 48
            if (r1 != 0) goto L_0x010f
            if (r3 == r2) goto L_0x010f
            if (r14 == 0) goto L_0x010f
            if (r5 != 0) goto L_0x010f
            boolean r14 = r13.f15F0
            if (r14 == 0) goto L_0x010f
            int r14 = android.os.Build.VERSION.SDK_INT
            java.lang.Object r14 = r13.f32Z
            boolean r8 = r14 instanceof android.app.Activity
            if (r8 == 0) goto L_0x010f
            android.app.Activity r14 = (android.app.Activity) r14
            p000.C1669q5.m11515b(r14)
            r1 = 1
        L_0x010f:
            if (r1 != 0) goto L_0x024d
            if (r3 == r2) goto L_0x024d
            android.content.Context r14 = r13.f33a0
            android.content.res.Resources r14 = r14.getResources()
            android.content.res.Configuration r1 = new android.content.res.Configuration
            android.content.res.Configuration r3 = r14.getConfiguration()
            r1.<init>(r3)
            android.content.res.Configuration r3 = r14.getConfiguration()
            int r3 = r3.uiMode
            r3 = r3 & -49
            r2 = r2 | r3
            r1.uiMode = r2
            r2 = 0
            r14.updateConfiguration(r1, r2)
            int r3 = android.os.Build.VERSION.SDK_INT
            r8 = 26
            if (r3 >= r8) goto L_0x020b
            r8 = 28
            if (r3 < r8) goto L_0x013d
            goto L_0x020b
        L_0x013d:
            r8 = 24
            java.lang.String r9 = "mDrawableCache"
            java.lang.String r10 = "ResourcesFlusher"
            if (r3 < r8) goto L_0x01a8
            boolean r3 = p000.C0815h0.f6472h
            if (r3 != 0) goto L_0x0161
            java.lang.Class<android.content.res.Resources> r3 = android.content.res.Resources.class
            java.lang.String r8 = "mResourcesImpl"
            java.lang.reflect.Field r3 = r3.getDeclaredField(r8)     // Catch:{ NoSuchFieldException -> 0x0159 }
            p000.C0815h0.f6471g = r3     // Catch:{ NoSuchFieldException -> 0x0159 }
            java.lang.reflect.Field r3 = p000.C0815h0.f6471g     // Catch:{ NoSuchFieldException -> 0x0159 }
            r3.setAccessible(r7)     // Catch:{ NoSuchFieldException -> 0x0159 }
            goto L_0x015f
        L_0x0159:
            r3 = move-exception
            java.lang.String r8 = "Could not retrieve Resources#mResourcesImpl field"
            android.util.Log.e(r10, r8, r3)
        L_0x015f:
            p000.C0815h0.f6472h = r7
        L_0x0161:
            java.lang.reflect.Field r3 = p000.C0815h0.f6471g
            if (r3 != 0) goto L_0x0167
            goto L_0x020b
        L_0x0167:
            java.lang.Object r14 = r3.get(r14)     // Catch:{ IllegalAccessException -> 0x016c }
            goto L_0x0173
        L_0x016c:
            r14 = move-exception
            java.lang.String r3 = "Could not retrieve value from Resources#mResourcesImpl"
            android.util.Log.e(r10, r3, r14)
            r14 = r2
        L_0x0173:
            if (r14 != 0) goto L_0x0177
            goto L_0x020b
        L_0x0177:
            boolean r3 = p000.C0815h0.f6466b
            if (r3 != 0) goto L_0x0193
            java.lang.Class r3 = r14.getClass()     // Catch:{ NoSuchFieldException -> 0x018b }
            java.lang.reflect.Field r3 = r3.getDeclaredField(r9)     // Catch:{ NoSuchFieldException -> 0x018b }
            p000.C0815h0.f6465a = r3     // Catch:{ NoSuchFieldException -> 0x018b }
            java.lang.reflect.Field r3 = p000.C0815h0.f6465a     // Catch:{ NoSuchFieldException -> 0x018b }
            r3.setAccessible(r7)     // Catch:{ NoSuchFieldException -> 0x018b }
            goto L_0x0191
        L_0x018b:
            r3 = move-exception
            java.lang.String r8 = "Could not retrieve ResourcesImpl#mDrawableCache field"
            android.util.Log.e(r10, r8, r3)
        L_0x0191:
            p000.C0815h0.f6466b = r7
        L_0x0193:
            java.lang.reflect.Field r3 = p000.C0815h0.f6465a
            if (r3 == 0) goto L_0x01a2
            java.lang.Object r2 = r3.get(r14)     // Catch:{ IllegalAccessException -> 0x019c }
            goto L_0x01a2
        L_0x019c:
            r14 = move-exception
            java.lang.String r3 = "Could not retrieve value from ResourcesImpl#mDrawableCache"
            android.util.Log.e(r10, r3, r14)
        L_0x01a2:
            if (r2 == 0) goto L_0x020b
            p000.C0815h0.m5848b((java.lang.Object) r2)
            goto L_0x020b
        L_0x01a8:
            java.lang.String r8 = "Could not retrieve Resources#mDrawableCache field"
            java.lang.String r11 = "Could not retrieve value from Resources#mDrawableCache"
            if (r3 < r6) goto L_0x01da
            boolean r3 = p000.C0815h0.f6466b
            if (r3 != 0) goto L_0x01c6
            java.lang.Class<android.content.res.Resources> r3 = android.content.res.Resources.class
            java.lang.reflect.Field r3 = r3.getDeclaredField(r9)     // Catch:{ NoSuchFieldException -> 0x01c0 }
            p000.C0815h0.f6465a = r3     // Catch:{ NoSuchFieldException -> 0x01c0 }
            java.lang.reflect.Field r3 = p000.C0815h0.f6465a     // Catch:{ NoSuchFieldException -> 0x01c0 }
            r3.setAccessible(r7)     // Catch:{ NoSuchFieldException -> 0x01c0 }
            goto L_0x01c4
        L_0x01c0:
            r3 = move-exception
            android.util.Log.e(r10, r8, r3)
        L_0x01c4:
            p000.C0815h0.f6466b = r7
        L_0x01c6:
            java.lang.reflect.Field r3 = p000.C0815h0.f6465a
            if (r3 == 0) goto L_0x01d3
            java.lang.Object r2 = r3.get(r14)     // Catch:{ IllegalAccessException -> 0x01cf }
            goto L_0x01d3
        L_0x01cf:
            r14 = move-exception
            android.util.Log.e(r10, r11, r14)
        L_0x01d3:
            if (r2 != 0) goto L_0x01d6
            goto L_0x020b
        L_0x01d6:
            p000.C0815h0.m5848b((java.lang.Object) r2)
            goto L_0x020b
        L_0x01da:
            r12 = 21
            if (r3 < r12) goto L_0x020b
            boolean r3 = p000.C0815h0.f6466b
            if (r3 != 0) goto L_0x01f6
            java.lang.Class<android.content.res.Resources> r3 = android.content.res.Resources.class
            java.lang.reflect.Field r3 = r3.getDeclaredField(r9)     // Catch:{ NoSuchFieldException -> 0x01f0 }
            p000.C0815h0.f6465a = r3     // Catch:{ NoSuchFieldException -> 0x01f0 }
            java.lang.reflect.Field r3 = p000.C0815h0.f6465a     // Catch:{ NoSuchFieldException -> 0x01f0 }
            r3.setAccessible(r7)     // Catch:{ NoSuchFieldException -> 0x01f0 }
            goto L_0x01f4
        L_0x01f0:
            r3 = move-exception
            android.util.Log.e(r10, r8, r3)
        L_0x01f4:
            p000.C0815h0.f6466b = r7
        L_0x01f6:
            java.lang.reflect.Field r3 = p000.C0815h0.f6465a
            if (r3 == 0) goto L_0x020b
            java.lang.Object r14 = r3.get(r14)     // Catch:{ IllegalAccessException -> 0x0201 }
            java.util.Map r14 = (java.util.Map) r14     // Catch:{ IllegalAccessException -> 0x0201 }
            goto L_0x0206
        L_0x0201:
            r14 = move-exception
            android.util.Log.e(r10, r11, r14)
            r14 = r2
        L_0x0206:
            if (r14 == 0) goto L_0x020b
            r14.clear()
        L_0x020b:
            int r14 = r13.f20K0
            if (r14 == 0) goto L_0x0223
            android.content.Context r2 = r13.f33a0
            r2.setTheme(r14)
            int r14 = android.os.Build.VERSION.SDK_INT
            if (r14 < r6) goto L_0x0223
            android.content.Context r14 = r13.f33a0
            android.content.res.Resources$Theme r14 = r14.getTheme()
            int r2 = r13.f20K0
            r14.applyStyle(r2, r7)
        L_0x0223:
            if (r5 == 0) goto L_0x024c
            java.lang.Object r14 = r13.f32Z
            boolean r2 = r14 instanceof android.app.Activity
            if (r2 == 0) goto L_0x024c
            android.app.Activity r14 = (android.app.Activity) r14
            boolean r2 = r14 instanceof p000.C1509ob
            if (r2 == 0) goto L_0x0245
            r2 = r14
            ob r2 = (p000.C1509ob) r2
            lb r2 = r2.mo635a()
            pb r2 = (p000.C1607pb) r2
            lb$b r2 = r2.f12333b
            lb$b r3 = p000.C1234lb.C1236b.STARTED
            boolean r2 = r2.mo8348a(r3)
            if (r2 == 0) goto L_0x024c
            goto L_0x0249
        L_0x0245:
            boolean r2 = r13.f17H0
            if (r2 == 0) goto L_0x024c
        L_0x0249:
            r14.onConfigurationChanged(r1)
        L_0x024c:
            r1 = 1
        L_0x024d:
            if (r1 == 0) goto L_0x025a
            java.lang.Object r14 = r13.f32Z
            boolean r2 = r14 instanceof androidx.appcompat.app.AppCompatActivity
            if (r2 == 0) goto L_0x025a
            androidx.appcompat.app.AppCompatActivity r14 = (androidx.appcompat.app.AppCompatActivity) r14
            r14.mo678n()
        L_0x025a:
            if (r0 != 0) goto L_0x0264
            a0$g r14 = r13.mo46k()
            r14.mo77e()
            goto L_0x026b
        L_0x0264:
            a0$g r14 = r13.f23N0
            if (r14 == 0) goto L_0x026b
            r14.mo76a()
        L_0x026b:
            if (r0 != r4) goto L_0x0280
            a0$g r14 = r13.f24O0
            if (r14 != 0) goto L_0x027a
            a0$f r14 = new a0$f
            android.content.Context r0 = r13.f33a0
            r14.<init>(r0)
            r13.f24O0 = r14
        L_0x027a:
            a0$g r14 = r13.f24O0
            r14.mo77e()
            goto L_0x0287
        L_0x0280:
            a0$g r14 = r13.f24O0
            if (r14 == 0) goto L_0x0287
            r14.mo76a()
        L_0x0287:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0011a0.mo25a(boolean):boolean");
    }

    /* renamed from: b */
    public void mo27b(int i) {
        mo43h();
        ViewGroup viewGroup = (ViewGroup) this.f50r0.findViewById(16908290);
        viewGroup.removeAllViews();
        LayoutInflater.from(this.f33a0).inflate(i, viewGroup);
        this.f35c0.f96X.onContentChanged();
    }

    /* renamed from: b */
    public void mo29b(View view, ViewGroup.LayoutParams layoutParams) {
        mo43h();
        ViewGroup viewGroup = (ViewGroup) this.f50r0.findViewById(16908290);
        viewGroup.removeAllViews();
        viewGroup.addView(view, layoutParams);
        this.f35c0.f96X.onContentChanged();
    }

    /* renamed from: a */
    public final void mo18a(Window window) {
        if (this.f34b0 == null) {
            Window.Callback callback = window.getCallback();
            if (!(callback instanceof C0017e)) {
                this.f35c0 = new C0017e(callback);
                window.setCallback(this.f35c0);
                C2322y3 a = C2322y3.m16056a(this.f33a0, (AttributeSet) null, f7Y0);
                Drawable c = a.mo12739c(0);
                if (c != null) {
                    window.setBackgroundDrawable(c);
                }
                a.f17544b.recycle();
                this.f34b0 = window;
                return;
            }
            throw new IllegalStateException("AppCompat has already installed itself into the Window");
        }
        throw new IllegalStateException("AppCompat has already installed itself into the Window");
    }

    /* renamed from: a */
    public void mo11a(int i, C0023j jVar, Menu menu) {
        if (menu == null) {
            if (jVar == null && i >= 0) {
                C0023j[] jVarArr = this.f12C0;
                if (i < jVarArr.length) {
                    jVar = jVarArr[i];
                }
            }
            if (jVar != null) {
                menu = jVar.f83j;
            }
        }
        if ((jVar == null || jVar.f88o) && !this.f18I0) {
            this.f35c0.f96X.onPanelClosed(i, menu);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:65:0x00d3  */
    /* JADX WARNING: Removed duplicated region for block: B:88:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:93:? A[RETURN, SYNTHETIC] */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo23a(android.view.KeyEvent r7) {
        /*
            r6 = this;
            java.lang.Object r0 = r6.f32Z
            boolean r1 = r0 instanceof p000.C0908i7.C0909a
            r2 = 1
            if (r1 != 0) goto L_0x000b
            boolean r0 = r0 instanceof p000.C0730g0
            if (r0 == 0) goto L_0x001a
        L_0x000b:
            android.view.Window r0 = r6.f34b0
            android.view.View r0 = r0.getDecorView()
            if (r0 == 0) goto L_0x001a
            boolean r0 = p000.C2189w7.m15001b((android.view.View) r0, (android.view.KeyEvent) r7)
            if (r0 == 0) goto L_0x001a
            return r2
        L_0x001a:
            int r0 = r7.getKeyCode()
            r1 = 82
            if (r0 != r1) goto L_0x002d
            a0$e r0 = r6.f35c0
            android.view.Window$Callback r0 = r0.f96X
            boolean r0 = r0.dispatchKeyEvent(r7)
            if (r0 == 0) goto L_0x002d
            return r2
        L_0x002d:
            int r0 = r7.getKeyCode()
            int r3 = r7.getAction()
            r4 = 0
            if (r3 != 0) goto L_0x003a
            r3 = 1
            goto L_0x003b
        L_0x003a:
            r3 = 0
        L_0x003b:
            r5 = 4
            if (r3 == 0) goto L_0x0065
            if (r0 == r5) goto L_0x0056
            if (r0 == r1) goto L_0x0043
            goto L_0x0062
        L_0x0043:
            int r0 = r7.getRepeatCount()
            if (r0 != 0) goto L_0x0119
            a0$j r0 = r6.mo34d(r4)
            boolean r1 = r0.f88o
            if (r1 != 0) goto L_0x0119
            r6.mo31b((p000.C0011a0.C0023j) r0, (android.view.KeyEvent) r7)
            goto L_0x0119
        L_0x0056:
            int r7 = r7.getFlags()
            r7 = r7 & 128(0x80, float:1.794E-43)
            if (r7 == 0) goto L_0x005f
            goto L_0x0060
        L_0x005f:
            r2 = 0
        L_0x0060:
            r6.f14E0 = r2
        L_0x0062:
            r2 = 0
            goto L_0x0119
        L_0x0065:
            if (r0 == r5) goto L_0x00eb
            if (r0 == r1) goto L_0x006a
            goto L_0x0062
        L_0x006a:
            t0 r0 = r6.f43k0
            if (r0 == 0) goto L_0x0070
            goto L_0x0119
        L_0x0070:
            a0$j r0 = r6.mo34d(r4)
            z2 r1 = r6.f40h0
            if (r1 == 0) goto L_0x00aa
            boolean r1 = r1.mo818g()
            if (r1 == 0) goto L_0x00aa
            android.content.Context r1 = r6.f33a0
            android.view.ViewConfiguration r1 = android.view.ViewConfiguration.get(r1)
            boolean r1 = r1.hasPermanentMenuKey()
            if (r1 != 0) goto L_0x00aa
            z2 r1 = r6.f40h0
            boolean r1 = r1.mo806a()
            if (r1 != 0) goto L_0x00a3
            boolean r1 = r6.f18I0
            if (r1 != 0) goto L_0x00ca
            boolean r7 = r6.mo31b((p000.C0011a0.C0023j) r0, (android.view.KeyEvent) r7)
            if (r7 == 0) goto L_0x00ca
            z2 r7 = r6.f40h0
            boolean r7 = r7.mo816f()
            goto L_0x00d1
        L_0x00a3:
            z2 r7 = r6.f40h0
            boolean r7 = r7.mo815e()
            goto L_0x00d1
        L_0x00aa:
            boolean r1 = r0.f88o
            if (r1 != 0) goto L_0x00cc
            boolean r1 = r0.f87n
            if (r1 == 0) goto L_0x00b3
            goto L_0x00cc
        L_0x00b3:
            boolean r1 = r0.f86m
            if (r1 == 0) goto L_0x00ca
            boolean r1 = r0.f91r
            if (r1 == 0) goto L_0x00c2
            r0.f86m = r4
            boolean r1 = r6.mo31b((p000.C0011a0.C0023j) r0, (android.view.KeyEvent) r7)
            goto L_0x00c3
        L_0x00c2:
            r1 = 1
        L_0x00c3:
            if (r1 == 0) goto L_0x00ca
            r6.mo12a((p000.C0011a0.C0023j) r0, (android.view.KeyEvent) r7)
            r7 = 1
            goto L_0x00d1
        L_0x00ca:
            r7 = 0
            goto L_0x00d1
        L_0x00cc:
            boolean r7 = r0.f88o
            r6.mo13a((p000.C0011a0.C0023j) r0, (boolean) r2)
        L_0x00d1:
            if (r7 == 0) goto L_0x0119
            android.content.Context r7 = r6.f33a0
            java.lang.String r0 = "audio"
            java.lang.Object r7 = r7.getSystemService(r0)
            android.media.AudioManager r7 = (android.media.AudioManager) r7
            if (r7 == 0) goto L_0x00e3
            r7.playSoundEffect(r4)
            goto L_0x0119
        L_0x00e3:
            java.lang.String r7 = "AppCompatDelegate"
            java.lang.String r0 = "Couldn't get audio manager"
            android.util.Log.w(r7, r0)
            goto L_0x0119
        L_0x00eb:
            boolean r7 = r6.f14E0
            r6.f14E0 = r4
            a0$j r0 = r6.mo34d(r4)
            if (r0 == 0) goto L_0x00ff
            boolean r1 = r0.f88o
            if (r1 == 0) goto L_0x00ff
            if (r7 != 0) goto L_0x0119
            r6.mo13a((p000.C0011a0.C0023j) r0, (boolean) r2)
            goto L_0x0119
        L_0x00ff:
            t0 r7 = r6.f43k0
            if (r7 == 0) goto L_0x0107
            r7.mo7754a()
            goto L_0x0114
        L_0x0107:
            r6.mo48m()
            n r7 = r6.f37e0
            if (r7 == 0) goto L_0x0116
            boolean r7 = r7.mo7743a()
            if (r7 == 0) goto L_0x0116
        L_0x0114:
            r7 = 1
            goto L_0x0117
        L_0x0116:
            r7 = 0
        L_0x0117:
            if (r7 == 0) goto L_0x0062
        L_0x0119:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0011a0.mo23a(android.view.KeyEvent):boolean");
    }

    /* renamed from: a */
    public void mo14a(Configuration configuration) {
        if (this.f55w0 && this.f49q0) {
            mo48m();
            C1377n nVar = this.f37e0;
            if (nVar != null) {
                nVar.mo7739a(configuration);
            }
        }
        C0820h2.m5929a().mo6353a(this.f33a0);
        mo25a(false);
    }

    /* renamed from: a */
    public void mo15a(Bundle bundle) {
        this.f15F0 = true;
        mo25a(false);
        mo44i();
        Object obj = this.f32Z;
        if (obj instanceof Activity) {
            String str = null;
            try {
                Activity activity = (Activity) obj;
                str = C0815h0.m5844b((Context) activity, activity.getComponentName());
            } catch (PackageManager.NameNotFoundException e) {
                throw new IllegalArgumentException(e);
            } catch (IllegalArgumentException unused) {
            }
            if (str != null) {
                C1377n nVar = this.f37e0;
                if (nVar == null) {
                    this.f28S0 = true;
                } else {
                    nVar.mo7747b(true);
                }
            }
        }
        this.f16G0 = true;
    }

    /* renamed from: a */
    public void mo19a(C0816h1 h1Var) {
        C2390z2 z2Var = this.f40h0;
        if (z2Var == null || !z2Var.mo818g() || (ViewConfiguration.get(this.f33a0).hasPermanentMenuKey() && !this.f40h0.mo813d())) {
            C0023j d = mo34d(0);
            d.f90q = true;
            mo13a(d, false);
            mo12a(d, (KeyEvent) null);
            return;
        }
        Window.Callback l = mo47l();
        if (this.f40h0.mo806a()) {
            this.f40h0.mo815e();
            if (!this.f18I0) {
                l.onPanelClosed(108, mo34d(0).f83j);
            }
        } else if (l != null && !this.f18I0) {
            if (this.f25P0 && (1 & this.f26Q0) != 0) {
                this.f34b0.getDecorView().removeCallbacks(this.f27R0);
                this.f27R0.run();
            }
            C0023j d2 = mo34d(0);
            C0816h1 h1Var2 = d2.f83j;
            if (h1Var2 != null && !d2.f91r && l.onPreparePanel(0, d2.f82i, h1Var2)) {
                l.onMenuOpened(108, d2.f83j);
                this.f40h0.mo816f();
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:67:0x0101, code lost:
        if (r14.f81h != null) goto L_0x0103;
     */
    /* JADX WARNING: Removed duplicated region for block: B:71:0x0108  */
    /* JADX WARNING: Removed duplicated region for block: B:93:? A[RETURN, SYNTHETIC] */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo12a(p000.C0011a0.C0023j r14, android.view.KeyEvent r15) {
        /*
            r13 = this;
            boolean r0 = r14.f88o
            if (r0 != 0) goto L_0x017f
            boolean r0 = r13.f18I0
            if (r0 == 0) goto L_0x000a
            goto L_0x017f
        L_0x000a:
            int r0 = r14.f74a
            r1 = 0
            r2 = 1
            if (r0 != 0) goto L_0x0027
            android.content.Context r0 = r13.f33a0
            android.content.res.Resources r0 = r0.getResources()
            android.content.res.Configuration r0 = r0.getConfiguration()
            int r0 = r0.screenLayout
            r0 = r0 & 15
            r3 = 4
            if (r0 != r3) goto L_0x0023
            r0 = 1
            goto L_0x0024
        L_0x0023:
            r0 = 0
        L_0x0024:
            if (r0 == 0) goto L_0x0027
            return
        L_0x0027:
            android.view.Window$Callback r0 = r13.mo47l()
            if (r0 == 0) goto L_0x003b
            int r3 = r14.f74a
            h1 r4 = r14.f83j
            boolean r0 = r0.onMenuOpened(r3, r4)
            if (r0 != 0) goto L_0x003b
            r13.mo13a((p000.C0011a0.C0023j) r14, (boolean) r2)
            return
        L_0x003b:
            android.content.Context r0 = r13.f33a0
            java.lang.String r3 = "window"
            java.lang.Object r0 = r0.getSystemService(r3)
            android.view.WindowManager r0 = (android.view.WindowManager) r0
            if (r0 != 0) goto L_0x0048
            return
        L_0x0048:
            boolean r15 = r13.mo31b((p000.C0011a0.C0023j) r14, (android.view.KeyEvent) r15)
            if (r15 != 0) goto L_0x004f
            return
        L_0x004f:
            android.view.ViewGroup r15 = r14.f80g
            r3 = -1
            r4 = -2
            if (r15 == 0) goto L_0x006b
            boolean r15 = r14.f90q
            if (r15 == 0) goto L_0x005a
            goto L_0x006b
        L_0x005a:
            android.view.View r15 = r14.f82i
            if (r15 == 0) goto L_0x015d
            android.view.ViewGroup$LayoutParams r15 = r15.getLayoutParams()
            if (r15 == 0) goto L_0x015d
            int r15 = r15.width
            if (r15 != r3) goto L_0x015d
            r6 = -1
            goto L_0x015e
        L_0x006b:
            android.view.ViewGroup r15 = r14.f80g
            if (r15 != 0) goto L_0x0088
            android.content.Context r15 = r13.mo45j()
            r14.mo82a((android.content.Context) r15)
            a0$i r15 = new a0$i
            android.content.Context r3 = r14.f85l
            r15.<init>(r3)
            r14.f80g = r15
            r15 = 81
            r14.f76c = r15
            android.view.ViewGroup r15 = r14.f80g
            if (r15 != 0) goto L_0x0097
            return
        L_0x0088:
            boolean r3 = r14.f90q
            if (r3 == 0) goto L_0x0097
            int r15 = r15.getChildCount()
            if (r15 <= 0) goto L_0x0097
            android.view.ViewGroup r15 = r14.f80g
            r15.removeAllViews()
        L_0x0097:
            android.view.View r15 = r14.f82i
            if (r15 == 0) goto L_0x009e
            r14.f81h = r15
            goto L_0x0103
        L_0x009e:
            h1 r15 = r14.f83j
            if (r15 != 0) goto L_0x00a3
            goto L_0x0105
        L_0x00a3:
            a0$k r15 = r13.f42j0
            if (r15 != 0) goto L_0x00ae
            a0$k r15 = new a0$k
            r15.<init>()
            r13.f42j0 = r15
        L_0x00ae:
            a0$k r15 = r13.f42j0
            h1 r3 = r14.f83j
            if (r3 != 0) goto L_0x00b6
            r15 = 0
            goto L_0x00fd
        L_0x00b6:
            f1 r3 = r14.f84k
            if (r3 != 0) goto L_0x00d0
            f1 r3 = new f1
            android.content.Context r5 = r14.f85l
            int r6 = p000.C0978j.abc_list_menu_item_layout
            r3.<init>(r5, r6)
            r14.f84k = r3
            f1 r3 = r14.f84k
            r3.f4926e0 = r15
            h1 r15 = r14.f83j
            android.content.Context r5 = r15.f6494a
            r15.mo6287a((p000.C1581p1) r3, (android.content.Context) r5)
        L_0x00d0:
            f1 r15 = r14.f84k
            android.view.ViewGroup r3 = r14.f80g
            androidx.appcompat.view.menu.ExpandedMenuView r5 = r15.f4922a0
            if (r5 != 0) goto L_0x00fb
            android.view.LayoutInflater r5 = r15.f4920Y
            int r6 = p000.C0978j.abc_expanded_menu_layout
            android.view.View r3 = r5.inflate(r6, r3, r1)
            androidx.appcompat.view.menu.ExpandedMenuView r3 = (androidx.appcompat.view.menu.ExpandedMenuView) r3
            r15.f4922a0 = r3
            f1$a r3 = r15.f4927f0
            if (r3 != 0) goto L_0x00ef
            f1$a r3 = new f1$a
            r3.<init>()
            r15.f4927f0 = r3
        L_0x00ef:
            androidx.appcompat.view.menu.ExpandedMenuView r3 = r15.f4922a0
            f1$a r5 = r15.f4927f0
            r3.setAdapter(r5)
            androidx.appcompat.view.menu.ExpandedMenuView r3 = r15.f4922a0
            r3.setOnItemClickListener(r15)
        L_0x00fb:
            androidx.appcompat.view.menu.ExpandedMenuView r15 = r15.f4922a0
        L_0x00fd:
            r14.f81h = r15
            android.view.View r15 = r14.f81h
            if (r15 == 0) goto L_0x0105
        L_0x0103:
            r15 = 1
            goto L_0x0106
        L_0x0105:
            r15 = 0
        L_0x0106:
            if (r15 == 0) goto L_0x017f
            android.view.View r15 = r14.f81h
            if (r15 != 0) goto L_0x010d
            goto L_0x0120
        L_0x010d:
            android.view.View r15 = r14.f82i
            if (r15 == 0) goto L_0x0112
            goto L_0x011e
        L_0x0112:
            f1 r15 = r14.f84k
            android.widget.ListAdapter r15 = r15.mo5270b()
            int r15 = r15.getCount()
            if (r15 <= 0) goto L_0x0120
        L_0x011e:
            r15 = 1
            goto L_0x0121
        L_0x0120:
            r15 = 0
        L_0x0121:
            if (r15 != 0) goto L_0x0124
            goto L_0x017f
        L_0x0124:
            android.view.View r15 = r14.f81h
            android.view.ViewGroup$LayoutParams r15 = r15.getLayoutParams()
            if (r15 != 0) goto L_0x0131
            android.view.ViewGroup$LayoutParams r15 = new android.view.ViewGroup$LayoutParams
            r15.<init>(r4, r4)
        L_0x0131:
            int r3 = r14.f75b
            android.view.ViewGroup r5 = r14.f80g
            r5.setBackgroundResource(r3)
            android.view.View r3 = r14.f81h
            android.view.ViewParent r3 = r3.getParent()
            boolean r5 = r3 instanceof android.view.ViewGroup
            if (r5 == 0) goto L_0x0149
            android.view.ViewGroup r3 = (android.view.ViewGroup) r3
            android.view.View r5 = r14.f81h
            r3.removeView(r5)
        L_0x0149:
            android.view.ViewGroup r3 = r14.f80g
            android.view.View r5 = r14.f81h
            r3.addView(r5, r15)
            android.view.View r15 = r14.f81h
            boolean r15 = r15.hasFocus()
            if (r15 != 0) goto L_0x015d
            android.view.View r15 = r14.f81h
            r15.requestFocus()
        L_0x015d:
            r6 = -2
        L_0x015e:
            r14.f87n = r1
            android.view.WindowManager$LayoutParams r15 = new android.view.WindowManager$LayoutParams
            r7 = -2
            int r8 = r14.f77d
            int r9 = r14.f78e
            r10 = 1002(0x3ea, float:1.404E-42)
            r11 = 8519680(0x820000, float:1.1938615E-38)
            r12 = -3
            r5 = r15
            r5.<init>(r6, r7, r8, r9, r10, r11, r12)
            int r1 = r14.f76c
            r15.gravity = r1
            int r1 = r14.f79f
            r15.windowAnimations = r1
            android.view.ViewGroup r1 = r14.f80g
            r0.addView(r1, r15)
            r14.f88o = r2
        L_0x017f:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0011a0.mo12a(a0$j, android.view.KeyEvent):void");
    }

    /* renamed from: a */
    public boolean mo21a(int i) {
        if (i == 8) {
            Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
            i = 108;
        } else if (i == 9) {
            Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
            i = 109;
        }
        if (this.f10A0 && i == 108) {
            return false;
        }
        if (this.f55w0 && i == 1) {
            this.f55w0 = false;
        }
        if (i == 1) {
            mo50o();
            this.f10A0 = true;
            return true;
        } else if (i == 2) {
            mo50o();
            this.f53u0 = true;
            return true;
        } else if (i == 5) {
            mo50o();
            this.f54v0 = true;
            return true;
        } else if (i == 10) {
            mo50o();
            this.f57y0 = true;
            return true;
        } else if (i == 108) {
            mo50o();
            this.f55w0 = true;
            return true;
        } else if (i != 109) {
            return this.f34b0.requestFeature(i);
        } else {
            mo50o();
            this.f56x0 = true;
            return true;
        }
    }

    /* renamed from: a */
    public void mo16a(View view) {
        mo43h();
        ViewGroup viewGroup = (ViewGroup) this.f50r0.findViewById(16908290);
        viewGroup.removeAllViews();
        viewGroup.addView(view);
        this.f35c0.f96X.onContentChanged();
    }

    /* renamed from: a */
    public final void mo20a(CharSequence charSequence) {
        this.f39g0 = charSequence;
        C2390z2 z2Var = this.f40h0;
        if (z2Var != null) {
            z2Var.setWindowTitle(charSequence);
            return;
        }
        C1377n nVar = this.f37e0;
        if (nVar != null) {
            nVar.mo7741a(charSequence);
            return;
        }
        TextView textView = this.f51s0;
        if (textView != null) {
            textView.setText(charSequence);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:25:0x0045  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x0049  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public p000.C1889t0 mo10a(p000.C1889t0.C1890a r8) {
        /*
            r7 = this;
            if (r8 == 0) goto L_0x01a4
            t0 r0 = r7.f43k0
            if (r0 == 0) goto L_0x0009
            r0.mo7754a()
        L_0x0009:
            a0$d r0 = new a0$d
            r0.<init>(r8)
            r7.mo48m()
            n r8 = r7.f37e0
            if (r8 == 0) goto L_0x0026
            t0 r8 = r8.mo7737a((p000.C1889t0.C1890a) r0)
            r7.f43k0 = r8
            t0 r8 = r7.f43k0
            if (r8 == 0) goto L_0x0026
            y r1 = r7.f36d0
            if (r1 == 0) goto L_0x0026
            r1.mo661a((p000.C1889t0) r8)
        L_0x0026:
            t0 r8 = r7.f43k0
            if (r8 != 0) goto L_0x01a1
            r7.mo40g()
            t0 r8 = r7.f43k0
            if (r8 == 0) goto L_0x0034
            r8.mo7754a()
        L_0x0034:
            y r8 = r7.f36d0
            r1 = 0
            if (r8 == 0) goto L_0x0042
            boolean r2 = r7.f18I0
            if (r2 != 0) goto L_0x0042
            t0 r8 = r8.mo659a((p000.C1889t0.C1890a) r0)     // Catch:{ AbstractMethodError -> 0x0042 }
            goto L_0x0043
        L_0x0042:
            r8 = r1
        L_0x0043:
            if (r8 == 0) goto L_0x0049
            r7.f43k0 = r8
            goto L_0x0192
        L_0x0049:
            androidx.appcompat.widget.ActionBarContextView r8 = r7.f44l0
            r2 = 1
            r3 = 0
            if (r8 != 0) goto L_0x0103
            boolean r8 = r7.f58z0
            if (r8 == 0) goto L_0x00d7
            android.util.TypedValue r8 = new android.util.TypedValue
            r8.<init>()
            android.content.Context r4 = r7.f33a0
            android.content.res.Resources$Theme r4 = r4.getTheme()
            int r5 = p000.C0502d.actionBarTheme
            r4.resolveAttribute(r5, r8, r2)
            int r5 = r8.resourceId
            if (r5 == 0) goto L_0x0088
            android.content.Context r5 = r7.f33a0
            android.content.res.Resources r5 = r5.getResources()
            android.content.res.Resources$Theme r5 = r5.newTheme()
            r5.setTo(r4)
            int r4 = r8.resourceId
            r5.applyStyle(r4, r2)
            v0 r4 = new v0
            android.content.Context r6 = r7.f33a0
            r4.<init>(r6, r3)
            android.content.res.Resources$Theme r6 = r4.getTheme()
            r6.setTo(r5)
            goto L_0x008a
        L_0x0088:
            android.content.Context r4 = r7.f33a0
        L_0x008a:
            androidx.appcompat.widget.ActionBarContextView r5 = new androidx.appcompat.widget.ActionBarContextView
            r5.<init>(r4)
            r7.f44l0 = r5
            android.widget.PopupWindow r5 = new android.widget.PopupWindow
            int r6 = p000.C0502d.actionModePopupWindowStyle
            r5.<init>(r4, r1, r6)
            r7.f45m0 = r5
            android.widget.PopupWindow r5 = r7.f45m0
            r6 = 2
            p000.C0815h0.m5812a((android.widget.PopupWindow) r5, (int) r6)
            android.widget.PopupWindow r5 = r7.f45m0
            androidx.appcompat.widget.ActionBarContextView r6 = r7.f44l0
            r5.setContentView(r6)
            android.widget.PopupWindow r5 = r7.f45m0
            r6 = -1
            r5.setWidth(r6)
            android.content.res.Resources$Theme r5 = r4.getTheme()
            int r6 = p000.C0502d.actionBarSize
            r5.resolveAttribute(r6, r8, r2)
            int r8 = r8.data
            android.content.res.Resources r4 = r4.getResources()
            android.util.DisplayMetrics r4 = r4.getDisplayMetrics()
            int r8 = android.util.TypedValue.complexToDimensionPixelSize(r8, r4)
            androidx.appcompat.widget.ActionBarContextView r4 = r7.f44l0
            r4.setContentHeight(r8)
            android.widget.PopupWindow r8 = r7.f45m0
            r4 = -2
            r8.setHeight(r4)
            e0 r8 = new e0
            r8.<init>(r7)
            r7.f46n0 = r8
            goto L_0x0103
        L_0x00d7:
            android.view.ViewGroup r8 = r7.f50r0
            int r4 = p000.C0887i.action_mode_bar_stub
            android.view.View r8 = r8.findViewById(r4)
            androidx.appcompat.widget.ViewStubCompat r8 = (androidx.appcompat.widget.ViewStubCompat) r8
            if (r8 == 0) goto L_0x0103
            r7.mo48m()
            n r4 = r7.f37e0
            if (r4 == 0) goto L_0x00ef
            android.content.Context r4 = r4.mo7748c()
            goto L_0x00f0
        L_0x00ef:
            r4 = r1
        L_0x00f0:
            if (r4 != 0) goto L_0x00f4
            android.content.Context r4 = r7.f33a0
        L_0x00f4:
            android.view.LayoutInflater r4 = android.view.LayoutInflater.from(r4)
            r8.setLayoutInflater(r4)
            android.view.View r8 = r8.mo1155a()
            androidx.appcompat.widget.ActionBarContextView r8 = (androidx.appcompat.widget.ActionBarContextView) r8
            r7.f44l0 = r8
        L_0x0103:
            androidx.appcompat.widget.ActionBarContextView r8 = r7.f44l0
            if (r8 == 0) goto L_0x0192
            r7.mo40g()
            androidx.appcompat.widget.ActionBarContextView r8 = r7.f44l0
            r8.mo778d()
            w0 r8 = new w0
            androidx.appcompat.widget.ActionBarContextView r4 = r7.f44l0
            android.content.Context r4 = r4.getContext()
            androidx.appcompat.widget.ActionBarContextView r5 = r7.f44l0
            android.widget.PopupWindow r6 = r7.f45m0
            if (r6 != 0) goto L_0x011e
            goto L_0x011f
        L_0x011e:
            r2 = 0
        L_0x011f:
            r8.<init>(r4, r5, r0, r2)
            h1 r2 = r8.f16481e0
            t0$a r0 = r0.f62a
            boolean r0 = r0.mo60b(r8, r2)
            if (r0 == 0) goto L_0x0190
            r8.mo7766g()
            androidx.appcompat.widget.ActionBarContextView r0 = r7.f44l0
            r0.mo775a(r8)
            r7.f43k0 = r8
            boolean r8 = r7.mo49n()
            r0 = 1065353216(0x3f800000, float:1.0)
            if (r8 == 0) goto L_0x015a
            androidx.appcompat.widget.ActionBarContextView r8 = r7.f44l0
            r1 = 0
            r8.setAlpha(r1)
            androidx.appcompat.widget.ActionBarContextView r8 = r7.f44l0
            a8 r8 = p000.C2189w7.m14976a(r8)
            r8.mo258a((float) r0)
            r7.f47o0 = r8
            a8 r8 = r7.f47o0
            f0 r0 = new f0
            r0.<init>(r7)
            r8.mo260a((p000.C0286b8) r0)
            goto L_0x0180
        L_0x015a:
            androidx.appcompat.widget.ActionBarContextView r8 = r7.f44l0
            r8.setAlpha(r0)
            androidx.appcompat.widget.ActionBarContextView r8 = r7.f44l0
            r8.setVisibility(r3)
            androidx.appcompat.widget.ActionBarContextView r8 = r7.f44l0
            r0 = 32
            r8.sendAccessibilityEvent(r0)
            androidx.appcompat.widget.ActionBarContextView r8 = r7.f44l0
            android.view.ViewParent r8 = r8.getParent()
            boolean r8 = r8 instanceof android.view.View
            if (r8 == 0) goto L_0x0180
            androidx.appcompat.widget.ActionBarContextView r8 = r7.f44l0
            android.view.ViewParent r8 = r8.getParent()
            android.view.View r8 = (android.view.View) r8
            p000.C2189w7.m14973E(r8)
        L_0x0180:
            android.widget.PopupWindow r8 = r7.f45m0
            if (r8 == 0) goto L_0x0192
            android.view.Window r8 = r7.f34b0
            android.view.View r8 = r8.getDecorView()
            java.lang.Runnable r0 = r7.f46n0
            r8.post(r0)
            goto L_0x0192
        L_0x0190:
            r7.f43k0 = r1
        L_0x0192:
            t0 r8 = r7.f43k0
            if (r8 == 0) goto L_0x019d
            y r0 = r7.f36d0
            if (r0 == 0) goto L_0x019d
            r0.mo661a((p000.C1889t0) r8)
        L_0x019d:
            t0 r8 = r7.f43k0
            r7.f43k0 = r8
        L_0x01a1:
            t0 r8 = r7.f43k0
            return r8
        L_0x01a4:
            java.lang.IllegalArgumentException r8 = new java.lang.IllegalArgumentException
            java.lang.String r0 = "ActionMode callback can not be null."
            r8.<init>(r0)
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0011a0.mo10a(t0$a):t0");
    }
}
