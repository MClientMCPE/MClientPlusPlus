package p000;

import android.os.Bundle;
import com.google.ads.mediation.admob.AdMobAdapter;
import java.util.Map;
import java.util.TreeMap;

/* renamed from: co */
public final class C0383co {

    /* renamed from: a */
    public final String f2821a;

    /* renamed from: b */
    public final Map<String, String> f2822b = new TreeMap();

    /* renamed from: c */
    public String f2823c;

    /* renamed from: d */
    public String f2824d;

    public C0383co(String str) {
        this.f2821a = str;
    }

    /* renamed from: a */
    public final void mo2991a(qv2 qv2, nf0 nf0) {
        this.f2823c = qv2.f13247g0.f12169X;
        Bundle bundle = qv2.f13250j0;
        Bundle bundle2 = bundle != null ? bundle.getBundle(AdMobAdapter.class.getName()) : null;
        if (bundle2 != null) {
            String a = C2166vt.f16437a.mo11055a();
            for (String str : bundle2.keySet()) {
                if (a.equals(str)) {
                    this.f2824d = bundle2.getString(str);
                } else if (str.startsWith("csa_")) {
                    this.f2822b.put(str.substring(4), bundle2.getString(str));
                }
            }
            this.f2822b.put("SDKVersion", nf0.f11062X);
        }
    }
}
