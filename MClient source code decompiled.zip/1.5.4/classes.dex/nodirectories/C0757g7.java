package p000;

import android.os.Build;
import android.os.Bundle;
import android.text.Spanned;
import android.text.style.ClickableSpan;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import p000.C0759g8;
import p000.C0910i8;
import p000.C2189w7;

/* renamed from: g7 */
public class C0757g7 {

    /* renamed from: c */
    public static final View.AccessibilityDelegate f6013c = new View.AccessibilityDelegate();

    /* renamed from: a */
    public final View.AccessibilityDelegate f6014a;

    /* renamed from: b */
    public final View.AccessibilityDelegate f6015b;

    /* renamed from: g7$a */
    public static final class C0758a extends View.AccessibilityDelegate {

        /* renamed from: a */
        public final C0757g7 f6016a;

        public C0758a(C0757g7 g7Var) {
            this.f6016a = g7Var;
        }

        public boolean dispatchPopulateAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            return this.f6016a.mo6019a(view, accessibilityEvent);
        }

        public AccessibilityNodeProvider getAccessibilityNodeProvider(View view) {
            C0835h8 a = this.f6016a.mo6017a(view);
            if (a != null) {
                return (AccessibilityNodeProvider) a.f6639a;
            }
            return null;
        }

        public void onInitializeAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            this.f6016a.mo1380b(view, accessibilityEvent);
        }

        public void onInitializeAccessibilityNodeInfo(View view, AccessibilityNodeInfo accessibilityNodeInfo) {
            int i;
            View view2 = view;
            C0759g8 g8Var = new C0759g8(accessibilityNodeInfo);
            boolean C = C2189w7.m14971C(view);
            if (Build.VERSION.SDK_INT >= 28) {
                g8Var.f6028a.setScreenReaderFocusable(C);
            } else {
                g8Var.mo6036a(1, C);
            }
            Boolean bool = (Boolean) new C2189w7.C2191b(C1498o5.tag_accessibility_heading, Boolean.class, 28).mo12142b(view2);
            boolean booleanValue = bool == null ? false : bool.booleanValue();
            if (Build.VERSION.SDK_INT >= 28) {
                g8Var.f6028a.setHeading(booleanValue);
            } else {
                g8Var.mo6036a(2, booleanValue);
            }
            CharSequence charSequence = (CharSequence) new C2329y7(C1498o5.tag_accessibility_pane_title, CharSequence.class, 8, 28).mo12142b(view2);
            if (Build.VERSION.SDK_INT >= 28) {
                g8Var.f6028a.setPaneTitle(charSequence);
            } else {
                g8Var.f6028a.getExtras().putCharSequence("androidx.view.accessibility.AccessibilityNodeInfoCompat.PANE_TITLE_KEY", charSequence);
            }
            this.f6016a.mo1378a(view2, g8Var);
            CharSequence text = accessibilityNodeInfo.getText();
            if (Build.VERSION.SDK_INT < 26) {
                g8Var.f6028a.getExtras().remove("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_START_KEY");
                g8Var.f6028a.getExtras().remove("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_END_KEY");
                g8Var.f6028a.getExtras().remove("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_FLAGS_KEY");
                g8Var.f6028a.getExtras().remove("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ID_KEY");
                SparseArray sparseArray = (SparseArray) view2.getTag(C1498o5.tag_accessibility_clickable_spans);
                if (sparseArray != null) {
                    ArrayList arrayList = new ArrayList();
                    for (int i2 = 0; i2 < sparseArray.size(); i2++) {
                        if (((WeakReference) sparseArray.valueAt(i2)).get() == null) {
                            arrayList.add(Integer.valueOf(i2));
                        }
                    }
                    for (int i3 = 0; i3 < arrayList.size(); i3++) {
                        sparseArray.remove(((Integer) arrayList.get(i3)).intValue());
                    }
                }
                ClickableSpan[] b = C0759g8.m5390b(text);
                if (b != null && b.length > 0) {
                    g8Var.mo6042c().putInt("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ACTION_ID_KEY", C1498o5.accessibility_action_clickable_span);
                    SparseArray sparseArray2 = (SparseArray) view2.getTag(C1498o5.tag_accessibility_clickable_spans);
                    if (sparseArray2 == null) {
                        sparseArray2 = new SparseArray();
                        view2.setTag(C1498o5.tag_accessibility_clickable_spans, sparseArray2);
                    }
                    for (int i4 = 0; i4 < b.length; i4++) {
                        ClickableSpan clickableSpan = b[i4];
                        int i5 = 0;
                        while (true) {
                            if (i5 >= sparseArray2.size()) {
                                i = C0759g8.f6027d;
                                C0759g8.f6027d = i + 1;
                                break;
                            } else if (clickableSpan.equals((ClickableSpan) ((WeakReference) sparseArray2.valueAt(i5)).get())) {
                                i = sparseArray2.keyAt(i5);
                                break;
                            } else {
                                i5++;
                            }
                        }
                        sparseArray2.put(i, new WeakReference(b[i4]));
                        ClickableSpan clickableSpan2 = b[i4];
                        Spanned spanned = (Spanned) text;
                        g8Var.mo6035a("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_START_KEY").add(Integer.valueOf(spanned.getSpanStart(clickableSpan2)));
                        g8Var.mo6035a("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_END_KEY").add(Integer.valueOf(spanned.getSpanEnd(clickableSpan2)));
                        g8Var.mo6035a("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_FLAGS_KEY").add(Integer.valueOf(spanned.getSpanFlags(clickableSpan2)));
                        g8Var.mo6035a("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ID_KEY").add(Integer.valueOf(i));
                    }
                }
            }
            List list = (List) view2.getTag(C1498o5.tag_accessibility_actions);
            if (list == null) {
                list = Collections.emptyList();
            }
            for (int i6 = 0; i6 < list.size(); i6++) {
                C0759g8.C0760a aVar = (C0759g8.C0760a) list.get(i6);
                if (Build.VERSION.SDK_INT >= 21) {
                    g8Var.f6028a.addAction((AccessibilityNodeInfo.AccessibilityAction) aVar.f6035a);
                }
            }
        }

        public void onPopulateAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            this.f6016a.mo2860c(view, accessibilityEvent);
        }

        public boolean onRequestSendAccessibilityEvent(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
            return this.f6016a.mo6020a(viewGroup, view, accessibilityEvent);
        }

        public boolean performAccessibilityAction(View view, int i, Bundle bundle) {
            return this.f6016a.mo1379a(view, i, bundle);
        }

        public void sendAccessibilityEvent(View view, int i) {
            this.f6016a.mo6018a(view, i);
        }

        public void sendAccessibilityEventUnchecked(View view, AccessibilityEvent accessibilityEvent) {
            this.f6016a.mo6021d(view, accessibilityEvent);
        }
    }

    public C0757g7() {
        this.f6014a = f6013c;
        this.f6015b = new C0758a(this);
    }

    public C0757g7(View.AccessibilityDelegate accessibilityDelegate) {
        this.f6014a = accessibilityDelegate;
        this.f6015b = new C0758a(this);
    }

    /* renamed from: a */
    public C0835h8 mo6017a(View view) {
        int i = Build.VERSION.SDK_INT;
        AccessibilityNodeProvider accessibilityNodeProvider = this.f6014a.getAccessibilityNodeProvider(view);
        if (accessibilityNodeProvider != null) {
            return new C0835h8(accessibilityNodeProvider);
        }
        return null;
    }

    /* renamed from: a */
    public void mo6018a(View view, int i) {
        this.f6014a.sendAccessibilityEvent(view, i);
    }

    /* renamed from: a */
    public void mo1378a(View view, C0759g8 g8Var) {
        this.f6014a.onInitializeAccessibilityNodeInfo(view, g8Var.f6028a);
    }

    /* renamed from: a */
    public boolean mo6019a(View view, AccessibilityEvent accessibilityEvent) {
        return this.f6014a.dispatchPopulateAccessibilityEvent(view, accessibilityEvent);
    }

    /* renamed from: a */
    public boolean mo6020a(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
        return this.f6014a.onRequestSendAccessibilityEvent(viewGroup, view, accessibilityEvent);
    }

    /* renamed from: b */
    public void mo1380b(View view, AccessibilityEvent accessibilityEvent) {
        this.f6014a.onInitializeAccessibilityEvent(view, accessibilityEvent);
    }

    /* renamed from: c */
    public void mo2860c(View view, AccessibilityEvent accessibilityEvent) {
        this.f6014a.onPopulateAccessibilityEvent(view, accessibilityEvent);
    }

    /* renamed from: d */
    public void mo6021d(View view, AccessibilityEvent accessibilityEvent) {
        this.f6014a.sendAccessibilityEventUnchecked(view, accessibilityEvent);
    }

    /* renamed from: a */
    public boolean mo1379a(View view, int i, Bundle bundle) {
        boolean z;
        WeakReference weakReference;
        boolean z2;
        List list = (List) view.getTag(C1498o5.tag_accessibility_actions);
        if (list == null) {
            list = Collections.emptyList();
        }
        int i2 = 0;
        while (true) {
            if (i2 >= list.size()) {
                break;
            }
            C0759g8.C0760a aVar = (C0759g8.C0760a) list.get(i2);
            if (aVar.mo6051a() != i) {
                i2++;
            } else if (aVar.f6038d != null) {
                Class<? extends C0910i8.C0911a> cls = aVar.f6037c;
                if (cls != null) {
                    try {
                        ((C0910i8.C0911a) cls.getDeclaredConstructor(new Class[0]).newInstance(new Object[0])).mo6876a(bundle);
                    } catch (Exception e) {
                        Class<? extends C0910i8.C0911a> cls2 = aVar.f6037c;
                        String name = cls2 == null ? "null" : cls2.getName();
                        Log.e("A11yActionCompat", "Failed to execute command with argument class ViewCommandArgument: " + name, e);
                    }
                }
                BottomSheetBehavior.C0427c cVar = (BottomSheetBehavior.C0427c) aVar.f6038d;
                BottomSheetBehavior.this.mo3420e(cVar.f3093a);
                z = true;
            }
        }
        z = false;
        if (!z) {
            int i3 = Build.VERSION.SDK_INT;
            z = this.f6014a.performAccessibilityAction(view, i, bundle);
        }
        if (z || i != C1498o5.accessibility_action_clickable_span) {
            return z;
        }
        int i4 = bundle.getInt("ACCESSIBILITY_CLICKABLE_SPAN_ID", -1);
        SparseArray sparseArray = (SparseArray) view.getTag(C1498o5.tag_accessibility_clickable_spans);
        if (!(sparseArray == null || (weakReference = (WeakReference) sparseArray.get(i4)) == null)) {
            ClickableSpan clickableSpan = (ClickableSpan) weakReference.get();
            if (clickableSpan != null) {
                ClickableSpan[] b = C0759g8.m5390b(view.createAccessibilityNodeInfo().getText());
                int i5 = 0;
                while (true) {
                    if (b == null || i5 >= b.length) {
                        break;
                    } else if (clickableSpan.equals(b[i5])) {
                        z2 = true;
                        break;
                    } else {
                        i5++;
                    }
                }
            }
            z2 = false;
            if (z2) {
                clickableSpan.onClick(view);
                return true;
            }
        }
        return false;
    }
}
