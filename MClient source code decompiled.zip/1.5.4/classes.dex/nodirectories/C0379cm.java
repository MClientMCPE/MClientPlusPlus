package p000;

/* renamed from: cm */
public abstract class C0379cm {

    /* renamed from: cm$a */
    public interface C0380a {
    }

    /* renamed from: cm$b */
    public interface C0381b {
    }

    /* renamed from: a */
    public abstract String mo2969a();

    /* renamed from: b */
    public abstract Object mo2970b();
}
