package p000;

import android.view.View;
import androidx.recyclerview.widget.RecyclerView;
import p000.C1510oc;

/* renamed from: ad */
public abstract class C0092ad extends RecyclerView.C0226l {

    /* renamed from: g */
    public boolean f360g = true;

    /* renamed from: a */
    public abstract boolean mo382a(RecyclerView.C0218d0 d0Var, int i, int i2, int i3, int i4);

    /* renamed from: a */
    public boolean mo384a(RecyclerView.C0218d0 d0Var, RecyclerView.C0226l.C0229c cVar, RecyclerView.C0226l.C0229c cVar2) {
        if (cVar == null || (cVar.f1344a == cVar2.f1344a && cVar.f1345b == cVar2.f1345b)) {
            C1510oc ocVar = (C1510oc) this;
            ocVar.mo9610j(d0Var);
            d0Var.f1316X.setAlpha(0.0f);
            ocVar.f11785i.add(d0Var);
            return true;
        }
        return mo382a(d0Var, cVar.f1344a, cVar.f1345b, cVar2.f1344a, cVar2.f1345b);
    }

    /* renamed from: b */
    public final void mo385b(RecyclerView.C0218d0 d0Var, boolean z) {
    }

    /* renamed from: b */
    public boolean mo386b(RecyclerView.C0218d0 d0Var, RecyclerView.C0226l.C0229c cVar, RecyclerView.C0226l.C0229c cVar2) {
        int i = cVar.f1344a;
        int i2 = cVar.f1345b;
        View view = d0Var.f1316X;
        int left = cVar2 == null ? view.getLeft() : cVar2.f1344a;
        int top = cVar2 == null ? view.getTop() : cVar2.f1345b;
        if (d0Var.mo1815r() || (i == left && i2 == top)) {
            C1510oc ocVar = (C1510oc) this;
            ocVar.mo9610j(d0Var);
            ocVar.f11784h.add(d0Var);
            return true;
        }
        view.layout(left, top, view.getWidth() + left, view.getHeight() + top);
        return mo382a(d0Var, i, i2, left, top);
    }

    /* renamed from: c */
    public boolean mo388c(RecyclerView.C0218d0 d0Var, RecyclerView.C0226l.C0229c cVar, RecyclerView.C0226l.C0229c cVar2) {
        if (cVar.f1344a == cVar2.f1344a && cVar.f1345b == cVar2.f1345b) {
            RecyclerView.C0226l.C0228b bVar = this.f1338a;
            if (bVar == null) {
                return false;
            }
            ((RecyclerView.C0230m) bVar).mo1861a(d0Var);
            return false;
        }
        return mo382a(d0Var, cVar.f1344a, cVar.f1345b, cVar2.f1344a, cVar2.f1345b);
    }

    /* renamed from: d */
    public final void mo389d(RecyclerView.C0218d0 d0Var) {
    }

    /* renamed from: e */
    public final void mo390e(RecyclerView.C0218d0 d0Var) {
        RecyclerView.C0226l.C0228b bVar = this.f1338a;
        if (bVar != null) {
            ((RecyclerView.C0230m) bVar).mo1861a(d0Var);
        }
    }

    /* renamed from: f */
    public final void mo391f(RecyclerView.C0218d0 d0Var) {
    }

    /* renamed from: g */
    public final void mo392g(RecyclerView.C0218d0 d0Var) {
        RecyclerView.C0226l.C0228b bVar = this.f1338a;
        if (bVar != null) {
            ((RecyclerView.C0230m) bVar).mo1861a(d0Var);
        }
    }

    /* renamed from: h */
    public final void mo393h(RecyclerView.C0218d0 d0Var) {
    }

    /* renamed from: a */
    public boolean mo383a(RecyclerView.C0218d0 d0Var, RecyclerView.C0218d0 d0Var2, RecyclerView.C0226l.C0229c cVar, RecyclerView.C0226l.C0229c cVar2) {
        int i;
        int i2;
        int i3 = cVar.f1344a;
        int i4 = cVar.f1345b;
        if (d0Var2.mo1821w()) {
            int i5 = cVar.f1344a;
            i = cVar.f1345b;
            i2 = i5;
        } else {
            i2 = cVar2.f1344a;
            i = cVar2.f1345b;
        }
        C1510oc ocVar = (C1510oc) this;
        if (d0Var == d0Var2) {
            return ocVar.mo382a(d0Var, i3, i4, i2, i);
        }
        float translationX = d0Var.f1316X.getTranslationX();
        float translationY = d0Var.f1316X.getTranslationY();
        float alpha = d0Var.f1316X.getAlpha();
        ocVar.mo9610j(d0Var);
        d0Var.f1316X.setTranslationX(translationX);
        d0Var.f1316X.setTranslationY(translationY);
        d0Var.f1316X.setAlpha(alpha);
        ocVar.mo9610j(d0Var2);
        d0Var2.f1316X.setTranslationX((float) (-((int) (((float) (i2 - i3)) - translationX))));
        d0Var2.f1316X.setTranslationY((float) (-((int) (((float) (i - i4)) - translationY))));
        d0Var2.f1316X.setAlpha(0.0f);
        ocVar.f11787k.add(new C1510oc.C1515e(d0Var, d0Var2, i3, i4, i2, i));
        return true;
    }

    /* renamed from: a */
    public final void mo381a(RecyclerView.C0218d0 d0Var, boolean z) {
        RecyclerView.C0226l.C0228b bVar = this.f1338a;
        if (bVar != null) {
            ((RecyclerView.C0230m) bVar).mo1861a(d0Var);
        }
    }

    /* renamed from: c */
    public final void mo387c(RecyclerView.C0218d0 d0Var) {
        RecyclerView.C0226l.C0228b bVar = this.f1338a;
        if (bVar != null) {
            ((RecyclerView.C0230m) bVar).mo1861a(d0Var);
        }
    }
}
