package p000;

/* renamed from: dp */
public interface C0552dp extends C0795gp {
}
