package p000;

import android.os.Parcelable;

/* renamed from: bv */
public final class C0324bv implements Parcelable.Creator<C0496cv> {
    /* JADX WARNING: type inference failed for: r1v3, types: [android.os.Parcelable] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final /* synthetic */ java.lang.Object createFromParcel(android.os.Parcel r13) {
        /*
            r12 = this;
            int r0 = p000.C0680fe.m4795b((android.os.Parcel) r13)
            r1 = 0
            r2 = 0
            r9 = r2
            r4 = 0
            r5 = 0
            r6 = 0
            r7 = 0
            r8 = 0
            r10 = 0
            r11 = 0
        L_0x000e:
            int r1 = r13.dataPosition()
            if (r1 >= r0) goto L_0x0050
            int r1 = r13.readInt()
            r2 = 65535(0xffff, float:9.1834E-41)
            r2 = r2 & r1
            switch(r2) {
                case 1: goto L_0x004b;
                case 2: goto L_0x0046;
                case 3: goto L_0x0041;
                case 4: goto L_0x003c;
                case 5: goto L_0x0037;
                case 6: goto L_0x002d;
                case 7: goto L_0x0028;
                case 8: goto L_0x0023;
                default: goto L_0x001f;
            }
        L_0x001f:
            p000.C0680fe.m4887m(r13, r1)
            goto L_0x000e
        L_0x0023:
            int r11 = p000.C0680fe.m4879j(r13, r1)
            goto L_0x000e
        L_0x0028:
            boolean r10 = p000.C0680fe.m4869g(r13, r1)
            goto L_0x000e
        L_0x002d:
            android.os.Parcelable$Creator<rz2> r2 = p000.rz2.CREATOR
            android.os.Parcelable r1 = p000.C0680fe.m4682a((android.os.Parcel) r13, (int) r1, r2)
            r9 = r1
            rz2 r9 = (p000.rz2) r9
            goto L_0x000e
        L_0x0037:
            int r8 = p000.C0680fe.m4879j(r13, r1)
            goto L_0x000e
        L_0x003c:
            boolean r7 = p000.C0680fe.m4869g(r13, r1)
            goto L_0x000e
        L_0x0041:
            int r6 = p000.C0680fe.m4879j(r13, r1)
            goto L_0x000e
        L_0x0046:
            boolean r5 = p000.C0680fe.m4869g(r13, r1)
            goto L_0x000e
        L_0x004b:
            int r4 = p000.C0680fe.m4879j(r13, r1)
            goto L_0x000e
        L_0x0050:
            p000.C0680fe.m4863f(r13, r0)
            cv r13 = new cv
            r3 = r13
            r3.<init>(r4, r5, r6, r7, r8, r9, r10, r11)
            return r13
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0324bv.createFromParcel(android.os.Parcel):java.lang.Object");
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new C0496cv[i];
    }
}
