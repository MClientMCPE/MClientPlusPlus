package p000;

import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: cv */
public final class C0496cv extends C1874sq {
    public static final Parcelable.Creator<C0496cv> CREATOR = new C0324bv();

    /* renamed from: X */
    public final int f3559X;

    /* renamed from: Y */
    public final boolean f3560Y;

    /* renamed from: Z */
    public final int f3561Z;

    /* renamed from: a0 */
    public final boolean f3562a0;

    /* renamed from: b0 */
    public final int f3563b0;

    /* renamed from: c0 */
    public final rz2 f3564c0;

    /* renamed from: d0 */
    public final boolean f3565d0;

    /* renamed from: e0 */
    public final int f3566e0;

    public C0496cv(int i, boolean z, int i2, boolean z2, int i3, rz2 rz2, boolean z3, int i4) {
        this.f3559X = i;
        this.f3560Y = z;
        this.f3561Z = i2;
        this.f3562a0 = z2;
        this.f3563b0 = i3;
        this.f3564c0 = rz2;
        this.f3565d0 = z3;
        this.f3566e0 = i4;
    }

    public C0496cv(C2156vl vlVar) {
        boolean z = vlVar.f16165a;
        int i = vlVar.f16166b;
        boolean z2 = vlVar.f16168d;
        int i2 = vlVar.f16169e;
        C1467nl nlVar = vlVar.f16170f;
        rz2 rz2 = nlVar != null ? new rz2(nlVar) : null;
        boolean z3 = vlVar.f16171g;
        int i3 = vlVar.f16167c;
        this.f3559X = 4;
        this.f3560Y = z;
        this.f3561Z = i;
        this.f3562a0 = z2;
        this.f3563b0 = i2;
        this.f3564c0 = rz2;
        this.f3565d0 = z3;
        this.f3566e0 = i3;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a = C0680fe.m4661a(parcel);
        C0680fe.m4744a(parcel, 1, this.f3559X);
        C0680fe.m4751a(parcel, 2, this.f3560Y);
        C0680fe.m4744a(parcel, 3, this.f3561Z);
        C0680fe.m4751a(parcel, 4, this.f3562a0);
        C0680fe.m4744a(parcel, 5, this.f3563b0);
        C0680fe.m4748a(parcel, 6, (Parcelable) this.f3564c0, i, false);
        C0680fe.m4751a(parcel, 7, this.f3565d0);
        C0680fe.m4744a(parcel, 8, this.f3566e0);
        C0680fe.m4891o(parcel, a);
    }
}
