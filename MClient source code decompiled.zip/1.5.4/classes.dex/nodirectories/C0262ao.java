package p000;

import java.util.concurrent.Callable;

/* renamed from: ao */
public final class C0262ao implements Callable<ya2> {

    /* renamed from: a */
    public final /* synthetic */ C2462zn f1467a;

    public C0262ao(C2462zn znVar) {
        this.f1467a = znVar;
    }

    public final /* synthetic */ Object call() {
        C2462zn znVar = this.f1467a;
        return new ya2(xb2.m15610a(znVar.f18472X.f11062X, znVar.f18475a0, false));
    }
}
