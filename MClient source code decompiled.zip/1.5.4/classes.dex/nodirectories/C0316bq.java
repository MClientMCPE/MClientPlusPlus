package p000;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.Signature;
import android.util.Log;

/* renamed from: bq */
public class C0316bq {

    /* renamed from: a */
    public static C0316bq f2300a;

    public C0316bq(Context context) {
        context.getApplicationContext();
    }

    /* renamed from: a */
    public static C0316bq m2121a(Context context) {
        C0680fe.m4695a(context);
        synchronized (C0316bq.class) {
            if (f2300a == null) {
                C1636pr.m11299a(context);
                f2300a = new C0316bq(context);
            }
        }
        return f2300a;
    }

    /* renamed from: a */
    public static C1714qr m2122a(PackageInfo packageInfo, C1714qr... qrVarArr) {
        Signature[] signatureArr = packageInfo.signatures;
        if (signatureArr == null) {
            return null;
        }
        if (signatureArr.length != 1) {
            Log.w("GoogleSignatureVerifier", "Package has more than one signature.");
            return null;
        }
        C1771rr rrVar = new C1771rr(signatureArr[0].toByteArray());
        for (int i = 0; i < qrVarArr.length; i++) {
            if (qrVarArr[i].equals(rrVar)) {
                return qrVarArr[i];
            }
        }
        return null;
    }

    /* renamed from: a */
    public static boolean m2123a(PackageInfo packageInfo, boolean z) {
        C1714qr qrVar;
        if (!(packageInfo == null || packageInfo.signatures == null)) {
            if (z) {
                qrVar = m2122a(packageInfo, C1942tr.f15130a);
            } else {
                qrVar = m2122a(packageInfo, C1942tr.f15130a[0]);
            }
            if (qrVar != null) {
                return true;
            }
        }
        return false;
    }
}
