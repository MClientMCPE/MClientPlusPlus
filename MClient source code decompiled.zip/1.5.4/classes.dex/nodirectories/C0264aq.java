package p000;

import android.content.Context;
import android.content.pm.PackageManager;
import android.util.Log;
import java.util.concurrent.atomic.AtomicBoolean;

/* renamed from: aq */
public class C0264aq {

    /* renamed from: a */
    public static final AtomicBoolean f1510a = new AtomicBoolean();

    static {
        new AtomicBoolean();
    }

    @Deprecated
    /* renamed from: a */
    public static int m1543a(Context context) {
        try {
            return context.getPackageManager().getPackageInfo("com.google.android.gms", 0).versionCode;
        } catch (PackageManager.NameNotFoundException unused) {
            Log.w("GooglePlayServicesUtil", "Google Play services is missing.");
            return 0;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:43:0x00aa  */
    /* JADX WARNING: Removed duplicated region for block: B:57:0x00dd  */
    /* JADX WARNING: Removed duplicated region for block: B:58:0x00df  */
    /* JADX WARNING: Removed duplicated region for block: B:61:0x00ea  */
    /* JADX WARNING: Removed duplicated region for block: B:71:0x0105  */
    /* JADX WARNING: Removed duplicated region for block: B:72:0x0108  */
    @java.lang.Deprecated
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static int m1544a(android.content.Context r9, int r10) {
        /*
            java.lang.String r0 = "GooglePlayServicesUtil"
            android.content.res.Resources r1 = r9.getResources()     // Catch:{ all -> 0x000c }
            int r2 = p000.C0491cq.common_google_play_services_unknown_issue     // Catch:{ all -> 0x000c }
            r1.getString(r2)     // Catch:{ all -> 0x000c }
            goto L_0x0011
        L_0x000c:
            java.lang.String r1 = "The Google Play services resources were not found. Check your project configuration to ensure that the resources are included."
            android.util.Log.e(r0, r1)
        L_0x0011:
            java.lang.String r1 = r9.getPackageName()
            java.lang.String r2 = "com.google.android.gms"
            boolean r1 = r2.equals(r1)
            java.lang.String r3 = " but found "
            if (r1 != 0) goto L_0x0060
            java.util.concurrent.atomic.AtomicBoolean r1 = f1510a
            boolean r1 = r1.get()
            if (r1 != 0) goto L_0x0060
            p000.C0492cr.m3245a(r9)
            int r1 = p000.C0492cr.f3505d
            if (r1 == 0) goto L_0x0058
            r4 = 12451000(0xbdfcb8, float:1.7447567E-38)
            if (r1 != r4) goto L_0x0034
            goto L_0x0060
        L_0x0034:
            java.lang.IllegalStateException r9 = new java.lang.IllegalStateException
            r10 = 320(0x140, float:4.48E-43)
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>(r10)
            java.lang.String r10 = "The meta-data tag in your app's AndroidManifest.xml does not have the right value.  Expected "
            r0.append(r10)
            r0.append(r4)
            r0.append(r3)
            r0.append(r1)
            java.lang.String r10 = ".  You must have the following declaration within the <application> element:     <meta-data android:name=\"com.google.android.gms.version\" android:value=\"@integer/google_play_services_version\" />"
            r0.append(r10)
            java.lang.String r10 = r0.toString()
            r9.<init>(r10)
            throw r9
        L_0x0058:
            java.lang.IllegalStateException r9 = new java.lang.IllegalStateException
            java.lang.String r10 = "A required meta-data tag in your app's AndroidManifest.xml does not exist.  You must have the following declaration within the <application> element:     <meta-data android:name=\"com.google.android.gms.version\" android:value=\"@integer/google_play_services_version\" />"
            r9.<init>(r10)
            throw r9
        L_0x0060:
            java.lang.Boolean r1 = p000.C0680fe.f5242e
            r4 = 1
            r5 = 0
            if (r1 != 0) goto L_0x0086
            int r1 = android.os.Build.VERSION.SDK_INT
            r6 = 20
            if (r1 < r6) goto L_0x006e
            r1 = 1
            goto L_0x006f
        L_0x006e:
            r1 = 0
        L_0x006f:
            if (r1 == 0) goto L_0x007f
            android.content.pm.PackageManager r1 = r9.getPackageManager()
            java.lang.String r6 = "android.hardware.type.watch"
            boolean r1 = r1.hasSystemFeature(r6)
            if (r1 == 0) goto L_0x007f
            r1 = 1
            goto L_0x0080
        L_0x007f:
            r1 = 0
        L_0x0080:
            java.lang.Boolean r1 = java.lang.Boolean.valueOf(r1)
            p000.C0680fe.f5242e = r1
        L_0x0086:
            java.lang.Boolean r1 = p000.C0680fe.f5242e
            boolean r1 = r1.booleanValue()
            if (r1 == 0) goto L_0x00a7
            int r1 = android.os.Build.VERSION.SDK_INT
            r6 = 24
            if (r1 < r6) goto L_0x0096
            r1 = 1
            goto L_0x0097
        L_0x0096:
            r1 = 0
        L_0x0097:
            if (r1 == 0) goto L_0x00a5
            boolean r1 = p000.C0680fe.m4834c((android.content.Context) r9)
            if (r1 == 0) goto L_0x00a7
            boolean r1 = p000.C0680fe.m4868g()
            if (r1 != 0) goto L_0x00a7
        L_0x00a5:
            r1 = 1
            goto L_0x00a8
        L_0x00a7:
            r1 = 0
        L_0x00a8:
            if (r1 != 0) goto L_0x00da
            java.lang.Boolean r1 = p000.C0680fe.f5245h
            if (r1 != 0) goto L_0x00d0
            android.content.pm.PackageManager r1 = r9.getPackageManager()
            java.lang.String r6 = "android.hardware.type.iot"
            boolean r1 = r1.hasSystemFeature(r6)
            if (r1 != 0) goto L_0x00c9
            android.content.pm.PackageManager r1 = r9.getPackageManager()
            java.lang.String r6 = "android.hardware.type.embedded"
            boolean r1 = r1.hasSystemFeature(r6)
            if (r1 == 0) goto L_0x00c7
            goto L_0x00c9
        L_0x00c7:
            r1 = 0
            goto L_0x00ca
        L_0x00c9:
            r1 = 1
        L_0x00ca:
            java.lang.Boolean r1 = java.lang.Boolean.valueOf(r1)
            p000.C0680fe.f5245h = r1
        L_0x00d0:
            java.lang.Boolean r1 = p000.C0680fe.f5245h
            boolean r1 = r1.booleanValue()
            if (r1 != 0) goto L_0x00da
            r1 = 1
            goto L_0x00db
        L_0x00da:
            r1 = 0
        L_0x00db:
            if (r10 < 0) goto L_0x00df
            r6 = 1
            goto L_0x00e0
        L_0x00df:
            r6 = 0
        L_0x00e0:
            p000.C0680fe.m4773a((boolean) r6)
            android.content.pm.PackageManager r6 = r9.getPackageManager()
            r7 = 0
            if (r1 == 0) goto L_0x00f6
            java.lang.String r7 = "com.android.vending"
            r8 = 8256(0x2040, float:1.1569E-41)
            android.content.pm.PackageInfo r7 = r6.getPackageInfo(r7, r8)     // Catch:{ NameNotFoundException -> 0x00f3 }
            goto L_0x00f6
        L_0x00f3:
            java.lang.String r9 = "Google Play Store is missing."
            goto L_0x0120
        L_0x00f6:
            r8 = 64
            android.content.pm.PackageInfo r8 = r6.getPackageInfo(r2, r8)     // Catch:{ NameNotFoundException -> 0x0159 }
            p000.C0316bq.m2121a(r9)
            boolean r9 = p000.C0316bq.m2123a((android.content.pm.PackageInfo) r8, (boolean) r4)
            if (r9 != 0) goto L_0x0108
            java.lang.String r9 = "Google Play services signature invalid."
            goto L_0x0120
        L_0x0108:
            if (r1 == 0) goto L_0x0126
            boolean r9 = p000.C0316bq.m2123a((android.content.pm.PackageInfo) r7, (boolean) r4)
            if (r9 == 0) goto L_0x011e
            android.content.pm.Signature[] r9 = r7.signatures
            r9 = r9[r5]
            android.content.pm.Signature[] r1 = r8.signatures
            r1 = r1[r5]
            boolean r9 = r9.equals(r1)
            if (r9 != 0) goto L_0x0126
        L_0x011e:
            java.lang.String r9 = "Google Play Store signature invalid."
        L_0x0120:
            android.util.Log.w(r0, r9)
            r4 = 9
            goto L_0x015e
        L_0x0126:
            int r9 = r8.versionCode
            int r9 = p000.C1092jr.m7830a(r9)
            int r1 = p000.C1092jr.m7830a(r10)
            if (r9 >= r1) goto L_0x0141
            int r9 = r8.versionCode
            r1 = 77
            java.lang.String r2 = "Google Play services out of date.  Requires "
            java.lang.String r9 = p000.C0789gk.m5552a((int) r1, (java.lang.String) r2, (int) r10, (java.lang.String) r3, (int) r9)
            android.util.Log.w(r0, r9)
            r4 = 2
            goto L_0x015e
        L_0x0141:
            android.content.pm.ApplicationInfo r9 = r8.applicationInfo
            if (r9 != 0) goto L_0x0151
            android.content.pm.ApplicationInfo r9 = r6.getApplicationInfo(r2, r5)     // Catch:{ NameNotFoundException -> 0x014a }
            goto L_0x0151
        L_0x014a:
            r9 = move-exception
            java.lang.String r10 = "Google Play services missing when getting application info."
            android.util.Log.wtf(r0, r10, r9)
            goto L_0x015e
        L_0x0151:
            boolean r9 = r9.enabled
            if (r9 != 0) goto L_0x0157
            r4 = 3
            goto L_0x015e
        L_0x0157:
            r4 = 0
            goto L_0x015e
        L_0x0159:
            java.lang.String r9 = "Google Play services is missing."
            android.util.Log.w(r0, r9)
        L_0x015e:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0264aq.m1544a(android.content.Context, int):int");
    }

    /* renamed from: b */
    public static Context m1545b(Context context) {
        try {
            return context.createPackageContext("com.google.android.gms", 3);
        } catch (PackageManager.NameNotFoundException unused) {
            return null;
        }
    }
}
