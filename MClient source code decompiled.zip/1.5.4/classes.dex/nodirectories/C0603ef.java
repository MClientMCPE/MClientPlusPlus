package p000;

/* renamed from: ef */
public abstract class C0603ef {
}
