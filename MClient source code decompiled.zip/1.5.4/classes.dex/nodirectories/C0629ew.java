package p000;

import android.os.IBinder;
import android.os.IInterface;

/* renamed from: ew */
public abstract class C0629ew extends qj2 implements C0725fw {
    public C0629ew() {
        super("com.google.android.gms.ads.internal.formats.client.INativeCustomTemplateAd");
    }

    /* renamed from: a */
    public static C0725fw m4328a(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.formats.client.INativeCustomTemplateAd");
        return queryLocalInterface instanceof C0725fw ? (C0725fw) queryLocalInterface : new C0883hw(iBinder);
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v3, resolved type: boolean} */
    /* JADX WARNING: type inference failed for: r1v0 */
    /* JADX WARNING: type inference failed for: r1v1, types: [int] */
    /* JADX WARNING: type inference failed for: r1v4 */
    /* JADX WARNING: type inference failed for: r1v5 */
    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0084, code lost:
        if (r6.f13974Y.mo4608t() != null) goto L_0x0088;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:22:0x0087, code lost:
        r1 = 1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x0088, code lost:
        r8.writeNoException();
        p000.sj2.m12850a(r8, r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:31:0x00e4, code lost:
        r8.writeNoException();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:42:0x0148, code lost:
        r8.writeNoException();
        p000.sj2.m12848a(r8, r6);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:44:0x0162, code lost:
        r8.writeNoException();
        r8.writeString(r6);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:45:0x0168, code lost:
        return true;
     */
    /* JADX WARNING: Multi-variable type inference failed */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean mo2162a(int r6, android.os.Parcel r7, android.os.Parcel r8, int r9) {
        /*
            r5 = this;
            r9 = 0
            r0 = 1
            r1 = 0
            switch(r6) {
                case 1: goto L_0x014f;
                case 2: goto L_0x0135;
                case 3: goto L_0x00f1;
                case 4: goto L_0x00e9;
                case 5: goto L_0x00d8;
                case 6: goto L_0x00cf;
                case 7: goto L_0x00c4;
                case 8: goto L_0x00bb;
                case 9: goto L_0x00b2;
                case 10: goto L_0x009b;
                case 11: goto L_0x0090;
                case 12: goto L_0x0067;
                case 13: goto L_0x004e;
                case 14: goto L_0x0026;
                case 15: goto L_0x0007;
                default: goto L_0x0006;
            }
        L_0x0006:
            return r1
        L_0x0007:
            r6 = r5
            s61 r6 = (p000.s61) r6
            d31 r7 = r6.f13974Y
            java.lang.String r7 = r7.mo4612x()
            java.lang.String r9 = "Google"
            boolean r9 = r9.equals(r7)
            if (r9 == 0) goto L_0x001f
            java.lang.String r6 = "Illegal argument specified for omid partner name."
            p000.C0680fe.m4893p(r6)
            goto L_0x00e4
        L_0x001f:
            v21 r6 = r6.f13976a0
            r6.mo11810a(r7, r1)
            goto L_0x00e4
        L_0x0026:
            android.os.IBinder r6 = r7.readStrongBinder()
            wr r6 = p000.C2232wr.C2233a.m15345a(r6)
            r7 = r5
            s61 r7 = (p000.s61) r7
            java.lang.Object r6 = p000.C2298xr.m15922z(r6)
            boolean r9 = r6 instanceof android.view.View
            if (r9 != 0) goto L_0x003b
            goto L_0x00e4
        L_0x003b:
            d31 r9 = r7.f13974Y
            wr r9 = r9.mo4610v()
            if (r9 != 0) goto L_0x0045
            goto L_0x00e4
        L_0x0045:
            v21 r7 = r7.f13976a0
            android.view.View r6 = (android.view.View) r6
            r7.mo11815b((android.view.View) r6)
            goto L_0x00e4
        L_0x004e:
            r6 = r5
            s61 r6 = (p000.s61) r6
            d31 r6 = r6.f13974Y
            wr r6 = r6.mo4610v()
            if (r6 == 0) goto L_0x0061
            eo r7 = p000.C0619eo.f4708B
            n60 r7 = r7.f4731v
            r7.mo9101a((p000.C2232wr) r6)
            goto L_0x0087
        L_0x0061:
            java.lang.String r6 = "Trying to start OMID session before creation."
            p000.C0680fe.m4893p(r6)
            goto L_0x0088
        L_0x0067:
            r6 = r5
            s61 r6 = (p000.s61) r6
            v21 r7 = r6.f13976a0
            h31 r7 = r7.f15818k
            boolean r7 = r7.mo5868a()
            if (r7 != 0) goto L_0x0075
            goto L_0x0088
        L_0x0075:
            d31 r7 = r6.f13974Y
            wj0 r7 = r7.mo4609u()
            if (r7 != 0) goto L_0x007e
            goto L_0x0088
        L_0x007e:
            d31 r6 = r6.f13974Y
            wj0 r6 = r6.mo4608t()
            if (r6 == 0) goto L_0x0087
            goto L_0x0088
        L_0x0087:
            r1 = 1
        L_0x0088:
            r8.writeNoException()
            p000.sj2.m12850a((android.os.Parcel) r8, (boolean) r1)
            goto L_0x0168
        L_0x0090:
            r6 = r5
            s61 r6 = (p000.s61) r6
            r8.writeNoException()
            p000.sj2.m12848a((android.os.Parcel) r8, (android.os.IInterface) r9)
            goto L_0x0168
        L_0x009b:
            android.os.IBinder r6 = r7.readStrongBinder()
            wr r6 = p000.C2232wr.C2233a.m15345a(r6)
            r7 = r5
            s61 r7 = (p000.s61) r7
            boolean r6 = r7.mo5805y(r6)
            r8.writeNoException()
            p000.sj2.m12850a((android.os.Parcel) r8, (boolean) r6)
            goto L_0x0168
        L_0x00b2:
            r6 = r5
            s61 r6 = (p000.s61) r6
            wr r6 = r6.mo5804d1()
            goto L_0x0148
        L_0x00bb:
            r6 = r5
            s61 r6 = (p000.s61) r6
            v21 r6 = r6.f13976a0
            r6.mo8115a()
            goto L_0x00e4
        L_0x00c4:
            r6 = r5
            s61 r6 = (p000.s61) r6
            d31 r6 = r6.f13974Y
            cy2 r6 = r6.mo4602n()
            goto L_0x0148
        L_0x00cf:
            r6 = r5
            s61 r6 = (p000.s61) r6
            v21 r6 = r6.f13976a0
            r6.mo11821f()
            goto L_0x00e4
        L_0x00d8:
            java.lang.String r6 = r7.readString()
            r7 = r5
            s61 r7 = (p000.s61) r7
            v21 r7 = r7.f13976a0
            r7.mo11809a((java.lang.String) r6)
        L_0x00e4:
            r8.writeNoException()
            goto L_0x0168
        L_0x00e9:
            r6 = r5
            s61 r6 = (p000.s61) r6
            java.lang.String r6 = r6.mo5806y0()
            goto L_0x0162
        L_0x00f1:
            r6 = r5
            s61 r6 = (p000.s61) r6
            d31 r7 = r6.f13974Y
            g5 r7 = r7.mo4611w()
            d31 r6 = r6.f13974Y
            g5 r6 = r6.mo4613y()
            int r9 = r7.f5965Z
            int r2 = r6.f5965Z
            int r9 = r9 + r2
            java.lang.String[] r9 = new java.lang.String[r9]
            r2 = 0
            r3 = 0
        L_0x0109:
            int r4 = r7.f5965Z
            if (r2 >= r4) goto L_0x011a
            java.lang.Object r4 = r7.mo5977c(r2)
            java.lang.String r4 = (java.lang.String) r4
            r9[r3] = r4
            int r2 = r2 + 1
            int r3 = r3 + 1
            goto L_0x0109
        L_0x011a:
            int r7 = r6.f5965Z
            if (r1 >= r7) goto L_0x012a
            java.lang.Object r7 = r6.mo5977c(r1)
            java.lang.String r7 = (java.lang.String) r7
            r9[r3] = r7
            int r1 = r1 + 1
            int r3 = r3 + r0
            goto L_0x011a
        L_0x012a:
            java.util.List r6 = java.util.Arrays.asList(r9)
            r8.writeNoException()
            r8.writeStringList(r6)
            goto L_0x0168
        L_0x0135:
            java.lang.String r6 = r7.readString()
            r7 = r5
            s61 r7 = (p000.s61) r7
            d31 r7 = r7.f13974Y
            g5 r7 = r7.mo4611w()
            java.lang.Object r6 = r7.getOrDefault(r6, r9)
            lv r6 = (p000.C1274lv) r6
        L_0x0148:
            r8.writeNoException()
            p000.sj2.m12848a((android.os.Parcel) r8, (android.os.IInterface) r6)
            goto L_0x0168
        L_0x014f:
            java.lang.String r6 = r7.readString()
            r7 = r5
            s61 r7 = (p000.s61) r7
            d31 r7 = r7.f13974Y
            g5 r7 = r7.mo4613y()
            java.lang.Object r6 = r7.getOrDefault(r6, r9)
            java.lang.String r6 = (java.lang.String) r6
        L_0x0162:
            r8.writeNoException()
            r8.writeString(r6)
        L_0x0168:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0629ew.mo2162a(int, android.os.Parcel, android.os.Parcel, int):boolean");
    }
}
