package p000;

/* renamed from: ai */
public class C0108ai implements C1617pg {

    /* renamed from: a */
    public final /* synthetic */ C0868hi f491a;

    public C0108ai(C0868hi hiVar) {
        this.f491a = hiVar;
    }

    /* renamed from: a */
    public void mo532a(C1249lg lgVar) {
        if (this.f491a.mo6550c(lgVar)) {
            this.f491a.mo6551d(lgVar);
        }
    }
}
