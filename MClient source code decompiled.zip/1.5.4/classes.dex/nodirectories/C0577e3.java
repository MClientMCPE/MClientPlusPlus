package p000;

import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewParent;

/* renamed from: e3 */
public abstract class C0577e3 implements View.OnTouchListener, View.OnAttachStateChangeListener {

    /* renamed from: X */
    public final float f4235X;

    /* renamed from: Y */
    public final int f4236Y;

    /* renamed from: Z */
    public final int f4237Z;

    /* renamed from: a0 */
    public final View f4238a0;

    /* renamed from: b0 */
    public Runnable f4239b0;

    /* renamed from: c0 */
    public Runnable f4240c0;

    /* renamed from: d0 */
    public boolean f4241d0;

    /* renamed from: e0 */
    public int f4242e0;

    /* renamed from: f0 */
    public final int[] f4243f0 = new int[2];

    /* renamed from: e3$a */
    public class C0578a implements Runnable {
        public C0578a() {
        }

        public void run() {
            ViewParent parent = C0577e3.this.f4238a0.getParent();
            if (parent != null) {
                parent.requestDisallowInterceptTouchEvent(true);
            }
        }
    }

    /* renamed from: e3$b */
    public class C0579b implements Runnable {
        public C0579b() {
        }

        public void run() {
            C0577e3 e3Var = C0577e3.this;
            e3Var.mo5024i();
            View view = e3Var.f4238a0;
            if (view.isEnabled() && !view.isLongClickable() && e3Var.mo147k()) {
                view.getParent().requestDisallowInterceptTouchEvent(true);
                long uptimeMillis = SystemClock.uptimeMillis();
                MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                view.onTouchEvent(obtain);
                obtain.recycle();
                e3Var.f4241d0 = true;
            }
        }
    }

    public C0577e3(View view) {
        this.f4238a0 = view;
        view.setLongClickable(true);
        view.addOnAttachStateChangeListener(this);
        this.f4235X = (float) ViewConfiguration.get(view.getContext()).getScaledTouchSlop();
        this.f4236Y = ViewConfiguration.getTapTimeout();
        this.f4237Z = (ViewConfiguration.getLongPressTimeout() + this.f4236Y) / 2;
    }

    /* renamed from: i */
    public final void mo5024i() {
        Runnable runnable = this.f4240c0;
        if (runnable != null) {
            this.f4238a0.removeCallbacks(runnable);
        }
        Runnable runnable2 = this.f4239b0;
        if (runnable2 != null) {
            this.f4238a0.removeCallbacks(runnable2);
        }
    }

    /* renamed from: j */
    public abstract C1788s1 mo146j();

    /* renamed from: k */
    public abstract boolean mo147k();

    /* renamed from: l */
    public boolean mo148l() {
        C1788s1 j = mo146j();
        if (j == null || !j.mo4983r()) {
            return true;
        }
        j.dismiss();
        return true;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:32:0x0087, code lost:
        if (r4 != 3) goto L_0x0079;
     */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x006b  */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x006e  */
    /* JADX WARNING: Removed duplicated region for block: B:58:0x010e  */
    /* JADX WARNING: Removed duplicated region for block: B:59:0x0110  */
    /* JADX WARNING: Removed duplicated region for block: B:61:0x0113  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouch(android.view.View r12, android.view.MotionEvent r13) {
        /*
            r11 = this;
            boolean r12 = r11.f4241d0
            r0 = 3
            r1 = 0
            r2 = 1
            if (r12 == 0) goto L_0x0071
            android.view.View r3 = r11.f4238a0
            s1 r4 = r11.mo146j()
            if (r4 == 0) goto L_0x0061
            boolean r5 = r4.mo4983r()
            if (r5 != 0) goto L_0x0016
            goto L_0x0061
        L_0x0016:
            android.widget.ListView r4 = r4.mo4984s()
            c3 r4 = (p000.C0335c3) r4
            if (r4 == 0) goto L_0x0061
            boolean r5 = r4.isShown()
            if (r5 != 0) goto L_0x0025
            goto L_0x0061
        L_0x0025:
            android.view.MotionEvent r5 = android.view.MotionEvent.obtainNoHistory(r13)
            int[] r6 = r11.f4243f0
            r3.getLocationOnScreen(r6)
            r3 = r6[r1]
            float r3 = (float) r3
            r6 = r6[r2]
            float r6 = (float) r6
            r5.offsetLocation(r3, r6)
            int[] r3 = r11.f4243f0
            r4.getLocationOnScreen(r3)
            r6 = r3[r1]
            int r6 = -r6
            float r6 = (float) r6
            r3 = r3[r2]
            int r3 = -r3
            float r3 = (float) r3
            r5.offsetLocation(r6, r3)
            int r3 = r11.f4242e0
            boolean r3 = r4.mo2763a(r5, r3)
            r5.recycle()
            int r13 = r13.getActionMasked()
            if (r13 == r2) goto L_0x005a
            if (r13 == r0) goto L_0x005a
            r13 = 1
            goto L_0x005b
        L_0x005a:
            r13 = 0
        L_0x005b:
            if (r3 == 0) goto L_0x0061
            if (r13 == 0) goto L_0x0061
            r13 = 1
            goto L_0x0062
        L_0x0061:
            r13 = 0
        L_0x0062:
            if (r13 != 0) goto L_0x006e
            boolean r13 = r11.mo148l()
            if (r13 != 0) goto L_0x006b
            goto L_0x006e
        L_0x006b:
            r13 = 0
            goto L_0x0128
        L_0x006e:
            r13 = 1
            goto L_0x0128
        L_0x0071:
            android.view.View r3 = r11.f4238a0
            boolean r4 = r3.isEnabled()
            if (r4 != 0) goto L_0x007c
        L_0x0079:
            r13 = 0
            goto L_0x0106
        L_0x007c:
            int r4 = r13.getActionMasked()
            if (r4 == 0) goto L_0x00d8
            if (r4 == r2) goto L_0x00d4
            r5 = 2
            if (r4 == r5) goto L_0x008a
            if (r4 == r0) goto L_0x00d4
            goto L_0x0079
        L_0x008a:
            int r0 = r11.f4242e0
            int r0 = r13.findPointerIndex(r0)
            if (r0 < 0) goto L_0x0079
            float r4 = r13.getX(r0)
            float r13 = r13.getY(r0)
            float r0 = r11.f4235X
            float r5 = -r0
            int r6 = (r4 > r5 ? 1 : (r4 == r5 ? 0 : -1))
            if (r6 < 0) goto L_0x00c5
            int r5 = (r13 > r5 ? 1 : (r13 == r5 ? 0 : -1))
            if (r5 < 0) goto L_0x00c5
            int r5 = r3.getRight()
            int r6 = r3.getLeft()
            int r5 = r5 - r6
            float r5 = (float) r5
            float r5 = r5 + r0
            int r4 = (r4 > r5 ? 1 : (r4 == r5 ? 0 : -1))
            if (r4 >= 0) goto L_0x00c5
            int r4 = r3.getBottom()
            int r5 = r3.getTop()
            int r4 = r4 - r5
            float r4 = (float) r4
            float r4 = r4 + r0
            int r13 = (r13 > r4 ? 1 : (r13 == r4 ? 0 : -1))
            if (r13 >= 0) goto L_0x00c5
            r13 = 1
            goto L_0x00c6
        L_0x00c5:
            r13 = 0
        L_0x00c6:
            if (r13 != 0) goto L_0x0079
            r11.mo5024i()
            android.view.ViewParent r13 = r3.getParent()
            r13.requestDisallowInterceptTouchEvent(r2)
            r13 = 1
            goto L_0x0106
        L_0x00d4:
            r11.mo5024i()
            goto L_0x0079
        L_0x00d8:
            int r13 = r13.getPointerId(r1)
            r11.f4242e0 = r13
            java.lang.Runnable r13 = r11.f4239b0
            if (r13 != 0) goto L_0x00e9
            e3$a r13 = new e3$a
            r13.<init>()
            r11.f4239b0 = r13
        L_0x00e9:
            java.lang.Runnable r13 = r11.f4239b0
            int r0 = r11.f4236Y
            long r4 = (long) r0
            r3.postDelayed(r13, r4)
            java.lang.Runnable r13 = r11.f4240c0
            if (r13 != 0) goto L_0x00fc
            e3$b r13 = new e3$b
            r13.<init>()
            r11.f4240c0 = r13
        L_0x00fc:
            java.lang.Runnable r13 = r11.f4240c0
            int r0 = r11.f4237Z
            long r4 = (long) r0
            r3.postDelayed(r13, r4)
            goto L_0x0079
        L_0x0106:
            if (r13 == 0) goto L_0x0110
            boolean r13 = r11.mo147k()
            if (r13 == 0) goto L_0x0110
            r13 = 1
            goto L_0x0111
        L_0x0110:
            r13 = 0
        L_0x0111:
            if (r13 == 0) goto L_0x0128
            long r5 = android.os.SystemClock.uptimeMillis()
            r7 = 3
            r8 = 0
            r9 = 0
            r10 = 0
            r3 = r5
            android.view.MotionEvent r0 = android.view.MotionEvent.obtain(r3, r5, r7, r8, r9, r10)
            android.view.View r3 = r11.f4238a0
            r3.onTouchEvent(r0)
            r0.recycle()
        L_0x0128:
            r11.f4241d0 = r13
            if (r13 != 0) goto L_0x012e
            if (r12 == 0) goto L_0x012f
        L_0x012e:
            r1 = 1
        L_0x012f:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0577e3.onTouch(android.view.View, android.view.MotionEvent):boolean");
    }

    public void onViewAttachedToWindow(View view) {
    }

    public void onViewDetachedFromWindow(View view) {
        this.f4241d0 = false;
        this.f4242e0 = -1;
        Runnable runnable = this.f4239b0;
        if (runnable != null) {
            this.f4238a0.removeCallbacks(runnable);
        }
    }
}
