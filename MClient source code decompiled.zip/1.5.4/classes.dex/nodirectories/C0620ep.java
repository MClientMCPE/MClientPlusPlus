package p000;

import java.util.HashMap;

@Deprecated
/* renamed from: ep */
public final class C0620ep implements C1627pk {

    /* renamed from: a */
    public final HashMap<String, Object> f4740a = new HashMap<>();
}
