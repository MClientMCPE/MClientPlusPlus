package p000;

import android.content.DialogInterface;
import androidx.fragment.app.Fragment;

/* renamed from: ca */
public class C0364ca extends Fragment implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener {
}
