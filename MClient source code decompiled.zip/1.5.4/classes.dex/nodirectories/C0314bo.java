package p000;

import android.view.MotionEvent;
import android.view.View;

/* renamed from: bo */
public final class C0314bo implements View.OnTouchListener {

    /* renamed from: X */
    public final /* synthetic */ C2462zn f2278X;

    public C0314bo(C2462zn znVar) {
        this.f2278X = znVar;
    }

    public final boolean onTouch(View view, MotionEvent motionEvent) {
        ya2 ya2 = this.f2278X.f18479e0;
        if (ya2 == null) {
            return false;
        }
        ya2.f17701c.mo6411a(motionEvent);
        return false;
    }
}
