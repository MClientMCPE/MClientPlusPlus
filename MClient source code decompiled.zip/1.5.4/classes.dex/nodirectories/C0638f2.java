package p000;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.CheckedTextView;
import android.widget.TextView;

/* renamed from: f2 */
public class C0638f2 extends CheckedTextView {

    /* renamed from: b0 */
    public static final int[] f4944b0 = {16843016};

    /* renamed from: a0 */
    public final C2176w2 f4945a0 = new C2176w2(this);

    public C0638f2(Context context, AttributeSet attributeSet) {
        super(C2083v3.m14434a(context), attributeSet, 16843720);
        this.f4945a0.mo12087a(attributeSet, 16843720);
        this.f4945a0.mo12081a();
        C2322y3 a = C2322y3.m16057a(getContext(), attributeSet, f4944b0, 16843720, 0);
        setCheckMarkDrawable(a.mo12737b(0));
        a.f17544b.recycle();
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        C2176w2 w2Var = this.f4945a0;
        if (w2Var != null) {
            w2Var.mo12081a();
        }
    }

    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        C0815h0.m5787a(onCreateInputConnection, editorInfo, (View) this);
        return onCreateInputConnection;
    }

    public void setCheckMarkDrawable(int i) {
        setCheckMarkDrawable(C1206l0.m8461c(getContext(), i));
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(C0815h0.m5786a((TextView) this, callback));
    }

    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        C2176w2 w2Var = this.f4945a0;
        if (w2Var != null) {
            w2Var.mo12084a(context, i);
        }
    }
}
