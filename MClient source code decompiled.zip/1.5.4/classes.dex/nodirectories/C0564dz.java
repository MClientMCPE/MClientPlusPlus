package p000;

import android.os.IInterface;

/* renamed from: dz */
public interface C0564dz extends IInterface {
}
