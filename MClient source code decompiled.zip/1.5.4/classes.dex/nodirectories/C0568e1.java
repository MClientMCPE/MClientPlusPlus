package p000;

import android.content.Context;
import android.content.res.Resources;
import android.os.Handler;
import android.os.SystemClock;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import java.util.ArrayList;
import java.util.List;
import p000.C1581p1;

/* renamed from: e1 */
public final class C0568e1 extends C1301m1 implements C1581p1, View.OnKeyListener, PopupWindow.OnDismissListener {

    /* renamed from: y0 */
    public static final int f4189y0 = C0978j.abc_cascading_menu_item_layout;

    /* renamed from: Y */
    public final Context f4190Y;

    /* renamed from: Z */
    public final int f4191Z;

    /* renamed from: a0 */
    public final int f4192a0;

    /* renamed from: b0 */
    public final int f4193b0;

    /* renamed from: c0 */
    public final boolean f4194c0;

    /* renamed from: d0 */
    public final Handler f4195d0;

    /* renamed from: e0 */
    public final List<C0816h1> f4196e0 = new ArrayList();

    /* renamed from: f0 */
    public final List<C0573d> f4197f0 = new ArrayList();

    /* renamed from: g0 */
    public final ViewTreeObserver.OnGlobalLayoutListener f4198g0 = new C0569a();

    /* renamed from: h0 */
    public final View.OnAttachStateChangeListener f4199h0 = new C0570b();

    /* renamed from: i0 */
    public final C0985j3 f4200i0 = new C0571c();

    /* renamed from: j0 */
    public int f4201j0 = 0;

    /* renamed from: k0 */
    public int f4202k0 = 0;

    /* renamed from: l0 */
    public View f4203l0;

    /* renamed from: m0 */
    public View f4204m0;

    /* renamed from: n0 */
    public int f4205n0;

    /* renamed from: o0 */
    public boolean f4206o0;

    /* renamed from: p0 */
    public boolean f4207p0;

    /* renamed from: q0 */
    public int f4208q0;

    /* renamed from: r0 */
    public int f4209r0;

    /* renamed from: s0 */
    public boolean f4210s0;

    /* renamed from: t0 */
    public boolean f4211t0;

    /* renamed from: u0 */
    public C1581p1.C1582a f4212u0;

    /* renamed from: v0 */
    public ViewTreeObserver f4213v0;

    /* renamed from: w0 */
    public PopupWindow.OnDismissListener f4214w0;

    /* renamed from: x0 */
    public boolean f4215x0;

    /* renamed from: e1$a */
    public class C0569a implements ViewTreeObserver.OnGlobalLayoutListener {
        public C0569a() {
        }

        public void onGlobalLayout() {
            if (C0568e1.this.mo4983r() && C0568e1.this.f4197f0.size() > 0 && !C0568e1.this.f4197f0.get(0).f4223a.f7114A0) {
                View view = C0568e1.this.f4204m0;
                if (view == null || !view.isShown()) {
                    C0568e1.this.dismiss();
                    return;
                }
                for (C0573d dVar : C0568e1.this.f4197f0) {
                    dVar.f4223a.mo4982q();
                }
            }
        }
    }

    /* renamed from: e1$b */
    public class C0570b implements View.OnAttachStateChangeListener {
        public C0570b() {
        }

        public void onViewAttachedToWindow(View view) {
        }

        public void onViewDetachedFromWindow(View view) {
            ViewTreeObserver viewTreeObserver = C0568e1.this.f4213v0;
            if (viewTreeObserver != null) {
                if (!viewTreeObserver.isAlive()) {
                    C0568e1.this.f4213v0 = view.getViewTreeObserver();
                }
                C0568e1 e1Var = C0568e1.this;
                e1Var.f4213v0.removeGlobalOnLayoutListener(e1Var.f4198g0);
            }
            view.removeOnAttachStateChangeListener(this);
        }
    }

    /* renamed from: e1$c */
    public class C0571c implements C0985j3 {

        /* renamed from: e1$c$a */
        public class C0572a implements Runnable {

            /* renamed from: X */
            public final /* synthetic */ C0573d f4219X;

            /* renamed from: Y */
            public final /* synthetic */ MenuItem f4220Y;

            /* renamed from: Z */
            public final /* synthetic */ C0816h1 f4221Z;

            public C0572a(C0573d dVar, MenuItem menuItem, C0816h1 h1Var) {
                this.f4219X = dVar;
                this.f4220Y = menuItem;
                this.f4221Z = h1Var;
            }

            public void run() {
                C0573d dVar = this.f4219X;
                if (dVar != null) {
                    C0568e1.this.f4215x0 = true;
                    dVar.f4224b.mo6288a(false);
                    C0568e1.this.f4215x0 = false;
                }
                if (this.f4220Y.isEnabled() && this.f4220Y.hasSubMenu()) {
                    this.f4221Z.mo6289a(this.f4220Y, 4);
                }
            }
        }

        public C0571c() {
        }

        /* renamed from: a */
        public void mo4988a(C0816h1 h1Var, MenuItem menuItem) {
            C0573d dVar = null;
            C0568e1.this.f4195d0.removeCallbacksAndMessages((Object) null);
            int size = C0568e1.this.f4197f0.size();
            int i = 0;
            while (true) {
                if (i >= size) {
                    i = -1;
                    break;
                } else if (h1Var == C0568e1.this.f4197f0.get(i).f4224b) {
                    break;
                } else {
                    i++;
                }
            }
            if (i != -1) {
                int i2 = i + 1;
                if (i2 < C0568e1.this.f4197f0.size()) {
                    dVar = C0568e1.this.f4197f0.get(i2);
                }
                C0568e1.this.f4195d0.postAtTime(new C0572a(dVar, menuItem, h1Var), h1Var, SystemClock.uptimeMillis() + 200);
            }
        }

        /* renamed from: b */
        public void mo4989b(C0816h1 h1Var, MenuItem menuItem) {
            C0568e1.this.f4195d0.removeCallbacksAndMessages(h1Var);
        }
    }

    /* renamed from: e1$d */
    public static class C0573d {

        /* renamed from: a */
        public final C1118k3 f4223a;

        /* renamed from: b */
        public final C0816h1 f4224b;

        /* renamed from: c */
        public final int f4225c;

        public C0573d(C1118k3 k3Var, C0816h1 h1Var, int i) {
            this.f4223a = k3Var;
            this.f4224b = h1Var;
            this.f4225c = i;
        }
    }

    public C0568e1(Context context, View view, int i, int i2, boolean z) {
        this.f4190Y = context;
        this.f4203l0 = view;
        this.f4192a0 = i;
        this.f4193b0 = i2;
        this.f4194c0 = z;
        this.f4210s0 = false;
        this.f4205n0 = C2189w7.m15018m(this.f4203l0) == 1 ? 0 : 1;
        Resources resources = context.getResources();
        this.f4191Z = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(C0729g.abc_config_prefDialogWidth));
        this.f4195d0 = new Handler();
    }

    /* renamed from: a */
    public void mo4969a(int i) {
        if (this.f4201j0 != i) {
            this.f4201j0 = i;
            this.f4202k0 = C0815h0.m5770a(i, C2189w7.m15018m(this.f4203l0));
        }
    }

    /* renamed from: a */
    public void mo4970a(View view) {
        if (this.f4203l0 != view) {
            this.f4203l0 = view;
            this.f4202k0 = C0815h0.m5770a(this.f4201j0, C2189w7.m15018m(this.f4203l0));
        }
    }

    /* renamed from: a */
    public void mo4971a(PopupWindow.OnDismissListener onDismissListener) {
        this.f4214w0 = onDismissListener;
    }

    /* renamed from: a */
    public void mo4972a(C0816h1 h1Var) {
        h1Var.mo6287a((C1581p1) this, this.f4190Y);
        if (mo4983r()) {
            mo4977c(h1Var);
        } else {
            this.f4196e0.add(h1Var);
        }
    }

    /* renamed from: a */
    public void mo130a(C0816h1 h1Var, boolean z) {
        int i;
        int size = this.f4197f0.size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                i2 = -1;
                break;
            } else if (h1Var == this.f4197f0.get(i2).f4224b) {
                break;
            } else {
                i2++;
            }
        }
        if (i2 >= 0) {
            int i3 = i2 + 1;
            if (i3 < this.f4197f0.size()) {
                this.f4197f0.get(i3).f4224b.mo6288a(false);
            }
            C0573d remove = this.f4197f0.remove(i2);
            remove.f4224b.mo6286a((C1581p1) this);
            if (this.f4215x0) {
                remove.f4223a.mo7853a((Object) null);
                remove.f4223a.f7115B0.setAnimationStyle(0);
            }
            remove.f4223a.dismiss();
            int size2 = this.f4197f0.size();
            if (size2 > 0) {
                i = this.f4197f0.get(size2 - 1).f4225c;
            } else {
                i = C2189w7.m15018m(this.f4203l0) == 1 ? 0 : 1;
            }
            this.f4205n0 = i;
            if (size2 == 0) {
                dismiss();
                C1581p1.C1582a aVar = this.f4212u0;
                if (aVar != null) {
                    aVar.mo55a(h1Var, true);
                }
                ViewTreeObserver viewTreeObserver = this.f4213v0;
                if (viewTreeObserver != null) {
                    if (viewTreeObserver.isAlive()) {
                        this.f4213v0.removeGlobalOnLayoutListener(this.f4198g0);
                    }
                    this.f4213v0 = null;
                }
                this.f4204m0.removeOnAttachStateChangeListener(this.f4199h0);
                this.f4214w0.onDismiss();
            } else if (z) {
                this.f4197f0.get(0).f4224b.mo6288a(false);
            }
        }
    }

    /* renamed from: a */
    public void mo2707a(C1581p1.C1582a aVar) {
        this.f4212u0 = aVar;
    }

    /* renamed from: a */
    public boolean mo132a() {
        return false;
    }

    /* renamed from: b */
    public void mo4973b(int i) {
        this.f4206o0 = true;
        this.f4208q0 = i;
    }

    /* renamed from: b */
    public void mo4974b(boolean z) {
        this.f4210s0 = z;
    }

    /* renamed from: b */
    public boolean mo4975b() {
        return false;
    }

    /* renamed from: c */
    public void mo4976c(int i) {
        this.f4207p0 = true;
        this.f4209r0 = i;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:54:0x0149, code lost:
        if (((r9.getWidth() + r11[0]) + r4) > r10.right) goto L_0x0153;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:56:0x014f, code lost:
        if ((r11[0] - r4) < 0) goto L_0x0151;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:58:0x0153, code lost:
        r9 = 0;
     */
    /* JADX WARNING: Removed duplicated region for block: B:101:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:39:0x00e9  */
    /* JADX WARNING: Removed duplicated region for block: B:78:0x01b9  */
    /* JADX WARNING: Removed duplicated region for block: B:91:0x01ed  */
    /* renamed from: c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo4977c(p000.C0816h1 r17) {
        /*
            r16 = this;
            r0 = r16
            r1 = r17
            android.content.Context r2 = r0.f4190Y
            android.view.LayoutInflater r2 = android.view.LayoutInflater.from(r2)
            g1 r3 = new g1
            boolean r4 = r0.f4194c0
            int r5 = f4189y0
            r3.<init>(r1, r2, r4, r5)
            boolean r4 = r16.mo4983r()
            r5 = 1
            if (r4 != 0) goto L_0x0021
            boolean r4 = r0.f4210s0
            if (r4 == 0) goto L_0x0021
            r3.f5856Z = r5
            goto L_0x002d
        L_0x0021:
            boolean r4 = r16.mo4983r()
            if (r4 == 0) goto L_0x002d
            boolean r4 = p000.C1301m1.m8957b((p000.C0816h1) r17)
            r3.f5856Z = r4
        L_0x002d:
            android.content.Context r4 = r0.f4190Y
            int r6 = r0.f4191Z
            r7 = 0
            int r4 = p000.C1301m1.m8956a(r3, r7, r4, r6)
            k3 r6 = new k3
            android.content.Context r8 = r0.f4190Y
            int r9 = r0.f4192a0
            int r10 = r0.f4193b0
            r6.<init>(r8, r7, r9, r10)
            j3 r8 = r0.f4200i0
            r6.f8850F0 = r8
            r6.f7136r0 = r0
            android.widget.PopupWindow r8 = r6.f7115B0
            r8.setOnDismissListener(r0)
            android.view.View r8 = r0.f4203l0
            r6.f7134p0 = r8
            int r8 = r0.f4202k0
            r6.f7127i0 = r8
            r6.mo6809a((boolean) r5)
            android.widget.PopupWindow r8 = r6.f7115B0
            r9 = 2
            r8.setInputMethodMode(r9)
            r6.mo6808a((android.widget.ListAdapter) r3)
            r6.mo6813d(r4)
            int r3 = r0.f4202k0
            r6.f7127i0 = r3
            java.util.List<e1$d> r3 = r0.f4197f0
            int r3 = r3.size()
            r8 = 0
            if (r3 <= 0) goto L_0x00e5
            java.util.List<e1$d> r3 = r0.f4197f0
            int r10 = r3.size()
            int r10 = r10 - r5
            java.lang.Object r3 = r3.get(r10)
            e1$d r3 = (p000.C0568e1.C0573d) r3
            h1 r10 = r3.f4224b
            int r11 = r10.size()
            r12 = 0
        L_0x0084:
            if (r12 >= r11) goto L_0x009a
            android.view.MenuItem r13 = r10.getItem(r12)
            boolean r14 = r13.hasSubMenu()
            if (r14 == 0) goto L_0x0097
            android.view.SubMenu r14 = r13.getSubMenu()
            if (r1 != r14) goto L_0x0097
            goto L_0x009b
        L_0x0097:
            int r12 = r12 + 1
            goto L_0x0084
        L_0x009a:
            r13 = r7
        L_0x009b:
            if (r13 != 0) goto L_0x009e
            goto L_0x00e7
        L_0x009e:
            k3 r10 = r3.f4223a
            c3 r10 = r10.f7118Z
            android.widget.ListAdapter r11 = r10.getAdapter()
            boolean r12 = r11 instanceof android.widget.HeaderViewListAdapter
            if (r12 == 0) goto L_0x00b7
            android.widget.HeaderViewListAdapter r11 = (android.widget.HeaderViewListAdapter) r11
            int r12 = r11.getHeadersCount()
            android.widget.ListAdapter r11 = r11.getWrappedAdapter()
            g1 r11 = (p000.C0732g1) r11
            goto L_0x00ba
        L_0x00b7:
            g1 r11 = (p000.C0732g1) r11
            r12 = 0
        L_0x00ba:
            int r14 = r11.getCount()
            r15 = 0
        L_0x00bf:
            r9 = -1
            if (r15 >= r14) goto L_0x00cd
            k1 r7 = r11.getItem((int) r15)
            if (r13 != r7) goto L_0x00c9
            goto L_0x00ce
        L_0x00c9:
            int r15 = r15 + 1
            r7 = 0
            goto L_0x00bf
        L_0x00cd:
            r15 = -1
        L_0x00ce:
            if (r15 != r9) goto L_0x00d1
            goto L_0x00e6
        L_0x00d1:
            int r15 = r15 + r12
            int r7 = r10.getFirstVisiblePosition()
            int r15 = r15 - r7
            if (r15 < 0) goto L_0x00e6
            int r7 = r10.getChildCount()
            if (r15 < r7) goto L_0x00e0
            goto L_0x00e6
        L_0x00e0:
            android.view.View r7 = r10.getChildAt(r15)
            goto L_0x00e7
        L_0x00e5:
            r3 = 0
        L_0x00e6:
            r7 = 0
        L_0x00e7:
            if (r7 == 0) goto L_0x01b9
            int r9 = android.os.Build.VERSION.SDK_INT
            r10 = 28
            if (r9 > r10) goto L_0x0109
            java.lang.reflect.Method r9 = p000.C1118k3.f8849G0
            if (r9 == 0) goto L_0x010e
            android.widget.PopupWindow r10 = r6.f7115B0     // Catch:{ Exception -> 0x0101 }
            java.lang.Object[] r11 = new java.lang.Object[r5]     // Catch:{ Exception -> 0x0101 }
            java.lang.Boolean r12 = java.lang.Boolean.valueOf(r8)     // Catch:{ Exception -> 0x0101 }
            r11[r8] = r12     // Catch:{ Exception -> 0x0101 }
            r9.invoke(r10, r11)     // Catch:{ Exception -> 0x0101 }
            goto L_0x010e
        L_0x0101:
            java.lang.String r9 = "MenuPopupWindow"
            java.lang.String r10 = "Could not invoke setTouchModal() on PopupWindow. Oh well."
            android.util.Log.i(r9, r10)
            goto L_0x010e
        L_0x0109:
            android.widget.PopupWindow r9 = r6.f7115B0
            r9.setTouchModal(r8)
        L_0x010e:
            int r9 = android.os.Build.VERSION.SDK_INT
            r10 = 23
            if (r9 < r10) goto L_0x011a
            android.widget.PopupWindow r9 = r6.f7115B0
            r10 = 0
            r9.setEnterTransition(r10)
        L_0x011a:
            java.util.List<e1$d> r9 = r0.f4197f0
            int r10 = r9.size()
            int r10 = r10 - r5
            java.lang.Object r9 = r9.get(r10)
            e1$d r9 = (p000.C0568e1.C0573d) r9
            k3 r9 = r9.f4223a
            c3 r9 = r9.f7118Z
            r10 = 2
            int[] r11 = new int[r10]
            r9.getLocationOnScreen(r11)
            android.graphics.Rect r10 = new android.graphics.Rect
            r10.<init>()
            android.view.View r12 = r0.f4204m0
            r12.getWindowVisibleDisplayFrame(r10)
            int r12 = r0.f4205n0
            if (r12 != r5) goto L_0x014c
            r11 = r11[r8]
            int r9 = r9.getWidth()
            int r9 = r9 + r11
            int r9 = r9 + r4
            int r10 = r10.right
            if (r9 <= r10) goto L_0x0151
            goto L_0x0153
        L_0x014c:
            r9 = r11[r8]
            int r9 = r9 - r4
            if (r9 >= 0) goto L_0x0153
        L_0x0151:
            r9 = 1
            goto L_0x0154
        L_0x0153:
            r9 = 0
        L_0x0154:
            if (r9 != r5) goto L_0x0158
            r10 = 1
            goto L_0x0159
        L_0x0158:
            r10 = 0
        L_0x0159:
            r0.f4205n0 = r9
            int r9 = android.os.Build.VERSION.SDK_INT
            r11 = 26
            r12 = 5
            if (r9 < r11) goto L_0x0167
            r6.f7134p0 = r7
            r9 = 0
            r13 = 0
            goto L_0x0198
        L_0x0167:
            r9 = 2
            int[] r11 = new int[r9]
            android.view.View r13 = r0.f4203l0
            r13.getLocationOnScreen(r11)
            int[] r9 = new int[r9]
            r7.getLocationOnScreen(r9)
            int r13 = r0.f4202k0
            r13 = r13 & 7
            if (r13 != r12) goto L_0x018e
            r13 = r11[r8]
            android.view.View r14 = r0.f4203l0
            int r14 = r14.getWidth()
            int r14 = r14 + r13
            r11[r8] = r14
            r13 = r9[r8]
            int r14 = r7.getWidth()
            int r14 = r14 + r13
            r9[r8] = r14
        L_0x018e:
            r13 = r9[r8]
            r14 = r11[r8]
            int r13 = r13 - r14
            r9 = r9[r5]
            r11 = r11[r5]
            int r9 = r9 - r11
        L_0x0198:
            int r11 = r0.f4202k0
            r11 = r11 & r12
            if (r11 != r12) goto L_0x01a6
            if (r10 == 0) goto L_0x01a1
            int r13 = r13 + r4
            goto L_0x01af
        L_0x01a1:
            int r4 = r7.getWidth()
            goto L_0x01ae
        L_0x01a6:
            if (r10 == 0) goto L_0x01ae
            int r4 = r7.getWidth()
            int r13 = r13 + r4
            goto L_0x01af
        L_0x01ae:
            int r13 = r13 - r4
        L_0x01af:
            r6.f7121c0 = r13
            r6.f7126h0 = r5
            r6.f7125g0 = r5
            r6.mo6805a((int) r9)
            goto L_0x01cf
        L_0x01b9:
            boolean r4 = r0.f4206o0
            if (r4 == 0) goto L_0x01c1
            int r4 = r0.f4208q0
            r6.f7121c0 = r4
        L_0x01c1:
            boolean r4 = r0.f4207p0
            if (r4 == 0) goto L_0x01ca
            int r4 = r0.f4209r0
            r6.mo6805a((int) r4)
        L_0x01ca:
            android.graphics.Rect r4 = r0.f9892X
            r6.mo6806a((android.graphics.Rect) r4)
        L_0x01cf:
            e1$d r4 = new e1$d
            int r5 = r0.f4205n0
            r4.<init>(r6, r1, r5)
            java.util.List<e1$d> r5 = r0.f4197f0
            r5.add(r4)
            r6.mo4982q()
            c3 r4 = r6.f7118Z
            r4.setOnKeyListener(r0)
            if (r3 != 0) goto L_0x020d
            boolean r3 = r0.f4211t0
            if (r3 == 0) goto L_0x020d
            java.lang.CharSequence r3 = r1.f6507n
            if (r3 == 0) goto L_0x020d
            int r3 = p000.C0978j.abc_popup_menu_header_item_layout
            android.view.View r2 = r2.inflate(r3, r4, r8)
            android.widget.FrameLayout r2 = (android.widget.FrameLayout) r2
            r3 = 16908310(0x1020016, float:2.387729E-38)
            android.view.View r3 = r2.findViewById(r3)
            android.widget.TextView r3 = (android.widget.TextView) r3
            r2.setEnabled(r8)
            java.lang.CharSequence r1 = r1.f6507n
            r3.setText(r1)
            r1 = 0
            r4.addHeaderView(r2, r1, r8)
            r6.mo4982q()
        L_0x020d:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0568e1.mo4977c(h1):void");
    }

    /* renamed from: c */
    public void mo4978c(boolean z) {
        this.f4211t0 = z;
    }

    public void dismiss() {
        int size = this.f4197f0.size();
        if (size > 0) {
            C0573d[] dVarArr = (C0573d[]) this.f4197f0.toArray(new C0573d[size]);
            for (int i = size - 1; i >= 0; i--) {
                C0573d dVar = dVarArr[i];
                if (dVar.f4223a.mo4983r()) {
                    dVar.f4223a.dismiss();
                }
            }
        }
    }

    public void onDismiss() {
        C0573d dVar;
        int size = this.f4197f0.size();
        int i = 0;
        while (true) {
            if (i >= size) {
                dVar = null;
                break;
            }
            dVar = this.f4197f0.get(i);
            if (!dVar.f4223a.mo4983r()) {
                break;
            }
            i++;
        }
        if (dVar != null) {
            dVar.f4224b.mo6288a(false);
        }
    }

    public boolean onKey(View view, int i, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 1 || i != 82) {
            return false;
        }
        dismiss();
        return true;
    }

    /* renamed from: q */
    public void mo4982q() {
        if (!mo4983r()) {
            for (C0816h1 c : this.f4196e0) {
                mo4977c(c);
            }
            this.f4196e0.clear();
            this.f4204m0 = this.f4203l0;
            if (this.f4204m0 != null) {
                boolean z = this.f4213v0 == null;
                this.f4213v0 = this.f4204m0.getViewTreeObserver();
                if (z) {
                    this.f4213v0.addOnGlobalLayoutListener(this.f4198g0);
                }
                this.f4204m0.addOnAttachStateChangeListener(this.f4199h0);
            }
        }
    }

    /* renamed from: r */
    public boolean mo4983r() {
        return this.f4197f0.size() > 0 && this.f4197f0.get(0).f4223a.mo4983r();
    }

    /* renamed from: s */
    public ListView mo4984s() {
        if (this.f4197f0.isEmpty()) {
            return null;
        }
        List<C0573d> list = this.f4197f0;
        return list.get(list.size() - 1).f4223a.f7118Z;
    }

    /* renamed from: a */
    public boolean mo134a(C2081v1 v1Var) {
        for (C0573d next : this.f4197f0) {
            if (v1Var == next.f4224b) {
                next.f4223a.f7118Z.requestFocus();
                return true;
            }
        }
        if (!v1Var.hasVisibleItems()) {
            return false;
        }
        mo4972a((C0816h1) v1Var);
        C1581p1.C1582a aVar = this.f4212u0;
        if (aVar != null) {
            aVar.mo56a(v1Var);
        }
        return true;
    }

    /* renamed from: a */
    public void mo131a(boolean z) {
        for (C0573d dVar : this.f4197f0) {
            ListAdapter adapter = dVar.f4223a.f7118Z.getAdapter();
            if (adapter instanceof HeaderViewListAdapter) {
                adapter = ((HeaderViewListAdapter) adapter).getWrappedAdapter();
            }
            ((C0732g1) adapter).notifyDataSetChanged();
        }
    }
}
