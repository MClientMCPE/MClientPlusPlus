package p000;

import android.os.IInterface;

/* renamed from: cx */
public interface C0498cx extends IInterface {
}
