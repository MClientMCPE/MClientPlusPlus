package p000;

import android.os.IInterface;

/* renamed from: es */
public interface C0623es extends IInterface {
}
