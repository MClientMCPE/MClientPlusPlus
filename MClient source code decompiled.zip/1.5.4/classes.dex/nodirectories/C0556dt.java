package p000;

import android.content.Context;
import android.os.Looper;
import p000.lz1;
import p000.qz1;

/* renamed from: dt */
public final class C0556dt {

    /* renamed from: a */
    public final Context f4094a;

    /* renamed from: b */
    public final Looper f4095b;

    public C0556dt(Context context, Looper looper) {
        this.f4094a = context;
        this.f4095b = looper;
    }

    /* renamed from: a */
    public final void mo4914a(String str) {
        qz1.C1726b bVar = (qz1.C1726b) qz1.zzgsw.mo9631i();
        String packageName = this.f4094a.getPackageName();
        if (bVar.f11828Z) {
            bVar.mo9638h();
            bVar.f11828Z = false;
        }
        ((qz1) bVar.f11827Y).mo10457a(packageName);
        qz1.C1725a aVar = qz1.C1725a.BLOCKED_IMPRESSION;
        if (bVar.f11828Z) {
            bVar.mo9638h();
            bVar.f11828Z = false;
        }
        ((qz1) bVar.f11827Y).mo10459a(aVar);
        lz1.C1291b bVar2 = (lz1.C1291b) lz1.zzgsn.mo9631i();
        if (bVar2.f11828Z) {
            bVar2.mo9638h();
            bVar2.f11828Z = false;
        }
        ((lz1) bVar2.f11827Y).mo8519a(str);
        lz1.C1290a aVar2 = lz1.C1290a.BLOCKED_REASON_BACKGROUND;
        if (bVar2.f11828Z) {
            bVar2.mo9638h();
            bVar2.f11828Z = false;
        }
        ((lz1) bVar2.f11827Y).mo8520a(aVar2);
        if (bVar.f11828Z) {
            bVar.mo9638h();
            bVar.f11828Z = false;
        }
        ((qz1) bVar.f11827Y).mo10458a((lz1) bVar2.mo9639i());
        new C0719ft(this.f4094a, this.f4095b, (qz1) bVar.mo9639i()).mo5778b();
    }
}
