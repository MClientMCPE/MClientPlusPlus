package p000;

import android.os.AsyncTask;
import android.webkit.WebView;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/* renamed from: do */
public final class C0551do extends AsyncTask<Void, Void, String> {

    /* renamed from: a */
    public final /* synthetic */ C2462zn f4039a;

    public /* synthetic */ C0551do(C2462zn znVar, C2371yn ynVar) {
        this.f4039a = znVar;
    }

    public final /* synthetic */ Object doInBackground(Object[] objArr) {
        Void[] voidArr = (Void[]) objArr;
        try {
            this.f4039a.f18479e0 = this.f4039a.f18474Z.get(1000, TimeUnit.MILLISECONDS);
        } catch (InterruptedException | ExecutionException | TimeoutException e) {
            C0680fe.m4844d("", e);
        }
        return this.f4039a.mo13338m1();
    }

    public final /* synthetic */ void onPostExecute(Object obj) {
        String str = (String) obj;
        WebView webView = this.f4039a.f18477c0;
        if (webView != null && str != null) {
            webView.loadUrl(str);
        }
    }
}
