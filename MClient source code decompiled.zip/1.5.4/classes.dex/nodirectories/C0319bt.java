package p000;

import android.content.Context;
import java.util.concurrent.Callable;

/* renamed from: bt */
public final /* synthetic */ class C0319bt implements Callable {

    /* renamed from: a */
    public final Context f2331a;

    public C0319bt(Context context) {
        this.f2331a = context;
    }

    public final Object call() {
        return new gu2(this.f2331a, "GLAS");
    }
}
