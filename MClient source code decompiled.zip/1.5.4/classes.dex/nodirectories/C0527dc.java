package p000;

import android.os.Bundle;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* renamed from: dc */
public class C0527dc extends C0367cc {

    /* renamed from: a */
    public final C1509ob f3792a;

    /* renamed from: b */
    public final C0529b f3793b;

    /* renamed from: dc$a */
    public static class C0528a<D> extends C1910tb<D> implements C0598ec<D> {

        /* renamed from: j */
        public final int f3794j;

        /* renamed from: k */
        public final Bundle f3795k;

        /* renamed from: l */
        public C1509ob f3796l;

        /* renamed from: a */
        public void mo1478a() {
            throw null;
        }

        /* renamed from: a */
        public void mo1480a(D d) {
            super.mo1480a(d);
        }

        /* renamed from: a */
        public void mo1481a(C2006ub<? super D> ubVar) {
            super.mo1481a(ubVar);
            this.f3796l = null;
        }

        /* renamed from: a */
        public Object<D> mo4720a(boolean z) {
            throw null;
        }

        /* renamed from: b */
        public void mo1482b() {
            throw null;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder(64);
            sb.append("LoaderInfo{");
            sb.append(Integer.toHexString(System.identityHashCode(this)));
            sb.append(" #");
            sb.append(this.f3794j);
            sb.append(" : ");
            C0815h0.m5819a((Object) null, sb);
            sb.append("}}");
            return sb.toString();
        }
    }

    /* renamed from: dc$b */
    public static class C0529b extends C2265xb {

        /* renamed from: c */
        public static final C2338yb f3797c = new C0530a();

        /* renamed from: b */
        public C0829h5<C0528a> f3798b = new C0829h5<>(10);

        /* renamed from: dc$b$a */
        public static class C0530a implements C2338yb {
            /* renamed from: a */
            public <T extends C2265xb> T mo4725a(Class<T> cls) {
                return new C0529b();
            }
        }

        /* renamed from: a */
        public void mo4722a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
            if (this.f3798b.mo6418b() > 0) {
                printWriter.print(str);
                printWriter.println("Loaders:");
                String str2 = str + "    ";
                if (this.f3798b.mo6418b() > 0) {
                    C0528a d = this.f3798b.mo6424d(0);
                    printWriter.print(str);
                    printWriter.print("  #");
                    printWriter.print(this.f3798b.mo6419b(0));
                    printWriter.print(": ");
                    printWriter.println(d.toString());
                    printWriter.print(str2);
                    printWriter.print("mId=");
                    printWriter.print(d.f3794j);
                    printWriter.print(" mArgs=");
                    printWriter.println(d.f3795k);
                    printWriter.print(str2);
                    printWriter.print("mLoader=");
                    printWriter.println((Object) null);
                    str2 + "  ";
                    throw null;
                }
            }
        }

        /* renamed from: b */
        public void mo4723b() {
            if (this.f3798b.mo6418b() <= 0) {
                C0829h5<C0528a> h5Var = this.f3798b;
                int i = h5Var.f6611a0;
                Object[] objArr = h5Var.f6610Z;
                for (int i2 = 0; i2 < i; i2++) {
                    objArr[i2] = null;
                }
                h5Var.f6611a0 = 0;
                h5Var.f6608X = false;
                return;
            }
            this.f3798b.mo6424d(0).mo4720a(true);
            throw null;
        }

        /* renamed from: c */
        public void mo4724c() {
            int b = this.f3798b.mo6418b();
            for (int i = 0; i < b; i++) {
                C1509ob obVar = this.f3798b.mo6424d(i).f3796l;
            }
        }
    }

    public C0527dc(C1509ob obVar, C0091ac acVar) {
        this.f3792a = obVar;
        C2338yb ybVar = C0529b.f3797c;
        Class cls = C0529b.class;
        String canonicalName = cls.getCanonicalName();
        if (canonicalName != null) {
            String str = "androidx.lifecycle.ViewModelProvider.DefaultKey:" + canonicalName;
            C2265xb xbVar = acVar.f345a.get(str);
            if (!cls.isInstance(xbVar)) {
                xbVar = ybVar instanceof C2434zb ? ((C2434zb) ybVar).mo13121a(str, cls) : ybVar.mo4725a(cls);
                C2265xb put = acVar.f345a.put(str, xbVar);
                if (put != null) {
                    put.mo4723b();
                }
            }
            this.f3793b = (C0529b) xbVar;
            return;
        }
        throw new IllegalArgumentException("Local and anonymous classes can not be ViewModels");
    }

    @Deprecated
    /* renamed from: a */
    public void mo2889a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        this.f3793b.mo4722a(str, fileDescriptor, printWriter, strArr);
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(128);
        sb.append("LoaderManager{");
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append(" in ");
        C0815h0.m5819a((Object) this.f3792a, sb);
        sb.append("}}");
        return sb.toString();
    }
}
