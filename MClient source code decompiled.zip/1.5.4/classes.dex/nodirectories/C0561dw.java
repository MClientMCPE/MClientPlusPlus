package p000;

import android.os.IBinder;
import android.os.Parcel;
import java.util.ArrayList;
import java.util.List;

/* renamed from: dw */
public final class C0561dw extends rj2 implements C0325bw {
    public C0561dw(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.formats.client.INativeContentAd");
    }

    /* renamed from: F */
    public final String mo2671F() {
        Parcel a = mo10676a(8, mo10675a());
        String readString = a.readString();
        a.recycle();
        return readString;
    }

    /* renamed from: J */
    public final C2232wr mo2672J() {
        return C0789gk.m5564a(mo10676a(2, mo10675a()));
    }

    /* JADX WARNING: type inference failed for: r2v1, types: [android.os.IInterface] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* renamed from: T */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final p000.C1274lv mo2673T() {
        /*
            r4 = this;
            android.os.Parcel r0 = r4.mo10675a()
            r1 = 6
            android.os.Parcel r0 = r4.mo10676a(r1, r0)
            android.os.IBinder r1 = r0.readStrongBinder()
            if (r1 != 0) goto L_0x0011
            r1 = 0
            goto L_0x0025
        L_0x0011:
            java.lang.String r2 = "com.google.android.gms.ads.internal.formats.client.INativeAdImage"
            android.os.IInterface r2 = r1.queryLocalInterface(r2)
            boolean r3 = r2 instanceof p000.C1274lv
            if (r3 == 0) goto L_0x001f
            r1 = r2
            lv r1 = (p000.C1274lv) r1
            goto L_0x0025
        L_0x001f:
            nv r2 = new nv
            r2.<init>(r1)
            r1 = r2
        L_0x0025:
            r0.recycle()
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0561dw.mo2673T():lv");
    }

    public final cy2 getVideoController() {
        Parcel a = mo10676a(11, mo10675a());
        cy2 a2 = ey2.m4340a(a.readStrongBinder());
        a.recycle();
        return a2;
    }

    /* renamed from: t */
    public final String mo2675t() {
        Parcel a = mo10676a(3, mo10675a());
        String readString = a.readString();
        a.recycle();
        return readString;
    }

    /* renamed from: u */
    public final String mo2676u() {
        Parcel a = mo10676a(5, mo10675a());
        String readString = a.readString();
        a.recycle();
        return readString;
    }

    /* renamed from: v */
    public final String mo2677v() {
        Parcel a = mo10676a(7, mo10675a());
        String readString = a.readString();
        a.recycle();
        return readString;
    }

    /* JADX WARNING: type inference failed for: r2v1, types: [android.os.IInterface] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* renamed from: w */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final p000.C0724fv mo2678w() {
        /*
            r4 = this;
            android.os.Parcel r0 = r4.mo10675a()
            r1 = 15
            android.os.Parcel r0 = r4.mo10676a(r1, r0)
            android.os.IBinder r1 = r0.readStrongBinder()
            if (r1 != 0) goto L_0x0012
            r1 = 0
            goto L_0x0026
        L_0x0012:
            java.lang.String r2 = "com.google.android.gms.ads.internal.formats.client.IAttributionInfo"
            android.os.IInterface r2 = r1.queryLocalInterface(r2)
            boolean r3 = r2 instanceof p000.C0724fv
            if (r3 == 0) goto L_0x0020
            r1 = r2
            fv r1 = (p000.C0724fv) r1
            goto L_0x0026
        L_0x0020:
            hv r2 = new hv
            r2.<init>(r1)
            r1 = r2
        L_0x0026:
            r0.recycle()
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0561dw.mo2678w():fv");
    }

    /* renamed from: x */
    public final List mo2679x() {
        Parcel a = mo10676a(4, mo10675a());
        ArrayList b = sj2.m12852b(a);
        a.recycle();
        return b;
    }
}
