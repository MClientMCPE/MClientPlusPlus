package p000;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.VectorDrawable;
import android.os.Build;
import android.util.AttributeSet;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;

/* renamed from: af */
public class C0095af extends C2438ze {

    /* renamed from: g0 */
    public static final PorterDuff.Mode f372g0 = PorterDuff.Mode.SRC_IN;

    /* renamed from: Y */
    public C0103h f373Y;

    /* renamed from: Z */
    public PorterDuffColorFilter f374Z;

    /* renamed from: a0 */
    public ColorFilter f375a0;

    /* renamed from: b0 */
    public boolean f376b0;

    /* renamed from: c0 */
    public boolean f377c0;

    /* renamed from: d0 */
    public final float[] f378d0;

    /* renamed from: e0 */
    public final Matrix f379e0;

    /* renamed from: f0 */
    public final Rect f380f0;

    /* renamed from: af$b */
    public static class C0097b extends C0101f {
        public C0097b() {
        }

        public C0097b(C0097b bVar) {
            super(bVar);
        }

        /* renamed from: a */
        public void mo441a(Resources resources, AttributeSet attributeSet, Resources.Theme theme, XmlPullParser xmlPullParser) {
            if (C0815h0.m5827a(xmlPullParser, "pathData")) {
                TypedArray a = C0815h0.m5783a(resources, theme, attributeSet, C1916te.f14845d);
                String string = a.getString(0);
                if (string != null) {
                    this.f407b = string;
                }
                String string2 = a.getString(1);
                if (string2 != null) {
                    this.f406a = C0815h0.m5831a(string2);
                }
                this.f408c = C0815h0.m5835b(a, xmlPullParser, "fillType", 2, 0);
                a.recycle();
            }
        }

        /* renamed from: b */
        public boolean mo442b() {
            return true;
        }
    }

    /* renamed from: af$c */
    public static class C0098c extends C0101f {

        /* renamed from: e */
        public int[] f381e;

        /* renamed from: f */
        public C2181w5 f382f;

        /* renamed from: g */
        public float f383g = 0.0f;

        /* renamed from: h */
        public C2181w5 f384h;

        /* renamed from: i */
        public float f385i = 1.0f;

        /* renamed from: j */
        public float f386j = 1.0f;

        /* renamed from: k */
        public float f387k = 0.0f;

        /* renamed from: l */
        public float f388l = 1.0f;

        /* renamed from: m */
        public float f389m = 0.0f;

        /* renamed from: n */
        public Paint.Cap f390n = Paint.Cap.BUTT;

        /* renamed from: o */
        public Paint.Join f391o = Paint.Join.MITER;

        /* renamed from: p */
        public float f392p = 4.0f;

        public C0098c() {
        }

        public C0098c(C0098c cVar) {
            super(cVar);
            this.f381e = cVar.f381e;
            this.f382f = cVar.f382f;
            this.f383g = cVar.f383g;
            this.f385i = cVar.f385i;
            this.f384h = cVar.f384h;
            this.f408c = cVar.f408c;
            this.f386j = cVar.f386j;
            this.f387k = cVar.f387k;
            this.f388l = cVar.f388l;
            this.f389m = cVar.f389m;
            this.f390n = cVar.f390n;
            this.f391o = cVar.f391o;
            this.f392p = cVar.f392p;
        }

        /* renamed from: a */
        public void mo443a(Resources resources, AttributeSet attributeSet, Resources.Theme theme, XmlPullParser xmlPullParser) {
            TypedArray a = C0815h0.m5783a(resources, theme, attributeSet, C1916te.f14844c);
            this.f381e = null;
            if (C0815h0.m5827a(xmlPullParser, "pathData")) {
                String string = a.getString(0);
                if (string != null) {
                    this.f407b = string;
                }
                String string2 = a.getString(2);
                if (string2 != null) {
                    this.f406a = C0815h0.m5831a(string2);
                }
                this.f384h = C0815h0.m5795a(a, xmlPullParser, theme, "fillColor", 1, 0);
                this.f386j = C0815h0.m5768a(a, xmlPullParser, "fillAlpha", 12, this.f386j);
                int b = C0815h0.m5835b(a, xmlPullParser, "strokeLineCap", 8, -1);
                Paint.Cap cap = this.f390n;
                if (b == 0) {
                    cap = Paint.Cap.BUTT;
                } else if (b == 1) {
                    cap = Paint.Cap.ROUND;
                } else if (b == 2) {
                    cap = Paint.Cap.SQUARE;
                }
                this.f390n = cap;
                int b2 = C0815h0.m5835b(a, xmlPullParser, "strokeLineJoin", 9, -1);
                Paint.Join join = this.f391o;
                if (b2 == 0) {
                    join = Paint.Join.MITER;
                } else if (b2 == 1) {
                    join = Paint.Join.ROUND;
                } else if (b2 == 2) {
                    join = Paint.Join.BEVEL;
                }
                this.f391o = join;
                this.f392p = C0815h0.m5768a(a, xmlPullParser, "strokeMiterLimit", 10, this.f392p);
                this.f382f = C0815h0.m5795a(a, xmlPullParser, theme, "strokeColor", 3, 0);
                this.f385i = C0815h0.m5768a(a, xmlPullParser, "strokeAlpha", 11, this.f385i);
                this.f383g = C0815h0.m5768a(a, xmlPullParser, "strokeWidth", 4, this.f383g);
                this.f388l = C0815h0.m5768a(a, xmlPullParser, "trimPathEnd", 6, this.f388l);
                this.f389m = C0815h0.m5768a(a, xmlPullParser, "trimPathOffset", 7, this.f389m);
                this.f387k = C0815h0.m5768a(a, xmlPullParser, "trimPathStart", 5, this.f387k);
                this.f408c = C0815h0.m5835b(a, xmlPullParser, "fillType", 13, this.f408c);
            }
            a.recycle();
        }

        /* renamed from: a */
        public boolean mo444a() {
            return this.f384h.mo12110c() || this.f382f.mo12110c();
        }

        /* renamed from: a */
        public boolean mo445a(int[] iArr) {
            return this.f382f.mo12108a(iArr) | this.f384h.mo12108a(iArr);
        }

        public float getFillAlpha() {
            return this.f386j;
        }

        public int getFillColor() {
            return this.f384h.f16537c;
        }

        public float getStrokeAlpha() {
            return this.f385i;
        }

        public int getStrokeColor() {
            return this.f382f.f16537c;
        }

        public float getStrokeWidth() {
            return this.f383g;
        }

        public float getTrimPathEnd() {
            return this.f388l;
        }

        public float getTrimPathOffset() {
            return this.f389m;
        }

        public float getTrimPathStart() {
            return this.f387k;
        }

        public void setFillAlpha(float f) {
            this.f386j = f;
        }

        public void setFillColor(int i) {
            this.f384h.f16537c = i;
        }

        public void setStrokeAlpha(float f) {
            this.f385i = f;
        }

        public void setStrokeColor(int i) {
            this.f382f.f16537c = i;
        }

        public void setStrokeWidth(float f) {
            this.f383g = f;
        }

        public void setTrimPathEnd(float f) {
            this.f388l = f;
        }

        public void setTrimPathOffset(float f) {
            this.f389m = f;
        }

        public void setTrimPathStart(float f) {
            this.f387k = f;
        }
    }

    /* renamed from: af$d */
    public static class C0099d extends C0100e {

        /* renamed from: a */
        public final Matrix f393a = new Matrix();

        /* renamed from: b */
        public final ArrayList<C0100e> f394b = new ArrayList<>();

        /* renamed from: c */
        public float f395c = 0.0f;

        /* renamed from: d */
        public float f396d = 0.0f;

        /* renamed from: e */
        public float f397e = 0.0f;

        /* renamed from: f */
        public float f398f = 1.0f;

        /* renamed from: g */
        public float f399g = 1.0f;

        /* renamed from: h */
        public float f400h = 0.0f;

        /* renamed from: i */
        public float f401i = 0.0f;

        /* renamed from: j */
        public final Matrix f402j = new Matrix();

        /* renamed from: k */
        public int f403k;

        /* renamed from: l */
        public int[] f404l;

        /* renamed from: m */
        public String f405m = null;

        public C0099d() {
            super((C0096a) null);
        }

        public C0099d(C0099d dVar, C2399z4<String, Object> z4Var) {
            super((C0096a) null);
            C0101f fVar;
            this.f395c = dVar.f395c;
            this.f396d = dVar.f396d;
            this.f397e = dVar.f397e;
            this.f398f = dVar.f398f;
            this.f399g = dVar.f399g;
            this.f400h = dVar.f400h;
            this.f401i = dVar.f401i;
            this.f404l = dVar.f404l;
            this.f405m = dVar.f405m;
            this.f403k = dVar.f403k;
            String str = this.f405m;
            if (str != null) {
                z4Var.put(str, this);
            }
            this.f402j.set(dVar.f402j);
            ArrayList<C0100e> arrayList = dVar.f394b;
            for (int i = 0; i < arrayList.size(); i++) {
                C0100e eVar = arrayList.get(i);
                if (eVar instanceof C0099d) {
                    this.f394b.add(new C0099d((C0099d) eVar, z4Var));
                } else {
                    if (eVar instanceof C0098c) {
                        fVar = new C0098c((C0098c) eVar);
                    } else if (eVar instanceof C0097b) {
                        fVar = new C0097b((C0097b) eVar);
                    } else {
                        throw new IllegalStateException("Unknown object in the tree!");
                    }
                    this.f394b.add(fVar);
                    String str2 = fVar.f407b;
                    if (str2 != null) {
                        z4Var.put(str2, fVar);
                    }
                }
            }
        }

        /* renamed from: a */
        public void mo462a(Resources resources, AttributeSet attributeSet, Resources.Theme theme, XmlPullParser xmlPullParser) {
            TypedArray a = C0815h0.m5783a(resources, theme, attributeSet, C1916te.f14843b);
            this.f404l = null;
            this.f395c = C0815h0.m5768a(a, xmlPullParser, "rotation", 5, this.f395c);
            this.f396d = a.getFloat(1, this.f396d);
            this.f397e = a.getFloat(2, this.f397e);
            this.f398f = C0815h0.m5768a(a, xmlPullParser, "scaleX", 3, this.f398f);
            this.f399g = C0815h0.m5768a(a, xmlPullParser, "scaleY", 4, this.f399g);
            this.f400h = C0815h0.m5768a(a, xmlPullParser, "translateX", 6, this.f400h);
            this.f401i = C0815h0.m5768a(a, xmlPullParser, "translateY", 7, this.f401i);
            String string = a.getString(0);
            if (string != null) {
                this.f405m = string;
            }
            mo463b();
            a.recycle();
        }

        /* renamed from: a */
        public boolean mo444a() {
            for (int i = 0; i < this.f394b.size(); i++) {
                if (this.f394b.get(i).mo444a()) {
                    return true;
                }
            }
            return false;
        }

        /* renamed from: a */
        public boolean mo445a(int[] iArr) {
            boolean z = false;
            for (int i = 0; i < this.f394b.size(); i++) {
                z |= this.f394b.get(i).mo445a(iArr);
            }
            return z;
        }

        /* renamed from: b */
        public final void mo463b() {
            this.f402j.reset();
            this.f402j.postTranslate(-this.f396d, -this.f397e);
            this.f402j.postScale(this.f398f, this.f399g);
            this.f402j.postRotate(this.f395c, 0.0f, 0.0f);
            this.f402j.postTranslate(this.f400h + this.f396d, this.f401i + this.f397e);
        }

        public String getGroupName() {
            return this.f405m;
        }

        public Matrix getLocalMatrix() {
            return this.f402j;
        }

        public float getPivotX() {
            return this.f396d;
        }

        public float getPivotY() {
            return this.f397e;
        }

        public float getRotation() {
            return this.f395c;
        }

        public float getScaleX() {
            return this.f398f;
        }

        public float getScaleY() {
            return this.f399g;
        }

        public float getTranslateX() {
            return this.f400h;
        }

        public float getTranslateY() {
            return this.f401i;
        }

        public void setPivotX(float f) {
            if (f != this.f396d) {
                this.f396d = f;
                mo463b();
            }
        }

        public void setPivotY(float f) {
            if (f != this.f397e) {
                this.f397e = f;
                mo463b();
            }
        }

        public void setRotation(float f) {
            if (f != this.f395c) {
                this.f395c = f;
                mo463b();
            }
        }

        public void setScaleX(float f) {
            if (f != this.f398f) {
                this.f398f = f;
                mo463b();
            }
        }

        public void setScaleY(float f) {
            if (f != this.f399g) {
                this.f399g = f;
                mo463b();
            }
        }

        public void setTranslateX(float f) {
            if (f != this.f400h) {
                this.f400h = f;
                mo463b();
            }
        }

        public void setTranslateY(float f) {
            if (f != this.f401i) {
                this.f401i = f;
                mo463b();
            }
        }
    }

    /* renamed from: af$e */
    public static abstract class C0100e {
        public C0100e() {
        }

        public /* synthetic */ C0100e(C0096a aVar) {
        }

        /* renamed from: a */
        public boolean mo444a() {
            return false;
        }

        /* renamed from: a */
        public boolean mo445a(int[] iArr) {
            return false;
        }
    }

    /* renamed from: af$f */
    public static abstract class C0101f extends C0100e {

        /* renamed from: a */
        public C0664f6[] f406a = null;

        /* renamed from: b */
        public String f407b;

        /* renamed from: c */
        public int f408c = 0;

        /* renamed from: d */
        public int f409d;

        public C0101f() {
            super((C0096a) null);
        }

        public C0101f(C0101f fVar) {
            super((C0096a) null);
            this.f407b = fVar.f407b;
            this.f409d = fVar.f409d;
            this.f406a = C0815h0.m5832a(fVar.f406a);
        }

        /* renamed from: a */
        public void mo480a(Path path) {
            path.reset();
            C0664f6[] f6VarArr = this.f406a;
            if (f6VarArr != null) {
                C0664f6.m4508a(f6VarArr, path);
            }
        }

        /* renamed from: b */
        public boolean mo442b() {
            return false;
        }

        public C0664f6[] getPathData() {
            return this.f406a;
        }

        public String getPathName() {
            return this.f407b;
        }

        public void setPathData(C0664f6[] f6VarArr) {
            if (!C0815h0.m5828a(this.f406a, f6VarArr)) {
                this.f406a = C0815h0.m5832a(f6VarArr);
                return;
            }
            C0664f6[] f6VarArr2 = this.f406a;
            for (int i = 0; i < f6VarArr.length; i++) {
                f6VarArr2[i].f5061a = f6VarArr[i].f5061a;
                for (int i2 = 0; i2 < f6VarArr[i].f5062b.length; i2++) {
                    f6VarArr2[i].f5062b[i2] = f6VarArr[i].f5062b[i2];
                }
            }
        }
    }

    /* renamed from: af$g */
    public static class C0102g {

        /* renamed from: q */
        public static final Matrix f410q = new Matrix();

        /* renamed from: a */
        public final Path f411a;

        /* renamed from: b */
        public final Path f412b;

        /* renamed from: c */
        public final Matrix f413c;

        /* renamed from: d */
        public Paint f414d;

        /* renamed from: e */
        public Paint f415e;

        /* renamed from: f */
        public PathMeasure f416f;

        /* renamed from: g */
        public int f417g;

        /* renamed from: h */
        public final C0099d f418h;

        /* renamed from: i */
        public float f419i;

        /* renamed from: j */
        public float f420j;

        /* renamed from: k */
        public float f421k;

        /* renamed from: l */
        public float f422l;

        /* renamed from: m */
        public int f423m;

        /* renamed from: n */
        public String f424n;

        /* renamed from: o */
        public Boolean f425o;

        /* renamed from: p */
        public final C2399z4<String, Object> f426p;

        public C0102g() {
            this.f413c = new Matrix();
            this.f419i = 0.0f;
            this.f420j = 0.0f;
            this.f421k = 0.0f;
            this.f422l = 0.0f;
            this.f423m = 255;
            this.f424n = null;
            this.f425o = null;
            this.f426p = new C2399z4<>();
            this.f418h = new C0099d();
            this.f411a = new Path();
            this.f412b = new Path();
        }

        public C0102g(C0102g gVar) {
            this.f413c = new Matrix();
            this.f419i = 0.0f;
            this.f420j = 0.0f;
            this.f421k = 0.0f;
            this.f422l = 0.0f;
            this.f423m = 255;
            this.f424n = null;
            this.f425o = null;
            this.f426p = new C2399z4<>();
            this.f418h = new C0099d(gVar.f418h, this.f426p);
            this.f411a = new Path(gVar.f411a);
            this.f412b = new Path(gVar.f412b);
            this.f419i = gVar.f419i;
            this.f420j = gVar.f420j;
            this.f421k = gVar.f421k;
            this.f422l = gVar.f422l;
            this.f417g = gVar.f417g;
            this.f423m = gVar.f423m;
            this.f424n = gVar.f424n;
            String str = gVar.f424n;
            if (str != null) {
                this.f426p.put(str, this);
            }
            this.f425o = gVar.f425o;
        }

        /* JADX WARNING: type inference failed for: r11v0 */
        /* JADX WARNING: type inference failed for: r11v1, types: [boolean] */
        /* JADX WARNING: type inference failed for: r11v2 */
        /* renamed from: a */
        public final void mo484a(C0099d dVar, Matrix matrix, Canvas canvas, int i, int i2, ColorFilter colorFilter) {
            C0102g gVar;
            C0102g gVar2 = this;
            C0099d dVar2 = dVar;
            Canvas canvas2 = canvas;
            ColorFilter colorFilter2 = colorFilter;
            dVar2.f393a.set(matrix);
            dVar2.f393a.preConcat(dVar2.f402j);
            canvas.save();
            ? r11 = 0;
            int i3 = 0;
            while (i3 < dVar2.f394b.size()) {
                C0100e eVar = dVar2.f394b.get(i3);
                if (eVar instanceof C0099d) {
                    mo484a((C0099d) eVar, dVar2.f393a, canvas, i, i2, colorFilter);
                } else if (eVar instanceof C0101f) {
                    C0101f fVar = (C0101f) eVar;
                    float f = ((float) i) / gVar2.f421k;
                    float f2 = ((float) i2) / gVar2.f422l;
                    float min = Math.min(f, f2);
                    Matrix matrix2 = dVar2.f393a;
                    gVar2.f413c.set(matrix2);
                    gVar2.f413c.postScale(f, f2);
                    float[] fArr = {0.0f, 1.0f, 1.0f, 0.0f};
                    matrix2.mapVectors(fArr);
                    float f3 = min;
                    float f4 = (fArr[r11] * fArr[3]) - (fArr[1] * fArr[2]);
                    float max = Math.max((float) Math.hypot((double) fArr[r11], (double) fArr[1]), (float) Math.hypot((double) fArr[2], (double) fArr[3]));
                    float abs = max > 0.0f ? Math.abs(f4) / max : 0.0f;
                    if (abs == 0.0f) {
                        gVar = this;
                    } else {
                        gVar = this;
                        fVar.mo480a(gVar.f411a);
                        Path path = gVar.f411a;
                        gVar.f412b.reset();
                        if (fVar.mo442b()) {
                            gVar.f412b.setFillType(fVar.f408c == 0 ? Path.FillType.WINDING : Path.FillType.EVEN_ODD);
                            gVar.f412b.addPath(path, gVar.f413c);
                            canvas2.clipPath(gVar.f412b);
                        } else {
                            C0098c cVar = (C0098c) fVar;
                            if (!(cVar.f387k == 0.0f && cVar.f388l == 1.0f)) {
                                float f5 = cVar.f387k;
                                float f6 = cVar.f389m;
                                float f7 = (f5 + f6) % 1.0f;
                                float f8 = (cVar.f388l + f6) % 1.0f;
                                if (gVar.f416f == null) {
                                    gVar.f416f = new PathMeasure();
                                }
                                gVar.f416f.setPath(gVar.f411a, r11);
                                float length = gVar.f416f.getLength();
                                float f9 = f7 * length;
                                float f10 = f8 * length;
                                path.reset();
                                if (f9 > f10) {
                                    gVar.f416f.getSegment(f9, length, path, true);
                                    gVar.f416f.getSegment(0.0f, f10, path, true);
                                } else {
                                    gVar.f416f.getSegment(f9, f10, path, true);
                                }
                                path.rLineTo(0.0f, 0.0f);
                            }
                            gVar.f412b.addPath(path, gVar.f413c);
                            if (cVar.f384h.mo12111d()) {
                                C2181w5 w5Var = cVar.f384h;
                                if (gVar.f415e == null) {
                                    gVar.f415e = new Paint(1);
                                    gVar.f415e.setStyle(Paint.Style.FILL);
                                }
                                Paint paint = gVar.f415e;
                                if (w5Var.mo12109b()) {
                                    Shader a = w5Var.mo12107a();
                                    a.setLocalMatrix(gVar.f413c);
                                    paint.setShader(a);
                                    paint.setAlpha(Math.round(cVar.f386j * 255.0f));
                                } else {
                                    paint.setShader((Shader) null);
                                    paint.setAlpha(255);
                                    paint.setColor(C0095af.m437a(w5Var.f16537c, cVar.f386j));
                                }
                                paint.setColorFilter(colorFilter2);
                                gVar.f412b.setFillType(cVar.f408c == 0 ? Path.FillType.WINDING : Path.FillType.EVEN_ODD);
                                canvas2.drawPath(gVar.f412b, paint);
                            }
                            if (cVar.f382f.mo12111d()) {
                                C2181w5 w5Var2 = cVar.f382f;
                                if (gVar.f414d == null) {
                                    gVar.f414d = new Paint(1);
                                    gVar.f414d.setStyle(Paint.Style.STROKE);
                                }
                                Paint paint2 = gVar.f414d;
                                Paint.Join join = cVar.f391o;
                                if (join != null) {
                                    paint2.setStrokeJoin(join);
                                }
                                Paint.Cap cap = cVar.f390n;
                                if (cap != null) {
                                    paint2.setStrokeCap(cap);
                                }
                                paint2.setStrokeMiter(cVar.f392p);
                                if (w5Var2.mo12109b()) {
                                    Shader a2 = w5Var2.mo12107a();
                                    a2.setLocalMatrix(gVar.f413c);
                                    paint2.setShader(a2);
                                    paint2.setAlpha(Math.round(cVar.f385i * 255.0f));
                                } else {
                                    paint2.setShader((Shader) null);
                                    paint2.setAlpha(255);
                                    paint2.setColor(C0095af.m437a(w5Var2.f16537c, cVar.f385i));
                                }
                                paint2.setColorFilter(colorFilter2);
                                paint2.setStrokeWidth(cVar.f383g * abs * f3);
                                canvas2.drawPath(gVar.f412b, paint2);
                            }
                        }
                    }
                    i3++;
                    gVar2 = gVar;
                    r11 = 0;
                }
                int i4 = i;
                int i5 = i2;
                gVar = gVar2;
                i3++;
                gVar2 = gVar;
                r11 = 0;
            }
            C0102g gVar3 = gVar2;
            canvas.restore();
        }

        /* renamed from: a */
        public void mo485a(Canvas canvas, int i, int i2, ColorFilter colorFilter) {
            mo484a(this.f418h, f410q, canvas, i, i2, colorFilter);
        }

        /* renamed from: a */
        public boolean mo486a() {
            if (this.f425o == null) {
                this.f425o = Boolean.valueOf(this.f418h.mo444a());
            }
            return this.f425o.booleanValue();
        }

        /* renamed from: a */
        public boolean mo487a(int[] iArr) {
            return this.f418h.mo445a(iArr);
        }

        public float getAlpha() {
            return ((float) getRootAlpha()) / 255.0f;
        }

        public int getRootAlpha() {
            return this.f423m;
        }

        public void setAlpha(float f) {
            setRootAlpha((int) (f * 255.0f));
        }

        public void setRootAlpha(int i) {
            this.f423m = i;
        }
    }

    /* renamed from: af$h */
    public static class C0103h extends Drawable.ConstantState {

        /* renamed from: a */
        public int f427a;

        /* renamed from: b */
        public C0102g f428b;

        /* renamed from: c */
        public ColorStateList f429c;

        /* renamed from: d */
        public PorterDuff.Mode f430d;

        /* renamed from: e */
        public boolean f431e;

        /* renamed from: f */
        public Bitmap f432f;

        /* renamed from: g */
        public ColorStateList f433g;

        /* renamed from: h */
        public PorterDuff.Mode f434h;

        /* renamed from: i */
        public int f435i;

        /* renamed from: j */
        public boolean f436j;

        /* renamed from: k */
        public boolean f437k;

        /* renamed from: l */
        public Paint f438l;

        public C0103h() {
            this.f429c = null;
            this.f430d = C0095af.f372g0;
            this.f428b = new C0102g();
        }

        public C0103h(C0103h hVar) {
            this.f429c = null;
            this.f430d = C0095af.f372g0;
            if (hVar != null) {
                this.f427a = hVar.f427a;
                this.f428b = new C0102g(hVar.f428b);
                Paint paint = hVar.f428b.f415e;
                if (paint != null) {
                    this.f428b.f415e = new Paint(paint);
                }
                Paint paint2 = hVar.f428b.f414d;
                if (paint2 != null) {
                    this.f428b.f414d = new Paint(paint2);
                }
                this.f429c = hVar.f429c;
                this.f430d = hVar.f430d;
                this.f431e = hVar.f431e;
            }
        }

        /* renamed from: a */
        public Paint mo492a(ColorFilter colorFilter) {
            if (!mo498b() && colorFilter == null) {
                return null;
            }
            if (this.f438l == null) {
                this.f438l = new Paint();
                this.f438l.setFilterBitmap(true);
            }
            this.f438l.setAlpha(this.f428b.getRootAlpha());
            this.f438l.setColorFilter(colorFilter);
            return this.f438l;
        }

        /* renamed from: a */
        public void mo493a(Canvas canvas, ColorFilter colorFilter, Rect rect) {
            canvas.drawBitmap(this.f432f, (Rect) null, rect, mo492a(colorFilter));
        }

        /* renamed from: a */
        public boolean mo494a() {
            return !this.f437k && this.f433g == this.f429c && this.f434h == this.f430d && this.f436j == this.f431e && this.f435i == this.f428b.getRootAlpha();
        }

        /* renamed from: a */
        public boolean mo495a(int i, int i2) {
            return i == this.f432f.getWidth() && i2 == this.f432f.getHeight();
        }

        /* renamed from: a */
        public boolean mo496a(int[] iArr) {
            boolean a = this.f428b.mo487a(iArr);
            this.f437k |= a;
            return a;
        }

        /* renamed from: b */
        public void mo497b(int i, int i2) {
            if (this.f432f == null || !mo495a(i, i2)) {
                this.f432f = Bitmap.createBitmap(i, i2, Bitmap.Config.ARGB_8888);
                this.f437k = true;
            }
        }

        /* renamed from: b */
        public boolean mo498b() {
            return this.f428b.getRootAlpha() < 255;
        }

        /* renamed from: c */
        public void mo499c(int i, int i2) {
            this.f432f.eraseColor(0);
            this.f428b.mo485a(new Canvas(this.f432f), i, i2, (ColorFilter) null);
        }

        /* renamed from: c */
        public boolean mo500c() {
            return this.f428b.mo486a();
        }

        /* renamed from: d */
        public void mo501d() {
            this.f433g = this.f429c;
            this.f434h = this.f430d;
            this.f435i = this.f428b.getRootAlpha();
            this.f436j = this.f431e;
            this.f437k = false;
        }

        public int getChangingConfigurations() {
            return this.f427a;
        }

        public Drawable newDrawable() {
            return new C0095af(this);
        }

        public Drawable newDrawable(Resources resources) {
            return new C0095af(this);
        }
    }

    /* renamed from: af$i */
    public static class C0104i extends Drawable.ConstantState {

        /* renamed from: a */
        public final Drawable.ConstantState f439a;

        public C0104i(Drawable.ConstantState constantState) {
            this.f439a = constantState;
        }

        public boolean canApplyTheme() {
            return this.f439a.canApplyTheme();
        }

        public int getChangingConfigurations() {
            return this.f439a.getChangingConfigurations();
        }

        public Drawable newDrawable() {
            C0095af afVar = new C0095af();
            afVar.f18302X = (VectorDrawable) this.f439a.newDrawable();
            return afVar;
        }

        public Drawable newDrawable(Resources resources) {
            C0095af afVar = new C0095af();
            afVar.f18302X = (VectorDrawable) this.f439a.newDrawable(resources);
            return afVar;
        }

        public Drawable newDrawable(Resources resources, Resources.Theme theme) {
            C0095af afVar = new C0095af();
            afVar.f18302X = (VectorDrawable) this.f439a.newDrawable(resources, theme);
            return afVar;
        }
    }

    public C0095af() {
        this.f377c0 = true;
        this.f378d0 = new float[9];
        this.f379e0 = new Matrix();
        this.f380f0 = new Rect();
        this.f373Y = new C0103h();
    }

    public C0095af(C0103h hVar) {
        this.f377c0 = true;
        this.f378d0 = new float[9];
        this.f379e0 = new Matrix();
        this.f380f0 = new Rect();
        this.f373Y = hVar;
        this.f374Z = mo414a(hVar.f429c, hVar.f430d);
    }

    /* renamed from: a */
    public static int m437a(int i, float f) {
        return (i & 16777215) | (((int) (((float) Color.alpha(i)) * f)) << 24);
    }

    /* JADX WARNING: Removed duplicated region for block: B:16:0x003d A[Catch:{ IOException | XmlPullParserException -> 0x004a }] */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x0042 A[Catch:{ IOException | XmlPullParserException -> 0x004a }] */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static p000.C0095af m438a(android.content.res.Resources r4, int r5, android.content.res.Resources.Theme r6) {
        /*
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 24
            if (r0 < r1) goto L_0x0028
            af r0 = new af
            r0.<init>()
            int r1 = android.os.Build.VERSION.SDK_INT
            r2 = 21
            if (r1 < r2) goto L_0x0016
            android.graphics.drawable.Drawable r4 = r4.getDrawable(r5, r6)
            goto L_0x001a
        L_0x0016:
            android.graphics.drawable.Drawable r4 = r4.getDrawable(r5)
        L_0x001a:
            r0.f18302X = r4
            af$i r4 = new af$i
            android.graphics.drawable.Drawable r5 = r0.f18302X
            android.graphics.drawable.Drawable$ConstantState r5 = r5.getConstantState()
            r4.<init>(r5)
            return r0
        L_0x0028:
            android.content.res.XmlResourceParser r5 = r4.getXml(r5)     // Catch:{ XmlPullParserException -> 0x004c, IOException -> 0x004a }
            android.util.AttributeSet r0 = android.util.Xml.asAttributeSet(r5)     // Catch:{ XmlPullParserException -> 0x004c, IOException -> 0x004a }
        L_0x0030:
            int r1 = r5.next()     // Catch:{ XmlPullParserException -> 0x004c, IOException -> 0x004a }
            r2 = 2
            if (r1 == r2) goto L_0x003b
            r3 = 1
            if (r1 == r3) goto L_0x003b
            goto L_0x0030
        L_0x003b:
            if (r1 != r2) goto L_0x0042
            af r4 = createFromXmlInner(r4, r5, r0, r6)     // Catch:{ XmlPullParserException -> 0x004c, IOException -> 0x004a }
            return r4
        L_0x0042:
            org.xmlpull.v1.XmlPullParserException r4 = new org.xmlpull.v1.XmlPullParserException     // Catch:{ XmlPullParserException -> 0x004c, IOException -> 0x004a }
            java.lang.String r5 = "No start tag found"
            r4.<init>(r5)     // Catch:{ XmlPullParserException -> 0x004c, IOException -> 0x004a }
            throw r4     // Catch:{ XmlPullParserException -> 0x004c, IOException -> 0x004a }
        L_0x004a:
            r4 = move-exception
            goto L_0x004d
        L_0x004c:
            r4 = move-exception
        L_0x004d:
            java.lang.String r5 = "parser error"
            java.lang.String r6 = "VectorDrawableCompat"
            android.util.Log.e(r6, r5, r4)
            r4 = 0
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0095af.m438a(android.content.res.Resources, int, android.content.res.Resources$Theme):af");
    }

    public static C0095af createFromXmlInner(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
        C0095af afVar = new C0095af();
        afVar.inflate(resources, xmlPullParser, attributeSet, theme);
        return afVar;
    }

    /* renamed from: a */
    public PorterDuffColorFilter mo414a(ColorStateList colorStateList, PorterDuff.Mode mode) {
        if (colorStateList == null || mode == null) {
            return null;
        }
        return new PorterDuffColorFilter(colorStateList.getColorForState(getState(), 0), mode);
    }

    public boolean canApplyTheme() {
        Drawable drawable = this.f18302X;
        if (drawable == null || Build.VERSION.SDK_INT < 21) {
            return false;
        }
        drawable.canApplyTheme();
        return false;
    }

    public void draw(Canvas canvas) {
        Drawable drawable = this.f18302X;
        if (drawable != null) {
            drawable.draw(canvas);
            return;
        }
        copyBounds(this.f380f0);
        if (this.f380f0.width() > 0 && this.f380f0.height() > 0) {
            ColorFilter colorFilter = this.f375a0;
            if (colorFilter == null) {
                colorFilter = this.f374Z;
            }
            canvas.getMatrix(this.f379e0);
            this.f379e0.getValues(this.f378d0);
            float abs = Math.abs(this.f378d0[0]);
            float abs2 = Math.abs(this.f378d0[4]);
            boolean z = true;
            float abs3 = Math.abs(this.f378d0[1]);
            float abs4 = Math.abs(this.f378d0[3]);
            if (!(abs3 == 0.0f && abs4 == 0.0f)) {
                abs = 1.0f;
                abs2 = 1.0f;
            }
            int min = Math.min(2048, (int) (((float) this.f380f0.width()) * abs));
            int min2 = Math.min(2048, (int) (((float) this.f380f0.height()) * abs2));
            if (min > 0 && min2 > 0) {
                int save = canvas.save();
                Rect rect = this.f380f0;
                canvas.translate((float) rect.left, (float) rect.top);
                int i = Build.VERSION.SDK_INT;
                if (!isAutoMirrored() || C0815h0.m5836b((Drawable) this) != 1) {
                    z = false;
                }
                if (z) {
                    canvas.translate((float) this.f380f0.width(), 0.0f);
                    canvas.scale(-1.0f, 1.0f);
                }
                this.f380f0.offsetTo(0, 0);
                this.f373Y.mo497b(min, min2);
                if (!this.f377c0) {
                    this.f373Y.mo499c(min, min2);
                } else if (!this.f373Y.mo494a()) {
                    this.f373Y.mo499c(min, min2);
                    this.f373Y.mo501d();
                }
                this.f373Y.mo493a(canvas, colorFilter, this.f380f0);
                canvas.restoreToCount(save);
            }
        }
    }

    public int getAlpha() {
        Drawable drawable = this.f18302X;
        if (drawable == null) {
            return this.f373Y.f428b.getRootAlpha();
        }
        int i = Build.VERSION.SDK_INT;
        return drawable.getAlpha();
    }

    public int getChangingConfigurations() {
        Drawable drawable = this.f18302X;
        return drawable != null ? drawable.getChangingConfigurations() : super.getChangingConfigurations() | this.f373Y.getChangingConfigurations();
    }

    public ColorFilter getColorFilter() {
        Drawable drawable = this.f18302X;
        if (drawable == null) {
            return this.f375a0;
        }
        if (Build.VERSION.SDK_INT >= 21) {
            return drawable.getColorFilter();
        }
        return null;
    }

    public Drawable.ConstantState getConstantState() {
        Drawable drawable = this.f18302X;
        if (drawable != null && Build.VERSION.SDK_INT >= 24) {
            return new C0104i(drawable.getConstantState());
        }
        this.f373Y.f427a = getChangingConfigurations();
        return this.f373Y;
    }

    public int getIntrinsicHeight() {
        Drawable drawable = this.f18302X;
        return drawable != null ? drawable.getIntrinsicHeight() : (int) this.f373Y.f428b.f420j;
    }

    public int getIntrinsicWidth() {
        Drawable drawable = this.f18302X;
        return drawable != null ? drawable.getIntrinsicWidth() : (int) this.f373Y.f428b.f419i;
    }

    public int getOpacity() {
        Drawable drawable = this.f18302X;
        if (drawable != null) {
            return drawable.getOpacity();
        }
        return -3;
    }

    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet) {
        Drawable drawable = this.f18302X;
        if (drawable != null) {
            drawable.inflate(resources, xmlPullParser, attributeSet);
        } else {
            inflate(resources, xmlPullParser, attributeSet, (Resources.Theme) null);
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r9v10, resolved type: af$b} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r9v16, resolved type: af$c} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r9v17, resolved type: af$b} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r9v18, resolved type: af$b} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r9v19, resolved type: af$b} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x00b9  */
    /* JADX WARNING: Removed duplicated region for block: B:38:0x00c6  */
    /* JADX WARNING: Removed duplicated region for block: B:41:0x00ea  */
    /* JADX WARNING: Removed duplicated region for block: B:92:0x025f  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void inflate(android.content.res.Resources r18, org.xmlpull.v1.XmlPullParser r19, android.util.AttributeSet r20, android.content.res.Resources.Theme r21) {
        /*
            r17 = this;
            r1 = r17
            r2 = r18
            r3 = r19
            r4 = r20
            r5 = r21
            android.graphics.drawable.Drawable r0 = r1.f18302X
            if (r0 == 0) goto L_0x001c
            int r6 = android.os.Build.VERSION.SDK_INT
            r7 = 21
            if (r6 < r7) goto L_0x0018
            r0.inflate(r2, r3, r4, r5)
            goto L_0x001b
        L_0x0018:
            r0.inflate(r2, r3, r4)
        L_0x001b:
            return
        L_0x001c:
            af$h r6 = r1.f373Y
            af$g r0 = new af$g
            r0.<init>()
            r6.f428b = r0
            int[] r0 = p000.C1916te.f14842a
            android.content.res.TypedArray r7 = p000.C0815h0.m5783a((android.content.res.Resources) r2, (android.content.res.Resources.Theme) r5, (android.util.AttributeSet) r4, (int[]) r0)
            af$h r8 = r1.f373Y
            af$g r9 = r8.f428b
            r0 = 6
            r10 = -1
            java.lang.String r11 = "tintMode"
            int r0 = p000.C0815h0.m5835b(r7, r3, r11, r0, r10)
            android.graphics.PorterDuff$Mode r10 = android.graphics.PorterDuff.Mode.SRC_IN
            r11 = 5
            r12 = 3
            if (r0 == r12) goto L_0x0053
            if (r0 == r11) goto L_0x0055
            r13 = 9
            if (r0 == r13) goto L_0x0050
            switch(r0) {
                case 14: goto L_0x004d;
                case 15: goto L_0x004a;
                case 16: goto L_0x0047;
                default: goto L_0x0046;
            }
        L_0x0046:
            goto L_0x0055
        L_0x0047:
            android.graphics.PorterDuff$Mode r10 = android.graphics.PorterDuff.Mode.ADD
            goto L_0x0055
        L_0x004a:
            android.graphics.PorterDuff$Mode r10 = android.graphics.PorterDuff.Mode.SCREEN
            goto L_0x0055
        L_0x004d:
            android.graphics.PorterDuff$Mode r10 = android.graphics.PorterDuff.Mode.MULTIPLY
            goto L_0x0055
        L_0x0050:
            android.graphics.PorterDuff$Mode r10 = android.graphics.PorterDuff.Mode.SRC_ATOP
            goto L_0x0055
        L_0x0053:
            android.graphics.PorterDuff$Mode r10 = android.graphics.PorterDuff.Mode.SRC_OVER
        L_0x0055:
            r8.f430d = r10
            java.lang.String r0 = "tint"
            boolean r0 = p000.C0815h0.m5827a((org.xmlpull.v1.XmlPullParser) r3, (java.lang.String) r0)
            r10 = 0
            r13 = 1
            r14 = 2
            if (r0 == 0) goto L_0x00b6
            android.util.TypedValue r0 = new android.util.TypedValue
            r0.<init>()
            r7.getValue(r13, r0)
            int r15 = r0.type
            if (r15 == r14) goto L_0x0097
            r14 = 28
            if (r15 < r14) goto L_0x007d
            r14 = 31
            if (r15 > r14) goto L_0x007d
            int r0 = r0.data
            android.content.res.ColorStateList r0 = android.content.res.ColorStateList.valueOf(r0)
            goto L_0x00b7
        L_0x007d:
            android.content.res.Resources r0 = r7.getResources()
            int r14 = r7.getResourceId(r13, r10)
            android.content.res.XmlResourceParser r14 = r0.getXml(r14)     // Catch:{ Exception -> 0x008e }
            android.content.res.ColorStateList r0 = p000.C0815h0.m5781a((android.content.res.Resources) r0, (org.xmlpull.v1.XmlPullParser) r14, (android.content.res.Resources.Theme) r5)     // Catch:{ Exception -> 0x008e }
            goto L_0x00b7
        L_0x008e:
            r0 = move-exception
            java.lang.String r14 = "CSLCompat"
            java.lang.String r15 = "Failed to inflate ColorStateList."
            android.util.Log.e(r14, r15, r0)
            goto L_0x00b6
        L_0x0097:
            java.lang.UnsupportedOperationException r2 = new java.lang.UnsupportedOperationException
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            r3.<init>()
            java.lang.String r4 = "Failed to resolve attribute at index "
            r3.append(r4)
            r3.append(r13)
            java.lang.String r4 = ": "
            r3.append(r4)
            r3.append(r0)
            java.lang.String r0 = r3.toString()
            r2.<init>(r0)
            throw r2
        L_0x00b6:
            r0 = 0
        L_0x00b7:
            if (r0 == 0) goto L_0x00bb
            r8.f429c = r0
        L_0x00bb:
            boolean r0 = r8.f431e
            java.lang.String r14 = "autoMirrored"
            boolean r14 = p000.C0815h0.m5827a((org.xmlpull.v1.XmlPullParser) r3, (java.lang.String) r14)
            if (r14 != 0) goto L_0x00c6
            goto L_0x00ca
        L_0x00c6:
            boolean r0 = r7.getBoolean(r11, r0)
        L_0x00ca:
            r8.f431e = r0
            r0 = 7
            float r8 = r9.f421k
            java.lang.String r11 = "viewportWidth"
            float r0 = p000.C0815h0.m5768a((android.content.res.TypedArray) r7, (org.xmlpull.v1.XmlPullParser) r3, (java.lang.String) r11, (int) r0, (float) r8)
            r9.f421k = r0
            r0 = 8
            float r8 = r9.f422l
            java.lang.String r11 = "viewportHeight"
            float r0 = p000.C0815h0.m5768a((android.content.res.TypedArray) r7, (org.xmlpull.v1.XmlPullParser) r3, (java.lang.String) r11, (int) r0, (float) r8)
            r9.f422l = r0
            float r0 = r9.f421k
            r8 = 0
            int r0 = (r0 > r8 ? 1 : (r0 == r8 ? 0 : -1))
            if (r0 <= 0) goto L_0x025f
            float r0 = r9.f422l
            int r0 = (r0 > r8 ? 1 : (r0 == r8 ? 0 : -1))
            if (r0 <= 0) goto L_0x0244
            float r0 = r9.f419i
            float r0 = r7.getDimension(r12, r0)
            r9.f419i = r0
            float r0 = r9.f420j
            r11 = 2
            float r0 = r7.getDimension(r11, r0)
            r9.f420j = r0
            float r0 = r9.f419i
            int r0 = (r0 > r8 ? 1 : (r0 == r8 ? 0 : -1))
            if (r0 <= 0) goto L_0x0229
            float r0 = r9.f420j
            int r0 = (r0 > r8 ? 1 : (r0 == r8 ? 0 : -1))
            if (r0 <= 0) goto L_0x020e
            r0 = 4
            float r8 = r9.getAlpha()
            java.lang.String r11 = "alpha"
            float r0 = p000.C0815h0.m5768a((android.content.res.TypedArray) r7, (org.xmlpull.v1.XmlPullParser) r3, (java.lang.String) r11, (int) r0, (float) r8)
            r9.setAlpha(r0)
            java.lang.String r0 = r7.getString(r10)
            if (r0 == 0) goto L_0x0128
            r9.f424n = r0
            z4<java.lang.String, java.lang.Object> r8 = r9.f426p
            r8.put(r0, r9)
        L_0x0128:
            r7.recycle()
            int r0 = r17.getChangingConfigurations()
            r6.f427a = r0
            r6.f437k = r13
            af$h r0 = r1.f373Y
            af$g r7 = r0.f428b
            java.util.ArrayDeque r8 = new java.util.ArrayDeque
            r8.<init>()
            af$d r9 = r7.f418h
            r8.push(r9)
            int r9 = r19.getEventType()
            int r11 = r19.getDepth()
            int r11 = r11 + r13
            r14 = 1
        L_0x014b:
            if (r9 == r13) goto L_0x01f9
            int r15 = r19.getDepth()
            if (r15 >= r11) goto L_0x0155
            if (r9 == r12) goto L_0x01f9
        L_0x0155:
            java.lang.String r15 = "group"
            r10 = 2
            if (r9 != r10) goto L_0x01e2
            java.lang.String r9 = r19.getName()
            java.lang.Object r16 = r8.peek()
            r10 = r16
            af$d r10 = (p000.C0095af.C0099d) r10
            java.lang.String r13 = "path"
            boolean r13 = r13.equals(r9)
            if (r13 == 0) goto L_0x018c
            af$c r9 = new af$c
            r9.<init>()
            r9.mo443a(r2, r4, r5, r3)
            java.util.ArrayList<af$e> r10 = r10.f394b
            r10.add(r9)
            java.lang.String r10 = r9.getPathName()
            if (r10 == 0) goto L_0x018a
            z4<java.lang.String, java.lang.Object> r10 = r7.f426p
            java.lang.String r13 = r9.getPathName()
            r10.put(r13, r9)
        L_0x018a:
            r14 = 0
            goto L_0x01b0
        L_0x018c:
            java.lang.String r13 = "clip-path"
            boolean r13 = r13.equals(r9)
            if (r13 == 0) goto L_0x01b5
            af$b r9 = new af$b
            r9.<init>()
            r9.mo441a(r2, r4, r5, r3)
            java.util.ArrayList<af$e> r10 = r10.f394b
            r10.add(r9)
            java.lang.String r10 = r9.getPathName()
            if (r10 == 0) goto L_0x01b0
            z4<java.lang.String, java.lang.Object> r10 = r7.f426p
            java.lang.String r13 = r9.getPathName()
            r10.put(r13, r9)
        L_0x01b0:
            int r10 = r0.f427a
            int r9 = r9.f409d
            goto L_0x01de
        L_0x01b5:
            boolean r9 = r15.equals(r9)
            if (r9 == 0) goto L_0x01f1
            af$d r9 = new af$d
            r9.<init>()
            r9.mo462a(r2, r4, r5, r3)
            java.util.ArrayList<af$e> r10 = r10.f394b
            r10.add(r9)
            r8.push(r9)
            java.lang.String r10 = r9.getGroupName()
            if (r10 == 0) goto L_0x01da
            z4<java.lang.String, java.lang.Object> r10 = r7.f426p
            java.lang.String r13 = r9.getGroupName()
            r10.put(r13, r9)
        L_0x01da:
            int r10 = r0.f427a
            int r9 = r9.f403k
        L_0x01de:
            r9 = r9 | r10
            r0.f427a = r9
            goto L_0x01f1
        L_0x01e2:
            if (r9 != r12) goto L_0x01f1
            java.lang.String r9 = r19.getName()
            boolean r9 = r15.equals(r9)
            if (r9 == 0) goto L_0x01f1
            r8.pop()
        L_0x01f1:
            int r9 = r19.next()
            r10 = 0
            r13 = 1
            goto L_0x014b
        L_0x01f9:
            if (r14 != 0) goto L_0x0206
            android.content.res.ColorStateList r0 = r6.f429c
            android.graphics.PorterDuff$Mode r2 = r6.f430d
            android.graphics.PorterDuffColorFilter r0 = r1.mo414a((android.content.res.ColorStateList) r0, (android.graphics.PorterDuff.Mode) r2)
            r1.f374Z = r0
            return
        L_0x0206:
            org.xmlpull.v1.XmlPullParserException r0 = new org.xmlpull.v1.XmlPullParserException
            java.lang.String r2 = "no path defined"
            r0.<init>(r2)
            throw r0
        L_0x020e:
            org.xmlpull.v1.XmlPullParserException r0 = new org.xmlpull.v1.XmlPullParserException
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r3 = r7.getPositionDescription()
            r2.append(r3)
            java.lang.String r3 = "<vector> tag requires height > 0"
            r2.append(r3)
            java.lang.String r2 = r2.toString()
            r0.<init>(r2)
            throw r0
        L_0x0229:
            org.xmlpull.v1.XmlPullParserException r0 = new org.xmlpull.v1.XmlPullParserException
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r3 = r7.getPositionDescription()
            r2.append(r3)
            java.lang.String r3 = "<vector> tag requires width > 0"
            r2.append(r3)
            java.lang.String r2 = r2.toString()
            r0.<init>(r2)
            throw r0
        L_0x0244:
            org.xmlpull.v1.XmlPullParserException r0 = new org.xmlpull.v1.XmlPullParserException
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r3 = r7.getPositionDescription()
            r2.append(r3)
            java.lang.String r3 = "<vector> tag requires viewportHeight > 0"
            r2.append(r3)
            java.lang.String r2 = r2.toString()
            r0.<init>(r2)
            throw r0
        L_0x025f:
            org.xmlpull.v1.XmlPullParserException r0 = new org.xmlpull.v1.XmlPullParserException
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r3 = r7.getPositionDescription()
            r2.append(r3)
            java.lang.String r3 = "<vector> tag requires viewportWidth > 0"
            r2.append(r3)
            java.lang.String r2 = r2.toString()
            r0.<init>(r2)
            goto L_0x027b
        L_0x027a:
            throw r0
        L_0x027b:
            goto L_0x027a
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0095af.inflate(android.content.res.Resources, org.xmlpull.v1.XmlPullParser, android.util.AttributeSet, android.content.res.Resources$Theme):void");
    }

    public void invalidateSelf() {
        Drawable drawable = this.f18302X;
        if (drawable != null) {
            drawable.invalidateSelf();
        } else {
            super.invalidateSelf();
        }
    }

    public boolean isAutoMirrored() {
        Drawable drawable = this.f18302X;
        return drawable != null ? C0815h0.m5854c(drawable) : this.f373Y.f431e;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x0019, code lost:
        r0 = r1.f373Y.f429c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:6:0x000f, code lost:
        r0 = r1.f373Y;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean isStateful() {
        /*
            r1 = this;
            android.graphics.drawable.Drawable r0 = r1.f18302X
            if (r0 == 0) goto L_0x0009
            boolean r0 = r0.isStateful()
            return r0
        L_0x0009:
            boolean r0 = super.isStateful()
            if (r0 != 0) goto L_0x0028
            af$h r0 = r1.f373Y
            if (r0 == 0) goto L_0x0026
            boolean r0 = r0.mo500c()
            if (r0 != 0) goto L_0x0028
            af$h r0 = r1.f373Y
            android.content.res.ColorStateList r0 = r0.f429c
            if (r0 == 0) goto L_0x0026
            boolean r0 = r0.isStateful()
            if (r0 == 0) goto L_0x0026
            goto L_0x0028
        L_0x0026:
            r0 = 0
            goto L_0x0029
        L_0x0028:
            r0 = 1
        L_0x0029:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0095af.isStateful():boolean");
    }

    public Drawable mutate() {
        Drawable drawable = this.f18302X;
        if (drawable != null) {
            drawable.mutate();
            return this;
        }
        if (!this.f376b0 && super.mutate() == this) {
            this.f373Y = new C0103h(this.f373Y);
            this.f376b0 = true;
        }
        return this;
    }

    public void onBoundsChange(Rect rect) {
        Drawable drawable = this.f18302X;
        if (drawable != null) {
            drawable.setBounds(rect);
        }
    }

    public boolean onStateChange(int[] iArr) {
        PorterDuff.Mode mode;
        Drawable drawable = this.f18302X;
        if (drawable != null) {
            return drawable.setState(iArr);
        }
        boolean z = false;
        C0103h hVar = this.f373Y;
        ColorStateList colorStateList = hVar.f429c;
        if (!(colorStateList == null || (mode = hVar.f430d) == null)) {
            this.f374Z = mo414a(colorStateList, mode);
            invalidateSelf();
            z = true;
        }
        if (!hVar.mo500c() || !hVar.mo496a(iArr)) {
            return z;
        }
        invalidateSelf();
        return true;
    }

    public void scheduleSelf(Runnable runnable, long j) {
        Drawable drawable = this.f18302X;
        if (drawable != null) {
            drawable.scheduleSelf(runnable, j);
        } else {
            super.scheduleSelf(runnable, j);
        }
    }

    public void setAlpha(int i) {
        Drawable drawable = this.f18302X;
        if (drawable != null) {
            drawable.setAlpha(i);
        } else if (this.f373Y.f428b.getRootAlpha() != i) {
            this.f373Y.f428b.setRootAlpha(i);
            invalidateSelf();
        }
    }

    public void setAutoMirrored(boolean z) {
        Drawable drawable = this.f18302X;
        if (drawable != null) {
            int i = Build.VERSION.SDK_INT;
            drawable.setAutoMirrored(z);
            return;
        }
        this.f373Y.f431e = z;
    }

    public void setColorFilter(ColorFilter colorFilter) {
        Drawable drawable = this.f18302X;
        if (drawable != null) {
            drawable.setColorFilter(colorFilter);
            return;
        }
        this.f375a0 = colorFilter;
        invalidateSelf();
    }

    public void setTint(int i) {
        Drawable drawable = this.f18302X;
        if (drawable != null) {
            C0815h0.m5845b(drawable, i);
        } else {
            setTintList(ColorStateList.valueOf(i));
        }
    }

    public void setTintList(ColorStateList colorStateList) {
        Drawable drawable = this.f18302X;
        if (drawable != null) {
            C0815h0.m5802a(drawable, colorStateList);
            return;
        }
        C0103h hVar = this.f373Y;
        if (hVar.f429c != colorStateList) {
            hVar.f429c = colorStateList;
            this.f374Z = mo414a(colorStateList, hVar.f430d);
            invalidateSelf();
        }
    }

    public void setTintMode(PorterDuff.Mode mode) {
        Drawable drawable = this.f18302X;
        if (drawable != null) {
            C0815h0.m5803a(drawable, mode);
            return;
        }
        C0103h hVar = this.f373Y;
        if (hVar.f430d != mode) {
            hVar.f430d = mode;
            this.f374Z = mo414a(hVar.f429c, mode);
            invalidateSelf();
        }
    }

    public boolean setVisible(boolean z, boolean z2) {
        Drawable drawable = this.f18302X;
        return drawable != null ? drawable.setVisible(z, z2) : super.setVisible(z, z2);
    }

    public void unscheduleSelf(Runnable runnable) {
        Drawable drawable = this.f18302X;
        if (drawable != null) {
            drawable.unscheduleSelf(runnable);
        } else {
            super.unscheduleSelf(runnable);
        }
    }
}
