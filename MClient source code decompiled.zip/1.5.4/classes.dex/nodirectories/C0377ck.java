package p000;

import java.util.List;

/* renamed from: ck */
public final /* synthetic */ class C0377ck implements Runnable {

    /* renamed from: X */
    public final /* synthetic */ C1706qj f2775X;

    public /* synthetic */ C0377ck(C1706qj qjVar) {
        this.f2775X = qjVar;
    }

    public final void run() {
        this.f2775X.mo8412a(C2151vj.f16144k, (List<C1626pj>) null);
    }
}
