package p000;

import java.util.Map;

/* renamed from: dy */
public final /* synthetic */ class C0563dy implements C1373my {

    /* renamed from: a */
    public static final C1373my f4177a = new C0563dy();

    /* renamed from: a */
    public final void mo2197a(Object obj, Map map) {
        C2476zx.m17353a((wk0) obj, map);
    }
}
