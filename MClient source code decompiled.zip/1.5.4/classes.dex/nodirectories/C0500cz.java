package p000;

import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: cz */
public final class C0500cz implements Parcelable.Creator<C2384yy> {
    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        int b = C0680fe.m4795b(parcel);
        String str = null;
        String[] strArr = null;
        String[] strArr2 = null;
        while (parcel.dataPosition() < b) {
            int readInt = parcel.readInt();
            int i = 65535 & readInt;
            if (i == 1) {
                str = C0680fe.m4826c(parcel, readInt);
            } else if (i == 2) {
                strArr = C0680fe.m4848d(parcel, readInt);
            } else if (i != 3) {
                C0680fe.m4887m(parcel, readInt);
            } else {
                strArr2 = C0680fe.m4848d(parcel, readInt);
            }
        }
        C0680fe.m4863f(parcel, b);
        return new C2384yy(str, strArr, strArr2);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new C2384yy[i];
    }
}
