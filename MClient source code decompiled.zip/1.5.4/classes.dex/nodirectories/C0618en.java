package p000;

import android.content.Context;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageButton;

/* renamed from: en */
public final class C0618en extends FrameLayout implements View.OnClickListener {

    /* renamed from: a0 */
    public final ImageButton f4601a0;

    /* renamed from: b0 */
    public final C1346mn f4602b0;

    public C0618en(Context context, C0550dn dnVar, C1346mn mnVar) {
        super(context);
        this.f4602b0 = mnVar;
        setOnClickListener(this);
        this.f4601a0 = new ImageButton(context);
        this.f4601a0.setImageResource(17301527);
        this.f4601a0.setBackgroundColor(0);
        this.f4601a0.setOnClickListener(this);
        ImageButton imageButton = this.f4601a0;
        af0 af0 = kw2.f9317j.f9318a;
        int a = af0.m467a(context.getResources().getDisplayMetrics(), dnVar.f3976a);
        af0 af02 = kw2.f9317j.f9318a;
        int a2 = af0.m467a(context.getResources().getDisplayMetrics(), 0);
        af0 af03 = kw2.f9317j.f9318a;
        int a3 = af0.m467a(context.getResources().getDisplayMetrics(), dnVar.f3977b);
        af0 af04 = kw2.f9317j.f9318a;
        imageButton.setPadding(a, a2, a3, af0.m467a(context.getResources().getDisplayMetrics(), dnVar.f3978c));
        this.f4601a0.setContentDescription("Interstitial close button");
        ImageButton imageButton2 = this.f4601a0;
        af0 af05 = kw2.f9317j.f9318a;
        int a4 = af0.m467a(context.getResources().getDisplayMetrics(), dnVar.f3979d + dnVar.f3976a + dnVar.f3977b);
        af0 af06 = kw2.f9317j.f9318a;
        addView(imageButton2, new FrameLayout.LayoutParams(a4, af0.m467a(context.getResources().getDisplayMetrics(), dnVar.f3979d + dnVar.f3978c), 17));
    }

    public final void onClick(View view) {
        C1346mn mnVar = this.f4602b0;
        if (mnVar != null) {
            mnVar.mo6705l1();
        }
    }
}
