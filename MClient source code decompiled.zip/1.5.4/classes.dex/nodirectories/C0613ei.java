package p000;

/* renamed from: ei */
public class C0613ei implements C1617pg {

    /* renamed from: a */
    public final /* synthetic */ C0868hi f4497a;

    public C0613ei(C0868hi hiVar) {
        this.f4497a = hiVar;
    }

    /* renamed from: a */
    public void mo532a(C1249lg lgVar) {
        if (this.f4497a.mo6550c(lgVar)) {
            this.f4497a.mo6549b(lgVar);
        }
    }
}
