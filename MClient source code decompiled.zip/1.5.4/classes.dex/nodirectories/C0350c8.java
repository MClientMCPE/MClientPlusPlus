package p000;

import android.view.View;

/* renamed from: c8 */
public class C0350c8 implements C0286b8 {
    /* renamed from: a */
    public void mo172a(View view) {
    }

    /* renamed from: c */
    public void mo173c(View view) {
    }
}
