package p000;

/* renamed from: fr */
public interface C0717fr {
}
