package p000;

import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroupOverlay;

/* renamed from: ce */
public class C0370ce implements C0534de {

    /* renamed from: a */
    public final ViewGroupOverlay f2668a;

    public C0370ce(ViewGroup viewGroup) {
        this.f2668a = viewGroup.getOverlay();
    }

    /* renamed from: a */
    public void mo2906a(Drawable drawable) {
        this.f2668a.add(drawable);
    }

    /* renamed from: a */
    public void mo2907a(View view) {
        this.f2668a.add(view);
    }

    /* renamed from: b */
    public void mo2908b(Drawable drawable) {
        this.f2668a.remove(drawable);
    }

    /* renamed from: b */
    public void mo2909b(View view) {
        this.f2668a.remove(view);
    }
}
