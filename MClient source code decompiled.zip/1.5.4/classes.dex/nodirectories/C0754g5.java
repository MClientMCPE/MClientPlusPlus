package p000;

import java.util.ConcurrentModificationException;
import java.util.Map;

/* renamed from: g5 */
public class C0754g5<K, V> {

    /* renamed from: a0 */
    public static Object[] f5959a0;

    /* renamed from: b0 */
    public static int f5960b0;

    /* renamed from: c0 */
    public static Object[] f5961c0;

    /* renamed from: d0 */
    public static int f5962d0;

    /* renamed from: X */
    public int[] f5963X;

    /* renamed from: Y */
    public Object[] f5964Y;

    /* renamed from: Z */
    public int f5965Z;

    public C0754g5() {
        this.f5963X = C0339c5.f2506a;
        this.f5964Y = C0339c5.f2508c;
        this.f5965Z = 0;
    }

    public C0754g5(int i) {
        if (i == 0) {
            this.f5963X = C0339c5.f2506a;
            this.f5964Y = C0339c5.f2508c;
        } else {
            mo5974a(i);
        }
        this.f5965Z = 0;
    }

    public C0754g5(C0754g5<K, V> g5Var) {
        this();
        if (g5Var != null) {
            int i = g5Var.f5965Z;
            mo5976b(this.f5965Z + i);
            if (this.f5965Z != 0) {
                for (int i2 = 0; i2 < i; i2++) {
                    put(g5Var.mo5977c(i2), g5Var.mo5982e(i2));
                }
            } else if (i > 0) {
                System.arraycopy(g5Var.f5963X, 0, this.f5963X, 0, i);
                System.arraycopy(g5Var.f5964Y, 0, this.f5964Y, 0, i << 1);
                this.f5965Z = i;
            }
        }
    }

    /* renamed from: a */
    public static void m5332a(int[] iArr, Object[] objArr, int i) {
        Class<C0754g5> cls = C0754g5.class;
        if (iArr.length == 8) {
            synchronized (cls) {
                if (f5962d0 < 10) {
                    objArr[0] = f5961c0;
                    objArr[1] = iArr;
                    for (int i2 = (i << 1) - 1; i2 >= 2; i2--) {
                        objArr[i2] = null;
                    }
                    f5961c0 = objArr;
                    f5962d0++;
                }
            }
        } else if (iArr.length == 4) {
            synchronized (cls) {
                if (f5960b0 < 10) {
                    objArr[0] = f5959a0;
                    objArr[1] = iArr;
                    for (int i3 = (i << 1) - 1; i3 >= 2; i3--) {
                        objArr[i3] = null;
                    }
                    f5959a0 = objArr;
                    f5960b0++;
                }
            }
        }
    }

    /* renamed from: a */
    public int mo5971a(Object obj) {
        return obj == null ? mo5970a() : mo5972a(obj, obj.hashCode());
    }

    /* renamed from: a */
    public int mo5972a(Object obj, int i) {
        int i2 = this.f5965Z;
        if (i2 == 0) {
            return -1;
        }
        try {
            int a = C0339c5.m2291a(this.f5963X, i2, i);
            if (a < 0 || obj.equals(this.f5964Y[a << 1])) {
                return a;
            }
            int i3 = a + 1;
            while (i3 < i2 && this.f5963X[i3] == i) {
                if (obj.equals(this.f5964Y[i3 << 1])) {
                    return i3;
                }
                i3++;
            }
            int i4 = a - 1;
            while (i4 >= 0 && this.f5963X[i4] == i) {
                if (obj.equals(this.f5964Y[i4 << 1])) {
                    return i4;
                }
                i4--;
            }
            return i3 ^ -1;
        } catch (ArrayIndexOutOfBoundsException unused) {
            throw new ConcurrentModificationException();
        }
    }

    /* renamed from: a */
    public V mo5973a(int i, V v) {
        int i2 = (i << 1) + 1;
        V[] vArr = this.f5964Y;
        V v2 = vArr[i2];
        vArr[i2] = v;
        return v2;
    }

    /* renamed from: a */
    public final void mo5974a(int i) {
        Class<C0754g5> cls = C0754g5.class;
        if (i == 8) {
            synchronized (cls) {
                if (f5961c0 != null) {
                    Object[] objArr = f5961c0;
                    this.f5964Y = objArr;
                    f5961c0 = (Object[]) objArr[0];
                    this.f5963X = (int[]) objArr[1];
                    objArr[1] = null;
                    objArr[0] = null;
                    f5962d0--;
                    return;
                }
            }
        } else if (i == 4) {
            synchronized (cls) {
                if (f5959a0 != null) {
                    Object[] objArr2 = f5959a0;
                    this.f5964Y = objArr2;
                    f5959a0 = (Object[]) objArr2[0];
                    this.f5963X = (int[]) objArr2[1];
                    objArr2[1] = null;
                    objArr2[0] = null;
                    f5960b0--;
                    return;
                }
            }
        }
        this.f5963X = new int[i];
        this.f5964Y = new Object[(i << 1)];
    }

    /* renamed from: b */
    public int mo5975b(Object obj) {
        int i = this.f5965Z * 2;
        Object[] objArr = this.f5964Y;
        if (obj == null) {
            for (int i2 = 1; i2 < i; i2 += 2) {
                if (objArr[i2] == null) {
                    return i2 >> 1;
                }
            }
            return -1;
        }
        for (int i3 = 1; i3 < i; i3 += 2) {
            if (obj.equals(objArr[i3])) {
                return i3 >> 1;
            }
        }
        return -1;
    }

    /* renamed from: b */
    public void mo5976b(int i) {
        int i2 = this.f5965Z;
        int[] iArr = this.f5963X;
        if (iArr.length < i) {
            Object[] objArr = this.f5964Y;
            mo5974a(i);
            if (this.f5965Z > 0) {
                System.arraycopy(iArr, 0, this.f5963X, 0, i2);
                System.arraycopy(objArr, 0, this.f5964Y, 0, i2 << 1);
            }
            m5332a(iArr, objArr, i2);
        }
        if (this.f5965Z != i2) {
            throw new ConcurrentModificationException();
        }
    }

    /* renamed from: c */
    public K mo5977c(int i) {
        return this.f5964Y[i << 1];
    }

    public void clear() {
        int i = this.f5965Z;
        if (i > 0) {
            int[] iArr = this.f5963X;
            Object[] objArr = this.f5964Y;
            this.f5963X = C0339c5.f2506a;
            this.f5964Y = C0339c5.f2508c;
            this.f5965Z = 0;
            m5332a(iArr, objArr, i);
        }
        if (this.f5965Z > 0) {
            throw new ConcurrentModificationException();
        }
    }

    public boolean containsKey(Object obj) {
        return mo5971a(obj) >= 0;
    }

    public boolean containsValue(Object obj) {
        return mo5975b(obj) >= 0;
    }

    /* renamed from: d */
    public V mo5981d(int i) {
        int i2;
        V[] vArr = this.f5964Y;
        int i3 = i << 1;
        V v = vArr[i3 + 1];
        int i4 = this.f5965Z;
        if (i4 <= 1) {
            m5332a(this.f5963X, vArr, i4);
            this.f5963X = C0339c5.f2506a;
            this.f5964Y = C0339c5.f2508c;
            i2 = 0;
        } else {
            i2 = i4 - 1;
            int[] iArr = this.f5963X;
            int i5 = 8;
            if (iArr.length <= 8 || i4 >= iArr.length / 3) {
                if (i < i2) {
                    int[] iArr2 = this.f5963X;
                    int i6 = i + 1;
                    int i7 = i2 - i;
                    System.arraycopy(iArr2, i6, iArr2, i, i7);
                    Object[] objArr = this.f5964Y;
                    System.arraycopy(objArr, i6 << 1, objArr, i3, i7 << 1);
                }
                Object[] objArr2 = this.f5964Y;
                int i8 = i2 << 1;
                objArr2[i8] = null;
                objArr2[i8 + 1] = null;
            } else {
                if (i4 > 8) {
                    i5 = i4 + (i4 >> 1);
                }
                int[] iArr3 = this.f5963X;
                Object[] objArr3 = this.f5964Y;
                mo5974a(i5);
                if (i4 == this.f5965Z) {
                    if (i > 0) {
                        System.arraycopy(iArr3, 0, this.f5963X, 0, i);
                        System.arraycopy(objArr3, 0, this.f5964Y, 0, i3);
                    }
                    if (i < i2) {
                        int i9 = i + 1;
                        int i10 = i2 - i;
                        System.arraycopy(iArr3, i9, this.f5963X, i, i10);
                        System.arraycopy(objArr3, i9 << 1, this.f5964Y, i3, i10 << 1);
                    }
                } else {
                    throw new ConcurrentModificationException();
                }
            }
        }
        if (i4 == this.f5965Z) {
            this.f5965Z = i2;
            return v;
        }
        throw new ConcurrentModificationException();
    }

    /* renamed from: e */
    public V mo5982e(int i) {
        return this.f5964Y[(i << 1) + 1];
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof C0754g5) {
            C0754g5 g5Var = (C0754g5) obj;
            if (this.f5965Z != g5Var.f5965Z) {
                return false;
            }
            int i = 0;
            while (i < this.f5965Z) {
                try {
                    Object c = mo5977c(i);
                    Object e = mo5982e(i);
                    Object obj2 = g5Var.get(c);
                    if (e == null) {
                        if (obj2 != null || !g5Var.containsKey(c)) {
                            return false;
                        }
                    } else if (!e.equals(obj2)) {
                        return false;
                    }
                    i++;
                } catch (ClassCastException | NullPointerException unused) {
                    return false;
                }
            }
            return true;
        }
        if (obj instanceof Map) {
            Map map = (Map) obj;
            if (this.f5965Z != map.size()) {
                return false;
            }
            int i2 = 0;
            while (i2 < this.f5965Z) {
                try {
                    Object c2 = mo5977c(i2);
                    Object e2 = mo5982e(i2);
                    Object obj3 = map.get(c2);
                    if (e2 == null) {
                        if (obj3 != null || !map.containsKey(c2)) {
                            return false;
                        }
                    } else if (!e2.equals(obj3)) {
                        return false;
                    }
                    i2++;
                } catch (ClassCastException | NullPointerException unused2) {
                }
            }
            return true;
        }
        return false;
    }

    public V get(Object obj) {
        return getOrDefault(obj, (Object) null);
    }

    public V getOrDefault(Object obj, V v) {
        int a = mo5971a(obj);
        return a >= 0 ? this.f5964Y[(a << 1) + 1] : v;
    }

    public int hashCode() {
        int[] iArr = this.f5963X;
        Object[] objArr = this.f5964Y;
        int i = this.f5965Z;
        int i2 = 0;
        int i3 = 0;
        int i4 = 1;
        while (i2 < i) {
            Object obj = objArr[i4];
            i3 += (obj == null ? 0 : obj.hashCode()) ^ iArr[i2];
            i2++;
            i4 += 2;
        }
        return i3;
    }

    public boolean isEmpty() {
        return this.f5965Z <= 0;
    }

    public V put(K k, V v) {
        int i;
        int i2;
        int i3 = this.f5965Z;
        if (k == null) {
            i2 = mo5970a();
            i = 0;
        } else {
            int hashCode = k.hashCode();
            i = hashCode;
            i2 = mo5972a((Object) k, hashCode);
        }
        if (i2 >= 0) {
            int i4 = (i2 << 1) + 1;
            V[] vArr = this.f5964Y;
            V v2 = vArr[i4];
            vArr[i4] = v;
            return v2;
        }
        int i5 = i2 ^ -1;
        if (i3 >= this.f5963X.length) {
            int i6 = 4;
            if (i3 >= 8) {
                i6 = (i3 >> 1) + i3;
            } else if (i3 >= 4) {
                i6 = 8;
            }
            int[] iArr = this.f5963X;
            Object[] objArr = this.f5964Y;
            mo5974a(i6);
            if (i3 == this.f5965Z) {
                int[] iArr2 = this.f5963X;
                if (iArr2.length > 0) {
                    System.arraycopy(iArr, 0, iArr2, 0, iArr.length);
                    System.arraycopy(objArr, 0, this.f5964Y, 0, objArr.length);
                }
                m5332a(iArr, objArr, i3);
            } else {
                throw new ConcurrentModificationException();
            }
        }
        if (i5 < i3) {
            int[] iArr3 = this.f5963X;
            int i7 = i5 + 1;
            System.arraycopy(iArr3, i5, iArr3, i7, i3 - i5);
            Object[] objArr2 = this.f5964Y;
            System.arraycopy(objArr2, i5 << 1, objArr2, i7 << 1, (this.f5965Z - i5) << 1);
        }
        int i8 = this.f5965Z;
        if (i3 == i8) {
            int[] iArr4 = this.f5963X;
            if (i5 < iArr4.length) {
                iArr4[i5] = i;
                Object[] objArr3 = this.f5964Y;
                int i9 = i5 << 1;
                objArr3[i9] = k;
                objArr3[i9 + 1] = v;
                this.f5965Z = i8 + 1;
                return null;
            }
        }
        throw new ConcurrentModificationException();
    }

    public V putIfAbsent(K k, V v) {
        V orDefault = getOrDefault(k, (Object) null);
        return orDefault == null ? put(k, v) : orDefault;
    }

    public V remove(Object obj) {
        int a = mo5971a(obj);
        if (a >= 0) {
            return mo5981d(a);
        }
        return null;
    }

    public boolean remove(Object obj, Object obj2) {
        int a = mo5971a(obj);
        if (a < 0) {
            return false;
        }
        Object e = mo5982e(a);
        if (obj2 != e && (obj2 == null || !obj2.equals(e))) {
            return false;
        }
        mo5981d(a);
        return true;
    }

    public V replace(K k, V v) {
        int a = mo5971a((Object) k);
        if (a >= 0) {
            return mo5973a(a, v);
        }
        return null;
    }

    public boolean replace(K k, V v, V v2) {
        int a = mo5971a((Object) k);
        if (a < 0) {
            return false;
        }
        V e = mo5982e(a);
        if (e != v && (v == null || !v.equals(e))) {
            return false;
        }
        mo5973a(a, v2);
        return true;
    }

    public int size() {
        return this.f5965Z;
    }

    public String toString() {
        if (isEmpty()) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.f5965Z * 28);
        sb.append('{');
        for (int i = 0; i < this.f5965Z; i++) {
            if (i > 0) {
                sb.append(", ");
            }
            Object c = mo5977c(i);
            if (c != this) {
                sb.append(c);
            } else {
                sb.append("(this Map)");
            }
            sb.append('=');
            Object e = mo5982e(i);
            if (e != this) {
                sb.append(e);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }

    /* renamed from: a */
    public int mo5970a() {
        int i = this.f5965Z;
        if (i == 0) {
            return -1;
        }
        try {
            int a = C0339c5.m2291a(this.f5963X, i, 0);
            if (a < 0 || this.f5964Y[a << 1] == null) {
                return a;
            }
            int i2 = a + 1;
            while (i2 < i && this.f5963X[i2] == 0) {
                if (this.f5964Y[i2 << 1] == null) {
                    return i2;
                }
                i2++;
            }
            int i3 = a - 1;
            while (i3 >= 0 && this.f5963X[i3] == 0) {
                if (this.f5964Y[i3 << 1] == null) {
                    return i3;
                }
                i3--;
            }
            return i2 ^ -1;
        } catch (ArrayIndexOutOfBoundsException unused) {
            throw new ConcurrentModificationException();
        }
    }
}
