package p000;

import android.graphics.Path;
import android.util.Log;

/* renamed from: f6 */
public class C0664f6 {

    /* renamed from: a */
    public char f5061a;

    /* renamed from: b */
    public float[] f5062b;

    public C0664f6(char c, float[] fArr) {
        this.f5061a = c;
        this.f5062b = fArr;
    }

    public C0664f6(C0664f6 f6Var) {
        this.f5061a = f6Var.f5061a;
        float[] fArr = f6Var.f5062b;
        this.f5062b = C0815h0.m5829a(fArr, 0, fArr.length);
    }

    /* renamed from: a */
    public static void m4507a(Path path, float f, float f2, float f3, float f4, float f5, float f6, float f7, boolean z, boolean z2) {
        double d;
        double d2;
        float f8 = f;
        float f9 = f3;
        float f10 = f5;
        boolean z3 = z2;
        double radians = Math.toRadians((double) f7);
        double cos = Math.cos(radians);
        double sin = Math.sin(radians);
        double d3 = (double) f8;
        Double.isNaN(d3);
        double d4 = (double) f2;
        Double.isNaN(d4);
        double d5 = (d4 * sin) + (d3 * cos);
        double d6 = d3;
        double d7 = (double) f10;
        Double.isNaN(d7);
        double d8 = d5 / d7;
        double d9 = radians;
        double d10 = (double) (-f8);
        Double.isNaN(d10);
        Double.isNaN(d4);
        double d11 = (d4 * cos) + (d10 * sin);
        double d12 = (double) f6;
        Double.isNaN(d12);
        double d13 = d11 / d12;
        double d14 = d4;
        double d15 = (double) f9;
        Double.isNaN(d15);
        double d16 = (double) f4;
        Double.isNaN(d16);
        Double.isNaN(d7);
        double d17 = ((d16 * sin) + (d15 * cos)) / d7;
        double d18 = (double) (-f9);
        Double.isNaN(d18);
        Double.isNaN(d16);
        Double.isNaN(d12);
        double d19 = ((d16 * cos) + (d18 * sin)) / d12;
        double d20 = d8 - d17;
        double d21 = d13 - d19;
        double d22 = (d8 + d17) / 2.0d;
        double d23 = (d13 + d19) / 2.0d;
        double d24 = sin;
        double d25 = (d21 * d21) + (d20 * d20);
        if (d25 == 0.0d) {
            Log.w("PathParser", " Points are coincident");
            return;
        }
        double d26 = (1.0d / d25) - 0.25d;
        if (d26 < 0.0d) {
            Log.w("PathParser", "Points are too far apart " + d25);
            float sqrt = (float) (Math.sqrt(d25) / 1.99999d);
            m4507a(path, f, f2, f3, f4, f10 * sqrt, f6 * sqrt, f7, z, z2);
            return;
        }
        double sqrt2 = Math.sqrt(d26);
        double d27 = d20 * sqrt2;
        double d28 = sqrt2 * d21;
        if (z == z3) {
            d2 = d22 - d28;
            d = d23 + d27;
        } else {
            d2 = d22 + d28;
            d = d23 - d27;
        }
        double atan2 = Math.atan2(d13 - d, d8 - d2);
        double atan22 = Math.atan2(d19 - d, d17 - d2) - atan2;
        int i = 0;
        if (z3 != (atan22 >= 0.0d)) {
            atan22 = atan22 > 0.0d ? atan22 - 6.283185307179586d : atan22 + 6.283185307179586d;
        }
        Double.isNaN(d7);
        double d29 = d2 * d7;
        Double.isNaN(d12);
        double d30 = d * d12;
        double d31 = (d29 * cos) - (d30 * d24);
        double d32 = (d30 * cos) + (d29 * d24);
        int ceil = (int) Math.ceil(Math.abs((atan22 * 4.0d) / 3.141592653589793d));
        double cos2 = Math.cos(d9);
        double sin2 = Math.sin(d9);
        double cos3 = Math.cos(atan2);
        double sin3 = Math.sin(atan2);
        Double.isNaN(d7);
        double d33 = -d7;
        double d34 = d33 * cos2;
        Double.isNaN(d12);
        double d35 = d12 * sin2;
        double d36 = (d34 * sin3) - (d35 * cos3);
        double d37 = d33 * sin2;
        Double.isNaN(d12);
        double d38 = d12 * cos2;
        double d39 = (cos3 * d38) + (sin3 * d37);
        double d40 = atan2;
        double d41 = (double) ceil;
        Double.isNaN(d41);
        Double.isNaN(d41);
        double d42 = atan22 / d41;
        double d43 = d40;
        while (i < ceil) {
            double d44 = d43 + d42;
            double sin4 = Math.sin(d44);
            double cos4 = Math.cos(d44);
            Double.isNaN(d7);
            double d45 = d42;
            double d46 = (((d7 * cos2) * cos4) + d31) - (d35 * sin4);
            Double.isNaN(d7);
            double d47 = d31;
            double d48 = (d38 * sin4) + (d7 * sin2 * cos4) + d32;
            double d49 = (d34 * sin4) - (d35 * cos4);
            double d50 = (cos4 * d38) + (sin4 * d37);
            double d51 = d44 - d43;
            double tan = Math.tan(d51 / 2.0d);
            double sqrt3 = ((Math.sqrt(((tan * 3.0d) * tan) + 4.0d) - 1.0d) * Math.sin(d51)) / 3.0d;
            double d52 = (d36 * sqrt3) + d6;
            path.rLineTo(0.0f, 0.0f);
            path.cubicTo((float) d52, (float) ((d39 * sqrt3) + d14), (float) (d46 - (sqrt3 * d49)), (float) (d48 - (sqrt3 * d50)), (float) d46, (float) d48);
            i++;
            d38 = d38;
            d37 = d37;
            ceil = ceil;
            cos2 = cos2;
            d43 = d44;
            d7 = d7;
            d39 = d50;
            d36 = d49;
            d6 = d46;
            d14 = d48;
            d42 = d45;
            d31 = d47;
        }
    }

    /* renamed from: a */
    public void mo5454a(C0664f6 f6Var, C0664f6 f6Var2, float f) {
        this.f5061a = f6Var.f5061a;
        int i = 0;
        while (true) {
            float[] fArr = f6Var.f5062b;
            if (i < fArr.length) {
                this.f5062b[i] = (f6Var2.f5062b[i] * f) + ((1.0f - f) * fArr[i]);
                i++;
            } else {
                return;
            }
        }
    }

    /* renamed from: a */
    public static void m4508a(C0664f6[] f6VarArr, Path path) {
        int i;
        float f;
        int i2;
        float[] fArr;
        int i3;
        char c;
        int i4;
        float f2;
        float f3;
        float f4;
        int i5;
        float f5;
        float f6;
        float f7;
        float f8;
        float f9;
        float f10;
        float f11;
        float f12;
        float f13;
        float f14;
        float f15;
        float f16;
        float f17;
        float f18;
        C0664f6[] f6VarArr2 = f6VarArr;
        Path path2 = path;
        float[] fArr2 = new float[6];
        char c2 = 'm';
        char c3 = 0;
        char c4 = 'm';
        int i6 = 0;
        while (i6 < f6VarArr2.length) {
            char c5 = f6VarArr2[i6].f5061a;
            float[] fArr3 = f6VarArr2[i6].f5062b;
            float f19 = fArr2[c3];
            float f20 = fArr2[1];
            float f21 = fArr2[2];
            float f22 = fArr2[3];
            float f23 = fArr2[4];
            float f24 = fArr2[5];
            switch (c5) {
                case 'A':
                case 'a':
                    i = 7;
                    break;
                case 'C':
                case 'c':
                    i = 6;
                    break;
                case 'H':
                case 'V':
                case 'h':
                case 'v':
                    i = 1;
                    break;
                case 'Q':
                case 'S':
                case 'q':
                case 's':
                    i = 4;
                    break;
                case 'Z':
                case 'z':
                    path.close();
                    path2.moveTo(f23, f24);
                    f19 = f23;
                    f21 = f19;
                    f20 = f24;
                    f22 = f20;
                    break;
            }
            i = 2;
            float f25 = f23;
            float f26 = f24;
            int i7 = 0;
            float f27 = f20;
            float f28 = f19;
            char c6 = c4;
            float f29 = f22;
            float f30 = f28;
            while (i7 < fArr3.length) {
                if (c5 != 'A') {
                    if (c5 == 'C') {
                        i3 = i7;
                        fArr = fArr3;
                        c = c5;
                        i2 = i6;
                        int i8 = i3 + 2;
                        int i9 = i3 + 3;
                        int i10 = i3 + 4;
                        int i11 = i3 + 5;
                        path.cubicTo(fArr[i3 + 0], fArr[i3 + 1], fArr[i8], fArr[i9], fArr[i10], fArr[i11]);
                        f30 = fArr[i10];
                        f27 = fArr[i11];
                        float f31 = fArr[i8];
                        f29 = fArr[i9];
                        f = f31;
                    } else if (c5 == 'H') {
                        i3 = i7;
                        fArr = fArr3;
                        c = c5;
                        i2 = i6;
                        int i12 = i3 + 0;
                        path2.lineTo(fArr[i12], f27);
                        f30 = fArr[i12];
                    } else if (c5 == 'Q') {
                        i3 = i7;
                        fArr = fArr3;
                        c = c5;
                        i2 = i6;
                        int i13 = i3 + 0;
                        int i14 = i3 + 1;
                        int i15 = i3 + 2;
                        int i16 = i3 + 3;
                        path2.quadTo(fArr[i13], fArr[i14], fArr[i15], fArr[i16]);
                        float f32 = fArr[i13];
                        f29 = fArr[i14];
                        float f33 = fArr[i15];
                        f27 = fArr[i16];
                        f = f32;
                        f30 = f33;
                    } else if (c5 == 'V') {
                        i3 = i7;
                        fArr = fArr3;
                        c = c5;
                        i2 = i6;
                        int i17 = i3 + 0;
                        path2.lineTo(f30, fArr[i17]);
                        f27 = fArr[i17];
                    } else if (c5 != 'a') {
                        if (c5 != 'c') {
                            if (c5 == 'h') {
                                float f34 = f27;
                                i3 = i7;
                                int i18 = i3 + 0;
                                path2.rLineTo(fArr3[i18], 0.0f);
                                f30 += fArr3[i18];
                            } else if (c5 != 'q') {
                                if (c5 == 'v') {
                                    f10 = f30;
                                    f12 = f27;
                                    i3 = i7;
                                    int i19 = i3 + 0;
                                    path2.rLineTo(0.0f, fArr3[i19]);
                                    f11 = fArr3[i19];
                                } else if (c5 != 'L') {
                                    if (c5 == 'M') {
                                        i3 = i7;
                                        int i20 = i3 + 0;
                                        float f35 = fArr3[i20];
                                        int i21 = i3 + 1;
                                        f3 = fArr3[i21];
                                        if (i3 > 0) {
                                            path2.lineTo(fArr3[i20], fArr3[i21]);
                                            f30 = f35;
                                            f27 = f3;
                                        } else {
                                            path2.moveTo(fArr3[i20], fArr3[i21]);
                                            f25 = f35;
                                            f26 = f3;
                                        }
                                    } else if (c5 == 'S') {
                                        float f36 = f30;
                                        float f37 = f27;
                                        i5 = i7;
                                        if (c6 == 'c' || c6 == 's' || c6 == 'C' || c6 == 'S') {
                                            f14 = (f36 * 2.0f) - f;
                                            f13 = (f37 * 2.0f) - f29;
                                        } else {
                                            f13 = f37;
                                            f14 = f36;
                                        }
                                        int i22 = i5 + 0;
                                        int i23 = i5 + 1;
                                        int i24 = i5 + 2;
                                        int i25 = i5 + 3;
                                        path.cubicTo(f14, f13, fArr3[i22], fArr3[i23], fArr3[i24], fArr3[i25]);
                                        float f38 = fArr3[i22];
                                        f29 = fArr3[i23];
                                        f4 = fArr3[i24];
                                        f3 = fArr3[i25];
                                        f = f38;
                                        f30 = f4;
                                        f27 = f3;
                                    } else if (c5 == 'T') {
                                        float f39 = f30;
                                        float f40 = f27;
                                        i3 = i7;
                                        if (c6 == 'q' || c6 == 't' || c6 == 'Q' || c6 == 'T') {
                                            f39 = (f39 * 2.0f) - f;
                                            f40 = (f40 * 2.0f) - f29;
                                        }
                                        int i26 = i3 + 0;
                                        int i27 = i3 + 1;
                                        path2.quadTo(f39, f40, fArr3[i26], fArr3[i27]);
                                        f30 = fArr3[i26];
                                        f27 = fArr3[i27];
                                        f29 = f40;
                                        fArr = fArr3;
                                        c = c5;
                                        i2 = i6;
                                        f = f39;
                                    } else if (c5 == 'l') {
                                        f12 = f27;
                                        i3 = i7;
                                        int i28 = i3 + 0;
                                        int i29 = i3 + 1;
                                        path2.rLineTo(fArr3[i28], fArr3[i29]);
                                        float f41 = f30 + fArr3[i28];
                                        f11 = fArr3[i29];
                                        f10 = f41;
                                    } else if (c5 == c2) {
                                        i3 = i7;
                                        int i30 = i3 + 0;
                                        f30 += fArr3[i30];
                                        int i31 = i3 + 1;
                                        f27 += fArr3[i31];
                                        if (i3 > 0) {
                                            path2.rLineTo(fArr3[i30], fArr3[i31]);
                                        } else {
                                            path2.rMoveTo(fArr3[i30], fArr3[i31]);
                                            f25 = f30;
                                            f26 = f27;
                                        }
                                    } else if (c5 != 's') {
                                        if (c5 == 't') {
                                            if (c6 == 'q' || c6 == 't' || c6 == 'Q' || c6 == 'T') {
                                                f17 = f30 - f;
                                                f18 = f27 - f29;
                                            } else {
                                                f18 = 0.0f;
                                                f17 = 0;
                                            }
                                            int i32 = i7 + 0;
                                            int i33 = i7 + 1;
                                            path2.rQuadTo(f17, f18, fArr3[i32], fArr3[i33]);
                                            float f42 = f17 + f30;
                                            f29 = f18 + f27;
                                            f30 += fArr3[i32];
                                            f27 += fArr3[i33];
                                            f = f42;
                                        }
                                        i3 = i7;
                                    } else {
                                        if (c6 == 'c' || c6 == 's' || c6 == 'C' || c6 == 'S') {
                                            f16 = f30 - f;
                                            f15 = f27 - f29;
                                        } else {
                                            f16 = 0.0f;
                                            f15 = 0.0f;
                                        }
                                        int i34 = i7 + 0;
                                        int i35 = i7 + 1;
                                        int i36 = i7 + 2;
                                        int i37 = i7 + 3;
                                        float f43 = f30;
                                        f9 = f27;
                                        i5 = i7;
                                        path.rCubicTo(f16, f15, fArr3[i34], fArr3[i35], fArr3[i36], fArr3[i37]);
                                        f8 = fArr3[i34] + f43;
                                        f7 = fArr3[i35] + f9;
                                        f5 = f43 + fArr3[i36];
                                        f6 = fArr3[i37];
                                    }
                                    f30 = f25;
                                    f27 = f26;
                                } else {
                                    i3 = i7;
                                    int i38 = i3 + 0;
                                    int i39 = i3 + 1;
                                    path2.lineTo(fArr3[i38], fArr3[i39]);
                                    f30 = fArr3[i38];
                                    f27 = fArr3[i39];
                                }
                                f27 = f12 + f11;
                                f30 = f10;
                            } else {
                                float f44 = f30;
                                f9 = f27;
                                i5 = i7;
                                int i40 = i5 + 0;
                                int i41 = i5 + 1;
                                int i42 = i5 + 2;
                                int i43 = i5 + 3;
                                path2.rQuadTo(fArr3[i40], fArr3[i41], fArr3[i42], fArr3[i43]);
                                f8 = fArr3[i40] + f44;
                                f7 = fArr3[i41] + f9;
                                f5 = f44 + fArr3[i42];
                                f6 = fArr3[i43];
                            }
                            fArr = fArr3;
                            c = c5;
                            i2 = i6;
                        } else {
                            float f45 = f30;
                            f9 = f27;
                            i5 = i7;
                            int i44 = i5 + 2;
                            int i45 = i5 + 3;
                            int i46 = i5 + 4;
                            int i47 = i5 + 5;
                            path.rCubicTo(fArr3[i5 + 0], fArr3[i5 + 1], fArr3[i44], fArr3[i45], fArr3[i46], fArr3[i47]);
                            f8 = fArr3[i44] + f45;
                            f7 = fArr3[i45] + f9;
                            f5 = f45 + fArr3[i46];
                            f6 = fArr3[i47];
                        }
                        f3 = f6 + f9;
                        f = f8;
                        f29 = f7;
                        f4 = f5;
                        f30 = f4;
                        f27 = f3;
                        fArr = fArr3;
                        c = c5;
                        i2 = i6;
                    } else {
                        float f46 = f30;
                        float f47 = f27;
                        i4 = i7;
                        int i48 = i4 + 5;
                        float f48 = fArr3[i48] + f46;
                        int i49 = i4 + 6;
                        float f49 = fArr3[i49] + f47;
                        float f50 = fArr3[i4 + 0];
                        float f51 = fArr3[i4 + 1];
                        float f52 = fArr3[i4 + 2];
                        boolean z = fArr3[i4 + 3] != 0.0f;
                        boolean z2 = fArr3[i4 + 4] != 0.0f;
                        fArr = fArr3;
                        float f53 = f52;
                        c = c5;
                        i2 = i6;
                        m4507a(path, f46, f47, f48, f49, f50, f51, f53, z, z2);
                        f2 = f46 + fArr[i48];
                        f27 = f47 + fArr[i49];
                    }
                    i7 = i3 + i;
                    c2 = 'm';
                    C0664f6[] f6VarArr3 = f6VarArr;
                    c6 = c;
                    c5 = c6;
                    fArr3 = fArr;
                    i6 = i2;
                } else {
                    i4 = i7;
                    fArr = fArr3;
                    c = c5;
                    i2 = i6;
                    int i50 = i4 + 5;
                    int i51 = i4 + 6;
                    m4507a(path, f30, f27, fArr[i50], fArr[i51], fArr[i4 + 0], fArr[i4 + 1], fArr[i4 + 2], fArr[i4 + 3] != 0.0f, fArr[i4 + 4] != 0.0f);
                    f2 = fArr[i50];
                    f27 = fArr[i51];
                }
                f = f30;
                f29 = f27;
                i7 = i3 + i;
                c2 = 'm';
                C0664f6[] f6VarArr32 = f6VarArr;
                c6 = c;
                c5 = c6;
                fArr3 = fArr;
                i6 = i2;
            }
            int i52 = i6;
            fArr2[0] = f30;
            fArr2[1] = f27;
            fArr2[2] = f;
            fArr2[3] = f29;
            fArr2[4] = f25;
            fArr2[5] = f26;
            c4 = f6VarArr[i52].f5061a;
            i6 = i52 + 1;
            c2 = 'm';
            c3 = 0;
            f6VarArr2 = f6VarArr;
        }
    }
}
