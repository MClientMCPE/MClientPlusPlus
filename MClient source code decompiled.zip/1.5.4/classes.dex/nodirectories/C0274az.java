package p000;

import android.content.Context;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import p000.C1173kq;

/* renamed from: az */
public final class C0274az extends C1632pn<C0728fz> {
    public C0274az(Context context, Looper looper, C1173kq.C1174a aVar, C1173kq.C1175b bVar) {
        super(t80.m13184a(context), looper, 166, aVar, bVar);
    }

    /* renamed from: a */
    public final /* synthetic */ IInterface mo2201a(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.httpcache.IHttpAssetsCacheService");
        return queryLocalInterface instanceof C0728fz ? (C0728fz) queryLocalInterface : new C0977iz(iBinder);
    }

    /* renamed from: g */
    public final String mo2202g() {
        return "com.google.android.gms.ads.internal.httpcache.IHttpAssetsCacheService";
    }

    /* renamed from: h */
    public final String mo2203h() {
        return "com.google.android.gms.ads.service.HTTP";
    }

    /* renamed from: m */
    public final C0728fz mo2204m() {
        return (C0728fz) super.mo8080f();
    }
}
