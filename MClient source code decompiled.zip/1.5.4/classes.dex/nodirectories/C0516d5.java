package p000;

/* renamed from: d5 */
public class C0516d5<E> implements Cloneable {

    /* renamed from: b0 */
    public static final Object f3724b0 = new Object();

    /* renamed from: X */
    public boolean f3725X = false;

    /* renamed from: Y */
    public long[] f3726Y;

    /* renamed from: Z */
    public Object[] f3727Z;

    /* renamed from: a0 */
    public int f3728a0;

    public C0516d5() {
        int c = C0339c5.m2295c(10);
        this.f3726Y = new long[c];
        this.f3727Z = new Object[c];
    }

    /* renamed from: a */
    public long mo4660a(int i) {
        if (this.f3725X) {
            mo4666b();
        }
        return this.f3726Y[i];
    }

    /* renamed from: a */
    public E mo4661a(long j) {
        return mo4665b(j, (Object) null);
    }

    /* renamed from: a */
    public void mo4662a() {
        int i = this.f3728a0;
        Object[] objArr = this.f3727Z;
        for (int i2 = 0; i2 < i; i2++) {
            objArr[i2] = null;
        }
        this.f3728a0 = 0;
        this.f3725X = false;
    }

    /* renamed from: a */
    public void mo4663a(long j, E e) {
        int i = this.f3728a0;
        if (i == 0 || j > this.f3726Y[i - 1]) {
            if (this.f3725X && this.f3728a0 >= this.f3726Y.length) {
                mo4666b();
            }
            int i2 = this.f3728a0;
            if (i2 >= this.f3726Y.length) {
                int c = C0339c5.m2295c(i2 + 1);
                long[] jArr = new long[c];
                Object[] objArr = new Object[c];
                long[] jArr2 = this.f3726Y;
                System.arraycopy(jArr2, 0, jArr, 0, jArr2.length);
                Object[] objArr2 = this.f3727Z;
                System.arraycopy(objArr2, 0, objArr, 0, objArr2.length);
                this.f3726Y = jArr;
                this.f3727Z = objArr;
            }
            this.f3726Y[i2] = j;
            this.f3727Z[i2] = e;
            this.f3728a0 = i2 + 1;
            return;
        }
        mo4668c(j, e);
    }

    /* renamed from: b */
    public E mo4664b(int i) {
        if (this.f3725X) {
            mo4666b();
        }
        return this.f3727Z[i];
    }

    /* renamed from: b */
    public E mo4665b(long j, E e) {
        int a = C0339c5.m2292a(this.f3726Y, this.f3728a0, j);
        if (a >= 0) {
            E[] eArr = this.f3727Z;
            if (eArr[a] != f3724b0) {
                return eArr[a];
            }
        }
        return e;
    }

    /* renamed from: b */
    public final void mo4666b() {
        int i = this.f3728a0;
        long[] jArr = this.f3726Y;
        Object[] objArr = this.f3727Z;
        int i2 = 0;
        for (int i3 = 0; i3 < i; i3++) {
            Object obj = objArr[i3];
            if (obj != f3724b0) {
                if (i3 != i2) {
                    jArr[i2] = jArr[i3];
                    objArr[i2] = obj;
                    objArr[i3] = null;
                }
                i2++;
            }
        }
        this.f3725X = false;
        this.f3728a0 = i2;
    }

    /* renamed from: c */
    public int mo4667c() {
        if (this.f3725X) {
            mo4666b();
        }
        return this.f3728a0;
    }

    /* renamed from: c */
    public void mo4668c(long j, E e) {
        int a = C0339c5.m2292a(this.f3726Y, this.f3728a0, j);
        if (a >= 0) {
            this.f3727Z[a] = e;
            return;
        }
        int i = a ^ -1;
        if (i < this.f3728a0) {
            Object[] objArr = this.f3727Z;
            if (objArr[i] == f3724b0) {
                this.f3726Y[i] = j;
                objArr[i] = e;
                return;
            }
        }
        if (this.f3725X && this.f3728a0 >= this.f3726Y.length) {
            mo4666b();
            i = C0339c5.m2292a(this.f3726Y, this.f3728a0, j) ^ -1;
        }
        int i2 = this.f3728a0;
        if (i2 >= this.f3726Y.length) {
            int c = C0339c5.m2295c(i2 + 1);
            long[] jArr = new long[c];
            Object[] objArr2 = new Object[c];
            long[] jArr2 = this.f3726Y;
            System.arraycopy(jArr2, 0, jArr, 0, jArr2.length);
            Object[] objArr3 = this.f3727Z;
            System.arraycopy(objArr3, 0, objArr2, 0, objArr3.length);
            this.f3726Y = jArr;
            this.f3727Z = objArr2;
        }
        int i3 = this.f3728a0;
        if (i3 - i != 0) {
            long[] jArr3 = this.f3726Y;
            int i4 = i + 1;
            System.arraycopy(jArr3, i, jArr3, i4, i3 - i);
            Object[] objArr4 = this.f3727Z;
            System.arraycopy(objArr4, i, objArr4, i4, this.f3728a0 - i);
        }
        this.f3726Y[i] = j;
        this.f3727Z[i] = e;
        this.f3728a0++;
    }

    public C0516d5<E> clone() {
        try {
            C0516d5<E> d5Var = (C0516d5) super.clone();
            d5Var.f3726Y = (long[]) this.f3726Y.clone();
            d5Var.f3727Z = (Object[]) this.f3727Z.clone();
            return d5Var;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError(e);
        }
    }

    public String toString() {
        if (mo4667c() <= 0) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.f3728a0 * 28);
        sb.append('{');
        for (int i = 0; i < this.f3728a0; i++) {
            if (i > 0) {
                sb.append(", ");
            }
            if (this.f3725X) {
                mo4666b();
            }
            sb.append(this.f3726Y[i]);
            sb.append('=');
            Object b = mo4664b(i);
            if (b != this) {
                sb.append(b);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }
}
