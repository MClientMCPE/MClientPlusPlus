package p000;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import java.util.Collections;
import java.util.List;

/* renamed from: er */
public class C0622er {

    /* renamed from: a */
    public static final Object f4770a = new Object();

    /* renamed from: b */
    public static volatile C0622er f4771b;

    public C0622er() {
        List list = Collections.EMPTY_LIST;
    }

    /* renamed from: a */
    public static C0622er m4272a() {
        if (f4771b == null) {
            synchronized (f4770a) {
                if (f4771b == null) {
                    f4771b = new C0622er();
                }
            }
        }
        return f4771b;
    }

    @SuppressLint({"UntrackedBindService"})
    /* renamed from: a */
    public void mo5223a(Context context, ServiceConnection serviceConnection) {
        context.unbindService(serviceConnection);
    }

    /* renamed from: a */
    public boolean mo5224a(Context context, Intent intent, ServiceConnection serviceConnection, int i) {
        context.getClass().getName();
        return mo5225b(context, intent, serviceConnection, i);
    }

    /* JADX WARNING: Removed duplicated region for block: B:11:0x002a  */
    /* JADX WARNING: Removed duplicated region for block: B:13:0x0032  */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean mo5225b(android.content.Context r4, android.content.Intent r5, android.content.ServiceConnection r6, int r7) {
        /*
            r3 = this;
            android.content.ComponentName r0 = r5.getComponent()
            r1 = 0
            if (r0 != 0) goto L_0x0009
        L_0x0007:
            r0 = 0
            goto L_0x0028
        L_0x0009:
            java.lang.String r0 = r0.getPackageName()
            java.lang.String r2 = "com.google.android.gms"
            r2.equals(r0)
            lr r2 = p000.C1351mr.m9516b(r4)     // Catch:{ NameNotFoundException -> 0x0007 }
            android.content.Context r2 = r2.f9770a     // Catch:{ NameNotFoundException -> 0x0007 }
            android.content.pm.PackageManager r2 = r2.getPackageManager()     // Catch:{ NameNotFoundException -> 0x0007 }
            android.content.pm.ApplicationInfo r0 = r2.getApplicationInfo(r0, r1)     // Catch:{ NameNotFoundException -> 0x0007 }
            int r0 = r0.flags     // Catch:{ NameNotFoundException -> 0x0007 }
            r2 = 2097152(0x200000, float:2.938736E-39)
            r0 = r0 & r2
            if (r0 == 0) goto L_0x0007
            r0 = 1
        L_0x0028:
            if (r0 == 0) goto L_0x0032
            java.lang.String r4 = "ConnectionTracker"
            java.lang.String r5 = "Attempted to bind to a service in a STOPPED package."
            android.util.Log.w(r4, r5)
            return r1
        L_0x0032:
            boolean r4 = r4.bindService(r5, r6, r7)
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0622er.mo5225b(android.content.Context, android.content.Intent, android.content.ServiceConnection, int):boolean");
    }
}
