package p000;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.widget.CompoundButton;

/* renamed from: g2 */
public class C0747g2 {

    /* renamed from: a */
    public final CompoundButton f5903a;

    /* renamed from: b */
    public ColorStateList f5904b = null;

    /* renamed from: c */
    public PorterDuff.Mode f5905c = null;

    /* renamed from: d */
    public boolean f5906d = false;

    /* renamed from: e */
    public boolean f5907e = false;

    /* renamed from: f */
    public boolean f5908f;

    public C0747g2(CompoundButton compoundButton) {
        this.f5903a = compoundButton;
    }

    /* renamed from: a */
    public void mo5861a() {
        Drawable a = C0815h0.m5785a(this.f5903a);
        if (a == null) {
            return;
        }
        if (this.f5906d || this.f5907e) {
            Drawable mutate = C0815h0.m5858e(a).mutate();
            if (this.f5906d) {
                C0815h0.m5802a(mutate, this.f5904b);
            }
            if (this.f5907e) {
                C0815h0.m5803a(mutate, this.f5905c);
            }
            if (mutate.isStateful()) {
                mutate.setState(this.f5903a.getDrawableState());
            }
            this.f5903a.setButtonDrawable(mutate);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x0031 A[SYNTHETIC, Splitter:B:12:0x0031] */
    /* JADX WARNING: Removed duplicated region for block: B:20:0x0058 A[Catch:{ all -> 0x0090 }] */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x006b A[Catch:{ all -> 0x0090 }] */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo5862a(android.util.AttributeSet r4, int r5) {
        /*
            r3 = this;
            android.widget.CompoundButton r0 = r3.f5903a
            android.content.Context r0 = r0.getContext()
            int[] r1 = p000.C1292m.CompoundButton
            r2 = 0
            android.content.res.TypedArray r4 = r0.obtainStyledAttributes(r4, r1, r5, r2)
            int r5 = p000.C1292m.CompoundButton_buttonCompat     // Catch:{ all -> 0x0090 }
            boolean r5 = r4.hasValue(r5)     // Catch:{ all -> 0x0090 }
            if (r5 == 0) goto L_0x002e
            int r5 = p000.C1292m.CompoundButton_buttonCompat     // Catch:{ all -> 0x0090 }
            int r5 = r4.getResourceId(r5, r2)     // Catch:{ all -> 0x0090 }
            if (r5 == 0) goto L_0x002e
            android.widget.CompoundButton r0 = r3.f5903a     // Catch:{ NotFoundException -> 0x002e }
            android.widget.CompoundButton r1 = r3.f5903a     // Catch:{ NotFoundException -> 0x002e }
            android.content.Context r1 = r1.getContext()     // Catch:{ NotFoundException -> 0x002e }
            android.graphics.drawable.Drawable r5 = p000.C1206l0.m8461c(r1, r5)     // Catch:{ NotFoundException -> 0x002e }
            r0.setButtonDrawable(r5)     // Catch:{ NotFoundException -> 0x002e }
            r5 = 1
            goto L_0x002f
        L_0x002e:
            r5 = 0
        L_0x002f:
            if (r5 != 0) goto L_0x0050
            int r5 = p000.C1292m.CompoundButton_android_button     // Catch:{ all -> 0x0090 }
            boolean r5 = r4.hasValue(r5)     // Catch:{ all -> 0x0090 }
            if (r5 == 0) goto L_0x0050
            int r5 = p000.C1292m.CompoundButton_android_button     // Catch:{ all -> 0x0090 }
            int r5 = r4.getResourceId(r5, r2)     // Catch:{ all -> 0x0090 }
            if (r5 == 0) goto L_0x0050
            android.widget.CompoundButton r0 = r3.f5903a     // Catch:{ all -> 0x0090 }
            android.widget.CompoundButton r1 = r3.f5903a     // Catch:{ all -> 0x0090 }
            android.content.Context r1 = r1.getContext()     // Catch:{ all -> 0x0090 }
            android.graphics.drawable.Drawable r5 = p000.C1206l0.m8461c(r1, r5)     // Catch:{ all -> 0x0090 }
            r0.setButtonDrawable(r5)     // Catch:{ all -> 0x0090 }
        L_0x0050:
            int r5 = p000.C1292m.CompoundButton_buttonTint     // Catch:{ all -> 0x0090 }
            boolean r5 = r4.hasValue(r5)     // Catch:{ all -> 0x0090 }
            if (r5 == 0) goto L_0x0063
            android.widget.CompoundButton r5 = r3.f5903a     // Catch:{ all -> 0x0090 }
            int r0 = p000.C1292m.CompoundButton_buttonTint     // Catch:{ all -> 0x0090 }
            android.content.res.ColorStateList r0 = r4.getColorStateList(r0)     // Catch:{ all -> 0x0090 }
            p000.C0815h0.m5807a((android.widget.CompoundButton) r5, (android.content.res.ColorStateList) r0)     // Catch:{ all -> 0x0090 }
        L_0x0063:
            int r5 = p000.C1292m.CompoundButton_buttonTintMode     // Catch:{ all -> 0x0090 }
            boolean r5 = r4.hasValue(r5)     // Catch:{ all -> 0x0090 }
            if (r5 == 0) goto L_0x008c
            android.widget.CompoundButton r5 = r3.f5903a     // Catch:{ all -> 0x0090 }
            int r0 = p000.C1292m.CompoundButton_buttonTintMode     // Catch:{ all -> 0x0090 }
            r1 = -1
            int r0 = r4.getInt(r0, r1)     // Catch:{ all -> 0x0090 }
            r1 = 0
            android.graphics.PorterDuff$Mode r0 = p000.C0279b3.m1705a(r0, r1)     // Catch:{ all -> 0x0090 }
            int r1 = android.os.Build.VERSION.SDK_INT     // Catch:{ all -> 0x0090 }
            r2 = 21
            if (r1 < r2) goto L_0x0083
            r5.setButtonTintMode(r0)     // Catch:{ all -> 0x0090 }
            goto L_0x008c
        L_0x0083:
            boolean r1 = r5 instanceof p000.C1405n8     // Catch:{ all -> 0x0090 }
            if (r1 == 0) goto L_0x008c
            n8 r5 = (p000.C1405n8) r5     // Catch:{ all -> 0x0090 }
            r5.setSupportButtonTintMode(r0)     // Catch:{ all -> 0x0090 }
        L_0x008c:
            r4.recycle()
            return
        L_0x0090:
            r5 = move-exception
            r4.recycle()
            throw r5
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0747g2.mo5862a(android.util.AttributeSet, int):void");
    }
}
