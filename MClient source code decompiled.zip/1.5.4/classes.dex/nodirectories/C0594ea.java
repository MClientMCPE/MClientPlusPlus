package p000;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import androidx.fragment.app.Fragment;

/* renamed from: ea */
public abstract class C0594ea {
    /* renamed from: a */
    public abstract View mo1476a(int i);

    @Deprecated
    /* renamed from: a */
    public Fragment mo5067a(Context context, String str, Bundle bundle) {
        return Fragment.m947a(context, str, bundle);
    }

    /* renamed from: c */
    public abstract boolean mo1477c();
}
