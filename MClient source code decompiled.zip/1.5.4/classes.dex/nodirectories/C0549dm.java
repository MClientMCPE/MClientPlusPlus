package p000;

import android.os.RemoteException;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import p000.C0379cm;

/* renamed from: dm */
public final class C0549dm extends FrameLayout {

    /* renamed from: a0 */
    public final FrameLayout f3968a0;

    /* renamed from: b0 */
    public final C1647pv f3969b0;

    /* renamed from: a */
    public final View mo4834a(String str) {
        try {
            return (View) C2298xr.m15922z(((t31) this.f3969b0).mo11131o(str));
        } catch (RemoteException e) {
            C0680fe.m4830c("Unable to call getAssetView on delegate", (Throwable) e);
            return null;
        }
    }

    /* renamed from: a */
    public final /* synthetic */ void mo4835a(ImageView.ScaleType scaleType) {
        try {
            if (scaleType instanceof ImageView.ScaleType) {
                ((t31) this.f3969b0).mo11125C(new C2298xr(scaleType));
            }
        } catch (RemoteException e) {
            C0680fe.m4830c("Unable to call setMediaViewImageScaleType on delegate", (Throwable) e);
        }
    }

    public final void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        super.addView(view, i, layoutParams);
        super.bringChildToFront(this.f3968a0);
    }

    public final void bringChildToFront(View view) {
        super.bringChildToFront(view);
        FrameLayout frameLayout = this.f3968a0;
        if (frameLayout != view) {
            super.bringChildToFront(frameLayout);
        }
    }

    public final boolean dispatchTouchEvent(MotionEvent motionEvent) {
        C1647pv pvVar;
        if (((Boolean) kw2.f9317j.f9323f.mo4518a(g03.f5771i1)).booleanValue() && (pvVar = this.f3969b0) != null) {
            try {
                ((t31) pvVar).mo11124B(new C2298xr(motionEvent));
            } catch (RemoteException e) {
                C0680fe.m4830c("Unable to call handleTouchEvent on delegate", (Throwable) e);
            }
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    public final C1868sl getAdChoicesView() {
        View a = mo4834a("3011");
        if (a instanceof C1868sl) {
            return (C1868sl) a;
        }
        return null;
    }

    public final View getAdvertiserView() {
        return mo4834a("3005");
    }

    public final View getBodyView() {
        return mo4834a("3004");
    }

    public final View getCallToActionView() {
        return mo4834a("3002");
    }

    public final View getHeadlineView() {
        return mo4834a("3001");
    }

    public final View getIconView() {
        return mo4834a("3003");
    }

    public final View getImageView() {
        return mo4834a("3008");
    }

    public final C1933tl getMediaView() {
        View a = mo4834a("3010");
        if (a instanceof C1933tl) {
            return (C1933tl) a;
        }
        if (a == null) {
            return null;
        }
        C0680fe.m4886l("View is not an instance of MediaView");
        return null;
    }

    public final View getPriceView() {
        return mo4834a("3007");
    }

    public final View getStarRatingView() {
        return mo4834a("3009");
    }

    public final View getStoreView() {
        return mo4834a("3006");
    }

    public final void onVisibilityChanged(View view, int i) {
        super.onVisibilityChanged(view, i);
        C1647pv pvVar = this.f3969b0;
        if (pvVar != null) {
            try {
                ((t31) pvVar).mo11128d(new C2298xr(view), i);
            } catch (RemoteException e) {
                C0680fe.m4830c("Unable to call onVisibilityChanged on delegate", (Throwable) e);
            }
        }
    }

    public final void removeAllViews() {
        super.removeAllViews();
        super.addView(this.f3968a0);
    }

    public final void removeView(View view) {
        if (this.f3968a0 != view) {
            super.removeView(view);
        }
    }

    public final void setAdChoicesView(C1868sl slVar) {
        mo4837a("3011", slVar);
    }

    public final void setAdvertiserView(View view) {
        mo4837a("3005", view);
    }

    public final void setBodyView(View view) {
        mo4837a("3004", view);
    }

    public final void setCallToActionView(View view) {
        mo4837a("3002", view);
    }

    public final void setClickConfirmingView(View view) {
        try {
            ((t31) this.f3969b0).mo11123A(new C2298xr(view));
        } catch (RemoteException e) {
            C0680fe.m4830c("Unable to call setClickConfirmingView on delegate", (Throwable) e);
        }
    }

    public final void setHeadlineView(View view) {
        mo4837a("3001", view);
    }

    public final void setIconView(View view) {
        mo4837a("3003", view);
    }

    public final void setImageView(View view) {
        mo4837a("3008", view);
    }

    public final void setMediaView(C1933tl tlVar) {
        mo4837a("3010", tlVar);
        if (tlVar != null) {
            tlVar.mo11327a((C2306xu) new C0872hm(this));
            tlVar.mo11328a((C2473zu) new C0792gm(this));
        }
    }

    public final void setNativeAd(C0379cm cmVar) {
        try {
            ((t31) this.f3969b0).mo11136z((C2232wr) cmVar.mo2970b());
        } catch (RemoteException e) {
            C0680fe.m4830c("Unable to call setNativeAd on delegate", (Throwable) e);
        }
    }

    public final void setPriceView(View view) {
        mo4837a("3007", view);
    }

    public final void setStarRatingView(View view) {
        mo4837a("3009", view);
    }

    public final void setStoreView(View view) {
        mo4837a("3006", view);
    }

    /* renamed from: a */
    public final /* synthetic */ void mo4836a(C0379cm.C0380a aVar) {
        try {
            if (aVar instanceof C1278lx) {
                ((t31) this.f3969b0).mo11126a(((C1278lx) aVar).f9833a);
            } else if (aVar == null) {
                ((t31) this.f3969b0).mo11126a((C0972iv) null);
            } else {
                C0680fe.m4886l("Use MediaContent provided by UnifiedNativeAd.getMediaContent");
            }
        } catch (RemoteException e) {
            C0680fe.m4830c("Unable to call setMediaContent on delegate", (Throwable) e);
        }
    }

    /* renamed from: a */
    public final void mo4837a(String str, View view) {
        try {
            ((t31) this.f3969b0).mo11127b(str, new C2298xr(view));
        } catch (RemoteException e) {
            C0680fe.m4830c("Unable to call setAssetView on delegate", (Throwable) e);
        }
    }
}
