package p000;

/* renamed from: e7 */
public class C0590e7<T> {

    /* renamed from: a */
    public final Object[] f4312a;

    /* renamed from: b */
    public int f4313b;

    public C0590e7(int i) {
        if (i > 0) {
            this.f4312a = new Object[i];
            return;
        }
        throw new IllegalArgumentException("The max pool size must be > 0");
    }

    /* renamed from: a */
    public T mo5048a() {
        int i = this.f4313b;
        if (i <= 0) {
            return null;
        }
        int i2 = i - 1;
        T[] tArr = this.f4312a;
        T t = tArr[i2];
        tArr[i2] = null;
        this.f4313b = i - 1;
        return t;
    }

    /* renamed from: a */
    public boolean mo5049a(T t) {
        boolean z;
        int i = 0;
        while (true) {
            if (i >= this.f4313b) {
                z = false;
                break;
            } else if (this.f4312a[i] == t) {
                z = true;
                break;
            } else {
                i++;
            }
        }
        if (!z) {
            int i2 = this.f4313b;
            Object[] objArr = this.f4312a;
            if (i2 >= objArr.length) {
                return false;
            }
            objArr[i2] = t;
            this.f4313b = i2 + 1;
            return true;
        }
        throw new IllegalStateException("Already in the pool!");
    }
}
