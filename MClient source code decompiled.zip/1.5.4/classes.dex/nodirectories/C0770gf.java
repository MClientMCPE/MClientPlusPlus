package p000;

/* renamed from: gf */
public interface C0770gf<T> {
    /* renamed from: a */
    void mo6077a(T t);
}
