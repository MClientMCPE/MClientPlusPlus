package p000;

import android.content.Context;
import android.content.res.Resources;
import android.text.TextUtils;
import com.google.android.gms.common.api.Status;

@Deprecated
/* renamed from: eq */
public final class C0621eq {

    /* renamed from: c */
    public static final Object f4751c = new Object();

    /* renamed from: d */
    public static C0621eq f4752d;

    /* renamed from: a */
    public final String f4753a;

    /* renamed from: b */
    public final Status f4754b;

    public C0621eq(Context context) {
        Resources resources = context.getResources();
        int identifier = resources.getIdentifier("google_app_measurement_enable", "integer", resources.getResourcePackageName(C0491cq.common_google_play_services_unknown_issue));
        if (identifier != 0) {
            resources.getInteger(identifier);
        }
        C0492cr.m3245a(context);
        String str = C0492cr.f3504c;
        if (str == null) {
            C0680fe.m4695a(context);
            Resources resources2 = context.getResources();
            int identifier2 = resources2.getIdentifier("google_app_id", "string", resources2.getResourcePackageName(C0491cq.common_google_play_services_unknown_issue));
            str = identifier2 == 0 ? null : resources2.getString(identifier2);
        }
        if (TextUtils.isEmpty(str)) {
            this.f4754b = new Status(10, "Missing google app id value from from string resources with name google_app_id.");
            this.f4753a = null;
            return;
        }
        this.f4753a = str;
        this.f4754b = Status.f2957b0;
    }

    /* renamed from: a */
    public static Status m4268a(Context context) {
        Status status;
        C0680fe.m4697a(context, (Object) "Context must not be null.");
        synchronized (f4751c) {
            if (f4752d == null) {
                f4752d = new C0621eq(context);
            }
            status = f4752d.f4754b;
        }
        return status;
    }

    /* renamed from: a */
    public static C0621eq m4269a(String str) {
        C0621eq eqVar;
        synchronized (f4751c) {
            if (f4752d != null) {
                eqVar = f4752d;
            } else {
                StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 34);
                sb.append("Initialize must be called before ");
                sb.append(str);
                sb.append(".");
                throw new IllegalStateException(sb.toString());
            }
        }
        return eqVar;
    }
}
