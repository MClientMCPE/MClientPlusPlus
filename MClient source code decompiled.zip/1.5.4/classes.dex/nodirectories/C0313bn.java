package p000;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel;

/* renamed from: bn */
public final class C0313bn {
    /* renamed from: a */
    public static void m2070a(Context context, AdOverlayInfoParcel adOverlayInfoParcel, boolean z) {
        if (adOverlayInfoParcel.f2945h0 == 4 && adOverlayInfoParcel.f2937Z == null) {
            iv2 iv2 = adOverlayInfoParcel.f2936Y;
            if (iv2 != null) {
                iv2.mo2882k();
            }
            C1631pm pmVar = C0619eo.f4708B.f4710a;
            C1631pm.m11279a(context, adOverlayInfoParcel.f2935X, adOverlayInfoParcel.f2943f0);
            return;
        }
        Intent intent = new Intent();
        intent.setClassName(context, "com.google.android.gms.ads.AdActivity");
        intent.putExtra("com.google.android.gms.ads.internal.overlay.useClientJar", adOverlayInfoParcel.f2947j0.f11065a0);
        intent.putExtra("shouldCallOnOverlayOpened", z);
        Bundle bundle = new Bundle(1);
        bundle.putParcelable("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo", adOverlayInfoParcel);
        intent.putExtra("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo", bundle);
        if (!C0680fe.m4865f()) {
            intent.addFlags(524288);
        }
        if (!(context instanceof Activity)) {
            intent.addFlags(268435456);
        }
        xc0 xc0 = C0619eo.f4708B.f4712c;
        xc0.m15635a(context, intent);
    }
}
