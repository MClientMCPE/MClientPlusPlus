package p000;

import androidx.appcompat.widget.ContentFrameLayout;

/* renamed from: d0 */
public class C0503d0 implements ContentFrameLayout.C0143a {

    /* renamed from: a */
    public final /* synthetic */ C0011a0 f3611a;

    public C0503d0(C0011a0 a0Var) {
        this.f3611a = a0Var;
    }

    /* renamed from: a */
    public void mo4516a() {
    }
}
