package p000;

import java.math.BigDecimal;
import org.json.JSONObject;

/* renamed from: ch */
public class C0373ch implements C1616pf {

    /* renamed from: a */
    public final /* synthetic */ C0302bh f2706a;

    /* renamed from: ch$a */
    public class C0374a implements Runnable {

        /* renamed from: X */
        public final /* synthetic */ String f2707X;

        /* renamed from: Y */
        public final /* synthetic */ String f2708Y;

        /* renamed from: Z */
        public final /* synthetic */ float f2709Z;

        public C0374a(String str, String str2, float f) {
            this.f2707X = str;
            this.f2708Y = str2;
            this.f2709Z = f;
        }

        public void run() {
            C0302bh omidManager;
            if (this.f2707X.equals(C0373ch.this.f2706a.f1950o)) {
                omidManager = C0373ch.this.f2706a;
            } else {
                C1247lf lfVar = C0680fe.m4730a().mo11965f().f11074d.get(this.f2707X);
                omidManager = lfVar != null ? lfVar.getOmidManager() : null;
                if (omidManager == null) {
                    return;
                }
            }
            omidManager.mo2532a(this.f2708Y, this.f2709Z);
        }
    }

    public C0373ch(C0302bh bhVar) {
        this.f2706a = bhVar;
    }

    /* renamed from: a */
    public void mo2933a(C1527of ofVar) {
        JSONObject a = C0680fe.m4721a(ofVar.f11888a, (String) null);
        String optString = a.optString("event_type");
        float floatValue = BigDecimal.valueOf(a.optDouble("duration", 0.0d)).floatValue();
        boolean optBoolean = a.optBoolean("replay");
        boolean equals = a.optString("skip_type").equals("dec");
        String optString2 = a.optString("asi");
        if (optString.equals("skip") && equals) {
            this.f2706a.f1946k = true;
        } else if (!optBoolean || (!optString.equals("start") && !optString.equals("first_quartile") && !optString.equals("midpoint") && !optString.equals("third_quartile") && !optString.equals("complete"))) {
            C1062ji.m7720a((Runnable) new C0374a(optString2, optString, floatValue));
        }
    }
}
