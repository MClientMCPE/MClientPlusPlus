package p000;

/* renamed from: a7 */
public final class C0045a7 {

    /* renamed from: a */
    public static final C2404z6 f224a = new C0050e((C0048c) null, false);

    /* renamed from: b */
    public static final C2404z6 f225b = new C0050e((C0048c) null, true);

    /* renamed from: c */
    public static final C2404z6 f226c = new C0050e(C0047b.f230a, false);

    /* renamed from: d */
    public static final C2404z6 f227d = new C0050e(C0047b.f230a, true);

    /* renamed from: a7$a */
    public static class C0046a implements C0048c {

        /* renamed from: b */
        public static final C0046a f228b = new C0046a(true);

        /* renamed from: a */
        public final boolean f229a;

        public C0046a(boolean z) {
            this.f229a = z;
        }

        /* renamed from: a */
        public int mo246a(CharSequence charSequence, int i, int i2) {
            int i3 = i2 + i;
            boolean z = false;
            while (i < i3) {
                int a = C0045a7.m254a(Character.getDirectionality(charSequence.charAt(i)));
                if (a != 0) {
                    if (a != 1) {
                        continue;
                        i++;
                    } else if (!this.f229a) {
                        return 1;
                    }
                } else if (this.f229a) {
                    return 0;
                }
                z = true;
                i++;
            }
            if (z) {
                return this.f229a ? 1 : 0;
            }
            return 2;
        }
    }

    /* renamed from: a7$b */
    public static class C0047b implements C0048c {

        /* renamed from: a */
        public static final C0047b f230a = new C0047b();

        /* renamed from: a */
        public int mo246a(CharSequence charSequence, int i, int i2) {
            int i3 = i2 + i;
            int i4 = 2;
            while (i < i3 && i4 == 2) {
                i4 = C0045a7.m255b(Character.getDirectionality(charSequence.charAt(i)));
                i++;
            }
            return i4;
        }
    }

    /* renamed from: a7$c */
    public interface C0048c {
        /* renamed from: a */
        int mo246a(CharSequence charSequence, int i, int i2);
    }

    /* renamed from: a7$d */
    public static abstract class C0049d implements C2404z6 {

        /* renamed from: a */
        public final C0048c f231a;

        public C0049d(C0048c cVar) {
            this.f231a = cVar;
        }

        /* renamed from: a */
        public abstract boolean mo247a();

        /* renamed from: a */
        public boolean mo248a(CharSequence charSequence, int i, int i2) {
            if (charSequence == null || i < 0 || i2 < 0 || charSequence.length() - i2 < i) {
                throw new IllegalArgumentException();
            }
            C0048c cVar = this.f231a;
            if (cVar == null) {
                return mo247a();
            }
            int a = cVar.mo246a(charSequence, i, i2);
            if (a == 0) {
                return true;
            }
            if (a != 1) {
                return mo247a();
            }
            return false;
        }
    }

    /* renamed from: a7$e */
    public static class C0050e extends C0049d {

        /* renamed from: b */
        public final boolean f232b;

        public C0050e(C0048c cVar, boolean z) {
            super(cVar);
            this.f232b = z;
        }

        /* renamed from: a */
        public boolean mo247a() {
            return this.f232b;
        }
    }

    static {
        C0046a aVar = C0046a.f228b;
    }

    /* renamed from: a */
    public static int m254a(int i) {
        if (i != 0) {
            return (i == 1 || i == 2) ? 0 : 2;
        }
        return 1;
    }

    /* renamed from: b */
    public static int m255b(int i) {
        if (i != 0) {
            if (i == 1 || i == 2) {
                return 0;
            }
            switch (i) {
                case 14:
                case 15:
                    break;
                case 16:
                case 17:
                    return 0;
                default:
                    return 2;
            }
        }
        return 1;
    }
}
