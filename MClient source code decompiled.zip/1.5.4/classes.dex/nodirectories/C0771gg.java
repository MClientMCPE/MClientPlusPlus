package p000;

import android.view.View;

/* renamed from: gg */
public class C0771gg implements C1617pg {

    /* renamed from: a */
    public final /* synthetic */ C1335mg f6110a;

    public C0771gg(C1335mg mgVar) {
        this.f6110a = mgVar;
    }

    /* renamed from: a */
    public void mo532a(C1249lg lgVar) {
        if (this.f6110a.mo8736i(lgVar)) {
            C1335mg mgVar = this.f6110a;
            View b = mgVar.mo8729b(lgVar);
            ic3 ic3 = ic3.OTHER;
            dc3 dc3 = mgVar.f10234x0;
            if (dc3 != null) {
                try {
                    dc3.mo4737a(b, ic3, (String) null);
                } catch (RuntimeException unused) {
                }
            }
        }
    }
}
