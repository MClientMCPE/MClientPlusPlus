package p000;

/* renamed from: fg */
public class C0692fg implements C1617pg {

    /* renamed from: a */
    public final /* synthetic */ C1335mg f5335a;

    /* renamed from: fg$a */
    public class C0693a implements Runnable {

        /* renamed from: X */
        public final /* synthetic */ C1249lg f5336X;

        public C0693a(C1249lg lgVar) {
            this.f5336X = lgVar;
        }

        public void run() {
            C0692fg.this.f5335a.mo8735h(this.f5336X);
        }
    }

    public C0692fg(C1335mg mgVar) {
        this.f5335a = mgVar;
    }

    /* renamed from: a */
    public void mo532a(C1249lg lgVar) {
        if (this.f5335a.mo8736i(lgVar)) {
            C1062ji.m7720a((Runnable) new C0693a(lgVar));
        }
    }
}
