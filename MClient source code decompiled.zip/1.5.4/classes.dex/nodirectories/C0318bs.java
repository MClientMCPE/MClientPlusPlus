package p000;

import android.content.Context;
import com.google.android.gms.dynamite.DynamiteModule;

/* renamed from: bs */
public final class C0318bs implements DynamiteModule.C0408b {
    /* renamed from: a */
    public final DynamiteModule.C0408b.C0410b mo2131a(Context context, String str, DynamiteModule.C0408b.C0409a aVar) {
        DynamiteModule.C0408b.C0410b bVar = new DynamiteModule.C0408b.C0410b();
        bVar.f2973a = aVar.mo3272a(context, str);
        if (bVar.f2973a != 0) {
            bVar.f2975c = -1;
        } else {
            bVar.f2974b = aVar.mo3273a(context, str, true);
            if (bVar.f2974b != 0) {
                bVar.f2975c = 1;
            }
        }
        return bVar;
    }
}
