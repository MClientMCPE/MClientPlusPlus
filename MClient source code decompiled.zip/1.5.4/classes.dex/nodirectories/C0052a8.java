package p000;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.os.Build;
import android.view.View;
import java.lang.ref.WeakReference;

/* renamed from: a8 */
public final class C0052a8 {

    /* renamed from: a */
    public WeakReference<View> f239a;

    /* renamed from: b */
    public Runnable f240b = null;

    /* renamed from: c */
    public Runnable f241c = null;

    /* renamed from: d */
    public int f242d = -1;

    /* renamed from: a8$a */
    public class C0053a extends AnimatorListenerAdapter {

        /* renamed from: a */
        public final /* synthetic */ C0286b8 f243a;

        /* renamed from: b */
        public final /* synthetic */ View f244b;

        public C0053a(C0052a8 a8Var, C0286b8 b8Var, View view) {
            this.f243a = b8Var;
            this.f244b = view;
        }

        public void onAnimationCancel(Animator animator) {
            this.f243a.mo172a(this.f244b);
        }

        public void onAnimationEnd(Animator animator) {
            this.f243a.mo61b(this.f244b);
        }

        public void onAnimationStart(Animator animator) {
            this.f243a.mo173c(this.f244b);
        }
    }

    /* renamed from: a8$b */
    public class C0054b implements ValueAnimator.AnimatorUpdateListener {

        /* renamed from: a */
        public final /* synthetic */ C0522d8 f245a;

        /* renamed from: b */
        public final /* synthetic */ View f246b;

        public C0054b(C0052a8 a8Var, C0522d8 d8Var, View view) {
            this.f245a = d8Var;
            this.f246b = view;
        }

        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            ((View) C1110k0.this.f8734d.getParent()).invalidate();
        }
    }

    public C0052a8(View view) {
        this.f239a = new WeakReference<>(view);
    }

    /* renamed from: a */
    public C0052a8 mo258a(float f) {
        View view = (View) this.f239a.get();
        if (view != null) {
            view.animate().alpha(f);
        }
        return this;
    }

    /* renamed from: a */
    public C0052a8 mo259a(long j) {
        View view = (View) this.f239a.get();
        if (view != null) {
            view.animate().setDuration(j);
        }
        return this;
    }

    /* renamed from: a */
    public C0052a8 mo260a(C0286b8 b8Var) {
        View view = (View) this.f239a.get();
        if (view != null) {
            int i = Build.VERSION.SDK_INT;
            mo263a(view, b8Var);
        }
        return this;
    }

    /* renamed from: a */
    public C0052a8 mo261a(C0522d8 d8Var) {
        View view = (View) this.f239a.get();
        if (view != null) {
            int i = Build.VERSION.SDK_INT;
            C0054b bVar = null;
            if (d8Var != null) {
                bVar = new C0054b(this, d8Var, view);
            }
            view.animate().setUpdateListener(bVar);
        }
        return this;
    }

    /* renamed from: a */
    public void mo262a() {
        View view = (View) this.f239a.get();
        if (view != null) {
            view.animate().cancel();
        }
    }

    /* renamed from: a */
    public final void mo263a(View view, C0286b8 b8Var) {
        if (b8Var != null) {
            view.animate().setListener(new C0053a(this, b8Var, view));
        } else {
            view.animate().setListener((Animator.AnimatorListener) null);
        }
    }

    /* renamed from: b */
    public C0052a8 mo264b(float f) {
        View view = (View) this.f239a.get();
        if (view != null) {
            view.animate().translationY(f);
        }
        return this;
    }
}
