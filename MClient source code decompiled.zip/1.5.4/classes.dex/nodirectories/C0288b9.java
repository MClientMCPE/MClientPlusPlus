package p000;

import java.util.ArrayList;
import java.util.List;

/* renamed from: b9 */
public class C0288b9<C, T, A> implements Cloneable {

    /* renamed from: X */
    public List<C> f1757X = new ArrayList();

    /* renamed from: Y */
    public long f1758Y = 0;

    /* renamed from: Z */
    public long[] f1759Z;

    /* renamed from: a0 */
    public int f1760a0;

    /* renamed from: b0 */
    public final C0289a<C, T, A> f1761b0;

    /* renamed from: b9$a */
    public static abstract class C0289a<C, T, A> {
        /* renamed from: a */
        public abstract void mo2374a(C c, T t, int i, A a);
    }

    public C0288b9(C0289a<C, T, A> aVar) {
        this.f1761b0 = aVar;
    }

    /* renamed from: a */
    public final void mo2365a(int i, long j) {
        long j2 = Long.MIN_VALUE;
        for (int i2 = (i + 64) - 1; i2 >= i; i2--) {
            if ((j & j2) != 0) {
                this.f1757X.remove(i2);
            }
            j2 >>>= 1;
        }
    }

    /* renamed from: a */
    public synchronized void mo2366a(C c) {
        if (c != null) {
            int lastIndexOf = this.f1757X.lastIndexOf(c);
            if (lastIndexOf < 0 || mo2370a(lastIndexOf)) {
                this.f1757X.add(c);
            }
        } else {
            throw new IllegalArgumentException("callback cannot be null");
        }
    }

    /* renamed from: a */
    public synchronized void mo2367a(T t, int i, A a) {
        this.f1760a0++;
        int size = this.f1757X.size();
        long[] jArr = this.f1759Z;
        int i2 = -1;
        if (jArr != null) {
            i2 = -1 + jArr.length;
        }
        mo2368a(t, i, a, i2);
        mo2369a(t, i, a, (i2 + 2) * 64, size, 0);
        this.f1760a0--;
        if (this.f1760a0 == 0) {
            if (this.f1759Z != null) {
                for (int length = this.f1759Z.length - 1; length >= 0; length--) {
                    long j = this.f1759Z[length];
                    if (j != 0) {
                        mo2365a((length + 1) * 64, j);
                        this.f1759Z[length] = 0;
                    }
                }
            }
            if (this.f1758Y != 0) {
                mo2365a(0, this.f1758Y);
                this.f1758Y = 0;
            }
        }
    }

    /* renamed from: a */
    public final void mo2369a(T t, int i, A a, int i2, int i3, long j) {
        long j2 = 1;
        while (i2 < i3) {
            if ((j & j2) == 0) {
                this.f1761b0.mo2374a(this.f1757X.get(i2), t, i, a);
            }
            j2 <<= 1;
            i2++;
        }
    }

    /* renamed from: a */
    public final boolean mo2370a(int i) {
        int i2;
        if (i < 64) {
            return ((1 << i) & this.f1758Y) != 0;
        }
        long[] jArr = this.f1759Z;
        if (jArr == null || (i2 = (i / 64) - 1) >= jArr.length) {
            return false;
        }
        return ((1 << (i % 64)) & jArr[i2]) != 0;
    }

    /* renamed from: b */
    public final void mo2371b(int i) {
        if (i < 64) {
            this.f1758Y = (1 << i) | this.f1758Y;
            return;
        }
        int i2 = (i / 64) - 1;
        long[] jArr = this.f1759Z;
        if (jArr == null) {
            this.f1759Z = new long[(this.f1757X.size() / 64)];
        } else if (jArr.length <= i2) {
            long[] jArr2 = new long[(this.f1757X.size() / 64)];
            long[] jArr3 = this.f1759Z;
            System.arraycopy(jArr3, 0, jArr2, 0, jArr3.length);
            this.f1759Z = jArr2;
        }
        long j = 1 << (i % 64);
        long[] jArr4 = this.f1759Z;
        jArr4[i2] = j | jArr4[i2];
    }

    /* renamed from: b */
    public synchronized void mo2372b(C c) {
        if (this.f1760a0 == 0) {
            this.f1757X.remove(c);
        } else {
            int lastIndexOf = this.f1757X.lastIndexOf(c);
            if (lastIndexOf >= 0) {
                mo2371b(lastIndexOf);
            }
        }
    }

    public synchronized C0288b9<C, T, A> clone() {
        C0288b9<C, T, A> b9Var;
        CloneNotSupportedException e;
        try {
            b9Var = (C0288b9) super.clone();
            try {
                b9Var.f1758Y = 0;
                b9Var.f1759Z = null;
                b9Var.f1760a0 = 0;
                b9Var.f1757X = new ArrayList();
                int size = this.f1757X.size();
                for (int i = 0; i < size; i++) {
                    if (!mo2370a(i)) {
                        b9Var.f1757X.add(this.f1757X.get(i));
                    }
                }
            } catch (CloneNotSupportedException e2) {
                e = e2;
                e.printStackTrace();
                return b9Var;
            }
        } catch (CloneNotSupportedException e3) {
            CloneNotSupportedException cloneNotSupportedException = e3;
            b9Var = null;
            e = cloneNotSupportedException;
            e.printStackTrace();
            return b9Var;
        }
        return b9Var;
    }

    /* renamed from: a */
    public final void mo2368a(T t, int i, A a, int i2) {
        if (i2 < 0) {
            mo2369a(t, i, a, 0, Math.min(64, this.f1757X.size()), this.f1758Y);
            return;
        }
        long j = this.f1759Z[i2];
        int i3 = (i2 + 1) * 64;
        int min = Math.min(this.f1757X.size(), i3 + 64);
        mo2368a(t, i, a, i2 - 1);
        mo2369a(t, i, a, i3, min, j);
    }
}
