package p000;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.TextView;

/* renamed from: d2 */
public class C0507d2 extends Button implements C2097v7, C1133k8 {

    /* renamed from: a0 */
    public final C0334c2 f3635a0;

    /* renamed from: b0 */
    public final C2176w2 f3636b0;

    public C0507d2(Context context) {
        this(context, (AttributeSet) null);
    }

    public C0507d2(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0502d.buttonStyle);
    }

    public C0507d2(Context context, AttributeSet attributeSet, int i) {
        super(C2083v3.m14434a(context), attributeSet, i);
        this.f3635a0 = new C0334c2(this);
        this.f3635a0.mo2717a(attributeSet, i);
        this.f3636b0 = new C2176w2(this);
        this.f3636b0.mo12087a(attributeSet, i);
        this.f3636b0.mo12081a();
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        C0334c2 c2Var = this.f3635a0;
        if (c2Var != null) {
            c2Var.mo2713a();
        }
        C2176w2 w2Var = this.f3636b0;
        if (w2Var != null) {
            w2Var.mo12081a();
        }
    }

    public int getAutoSizeMaxTextSize() {
        if (C1133k8.f8952a) {
            return super.getAutoSizeMaxTextSize();
        }
        C2176w2 w2Var = this.f3636b0;
        if (w2Var != null) {
            return w2Var.mo12089b();
        }
        return -1;
    }

    public int getAutoSizeMinTextSize() {
        if (C1133k8.f8952a) {
            return super.getAutoSizeMinTextSize();
        }
        C2176w2 w2Var = this.f3636b0;
        if (w2Var != null) {
            return w2Var.mo12090c();
        }
        return -1;
    }

    public int getAutoSizeStepGranularity() {
        if (C1133k8.f8952a) {
            return super.getAutoSizeStepGranularity();
        }
        C2176w2 w2Var = this.f3636b0;
        if (w2Var != null) {
            return w2Var.mo12091d();
        }
        return -1;
    }

    public int[] getAutoSizeTextAvailableSizes() {
        if (C1133k8.f8952a) {
            return super.getAutoSizeTextAvailableSizes();
        }
        C2176w2 w2Var = this.f3636b0;
        return w2Var != null ? w2Var.mo12092e() : new int[0];
    }

    @SuppressLint({"WrongConstant"})
    public int getAutoSizeTextType() {
        if (C1133k8.f8952a) {
            return super.getAutoSizeTextType() == 1 ? 1 : 0;
        }
        C2176w2 w2Var = this.f3636b0;
        if (w2Var != null) {
            return w2Var.mo12093f();
        }
        return 0;
    }

    public ColorStateList getSupportBackgroundTintList() {
        C0334c2 c2Var = this.f3635a0;
        if (c2Var != null) {
            return c2Var.mo2718b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        C0334c2 c2Var = this.f3635a0;
        if (c2Var != null) {
            return c2Var.mo2720c();
        }
        return null;
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(Button.class.getName());
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(Button.class.getName());
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        C2176w2 w2Var = this.f3636b0;
        if (w2Var != null && !C1133k8.f8952a) {
            w2Var.f16501i.mo12417a();
        }
    }

    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        super.onTextChanged(charSequence, i, i2, i3);
        C2176w2 w2Var = this.f3636b0;
        if (w2Var != null && !C1133k8.f8952a && w2Var.mo12094g()) {
            this.f3636b0.f16501i.mo12417a();
        }
    }

    public void setAutoSizeTextTypeUniformWithConfiguration(int i, int i2, int i3, int i4) {
        if (C1133k8.f8952a) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i, i2, i3, i4);
            return;
        }
        C2176w2 w2Var = this.f3636b0;
        if (w2Var != null) {
            w2Var.mo12083a(i, i2, i3, i4);
        }
    }

    public void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i) {
        if (C1133k8.f8952a) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i);
            return;
        }
        C2176w2 w2Var = this.f3636b0;
        if (w2Var != null) {
            w2Var.mo12088a(iArr, i);
        }
    }

    public void setAutoSizeTextTypeWithDefaults(int i) {
        if (C1133k8.f8952a) {
            super.setAutoSizeTextTypeWithDefaults(i);
            return;
        }
        C2176w2 w2Var = this.f3636b0;
        if (w2Var != null) {
            w2Var.mo12082a(i);
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        C0334c2 c2Var = this.f3635a0;
        if (c2Var != null) {
            c2Var.mo2721d();
        }
    }

    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        C0334c2 c2Var = this.f3635a0;
        if (c2Var != null) {
            c2Var.mo2714a(i);
        }
    }

    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(C0815h0.m5786a((TextView) this, callback));
    }

    public void setSupportAllCaps(boolean z) {
        C2176w2 w2Var = this.f3636b0;
        if (w2Var != null) {
            w2Var.f16493a.setAllCaps(z);
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        C0334c2 c2Var = this.f3635a0;
        if (c2Var != null) {
            c2Var.mo2719b(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        C0334c2 c2Var = this.f3635a0;
        if (c2Var != null) {
            c2Var.mo2716a(mode);
        }
    }

    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        C2176w2 w2Var = this.f3636b0;
        if (w2Var != null) {
            w2Var.mo12084a(context, i);
        }
    }

    public void setTextSize(int i, float f) {
        boolean z = C1133k8.f8952a;
        if (z) {
            super.setTextSize(i, f);
            return;
        }
        C2176w2 w2Var = this.f3636b0;
        if (w2Var != null && !z && !w2Var.mo12094g()) {
            w2Var.f16501i.mo12419a(i, f);
        }
    }
}
