package p000;

import android.os.Build;
import android.view.ViewGroup;

/* renamed from: ee */
public class C0602ee {

    /* renamed from: a */
    public static boolean f4422a = true;

    /* renamed from: a */
    public static C0534de m4048a(ViewGroup viewGroup) {
        int i = Build.VERSION.SDK_INT;
        return new C0370ce(viewGroup);
    }

    /* renamed from: a */
    public static void m4049a(ViewGroup viewGroup, boolean z) {
        if (Build.VERSION.SDK_INT >= 29) {
            viewGroup.suppressLayout(z);
        } else if (f4422a) {
            try {
                viewGroup.suppressLayout(z);
            } catch (NoSuchMethodError unused) {
                f4422a = false;
            }
        }
    }
}
