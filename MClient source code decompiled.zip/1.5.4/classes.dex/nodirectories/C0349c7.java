package p000;

import android.util.Log;
import java.io.Writer;

/* renamed from: c7 */
public class C0349c7 extends Writer {

    /* renamed from: X */
    public final String f2565X;

    /* renamed from: Y */
    public StringBuilder f2566Y = new StringBuilder(128);

    public C0349c7(String str) {
        this.f2565X = str;
    }

    /* renamed from: a */
    public final void mo2833a() {
        if (this.f2566Y.length() > 0) {
            Log.d(this.f2565X, this.f2566Y.toString());
            StringBuilder sb = this.f2566Y;
            sb.delete(0, sb.length());
        }
    }

    public void close() {
        mo2833a();
    }

    public void flush() {
        mo2833a();
    }

    public void write(char[] cArr, int i, int i2) {
        for (int i3 = 0; i3 < i2; i3++) {
            char c = cArr[i + i3];
            if (c == 10) {
                mo2833a();
            } else {
                this.f2566Y.append(c);
            }
        }
    }
}
