package p000;

import android.os.Build;
import android.text.TextUtils;
import java.util.Locale;

/* renamed from: b7 */
public final class C0285b7 {

    /* renamed from: a */
    public static final Locale f1746a = new Locale("", "");

    /* renamed from: a */
    public static int m1740a(Locale locale) {
        int i = Build.VERSION.SDK_INT;
        return TextUtils.getLayoutDirectionFromLocale(locale);
    }
}
