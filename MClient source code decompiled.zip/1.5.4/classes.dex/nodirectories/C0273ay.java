package p000;

import java.util.Map;

/* renamed from: ay */
public final /* synthetic */ class C0273ay implements C1373my {

    /* renamed from: a */
    public static final C1373my f1601a = new C0273ay();

    /* renamed from: a */
    public final void mo2197a(Object obj, Map map) {
        C2476zx.m17352a((k00) obj, map);
    }
}
