package p000;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import java.util.List;

/* renamed from: dv */
public abstract class C0559dv extends qj2 implements C0724fv {
    public C0559dv() {
        super("com.google.android.gms.ads.internal.formats.client.IAttributionInfo");
    }

    /* renamed from: a */
    public static C0724fv m3812a(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface queryLocalInterface = iBinder.queryLocalInterface("com.google.android.gms.ads.internal.formats.client.IAttributionInfo");
        return queryLocalInterface instanceof C0724fv ? (C0724fv) queryLocalInterface : new C0882hv(iBinder);
    }

    /* renamed from: a */
    public final boolean mo2162a(int i, Parcel parcel, Parcel parcel2, int i2) {
        if (i == 2) {
            String str = ((C2072uu) this).f15725X;
            parcel2.writeNoException();
            parcel2.writeString(str);
            return true;
        } else if (i != 3) {
            return false;
        } else {
            List<C1274lv> l0 = ((C2072uu) this).mo5787l0();
            parcel2.writeNoException();
            parcel2.writeList(l0);
            return true;
        }
    }
}
