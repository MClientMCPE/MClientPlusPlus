package p000;

import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: bz */
public final class C0330bz extends C1874sq {
    public static final Parcelable.Creator<C0330bz> CREATOR = new C0632ez();

    /* renamed from: X */
    public final boolean f2395X;

    /* renamed from: Y */
    public final String f2396Y;

    /* renamed from: Z */
    public final int f2397Z;

    /* renamed from: a0 */
    public final byte[] f2398a0;

    /* renamed from: b0 */
    public final String[] f2399b0;

    /* renamed from: c0 */
    public final String[] f2400c0;

    /* renamed from: d0 */
    public final boolean f2401d0;

    /* renamed from: e0 */
    public final long f2402e0;

    public C0330bz(boolean z, String str, int i, byte[] bArr, String[] strArr, String[] strArr2, boolean z2, long j) {
        this.f2395X = z;
        this.f2396Y = str;
        this.f2397Z = i;
        this.f2398a0 = bArr;
        this.f2399b0 = strArr;
        this.f2400c0 = strArr2;
        this.f2401d0 = z2;
        this.f2402e0 = j;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a = C0680fe.m4661a(parcel);
        C0680fe.m4751a(parcel, 1, this.f2395X);
        C0680fe.m4749a(parcel, 2, this.f2396Y, false);
        C0680fe.m4744a(parcel, 3, this.f2397Z);
        C0680fe.m4752a(parcel, 4, this.f2398a0, false);
        C0680fe.m4754a(parcel, 5, this.f2399b0, false);
        C0680fe.m4754a(parcel, 6, this.f2400c0, false);
        C0680fe.m4751a(parcel, 7, this.f2401d0);
        C0680fe.m4745a(parcel, 8, this.f2402e0);
        C0680fe.m4891o(parcel, a);
    }
}
