package p000;

/* renamed from: fi */
public class C0700fi implements C1617pg {

    /* renamed from: a */
    public final /* synthetic */ C0868hi f5373a;

    public C0700fi(C0868hi hiVar) {
        this.f5373a = hiVar;
    }

    /* renamed from: a */
    public void mo532a(C1249lg lgVar) {
        if (this.f5373a.mo6550c(lgVar)) {
            this.f5373a.mo6556i(lgVar);
        }
    }
}
