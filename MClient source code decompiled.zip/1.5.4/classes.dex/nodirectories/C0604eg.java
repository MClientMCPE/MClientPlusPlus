package p000;

import android.view.View;

/* renamed from: eg */
public class C0604eg implements C1617pg {

    /* renamed from: a */
    public final /* synthetic */ C1335mg f4456a;

    /* renamed from: eg$a */
    public class C0605a implements Runnable {

        /* renamed from: X */
        public final /* synthetic */ C1249lg f4457X;

        public C0605a(C1249lg lgVar) {
            this.f4457X = lgVar;
        }

        public void run() {
            C1335mg mgVar = C0604eg.this.f4456a;
            mgVar.mo8728a((View) mgVar.mo8731d(this.f4457X), ic3.OTHER);
        }
    }

    public C0604eg(C1335mg mgVar) {
        this.f4456a = mgVar;
    }

    /* renamed from: a */
    public void mo532a(C1249lg lgVar) {
        if (this.f4456a.mo8736i(lgVar)) {
            C1062ji.m7720a((Runnable) new C0605a(lgVar));
        }
    }
}
