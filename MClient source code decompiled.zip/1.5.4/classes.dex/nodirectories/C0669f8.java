package p000;

import android.os.Bundle;
import android.text.style.ClickableSpan;
import android.view.View;

/* renamed from: f8 */
public final class C0669f8 extends ClickableSpan {

    /* renamed from: X */
    public final int f5124X;

    /* renamed from: Y */
    public final C0759g8 f5125Y;

    /* renamed from: Z */
    public final int f5126Z;

    public C0669f8(int i, C0759g8 g8Var, int i2) {
        this.f5124X = i;
        this.f5125Y = g8Var;
        this.f5126Z = i2;
    }

    public void onClick(View view) {
        Bundle bundle = new Bundle();
        bundle.putInt("ACCESSIBILITY_CLICKABLE_SPAN_ID", this.f5124X);
        this.f5125Y.mo6039a(this.f5126Z, bundle);
    }
}
