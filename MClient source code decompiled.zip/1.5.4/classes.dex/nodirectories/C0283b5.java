package p000;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;
import p000.C0658f5;

/* renamed from: b5 */
public final class C0283b5<E> implements Collection<E>, Set<E> {

    /* renamed from: b0 */
    public static final int[] f1710b0 = new int[0];

    /* renamed from: c0 */
    public static final Object[] f1711c0 = new Object[0];

    /* renamed from: d0 */
    public static Object[] f1712d0;

    /* renamed from: e0 */
    public static int f1713e0;

    /* renamed from: f0 */
    public static Object[] f1714f0;

    /* renamed from: g0 */
    public static int f1715g0;

    /* renamed from: X */
    public int[] f1716X;

    /* renamed from: Y */
    public Object[] f1717Y;

    /* renamed from: Z */
    public int f1718Z;

    /* renamed from: a0 */
    public C0658f5<E, E> f1719a0;

    public C0283b5() {
        this(0);
    }

    public C0283b5(int i) {
        if (i == 0) {
            this.f1716X = f1710b0;
            this.f1717Y = f1711c0;
        } else {
            mo2332c(i);
        }
        this.f1718Z = 0;
    }

    /* renamed from: a */
    public static void m1725a(int[] iArr, Object[] objArr, int i) {
        if (iArr.length == 8) {
            synchronized (C0283b5.class) {
                if (f1715g0 < 10) {
                    objArr[0] = f1714f0;
                    objArr[1] = iArr;
                    for (int i2 = i - 1; i2 >= 2; i2--) {
                        objArr[i2] = null;
                    }
                    f1714f0 = objArr;
                    f1715g0++;
                }
            }
        } else if (iArr.length == 4) {
            synchronized (C0283b5.class) {
                if (f1713e0 < 10) {
                    objArr[0] = f1712d0;
                    objArr[1] = iArr;
                    for (int i3 = i - 1; i3 >= 2; i3--) {
                        objArr[i3] = null;
                    }
                    f1712d0 = objArr;
                    f1713e0++;
                }
            }
        }
    }

    /* renamed from: a */
    public final int mo2328a(Object obj, int i) {
        int i2 = this.f1718Z;
        if (i2 == 0) {
            return -1;
        }
        int a = C0339c5.m2291a(this.f1716X, i2, i);
        if (a < 0 || obj.equals(this.f1717Y[a])) {
            return a;
        }
        int i3 = a + 1;
        while (i3 < i2 && this.f1716X[i3] == i) {
            if (obj.equals(this.f1717Y[i3])) {
                return i3;
            }
            i3++;
        }
        int i4 = a - 1;
        while (i4 >= 0 && this.f1716X[i4] == i) {
            if (obj.equals(this.f1717Y[i4])) {
                return i4;
            }
            i4--;
        }
        return i3 ^ -1;
    }

    public boolean add(E e) {
        int i;
        int i2;
        if (e == null) {
            i2 = mo2331c();
            i = 0;
        } else {
            int hashCode = e.hashCode();
            i = hashCode;
            i2 = mo2328a(e, hashCode);
        }
        if (i2 >= 0) {
            return false;
        }
        int i3 = i2 ^ -1;
        int i4 = this.f1718Z;
        if (i4 >= this.f1716X.length) {
            int i5 = 4;
            if (i4 >= 8) {
                i5 = (i4 >> 1) + i4;
            } else if (i4 >= 4) {
                i5 = 8;
            }
            int[] iArr = this.f1716X;
            Object[] objArr = this.f1717Y;
            mo2332c(i5);
            int[] iArr2 = this.f1716X;
            if (iArr2.length > 0) {
                System.arraycopy(iArr, 0, iArr2, 0, iArr.length);
                System.arraycopy(objArr, 0, this.f1717Y, 0, objArr.length);
            }
            m1725a(iArr, objArr, this.f1718Z);
        }
        int i6 = this.f1718Z;
        if (i3 < i6) {
            int[] iArr3 = this.f1716X;
            int i7 = i3 + 1;
            System.arraycopy(iArr3, i3, iArr3, i7, i6 - i3);
            Object[] objArr2 = this.f1717Y;
            System.arraycopy(objArr2, i3, objArr2, i7, this.f1718Z - i3);
        }
        this.f1716X[i3] = i;
        this.f1717Y[i3] = e;
        this.f1718Z++;
        return true;
    }

    public boolean addAll(Collection<? extends E> collection) {
        int size = collection.size() + this.f1718Z;
        int[] iArr = this.f1716X;
        boolean z = false;
        if (iArr.length < size) {
            Object[] objArr = this.f1717Y;
            mo2332c(size);
            int i = this.f1718Z;
            if (i > 0) {
                System.arraycopy(iArr, 0, this.f1716X, 0, i);
                System.arraycopy(objArr, 0, this.f1717Y, 0, this.f1718Z);
            }
            m1725a(iArr, objArr, this.f1718Z);
        }
        for (Object add : collection) {
            z |= add(add);
        }
        return z;
    }

    /* renamed from: c */
    public final int mo2331c() {
        int i = this.f1718Z;
        if (i == 0) {
            return -1;
        }
        int a = C0339c5.m2291a(this.f1716X, i, 0);
        if (a < 0 || this.f1717Y[a] == null) {
            return a;
        }
        int i2 = a + 1;
        while (i2 < i && this.f1716X[i2] == 0) {
            if (this.f1717Y[i2] == null) {
                return i2;
            }
            i2++;
        }
        int i3 = a - 1;
        while (i3 >= 0 && this.f1716X[i3] == 0) {
            if (this.f1717Y[i3] == null) {
                return i3;
            }
            i3--;
        }
        return i2 ^ -1;
    }

    /* renamed from: c */
    public final void mo2332c(int i) {
        if (i == 8) {
            synchronized (C0283b5.class) {
                if (f1714f0 != null) {
                    Object[] objArr = f1714f0;
                    this.f1717Y = objArr;
                    f1714f0 = (Object[]) objArr[0];
                    this.f1716X = (int[]) objArr[1];
                    objArr[1] = null;
                    objArr[0] = null;
                    f1715g0--;
                    return;
                }
            }
        } else if (i == 4) {
            synchronized (C0283b5.class) {
                if (f1712d0 != null) {
                    Object[] objArr2 = f1712d0;
                    this.f1717Y = objArr2;
                    f1712d0 = (Object[]) objArr2[0];
                    this.f1716X = (int[]) objArr2[1];
                    objArr2[1] = null;
                    objArr2[0] = null;
                    f1713e0--;
                    return;
                }
            }
        }
        this.f1716X = new int[i];
        this.f1717Y = new Object[i];
    }

    public void clear() {
        int i = this.f1718Z;
        if (i != 0) {
            m1725a(this.f1716X, this.f1717Y, i);
            this.f1716X = f1710b0;
            this.f1717Y = f1711c0;
            this.f1718Z = 0;
        }
    }

    public boolean contains(Object obj) {
        return indexOf(obj) >= 0;
    }

    public boolean containsAll(Collection<?> collection) {
        for (Object contains : collection) {
            if (!contains(contains)) {
                return false;
            }
        }
        return true;
    }

    /* renamed from: d */
    public E mo2336d(int i) {
        E[] eArr = this.f1717Y;
        E e = eArr[i];
        int i2 = this.f1718Z;
        if (i2 <= 1) {
            m1725a(this.f1716X, eArr, i2);
            this.f1716X = f1710b0;
            this.f1717Y = f1711c0;
            this.f1718Z = 0;
        } else {
            int[] iArr = this.f1716X;
            int i3 = 8;
            if (iArr.length <= 8 || i2 >= iArr.length / 3) {
                this.f1718Z--;
                int i4 = this.f1718Z;
                if (i < i4) {
                    int[] iArr2 = this.f1716X;
                    int i5 = i + 1;
                    System.arraycopy(iArr2, i5, iArr2, i, i4 - i);
                    Object[] objArr = this.f1717Y;
                    System.arraycopy(objArr, i5, objArr, i, this.f1718Z - i);
                }
                this.f1717Y[this.f1718Z] = null;
            } else {
                if (i2 > 8) {
                    i3 = i2 + (i2 >> 1);
                }
                int[] iArr3 = this.f1716X;
                Object[] objArr2 = this.f1717Y;
                mo2332c(i3);
                this.f1718Z--;
                if (i > 0) {
                    System.arraycopy(iArr3, 0, this.f1716X, 0, i);
                    System.arraycopy(objArr2, 0, this.f1717Y, 0, i);
                }
                int i6 = this.f1718Z;
                if (i < i6) {
                    int i7 = i + 1;
                    System.arraycopy(iArr3, i7, this.f1716X, i, i6 - i);
                    System.arraycopy(objArr2, i7, this.f1717Y, i, this.f1718Z - i);
                }
            }
        }
        return e;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof Set) {
            Set set = (Set) obj;
            if (this.f1718Z != set.size()) {
                return false;
            }
            int i = 0;
            while (i < this.f1718Z) {
                try {
                    if (!set.contains(this.f1717Y[i])) {
                        return false;
                    }
                    i++;
                } catch (ClassCastException | NullPointerException unused) {
                }
            }
            return true;
        }
        return false;
    }

    public int hashCode() {
        int[] iArr = this.f1716X;
        int i = this.f1718Z;
        int i2 = 0;
        for (int i3 = 0; i3 < i; i3++) {
            i2 += iArr[i3];
        }
        return i2;
    }

    public int indexOf(Object obj) {
        return obj == null ? mo2331c() : mo2328a(obj, obj.hashCode());
    }

    public boolean isEmpty() {
        return this.f1718Z <= 0;
    }

    public Iterator<E> iterator() {
        if (this.f1719a0 == null) {
            this.f1719a0 = new C0042a5(this);
        }
        C0658f5<E, E> f5Var = this.f1719a0;
        if (f5Var.f5043b == null) {
            f5Var.f5043b = new C0658f5.C0661c();
        }
        return f5Var.f5043b.iterator();
    }

    public boolean remove(Object obj) {
        int indexOf = indexOf(obj);
        if (indexOf < 0) {
            return false;
        }
        mo2336d(indexOf);
        return true;
    }

    public boolean removeAll(Collection<?> collection) {
        boolean z = false;
        for (Object remove : collection) {
            z |= remove(remove);
        }
        return z;
    }

    public boolean retainAll(Collection<?> collection) {
        boolean z = false;
        for (int i = this.f1718Z - 1; i >= 0; i--) {
            if (!collection.contains(this.f1717Y[i])) {
                mo2336d(i);
                z = true;
            }
        }
        return z;
    }

    public int size() {
        return this.f1718Z;
    }

    public Object[] toArray() {
        int i = this.f1718Z;
        Object[] objArr = new Object[i];
        System.arraycopy(this.f1717Y, 0, objArr, 0, i);
        return objArr;
    }

    public <T> T[] toArray(T[] tArr) {
        if (tArr.length < this.f1718Z) {
            tArr = (Object[]) Array.newInstance(tArr.getClass().getComponentType(), this.f1718Z);
        }
        System.arraycopy(this.f1717Y, 0, tArr, 0, this.f1718Z);
        int length = tArr.length;
        int i = this.f1718Z;
        if (length > i) {
            tArr[i] = null;
        }
        return tArr;
    }

    public String toString() {
        if (isEmpty()) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.f1718Z * 14);
        sb.append('{');
        for (int i = 0; i < this.f1718Z; i++) {
            if (i > 0) {
                sb.append(", ");
            }
            Object obj = this.f1717Y[i];
            if (obj != this) {
                sb.append(obj);
            } else {
                sb.append("(this Set)");
            }
        }
        sb.append('}');
        return sb.toString();
    }
}
