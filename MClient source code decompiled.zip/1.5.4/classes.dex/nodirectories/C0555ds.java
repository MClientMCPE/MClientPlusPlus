package p000;

import dalvik.system.PathClassLoader;

/* renamed from: ds */
public final class C0555ds extends PathClassLoader {
    public C0555ds(String str, ClassLoader classLoader) {
        super(str, classLoader);
    }

    public final Class<?> loadClass(String str, boolean z) {
        if (!str.startsWith("java.") && !str.startsWith("android.")) {
            try {
                return findClass(str);
            } catch (ClassNotFoundException unused) {
            }
        }
        return super.loadClass(str, z);
    }
}
