package p000;

import java.util.List;

/* renamed from: b6 */
public final class C0284b6 {

    /* renamed from: a */
    public final int[] f1736a;

    /* renamed from: b */
    public final float[] f1737b;

    public C0284b6(int i, int i2) {
        this.f1736a = new int[]{i, i2};
        this.f1737b = new float[]{0.0f, 1.0f};
    }

    public C0284b6(int i, int i2, int i3) {
        this.f1736a = new int[]{i, i2, i3};
        this.f1737b = new float[]{0.0f, 0.5f, 1.0f};
    }

    public C0284b6(List<Integer> list, List<Float> list2) {
        int size = list.size();
        this.f1736a = new int[size];
        this.f1737b = new float[size];
        for (int i = 0; i < size; i++) {
            this.f1736a[i] = list.get(i).intValue();
            this.f1737b[i] = list2.get(i).floatValue();
        }
    }
}
