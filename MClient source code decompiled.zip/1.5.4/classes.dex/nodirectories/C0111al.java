package p000;

import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/* renamed from: al */
public class C0111al {

    /* renamed from: a */
    public final C2290xk f546a;

    /* renamed from: b */
    public boolean[] f547b;

    /* renamed from: c */
    public int[] f548c;

    /* renamed from: d */
    public long[] f549d;

    /* renamed from: e */
    public long[] f550e;

    /* renamed from: al$b */
    public static class C0113b {

        /* renamed from: a */
        public List<C2458zk> f551a;

        /* renamed from: b */
        public int f552b;

        /* renamed from: a */
        public void mo600a() {
            this.f551a = null;
            this.f552b = 0;
        }
    }

    /* renamed from: al$c */
    public static class C0114c implements Comparable<C0114c> {

        /* renamed from: X */
        public int f553X;

        /* renamed from: Y */
        public int f554Y;

        public C0114c() {
        }

        public /* synthetic */ C0114c(C0112a aVar) {
        }

        public int compareTo(Object obj) {
            C0114c cVar = (C0114c) obj;
            int i = this.f554Y;
            int i2 = cVar.f554Y;
            return i != i2 ? i - i2 : this.f553X - cVar.f553X;
        }

        public String toString() {
            StringBuilder a = C0789gk.m5562a("Order{order=");
            a.append(this.f554Y);
            a.append(", index=");
            a.append(this.f553X);
            a.append('}');
            return a.toString();
        }
    }

    public C0111al(C2290xk xkVar) {
        this.f546a = xkVar;
    }

    /* renamed from: a */
    public final int mo571a(int i, C2367yk ykVar, int i2) {
        int f;
        C2290xk xkVar = this.f546a;
        int a = xkVar.mo3105a(i, ykVar.mo3176j() + ykVar.mo3179m() + this.f546a.getPaddingBottom() + xkVar.getPaddingTop() + i2, ykVar.getHeight());
        int size = View.MeasureSpec.getSize(a);
        if (size > ykVar.mo3175i()) {
            f = ykVar.mo3175i();
        } else if (size >= ykVar.mo3169f()) {
            return a;
        } else {
            f = ykVar.mo3169f();
        }
        return View.MeasureSpec.makeMeasureSpec(f, View.MeasureSpec.getMode(a));
    }

    /* renamed from: a */
    public int mo572a(long j) {
        return (int) (j >> 32);
    }

    /* renamed from: a */
    public final int mo573a(C2367yk ykVar, boolean z) {
        return z ? ykVar.mo3176j() : ykVar.mo3168e();
    }

    /* renamed from: a */
    public final List<C0114c> mo574a(int i) {
        ArrayList arrayList = new ArrayList(i);
        for (int i2 = 0; i2 < i; i2++) {
            C0114c cVar = new C0114c((C0112a) null);
            cVar.f554Y = ((C2367yk) this.f546a.mo3108a(i2).getLayoutParams()).getOrder();
            cVar.f553X = i2;
            arrayList.add(cVar);
        }
        return arrayList;
    }

    /* renamed from: a */
    public final List<C2458zk> mo575a(List<C2458zk> list, int i, int i2) {
        ArrayList arrayList = new ArrayList();
        C2458zk zkVar = new C2458zk();
        zkVar.f18437g = (i - i2) / 2;
        int size = list.size();
        for (int i3 = 0; i3 < size; i3++) {
            if (i3 == 0) {
                arrayList.add(zkVar);
            }
            arrayList.add(list.get(i3));
            if (i3 == list.size() - 1) {
                arrayList.add(zkVar);
            }
        }
        return arrayList;
    }

    /* renamed from: a */
    public void mo576a(int i, int i2, int i3) {
        int i4;
        int i5;
        int flexDirection = this.f546a.getFlexDirection();
        if (flexDirection == 0 || flexDirection == 1) {
            i5 = View.MeasureSpec.getMode(i2);
            i4 = View.MeasureSpec.getSize(i2);
        } else if (flexDirection == 2 || flexDirection == 3) {
            int mode = View.MeasureSpec.getMode(i);
            i4 = View.MeasureSpec.getSize(i);
            i5 = mode;
        } else {
            throw new IllegalArgumentException(C0789gk.m5568b("Invalid flex direction: ", flexDirection));
        }
        List<C2458zk> flexLinesInternal = this.f546a.getFlexLinesInternal();
        if (i5 == 1073741824) {
            int sumOfCrossSize = this.f546a.getSumOfCrossSize() + i3;
            int i6 = 0;
            if (flexLinesInternal.size() == 1) {
                flexLinesInternal.get(0).f18437g = i4 - i3;
            } else if (flexLinesInternal.size() >= 2) {
                int alignContent = this.f546a.getAlignContent();
                if (alignContent != 1) {
                    if (alignContent != 2) {
                        if (alignContent != 3) {
                            if (alignContent != 4) {
                                if (alignContent == 5 && sumOfCrossSize < i4) {
                                    float size = ((float) (i4 - sumOfCrossSize)) / ((float) flexLinesInternal.size());
                                    int size2 = flexLinesInternal.size();
                                    float f = 0.0f;
                                    while (i6 < size2) {
                                        C2458zk zkVar = flexLinesInternal.get(i6);
                                        float f2 = ((float) zkVar.f18437g) + size;
                                        if (i6 == flexLinesInternal.size() - 1) {
                                            f2 += f;
                                            f = 0.0f;
                                        }
                                        int round = Math.round(f2);
                                        float f3 = (f2 - ((float) round)) + f;
                                        if (f3 > 1.0f) {
                                            round++;
                                            f3 -= 1.0f;
                                        } else if (f3 < -1.0f) {
                                            round--;
                                            f3 += 1.0f;
                                        }
                                        f = f3;
                                        zkVar.f18437g = round;
                                        i6++;
                                    }
                                    return;
                                }
                                return;
                            } else if (sumOfCrossSize < i4) {
                                int size3 = (i4 - sumOfCrossSize) / (flexLinesInternal.size() * 2);
                                ArrayList arrayList = new ArrayList();
                                C2458zk zkVar2 = new C2458zk();
                                zkVar2.f18437g = size3;
                                for (C2458zk add : flexLinesInternal) {
                                    arrayList.add(zkVar2);
                                    arrayList.add(add);
                                    arrayList.add(zkVar2);
                                }
                                this.f546a.setFlexLines(arrayList);
                                return;
                            }
                        } else if (sumOfCrossSize < i4) {
                            float size4 = ((float) (i4 - sumOfCrossSize)) / ((float) (flexLinesInternal.size() - 1));
                            ArrayList arrayList2 = new ArrayList();
                            int size5 = flexLinesInternal.size();
                            float f4 = 0.0f;
                            while (i6 < size5) {
                                arrayList2.add(flexLinesInternal.get(i6));
                                if (i6 != flexLinesInternal.size() - 1) {
                                    C2458zk zkVar3 = new C2458zk();
                                    if (i6 == flexLinesInternal.size() - 2) {
                                        zkVar3.f18437g = Math.round(f4 + size4);
                                        f4 = 0.0f;
                                    } else {
                                        zkVar3.f18437g = Math.round(size4);
                                    }
                                    int i7 = zkVar3.f18437g;
                                    float f5 = (size4 - ((float) i7)) + f4;
                                    if (f5 > 1.0f) {
                                        zkVar3.f18437g = i7 + 1;
                                        f5 -= 1.0f;
                                    } else if (f5 < -1.0f) {
                                        zkVar3.f18437g = i7 - 1;
                                        f5 += 1.0f;
                                    }
                                    arrayList2.add(zkVar3);
                                    f4 = f5;
                                }
                                i6++;
                            }
                            this.f546a.setFlexLines(arrayList2);
                            return;
                        } else {
                            return;
                        }
                    }
                    this.f546a.setFlexLines(mo575a(flexLinesInternal, i4, sumOfCrossSize));
                    return;
                }
                int i8 = i4 - sumOfCrossSize;
                C2458zk zkVar4 = new C2458zk();
                zkVar4.f18437g = i8;
                flexLinesInternal.add(0, zkVar4);
            }
        }
    }

    /* renamed from: a */
    public final void mo577a(int i, int i2, int i3, View view) {
        long[] jArr = this.f549d;
        if (jArr != null) {
            jArr[i] = (((long) i2) & 4294967295L) | (((long) i3) << 32);
        }
        long[] jArr2 = this.f550e;
        if (jArr2 != null) {
            jArr2[i] = (((long) view.getMeasuredWidth()) & 4294967295L) | (((long) view.getMeasuredHeight()) << 32);
        }
    }

    /* renamed from: a */
    public final void mo578a(int i, int i2, C2458zk zkVar, int i3, int i4, boolean z) {
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        double d;
        int i10;
        double d2;
        C2458zk zkVar2 = zkVar;
        int i11 = i3;
        float f = zkVar2.f18440j;
        float f2 = 0.0f;
        if (f > 0.0f && i11 >= (i5 = zkVar2.f18435e)) {
            float f3 = ((float) (i11 - i5)) / f;
            zkVar2.f18435e = i4 + zkVar2.f18436f;
            if (!z) {
                zkVar2.f18437g = RecyclerView.UNDEFINED_DURATION;
            }
            int i12 = 0;
            boolean z2 = false;
            float f4 = 0.0f;
            int i13 = 0;
            while (i12 < zkVar2.f18438h) {
                int i14 = zkVar2.f18445o + i12;
                View b = this.f546a.mo3121b(i14);
                if (b == null || b.getVisibility() == 8) {
                    int i15 = i2;
                    i6 = i5;
                } else {
                    C2367yk ykVar = (C2367yk) b.getLayoutParams();
                    int flexDirection = this.f546a.getFlexDirection();
                    if (flexDirection == 0 || flexDirection == 1) {
                        int i16 = i5;
                        int i17 = i;
                        int measuredWidth = b.getMeasuredWidth();
                        long[] jArr = this.f550e;
                        if (jArr != null) {
                            measuredWidth = (int) jArr[i14];
                        }
                        int measuredHeight = b.getMeasuredHeight();
                        long[] jArr2 = this.f550e;
                        i6 = i16;
                        if (jArr2 != null) {
                            measuredHeight = mo572a(jArr2[i14]);
                        }
                        if (this.f547b[i14] || ykVar.mo3161a() <= 0.0f) {
                            int i18 = i2;
                            i9 = measuredWidth;
                            i8 = measuredHeight;
                        } else {
                            float a = (ykVar.mo3161a() * f3) + ((float) measuredWidth);
                            if (i12 == zkVar2.f18438h - 1) {
                                a += f4;
                                f4 = 0.0f;
                            }
                            int round = Math.round(a);
                            if (round > ykVar.mo3178l()) {
                                round = ykVar.mo3178l();
                                this.f547b[i14] = true;
                                zkVar2.f18440j -= ykVar.mo3161a();
                                z2 = true;
                            } else {
                                float f5 = (a - ((float) round)) + f4;
                                double d3 = (double) f5;
                                if (d3 > 1.0d) {
                                    round++;
                                    Double.isNaN(d3);
                                    d = d3 - 1.0d;
                                } else {
                                    if (d3 < -1.0d) {
                                        round--;
                                        Double.isNaN(d3);
                                        d = d3 + 1.0d;
                                    }
                                    f4 = f5;
                                }
                                f5 = (float) d;
                                f4 = f5;
                            }
                            int a2 = mo571a(i2, ykVar, zkVar2.f18443m);
                            int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(round, 1073741824);
                            b.measure(makeMeasureSpec, a2);
                            i9 = b.getMeasuredWidth();
                            i8 = b.getMeasuredHeight();
                            mo577a(i14, makeMeasureSpec, a2, b);
                            this.f546a.mo3110a(i14, b);
                        }
                        i7 = Math.max(i13, this.f546a.mo3106a(b) + ykVar.mo3176j() + ykVar.mo3179m() + i8);
                        zkVar2.f18435e = ykVar.mo3168e() + ykVar.mo3177k() + i9 + zkVar2.f18435e;
                    } else {
                        int measuredHeight2 = b.getMeasuredHeight();
                        long[] jArr3 = this.f550e;
                        if (jArr3 != null) {
                            measuredHeight2 = mo572a(jArr3[i14]);
                        }
                        int measuredWidth2 = b.getMeasuredWidth();
                        long[] jArr4 = this.f550e;
                        if (jArr4 != null) {
                            measuredWidth2 = (int) jArr4[i14];
                        }
                        if (this.f547b[i14] || ykVar.mo3161a() <= f2) {
                            i10 = i5;
                            int i19 = i;
                        } else {
                            float a3 = (ykVar.mo3161a() * f3) + ((float) measuredHeight2);
                            if (i12 == zkVar2.f18438h - 1) {
                                a3 += f4;
                                f4 = 0.0f;
                            }
                            int round2 = Math.round(a3);
                            if (round2 > ykVar.mo3175i()) {
                                round2 = ykVar.mo3175i();
                                this.f547b[i14] = true;
                                zkVar2.f18440j -= ykVar.mo3161a();
                                i10 = i5;
                                z2 = true;
                            } else {
                                float f6 = (a3 - ((float) round2)) + f4;
                                i10 = i5;
                                double d4 = (double) f6;
                                if (d4 > 1.0d) {
                                    round2++;
                                    Double.isNaN(d4);
                                    d2 = d4 - 1.0d;
                                } else if (d4 < -1.0d) {
                                    round2--;
                                    Double.isNaN(d4);
                                    d2 = d4 + 1.0d;
                                } else {
                                    f4 = f6;
                                }
                                f4 = (float) d2;
                            }
                            int b2 = mo588b(i, ykVar, zkVar2.f18443m);
                            int makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(round2, 1073741824);
                            b.measure(b2, makeMeasureSpec2);
                            measuredWidth2 = b.getMeasuredWidth();
                            int measuredHeight3 = b.getMeasuredHeight();
                            mo577a(i14, b2, makeMeasureSpec2, b);
                            this.f546a.mo3110a(i14, b);
                            measuredHeight2 = measuredHeight3;
                        }
                        i7 = Math.max(i13, this.f546a.mo3106a(b) + ykVar.mo3168e() + ykVar.mo3177k() + measuredWidth2);
                        zkVar2.f18435e = ykVar.mo3176j() + ykVar.mo3179m() + measuredHeight2 + zkVar2.f18435e;
                        int i20 = i2;
                        i6 = i10;
                    }
                    zkVar2.f18437g = Math.max(zkVar2.f18437g, i7);
                    i13 = i7;
                }
                i12++;
                i5 = i6;
                f2 = 0.0f;
            }
            int i21 = i2;
            int i22 = i5;
            if (z2 && i22 != zkVar2.f18435e) {
                mo578a(i, i2, zkVar, i3, i4, true);
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:109:0x02b7  */
    /* JADX WARNING: Removed duplicated region for block: B:112:0x02d0  */
    /* JADX WARNING: Removed duplicated region for block: B:113:0x02d3  */
    /* JADX WARNING: Removed duplicated region for block: B:116:0x02e3  */
    /* JADX WARNING: Removed duplicated region for block: B:117:0x02e6  */
    /* JADX WARNING: Removed duplicated region for block: B:120:0x02f0  */
    /* JADX WARNING: Removed duplicated region for block: B:123:0x02fa  */
    /* JADX WARNING: Removed duplicated region for block: B:124:0x02ff  */
    /* JADX WARNING: Removed duplicated region for block: B:127:0x032e  */
    /* JADX WARNING: Removed duplicated region for block: B:128:0x0333  */
    /* JADX WARNING: Removed duplicated region for block: B:131:0x0358  */
    /* JADX WARNING: Removed duplicated region for block: B:138:0x038b  */
    /* JADX WARNING: Removed duplicated region for block: B:150:0x03bb A[ADDED_TO_REGION] */
    /* JADX WARNING: Removed duplicated region for block: B:93:0x0233  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo579a(p000.C0111al.C0113b r28, int r29, int r30, int r31, int r32, int r33, java.util.List<p000.C2458zk> r34) {
        /*
            r27 = this;
            r0 = r27
            r1 = r28
            r2 = r29
            r3 = r30
            r4 = r33
            xk r5 = r0.f546a
            boolean r5 = r5.mo3117a()
            int r6 = android.view.View.MeasureSpec.getMode(r29)
            int r7 = android.view.View.MeasureSpec.getSize(r29)
            if (r34 != 0) goto L_0x0020
            java.util.ArrayList r8 = new java.util.ArrayList
            r8.<init>()
            goto L_0x0022
        L_0x0020:
            r8 = r34
        L_0x0022:
            r1.f551a = r8
            r9 = -1
            if (r4 != r9) goto L_0x0029
            r12 = 1
            goto L_0x002a
        L_0x0029:
            r12 = 0
        L_0x002a:
            xk r13 = r0.f546a
            if (r5 == 0) goto L_0x0033
            int r13 = r13.getPaddingStart()
            goto L_0x0037
        L_0x0033:
            int r13 = r13.getPaddingTop()
        L_0x0037:
            xk r14 = r0.f546a
            if (r5 == 0) goto L_0x0040
            int r14 = r14.getPaddingEnd()
            goto L_0x0044
        L_0x0040:
            int r14 = r14.getPaddingBottom()
        L_0x0044:
            xk r15 = r0.f546a
            if (r5 == 0) goto L_0x004d
            int r15 = r15.getPaddingTop()
            goto L_0x0051
        L_0x004d:
            int r15 = r15.getPaddingStart()
        L_0x0051:
            xk r10 = r0.f546a
            if (r5 == 0) goto L_0x005a
            int r10 = r10.getPaddingBottom()
            goto L_0x005e
        L_0x005a:
            int r10 = r10.getPaddingEnd()
        L_0x005e:
            zk r9 = new zk
            r9.<init>()
            r11 = r32
            r9.f18445o = r11
            int r13 = r13 + r14
            r9.f18435e = r13
            xk r14 = r0.f546a
            int r14 = r14.getFlexItemCount()
            r17 = -2147483648(0xffffffff80000000, float:-0.0)
            r1 = r9
            r19 = r12
            r4 = 0
            r9 = 0
            r12 = 0
            r18 = -2147483648(0xffffffff80000000, float:-0.0)
        L_0x007a:
            if (r11 >= r14) goto L_0x03d6
            r32 = r12
            xk r12 = r0.f546a
            android.view.View r12 = r12.mo3121b(r11)
            if (r12 != 0) goto L_0x0092
            boolean r12 = r0.mo586a((int) r11, (int) r14, (p000.C2458zk) r1)
            if (r12 == 0) goto L_0x008f
            r0.mo585a((java.util.List<p000.C2458zk>) r8, (p000.C2458zk) r1, (int) r11, (int) r4)
        L_0x008f:
            r20 = r9
            goto L_0x00b0
        L_0x0092:
            r20 = r9
            int r9 = r12.getVisibility()
            r3 = 8
            if (r9 != r3) goto L_0x00c4
            int r3 = r1.f18439i
            r9 = 1
            int r3 = r3 + r9
            r1.f18439i = r3
            int r3 = r1.f18438h
            int r3 = r3 + r9
            r1.f18438h = r3
            boolean r3 = r0.mo586a((int) r11, (int) r14, (p000.C2458zk) r1)
            if (r3 == 0) goto L_0x00b0
            r0.mo585a((java.util.List<p000.C2458zk>) r8, (p000.C2458zk) r1, (int) r11, (int) r4)
        L_0x00b0:
            r24 = r6
            r2 = r7
            r7 = r8
            r26 = r10
            r3 = r14
            r9 = r20
            r12 = -1
            r6 = r30
            r14 = r31
            r10 = r32
            r8 = r33
            goto L_0x03c7
        L_0x00c4:
            boolean r3 = r12 instanceof android.widget.CompoundButton
            if (r3 == 0) goto L_0x0106
            r3 = r12
            android.widget.CompoundButton r3 = (android.widget.CompoundButton) r3
            android.view.ViewGroup$LayoutParams r9 = r3.getLayoutParams()
            yk r9 = (p000.C2367yk) r9
            r21 = r14
            int r14 = r9.mo3170g()
            r22 = r8
            int r8 = r9.mo3169f()
            android.graphics.drawable.Drawable r3 = p000.C0815h0.m5785a((android.widget.CompoundButton) r3)
            if (r3 != 0) goto L_0x00e6
            r23 = 0
            goto L_0x00ea
        L_0x00e6:
            int r23 = r3.getMinimumWidth()
        L_0x00ea:
            if (r3 != 0) goto L_0x00f0
            r3 = -1
            r24 = 0
            goto L_0x00f7
        L_0x00f0:
            int r3 = r3.getMinimumHeight()
            r24 = r3
            r3 = -1
        L_0x00f7:
            if (r14 != r3) goto L_0x00fb
            r14 = r23
        L_0x00fb:
            r9.mo3164b(r14)
            if (r8 != r3) goto L_0x0102
            r8 = r24
        L_0x0102:
            r9.mo3162a(r8)
            goto L_0x010a
        L_0x0106:
            r22 = r8
            r21 = r14
        L_0x010a:
            android.view.ViewGroup$LayoutParams r3 = r12.getLayoutParams()
            yk r3 = (p000.C2367yk) r3
            int r8 = r3.mo3165c()
            r9 = 4
            if (r8 != r9) goto L_0x0120
            java.util.List<java.lang.Integer> r8 = r1.f18444n
            java.lang.Integer r9 = java.lang.Integer.valueOf(r11)
            r8.add(r9)
        L_0x0120:
            if (r5 == 0) goto L_0x0127
            int r8 = r3.getWidth()
            goto L_0x012b
        L_0x0127:
            int r8 = r3.getHeight()
        L_0x012b:
            float r9 = r3.mo3163b()
            r14 = -1082130432(0xffffffffbf800000, float:-1.0)
            int r9 = (r9 > r14 ? 1 : (r9 == r14 ? 0 : -1))
            if (r9 == 0) goto L_0x0144
            r9 = 1073741824(0x40000000, float:2.0)
            if (r6 != r9) goto L_0x0144
            float r8 = (float) r7
            float r9 = r3.mo3163b()
            float r9 = r9 * r8
            int r8 = java.lang.Math.round(r9)
        L_0x0144:
            if (r5 == 0) goto L_0x0181
            xk r9 = r0.f546a
            r14 = 1
            int r16 = r0.mo597d(r3, r14)
            int r16 = r16 + r13
            int r23 = r0.mo590b(r3, r14)
            int r14 = r23 + r16
            int r8 = r9.mo3120b(r2, r14, r8)
            xk r9 = r0.f546a
            int r14 = r15 + r10
            r23 = r7
            r7 = 1
            int r16 = r0.mo595c(r3, r7)
            int r14 = r16 + r14
            int r24 = r0.mo573a((p000.C2367yk) r3, (boolean) r7)
            int r24 = r24 + r14
            int r7 = r24 + r4
            int r14 = r3.getHeight()
            r24 = r6
            r6 = r30
            int r7 = r9.mo3105a((int) r6, (int) r7, (int) r14)
            r12.measure(r8, r7)
            r0.mo577a((int) r11, (int) r8, (int) r7, (android.view.View) r12)
            goto L_0x01ba
        L_0x0181:
            r24 = r6
            r23 = r7
            r6 = r30
            xk r7 = r0.f546a
            int r9 = r15 + r10
            r14 = 0
            int r25 = r0.mo595c(r3, r14)
            int r25 = r25 + r9
            int r9 = r0.mo573a((p000.C2367yk) r3, (boolean) r14)
            int r9 = r9 + r25
            int r9 = r9 + r4
            int r14 = r3.getWidth()
            int r7 = r7.mo3120b(r6, r9, r14)
            xk r9 = r0.f546a
            r14 = 0
            int r25 = r0.mo597d(r3, r14)
            int r25 = r25 + r13
            int r26 = r0.mo590b(r3, r14)
            int r14 = r26 + r25
            int r8 = r9.mo3105a((int) r2, (int) r14, (int) r8)
            r12.measure(r7, r8)
            r0.mo577a((int) r11, (int) r7, (int) r8, (android.view.View) r12)
        L_0x01ba:
            xk r7 = r0.f546a
            r7.mo3110a(r11, r12)
            r0.mo580a((android.view.View) r12, (int) r11)
            int r7 = r12.getMeasuredState()
            r9 = r20
            int r9 = android.view.View.combineMeasuredStates(r9, r7)
            int r7 = r1.f18435e
            if (r5 == 0) goto L_0x01d5
            int r14 = r12.getMeasuredWidth()
            goto L_0x01d9
        L_0x01d5:
            int r14 = r12.getMeasuredHeight()
        L_0x01d9:
            int r20 = r0.mo597d(r3, r5)
            int r20 = r20 + r14
            int r14 = r0.mo590b(r3, r5)
            int r14 = r14 + r20
            int r20 = r22.size()
            xk r2 = r0.f546a
            int r2 = r2.getFlexWrap()
            if (r2 != 0) goto L_0x01f2
            goto L_0x01fc
        L_0x01f2:
            boolean r2 = r3.mo3174h()
            if (r2 == 0) goto L_0x01fa
            r2 = 1
            goto L_0x01fd
        L_0x01fa:
            if (r24 != 0) goto L_0x0207
        L_0x01fc:
            r2 = 0
        L_0x01fd:
            r7 = r2
            r25 = r9
            r26 = r10
            r2 = r23
            r9 = r32
            goto L_0x0231
        L_0x0207:
            xk r2 = r0.f546a
            int r2 = r2.getMaxLine()
            r25 = r9
            r9 = -1
            r26 = r10
            if (r2 == r9) goto L_0x021e
            r9 = 1
            int r10 = r20 + 1
            if (r2 > r10) goto L_0x021e
            r9 = r32
            r2 = r23
            goto L_0x0230
        L_0x021e:
            xk r2 = r0.f546a
            r9 = r32
            int r2 = r2.mo3107a((android.view.View) r12, (int) r11, (int) r9)
            if (r2 <= 0) goto L_0x0229
            int r14 = r14 + r2
        L_0x0229:
            int r7 = r7 + r14
            r2 = r23
            if (r2 >= r7) goto L_0x0230
            r7 = 1
            goto L_0x0231
        L_0x0230:
            r7 = 0
        L_0x0231:
            if (r7 == 0) goto L_0x02b7
            int r7 = r1.mo13328a()
            if (r7 <= 0) goto L_0x024a
            if (r11 <= 0) goto L_0x0240
            int r10 = r11 + -1
            r7 = r22
            goto L_0x0243
        L_0x0240:
            r7 = r22
            r10 = 0
        L_0x0243:
            r0.mo585a((java.util.List<p000.C2458zk>) r7, (p000.C2458zk) r1, (int) r10, (int) r4)
            int r1 = r1.f18437g
            int r4 = r4 + r1
            goto L_0x024c
        L_0x024a:
            r7 = r22
        L_0x024c:
            if (r5 == 0) goto L_0x0279
            int r1 = r3.getHeight()
            r9 = -1
            if (r1 != r9) goto L_0x02a6
            xk r1 = r0.f546a
            int r9 = r1.getPaddingTop()
            xk r10 = r0.f546a
            int r10 = r10.getPaddingBottom()
            int r10 = r10 + r9
            int r9 = r3.mo3179m()
            int r9 = r9 + r10
            int r10 = r3.mo3176j()
            int r10 = r10 + r9
            int r10 = r10 + r4
            int r9 = r3.getHeight()
            int r1 = r1.mo3105a((int) r6, (int) r10, (int) r9)
            r12.measure(r8, r1)
            goto L_0x02a3
        L_0x0279:
            int r1 = r3.getWidth()
            r9 = -1
            if (r1 != r9) goto L_0x02a6
            xk r1 = r0.f546a
            int r9 = r1.getPaddingLeft()
            xk r10 = r0.f546a
            int r10 = r10.getPaddingRight()
            int r10 = r10 + r9
            int r9 = r3.mo3177k()
            int r9 = r9 + r10
            int r10 = r3.mo3168e()
            int r10 = r10 + r9
            int r10 = r10 + r4
            int r9 = r3.getWidth()
            int r1 = r1.mo3120b(r6, r10, r9)
            r12.measure(r1, r8)
        L_0x02a3:
            r0.mo580a((android.view.View) r12, (int) r11)
        L_0x02a6:
            zk r1 = new zk
            r1.<init>()
            r8 = 1
            r1.f18438h = r8
            r1.f18435e = r13
            r1.f18445o = r11
            r9 = r4
            r4 = -2147483648(0xffffffff80000000, float:-0.0)
            r10 = 0
            goto L_0x02c4
        L_0x02b7:
            r7 = r22
            r8 = 1
            int r10 = r1.f18438h
            int r10 = r10 + r8
            r1.f18438h = r10
            int r10 = r9 + 1
            r9 = r4
            r4 = r18
        L_0x02c4:
            boolean r14 = r1.f18447q
            float r16 = r3.mo3161a()
            r18 = 0
            int r16 = (r16 > r18 ? 1 : (r16 == r18 ? 0 : -1))
            if (r16 == 0) goto L_0x02d3
            r16 = 1
            goto L_0x02d5
        L_0x02d3:
            r16 = 0
        L_0x02d5:
            r14 = r14 | r16
            r1.f18447q = r14
            boolean r14 = r1.f18448r
            float r16 = r3.mo3166d()
            int r16 = (r16 > r18 ? 1 : (r16 == r18 ? 0 : -1))
            if (r16 == 0) goto L_0x02e6
            r16 = 1
            goto L_0x02e8
        L_0x02e6:
            r16 = 0
        L_0x02e8:
            r14 = r14 | r16
            r1.f18448r = r14
            int[] r14 = r0.f548c
            if (r14 == 0) goto L_0x02f6
            int r16 = r7.size()
            r14[r11] = r16
        L_0x02f6:
            int r14 = r1.f18435e
            if (r5 == 0) goto L_0x02ff
            int r16 = r12.getMeasuredWidth()
            goto L_0x0303
        L_0x02ff:
            int r16 = r12.getMeasuredHeight()
        L_0x0303:
            int r18 = r0.mo597d(r3, r5)
            int r18 = r18 + r16
            int r16 = r0.mo590b(r3, r5)
            int r16 = r16 + r18
            int r14 = r16 + r14
            r1.f18435e = r14
            float r14 = r1.f18440j
            float r16 = r3.mo3161a()
            float r14 = r16 + r14
            r1.f18440j = r14
            float r14 = r1.f18441k
            float r16 = r3.mo3166d()
            float r14 = r16 + r14
            r1.f18441k = r14
            xk r14 = r0.f546a
            r14.mo3113a(r12, r11, r10, r1)
            if (r5 == 0) goto L_0x0333
            int r14 = r12.getMeasuredHeight()
            goto L_0x0337
        L_0x0333:
            int r14 = r12.getMeasuredWidth()
        L_0x0337:
            int r16 = r0.mo595c(r3, r5)
            int r16 = r16 + r14
            int r14 = r0.mo573a((p000.C2367yk) r3, (boolean) r5)
            int r14 = r14 + r16
            xk r8 = r0.f546a
            int r8 = r8.mo3106a((android.view.View) r12)
            int r8 = r8 + r14
            int r4 = java.lang.Math.max(r4, r8)
            int r8 = r1.f18437g
            int r8 = java.lang.Math.max(r8, r4)
            r1.f18437g = r8
            if (r5 == 0) goto L_0x0383
            xk r8 = r0.f546a
            int r8 = r8.getFlexWrap()
            r14 = 2
            if (r8 == r14) goto L_0x036d
            int r8 = r1.f18442l
            int r12 = r12.getBaseline()
            int r3 = r3.mo3179m()
            int r3 = r3 + r12
            goto L_0x037d
        L_0x036d:
            int r8 = r1.f18442l
            int r14 = r12.getMeasuredHeight()
            int r12 = r12.getBaseline()
            int r14 = r14 - r12
            int r3 = r3.mo3176j()
            int r3 = r3 + r14
        L_0x037d:
            int r3 = java.lang.Math.max(r8, r3)
            r1.f18442l = r3
        L_0x0383:
            r3 = r21
            boolean r8 = r0.mo586a((int) r11, (int) r3, (p000.C2458zk) r1)
            if (r8 == 0) goto L_0x0391
            r0.mo585a((java.util.List<p000.C2458zk>) r7, (p000.C2458zk) r1, (int) r11, (int) r9)
            int r8 = r1.f18437g
            int r9 = r9 + r8
        L_0x0391:
            r8 = r33
            r12 = -1
            if (r8 == r12) goto L_0x03b7
            int r14 = r7.size()
            if (r14 <= 0) goto L_0x03b7
            int r14 = r7.size()
            int r14 = r14 + r12
            java.lang.Object r14 = r7.get(r14)
            zk r14 = (p000.C2458zk) r14
            int r14 = r14.f18446p
            if (r14 < r8) goto L_0x03b7
            if (r11 < r8) goto L_0x03b7
            if (r19 != 0) goto L_0x03b7
            int r9 = r1.f18437g
            int r9 = -r9
            r14 = r31
            r19 = 1
            goto L_0x03b9
        L_0x03b7:
            r14 = r31
        L_0x03b9:
            if (r9 <= r14) goto L_0x03c2
            if (r19 == 0) goto L_0x03c2
            r1 = r28
            r9 = r25
            goto L_0x03d8
        L_0x03c2:
            r18 = r4
            r4 = r9
            r9 = r25
        L_0x03c7:
            int r11 = r11 + 1
            r14 = r3
            r3 = r6
            r8 = r7
            r12 = r10
            r6 = r24
            r10 = r26
            r7 = r2
            r2 = r29
            goto L_0x007a
        L_0x03d6:
            r1 = r28
        L_0x03d8:
            r1.f552b = r9
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0111al.mo579a(al$b, int, int, int, int, int, java.util.List):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:10:0x002d  */
    /* JADX WARNING: Removed duplicated region for block: B:11:0x0032  */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x0040  */
    /* JADX WARNING: Removed duplicated region for block: B:18:? A[RETURN, SYNTHETIC] */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo580a(android.view.View r7, int r8) {
        /*
            r6 = this;
            android.view.ViewGroup$LayoutParams r0 = r7.getLayoutParams()
            yk r0 = (p000.C2367yk) r0
            int r1 = r7.getMeasuredWidth()
            int r2 = r7.getMeasuredHeight()
            int r3 = r0.mo3170g()
            r4 = 1
            if (r1 >= r3) goto L_0x001b
            int r1 = r0.mo3170g()
        L_0x0019:
            r3 = 1
            goto L_0x0027
        L_0x001b:
            int r3 = r0.mo3178l()
            if (r1 <= r3) goto L_0x0026
            int r1 = r0.mo3178l()
            goto L_0x0019
        L_0x0026:
            r3 = 0
        L_0x0027:
            int r5 = r0.mo3169f()
            if (r2 >= r5) goto L_0x0032
            int r2 = r0.mo3169f()
            goto L_0x003e
        L_0x0032:
            int r5 = r0.mo3175i()
            if (r2 <= r5) goto L_0x003d
            int r2 = r0.mo3175i()
            goto L_0x003e
        L_0x003d:
            r4 = r3
        L_0x003e:
            if (r4 == 0) goto L_0x0055
            r0 = 1073741824(0x40000000, float:2.0)
            int r1 = android.view.View.MeasureSpec.makeMeasureSpec(r1, r0)
            int r0 = android.view.View.MeasureSpec.makeMeasureSpec(r2, r0)
            r7.measure(r1, r0)
            r6.mo577a((int) r8, (int) r1, (int) r0, (android.view.View) r7)
            xk r0 = r6.f546a
            r0.mo3110a(r8, r7)
        L_0x0055:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0111al.mo580a(android.view.View, int):void");
    }

    /* renamed from: a */
    public final void mo581a(View view, int i, int i2) {
        C2367yk ykVar = (C2367yk) view.getLayoutParams();
        int min = Math.min(Math.max(((i - ykVar.mo3177k()) - ykVar.mo3168e()) - this.f546a.mo3106a(view), ykVar.mo3170g()), ykVar.mo3178l());
        long[] jArr = this.f550e;
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(jArr != null ? mo572a(jArr[i2]) : view.getMeasuredHeight(), 1073741824);
        int makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(min, 1073741824);
        view.measure(makeMeasureSpec2, makeMeasureSpec);
        mo577a(i2, makeMeasureSpec2, makeMeasureSpec, view);
        this.f546a.mo3110a(i2, view);
    }

    /* renamed from: a */
    public void mo582a(View view, C2458zk zkVar, int i, int i2, int i3, int i4) {
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int j;
        int i10;
        C2367yk ykVar = (C2367yk) view.getLayoutParams();
        int alignItems = this.f546a.getAlignItems();
        if (ykVar.mo3165c() != -1) {
            alignItems = ykVar.mo3165c();
        }
        int i11 = zkVar.f18437g;
        if (alignItems != 0) {
            if (alignItems != 1) {
                if (alignItems == 2) {
                    int m = ((ykVar.mo3179m() + (i11 - view.getMeasuredHeight())) - ykVar.mo3176j()) / 2;
                    int i12 = this.f546a.getFlexWrap() != 2 ? i2 + m : i2 - m;
                    view.layout(i, i12, i3, view.getMeasuredHeight() + i12);
                    return;
                } else if (alignItems == 3) {
                    int flexWrap = this.f546a.getFlexWrap();
                    int i13 = zkVar.f18442l;
                    if (flexWrap != 2) {
                        i10 = Math.max(i13 - view.getBaseline(), ykVar.mo3179m());
                        i6 = i2 + i10;
                    } else {
                        i7 = Math.max(view.getBaseline() + (i13 - view.getMeasuredHeight()), ykVar.mo3176j());
                        j = i2 - i7;
                        i5 = i4 - i7;
                        view.layout(i, i6, i3, i5);
                    }
                } else if (alignItems != 4) {
                    return;
                }
            } else if (this.f546a.getFlexWrap() != 2) {
                int i14 = i2 + i11;
                i9 = (i14 - view.getMeasuredHeight()) - ykVar.mo3176j();
                i8 = i14 - ykVar.mo3176j();
                view.layout(i, i9, i3, i8);
                return;
            } else {
                i6 = ykVar.mo3179m() + view.getMeasuredHeight() + (i2 - i11);
                i10 = view.getMeasuredHeight() + (i4 - i11);
                i4 = ykVar.mo3179m();
            }
            i5 = i4 + i10;
            view.layout(i, i6, i3, i5);
        }
        if (this.f546a.getFlexWrap() != 2) {
            i9 = ykVar.mo3179m() + i2;
            i8 = ykVar.mo3179m() + i4;
            view.layout(i, i9, i3, i8);
            return;
        }
        j = i2 - ykVar.mo3176j();
        i7 = ykVar.mo3176j();
        i5 = i4 - i7;
        view.layout(i, i6, i3, i5);
    }

    /* renamed from: a */
    public void mo583a(View view, C2458zk zkVar, boolean z, int i, int i2, int i3, int i4) {
        int i5;
        int i6;
        C2367yk ykVar = (C2367yk) view.getLayoutParams();
        int alignItems = this.f546a.getAlignItems();
        if (ykVar.mo3165c() != -1) {
            alignItems = ykVar.mo3165c();
        }
        int i7 = zkVar.f18437g;
        if (alignItems != 0) {
            if (alignItems != 1) {
                if (alignItems == 2) {
                    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
                    int b = ((C0815h0.m5837b(marginLayoutParams) + (i7 - view.getMeasuredWidth())) - C0815h0.m5774a(marginLayoutParams)) / 2;
                    if (!z) {
                        i6 = i + b;
                        i5 = i3 + b;
                    } else {
                        i6 = i - b;
                        i5 = i3 - b;
                    }
                    view.layout(i6, i2, i5, i4);
                } else if (!(alignItems == 3 || alignItems == 4)) {
                    return;
                }
            } else if (!z) {
                i6 = ((i + i7) - view.getMeasuredWidth()) - ykVar.mo3168e();
                i3 = (i3 + i7) - view.getMeasuredWidth();
                i5 = i3 - ykVar.mo3168e();
                view.layout(i6, i2, i5, i4);
            } else {
                int k = ykVar.mo3177k();
                view.layout(ykVar.mo3177k() + view.getMeasuredWidth() + (i - i7), i2, k + view.getMeasuredWidth() + (i3 - i7), i4);
                return;
            }
        }
        if (!z) {
            view.layout(ykVar.mo3177k() + i, i2, ykVar.mo3177k() + i3, i4);
            return;
        }
        i6 = i - ykVar.mo3168e();
        i5 = i3 - ykVar.mo3168e();
        view.layout(i6, i2, i5, i4);
    }

    /* renamed from: a */
    public void mo584a(List<C2458zk> list, int i) {
        int i2 = this.f548c[i];
        if (i2 == -1) {
            i2 = 0;
        }
        for (int size = list.size() - 1; size >= i2; size--) {
            list.remove(size);
        }
        int[] iArr = this.f548c;
        int length = iArr.length - 1;
        if (i > length) {
            Arrays.fill(iArr, -1);
        } else {
            Arrays.fill(iArr, i, length, -1);
        }
        long[] jArr = this.f549d;
        int length2 = jArr.length - 1;
        if (i > length2) {
            Arrays.fill(jArr, 0);
        } else {
            Arrays.fill(jArr, i, length2, 0);
        }
    }

    /* renamed from: a */
    public final void mo585a(List<C2458zk> list, C2458zk zkVar, int i, int i2) {
        zkVar.f18443m = i2;
        this.f546a.mo3114a(zkVar);
        zkVar.f18446p = i;
        list.add(zkVar);
    }

    /* renamed from: a */
    public final boolean mo586a(int i, int i2, C2458zk zkVar) {
        return i == i2 - 1 && zkVar.mo13328a() != 0;
    }

    /* renamed from: a */
    public final int[] mo587a(int i, List<C0114c> list, SparseIntArray sparseIntArray) {
        Collections.sort(list);
        sparseIntArray.clear();
        int[] iArr = new int[i];
        int i2 = 0;
        for (C0114c next : list) {
            int i3 = next.f553X;
            iArr[i2] = i3;
            sparseIntArray.append(i3, next.f554Y);
            i2++;
        }
        return iArr;
    }

    /* renamed from: b */
    public final int mo588b(int i, C2367yk ykVar, int i2) {
        int g;
        C2290xk xkVar = this.f546a;
        int b = xkVar.mo3120b(i, ykVar.mo3168e() + ykVar.mo3177k() + this.f546a.getPaddingRight() + xkVar.getPaddingLeft() + i2, ykVar.getWidth());
        int size = View.MeasureSpec.getSize(b);
        if (size > ykVar.mo3178l()) {
            g = ykVar.mo3178l();
        } else if (size >= ykVar.mo3170g()) {
            return b;
        } else {
            g = ykVar.mo3170g();
        }
        return View.MeasureSpec.makeMeasureSpec(g, View.MeasureSpec.getMode(b));
    }

    /* renamed from: b */
    public int mo589b(long j) {
        return (int) j;
    }

    /* renamed from: b */
    public final int mo590b(C2367yk ykVar, boolean z) {
        return z ? ykVar.mo3168e() : ykVar.mo3176j();
    }

    /* renamed from: b */
    public void mo591b(int i) {
        int[] iArr = this.f548c;
        if (iArr == null) {
            if (i < 10) {
                i = 10;
            }
            this.f548c = new int[i];
        } else if (iArr.length < i) {
            int length = iArr.length * 2;
            if (length >= i) {
                i = length;
            }
            this.f548c = Arrays.copyOf(this.f548c, i);
        }
    }

    /* renamed from: b */
    public void mo592b(int i, int i2, int i3) {
        int i4;
        int i5;
        int i6;
        int flexItemCount = this.f546a.getFlexItemCount();
        boolean[] zArr = this.f547b;
        int i7 = 0;
        if (zArr == null) {
            if (flexItemCount < 10) {
                flexItemCount = 10;
            }
            this.f547b = new boolean[flexItemCount];
        } else if (zArr.length < flexItemCount) {
            int length = zArr.length * 2;
            if (length >= flexItemCount) {
                flexItemCount = length;
            }
            this.f547b = new boolean[flexItemCount];
        } else {
            Arrays.fill(zArr, false);
        }
        if (i3 < this.f546a.getFlexItemCount()) {
            int flexDirection = this.f546a.getFlexDirection();
            int flexDirection2 = this.f546a.getFlexDirection();
            if (flexDirection2 == 0 || flexDirection2 == 1) {
                int mode = View.MeasureSpec.getMode(i);
                int size = View.MeasureSpec.getSize(i);
                int largestMainSize = this.f546a.getLargestMainSize();
                if (mode != 1073741824 && largestMainSize <= size) {
                    size = largestMainSize;
                }
                i6 = this.f546a.getPaddingLeft();
                i4 = this.f546a.getPaddingRight();
            } else if (flexDirection2 == 2 || flexDirection2 == 3) {
                int mode2 = View.MeasureSpec.getMode(i2);
                i5 = View.MeasureSpec.getSize(i2);
                if (mode2 != 1073741824) {
                    i5 = this.f546a.getLargestMainSize();
                }
                i6 = this.f546a.getPaddingTop();
                i4 = this.f546a.getPaddingBottom();
            } else {
                throw new IllegalArgumentException(C0789gk.m5568b("Invalid flex direction: ", flexDirection));
            }
            int i8 = i6 + i4;
            int[] iArr = this.f548c;
            if (iArr != null) {
                i7 = iArr[i3];
            }
            List<C2458zk> flexLinesInternal = this.f546a.getFlexLinesInternal();
            int size2 = flexLinesInternal.size();
            while (i7 < size2) {
                C2458zk zkVar = flexLinesInternal.get(i7);
                if (zkVar.f18435e < i5 && zkVar.f18447q) {
                    mo578a(i, i2, zkVar, i5, i8, false);
                } else if (zkVar.f18435e > i5 && zkVar.f18448r) {
                    mo593b(i, i2, zkVar, i5, i8, false);
                }
                i7++;
            }
        }
    }

    /* renamed from: b */
    public final void mo593b(int i, int i2, C2458zk zkVar, int i3, int i4, boolean z) {
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        C2458zk zkVar2 = zkVar;
        int i11 = i3;
        int i12 = zkVar2.f18435e;
        float f = zkVar2.f18441k;
        float f2 = 0.0f;
        if (f > 0.0f && i11 <= i12) {
            float f3 = ((float) (i12 - i11)) / f;
            zkVar2.f18435e = i4 + zkVar2.f18436f;
            if (!z) {
                zkVar2.f18437g = RecyclerView.UNDEFINED_DURATION;
            }
            int i13 = 0;
            boolean z2 = false;
            float f4 = 0.0f;
            int i14 = 0;
            while (i13 < zkVar2.f18438h) {
                int i15 = zkVar2.f18445o + i13;
                View b = this.f546a.mo3121b(i15);
                if (b == null || b.getVisibility() == 8) {
                    int i16 = i2;
                    i6 = i12;
                    i5 = i13;
                } else {
                    C2367yk ykVar = (C2367yk) b.getLayoutParams();
                    int flexDirection = this.f546a.getFlexDirection();
                    if (flexDirection == 0 || flexDirection == 1) {
                        i6 = i12;
                        int i17 = i13;
                        int i18 = i;
                        int measuredWidth = b.getMeasuredWidth();
                        long[] jArr = this.f550e;
                        if (jArr != null) {
                            measuredWidth = (int) jArr[i15];
                        }
                        int measuredHeight = b.getMeasuredHeight();
                        long[] jArr2 = this.f550e;
                        int i19 = i17;
                        if (jArr2 != null) {
                            measuredHeight = mo572a(jArr2[i15]);
                        }
                        if (this.f547b[i15] || ykVar.mo3166d() <= 0.0f) {
                            int i20 = i2;
                            i10 = i19;
                            i9 = measuredWidth;
                            i8 = measuredHeight;
                        } else {
                            float d = ((float) measuredWidth) - (ykVar.mo3166d() * f3);
                            i10 = i19;
                            if (i10 == zkVar2.f18438h - 1) {
                                d += f4;
                                f4 = 0.0f;
                            }
                            int round = Math.round(d);
                            if (round < ykVar.mo3170g()) {
                                round = ykVar.mo3170g();
                                this.f547b[i15] = true;
                                zkVar2.f18441k -= ykVar.mo3166d();
                                z2 = true;
                            } else {
                                float f5 = (d - ((float) round)) + f4;
                                double d2 = (double) f5;
                                if (d2 > 1.0d) {
                                    round++;
                                    f5 -= 1.0f;
                                } else if (d2 < -1.0d) {
                                    round--;
                                    f5 += 1.0f;
                                }
                                f4 = f5;
                            }
                            int a = mo571a(i2, ykVar, zkVar2.f18443m);
                            int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(round, 1073741824);
                            b.measure(makeMeasureSpec, a);
                            i9 = b.getMeasuredWidth();
                            i8 = b.getMeasuredHeight();
                            mo577a(i15, makeMeasureSpec, a, b);
                            this.f546a.mo3110a(i15, b);
                        }
                        i7 = Math.max(i14, this.f546a.mo3106a(b) + ykVar.mo3176j() + ykVar.mo3179m() + i8);
                        zkVar2.f18435e = ykVar.mo3168e() + ykVar.mo3177k() + i9 + zkVar2.f18435e;
                    } else {
                        int measuredHeight2 = b.getMeasuredHeight();
                        long[] jArr3 = this.f550e;
                        if (jArr3 != null) {
                            measuredHeight2 = mo572a(jArr3[i15]);
                        }
                        int measuredWidth2 = b.getMeasuredWidth();
                        long[] jArr4 = this.f550e;
                        if (jArr4 != null) {
                            measuredWidth2 = (int) jArr4[i15];
                        }
                        if (this.f547b[i15] || ykVar.mo3166d() <= f2) {
                            i6 = i12;
                            i5 = i13;
                            int i21 = i;
                        } else {
                            float d3 = ((float) measuredHeight2) - (ykVar.mo3166d() * f3);
                            if (i13 == zkVar2.f18438h - 1) {
                                d3 += f4;
                                f4 = 0.0f;
                            }
                            int round2 = Math.round(d3);
                            if (round2 < ykVar.mo3169f()) {
                                round2 = ykVar.mo3169f();
                                this.f547b[i15] = true;
                                zkVar2.f18441k -= ykVar.mo3166d();
                                i6 = i12;
                                i5 = i13;
                                z2 = true;
                            } else {
                                float f6 = (d3 - ((float) round2)) + f4;
                                i6 = i12;
                                i5 = i13;
                                double d4 = (double) f6;
                                if (d4 > 1.0d) {
                                    round2++;
                                    f6 -= 1.0f;
                                } else if (d4 < -1.0d) {
                                    round2--;
                                    f6 += 1.0f;
                                }
                                f4 = f6;
                            }
                            int b2 = mo588b(i, ykVar, zkVar2.f18443m);
                            int makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(round2, 1073741824);
                            b.measure(b2, makeMeasureSpec2);
                            measuredWidth2 = b.getMeasuredWidth();
                            int measuredHeight3 = b.getMeasuredHeight();
                            mo577a(i15, b2, makeMeasureSpec2, b);
                            this.f546a.mo3110a(i15, b);
                            measuredHeight2 = measuredHeight3;
                        }
                        i7 = Math.max(i14, this.f546a.mo3106a(b) + ykVar.mo3168e() + ykVar.mo3177k() + measuredWidth2);
                        zkVar2.f18435e = ykVar.mo3176j() + ykVar.mo3179m() + measuredHeight2 + zkVar2.f18435e;
                        int i22 = i2;
                    }
                    zkVar2.f18437g = Math.max(zkVar2.f18437g, i7);
                    i14 = i7;
                }
                i13 = i5 + 1;
                i12 = i6;
                f2 = 0.0f;
            }
            int i23 = i2;
            int i24 = i12;
            if (z2 && i24 != zkVar2.f18435e) {
                mo593b(i, i2, zkVar, i3, i4, true);
            }
        }
    }

    /* renamed from: b */
    public final void mo594b(View view, int i, int i2) {
        C2367yk ykVar = (C2367yk) view.getLayoutParams();
        int min = Math.min(Math.max(((i - ykVar.mo3179m()) - ykVar.mo3176j()) - this.f546a.mo3106a(view), ykVar.mo3169f()), ykVar.mo3175i());
        long[] jArr = this.f550e;
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(jArr != null ? (int) jArr[i2] : view.getMeasuredWidth(), 1073741824);
        int makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(min, 1073741824);
        view.measure(makeMeasureSpec, makeMeasureSpec2);
        mo577a(i2, makeMeasureSpec, makeMeasureSpec2, view);
        this.f546a.mo3110a(i2, view);
    }

    /* renamed from: c */
    public final int mo595c(C2367yk ykVar, boolean z) {
        return z ? ykVar.mo3179m() : ykVar.mo3177k();
    }

    /* renamed from: c */
    public void mo596c(int i) {
        long[] jArr = this.f549d;
        if (jArr == null) {
            if (i < 10) {
                i = 10;
            }
            this.f549d = new long[i];
        } else if (jArr.length < i) {
            int length = jArr.length * 2;
            if (length >= i) {
                i = length;
            }
            this.f549d = Arrays.copyOf(this.f549d, i);
        }
    }

    /* renamed from: d */
    public final int mo597d(C2367yk ykVar, boolean z) {
        return z ? ykVar.mo3177k() : ykVar.mo3179m();
    }

    /* renamed from: d */
    public void mo598d(int i) {
        long[] jArr = this.f550e;
        if (jArr == null) {
            if (i < 10) {
                i = 10;
            }
            this.f550e = new long[i];
        } else if (jArr.length < i) {
            int length = jArr.length * 2;
            if (length >= i) {
                i = length;
            }
            this.f550e = Arrays.copyOf(this.f550e, i);
        }
    }

    /* renamed from: e */
    public void mo599e(int i) {
        View b;
        if (i < this.f546a.getFlexItemCount()) {
            int flexDirection = this.f546a.getFlexDirection();
            if (this.f546a.getAlignItems() == 4) {
                int[] iArr = this.f548c;
                List<C2458zk> flexLinesInternal = this.f546a.getFlexLinesInternal();
                int size = flexLinesInternal.size();
                for (int i2 = iArr != null ? iArr[i] : 0; i2 < size; i2++) {
                    C2458zk zkVar = flexLinesInternal.get(i2);
                    int i3 = zkVar.f18438h;
                    for (int i4 = 0; i4 < i3; i4++) {
                        int i5 = zkVar.f18445o + i4;
                        if (!(i4 >= this.f546a.getFlexItemCount() || (b = this.f546a.mo3121b(i5)) == null || b.getVisibility() == 8)) {
                            C2367yk ykVar = (C2367yk) b.getLayoutParams();
                            if (ykVar.mo3165c() == -1 || ykVar.mo3165c() == 4) {
                                if (flexDirection == 0 || flexDirection == 1) {
                                    mo594b(b, zkVar.f18437g, i5);
                                } else if (flexDirection == 2 || flexDirection == 3) {
                                    mo581a(b, zkVar.f18437g, i5);
                                } else {
                                    throw new IllegalArgumentException(C0789gk.m5568b("Invalid flex direction: ", flexDirection));
                                }
                            }
                        }
                    }
                }
                return;
            }
            for (C2458zk next : this.f546a.getFlexLinesInternal()) {
                Iterator<Integer> it = next.f18444n.iterator();
                while (true) {
                    if (it.hasNext()) {
                        Integer next2 = it.next();
                        View b2 = this.f546a.mo3121b(next2.intValue());
                        if (flexDirection == 0 || flexDirection == 1) {
                            mo594b(b2, next.f18437g, next2.intValue());
                        } else if (flexDirection == 2 || flexDirection == 3) {
                            mo581a(b2, next.f18437g, next2.intValue());
                        } else {
                            throw new IllegalArgumentException(C0789gk.m5568b("Invalid flex direction: ", flexDirection));
                        }
                    }
                }
            }
        }
    }
}
