package p000;

/* renamed from: ev */
public class C0627ev extends C0327bx {
    public C0627ev() {
    }

    public C0627ev(mq2 mq2) {
        super(mq2);
    }
}
