package p000;

import android.os.Build;
import android.view.View;
import android.view.WindowInsets;

/* renamed from: b0 */
public class C0276b0 implements C1746r7 {

    /* renamed from: a */
    public final /* synthetic */ C0011a0 f1611a;

    public C0276b0(C0011a0 a0Var) {
        this.f1611a = a0Var;
    }

    /* renamed from: a */
    public C0592e8 mo1250a(View view, C0592e8 e8Var) {
        int d = e8Var.mo5057d();
        int h = this.f1611a.mo42h(d);
        if (d != h) {
            e8Var = Build.VERSION.SDK_INT >= 20 ? new C0592e8(((WindowInsets) e8Var.f4319a).replaceSystemWindowInsets(e8Var.mo5055b(), h, e8Var.mo5056c(), e8Var.mo5054a())) : null;
        }
        return C2189w7.m14977a(view, e8Var);
    }
}
