package p000;

/* renamed from: c6 */
public final class C0340c6 {
    /* renamed from: a */
    public static int m2308a(int i) {
        if (i <= 4) {
            return 8;
        }
        return i * 2;
    }
}
