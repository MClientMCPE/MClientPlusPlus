package p000;

import android.view.View;
import android.webkit.WebView;
import android.widget.ImageView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.RejectedExecutionException;
import org.json.JSONException;
import org.json.JSONObject;

/* renamed from: bh */
public class C0302bh {

    /* renamed from: a */
    public dc3 f1936a;

    /* renamed from: b */
    public cc3 f1937b;

    /* renamed from: c */
    public pc3 f1938c;

    /* renamed from: d */
    public List<mc3> f1939d = new ArrayList();

    /* renamed from: e */
    public int f1940e = -1;

    /* renamed from: f */
    public String f1941f = "";

    /* renamed from: g */
    public boolean f1942g;

    /* renamed from: h */
    public boolean f1943h;

    /* renamed from: i */
    public boolean f1944i;

    /* renamed from: j */
    public boolean f1945j;

    /* renamed from: k */
    public boolean f1946k;

    /* renamed from: l */
    public int f1947l;

    /* renamed from: m */
    public int f1948m;

    /* renamed from: n */
    public String f1949n = "";

    /* renamed from: o */
    public String f1950o = "";

    /* renamed from: bh$a */
    public class C0303a implements Runnable {

        /* renamed from: X */
        public final /* synthetic */ String f1951X;

        public C0303a(String str) {
            this.f1951X = str;
        }

        public void run() {
            JSONObject jSONObject = new JSONObject();
            JSONObject jSONObject2 = new JSONObject();
            C0680fe.m4784a(jSONObject2, "session_type", C0302bh.this.f1940e);
            C0680fe.m4785a(jSONObject2, "session_id", C0302bh.this.f1941f);
            C0680fe.m4785a(jSONObject2, "event", this.f1951X);
            C0680fe.m4785a(jSONObject, "type", "iab_hook");
            C0680fe.m4785a(jSONObject, "message", jSONObject2.toString());
            try {
                jSONObject.put("m_target", 0);
            } catch (JSONException e) {
                StringBuilder a = C0789gk.m5562a("JSON Error in ADCMessage constructor: ");
                a.append(e.toString());
                C0869hj.f6827i.mo6566a(a.toString());
            }
            if (jSONObject == null) {
                jSONObject = new JSONObject();
            }
            C0789gk.m5567a(jSONObject, "m_type", "CustomMessage.controller_send", jSONObject);
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:19:0x0076  */
    /* JADX WARNING: Removed duplicated region for block: B:22:0x0083  */
    /* JADX WARNING: Removed duplicated region for block: B:25:0x0090  */
    /* JADX WARNING: Removed duplicated region for block: B:29:0x009d A[SYNTHETIC, Splitter:B:29:0x009d] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public C0302bh(org.json.JSONObject r10, java.lang.String r11) {
        /*
            r9 = this;
            r9.<init>()
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            r9.f1939d = r0
            r0 = -1
            r9.f1940e = r0
            java.lang.String r1 = ""
            r9.f1941f = r1
            r9.f1949n = r1
            r9.f1950o = r1
            int r2 = r9.f1940e
            r3 = 0
            r4 = 1
            if (r2 != r0) goto L_0x0052
            java.lang.String r0 = "ad_unit_type"
            int r0 = r10.optInt(r0)
            java.lang.String r2 = "ad_type"
            java.lang.String r2 = r10.optString(r2)
            if (r0 != 0) goto L_0x002a
            goto L_0x0034
        L_0x002a:
            if (r0 != r4) goto L_0x0052
            java.lang.String r0 = "video"
            boolean r0 = r2.equals(r0)
            if (r0 == 0) goto L_0x0036
        L_0x0034:
            r0 = 0
            goto L_0x0054
        L_0x0036:
            java.lang.String r0 = "display"
            boolean r0 = r2.equals(r0)
            if (r0 == 0) goto L_0x0040
            r0 = 1
            goto L_0x0054
        L_0x0040:
            java.lang.String r0 = "banner_display"
            boolean r0 = r2.equals(r0)
            if (r0 != 0) goto L_0x0050
            java.lang.String r0 = "interstitial_display"
            boolean r0 = r2.equals(r0)
            if (r0 == 0) goto L_0x0052
        L_0x0050:
            r0 = 2
            goto L_0x0054
        L_0x0052:
            int r0 = r9.f1940e
        L_0x0054:
            r9.f1940e = r0
            java.lang.String r0 = "skippable"
            boolean r0 = r10.optBoolean(r0)
            r9.f1945j = r0
            java.lang.String r0 = "skip_offset"
            int r0 = r10.optInt(r0)
            r9.f1947l = r0
            java.lang.String r0 = "video_duration"
            int r0 = r10.optInt(r0)
            r9.f1948m = r0
            java.lang.String r0 = "js_resources"
            org.json.JSONArray r0 = r10.optJSONArray(r0)
            if (r0 != 0) goto L_0x007b
            org.json.JSONArray r0 = new org.json.JSONArray
            r0.<init>()
        L_0x007b:
            java.lang.String r2 = "verification_params"
            org.json.JSONArray r2 = r10.optJSONArray(r2)
            if (r2 != 0) goto L_0x0088
            org.json.JSONArray r2 = new org.json.JSONArray
            r2.<init>()
        L_0x0088:
            java.lang.String r5 = "vendor_keys"
            org.json.JSONArray r5 = r10.optJSONArray(r5)
            if (r5 != 0) goto L_0x0095
            org.json.JSONArray r5 = new org.json.JSONArray
            r5.<init>()
        L_0x0095:
            r9.f1950o = r11
        L_0x0097:
            int r11 = r0.length()
            if (r3 >= r11) goto L_0x00f2
            java.lang.String r11 = r2.optString(r3)     // Catch:{ MalformedURLException -> 0x00dc }
            java.lang.String r6 = r5.optString(r3)     // Catch:{ MalformedURLException -> 0x00dc }
            java.net.URL r7 = new java.net.URL     // Catch:{ MalformedURLException -> 0x00dc }
            java.lang.String r8 = r0.optString(r3)     // Catch:{ MalformedURLException -> 0x00dc }
            r7.<init>(r8)     // Catch:{ MalformedURLException -> 0x00dc }
            boolean r8 = r11.equals(r1)     // Catch:{ MalformedURLException -> 0x00dc }
            if (r8 != 0) goto L_0x00cf
            boolean r8 = r6.equals(r1)     // Catch:{ MalformedURLException -> 0x00dc }
            if (r8 != 0) goto L_0x00cf
            java.lang.String r8 = "VendorKey is null or empty"
            p000.t53.m13109a((java.lang.String) r6, (java.lang.String) r8)     // Catch:{ MalformedURLException -> 0x00dc }
            java.lang.String r8 = "ResourceURL is null"
            p000.t53.m13107a((java.lang.Object) r7, (java.lang.String) r8)     // Catch:{ MalformedURLException -> 0x00dc }
            java.lang.String r8 = "VerificationParameters is null or empty"
            p000.t53.m13109a((java.lang.String) r11, (java.lang.String) r8)     // Catch:{ MalformedURLException -> 0x00dc }
            mc3 r8 = new mc3     // Catch:{ MalformedURLException -> 0x00dc }
            r8.<init>(r6, r7, r11)     // Catch:{ MalformedURLException -> 0x00dc }
            goto L_0x00d6
        L_0x00cf:
            r6.equals(r1)     // Catch:{ MalformedURLException -> 0x00dc }
            mc3 r8 = p000.mc3.m9138a(r7)     // Catch:{ MalformedURLException -> 0x00dc }
        L_0x00d6:
            java.util.List<mc3> r11 = r9.f1939d     // Catch:{ MalformedURLException -> 0x00dc }
            r11.add(r8)     // Catch:{ MalformedURLException -> 0x00dc }
            goto L_0x00ef
        L_0x00dc:
            java.lang.StringBuilder r11 = new java.lang.StringBuilder
            r11.<init>()
            java.lang.String r6 = "Invalid js resource url passed to Omid"
            r11.append(r6)
            hj r6 = p000.C0869hj.f6827i
            java.lang.String r11 = r11.toString()
            r6.mo6566a(r11)
        L_0x00ef:
            int r3 = r3 + 1
            goto L_0x0097
        L_0x00f2:
            vg r11 = p000.C0680fe.m4730a()     // Catch:{ IOException -> 0x010b }
            ui r11 = r11.mo11968i()     // Catch:{ IOException -> 0x010b }
            java.lang.String r0 = "filepath"
            java.lang.String r10 = r10.optString(r0)     // Catch:{ IOException -> 0x010b }
            java.lang.StringBuilder r10 = r11.mo11678a((java.lang.String) r10, (boolean) r4)     // Catch:{ IOException -> 0x010b }
            java.lang.String r10 = r10.toString()     // Catch:{ IOException -> 0x010b }
            r9.f1949n = r10     // Catch:{ IOException -> 0x010b }
            goto L_0x011e
        L_0x010b:
            java.lang.StringBuilder r10 = new java.lang.StringBuilder
            r10.<init>()
            java.lang.String r11 = "Error loading IAB JS Client"
            r10.append(r11)
            hj r11 = p000.C0869hj.f6827i
            java.lang.String r10 = r10.toString()
            r11.mo6566a(r10)
        L_0x011e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0302bh.<init>(org.json.JSONObject, java.lang.String):void");
    }

    /* renamed from: a */
    public void mo2530a(WebView webView) {
        String str;
        List<mc3> list;
        nc3 nc3;
        if (this.f1940e >= 0 && (str = this.f1949n) != null && !str.equals("") && (list = this.f1939d) != null) {
            if (!list.isEmpty() || this.f1940e == 2) {
                C2120vg a = C0680fe.m4730a();
                kc3 kc3 = kc3.NATIVE;
                jc3 jc3 = jc3.BEGIN_TO_RENDER;
                int i = this.f1940e;
                if (i == 0) {
                    hc3 hc3 = hc3.VIDEO;
                    dc3 a2 = dc3.m3553a(ec3.m4015a(hc3, jc3, kc3, kc3, false), fc3.m4621a(a.f16031O, this.f1949n, this.f1939d, (String) null, (String) null));
                    this.f1936a = a2;
                    nc3 = (nc3) a2;
                } else if (i == 1) {
                    hc3 hc32 = hc3.NATIVE_DISPLAY;
                    dc3 a3 = dc3.m3553a(ec3.m4015a(hc32, jc3, kc3, (kc3) null, false), fc3.m4621a(a.f16031O, this.f1949n, this.f1939d, (String) null, (String) null));
                    this.f1936a = a3;
                    nc3 = (nc3) a3;
                } else if (i == 2) {
                    hc3 hc33 = hc3.HTML_DISPLAY;
                    lc3 lc3 = a.f16031O;
                    t53.m13107a((Object) lc3, "Partner is null");
                    t53.m13107a((Object) webView, "WebView is null");
                    dc3 a4 = dc3.m3553a(ec3.m4015a(hc33, jc3, kc3, (kc3) null, false), new fc3(lc3, webView, (String) null, (List<mc3>) null, "", (String) null, gc3.HTML));
                    this.f1936a = a4;
                    this.f1941f = ((nc3) a4).f11034h;
                    return;
                } else {
                    return;
                }
                this.f1941f = nc3.f11034h;
                mo2531a("inject_javascript");
            }
        }
    }

    /* renamed from: a */
    public void mo2533a(C1335mg mgVar) {
        pc3 pc3;
        rc3 rc3;
        if (!this.f1944i && this.f1940e >= 0 && this.f1936a != null) {
            mo2531a("register_ad_view");
            C2277xi xiVar = C0680fe.m4730a().mo11952a().get(Integer.valueOf(mgVar.f10221k0));
            if (xiVar == null && !mgVar.f10213c0.isEmpty()) {
                xiVar = (C2277xi) mgVar.f10213c0.entrySet().iterator().next().getValue();
            }
            dc3 dc3 = this.f1936a;
            if (dc3 != null && xiVar != null) {
                dc3.mo4736a(xiVar);
                ImageView imageView = xiVar.f17212M0;
                if (imageView != null) {
                    C1335mg mgVar2 = xiVar.f17210K0;
                    ic3 ic3 = ic3.OTHER;
                    dc3 dc32 = mgVar2.f10234x0;
                    if (dc32 != null) {
                        try {
                            dc32.mo4737a(imageView, ic3, (String) null);
                        } catch (RuntimeException unused) {
                        }
                    }
                }
            } else if (dc3 != null) {
                dc3.mo4736a(mgVar);
                mgVar.f10234x0 = this.f1936a;
                HashMap<Integer, View> hashMap = mgVar.f10217g0;
                if (!(mgVar.f10234x0 == null || hashMap == null)) {
                    for (Map.Entry<Integer, View> value : hashMap.entrySet()) {
                        mgVar.mo8728a((View) value.getValue(), ic3.OTHER);
                    }
                }
                mo2531a("register_obstructions");
            }
            C0859hf.m6214a((C1616pf) new C0373ch(this), "viewability_ad_event");
            if (this.f1940e != 0) {
                pc3 = null;
            } else {
                dc3 dc33 = this.f1936a;
                nc3 nc3 = (nc3) dc33;
                t53.m13107a((Object) dc33, "AdSession is null");
                if (!nc3.f11028b.mo5089b()) {
                    throw new IllegalStateException("Cannot create MediaEvents for JavaScript AdSession");
                } else if (nc3.mo9216d()) {
                    throw new IllegalStateException("AdSession is started");
                } else if (nc3.f11033g) {
                    throw new IllegalStateException("AdSession is finished");
                } else if (nc3.f11031e.f7456c == null) {
                    pc3 = new pc3(nc3);
                    nc3.f11031e.f7456c = pc3;
                } else {
                    throw new IllegalStateException("MediaEvents already exists for AdSession");
                }
            }
            this.f1938c = pc3;
            this.f1936a.mo4735a();
            dc3 dc34 = this.f1936a;
            nc3 nc32 = (nc3) dc34;
            t53.m13107a((Object) dc34, "AdSession is null");
            if (nc32.f11031e.f7455b != null) {
                throw new IllegalStateException("AdEvents already exists for AdSession");
            } else if (!nc32.f11033g) {
                cc3 cc3 = new cc3(nc32);
                nc32.f11031e.f7455b = cc3;
                this.f1937b = cc3;
                mo2531a("start_session");
                if (this.f1938c != null) {
                    qc3 qc3 = qc3.PREROLL;
                    if (this.f1945j) {
                        t53.m13107a((Object) qc3, "Position is null");
                        rc3 = new rc3(true, Float.valueOf((float) this.f1947l), true, qc3);
                    } else {
                        t53.m13107a((Object) qc3, "Position is null");
                        rc3 = new rc3(false, (Float) null, true, qc3);
                    }
                    this.f1937b.mo2900a(rc3);
                } else {
                    cc3 cc32 = this.f1937b;
                    t53.m13129b(cc32.f2650a);
                    t53.m13137c(cc32.f2650a);
                    nc3 nc33 = cc32.f2650a;
                    nc33.mo9217e();
                    nc33.f11031e.mo6943f();
                    nc33.f11036j = true;
                }
                this.f1944i = true;
            } else {
                throw new IllegalStateException("AdSession is finished");
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:100:0x0195, code lost:
        mo2531a(r13);
        mo2529a();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:112:0x01f3, code lost:
        mo2531a(r13);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:127:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:128:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:130:?, code lost:
        return;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:94:0x016f, code lost:
        r12.f1942g = true;
        r12.f1943h = false;
     */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo2532a(java.lang.String r13, float r14) {
        /*
            r12 = this;
            boolean r0 = p000.C0680fe.m4810b()
            if (r0 == 0) goto L_0x021d
            dc3 r0 = r12.f1936a
            if (r0 != 0) goto L_0x000c
            goto L_0x021d
        L_0x000c:
            pc3 r0 = r12.f1938c
            java.lang.String r1 = "cancel"
            java.lang.String r2 = "continue"
            java.lang.String r3 = "skip"
            java.lang.String r4 = "start"
            if (r0 != 0) goto L_0x0031
            boolean r0 = r13.equals(r4)
            if (r0 != 0) goto L_0x0031
            boolean r0 = r13.equals(r3)
            if (r0 != 0) goto L_0x0031
            boolean r0 = r13.equals(r2)
            if (r0 != 0) goto L_0x0031
            boolean r0 = r13.equals(r1)
            if (r0 != 0) goto L_0x0031
            return
        L_0x0031:
            r0 = -1
            int r5 = r13.hashCode()     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            java.lang.String r6 = "complete"
            java.lang.String r7 = "resume"
            java.lang.String r8 = "midpoint"
            r9 = 1
            r10 = 0
            java.lang.String r11 = "pause"
            switch(r5) {
                case -1941887438: goto L_0x00d8;
                case -1710060637: goto L_0x00cd;
                case -1638835128: goto L_0x00c5;
                case -1367724422: goto L_0x00bd;
                case -934426579: goto L_0x00b4;
                case -651914917: goto L_0x00aa;
                case -599445191: goto L_0x00a2;
                case -567202649: goto L_0x009a;
                case -342650039: goto L_0x008f;
                case 3532159: goto L_0x0087;
                case 106440182: goto L_0x007e;
                case 109757538: goto L_0x0075;
                case 583742045: goto L_0x0069;
                case 823102269: goto L_0x005d;
                case 1648173410: goto L_0x0051;
                case 1906584668: goto L_0x0045;
                default: goto L_0x0043;
            }
        L_0x0043:
            goto L_0x00e1
        L_0x0045:
            java.lang.String r1 = "buffer_end"
            boolean r1 = r13.equals(r1)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            if (r1 == 0) goto L_0x00e1
            r0 = 13
            goto L_0x00e1
        L_0x0051:
            java.lang.String r1 = "sound_unmute"
            boolean r1 = r13.equals(r1)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            if (r1 == 0) goto L_0x00e1
            r0 = 9
            goto L_0x00e1
        L_0x005d:
            java.lang.String r1 = "html5_interaction"
            boolean r1 = r13.equals(r1)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            if (r1 == 0) goto L_0x00e1
            r0 = 15
            goto L_0x00e1
        L_0x0069:
            java.lang.String r1 = "in_video_engagement"
            boolean r1 = r13.equals(r1)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            if (r1 == 0) goto L_0x00e1
            r0 = 14
            goto L_0x00e1
        L_0x0075:
            boolean r1 = r13.equals(r4)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            if (r1 == 0) goto L_0x00e1
            r0 = 0
            goto L_0x00e1
        L_0x007e:
            boolean r1 = r13.equals(r11)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            if (r1 == 0) goto L_0x00e1
            r0 = 10
            goto L_0x00e1
        L_0x0087:
            boolean r1 = r13.equals(r3)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            if (r1 == 0) goto L_0x00e1
            r0 = 6
            goto L_0x00e1
        L_0x008f:
            java.lang.String r1 = "sound_mute"
            boolean r1 = r13.equals(r1)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            if (r1 == 0) goto L_0x00e1
            r0 = 8
            goto L_0x00e1
        L_0x009a:
            boolean r1 = r13.equals(r2)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            if (r1 == 0) goto L_0x00e1
            r0 = 5
            goto L_0x00e1
        L_0x00a2:
            boolean r1 = r13.equals(r6)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            if (r1 == 0) goto L_0x00e1
            r0 = 4
            goto L_0x00e1
        L_0x00aa:
            java.lang.String r1 = "third_quartile"
            boolean r1 = r13.equals(r1)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            if (r1 == 0) goto L_0x00e1
            r0 = 3
            goto L_0x00e1
        L_0x00b4:
            boolean r1 = r13.equals(r7)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            if (r1 == 0) goto L_0x00e1
            r0 = 11
            goto L_0x00e1
        L_0x00bd:
            boolean r1 = r13.equals(r1)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            if (r1 == 0) goto L_0x00e1
            r0 = 7
            goto L_0x00e1
        L_0x00c5:
            boolean r1 = r13.equals(r8)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            if (r1 == 0) goto L_0x00e1
            r0 = 2
            goto L_0x00e1
        L_0x00cd:
            java.lang.String r1 = "buffer_start"
            boolean r1 = r13.equals(r1)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            if (r1 == 0) goto L_0x00e1
            r0 = 12
            goto L_0x00e1
        L_0x00d8:
            java.lang.String r1 = "first_quartile"
            boolean r1 = r13.equals(r1)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            if (r1 == 0) goto L_0x00e1
            r0 = 1
        L_0x00e1:
            r1 = 1065353216(0x3f800000, float:1.0)
            r2 = 0
            switch(r0) {
                case 0: goto L_0x01df;
                case 1: goto L_0x01ce;
                case 2: goto L_0x01bf;
                case 3: goto L_0x01ae;
                case 4: goto L_0x019d;
                case 5: goto L_0x0195;
                case 6: goto L_0x0183;
                case 7: goto L_0x0183;
                case 8: goto L_0x017c;
                case 9: goto L_0x0175;
                case 10: goto L_0x0152;
                case 11: goto L_0x0135;
                case 12: goto L_0x0123;
                case 13: goto L_0x0111;
                case 14: goto L_0x00e9;
                case 15: goto L_0x00e9;
                default: goto L_0x00e7;
            }     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
        L_0x00e7:
            goto L_0x021d
        L_0x00e9:
            pc3 r14 = r12.f1938c     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            oc3 r0 = p000.oc3.CLICK     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            r14.mo9988a((p000.oc3) r0)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            r12.mo2531a((java.lang.String) r13)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            boolean r14 = r12.f1943h     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            if (r14 == 0) goto L_0x021d
            boolean r14 = r12.f1942g     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            if (r14 != 0) goto L_0x021d
            boolean r14 = r12.f1946k     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            if (r14 != 0) goto L_0x021d
            pc3 r14 = r12.f1938c     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            nc3 r0 = r14.f12387a     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            p000.t53.m13129b((p000.nc3) r0)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            nc3 r14 = r14.f12387a     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            id3 r14 = r14.f11031e     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            r14.mo6934a((java.lang.String) r11)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            r12.mo2531a((java.lang.String) r11)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            goto L_0x016f
        L_0x0111:
            pc3 r14 = r12.f1938c     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            nc3 r0 = r14.f12387a     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            p000.t53.m13129b((p000.nc3) r0)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            nc3 r14 = r14.f12387a     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            id3 r14 = r14.f11031e     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            java.lang.String r0 = "bufferFinish"
            r14.mo6934a((java.lang.String) r0)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            goto L_0x01f3
        L_0x0123:
            pc3 r14 = r12.f1938c     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            nc3 r0 = r14.f12387a     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            p000.t53.m13129b((p000.nc3) r0)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            nc3 r14 = r14.f12387a     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            id3 r14 = r14.f11031e     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            java.lang.String r0 = "bufferStart"
            r14.mo6934a((java.lang.String) r0)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            goto L_0x01f3
        L_0x0135:
            boolean r14 = r12.f1942g     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            if (r14 == 0) goto L_0x021d
            boolean r14 = r12.f1946k     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            if (r14 != 0) goto L_0x021d
            pc3 r14 = r12.f1938c     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            nc3 r0 = r14.f12387a     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            p000.t53.m13129b((p000.nc3) r0)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            nc3 r14 = r14.f12387a     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            id3 r14 = r14.f11031e     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            r14.mo6934a((java.lang.String) r7)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            r12.mo2531a((java.lang.String) r13)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            r12.f1942g = r10     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            goto L_0x021d
        L_0x0152:
            boolean r14 = r12.f1942g     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            if (r14 != 0) goto L_0x021d
            boolean r14 = r12.f1943h     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            if (r14 != 0) goto L_0x021d
            boolean r14 = r12.f1946k     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            if (r14 != 0) goto L_0x021d
            pc3 r14 = r12.f1938c     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            nc3 r0 = r14.f12387a     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            p000.t53.m13129b((p000.nc3) r0)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            nc3 r14 = r14.f12387a     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            id3 r14 = r14.f11031e     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            r14.mo6934a((java.lang.String) r11)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            r12.mo2531a((java.lang.String) r13)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
        L_0x016f:
            r12.f1942g = r9     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            r12.f1943h = r10     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            goto L_0x021d
        L_0x0175:
            pc3 r14 = r12.f1938c     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            r14.mo9989b(r1)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            goto L_0x01f3
        L_0x017c:
            pc3 r14 = r12.f1938c     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            r14.mo9989b(r2)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            goto L_0x01f3
        L_0x0183:
            pc3 r14 = r12.f1938c     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            if (r14 == 0) goto L_0x0195
            nc3 r0 = r14.f12387a     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            p000.t53.m13129b((p000.nc3) r0)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            nc3 r14 = r14.f12387a     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            id3 r14 = r14.f11031e     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            java.lang.String r0 = "skipped"
            r14.mo6934a((java.lang.String) r0)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
        L_0x0195:
            r12.mo2531a((java.lang.String) r13)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            r12.mo2529a()     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            goto L_0x021d
        L_0x019d:
            r12.f1946k = r9     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            pc3 r14 = r12.f1938c     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            nc3 r0 = r14.f12387a     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            p000.t53.m13129b((p000.nc3) r0)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            nc3 r14 = r14.f12387a     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            id3 r14 = r14.f11031e     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            r14.mo6934a((java.lang.String) r6)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            goto L_0x01f3
        L_0x01ae:
            pc3 r14 = r12.f1938c     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            nc3 r0 = r14.f12387a     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            p000.t53.m13129b((p000.nc3) r0)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            nc3 r14 = r14.f12387a     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            id3 r14 = r14.f11031e     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            java.lang.String r0 = "thirdQuartile"
            r14.mo6934a((java.lang.String) r0)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            goto L_0x01f3
        L_0x01bf:
            pc3 r14 = r12.f1938c     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            nc3 r0 = r14.f12387a     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            p000.t53.m13129b((p000.nc3) r0)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            nc3 r14 = r14.f12387a     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            id3 r14 = r14.f11031e     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            r14.mo6934a((java.lang.String) r8)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            goto L_0x01f3
        L_0x01ce:
            pc3 r14 = r12.f1938c     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            nc3 r0 = r14.f12387a     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            p000.t53.m13129b((p000.nc3) r0)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            nc3 r14 = r14.f12387a     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            id3 r14 = r14.f11031e     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            java.lang.String r0 = "firstQuartile"
            r14.mo6934a((java.lang.String) r0)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            goto L_0x01f3
        L_0x01df:
            cc3 r0 = r12.f1937b     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            r0.mo2899a()     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            pc3 r0 = r12.f1938c     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            if (r0 == 0) goto L_0x01f3
            int r2 = (r14 > r2 ? 1 : (r14 == r2 ? 0 : -1))
            if (r2 <= 0) goto L_0x01ed
            goto L_0x01f0
        L_0x01ed:
            int r14 = r12.f1948m     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            float r14 = (float) r14     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
        L_0x01f0:
            r0.mo9987a(r14, r1)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
        L_0x01f3:
            r12.mo2531a((java.lang.String) r13)     // Catch:{ IllegalStateException -> 0x01f9, IllegalArgumentException -> 0x01f7 }
            goto L_0x021d
        L_0x01f7:
            r14 = move-exception
            goto L_0x01fa
        L_0x01f9:
            r14 = move-exception
        L_0x01fa:
            java.lang.String r0 = "Recording IAB event for "
            java.lang.StringBuilder r13 = p000.C0789gk.m5569b((java.lang.String) r0, (java.lang.String) r13)
            java.lang.String r0 = " caused "
            java.lang.StringBuilder r0 = p000.C0789gk.m5562a((java.lang.String) r0)
            java.lang.Class r14 = r14.getClass()
            r0.append(r14)
            java.lang.String r14 = r0.toString()
            r13.append(r14)
            hj r14 = p000.C0869hj.f6825g
            java.lang.String r13 = r13.toString()
            r14.mo6566a(r13)
        L_0x021d:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0302bh.mo2532a(java.lang.String, float):void");
    }

    /* renamed from: a */
    public void mo2529a() {
        C0859hf.m6211a("viewability_ad_event");
        nc3 nc3 = (nc3) this.f1936a;
        if (!nc3.f11033g) {
            nc3.f11030d.clear();
            if (!nc3.f11033g) {
                nc3.f11029c.clear();
            }
            nc3.f11033g = true;
            nc3.f11031e.mo6940c();
            sc3 sc3 = sc3.f14127c;
            boolean c = sc3.mo10928c();
            sc3.f14128a.remove(nc3);
            sc3.f14129b.remove(nc3);
            if (c && !sc3.mo10928c()) {
                yc3.m16408c().mo12901b();
            }
            nc3.f11031e.mo6939b();
            nc3.f11031e = null;
        }
        mo2531a("end_session");
        this.f1936a = null;
    }

    /* renamed from: a */
    public final void mo2531a(String str) {
        try {
            C1062ji.f8458a.execute(new C0303a(str));
        } catch (RejectedExecutionException e) {
            StringBuilder sb = new StringBuilder();
            StringBuilder a = C0789gk.m5562a("ADCOmidManager.sendIabCustomMessage failed with error: ");
            a.append(e.toString());
            sb.append(a.toString());
            C0869hj.f6827i.mo6566a(sb.toString());
        }
    }
}
