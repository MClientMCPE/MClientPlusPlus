package p000;

/* renamed from: dq */
public interface C0553dq {
}
