package p000;

import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;

/* renamed from: d6 */
public abstract class C0517d6 {

    /* renamed from: d6$a */
    public class C0518a implements Runnable {

        /* renamed from: X */
        public final /* synthetic */ Typeface f3739X;

        public C0518a(Typeface typeface) {
            this.f3739X = typeface;
        }

        public void run() {
            C0517d6.this.mo4680a(this.f3739X);
        }
    }

    /* renamed from: d6$b */
    public class C0519b implements Runnable {

        /* renamed from: X */
        public final /* synthetic */ int f3741X;

        public C0519b(int i) {
            this.f3741X = i;
        }

        public void run() {
            C0517d6.this.mo4678a(this.f3741X);
        }
    }

    /* renamed from: a */
    public abstract void mo4678a(int i);

    /* renamed from: a */
    public final void mo4679a(int i, Handler handler) {
        if (handler == null) {
            handler = new Handler(Looper.getMainLooper());
        }
        handler.post(new C0519b(i));
    }

    /* renamed from: a */
    public abstract void mo4680a(Typeface typeface);

    /* renamed from: a */
    public final void mo4681a(Typeface typeface, Handler handler) {
        if (handler == null) {
            handler = new Handler(Looper.getMainLooper());
        }
        handler.post(new C0518a(typeface));
    }
}
