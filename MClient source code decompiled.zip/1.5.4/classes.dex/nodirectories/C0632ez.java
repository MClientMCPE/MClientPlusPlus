package p000;

import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: ez */
public final class C0632ez implements Parcelable.Creator<C0330bz> {
    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        Parcel parcel2 = parcel;
        int b = C0680fe.m4795b(parcel);
        String str = null;
        byte[] bArr = null;
        String[] strArr = null;
        String[] strArr2 = null;
        long j = 0;
        boolean z = false;
        int i = 0;
        boolean z2 = false;
        while (parcel.dataPosition() < b) {
            int readInt = parcel.readInt();
            switch (65535 & readInt) {
                case 1:
                    z = C0680fe.m4869g(parcel2, readInt);
                    break;
                case 2:
                    str = C0680fe.m4826c(parcel2, readInt);
                    break;
                case 3:
                    i = C0680fe.m4879j(parcel2, readInt);
                    break;
                case 4:
                    bArr = C0680fe.m4814b(parcel2, readInt);
                    break;
                case 5:
                    strArr = C0680fe.m4848d(parcel2, readInt);
                    break;
                case 6:
                    strArr2 = C0680fe.m4848d(parcel2, readInt);
                    break;
                case 7:
                    z2 = C0680fe.m4869g(parcel2, readInt);
                    break;
                case 8:
                    j = C0680fe.m4882k(parcel2, readInt);
                    break;
                default:
                    C0680fe.m4887m(parcel2, readInt);
                    break;
            }
        }
        C0680fe.m4863f(parcel2, b);
        return new C0330bz(z, str, i, bArr, strArr, strArr2, z2, j);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new C0330bz[i];
    }
}
