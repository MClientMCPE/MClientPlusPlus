package p000;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.ListAdapter;
import android.widget.ListView;
import java.lang.reflect.Field;

/* renamed from: c3 */
public class C0335c3 extends ListView {

    /* renamed from: a0 */
    public final Rect f2459a0 = new Rect();

    /* renamed from: b0 */
    public int f2460b0 = 0;

    /* renamed from: c0 */
    public int f2461c0 = 0;

    /* renamed from: d0 */
    public int f2462d0 = 0;

    /* renamed from: e0 */
    public int f2463e0 = 0;

    /* renamed from: f0 */
    public int f2464f0;

    /* renamed from: g0 */
    public Field f2465g0;

    /* renamed from: h0 */
    public C0336a f2466h0;

    /* renamed from: i0 */
    public boolean f2467i0;

    /* renamed from: j0 */
    public boolean f2468j0;

    /* renamed from: k0 */
    public boolean f2469k0;

    /* renamed from: l0 */
    public C0052a8 f2470l0;

    /* renamed from: m0 */
    public C1230l8 f2471m0;

    /* renamed from: n0 */
    public C0337b f2472n0;

    /* renamed from: c3$a */
    public static class C0336a extends C1490o0 {

        /* renamed from: Y */
        public boolean f2473Y = true;

        public C0336a(Drawable drawable) {
            super(drawable);
        }

        public void draw(Canvas canvas) {
            if (this.f2473Y) {
                this.f11610X.draw(canvas);
            }
        }

        public void setHotspot(float f, float f2) {
            if (this.f2473Y) {
                C0815h0.m5800a(this.f11610X, f, f2);
            }
        }

        public void setHotspotBounds(int i, int i2, int i3, int i4) {
            if (this.f2473Y) {
                C0815h0.m5801a(this.f11610X, i, i2, i3, i4);
            }
        }

        public boolean setState(int[] iArr) {
            if (this.f2473Y) {
                return this.f11610X.setState(iArr);
            }
            return false;
        }

        public boolean setVisible(boolean z, boolean z2) {
            if (this.f2473Y) {
                return super.setVisible(z, z2);
            }
            return false;
        }
    }

    /* renamed from: c3$b */
    public class C0337b implements Runnable {
        public C0337b() {
        }

        public void run() {
            C0335c3 c3Var = C0335c3.this;
            c3Var.f2472n0 = null;
            c3Var.drawableStateChanged();
        }
    }

    public C0335c3(Context context, boolean z) {
        super(context, (AttributeSet) null, C0502d.dropDownListViewStyle);
        this.f2468j0 = z;
        setCacheColorHint(0);
        try {
            this.f2465g0 = AbsListView.class.getDeclaredField("mIsChildViewEnabled");
            this.f2465g0.setAccessible(true);
        } catch (NoSuchFieldException e) {
            e.printStackTrace();
        }
    }

    private void setSelectorEnabled(boolean z) {
        C0336a aVar = this.f2466h0;
        if (aVar != null) {
            aVar.f2473Y = z;
        }
    }

    /* renamed from: a */
    public int mo2761a(int i, int i2, int i3) {
        int listPaddingTop = getListPaddingTop();
        int listPaddingBottom = getListPaddingBottom();
        getListPaddingLeft();
        getListPaddingRight();
        int dividerHeight = getDividerHeight();
        Drawable divider = getDivider();
        ListAdapter adapter = getAdapter();
        int i4 = listPaddingTop + listPaddingBottom;
        if (adapter == null) {
            return i4;
        }
        if (dividerHeight <= 0 || divider == null) {
            dividerHeight = 0;
        }
        int count = adapter.getCount();
        int i5 = i4;
        View view = null;
        int i6 = 0;
        int i7 = 0;
        int i8 = 0;
        while (i6 < count) {
            int itemViewType = adapter.getItemViewType(i6);
            if (itemViewType != i7) {
                view = null;
                i7 = itemViewType;
            }
            view = adapter.getView(i6, view, this);
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            if (layoutParams == null) {
                layoutParams = generateDefaultLayoutParams();
                view.setLayoutParams(layoutParams);
            }
            int i9 = layoutParams.height;
            view.measure(i, i9 > 0 ? View.MeasureSpec.makeMeasureSpec(i9, 1073741824) : View.MeasureSpec.makeMeasureSpec(0, 0));
            view.forceLayout();
            if (i6 > 0) {
                i5 += dividerHeight;
            }
            i5 += view.getMeasuredHeight();
            if (i5 >= i2) {
                return (i3 < 0 || i6 <= i3 || i8 <= 0 || i5 == i2) ? i2 : i8;
            }
            if (i3 >= 0 && i6 >= i3) {
                i8 = i5;
            }
            i6++;
        }
        return i5;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:5:0x0010, code lost:
        if (r3 != 3) goto L_0x012b;
     */
    /* JADX WARNING: Removed duplicated region for block: B:72:0x0146  */
    /* JADX WARNING: Removed duplicated region for block: B:75:0x014d  */
    /* JADX WARNING: Removed duplicated region for block: B:77:0x0155  */
    /* JADX WARNING: Removed duplicated region for block: B:81:0x016c  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo2763a(android.view.MotionEvent r17, int r18) {
        /*
            r16 = this;
            r1 = r16
            r2 = r17
            int r3 = r17.getActionMasked()
            r4 = 0
            r5 = 1
            if (r3 == r5) goto L_0x0016
            r0 = 2
            if (r3 == r0) goto L_0x0014
            r0 = 3
            if (r3 == r0) goto L_0x001d
            goto L_0x012b
        L_0x0014:
            r0 = 1
            goto L_0x0017
        L_0x0016:
            r0 = 0
        L_0x0017:
            int r6 = r17.findPointerIndex(r18)
            if (r6 >= 0) goto L_0x0020
        L_0x001d:
            r0 = 0
            goto L_0x012c
        L_0x0020:
            float r7 = r2.getX(r6)
            int r7 = (int) r7
            float r6 = r2.getY(r6)
            int r6 = (int) r6
            int r8 = r1.pointToPosition(r7, r6)
            r9 = -1
            if (r8 != r9) goto L_0x0033
            goto L_0x012d
        L_0x0033:
            int r0 = r16.getFirstVisiblePosition()
            int r0 = r8 - r0
            android.view.View r10 = r1.getChildAt(r0)
            float r7 = (float) r7
            float r6 = (float) r6
            r1.f2469k0 = r5
            int r0 = android.os.Build.VERSION.SDK_INT
            r11 = 21
            if (r0 < r11) goto L_0x004a
            r1.drawableHotspotChanged(r7, r6)
        L_0x004a:
            boolean r0 = r16.isPressed()
            if (r0 != 0) goto L_0x0053
            r1.setPressed(r5)
        L_0x0053:
            r16.layoutChildren()
            int r0 = r1.f2464f0
            if (r0 == r9) goto L_0x0070
            int r12 = r16.getFirstVisiblePosition()
            int r0 = r0 - r12
            android.view.View r0 = r1.getChildAt(r0)
            if (r0 == 0) goto L_0x0070
            if (r0 == r10) goto L_0x0070
            boolean r12 = r0.isPressed()
            if (r12 == 0) goto L_0x0070
            r0.setPressed(r4)
        L_0x0070:
            r1.f2464f0 = r8
            int r0 = r10.getLeft()
            float r0 = (float) r0
            float r0 = r7 - r0
            int r12 = r10.getTop()
            float r12 = (float) r12
            float r12 = r6 - r12
            int r13 = android.os.Build.VERSION.SDK_INT
            if (r13 < r11) goto L_0x0087
            r10.drawableHotspotChanged(r0, r12)
        L_0x0087:
            boolean r0 = r10.isPressed()
            if (r0 != 0) goto L_0x0090
            r10.setPressed(r5)
        L_0x0090:
            android.graphics.drawable.Drawable r11 = r16.getSelector()
            if (r11 == 0) goto L_0x009a
            if (r8 == r9) goto L_0x009a
            r12 = 1
            goto L_0x009b
        L_0x009a:
            r12 = 0
        L_0x009b:
            if (r12 == 0) goto L_0x00a0
            r11.setVisible(r4, r4)
        L_0x00a0:
            android.graphics.Rect r0 = r1.f2459a0
            int r13 = r10.getLeft()
            int r14 = r10.getTop()
            int r15 = r10.getRight()
            int r5 = r10.getBottom()
            r0.set(r13, r14, r15, r5)
            int r5 = r0.left
            int r13 = r1.f2460b0
            int r5 = r5 - r13
            r0.left = r5
            int r5 = r0.top
            int r13 = r1.f2461c0
            int r5 = r5 - r13
            r0.top = r5
            int r5 = r0.right
            int r13 = r1.f2462d0
            int r5 = r5 + r13
            r0.right = r5
            int r5 = r0.bottom
            int r13 = r1.f2463e0
            int r5 = r5 + r13
            r0.bottom = r5
            java.lang.reflect.Field r0 = r1.f2465g0     // Catch:{ IllegalAccessException -> 0x00f1 }
            boolean r0 = r0.getBoolean(r1)     // Catch:{ IllegalAccessException -> 0x00f1 }
            boolean r5 = r10.isEnabled()     // Catch:{ IllegalAccessException -> 0x00f1 }
            if (r5 == r0) goto L_0x00f5
            java.lang.reflect.Field r5 = r1.f2465g0     // Catch:{ IllegalAccessException -> 0x00f1 }
            if (r0 != 0) goto L_0x00e3
            r0 = 1
            goto L_0x00e4
        L_0x00e3:
            r0 = 0
        L_0x00e4:
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)     // Catch:{ IllegalAccessException -> 0x00f1 }
            r5.set(r1, r0)     // Catch:{ IllegalAccessException -> 0x00f1 }
            if (r8 == r9) goto L_0x00f5
            r16.refreshDrawableState()     // Catch:{ IllegalAccessException -> 0x00f1 }
            goto L_0x00f5
        L_0x00f1:
            r0 = move-exception
            r0.printStackTrace()
        L_0x00f5:
            if (r12 == 0) goto L_0x0110
            android.graphics.Rect r0 = r1.f2459a0
            float r5 = r0.exactCenterX()
            float r0 = r0.exactCenterY()
            int r12 = r16.getVisibility()
            if (r12 != 0) goto L_0x0109
            r12 = 1
            goto L_0x010a
        L_0x0109:
            r12 = 0
        L_0x010a:
            r11.setVisible(r12, r4)
            p000.C0815h0.m5800a((android.graphics.drawable.Drawable) r11, (float) r5, (float) r0)
        L_0x0110:
            android.graphics.drawable.Drawable r0 = r16.getSelector()
            if (r0 == 0) goto L_0x011b
            if (r8 == r9) goto L_0x011b
            p000.C0815h0.m5800a((android.graphics.drawable.Drawable) r0, (float) r7, (float) r6)
        L_0x011b:
            r1.setSelectorEnabled(r4)
            r16.refreshDrawableState()
            r5 = 1
            if (r3 != r5) goto L_0x012b
            long r5 = r1.getItemIdAtPosition(r8)
            r1.performItemClick(r10, r8, r5)
        L_0x012b:
            r0 = 1
        L_0x012c:
            r5 = 0
        L_0x012d:
            if (r0 == 0) goto L_0x0131
            if (r5 == 0) goto L_0x0153
        L_0x0131:
            r1.f2469k0 = r4
            r1.setPressed(r4)
            r16.drawableStateChanged()
            int r3 = r1.f2464f0
            int r5 = r16.getFirstVisiblePosition()
            int r3 = r3 - r5
            android.view.View r3 = r1.getChildAt(r3)
            if (r3 == 0) goto L_0x0149
            r3.setPressed(r4)
        L_0x0149:
            a8 r3 = r1.f2470l0
            if (r3 == 0) goto L_0x0153
            r3.mo262a()
            r3 = 0
            r1.f2470l0 = r3
        L_0x0153:
            if (r0 == 0) goto L_0x016c
            l8 r3 = r1.f2471m0
            if (r3 != 0) goto L_0x0160
            l8 r3 = new l8
            r3.<init>(r1)
            r1.f2471m0 = r3
        L_0x0160:
            l8 r3 = r1.f2471m0
            r4 = 1
            r3.mo7455a(r4)
            l8 r3 = r1.f2471m0
            r3.onTouch(r1, r2)
            goto L_0x0173
        L_0x016c:
            l8 r2 = r1.f2471m0
            if (r2 == 0) goto L_0x0173
            r2.mo7455a(r4)
        L_0x0173:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0335c3.mo2763a(android.view.MotionEvent, int):boolean");
    }

    public void dispatchDraw(Canvas canvas) {
        Drawable selector;
        if (!this.f2459a0.isEmpty() && (selector = getSelector()) != null) {
            selector.setBounds(this.f2459a0);
            selector.draw(canvas);
        }
        super.dispatchDraw(canvas);
    }

    public void drawableStateChanged() {
        if (this.f2472n0 == null) {
            super.drawableStateChanged();
            setSelectorEnabled(true);
            mo2762a();
        }
    }

    public boolean hasFocus() {
        return this.f2468j0 || super.hasFocus();
    }

    public boolean hasWindowFocus() {
        return this.f2468j0 || super.hasWindowFocus();
    }

    public boolean isFocused() {
        return this.f2468j0 || super.isFocused();
    }

    public boolean isInTouchMode() {
        return (this.f2468j0 && this.f2467i0) || super.isInTouchMode();
    }

    public void onDetachedFromWindow() {
        this.f2472n0 = null;
        super.onDetachedFromWindow();
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        if (Build.VERSION.SDK_INT < 26) {
            return super.onHoverEvent(motionEvent);
        }
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 10 && this.f2472n0 == null) {
            this.f2472n0 = new C0337b();
            C0337b bVar = this.f2472n0;
            C0335c3.this.post(bVar);
        }
        boolean onHoverEvent = super.onHoverEvent(motionEvent);
        if (actionMasked == 9 || actionMasked == 7) {
            int pointToPosition = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY());
            if (!(pointToPosition == -1 || pointToPosition == getSelectedItemPosition())) {
                View childAt = getChildAt(pointToPosition - getFirstVisiblePosition());
                if (childAt.isEnabled()) {
                    setSelectionFromTop(pointToPosition, childAt.getTop() - getTop());
                }
                mo2762a();
            }
        } else {
            setSelection(-1);
        }
        return onHoverEvent;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() == 0) {
            this.f2464f0 = pointToPosition((int) motionEvent.getX(), (int) motionEvent.getY());
        }
        C0337b bVar = this.f2472n0;
        if (bVar != null) {
            C0335c3 c3Var = C0335c3.this;
            c3Var.f2472n0 = null;
            c3Var.removeCallbacks(bVar);
        }
        return super.onTouchEvent(motionEvent);
    }

    public void setListSelectionHidden(boolean z) {
        this.f2467i0 = z;
    }

    public void setSelector(Drawable drawable) {
        this.f2466h0 = drawable != null ? new C0336a(drawable) : null;
        super.setSelector(this.f2466h0);
        Rect rect = new Rect();
        if (drawable != null) {
            drawable.getPadding(rect);
        }
        this.f2460b0 = rect.left;
        this.f2461c0 = rect.top;
        this.f2462d0 = rect.right;
        this.f2463e0 = rect.bottom;
    }

    /* renamed from: a */
    public final void mo2762a() {
        Drawable selector = getSelector();
        if (selector != null && this.f2469k0 && isPressed()) {
            selector.setState(getDrawableState());
        }
    }
}
