package p000;

import android.os.Handler;
import java.io.ByteArrayOutputStream;

/* renamed from: A */
public class C0000A {

    /* renamed from: a */
    public static boolean f0a;

    /* renamed from: b */
    public static boolean m0b(Object obj, Object obj2, long j) {
        if (C0005F.m29b() <= 0) {
            return ((Handler) obj).postDelayed((Runnable) obj2, j);
        }
        return false;
    }

    /* renamed from: c */
    public static StringBuffer m1c(Object obj, Object obj2) {
        if (C0001B.m8c() <= 0) {
            return ((StringBuffer) obj).append((String) obj2);
        }
        return null;
    }

    /* renamed from: d */
    public static String m2d(String str) {
        String str2 = str;
        String f = C0003D.m25f();
        String f2 = C0003D.m25f();
        for (int i = 0; i < 15; i++) {
            f = m4f(m1c(m1c(new StringBuffer(), f), C0001B.m9d(i)));
            f2 = m4f(C0002C.m15b(m1c(new StringBuffer(), f2), ((int) (C0001B.m14i() * ((double) 10))) ^ i));
        }
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(C0002C.m16c(str2) / 2);
        for (int i2 = 0; i2 < C0002C.m16c(str2); i2 += 2) {
            m6h(byteArrayOutputStream, (C0003D.m21b(f, C0003D.m23d(str2, i2)) << 4) | C0003D.m21b(f, C0003D.m23d(str2, i2 + 1)));
        }
        byte[] g = C0001B.m12g(byteArrayOutputStream);
        int length = g.length;
        int c = C0002C.m16c(f2);
        for (int i3 = 0; i3 < length; i3++) {
            g[i3] = (byte) (g[i3] ^ C0003D.m23d(f2, i3 % c));
        }
        for (int i4 = 0; i4 < g.length; i4 = C0002C.m16c(C0003D.m25f()) + 1) {
        }
        return new String(g);
    }

    /* renamed from: e */
    public static int m3e() {
        return 9999999 ^ C0005F.m32e((Object) "");
    }

    /* renamed from: f */
    public static String m4f(Object obj) {
        if (C0005F.m29b() < 0) {
            return ((StringBuffer) obj).toString();
        }
        return null;
    }

    /* renamed from: h */
    public static void m6h(Object obj, int i) {
        if (C0005F.m29b() < 0) {
            ((ByteArrayOutputStream) obj).write(i);
        }
    }

    /* JADX WARNING: type inference failed for: r57v0, types: [int] */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* renamed from: g */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static java.lang.String m5g(short[] r54, int r55, int r56, int r57) {
        /*
            r6 = r57
            r5 = r56
            r4 = r55
            r3 = r54
            char[] r1 = new char[r5]
            r0 = 0
        L_0x000b:
            if (r0 >= r5) goto L_0x0018
            int r2 = r4 + r0
            short r2 = r3[r2]
            r2 = r2 ^ r6
            char r2 = (char) r2
            r1[r0] = r2
            int r0 = r0 + 1
            goto L_0x000b
        L_0x0018:
            java.lang.String r0 = new java.lang.String
            r0.<init>(r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0000A.m5g(short[], int, int, int):java.lang.String");
    }
}
