package p000;

/* renamed from: fp */
public interface C0715fp extends C0795gp {
}
