package p000;

import android.app.Activity;
import android.os.Bundle;

/* renamed from: fn */
public final class C0713fn extends C1709qm {
    public C0713fn(Activity activity) {
        super(activity);
    }

    /* renamed from: c */
    public final void mo5746c(Bundle bundle) {
        C0680fe.m4888m("AdOverlayParcel is null or does not contain valid overlay type.");
        this.f13167j0 = 3;
        this.f13155X.finish();
    }
}
