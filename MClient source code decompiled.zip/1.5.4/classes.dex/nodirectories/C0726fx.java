package p000;

import android.os.IBinder;

/* renamed from: fx */
public final class C0726fx extends rj2 implements C0562dx {
    public C0726fx(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.formats.client.IUnconfirmedClickListener");
    }
}
