package p000;

import android.util.SparseArray;
import android.view.View;

/* renamed from: be */
public class C0299be {

    /* renamed from: a */
    public final C2399z4<View, C0094ae> f1838a = new C2399z4<>();

    /* renamed from: b */
    public final SparseArray<View> f1839b = new SparseArray<>();

    /* renamed from: c */
    public final C0516d5<View> f1840c = new C0516d5<>();

    /* renamed from: d */
    public final C2399z4<String, View> f1841d = new C2399z4<>();
}
