package p000;

import android.view.View;

/* renamed from: de */
public interface C0534de extends C0858he {
    /* renamed from: a */
    void mo2907a(View view);

    /* renamed from: b */
    void mo2909b(View view);
}
