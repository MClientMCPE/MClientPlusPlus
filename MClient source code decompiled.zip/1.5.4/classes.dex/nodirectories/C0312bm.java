package p000;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;

/* renamed from: bm */
public final class C0312bm extends C1874sq {
    public static final Parcelable.Creator<C0312bm> CREATOR = new C0712fm();

    /* renamed from: X */
    public final boolean f2105X;

    /* renamed from: Y */
    public final fx2 f2106Y;

    /* renamed from: Z */
    public final IBinder f2107Z;

    public C0312bm(boolean z, IBinder iBinder, IBinder iBinder2) {
        this.f2105X = z;
        this.f2106Y = iBinder != null ? vv2.m14800a(iBinder) : null;
        this.f2107Z = iBinder2;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a = C0680fe.m4661a(parcel);
        C0680fe.m4751a(parcel, 1, this.f2105X);
        fx2 fx2 = this.f2106Y;
        C0680fe.m4747a(parcel, 2, fx2 == null ? null : fx2.asBinder(), false);
        C0680fe.m4747a(parcel, 3, this.f2107Z, false);
        C0680fe.m4891o(parcel, a);
    }
}
