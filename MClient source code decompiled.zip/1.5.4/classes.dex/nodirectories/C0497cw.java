package p000;

import android.os.RemoteException;
import java.util.ArrayList;
import java.util.List;
import p000.C2059ul;

/* renamed from: cw */
public final class C0497cw extends C2459zl {

    /* renamed from: a */
    public final C0325bw f3580a;

    /* renamed from: b */
    public final List<C2059ul.C2061b> f3581b = new ArrayList();

    /* renamed from: c */
    public final C1370mv f3582c;

    /* renamed from: d */
    public final C1342ml f3583d = new C1342ml();

    /* JADX WARNING: type inference failed for: r3v3, types: [android.os.IInterface] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public C0497cw(p000.C0325bw r6) {
        /*
            r5 = this;
            java.lang.String r0 = ""
            r5.<init>()
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            r5.f3581b = r1
            ml r1 = new ml
            r1.<init>()
            r5.f3583d = r1
            r5.f3580a = r6
            r6 = 0
            bw r1 = r5.f3580a     // Catch:{ RemoteException -> 0x0057 }
            java.util.List r1 = r1.mo2679x()     // Catch:{ RemoteException -> 0x0057 }
            if (r1 == 0) goto L_0x005b
            java.util.Iterator r1 = r1.iterator()     // Catch:{ RemoteException -> 0x0057 }
        L_0x0022:
            boolean r2 = r1.hasNext()     // Catch:{ RemoteException -> 0x0057 }
            if (r2 == 0) goto L_0x005b
            java.lang.Object r2 = r1.next()     // Catch:{ RemoteException -> 0x0057 }
            boolean r3 = r2 instanceof android.os.IBinder     // Catch:{ RemoteException -> 0x0057 }
            if (r3 == 0) goto L_0x0049
            android.os.IBinder r2 = (android.os.IBinder) r2     // Catch:{ RemoteException -> 0x0057 }
            if (r2 == 0) goto L_0x0049
            java.lang.String r3 = "com.google.android.gms.ads.internal.formats.client.INativeAdImage"
            android.os.IInterface r3 = r2.queryLocalInterface(r3)     // Catch:{ RemoteException -> 0x0057 }
            boolean r4 = r3 instanceof p000.C1274lv     // Catch:{ RemoteException -> 0x0057 }
            if (r4 == 0) goto L_0x0042
            r2 = r3
            lv r2 = (p000.C1274lv) r2     // Catch:{ RemoteException -> 0x0057 }
            goto L_0x004a
        L_0x0042:
            nv r3 = new nv     // Catch:{ RemoteException -> 0x0057 }
            r3.<init>(r2)     // Catch:{ RemoteException -> 0x0057 }
            r2 = r3
            goto L_0x004a
        L_0x0049:
            r2 = r6
        L_0x004a:
            if (r2 == 0) goto L_0x0022
            java.util.List<ul$b> r3 = r5.f3581b     // Catch:{ RemoteException -> 0x0057 }
            mv r4 = new mv     // Catch:{ RemoteException -> 0x0057 }
            r4.<init>(r2)     // Catch:{ RemoteException -> 0x0057 }
            r3.add(r4)     // Catch:{ RemoteException -> 0x0057 }
            goto L_0x0022
        L_0x0057:
            r1 = move-exception
            p000.C0680fe.m4830c((java.lang.String) r0, (java.lang.Throwable) r1)
        L_0x005b:
            bw r1 = r5.f3580a     // Catch:{ RemoteException -> 0x006a }
            lv r1 = r1.mo2673T()     // Catch:{ RemoteException -> 0x006a }
            if (r1 == 0) goto L_0x006e
            mv r2 = new mv     // Catch:{ RemoteException -> 0x006a }
            r2.<init>(r1)     // Catch:{ RemoteException -> 0x006a }
            r6 = r2
            goto L_0x006e
        L_0x006a:
            r1 = move-exception
            p000.C0680fe.m4830c((java.lang.String) r0, (java.lang.Throwable) r1)
        L_0x006e:
            r5.f3582c = r6
            bw r6 = r5.f3580a     // Catch:{ RemoteException -> 0x0084 }
            fv r6 = r6.mo2678w()     // Catch:{ RemoteException -> 0x0084 }
            if (r6 == 0) goto L_0x0088
            gv r6 = new gv     // Catch:{ RemoteException -> 0x0084 }
            bw r1 = r5.f3580a     // Catch:{ RemoteException -> 0x0084 }
            fv r1 = r1.mo2678w()     // Catch:{ RemoteException -> 0x0084 }
            r6.<init>(r1)     // Catch:{ RemoteException -> 0x0084 }
            goto L_0x0088
        L_0x0084:
            r6 = move-exception
            p000.C0680fe.m4830c((java.lang.String) r0, (java.lang.Throwable) r6)
        L_0x0088:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0497cw.<init>(bw):void");
    }

    /* renamed from: a */
    public final /* synthetic */ Object mo4487a() {
        try {
            return this.f3580a.mo2672J();
        } catch (RemoteException e) {
            C0680fe.m4830c("", (Throwable) e);
            return null;
        }
    }

    /* renamed from: b */
    public final CharSequence mo4488b() {
        try {
            return this.f3580a.mo2675t();
        } catch (RemoteException e) {
            C0680fe.m4830c("", (Throwable) e);
            return null;
        }
    }
}
