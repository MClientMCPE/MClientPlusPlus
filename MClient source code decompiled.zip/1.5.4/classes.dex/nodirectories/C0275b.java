package p000;

import java.util.concurrent.CopyOnWriteArrayList;

/* renamed from: b */
public abstract class C0275b {

    /* renamed from: a */
    public boolean f1609a;

    /* renamed from: b */
    public CopyOnWriteArrayList<C0010a> f1610b = new CopyOnWriteArrayList<>();

    public C0275b(boolean z) {
        this.f1609a = z;
    }

    /* renamed from: a */
    public void mo2218a(C0010a aVar) {
        this.f1610b.add(aVar);
    }
}
