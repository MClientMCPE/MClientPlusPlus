package p000;

import android.util.Log;

/* renamed from: ag */
public class C0105ag implements Runnable {

    /* renamed from: X */
    public final /* synthetic */ int f455X;

    /* renamed from: Y */
    public final /* synthetic */ String f456Y;

    /* renamed from: Z */
    public final /* synthetic */ int f457Z;

    /* renamed from: a0 */
    public final /* synthetic */ boolean f458a0;

    /* renamed from: b0 */
    public final /* synthetic */ C2439zf f459b0;

    public C0105ag(C2439zf zfVar, int i, String str, int i2, boolean z) {
        this.f459b0 = zfVar;
        this.f455X = i;
        this.f456Y = str;
        this.f457Z = i2;
        this.f458a0 = z;
    }

    public void run() {
        String substring;
        String str;
        C2439zf zfVar = this.f459b0;
        int i = this.f455X;
        String str2 = this.f456Y;
        int i2 = this.f457Z;
        if (zfVar.f18314d != null) {
            if (i2 == 3 && zfVar.mo13160a(C0680fe.m4839d(zfVar.f18311a, Integer.toString(i)), 3)) {
                zfVar.f18314d.mo6992a(str2);
            } else if (i2 == 2 && zfVar.mo13160a(C0680fe.m4839d(zfVar.f18311a, Integer.toString(i)), 2)) {
                zfVar.f18314d.mo6997c(str2);
            } else if (i2 == 1 && zfVar.mo13160a(C0680fe.m4839d(zfVar.f18311a, Integer.toString(i)), 1)) {
                zfVar.f18314d.mo6998d(str2);
            } else if (i2 == 0 && zfVar.mo13160a(C0680fe.m4839d(zfVar.f18311a, Integer.toString(i)), 0)) {
                zfVar.f18314d.mo6996b(str2);
            }
        }
        int i3 = 0;
        while (i3 <= this.f456Y.length() / 4000) {
            int i4 = i3 * 4000;
            i3++;
            int min = Math.min(i3 * 4000, this.f456Y.length());
            if (this.f457Z == 3) {
                C2439zf zfVar2 = this.f459b0;
                if (zfVar2.mo13161a(C0680fe.m4839d(zfVar2.f18311a, Integer.toString(this.f455X)), 3, this.f458a0)) {
                    Log.d("AdColony [TRACE]", this.f456Y.substring(i4, min));
                }
            }
            if (this.f457Z == 2) {
                C2439zf zfVar3 = this.f459b0;
                if (zfVar3.mo13161a(C0680fe.m4839d(zfVar3.f18311a, Integer.toString(this.f455X)), 2, this.f458a0)) {
                    Log.i("AdColony [INFO]", this.f456Y.substring(i4, min));
                }
            }
            if (this.f457Z == 1) {
                C2439zf zfVar4 = this.f459b0;
                if (zfVar4.mo13161a(C0680fe.m4839d(zfVar4.f18311a, Integer.toString(this.f455X)), 1, this.f458a0)) {
                    Log.w("AdColony [WARNING]", this.f456Y.substring(i4, min));
                }
            }
            if (this.f457Z == 0) {
                C2439zf zfVar5 = this.f459b0;
                if (zfVar5.mo13161a(C0680fe.m4839d(zfVar5.f18311a, Integer.toString(this.f455X)), 0, this.f458a0)) {
                    substring = this.f456Y.substring(i4, min);
                    str = "AdColony [ERROR]";
                    Log.e(str, substring);
                }
            }
            if (this.f457Z == -1 && C2439zf.f18309f >= -1) {
                substring = this.f456Y.substring(i4, min);
                str = "AdColony [FATAL]";
                Log.e(str, substring);
            }
        }
    }
}
