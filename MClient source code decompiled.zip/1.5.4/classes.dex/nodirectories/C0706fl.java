package p000;

import android.os.Bundle;
import com.google.ads.mediation.admob.AdMobAdapter;

/* renamed from: fl */
public final class C0706fl {

    /* renamed from: a */
    public final jy2 f5464a;

    public /* synthetic */ C0706fl(C0707a aVar, C1940tp tpVar) {
        this.f5464a = new jy2(aVar.f5465a);
    }

    /* renamed from: fl$a */
    public static final class C0707a {

        /* renamed from: a */
        public final my2 f5465a = new my2();

        public C0707a() {
            this.f5465a.f10731d.add("B3EEABB8EE11C2BE770B684D95219ECB");
        }

        /* renamed from: a */
        public final C0707a mo5726a(Class<? extends C1541oo> cls, Bundle bundle) {
            this.f5465a.f10729b.putBundle(cls.getName(), bundle);
            if (cls.equals(AdMobAdapter.class) && bundle.getBoolean("_emulatorLiveAds")) {
                this.f5465a.f10731d.remove("B3EEABB8EE11C2BE770B684D95219ECB");
            }
            return this;
        }

        /* renamed from: a */
        public final C0707a mo5727a(String str) {
            this.f5465a.f10731d.add(str);
            return this;
        }
    }
}
