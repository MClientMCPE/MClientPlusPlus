package p000;

/* renamed from: aw */
public abstract class C0271aw extends qj2 implements C0325bw {
    public C0271aw() {
        super("com.google.android.gms.ads.internal.formats.client.INativeContentAd");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:10:0x006b, code lost:
        r3.writeNoException();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x00b4, code lost:
        r3.writeNoException();
        r3.writeString(r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:20:0x00c2, code lost:
        r3.writeNoException();
        p000.sj2.m12848a(r3, r1);
     */
    /* JADX WARNING: Code restructure failed: missing block: B:21:?, code lost:
        return true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:?, code lost:
        return true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:?, code lost:
        return true;
     */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean mo2162a(int r1, android.os.Parcel r2, android.os.Parcel r3, int r4) {
        /*
            r0 = this;
            switch(r1) {
                case 2: goto L_0x00bb;
                case 3: goto L_0x00ad;
                case 4: goto L_0x009f;
                case 5: goto L_0x0097;
                case 6: goto L_0x008f;
                case 7: goto L_0x0087;
                case 8: goto L_0x007f;
                case 9: goto L_0x006f;
                case 10: goto L_0x0063;
                case 11: goto L_0x005b;
                case 12: goto L_0x004a;
                case 13: goto L_0x0031;
                case 14: goto L_0x0020;
                case 15: goto L_0x0017;
                case 16: goto L_0x000c;
                case 17: goto L_0x0005;
                default: goto L_0x0003;
            }
        L_0x0003:
            r1 = 0
            return r1
        L_0x0005:
            r1 = r0
            q61 r1 = (p000.q61) r1
            java.lang.String r1 = r1.f12894X
            goto L_0x00b4
        L_0x000c:
            r1 = r0
            q61 r1 = (p000.q61) r1
            d31 r1 = r1.f12896Z
            wr r1 = r1.mo4568B()
            goto L_0x00c2
        L_0x0017:
            r1 = r0
            q61 r1 = (p000.q61) r1
            fv r1 = r1.mo2678w()
            goto L_0x00c2
        L_0x0020:
            android.os.Parcelable$Creator r1 = android.os.Bundle.CREATOR
            android.os.Parcelable r1 = p000.sj2.m12847a((android.os.Parcel) r2, r1)
            android.os.Bundle r1 = (android.os.Bundle) r1
            r2 = r0
            q61 r2 = (p000.q61) r2
            v21 r2 = r2.f12895Y
            r2.mo11814b((android.os.Bundle) r1)
            goto L_0x006b
        L_0x0031:
            android.os.Parcelable$Creator r1 = android.os.Bundle.CREATOR
            android.os.Parcelable r1 = p000.sj2.m12847a((android.os.Parcel) r2, r1)
            android.os.Bundle r1 = (android.os.Bundle) r1
            r2 = r0
            q61 r2 = (p000.q61) r2
            v21 r2 = r2.f12895Y
            boolean r1 = r2.mo11818c((android.os.Bundle) r1)
            r3.writeNoException()
            r3.writeInt(r1)
            goto L_0x00c8
        L_0x004a:
            android.os.Parcelable$Creator r1 = android.os.Bundle.CREATOR
            android.os.Parcelable r1 = p000.sj2.m12847a((android.os.Parcel) r2, r1)
            android.os.Bundle r1 = (android.os.Bundle) r1
            r2 = r0
            q61 r2 = (p000.q61) r2
            v21 r2 = r2.f12895Y
            r2.mo11803a((android.os.Bundle) r1)
            goto L_0x006b
        L_0x005b:
            r1 = r0
            q61 r1 = (p000.q61) r1
            cy2 r1 = r1.getVideoController()
            goto L_0x00c2
        L_0x0063:
            r1 = r0
            q61 r1 = (p000.q61) r1
            v21 r1 = r1.f12895Y
            r1.mo8115a()
        L_0x006b:
            r3.writeNoException()
            goto L_0x00c8
        L_0x006f:
            r1 = r0
            q61 r1 = (p000.q61) r1
            d31 r1 = r1.f12896Z
            android.os.Bundle r1 = r1.mo4594f()
            r3.writeNoException()
            p000.sj2.m12853b(r3, r1)
            goto L_0x00c8
        L_0x007f:
            r1 = r0
            q61 r1 = (p000.q61) r1
            java.lang.String r1 = r1.mo2671F()
            goto L_0x00b4
        L_0x0087:
            r1 = r0
            q61 r1 = (p000.q61) r1
            java.lang.String r1 = r1.mo2677v()
            goto L_0x00b4
        L_0x008f:
            r1 = r0
            q61 r1 = (p000.q61) r1
            lv r1 = r1.mo2673T()
            goto L_0x00c2
        L_0x0097:
            r1 = r0
            q61 r1 = (p000.q61) r1
            java.lang.String r1 = r1.mo2676u()
            goto L_0x00b4
        L_0x009f:
            r1 = r0
            q61 r1 = (p000.q61) r1
            java.util.List r1 = r1.mo2679x()
            r3.writeNoException()
            r3.writeList(r1)
            goto L_0x00c8
        L_0x00ad:
            r1 = r0
            q61 r1 = (p000.q61) r1
            java.lang.String r1 = r1.mo2675t()
        L_0x00b4:
            r3.writeNoException()
            r3.writeString(r1)
            goto L_0x00c8
        L_0x00bb:
            r1 = r0
            q61 r1 = (p000.q61) r1
            wr r1 = r1.mo2672J()
        L_0x00c2:
            r3.writeNoException()
            p000.sj2.m12848a((android.os.Parcel) r3, (android.os.IInterface) r1)
        L_0x00c8:
            r1 = 1
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0271aw.mo2162a(int, android.os.Parcel, android.os.Parcel, int):boolean");
    }
}
