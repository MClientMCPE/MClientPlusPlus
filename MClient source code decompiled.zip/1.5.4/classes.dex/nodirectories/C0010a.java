package p000;

/* renamed from: a */
public interface C0010a {
    void cancel();
}
