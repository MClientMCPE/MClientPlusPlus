package p000;

/* renamed from: f7 */
public class C0666f7<T> extends C0590e7<T> {

    /* renamed from: c */
    public final Object f5066c = new Object();

    public C0666f7(int i) {
        super(i);
    }

    /* renamed from: a */
    public T mo5048a() {
        T a;
        synchronized (this.f5066c) {
            a = super.mo5048a();
        }
        return a;
    }

    /* renamed from: a */
    public boolean mo5049a(T t) {
        boolean a;
        synchronized (this.f5066c) {
            a = super.mo5049a(t);
        }
        return a;
    }
}
