package p000;

/* renamed from: cl */
public enum C0378cl {
    BANNER,
    INTERSTITIAL,
    REWARDED,
    NATIVE
}
