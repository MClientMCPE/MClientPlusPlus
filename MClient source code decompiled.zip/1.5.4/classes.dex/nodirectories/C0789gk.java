package p000;

import android.os.Parcel;
import android.os.RemoteException;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;
import java.util.HashMap;
import java.util.LinkedHashMap;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import p000.C2232wr;

/* renamed from: gk */
/* compiled from: outline */
public class C0789gk {
    /* renamed from: a */
    public static int m5547a(int i, int i2, int i3, int i4) {
        return i + i2 + i3 + i4;
    }

    /* renamed from: a */
    public static int m5548a(String str, int i) {
        return String.valueOf(str).length() + i;
    }

    /* renamed from: a */
    public static long m5549a(long j, long j2, long j3, long j4) {
        return (j * j2) + j3 + j4;
    }

    /* renamed from: a */
    public static RemoteException m5550a(String str, Throwable th) {
        C0680fe.m4830c(str, th);
        return new RemoteException();
    }

    /* renamed from: a */
    public static String m5551a(int i, String str, int i2) {
        StringBuilder sb = new StringBuilder(i);
        sb.append(str);
        sb.append(i2);
        return sb.toString();
    }

    /* renamed from: a */
    public static String m5552a(int i, String str, int i2, String str2, int i3) {
        StringBuilder sb = new StringBuilder(i);
        sb.append(str);
        sb.append(i2);
        sb.append(str2);
        sb.append(i3);
        return sb.toString();
    }

    /* renamed from: a */
    public static String m5553a(int i, String str, String str2, String str3) {
        StringBuilder sb = new StringBuilder(i);
        sb.append(str);
        sb.append(str2);
        sb.append(str3);
        return sb.toString();
    }

    /* renamed from: a */
    public static String m5554a(RecyclerView recyclerView, StringBuilder sb) {
        sb.append(recyclerView.exceptionLabel());
        return sb.toString();
    }

    /* renamed from: a */
    public static String m5555a(String str, Fragment fragment, String str2) {
        return str + fragment + str2;
    }

    /* renamed from: a */
    public static String m5556a(String str, Object obj) {
        return str + obj;
    }

    /* renamed from: a */
    public static String m5557a(String str, String str2) {
        return str + str2;
    }

    /* renamed from: a */
    public static String m5558a(String str, String str2, String str3) {
        return str + str2 + str3;
    }

    /* renamed from: a */
    public static String m5559a(StringBuilder sb, String str, String str2) {
        sb.append(str);
        sb.append(str2);
        return sb.toString();
    }

    /* renamed from: a */
    public static String m5560a(XmlPullParser xmlPullParser, StringBuilder sb, String str) {
        sb.append(xmlPullParser.getPositionDescription());
        sb.append(str);
        return sb.toString();
    }

    /* renamed from: a */
    public static StringBuilder m5561a(int i, String str, String str2, String str3, String str4) {
        StringBuilder sb = new StringBuilder(i);
        sb.append(str);
        sb.append(str2);
        sb.append(str3);
        sb.append(str4);
        return sb;
    }

    /* renamed from: a */
    public static StringBuilder m5562a(String str) {
        StringBuilder sb = new StringBuilder();
        sb.append(str);
        return sb;
    }

    /* renamed from: a */
    public static tb4 m5563a(tb4 tb4, tb4 tb42, tb4 tb43) {
        return tb4.mo2496j().mo2484a(tb42).mo2484a(tb43);
    }

    /* renamed from: a */
    public static C2232wr m5564a(Parcel parcel) {
        C2232wr a = C2232wr.C2233a.m15345a(parcel.readStrongBinder());
        parcel.recycle();
        return a;
    }

    /* renamed from: a */
    public static void m5565a(int i, String str, HashMap hashMap, String str2) {
        hashMap.put(str2, new th4(i, str));
    }

    /* renamed from: a */
    public static void m5566a(String str, String str2, rh2 rh2, String str3, LinkedHashMap linkedHashMap, String str4, rh2 rh22) {
        C0680fe.m4698a(str, str2);
        C0680fe.m4698a(rh2, str3);
        linkedHashMap.put(str4, rh22);
    }

    /* renamed from: a */
    public static void m5567a(JSONObject jSONObject, String str, String str2, JSONObject jSONObject2) {
        C0680fe.m4785a(jSONObject, str, str2);
        C0680fe.m4730a().mo11970k().mo9679a(jSONObject2);
    }

    /* renamed from: b */
    public static String m5568b(String str, int i) {
        return str + i;
    }

    /* renamed from: b */
    public static StringBuilder m5569b(String str, String str2) {
        StringBuilder sb = new StringBuilder();
        sb.append(str);
        sb.append(str2);
        return sb;
    }
}
