package p000;

/* renamed from: cj */
public class C0376cj implements C1617pg {

    /* renamed from: a */
    public final /* synthetic */ C0546dj f2763a;

    public C0376cj(C0546dj djVar) {
        this.f2763a = djVar;
    }

    /* renamed from: a */
    public void mo532a(C1249lg lgVar) {
        if (this.f2763a.mo4806a(lgVar)) {
            this.f2763a.mo4808c(lgVar);
        }
    }
}
