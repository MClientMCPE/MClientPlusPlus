package p000;

import android.os.IInterface;

/* renamed from: br */
public interface C0317br extends IInterface {
}
