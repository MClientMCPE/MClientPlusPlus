package p000;

import android.os.IInterface;

/* renamed from: dx */
public interface C0562dx extends IInterface {
}
