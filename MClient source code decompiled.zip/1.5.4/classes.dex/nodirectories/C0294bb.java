package p000;

/* renamed from: bb */
public class C0294bb implements C1509ob {

    /* renamed from: X */
    public C1607pb f1793X = null;

    /* renamed from: a */
    public C1234lb mo635a() {
        if (this.f1793X == null) {
            this.f1793X = new C1607pb(this);
        }
        return this.f1793X;
    }
}
