package p000;

/* renamed from: fa */
public class C0673fa {

    /* renamed from: a */
    public final C0848ha<?> f5200a;

    public C0673fa(C0848ha<?> haVar) {
        this.f5200a = haVar;
    }

    /* renamed from: a */
    public void mo5532a() {
        this.f5200a.f6672b0.mo7552m();
    }
}
