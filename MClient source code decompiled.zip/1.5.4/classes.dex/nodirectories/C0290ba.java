package p000;

import android.annotation.SuppressLint;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import androidx.fragment.app.Fragment;
import java.util.ArrayList;
import p000.C1234lb;
import p000.C1689qa;

@SuppressLint({"BanParcelableUsage"})
/* renamed from: ba */
public final class C0290ba implements Parcelable {
    public static final Parcelable.Creator<C0290ba> CREATOR = new C0291a();

    /* renamed from: X */
    public final int[] f1768X;

    /* renamed from: Y */
    public final ArrayList<String> f1769Y;

    /* renamed from: Z */
    public final int[] f1770Z;

    /* renamed from: a0 */
    public final int[] f1771a0;

    /* renamed from: b0 */
    public final int f1772b0;

    /* renamed from: c0 */
    public final int f1773c0;

    /* renamed from: d0 */
    public final String f1774d0;

    /* renamed from: e0 */
    public final int f1775e0;

    /* renamed from: f0 */
    public final int f1776f0;

    /* renamed from: g0 */
    public final CharSequence f1777g0;

    /* renamed from: h0 */
    public final int f1778h0;

    /* renamed from: i0 */
    public final CharSequence f1779i0;

    /* renamed from: j0 */
    public final ArrayList<String> f1780j0;

    /* renamed from: k0 */
    public final ArrayList<String> f1781k0;

    /* renamed from: l0 */
    public final boolean f1782l0;

    /* renamed from: ba$a */
    public static class C0291a implements Parcelable.Creator<C0290ba> {
        public Object createFromParcel(Parcel parcel) {
            return new C0290ba(parcel);
        }

        public Object[] newArray(int i) {
            return new C0290ba[i];
        }
    }

    public C0290ba(C0056aa aaVar) {
        int size = aaVar.f12952a.size();
        this.f1768X = new int[(size * 5)];
        if (aaVar.f12959h) {
            this.f1769Y = new ArrayList<>(size);
            this.f1770Z = new int[size];
            this.f1771a0 = new int[size];
            int i = 0;
            int i2 = 0;
            while (i < size) {
                C1689qa.C1690a aVar = aaVar.f12952a.get(i);
                int i3 = i2 + 1;
                this.f1768X[i2] = aVar.f12969a;
                ArrayList<String> arrayList = this.f1769Y;
                Fragment fragment = aVar.f12970b;
                arrayList.add(fragment != null ? fragment.f1152b0 : null);
                int[] iArr = this.f1768X;
                int i4 = i3 + 1;
                iArr[i3] = aVar.f12971c;
                int i5 = i4 + 1;
                iArr[i4] = aVar.f12972d;
                int i6 = i5 + 1;
                iArr[i5] = aVar.f12973e;
                iArr[i6] = aVar.f12974f;
                this.f1770Z[i] = aVar.f12975g.ordinal();
                this.f1771a0[i] = aVar.f12976h.ordinal();
                i++;
                i2 = i6 + 1;
            }
            this.f1772b0 = aaVar.f12957f;
            this.f1773c0 = aaVar.f12958g;
            this.f1774d0 = aaVar.f12960i;
            this.f1775e0 = aaVar.f282t;
            this.f1776f0 = aaVar.f12961j;
            this.f1777g0 = aaVar.f12962k;
            this.f1778h0 = aaVar.f12963l;
            this.f1779i0 = aaVar.f12964m;
            this.f1780j0 = aaVar.f12965n;
            this.f1781k0 = aaVar.f12966o;
            this.f1782l0 = aaVar.f12967p;
            return;
        }
        throw new IllegalStateException("Not on back stack");
    }

    public C0290ba(Parcel parcel) {
        this.f1768X = parcel.createIntArray();
        this.f1769Y = parcel.createStringArrayList();
        this.f1770Z = parcel.createIntArray();
        this.f1771a0 = parcel.createIntArray();
        this.f1772b0 = parcel.readInt();
        this.f1773c0 = parcel.readInt();
        this.f1774d0 = parcel.readString();
        this.f1775e0 = parcel.readInt();
        this.f1776f0 = parcel.readInt();
        this.f1777g0 = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f1778h0 = parcel.readInt();
        this.f1779i0 = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
        this.f1780j0 = parcel.createStringArrayList();
        this.f1781k0 = parcel.createStringArrayList();
        this.f1782l0 = parcel.readInt() != 0;
    }

    /* renamed from: a */
    public C0056aa mo2383a(C1002ja jaVar) {
        C0056aa aaVar = new C0056aa(jaVar);
        int i = 0;
        int i2 = 0;
        while (i < this.f1768X.length) {
            C1689qa.C1690a aVar = new C1689qa.C1690a();
            int i3 = i + 1;
            aVar.f12969a = this.f1768X[i];
            String str = this.f1769Y.get(i2);
            aVar.f12970b = str != null ? jaVar.f8213d0.get(str) : null;
            aVar.f12975g = C1234lb.C1236b.values()[this.f1770Z[i2]];
            aVar.f12976h = C1234lb.C1236b.values()[this.f1771a0[i2]];
            int[] iArr = this.f1768X;
            int i4 = i3 + 1;
            aVar.f12971c = iArr[i3];
            int i5 = i4 + 1;
            aVar.f12972d = iArr[i4];
            int i6 = i5 + 1;
            aVar.f12973e = iArr[i5];
            aVar.f12974f = iArr[i6];
            aaVar.f12953b = aVar.f12971c;
            aaVar.f12954c = aVar.f12972d;
            aaVar.f12955d = aVar.f12973e;
            aaVar.f12956e = aVar.f12974f;
            aaVar.f12952a.add(aVar);
            aVar.f12971c = aaVar.f12953b;
            aVar.f12972d = aaVar.f12954c;
            aVar.f12973e = aaVar.f12955d;
            aVar.f12974f = aaVar.f12956e;
            i2++;
            i = i6 + 1;
        }
        aaVar.f12957f = this.f1772b0;
        aaVar.f12958g = this.f1773c0;
        aaVar.f12960i = this.f1774d0;
        aaVar.f282t = this.f1775e0;
        aaVar.f12959h = true;
        aaVar.f12961j = this.f1776f0;
        aaVar.f12962k = this.f1777g0;
        aaVar.f12963l = this.f1778h0;
        aaVar.f12964m = this.f1779i0;
        aaVar.f12965n = this.f1780j0;
        aaVar.f12966o = this.f1781k0;
        aaVar.f12967p = this.f1782l0;
        aaVar.mo288a(1);
        return aaVar;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeIntArray(this.f1768X);
        parcel.writeStringList(this.f1769Y);
        parcel.writeIntArray(this.f1770Z);
        parcel.writeIntArray(this.f1771a0);
        parcel.writeInt(this.f1772b0);
        parcel.writeInt(this.f1773c0);
        parcel.writeString(this.f1774d0);
        parcel.writeInt(this.f1775e0);
        parcel.writeInt(this.f1776f0);
        TextUtils.writeToParcel(this.f1777g0, parcel, 0);
        parcel.writeInt(this.f1778h0);
        TextUtils.writeToParcel(this.f1779i0, parcel, 0);
        parcel.writeStringList(this.f1780j0);
        parcel.writeStringList(this.f1781k0);
        parcel.writeInt(this.f1782l0 ? 1 : 0);
    }
}
