package p000;

import androidx.annotation.NonNull;

/* renamed from: H */
public class C0007H extends C0006G {
    public C0007H() {
    }

    @NonNull
    public String toString() {
        return super.toString();
    }
}
