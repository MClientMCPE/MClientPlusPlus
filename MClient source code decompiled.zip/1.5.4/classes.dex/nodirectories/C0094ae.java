package p000;

import android.view.View;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/* renamed from: ae */
public class C0094ae {

    /* renamed from: a */
    public final Map<String, Object> f363a = new HashMap();

    /* renamed from: b */
    public View f364b;

    /* renamed from: c */
    public final ArrayList<C1852sd> f365c = new ArrayList<>();

    @Deprecated
    public C0094ae() {
    }

    public C0094ae(View view) {
        this.f364b = view;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof C0094ae)) {
            return false;
        }
        C0094ae aeVar = (C0094ae) obj;
        return this.f364b == aeVar.f364b && this.f363a.equals(aeVar.f363a);
    }

    public int hashCode() {
        return this.f363a.hashCode() + (this.f364b.hashCode() * 31);
    }

    public String toString() {
        StringBuilder a = C0789gk.m5562a("TransitionValues@");
        a.append(Integer.toHexString(hashCode()));
        a.append(":\n");
        StringBuilder b = C0789gk.m5569b(a.toString(), "    view = ");
        b.append(this.f364b);
        b.append("\n");
        String a2 = C0789gk.m5557a(b.toString(), "    values:");
        for (String next : this.f363a.keySet()) {
            a2 = a2 + "    " + next + ": " + this.f363a.get(next) + "\n";
        }
        return a2;
    }
}
