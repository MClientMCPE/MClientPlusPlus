package p000;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

/* renamed from: f3 */
public class C0639f3 extends ViewGroup {

    /* renamed from: a0 */
    public boolean f4947a0;

    /* renamed from: b0 */
    public int f4948b0;

    /* renamed from: c0 */
    public int f4949c0;

    /* renamed from: d0 */
    public int f4950d0;

    /* renamed from: e0 */
    public int f4951e0;

    /* renamed from: f0 */
    public int f4952f0;

    /* renamed from: g0 */
    public float f4953g0;

    /* renamed from: h0 */
    public boolean f4954h0;

    /* renamed from: i0 */
    public int[] f4955i0;

    /* renamed from: j0 */
    public int[] f4956j0;

    /* renamed from: k0 */
    public Drawable f4957k0;

    /* renamed from: l0 */
    public int f4958l0;

    /* renamed from: m0 */
    public int f4959m0;

    /* renamed from: n0 */
    public int f4960n0;

    /* renamed from: o0 */
    public int f4961o0;

    /* renamed from: f3$a */
    public static class C0640a extends ViewGroup.MarginLayoutParams {

        /* renamed from: a */
        public float f4962a;

        /* renamed from: b */
        public int f4963b;

        public C0640a(int i, int i2) {
            super(i, i2);
            this.f4963b = -1;
            this.f4962a = 0.0f;
        }

        public C0640a(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f4963b = -1;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C1292m.LinearLayoutCompat_Layout);
            this.f4962a = obtainStyledAttributes.getFloat(C1292m.LinearLayoutCompat_Layout_android_layout_weight, 0.0f);
            this.f4963b = obtainStyledAttributes.getInt(C1292m.LinearLayoutCompat_Layout_android_layout_gravity, -1);
            obtainStyledAttributes.recycle();
        }

        public C0640a(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f4963b = -1;
        }
    }

    public C0639f3(Context context) {
        this(context, (AttributeSet) null);
    }

    public C0639f3(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:11:0x005a, code lost:
        r0 = r6.getResourceId(r7, 0);
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public C0639f3(android.content.Context r5, android.util.AttributeSet r6, int r7) {
        /*
            r4 = this;
            r4.<init>(r5, r6, r7)
            r0 = 1
            r4.f4947a0 = r0
            r1 = -1
            r4.f4948b0 = r1
            r2 = 0
            r4.f4949c0 = r2
            r3 = 8388659(0x800033, float:1.1755015E-38)
            r4.f4951e0 = r3
            int[] r3 = p000.C1292m.LinearLayoutCompat
            android.content.res.TypedArray r6 = r5.obtainStyledAttributes(r6, r3, r7, r2)
            int r7 = p000.C1292m.LinearLayoutCompat_android_orientation
            int r7 = r6.getInt(r7, r1)
            if (r7 < 0) goto L_0x0022
            r4.setOrientation(r7)
        L_0x0022:
            int r7 = p000.C1292m.LinearLayoutCompat_android_gravity
            int r7 = r6.getInt(r7, r1)
            if (r7 < 0) goto L_0x002d
            r4.setGravity(r7)
        L_0x002d:
            int r7 = p000.C1292m.LinearLayoutCompat_android_baselineAligned
            boolean r7 = r6.getBoolean(r7, r0)
            if (r7 != 0) goto L_0x0038
            r4.setBaselineAligned(r7)
        L_0x0038:
            int r7 = p000.C1292m.LinearLayoutCompat_android_weightSum
            r0 = -1082130432(0xffffffffbf800000, float:-1.0)
            float r7 = r6.getFloat(r7, r0)
            r4.f4953g0 = r7
            int r7 = p000.C1292m.LinearLayoutCompat_android_baselineAlignedChildIndex
            int r7 = r6.getInt(r7, r1)
            r4.f4948b0 = r7
            int r7 = p000.C1292m.LinearLayoutCompat_measureWithLargestChild
            boolean r7 = r6.getBoolean(r7, r2)
            r4.f4954h0 = r7
            int r7 = p000.C1292m.LinearLayoutCompat_divider
            boolean r0 = r6.hasValue(r7)
            if (r0 == 0) goto L_0x0065
            int r0 = r6.getResourceId(r7, r2)
            if (r0 == 0) goto L_0x0065
            android.graphics.drawable.Drawable r5 = p000.C1206l0.m8461c(r5, r0)
            goto L_0x0069
        L_0x0065:
            android.graphics.drawable.Drawable r5 = r6.getDrawable(r7)
        L_0x0069:
            r4.setDividerDrawable(r5)
            int r5 = p000.C1292m.LinearLayoutCompat_showDividers
            int r5 = r6.getInt(r5, r2)
            r4.f4960n0 = r5
            int r5 = p000.C1292m.LinearLayoutCompat_dividerPadding
            int r5 = r6.getDimensionPixelSize(r5, r2)
            r4.f4961o0 = r5
            r6.recycle()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0639f3.<init>(android.content.Context, android.util.AttributeSet, int):void");
    }

    /* renamed from: a */
    public View mo5294a(int i) {
        return getChildAt(i);
    }

    /* renamed from: a */
    public final void mo5295a(int i, int i2) {
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824);
        for (int i3 = 0; i3 < i; i3++) {
            View a = mo5294a(i3);
            if (a.getVisibility() != 8) {
                C0640a aVar = (C0640a) a.getLayoutParams();
                if (aVar.height == -1) {
                    int i4 = aVar.width;
                    aVar.width = a.getMeasuredWidth();
                    measureChildWithMargins(a, i2, 0, makeMeasureSpec, 0);
                    aVar.width = i4;
                }
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:27:0x00af  */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x00b9  */
    /* JADX WARNING: Removed duplicated region for block: B:42:0x00e8  */
    /* JADX WARNING: Removed duplicated region for block: B:45:0x00fb  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo5296a(int r23, int r24, int r25, int r26) {
        /*
            r22 = this;
            r0 = r22
            boolean r1 = p000.C0580e4.m3915a(r22)
            int r2 = r22.getPaddingTop()
            int r3 = r26 - r24
            int r4 = r22.getPaddingBottom()
            int r4 = r3 - r4
            int r3 = r3 - r2
            int r5 = r22.getPaddingBottom()
            int r3 = r3 - r5
            int r5 = r22.getVirtualChildCount()
            int r6 = r0.f4951e0
            r7 = 8388615(0x800007, float:1.1754953E-38)
            r7 = r7 & r6
            r6 = r6 & 112(0x70, float:1.57E-43)
            boolean r8 = r0.f4947a0
            int[] r9 = r0.f4955i0
            int[] r10 = r0.f4956j0
            int r11 = p000.C2189w7.m15018m(r22)
            int r7 = p000.C0815h0.m5770a((int) r7, (int) r11)
            r11 = 2
            r12 = 1
            if (r7 == r12) goto L_0x004a
            r13 = 5
            if (r7 == r13) goto L_0x003e
            int r7 = r22.getPaddingLeft()
            goto L_0x0055
        L_0x003e:
            int r7 = r22.getPaddingLeft()
            int r7 = r7 + r25
            int r7 = r7 - r23
            int r13 = r0.f4952f0
            int r7 = r7 - r13
            goto L_0x0055
        L_0x004a:
            int r7 = r22.getPaddingLeft()
            int r13 = r25 - r23
            int r14 = r0.f4952f0
            int r13 = r13 - r14
            int r13 = r13 / r11
            int r7 = r7 + r13
        L_0x0055:
            r13 = 0
            if (r1 == 0) goto L_0x005c
            int r1 = r5 + -1
            r15 = -1
            goto L_0x005e
        L_0x005c:
            r1 = 0
            r15 = 1
        L_0x005e:
            if (r13 >= r5) goto L_0x012b
            int r16 = r15 * r13
            int r12 = r16 + r1
            android.view.View r11 = r0.mo5294a((int) r12)
            if (r11 != 0) goto L_0x007c
            int r11 = r22.mo5310f()
            int r7 = r7 + r11
            r25 = r1
        L_0x0071:
            r17 = r5
            r16 = r6
            r18 = r8
            r19 = r15
            r15 = -1
            goto L_0x011b
        L_0x007c:
            int r14 = r11.getVisibility()
            r25 = r1
            r1 = 8
            if (r14 == r1) goto L_0x0071
            int r1 = r11.getMeasuredWidth()
            int r14 = r11.getMeasuredHeight()
            android.view.ViewGroup$LayoutParams r16 = r11.getLayoutParams()
            r17 = r5
            r5 = r16
            f3$a r5 = (p000.C0639f3.C0640a) r5
            r16 = r6
            if (r8 == 0) goto L_0x00a8
            int r6 = r5.height
            r18 = r8
            r8 = -1
            if (r6 == r8) goto L_0x00aa
            int r6 = r11.getBaseline()
            goto L_0x00ab
        L_0x00a8:
            r18 = r8
        L_0x00aa:
            r6 = -1
        L_0x00ab:
            int r8 = r5.f4963b
            if (r8 >= 0) goto L_0x00b1
            r8 = r16
        L_0x00b1:
            r8 = r8 & 112(0x70, float:1.57E-43)
            r19 = r15
            r15 = 16
            if (r8 == r15) goto L_0x00e8
            r15 = 48
            if (r8 == r15) goto L_0x00d9
            r15 = 80
            if (r8 == r15) goto L_0x00c3
            r8 = r2
            goto L_0x00d7
        L_0x00c3:
            int r8 = r4 - r14
            int r15 = r5.bottomMargin
            int r8 = r8 - r15
            r15 = -1
            if (r6 == r15) goto L_0x00d7
            int r15 = r11.getMeasuredHeight()
            int r15 = r15 - r6
            r6 = 2
            r20 = r10[r6]
            int r20 = r20 - r15
            int r8 = r8 - r20
        L_0x00d7:
            r15 = -1
            goto L_0x00f5
        L_0x00d9:
            int r8 = r5.topMargin
            int r8 = r8 + r2
            r15 = -1
            if (r6 == r15) goto L_0x00f5
            r20 = 1
            r21 = r9[r20]
            int r21 = r21 - r6
            int r8 = r21 + r8
            goto L_0x00f5
        L_0x00e8:
            r15 = -1
            int r6 = r3 - r14
            r8 = 2
            int r6 = r6 / r8
            int r6 = r6 + r2
            int r8 = r5.topMargin
            int r6 = r6 + r8
            int r8 = r5.bottomMargin
            int r8 = r6 - r8
        L_0x00f5:
            boolean r6 = r0.mo5304b((int) r12)
            if (r6 == 0) goto L_0x00fe
            int r6 = r0.f4958l0
            int r7 = r7 + r6
        L_0x00fe:
            int r6 = r5.leftMargin
            int r7 = r7 + r6
            int r6 = r22.mo5307d()
            int r6 = r6 + r7
            int r12 = r1 + r6
            int r14 = r14 + r8
            r11.layout(r6, r8, r12, r14)
            int r5 = r5.rightMargin
            int r1 = r1 + r5
            int r5 = r22.mo5309e()
            int r5 = r5 + r1
            int r5 = r5 + r7
            int r1 = r22.mo5305c()
            int r13 = r13 + r1
            r7 = r5
        L_0x011b:
            r1 = 1
            int r13 = r13 + r1
            r1 = r25
            r6 = r16
            r5 = r17
            r8 = r18
            r15 = r19
            r11 = 2
            r12 = 1
            goto L_0x005e
        L_0x012b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0639f3.mo5296a(int, int, int, int):void");
    }

    /* renamed from: a */
    public void mo5297a(Canvas canvas) {
        int i;
        int i2;
        int i3;
        int virtualChildCount = getVirtualChildCount();
        boolean a = C0580e4.m3915a(this);
        for (int i4 = 0; i4 < virtualChildCount; i4++) {
            View a2 = mo5294a(i4);
            if (!(a2 == null || a2.getVisibility() == 8 || !mo5304b(i4))) {
                C0640a aVar = (C0640a) a2.getLayoutParams();
                mo5303b(canvas, a ? a2.getRight() + aVar.rightMargin : (a2.getLeft() - aVar.leftMargin) - this.f4958l0);
            }
        }
        if (mo5304b(virtualChildCount)) {
            View a3 = mo5294a(virtualChildCount - 1);
            if (a3 != null) {
                C0640a aVar2 = (C0640a) a3.getLayoutParams();
                if (a) {
                    i3 = a3.getLeft();
                    i2 = aVar2.leftMargin;
                } else {
                    i = a3.getRight() + aVar2.rightMargin;
                    mo5303b(canvas, i);
                }
            } else if (a) {
                i = getPaddingLeft();
                mo5303b(canvas, i);
            } else {
                i3 = getWidth();
                i2 = getPaddingRight();
            }
            i = (i3 - i2) - this.f4958l0;
            mo5303b(canvas, i);
        }
    }

    /* renamed from: a */
    public void mo5298a(Canvas canvas, int i) {
        this.f4957k0.setBounds(getPaddingLeft() + this.f4961o0, i, (getWidth() - getPaddingRight()) - this.f4961o0, this.f4959m0 + i);
        this.f4957k0.draw(canvas);
    }

    /* renamed from: a */
    public void mo5299a(View view, int i, int i2, int i3, int i4) {
        measureChildWithMargins(view, i, i2, i3, i4);
    }

    /* renamed from: b */
    public final void mo5300b(int i, int i2) {
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824);
        for (int i3 = 0; i3 < i; i3++) {
            View a = mo5294a(i3);
            if (a.getVisibility() != 8) {
                C0640a aVar = (C0640a) a.getLayoutParams();
                if (aVar.width == -1) {
                    int i4 = aVar.height;
                    aVar.height = a.getMeasuredHeight();
                    measureChildWithMargins(a, makeMeasureSpec, 0, i2, 0);
                    aVar.height = i4;
                }
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:28:0x0094  */
    /* renamed from: b */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo5301b(int r12, int r13, int r14, int r15) {
        /*
            r11 = this;
            int r0 = r11.getPaddingLeft()
            int r14 = r14 - r12
            int r12 = r11.getPaddingRight()
            int r12 = r14 - r12
            int r14 = r14 - r0
            int r1 = r11.getPaddingRight()
            int r14 = r14 - r1
            int r1 = r11.getVirtualChildCount()
            int r2 = r11.f4951e0
            r3 = r2 & 112(0x70, float:1.57E-43)
            r4 = 8388615(0x800007, float:1.1754953E-38)
            r2 = r2 & r4
            r4 = 16
            if (r3 == r4) goto L_0x0035
            r4 = 80
            if (r3 == r4) goto L_0x002a
            int r13 = r11.getPaddingTop()
            goto L_0x0041
        L_0x002a:
            int r3 = r11.getPaddingTop()
            int r3 = r3 + r15
            int r3 = r3 - r13
            int r13 = r11.f4952f0
            int r13 = r3 - r13
            goto L_0x0041
        L_0x0035:
            int r3 = r11.getPaddingTop()
            int r15 = r15 - r13
            int r13 = r11.f4952f0
            int r15 = r15 - r13
            int r15 = r15 / 2
            int r13 = r3 + r15
        L_0x0041:
            r15 = 0
        L_0x0042:
            if (r15 >= r1) goto L_0x00b6
            android.view.View r3 = r11.mo5294a((int) r15)
            r4 = 1
            if (r3 != 0) goto L_0x0052
            int r3 = r11.mo5310f()
            int r3 = r3 + r13
        L_0x0050:
            r13 = r3
            goto L_0x00b4
        L_0x0052:
            int r5 = r3.getVisibility()
            r6 = 8
            if (r5 == r6) goto L_0x00b4
            int r5 = r3.getMeasuredWidth()
            int r6 = r3.getMeasuredHeight()
            android.view.ViewGroup$LayoutParams r7 = r3.getLayoutParams()
            f3$a r7 = (p000.C0639f3.C0640a) r7
            int r8 = r7.f4963b
            if (r8 >= 0) goto L_0x006d
            r8 = r2
        L_0x006d:
            int r9 = p000.C2189w7.m15018m(r11)
            int r8 = p000.C0815h0.m5770a((int) r8, (int) r9)
            r8 = r8 & 7
            if (r8 == r4) goto L_0x0083
            r9 = 5
            if (r8 == r9) goto L_0x0080
            int r8 = r7.leftMargin
            int r8 = r8 + r0
            goto L_0x008e
        L_0x0080:
            int r8 = r12 - r5
            goto L_0x008b
        L_0x0083:
            int r8 = r14 - r5
            int r8 = r8 / 2
            int r8 = r8 + r0
            int r9 = r7.leftMargin
            int r8 = r8 + r9
        L_0x008b:
            int r9 = r7.rightMargin
            int r8 = r8 - r9
        L_0x008e:
            boolean r9 = r11.mo5304b((int) r15)
            if (r9 == 0) goto L_0x0097
            int r9 = r11.f4959m0
            int r13 = r13 + r9
        L_0x0097:
            int r9 = r7.topMargin
            int r13 = r13 + r9
            int r9 = r11.mo5307d()
            int r9 = r9 + r13
            int r5 = r5 + r8
            int r10 = r6 + r9
            r3.layout(r8, r9, r5, r10)
            int r3 = r7.bottomMargin
            int r6 = r6 + r3
            int r3 = r11.mo5309e()
            int r3 = r3 + r6
            int r3 = r3 + r13
            int r13 = r11.mo5305c()
            int r15 = r15 + r13
            goto L_0x0050
        L_0x00b4:
            int r15 = r15 + r4
            goto L_0x0042
        L_0x00b6:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0639f3.mo5301b(int, int, int, int):void");
    }

    /* renamed from: b */
    public void mo5302b(Canvas canvas) {
        int virtualChildCount = getVirtualChildCount();
        for (int i = 0; i < virtualChildCount; i++) {
            View a = mo5294a(i);
            if (!(a == null || a.getVisibility() == 8 || !mo5304b(i))) {
                mo5298a(canvas, (a.getTop() - ((C0640a) a.getLayoutParams()).topMargin) - this.f4959m0);
            }
        }
        if (mo5304b(virtualChildCount)) {
            View a2 = mo5294a(virtualChildCount - 1);
            mo5298a(canvas, a2 == null ? (getHeight() - getPaddingBottom()) - this.f4959m0 : a2.getBottom() + ((C0640a) a2.getLayoutParams()).bottomMargin);
        }
    }

    /* renamed from: b */
    public void mo5303b(Canvas canvas, int i) {
        this.f4957k0.setBounds(i, getPaddingTop() + this.f4961o0, this.f4958l0 + i, (getHeight() - getPaddingBottom()) - this.f4961o0);
        this.f4957k0.draw(canvas);
    }

    /* renamed from: b */
    public boolean mo5304b(int i) {
        if (i == 0) {
            return (this.f4960n0 & 1) != 0;
        }
        if (i == getChildCount()) {
            return (this.f4960n0 & 4) != 0;
        }
        if ((this.f4960n0 & 2) == 0) {
            return false;
        }
        for (int i2 = i - 1; i2 >= 0; i2--) {
            if (getChildAt(i2).getVisibility() != 8) {
                return true;
            }
        }
        return false;
    }

    /* renamed from: c */
    public int mo5305c() {
        return 0;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:153:0x0394, code lost:
        if (r10 > 0) goto L_0x03a2;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:156:0x039f, code lost:
        if (r10 < 0) goto L_0x03a1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:157:0x03a1, code lost:
        r10 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:158:0x03a2, code lost:
        r13.measure(android.view.View.MeasureSpec.makeMeasureSpec(r10, r4), r1);
        r8 = android.view.View.combineMeasuredStates(r8, r13.getMeasuredState() & -16777216);
        r1 = r24;
        r4 = r26;
     */
    /* JADX WARNING: Removed duplicated region for block: B:182:0x042d  */
    /* JADX WARNING: Removed duplicated region for block: B:186:0x044f  */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x0162  */
    /* JADX WARNING: Removed duplicated region for block: B:58:0x016b  */
    /* JADX WARNING: Removed duplicated region for block: B:66:0x018d  */
    /* JADX WARNING: Removed duplicated region for block: B:72:0x01b7  */
    /* JADX WARNING: Removed duplicated region for block: B:73:0x01b9  */
    /* JADX WARNING: Removed duplicated region for block: B:76:0x01c0  */
    /* JADX WARNING: Removed duplicated region for block: B:79:0x01cb  */
    /* renamed from: c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo5306c(int r39, int r40) {
        /*
            r38 = this;
            r6 = r38
            r7 = r39
            r8 = r40
            r9 = 0
            r6.f4952f0 = r9
            int r10 = r38.getVirtualChildCount()
            int r11 = android.view.View.MeasureSpec.getMode(r39)
            int r12 = android.view.View.MeasureSpec.getMode(r40)
            int[] r0 = r6.f4955i0
            r13 = 4
            if (r0 == 0) goto L_0x001e
            int[] r0 = r6.f4956j0
            if (r0 != 0) goto L_0x0026
        L_0x001e:
            int[] r0 = new int[r13]
            r6.f4955i0 = r0
            int[] r0 = new int[r13]
            r6.f4956j0 = r0
        L_0x0026:
            int[] r14 = r6.f4955i0
            int[] r15 = r6.f4956j0
            r16 = 3
            r5 = -1
            r14[r16] = r5
            r17 = 2
            r14[r17] = r5
            r18 = 1
            r14[r18] = r5
            r14[r9] = r5
            r15[r16] = r5
            r15[r17] = r5
            r15[r18] = r5
            r15[r9] = r5
            boolean r4 = r6.f4947a0
            boolean r3 = r6.f4954h0
            r2 = 1073741824(0x40000000, float:2.0)
            if (r11 != r2) goto L_0x004c
            r19 = 1
            goto L_0x004e
        L_0x004c:
            r19 = 0
        L_0x004e:
            r20 = 0
            r0 = 0
            r1 = 0
            r13 = 0
            r21 = 0
            r22 = 0
            r23 = 0
            r24 = 0
            r26 = 0
            r27 = 1
            r28 = 0
        L_0x0061:
            r5 = 8
            if (r1 >= r10) goto L_0x01f7
            android.view.View r9 = r6.mo5294a((int) r1)
            if (r9 != 0) goto L_0x007b
            int r5 = r6.f4952f0
            int r9 = r38.mo5310f()
            int r9 = r9 + r5
            r6.f4952f0 = r9
        L_0x0074:
            r37 = r3
            r30 = r4
            r2 = -1
            goto L_0x01e7
        L_0x007b:
            int r2 = r9.getVisibility()
            if (r2 != r5) goto L_0x0087
            int r2 = r38.mo5305c()
            int r1 = r1 + r2
            goto L_0x0074
        L_0x0087:
            boolean r2 = r6.mo5304b((int) r1)
            if (r2 == 0) goto L_0x0094
            int r2 = r6.f4952f0
            int r5 = r6.f4958l0
            int r2 = r2 + r5
            r6.f4952f0 = r2
        L_0x0094:
            android.view.ViewGroup$LayoutParams r2 = r9.getLayoutParams()
            r5 = r2
            f3$a r5 = (p000.C0639f3.C0640a) r5
            float r2 = r5.f4962a
            float r33 = r0 + r2
            r2 = 1073741824(0x40000000, float:2.0)
            if (r11 != r2) goto L_0x00ec
            int r0 = r5.width
            if (r0 != 0) goto L_0x00ec
            float r0 = r5.f4962a
            int r0 = (r0 > r20 ? 1 : (r0 == r20 ? 0 : -1))
            if (r0 <= 0) goto L_0x00ec
            if (r19 == 0) goto L_0x00bc
            int r0 = r6.f4952f0
            int r2 = r5.leftMargin
            r34 = r1
            int r1 = r5.rightMargin
            int r2 = r2 + r1
            int r2 = r2 + r0
            r6.f4952f0 = r2
            goto L_0x00cc
        L_0x00bc:
            r34 = r1
            int r0 = r6.f4952f0
            int r1 = r5.leftMargin
            int r1 = r1 + r0
            int r2 = r5.rightMargin
            int r1 = r1 + r2
            int r0 = java.lang.Math.max(r0, r1)
            r6.f4952f0 = r0
        L_0x00cc:
            if (r4 == 0) goto L_0x00df
            r0 = 0
            int r1 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r0)
            r9.measure(r1, r1)
            r37 = r3
            r30 = r4
            r8 = r5
            r29 = -2
            goto L_0x015e
        L_0x00df:
            r37 = r3
            r30 = r4
            r8 = r5
            r1 = 1073741824(0x40000000, float:2.0)
            r24 = 1
            r29 = -2
            goto L_0x0160
        L_0x00ec:
            r34 = r1
            int r0 = r5.width
            if (r0 != 0) goto L_0x00fd
            float r0 = r5.f4962a
            int r0 = (r0 > r20 ? 1 : (r0 == r20 ? 0 : -1))
            if (r0 <= 0) goto L_0x00fd
            r2 = -2
            r5.width = r2
            r1 = 0
            goto L_0x0100
        L_0x00fd:
            r2 = -2
            r1 = -2147483648(0xffffffff80000000, float:-0.0)
        L_0x0100:
            int r0 = (r33 > r20 ? 1 : (r33 == r20 ? 0 : -1))
            if (r0 != 0) goto L_0x0109
            int r0 = r6.f4952f0
            r30 = r0
            goto L_0x010b
        L_0x0109:
            r30 = 0
        L_0x010b:
            r35 = 0
            r0 = r38
            r36 = r1
            r1 = r9
            r32 = -2
            r2 = r39
            r37 = r3
            r3 = r30
            r30 = r4
            r4 = r40
            r8 = r5
            r7 = -2147483648(0xffffffff80000000, float:-0.0)
            r29 = -2
            r5 = r35
            r0.mo5299a(r1, r2, r3, r4, r5)
            r0 = r36
            if (r0 == r7) goto L_0x012e
            r8.width = r0
        L_0x012e:
            int r0 = r9.getMeasuredWidth()
            int r1 = r6.f4952f0
            if (r19 == 0) goto L_0x0145
            int r2 = r8.leftMargin
            int r2 = r2 + r0
            int r3 = r8.rightMargin
            int r2 = r2 + r3
            int r3 = r38.mo5309e()
            int r3 = r3 + r2
            int r3 = r3 + r1
            r6.f4952f0 = r3
            goto L_0x0158
        L_0x0145:
            int r2 = r1 + r0
            int r3 = r8.leftMargin
            int r2 = r2 + r3
            int r3 = r8.rightMargin
            int r2 = r2 + r3
            int r3 = r38.mo5309e()
            int r3 = r3 + r2
            int r1 = java.lang.Math.max(r1, r3)
            r6.f4952f0 = r1
        L_0x0158:
            if (r37 == 0) goto L_0x015e
            int r13 = java.lang.Math.max(r0, r13)
        L_0x015e:
            r1 = 1073741824(0x40000000, float:2.0)
        L_0x0160:
            if (r12 == r1) goto L_0x016b
            int r0 = r8.height
            r2 = -1
            if (r0 != r2) goto L_0x016c
            r0 = 1
            r28 = 1
            goto L_0x016d
        L_0x016b:
            r2 = -1
        L_0x016c:
            r0 = 0
        L_0x016d:
            int r3 = r8.topMargin
            int r4 = r8.bottomMargin
            int r3 = r3 + r4
            int r4 = r9.getMeasuredHeight()
            int r4 = r4 + r3
            int r5 = r9.getMeasuredState()
            r7 = r26
            int r5 = android.view.View.combineMeasuredStates(r7, r5)
            if (r30 == 0) goto L_0x01ab
            int r7 = r9.getBaseline()
            if (r7 == r2) goto L_0x01ab
            int r9 = r8.f4963b
            if (r9 >= 0) goto L_0x018f
            int r9 = r6.f4951e0
        L_0x018f:
            r9 = r9 & 112(0x70, float:1.57E-43)
            r25 = 4
            int r9 = r9 >> 4
            r9 = r9 & -2
            int r9 = r9 >> 1
            r1 = r14[r9]
            int r1 = java.lang.Math.max(r1, r7)
            r14[r9] = r1
            r1 = r15[r9]
            int r7 = r4 - r7
            int r1 = java.lang.Math.max(r1, r7)
            r15[r9] = r1
        L_0x01ab:
            r9 = r21
            int r1 = java.lang.Math.max(r9, r4)
            if (r27 == 0) goto L_0x01b9
            int r7 = r8.height
            if (r7 != r2) goto L_0x01b9
            r7 = 1
            goto L_0x01ba
        L_0x01b9:
            r7 = 0
        L_0x01ba:
            float r8 = r8.f4962a
            int r8 = (r8 > r20 ? 1 : (r8 == r20 ? 0 : -1))
            if (r8 <= 0) goto L_0x01cb
            if (r0 == 0) goto L_0x01c3
            goto L_0x01c4
        L_0x01c3:
            r3 = r4
        L_0x01c4:
            r8 = r23
            int r23 = java.lang.Math.max(r8, r3)
            goto L_0x01d8
        L_0x01cb:
            r8 = r23
            if (r0 == 0) goto L_0x01d0
            r4 = r3
        L_0x01d0:
            r3 = r22
            int r22 = java.lang.Math.max(r3, r4)
            r23 = r8
        L_0x01d8:
            int r0 = r38.mo5305c()
            int r0 = r0 + r34
            r21 = r1
            r26 = r5
            r27 = r7
            r1 = r0
            r0 = r33
        L_0x01e7:
            int r1 = r1 + 1
            r7 = r39
            r8 = r40
            r4 = r30
            r3 = r37
            r2 = 1073741824(0x40000000, float:2.0)
            r5 = -1
            r9 = 0
            goto L_0x0061
        L_0x01f7:
            r37 = r3
            r30 = r4
            r9 = r21
            r3 = r22
            r8 = r23
            r2 = -1
            r7 = -2147483648(0xffffffff80000000, float:-0.0)
            r29 = -2
            int r1 = r6.f4952f0
            if (r1 <= 0) goto L_0x0217
            boolean r1 = r6.mo5304b((int) r10)
            if (r1 == 0) goto L_0x0217
            int r1 = r6.f4952f0
            int r4 = r6.f4958l0
            int r1 = r1 + r4
            r6.f4952f0 = r1
        L_0x0217:
            r1 = r14[r18]
            if (r1 != r2) goto L_0x022b
            r1 = 0
            r4 = r14[r1]
            if (r4 != r2) goto L_0x022b
            r1 = r14[r17]
            if (r1 != r2) goto L_0x022b
            r1 = r14[r16]
            if (r1 == r2) goto L_0x0229
            goto L_0x022b
        L_0x0229:
            r1 = r9
            goto L_0x0259
        L_0x022b:
            r1 = r14[r16]
            r4 = 0
            r2 = r14[r4]
            r5 = r14[r18]
            r7 = r14[r17]
            int r5 = java.lang.Math.max(r5, r7)
            int r2 = java.lang.Math.max(r2, r5)
            int r1 = java.lang.Math.max(r1, r2)
            r2 = r15[r16]
            r5 = r15[r4]
            r4 = r15[r18]
            r7 = r15[r17]
            int r4 = java.lang.Math.max(r4, r7)
            int r4 = java.lang.Math.max(r5, r4)
            int r2 = java.lang.Math.max(r2, r4)
            int r2 = r2 + r1
            int r1 = java.lang.Math.max(r9, r2)
        L_0x0259:
            if (r37 == 0) goto L_0x02b2
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r11 == r2) goto L_0x0261
            if (r11 != 0) goto L_0x02b2
        L_0x0261:
            r2 = 0
            r6.f4952f0 = r2
            r2 = 0
        L_0x0265:
            if (r2 >= r10) goto L_0x02b2
            android.view.View r4 = r6.mo5294a((int) r2)
            if (r4 != 0) goto L_0x0277
            int r4 = r6.f4952f0
            int r5 = r38.mo5310f()
            int r5 = r5 + r4
            r6.f4952f0 = r5
            goto L_0x02af
        L_0x0277:
            int r5 = r4.getVisibility()
            r7 = 8
            if (r5 != r7) goto L_0x0285
            int r4 = r38.mo5305c()
            int r2 = r2 + r4
            goto L_0x02af
        L_0x0285:
            android.view.ViewGroup$LayoutParams r4 = r4.getLayoutParams()
            f3$a r4 = (p000.C0639f3.C0640a) r4
            int r5 = r6.f4952f0
            if (r19 == 0) goto L_0x029c
            int r7 = r4.leftMargin
            int r7 = r7 + r13
            int r4 = r4.rightMargin
            int r7 = r7 + r4
            int r4 = r38.mo5309e()
            int r4 = r4 + r7
            int r4 = r4 + r5
            goto L_0x02ad
        L_0x029c:
            int r7 = r5 + r13
            int r9 = r4.leftMargin
            int r7 = r7 + r9
            int r4 = r4.rightMargin
            int r7 = r7 + r4
            int r4 = r38.mo5309e()
            int r4 = r4 + r7
            int r4 = java.lang.Math.max(r5, r4)
        L_0x02ad:
            r6.f4952f0 = r4
        L_0x02af:
            int r2 = r2 + 1
            goto L_0x0265
        L_0x02b2:
            int r2 = r6.f4952f0
            int r4 = r38.getPaddingLeft()
            int r5 = r38.getPaddingRight()
            int r5 = r5 + r4
            int r5 = r5 + r2
            r6.f4952f0 = r5
            int r2 = r6.f4952f0
            int r4 = r38.getSuggestedMinimumWidth()
            int r2 = java.lang.Math.max(r2, r4)
            r4 = r39
            r5 = 0
            int r2 = android.view.View.resolveSizeAndState(r2, r4, r5)
            r5 = 16777215(0xffffff, float:2.3509886E-38)
            r5 = r5 & r2
            int r7 = r6.f4952f0
            int r5 = r5 - r7
            if (r24 != 0) goto L_0x0325
            if (r5 == 0) goto L_0x02e1
            int r9 = (r0 > r20 ? 1 : (r0 == r20 ? 0 : -1))
            if (r9 <= 0) goto L_0x02e1
            goto L_0x0325
        L_0x02e1:
            int r0 = java.lang.Math.max(r3, r8)
            if (r37 == 0) goto L_0x031d
            r3 = 1073741824(0x40000000, float:2.0)
            if (r11 == r3) goto L_0x031d
            r3 = 0
        L_0x02ec:
            if (r3 >= r10) goto L_0x031d
            android.view.View r5 = r6.mo5294a((int) r3)
            if (r5 == 0) goto L_0x031a
            int r8 = r5.getVisibility()
            r9 = 8
            if (r8 != r9) goto L_0x02fd
            goto L_0x031a
        L_0x02fd:
            android.view.ViewGroup$LayoutParams r8 = r5.getLayoutParams()
            f3$a r8 = (p000.C0639f3.C0640a) r8
            float r8 = r8.f4962a
            int r8 = (r8 > r20 ? 1 : (r8 == r20 ? 0 : -1))
            if (r8 <= 0) goto L_0x031a
            r8 = 1073741824(0x40000000, float:2.0)
            int r9 = android.view.View.MeasureSpec.makeMeasureSpec(r13, r8)
            int r11 = r5.getMeasuredHeight()
            int r11 = android.view.View.MeasureSpec.makeMeasureSpec(r11, r8)
            r5.measure(r9, r11)
        L_0x031a:
            int r3 = r3 + 1
            goto L_0x02ec
        L_0x031d:
            r5 = r40
            r23 = r10
            r8 = r26
            goto L_0x04c0
        L_0x0325:
            float r1 = r6.f4953g0
            int r8 = (r1 > r20 ? 1 : (r1 == r20 ? 0 : -1))
            if (r8 <= 0) goto L_0x032c
            r0 = r1
        L_0x032c:
            r1 = -1
            r14[r16] = r1
            r14[r17] = r1
            r14[r18] = r1
            r8 = 0
            r14[r8] = r1
            r15[r16] = r1
            r15[r17] = r1
            r15[r18] = r1
            r15[r8] = r1
            r6.f4952f0 = r8
            r1 = r0
            r9 = r3
            r8 = r26
            r0 = 0
            r3 = -1
        L_0x0346:
            if (r0 >= r10) goto L_0x0469
            android.view.View r13 = r6.mo5294a((int) r0)
            if (r13 == 0) goto L_0x0459
            int r7 = r13.getVisibility()
            r4 = 8
            if (r7 != r4) goto L_0x0358
            goto L_0x0459
        L_0x0358:
            android.view.ViewGroup$LayoutParams r7 = r13.getLayoutParams()
            f3$a r7 = (p000.C0639f3.C0640a) r7
            float r4 = r7.f4962a
            int r23 = (r4 > r20 ? 1 : (r4 == r20 ? 0 : -1))
            if (r23 <= 0) goto L_0x03b9
            r23 = r10
            float r10 = (float) r5
            float r10 = r10 * r4
            float r10 = r10 / r1
            int r10 = (int) r10
            float r1 = r1 - r4
            int r5 = r5 - r10
            int r4 = r38.getPaddingTop()
            int r24 = r38.getPaddingBottom()
            int r24 = r24 + r4
            int r4 = r7.topMargin
            int r24 = r24 + r4
            int r4 = r7.bottomMargin
            int r4 = r24 + r4
            r24 = r1
            int r1 = r7.height
            r26 = r5
            r5 = r40
            int r1 = android.view.ViewGroup.getChildMeasureSpec(r5, r4, r1)
            int r4 = r7.width
            if (r4 != 0) goto L_0x0397
            r4 = 1073741824(0x40000000, float:2.0)
            if (r11 == r4) goto L_0x0394
            goto L_0x0399
        L_0x0394:
            if (r10 <= 0) goto L_0x03a1
            goto L_0x03a2
        L_0x0397:
            r4 = 1073741824(0x40000000, float:2.0)
        L_0x0399:
            int r31 = r13.getMeasuredWidth()
            int r10 = r31 + r10
            if (r10 >= 0) goto L_0x03a2
        L_0x03a1:
            r10 = 0
        L_0x03a2:
            int r10 = android.view.View.MeasureSpec.makeMeasureSpec(r10, r4)
            r13.measure(r10, r1)
            int r1 = r13.getMeasuredState()
            r4 = -16777216(0xffffffffff000000, float:-1.7014118E38)
            r1 = r1 & r4
            int r8 = android.view.View.combineMeasuredStates(r8, r1)
            r1 = r24
            r4 = r26
            goto L_0x03be
        L_0x03b9:
            r4 = r5
            r23 = r10
            r5 = r40
        L_0x03be:
            if (r19 == 0) goto L_0x03dc
            int r10 = r6.f4952f0
            int r24 = r13.getMeasuredWidth()
            r26 = r1
            int r1 = r7.leftMargin
            int r24 = r24 + r1
            int r1 = r7.rightMargin
            int r24 = r24 + r1
            int r1 = r38.mo5309e()
            int r1 = r1 + r24
            int r1 = r1 + r10
            r6.f4952f0 = r1
            r24 = r4
            goto L_0x03f8
        L_0x03dc:
            r26 = r1
            int r1 = r6.f4952f0
            int r10 = r13.getMeasuredWidth()
            int r10 = r10 + r1
            r24 = r4
            int r4 = r7.leftMargin
            int r10 = r10 + r4
            int r4 = r7.rightMargin
            int r10 = r10 + r4
            int r4 = r38.mo5309e()
            int r4 = r4 + r10
            int r1 = java.lang.Math.max(r1, r4)
            r6.f4952f0 = r1
        L_0x03f8:
            r1 = 1073741824(0x40000000, float:2.0)
            if (r12 == r1) goto L_0x0403
            int r1 = r7.height
            r4 = -1
            if (r1 != r4) goto L_0x0403
            r1 = 1
            goto L_0x0404
        L_0x0403:
            r1 = 0
        L_0x0404:
            int r4 = r7.topMargin
            int r10 = r7.bottomMargin
            int r4 = r4 + r10
            int r10 = r13.getMeasuredHeight()
            int r10 = r10 + r4
            int r3 = java.lang.Math.max(r3, r10)
            if (r1 == 0) goto L_0x0415
            goto L_0x0416
        L_0x0415:
            r4 = r10
        L_0x0416:
            int r1 = java.lang.Math.max(r9, r4)
            if (r27 == 0) goto L_0x0423
            int r4 = r7.height
            r9 = -1
            if (r4 != r9) goto L_0x0424
            r4 = 1
            goto L_0x0425
        L_0x0423:
            r9 = -1
        L_0x0424:
            r4 = 0
        L_0x0425:
            if (r30 == 0) goto L_0x044f
            int r13 = r13.getBaseline()
            if (r13 == r9) goto L_0x044f
            int r7 = r7.f4963b
            if (r7 >= 0) goto L_0x0433
            int r7 = r6.f4951e0
        L_0x0433:
            r7 = r7 & 112(0x70, float:1.57E-43)
            r25 = 4
            int r7 = r7 >> 4
            r7 = r7 & -2
            int r7 = r7 >> 1
            r9 = r14[r7]
            int r9 = java.lang.Math.max(r9, r13)
            r14[r7] = r9
            r9 = r15[r7]
            int r10 = r10 - r13
            int r9 = java.lang.Math.max(r9, r10)
            r15[r7] = r9
            goto L_0x0451
        L_0x044f:
            r25 = 4
        L_0x0451:
            r9 = r1
            r27 = r4
            r4 = r24
            r1 = r26
            goto L_0x0460
        L_0x0459:
            r4 = r5
            r23 = r10
            r25 = 4
            r5 = r40
        L_0x0460:
            int r0 = r0 + 1
            r5 = r4
            r10 = r23
            r4 = r39
            goto L_0x0346
        L_0x0469:
            r5 = r40
            r23 = r10
            int r0 = r6.f4952f0
            int r1 = r38.getPaddingLeft()
            int r4 = r38.getPaddingRight()
            int r4 = r4 + r1
            int r4 = r4 + r0
            r6.f4952f0 = r4
            r0 = r14[r18]
            r1 = -1
            if (r0 != r1) goto L_0x0490
            r0 = 0
            r4 = r14[r0]
            if (r4 != r1) goto L_0x0490
            r0 = r14[r17]
            if (r0 != r1) goto L_0x0490
            r0 = r14[r16]
            if (r0 == r1) goto L_0x048e
            goto L_0x0490
        L_0x048e:
            r1 = r3
            goto L_0x04bf
        L_0x0490:
            r0 = r14[r16]
            r1 = 0
            r4 = r14[r1]
            r7 = r14[r18]
            r10 = r14[r17]
            int r7 = java.lang.Math.max(r7, r10)
            int r4 = java.lang.Math.max(r4, r7)
            int r0 = java.lang.Math.max(r0, r4)
            r4 = r15[r16]
            r1 = r15[r1]
            r7 = r15[r18]
            r10 = r15[r17]
            int r7 = java.lang.Math.max(r7, r10)
            int r1 = java.lang.Math.max(r1, r7)
            int r1 = java.lang.Math.max(r4, r1)
            int r1 = r1 + r0
            int r0 = java.lang.Math.max(r3, r1)
            r1 = r0
        L_0x04bf:
            r0 = r9
        L_0x04c0:
            if (r27 != 0) goto L_0x04c7
            r3 = 1073741824(0x40000000, float:2.0)
            if (r12 == r3) goto L_0x04c7
            goto L_0x04c8
        L_0x04c7:
            r0 = r1
        L_0x04c8:
            int r1 = r38.getPaddingTop()
            int r3 = r38.getPaddingBottom()
            int r3 = r3 + r1
            int r3 = r3 + r0
            int r0 = r38.getSuggestedMinimumHeight()
            int r0 = java.lang.Math.max(r3, r0)
            r1 = -16777216(0xffffffffff000000, float:-1.7014118E38)
            r1 = r1 & r8
            r1 = r1 | r2
            int r2 = r8 << 16
            int r0 = android.view.View.resolveSizeAndState(r0, r5, r2)
            r6.setMeasuredDimension(r1, r0)
            if (r28 == 0) goto L_0x04f0
            r0 = r39
            r1 = r23
            r6.mo5295a((int) r1, (int) r0)
        L_0x04f0:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0639f3.mo5306c(int, int):void");
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0640a;
    }

    /* renamed from: d */
    public int mo5307d() {
        return 0;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:125:0x02c3, code lost:
        if (r10 > 0) goto L_0x02d1;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:128:0x02ce, code lost:
        if (r10 < 0) goto L_0x02d0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:129:0x02d0, code lost:
        r10 = 0;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:130:0x02d1, code lost:
        r14.measure(r3, android.view.View.MeasureSpec.makeMeasureSpec(r10, r12));
        r9 = android.view.View.combineMeasuredStates(r9, r14.getMeasuredState() & -256);
        r3 = r23;
     */
    /* JADX WARNING: Removed duplicated region for block: B:140:0x030e  */
    /* JADX WARNING: Removed duplicated region for block: B:145:0x0319  */
    /* JADX WARNING: Removed duplicated region for block: B:146:0x031b  */
    /* JADX WARNING: Removed duplicated region for block: B:29:0x00b1  */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x00b6  */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x00d9  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x00f6  */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x00fb  */
    /* JADX WARNING: Removed duplicated region for block: B:59:0x014a  */
    /* JADX WARNING: Removed duplicated region for block: B:60:0x014c  */
    /* JADX WARNING: Removed duplicated region for block: B:63:0x0154  */
    /* JADX WARNING: Removed duplicated region for block: B:66:0x0160  */
    /* renamed from: d */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo5308d(int r34, int r35) {
        /*
            r33 = this;
            r6 = r33
            r7 = r34
            r8 = r35
            r9 = 0
            r6.f4952f0 = r9
            int r10 = r33.getVirtualChildCount()
            int r11 = android.view.View.MeasureSpec.getMode(r34)
            int r12 = android.view.View.MeasureSpec.getMode(r35)
            int r13 = r6.f4948b0
            boolean r14 = r6.f4954h0
            r16 = 1
            r0 = 0
            r1 = 0
            r2 = 0
            r4 = 0
            r5 = 0
            r17 = 0
            r19 = 1
            r20 = 0
            r21 = 0
        L_0x0028:
            r3 = 8
            if (r5 >= r10) goto L_0x0184
            android.view.View r25 = r6.mo5294a((int) r5)
            if (r25 != 0) goto L_0x0043
            int r3 = r6.f4952f0
            int r15 = r33.mo5310f()
            int r15 = r15 + r3
            r6.f4952f0 = r15
        L_0x003b:
            r22 = r10
            r8 = r21
            r21 = r12
            goto L_0x0176
        L_0x0043:
            int r15 = r25.getVisibility()
            if (r15 != r3) goto L_0x004f
            int r3 = r33.mo5305c()
            int r5 = r5 + r3
            goto L_0x003b
        L_0x004f:
            boolean r3 = r6.mo5304b((int) r5)
            if (r3 == 0) goto L_0x005c
            int r3 = r6.f4952f0
            int r15 = r6.f4959m0
            int r3 = r3 + r15
            r6.f4952f0 = r3
        L_0x005c:
            android.view.ViewGroup$LayoutParams r3 = r25.getLayoutParams()
            r15 = r3
            f3$a r15 = (p000.C0639f3.C0640a) r15
            float r3 = r15.f4962a
            float r26 = r0 + r3
            r0 = 1073741824(0x40000000, float:2.0)
            if (r12 != r0) goto L_0x0096
            int r0 = r15.height
            if (r0 != 0) goto L_0x0096
            float r0 = r15.f4962a
            r3 = 0
            int r0 = (r0 > r3 ? 1 : (r0 == r3 ? 0 : -1))
            if (r0 <= 0) goto L_0x0096
            int r0 = r6.f4952f0
            int r3 = r15.topMargin
            int r3 = r3 + r0
            r27 = r1
            int r1 = r15.bottomMargin
            int r3 = r3 + r1
            int r0 = java.lang.Math.max(r0, r3)
            r6.f4952f0 = r0
            r31 = r4
            r32 = r5
            r22 = r10
            r8 = r21
            r30 = r27
            r17 = 1
            r21 = r12
            goto L_0x00fc
        L_0x0096:
            r27 = r1
            int r0 = r15.height
            if (r0 != 0) goto L_0x00a8
            float r0 = r15.f4962a
            r1 = 0
            int r0 = (r0 > r1 ? 1 : (r0 == r1 ? 0 : -1))
            if (r0 <= 0) goto L_0x00a9
            r0 = -2
            r15.height = r0
            r3 = 0
            goto L_0x00ab
        L_0x00a8:
            r1 = 0
        L_0x00a9:
            r3 = -2147483648(0xffffffff80000000, float:-0.0)
        L_0x00ab:
            r28 = 0
            int r0 = (r26 > r1 ? 1 : (r26 == r1 ? 0 : -1))
            if (r0 != 0) goto L_0x00b6
            int r0 = r6.f4952f0
            r29 = r0
            goto L_0x00b8
        L_0x00b6:
            r29 = 0
        L_0x00b8:
            r0 = r33
            r30 = r27
            r1 = r25
            r7 = r2
            r2 = r34
            r22 = r10
            r8 = r21
            r10 = -2147483648(0xffffffff80000000, float:-0.0)
            r21 = r12
            r12 = r3
            r3 = r28
            r31 = r4
            r4 = r35
            r32 = r5
            r5 = r29
            r0.mo5299a(r1, r2, r3, r4, r5)
            if (r12 == r10) goto L_0x00db
            r15.height = r12
        L_0x00db:
            int r0 = r25.getMeasuredHeight()
            int r1 = r6.f4952f0
            int r2 = r1 + r0
            int r3 = r15.topMargin
            int r2 = r2 + r3
            int r3 = r15.bottomMargin
            int r2 = r2 + r3
            int r3 = r33.mo5309e()
            int r3 = r3 + r2
            int r1 = java.lang.Math.max(r1, r3)
            r6.f4952f0 = r1
            if (r14 == 0) goto L_0x00fb
            int r2 = java.lang.Math.max(r0, r7)
            goto L_0x00fc
        L_0x00fb:
            r2 = r7
        L_0x00fc:
            if (r13 < 0) goto L_0x0109
            r0 = r32
            int r5 = r0 + 1
            if (r13 != r5) goto L_0x010b
            int r1 = r6.f4952f0
            r6.f4949c0 = r1
            goto L_0x010b
        L_0x0109:
            r0 = r32
        L_0x010b:
            if (r0 >= r13) goto L_0x011d
            float r1 = r15.f4962a
            r3 = 0
            int r1 = (r1 > r3 ? 1 : (r1 == r3 ? 0 : -1))
            if (r1 > 0) goto L_0x0115
            goto L_0x011d
        L_0x0115:
            java.lang.RuntimeException r0 = new java.lang.RuntimeException
            java.lang.String r1 = "A child of LinearLayout with index less than mBaselineAlignedChildIndex has weight > 0, which won't work.  Either remove the weight, or don't set mBaselineAlignedChildIndex."
            r0.<init>(r1)
            throw r0
        L_0x011d:
            r1 = 1073741824(0x40000000, float:2.0)
            if (r11 == r1) goto L_0x012a
            int r1 = r15.width
            r4 = -1
            if (r1 != r4) goto L_0x012b
            r1 = 1
            r20 = 1
            goto L_0x012c
        L_0x012a:
            r4 = -1
        L_0x012b:
            r1 = 0
        L_0x012c:
            int r3 = r15.leftMargin
            int r5 = r15.rightMargin
            int r3 = r3 + r5
            int r5 = r25.getMeasuredWidth()
            int r5 = r5 + r3
            r12 = r30
            int r7 = java.lang.Math.max(r12, r5)
            int r10 = r25.getMeasuredState()
            int r9 = android.view.View.combineMeasuredStates(r9, r10)
            if (r19 == 0) goto L_0x014c
            int r10 = r15.width
            if (r10 != r4) goto L_0x014c
            r4 = 1
            goto L_0x014d
        L_0x014c:
            r4 = 0
        L_0x014d:
            float r10 = r15.f4962a
            r12 = 0
            int r10 = (r10 > r12 ? 1 : (r10 == r12 ? 0 : -1))
            if (r10 <= 0) goto L_0x0160
            if (r1 == 0) goto L_0x0157
            goto L_0x0158
        L_0x0157:
            r3 = r5
        L_0x0158:
            int r1 = java.lang.Math.max(r8, r3)
            r8 = r1
            r1 = r31
            goto L_0x016a
        L_0x0160:
            if (r1 == 0) goto L_0x0163
            goto L_0x0164
        L_0x0163:
            r3 = r5
        L_0x0164:
            r1 = r31
            int r1 = java.lang.Math.max(r1, r3)
        L_0x016a:
            int r3 = r33.mo5305c()
            int r5 = r3 + r0
            r19 = r4
            r0 = r26
            r4 = r1
            r1 = r7
        L_0x0176:
            int r5 = r5 + 1
            r7 = r34
            r12 = r21
            r10 = r22
            r21 = r8
            r8 = r35
            goto L_0x0028
        L_0x0184:
            r7 = r2
            r22 = r10
            r8 = r21
            r10 = -2147483648(0xffffffff80000000, float:-0.0)
            r21 = r12
            r12 = r1
            r1 = r4
            r4 = -1
            int r2 = r6.f4952f0
            if (r2 <= 0) goto L_0x01a4
            r2 = r22
            boolean r5 = r6.mo5304b((int) r2)
            if (r5 == 0) goto L_0x01a6
            int r5 = r6.f4952f0
            int r13 = r6.f4959m0
            int r5 = r5 + r13
            r6.f4952f0 = r5
            goto L_0x01a6
        L_0x01a4:
            r2 = r22
        L_0x01a6:
            r5 = r21
            if (r14 == 0) goto L_0x01f2
            if (r5 == r10) goto L_0x01ae
            if (r5 != 0) goto L_0x01f2
        L_0x01ae:
            r10 = 0
            r6.f4952f0 = r10
            r10 = 0
        L_0x01b2:
            if (r10 >= r2) goto L_0x01f2
            android.view.View r13 = r6.mo5294a((int) r10)
            if (r13 != 0) goto L_0x01c4
            int r13 = r6.f4952f0
            int r15 = r33.mo5310f()
            int r15 = r15 + r13
            r6.f4952f0 = r15
            goto L_0x01ee
        L_0x01c4:
            int r15 = r13.getVisibility()
            if (r15 != r3) goto L_0x01d0
            int r13 = r33.mo5305c()
            int r10 = r10 + r13
            goto L_0x01ee
        L_0x01d0:
            android.view.ViewGroup$LayoutParams r13 = r13.getLayoutParams()
            f3$a r13 = (p000.C0639f3.C0640a) r13
            int r15 = r6.f4952f0
            int r21 = r15 + r7
            int r4 = r13.topMargin
            int r21 = r21 + r4
            int r4 = r13.bottomMargin
            int r21 = r21 + r4
            int r4 = r33.mo5309e()
            int r4 = r4 + r21
            int r4 = java.lang.Math.max(r15, r4)
            r6.f4952f0 = r4
        L_0x01ee:
            int r10 = r10 + 1
            r4 = -1
            goto L_0x01b2
        L_0x01f2:
            int r4 = r6.f4952f0
            int r10 = r33.getPaddingTop()
            int r13 = r33.getPaddingBottom()
            int r13 = r13 + r10
            int r13 = r13 + r4
            r6.f4952f0 = r13
            int r4 = r6.f4952f0
            int r10 = r33.getSuggestedMinimumHeight()
            int r4 = java.lang.Math.max(r4, r10)
            r10 = r8
            r13 = 0
            r8 = r35
            int r4 = android.view.View.resolveSizeAndState(r4, r8, r13)
            r13 = 16777215(0xffffff, float:2.3509886E-38)
            r13 = r13 & r4
            int r15 = r6.f4952f0
            int r13 = r13 - r15
            if (r17 != 0) goto L_0x0263
            if (r13 == 0) goto L_0x0223
            r15 = 0
            int r17 = (r0 > r15 ? 1 : (r0 == r15 ? 0 : -1))
            if (r17 <= 0) goto L_0x0223
            goto L_0x0263
        L_0x0223:
            int r0 = java.lang.Math.max(r1, r10)
            if (r14 == 0) goto L_0x025e
            r1 = 1073741824(0x40000000, float:2.0)
            if (r5 == r1) goto L_0x025e
            r1 = 0
        L_0x022e:
            if (r1 >= r2) goto L_0x025e
            android.view.View r5 = r6.mo5294a((int) r1)
            if (r5 == 0) goto L_0x025b
            int r10 = r5.getVisibility()
            if (r10 != r3) goto L_0x023d
            goto L_0x025b
        L_0x023d:
            android.view.ViewGroup$LayoutParams r10 = r5.getLayoutParams()
            f3$a r10 = (p000.C0639f3.C0640a) r10
            float r10 = r10.f4962a
            r13 = 0
            int r10 = (r10 > r13 ? 1 : (r10 == r13 ? 0 : -1))
            if (r10 <= 0) goto L_0x025b
            int r10 = r5.getMeasuredWidth()
            r13 = 1073741824(0x40000000, float:2.0)
            int r10 = android.view.View.MeasureSpec.makeMeasureSpec(r10, r13)
            int r14 = android.view.View.MeasureSpec.makeMeasureSpec(r7, r13)
            r5.measure(r10, r14)
        L_0x025b:
            int r1 = r1 + 1
            goto L_0x022e
        L_0x025e:
            r13 = r34
            r1 = r12
            goto L_0x0355
        L_0x0263:
            float r7 = r6.f4953g0
            r10 = 0
            int r14 = (r7 > r10 ? 1 : (r7 == r10 ? 0 : -1))
            if (r14 <= 0) goto L_0x026b
            r0 = r7
        L_0x026b:
            r10 = 0
            r6.f4952f0 = r10
            r7 = r1
            r1 = r12
            r12 = r0
            r0 = 0
        L_0x0272:
            if (r0 >= r2) goto L_0x0344
            android.view.View r14 = r6.mo5294a((int) r0)
            int r15 = r14.getVisibility()
            if (r15 != r3) goto L_0x0287
            r24 = r13
            r3 = -1
            r18 = 0
            r13 = r34
            goto L_0x033b
        L_0x0287:
            android.view.ViewGroup$LayoutParams r15 = r14.getLayoutParams()
            f3$a r15 = (p000.C0639f3.C0640a) r15
            float r3 = r15.f4962a
            r18 = 0
            int r21 = (r3 > r18 ? 1 : (r3 == r18 ? 0 : -1))
            if (r21 <= 0) goto L_0x02e5
            float r10 = (float) r13
            float r10 = r10 * r3
            float r10 = r10 / r12
            int r10 = (int) r10
            float r12 = r12 - r3
            int r13 = r13 - r10
            int r3 = r33.getPaddingLeft()
            int r22 = r33.getPaddingRight()
            int r22 = r22 + r3
            int r3 = r15.leftMargin
            int r22 = r22 + r3
            int r3 = r15.rightMargin
            int r3 = r22 + r3
            r22 = r12
            int r12 = r15.width
            r23 = r13
            r13 = r34
            int r3 = android.view.ViewGroup.getChildMeasureSpec(r13, r3, r12)
            int r12 = r15.height
            if (r12 != 0) goto L_0x02c6
            r12 = 1073741824(0x40000000, float:2.0)
            if (r5 == r12) goto L_0x02c3
            goto L_0x02c8
        L_0x02c3:
            if (r10 <= 0) goto L_0x02d0
            goto L_0x02d1
        L_0x02c6:
            r12 = 1073741824(0x40000000, float:2.0)
        L_0x02c8:
            int r24 = r14.getMeasuredHeight()
            int r10 = r24 + r10
            if (r10 >= 0) goto L_0x02d1
        L_0x02d0:
            r10 = 0
        L_0x02d1:
            int r10 = android.view.View.MeasureSpec.makeMeasureSpec(r10, r12)
            r14.measure(r3, r10)
            int r3 = r14.getMeasuredState()
            r3 = r3 & -256(0xffffffffffffff00, float:NaN)
            int r9 = android.view.View.combineMeasuredStates(r9, r3)
            r3 = r23
            goto L_0x02ea
        L_0x02e5:
            r3 = r13
            r13 = r34
            r22 = r12
        L_0x02ea:
            int r10 = r15.leftMargin
            int r12 = r15.rightMargin
            int r10 = r10 + r12
            int r12 = r14.getMeasuredWidth()
            int r12 = r12 + r10
            int r1 = java.lang.Math.max(r1, r12)
            r23 = r1
            r1 = 1073741824(0x40000000, float:2.0)
            if (r11 == r1) goto L_0x0307
            int r1 = r15.width
            r24 = r3
            r3 = -1
            if (r1 != r3) goto L_0x030a
            r1 = 1
            goto L_0x030b
        L_0x0307:
            r24 = r3
            r3 = -1
        L_0x030a:
            r1 = 0
        L_0x030b:
            if (r1 == 0) goto L_0x030e
            goto L_0x030f
        L_0x030e:
            r10 = r12
        L_0x030f:
            int r1 = java.lang.Math.max(r7, r10)
            if (r19 == 0) goto L_0x031b
            int r7 = r15.width
            if (r7 != r3) goto L_0x031b
            r7 = 1
            goto L_0x031c
        L_0x031b:
            r7 = 0
        L_0x031c:
            int r10 = r6.f4952f0
            int r12 = r14.getMeasuredHeight()
            int r12 = r12 + r10
            int r14 = r15.topMargin
            int r12 = r12 + r14
            int r14 = r15.bottomMargin
            int r12 = r12 + r14
            int r14 = r33.mo5309e()
            int r14 = r14 + r12
            int r10 = java.lang.Math.max(r10, r14)
            r6.f4952f0 = r10
            r19 = r7
            r12 = r22
            r7 = r1
            r1 = r23
        L_0x033b:
            int r0 = r0 + 1
            r13 = r24
            r3 = 8
            r10 = 0
            goto L_0x0272
        L_0x0344:
            r13 = r34
            int r0 = r6.f4952f0
            int r3 = r33.getPaddingTop()
            int r5 = r33.getPaddingBottom()
            int r5 = r5 + r3
            int r5 = r5 + r0
            r6.f4952f0 = r5
            r0 = r7
        L_0x0355:
            if (r19 != 0) goto L_0x035c
            r3 = 1073741824(0x40000000, float:2.0)
            if (r11 == r3) goto L_0x035c
            goto L_0x035d
        L_0x035c:
            r0 = r1
        L_0x035d:
            int r1 = r33.getPaddingLeft()
            int r3 = r33.getPaddingRight()
            int r3 = r3 + r1
            int r3 = r3 + r0
            int r0 = r33.getSuggestedMinimumWidth()
            int r0 = java.lang.Math.max(r3, r0)
            int r0 = android.view.View.resolveSizeAndState(r0, r13, r9)
            r6.setMeasuredDimension(r0, r4)
            if (r20 == 0) goto L_0x037b
            r6.mo5300b((int) r2, (int) r8)
        L_0x037b:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0639f3.mo5308d(int, int):void");
    }

    /* renamed from: e */
    public int mo5309e() {
        return 0;
    }

    /* renamed from: f */
    public int mo5310f() {
        return 0;
    }

    public C0640a generateDefaultLayoutParams() {
        int i = this.f4950d0;
        if (i == 0) {
            return new C0640a(-2, -2);
        }
        if (i == 1) {
            return new C0640a(-1, -2);
        }
        return null;
    }

    public C0640a generateLayoutParams(AttributeSet attributeSet) {
        return new C0640a(getContext(), attributeSet);
    }

    public C0640a generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new C0640a(layoutParams);
    }

    public int getBaseline() {
        int i;
        if (this.f4948b0 < 0) {
            return super.getBaseline();
        }
        int childCount = getChildCount();
        int i2 = this.f4948b0;
        if (childCount > i2) {
            View childAt = getChildAt(i2);
            int baseline = childAt.getBaseline();
            if (baseline != -1) {
                int i3 = this.f4949c0;
                if (this.f4950d0 == 1 && (i = this.f4951e0 & 112) != 48) {
                    if (i == 16) {
                        i3 += ((((getBottom() - getTop()) - getPaddingTop()) - getPaddingBottom()) - this.f4952f0) / 2;
                    } else if (i == 80) {
                        i3 = ((getBottom() - getTop()) - getPaddingBottom()) - this.f4952f0;
                    }
                }
                return i3 + ((C0640a) childAt.getLayoutParams()).topMargin + baseline;
            } else if (this.f4948b0 == 0) {
                return -1;
            } else {
                throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout points to a View that doesn't know how to get its baseline.");
            }
        } else {
            throw new RuntimeException("mBaselineAlignedChildIndex of LinearLayout set to an index that is out of bounds.");
        }
    }

    public int getBaselineAlignedChildIndex() {
        return this.f4948b0;
    }

    public Drawable getDividerDrawable() {
        return this.f4957k0;
    }

    public int getDividerPadding() {
        return this.f4961o0;
    }

    public int getDividerWidth() {
        return this.f4958l0;
    }

    public int getGravity() {
        return this.f4951e0;
    }

    public int getOrientation() {
        return this.f4950d0;
    }

    public int getShowDividers() {
        return this.f4960n0;
    }

    public int getVirtualChildCount() {
        return getChildCount();
    }

    public float getWeightSum() {
        return this.f4953g0;
    }

    public void onDraw(Canvas canvas) {
        if (this.f4957k0 != null) {
            if (this.f4950d0 == 1) {
                mo5302b(canvas);
            } else {
                mo5297a(canvas);
            }
        }
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName("androidx.appcompat.widget.LinearLayoutCompat");
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        if (this.f4950d0 == 1) {
            mo5301b(i, i2, i3, i4);
        } else {
            mo5296a(i, i2, i3, i4);
        }
    }

    public void onMeasure(int i, int i2) {
        if (this.f4950d0 == 1) {
            mo5308d(i, i2);
        } else {
            mo5306c(i, i2);
        }
    }

    public void setBaselineAligned(boolean z) {
        this.f4947a0 = z;
    }

    public void setBaselineAlignedChildIndex(int i) {
        if (i < 0 || i >= getChildCount()) {
            StringBuilder a = C0789gk.m5562a("base aligned child index out of range (0, ");
            a.append(getChildCount());
            a.append(")");
            throw new IllegalArgumentException(a.toString());
        }
        this.f4948b0 = i;
    }

    public void setDividerDrawable(Drawable drawable) {
        if (drawable != this.f4957k0) {
            this.f4957k0 = drawable;
            boolean z = false;
            if (drawable != null) {
                this.f4958l0 = drawable.getIntrinsicWidth();
                this.f4959m0 = drawable.getIntrinsicHeight();
            } else {
                this.f4958l0 = 0;
                this.f4959m0 = 0;
            }
            if (drawable == null) {
                z = true;
            }
            setWillNotDraw(z);
            requestLayout();
        }
    }

    public void setDividerPadding(int i) {
        this.f4961o0 = i;
    }

    public void setGravity(int i) {
        if (this.f4951e0 != i) {
            if ((8388615 & i) == 0) {
                i |= 8388611;
            }
            if ((i & 112) == 0) {
                i |= 48;
            }
            this.f4951e0 = i;
            requestLayout();
        }
    }

    public void setHorizontalGravity(int i) {
        int i2 = i & 8388615;
        int i3 = this.f4951e0;
        if ((8388615 & i3) != i2) {
            this.f4951e0 = i2 | (-8388616 & i3);
            requestLayout();
        }
    }

    public void setMeasureWithLargestChildEnabled(boolean z) {
        this.f4954h0 = z;
    }

    public void setOrientation(int i) {
        if (this.f4950d0 != i) {
            this.f4950d0 = i;
            requestLayout();
        }
    }

    public void setShowDividers(int i) {
        if (i != this.f4960n0) {
            requestLayout();
        }
        this.f4960n0 = i;
    }

    public void setVerticalGravity(int i) {
        int i2 = i & 112;
        int i3 = this.f4951e0;
        if ((i3 & 112) != i2) {
            this.f4951e0 = i2 | (i3 & -113);
            requestLayout();
        }
    }

    public void setWeightSum(float f) {
        this.f4953g0 = Math.max(0.0f, f);
    }

    public boolean shouldDelayChildPressedState() {
        return false;
    }
}
