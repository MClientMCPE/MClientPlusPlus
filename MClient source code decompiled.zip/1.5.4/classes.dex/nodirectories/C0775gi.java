package p000;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.Button;
import android.widget.FrameLayout;
import org.json.JSONException;
import org.json.JSONObject;

@SuppressLint({"AppCompatCustomView"})
/* renamed from: gi */
public class C0775gi extends Button {

    /* renamed from: a0 */
    public int f6142a0;

    /* renamed from: b0 */
    public int f6143b0;

    /* renamed from: c0 */
    public int f6144c0;

    /* renamed from: d0 */
    public int f6145d0;

    /* renamed from: e0 */
    public int f6146e0;

    /* renamed from: f0 */
    public int f6147f0;

    /* renamed from: g0 */
    public int f6148g0;

    /* renamed from: h0 */
    public int f6149h0;

    /* renamed from: i0 */
    public int f6150i0;

    /* renamed from: j0 */
    public int f6151j0;

    /* renamed from: k0 */
    public String f6152k0;

    /* renamed from: l0 */
    public String f6153l0;

    /* renamed from: m0 */
    public String f6154m0;

    /* renamed from: n0 */
    public String f6155n0;

    /* renamed from: o0 */
    public C1335mg f6156o0;

    /* renamed from: p0 */
    public C1249lg f6157p0;

    /* renamed from: gi$a */
    public class C0776a implements C1617pg {
        public C0776a() {
        }

        /* renamed from: a */
        public void mo532a(C1249lg lgVar) {
            if (C0775gi.this.mo6108c(lgVar)) {
                C0775gi.this.mo6106a(lgVar);
            }
        }
    }

    /* renamed from: gi$b */
    public class C0777b implements C1617pg {
        public C0777b() {
        }

        /* renamed from: a */
        public void mo532a(C1249lg lgVar) {
            if (C0775gi.this.mo6108c(lgVar)) {
                C0775gi.this.mo6116k(lgVar);
            }
        }
    }

    /* renamed from: gi$c */
    public class C0778c implements C1617pg {
        public C0778c() {
        }

        /* renamed from: a */
        public void mo532a(C1249lg lgVar) {
            if (C0775gi.this.mo6108c(lgVar)) {
                C0775gi.this.mo6110e(lgVar);
            }
        }
    }

    /* renamed from: gi$d */
    public class C0779d implements C1617pg {
        public C0779d() {
        }

        /* renamed from: a */
        public void mo532a(C1249lg lgVar) {
            if (C0775gi.this.mo6108c(lgVar)) {
                C0775gi.this.mo6111f(lgVar);
            }
        }
    }

    /* renamed from: gi$e */
    public class C0780e implements C1617pg {
        public C0780e() {
        }

        /* renamed from: a */
        public void mo532a(C1249lg lgVar) {
            if (C0775gi.this.mo6108c(lgVar)) {
                C0775gi.this.mo6109d(lgVar);
            }
        }
    }

    /* renamed from: gi$f */
    public class C0781f implements C1617pg {
        public C0781f() {
        }

        /* renamed from: a */
        public void mo532a(C1249lg lgVar) {
            if (C0775gi.this.mo6108c(lgVar)) {
                C0775gi.this.mo6115j(lgVar);
            }
        }
    }

    /* renamed from: gi$g */
    public class C0782g implements C1617pg {
        public C0782g() {
        }

        /* renamed from: a */
        public void mo532a(C1249lg lgVar) {
            if (C0775gi.this.mo6108c(lgVar)) {
                C0775gi.this.mo6112g(lgVar);
            }
        }
    }

    /* renamed from: gi$h */
    public class C0783h implements C1617pg {
        public C0783h() {
        }

        /* renamed from: a */
        public void mo532a(C1249lg lgVar) {
            if (C0775gi.this.mo6108c(lgVar)) {
                C0775gi.this.mo6113h(lgVar);
            }
        }
    }

    /* renamed from: gi$i */
    public class C0784i implements C1617pg {
        public C0784i() {
        }

        /* renamed from: a */
        public void mo532a(C1249lg lgVar) {
            if (C0775gi.this.mo6108c(lgVar)) {
                C0775gi.this.mo6107b(lgVar);
            }
        }
    }

    /* renamed from: gi$j */
    public class C0785j implements C1617pg {
        public C0785j() {
        }

        /* renamed from: a */
        public void mo532a(C1249lg lgVar) {
            if (C0775gi.this.mo6108c(lgVar)) {
                C0775gi.this.mo6114i(lgVar);
            }
        }
    }

    public C0775gi(Context context, int i, C1249lg lgVar, int i2, C1335mg mgVar) {
        super(context, (AttributeSet) null, i);
        this.f6142a0 = i2;
        this.f6157p0 = lgVar;
        this.f6156o0 = mgVar;
    }

    public C0775gi(Context context, C1249lg lgVar, int i, C1335mg mgVar) {
        super(context);
        this.f6142a0 = i;
        this.f6157p0 = lgVar;
        this.f6156o0 = mgVar;
    }

    /* renamed from: a */
    public int mo6104a(boolean z, int i) {
        if (i == 0) {
            return z ? 1 : 16;
        }
        if (i == 1) {
            return z ? 8388611 : 48;
        }
        if (i != 2) {
            return 17;
        }
        return z ? 8388613 : 80;
    }

    /* JADX WARNING: Removed duplicated region for block: B:23:0x0110  */
    /* JADX WARNING: Removed duplicated region for block: B:29:0x012f  */
    /* JADX WARNING: Removed duplicated region for block: B:32:0x014e  */
    /* JADX WARNING: Removed duplicated region for block: B:35:0x015f  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo6105a() {
        /*
            r11 = this;
            lg r0 = r11.f6157p0
            org.json.JSONObject r0 = r0.f9623b
            java.lang.String r1 = "ad_session_id"
            java.lang.String r1 = r0.optString(r1)
            r11.f6155n0 = r1
            java.lang.String r1 = "x"
            int r1 = r0.optInt(r1)
            r11.f6143b0 = r1
            java.lang.String r1 = "y"
            int r1 = r0.optInt(r1)
            r11.f6144c0 = r1
            java.lang.String r1 = "width"
            int r1 = r0.optInt(r1)
            r11.f6145d0 = r1
            java.lang.String r1 = "height"
            int r1 = r0.optInt(r1)
            r11.f6146e0 = r1
            java.lang.String r1 = "font_family"
            int r1 = r0.optInt(r1)
            r11.f6148g0 = r1
            java.lang.String r1 = "font_style"
            int r1 = r0.optInt(r1)
            r11.f6147f0 = r1
            java.lang.String r1 = "font_size"
            int r1 = r0.optInt(r1)
            r11.f6149h0 = r1
            java.lang.String r1 = "background_color"
            java.lang.String r1 = r0.optString(r1)
            r11.f6152k0 = r1
            java.lang.String r1 = "font_color"
            java.lang.String r1 = r0.optString(r1)
            r11.f6153l0 = r1
            java.lang.String r1 = "text"
            java.lang.String r1 = r0.optString(r1)
            r11.f6154m0 = r1
            java.lang.String r1 = "align_x"
            int r1 = r0.optInt(r1)
            r11.f6150i0 = r1
            java.lang.String r1 = "align_y"
            int r1 = r0.optInt(r1)
            r11.f6151j0 = r1
            vg r1 = p000.C0680fe.m4730a()
            java.lang.String r2 = r11.f6154m0
            java.lang.String r3 = ""
            boolean r2 = r2.equals(r3)
            if (r2 == 0) goto L_0x007e
            java.lang.String r2 = "Learn More"
            r11.f6154m0 = r2
        L_0x007e:
            r2 = 4
            r11.setVisibility(r2)
            java.lang.String r2 = "wrap_content"
            boolean r2 = r0.optBoolean(r2)
            if (r2 == 0) goto L_0x0091
            android.widget.FrameLayout$LayoutParams r2 = new android.widget.FrameLayout$LayoutParams
            r4 = -2
            r2.<init>(r4, r4)
            goto L_0x009a
        L_0x0091:
            android.widget.FrameLayout$LayoutParams r2 = new android.widget.FrameLayout$LayoutParams
            int r4 = r11.f6145d0
            int r5 = r11.f6146e0
            r2.<init>(r4, r5)
        L_0x009a:
            r4 = 0
            r2.gravity = r4
            java.lang.String r5 = r11.f6154m0
            r11.setText(r5)
            int r5 = r11.f6149h0
            float r5 = (float) r5
            r11.setTextSize(r5)
            java.lang.String r5 = "overlay"
            boolean r0 = r0.optBoolean(r5)
            if (r0 == 0) goto L_0x00e2
            r11.f6143b0 = r4
            r11.f6144c0 = r4
            kh r0 = r1.mo11966g()
            float r0 = r0.mo8006k()
            r5 = 1086324736(0x40c00000, float:6.0)
            float r0 = r0 * r5
            int r0 = (int) r0
            kh r6 = r1.mo11966g()
            float r6 = r6.mo8006k()
            float r6 = r6 * r5
            int r5 = (int) r6
            kh r1 = r1.mo11966g()
            float r1 = r1.mo8006k()
            r6 = 1082130432(0x40800000, float:4.0)
            float r1 = r1 * r6
            int r1 = (int) r1
            r11.setPadding(r1, r1, r1, r1)
            r1 = 8388693(0x800055, float:1.1755063E-38)
            r2.gravity = r1
            goto L_0x00e4
        L_0x00e2:
            r0 = 0
            r5 = 0
        L_0x00e4:
            int r1 = r11.f6143b0
            int r6 = r11.f6144c0
            r2.setMargins(r1, r6, r0, r5)
            mg r0 = r11.f6156o0
            r0.addView(r11, r2)
            int r0 = r11.f6148g0
            r1 = 3
            r2 = 2
            r5 = 1
            if (r0 == 0) goto L_0x0107
            if (r0 == r5) goto L_0x0104
            if (r0 == r2) goto L_0x0101
            if (r0 == r1) goto L_0x00fe
            goto L_0x010c
        L_0x00fe:
            android.graphics.Typeface r0 = android.graphics.Typeface.MONOSPACE
            goto L_0x0109
        L_0x0101:
            android.graphics.Typeface r0 = android.graphics.Typeface.SANS_SERIF
            goto L_0x0109
        L_0x0104:
            android.graphics.Typeface r0 = android.graphics.Typeface.SERIF
            goto L_0x0109
        L_0x0107:
            android.graphics.Typeface r0 = android.graphics.Typeface.DEFAULT
        L_0x0109:
            r11.setTypeface(r0)
        L_0x010c:
            int r0 = r11.f6147f0
            if (r0 == 0) goto L_0x012f
            if (r0 == r5) goto L_0x0127
            if (r0 == r2) goto L_0x011f
            if (r0 == r1) goto L_0x0117
            goto L_0x0136
        L_0x0117:
            android.graphics.Typeface r0 = r11.getTypeface()
            r11.setTypeface(r0, r1)
            goto L_0x0136
        L_0x011f:
            android.graphics.Typeface r0 = r11.getTypeface()
            r11.setTypeface(r0, r2)
            goto L_0x0136
        L_0x0127:
            android.graphics.Typeface r0 = r11.getTypeface()
            r11.setTypeface(r0, r5)
            goto L_0x0136
        L_0x012f:
            android.graphics.Typeface r0 = r11.getTypeface()
            r11.setTypeface(r0, r4)
        L_0x0136:
            int r0 = r11.f6150i0
            int r0 = r11.mo6104a(r5, r0)
            int r1 = r11.f6151j0
            int r1 = r11.mo6104a(r4, r1)
            r0 = r0 | r1
            r11.setGravity(r0)
            java.lang.String r0 = r11.f6152k0
            boolean r0 = r0.equals(r3)
            if (r0 != 0) goto L_0x0157
            java.lang.String r0 = r11.f6152k0
            int r0 = p000.C1062ji.m7738f(r0)
            r11.setBackgroundColor(r0)
        L_0x0157:
            java.lang.String r0 = r11.f6153l0
            boolean r0 = r0.equals(r3)
            if (r0 != 0) goto L_0x0168
            java.lang.String r0 = r11.f6153l0
            int r0 = p000.C1062ji.m7738f(r0)
            r11.setTextColor(r0)
        L_0x0168:
            mg r0 = r11.f6156o0
            java.util.ArrayList<pg> r0 = r0.f10229s0
            gi$b r1 = new gi$b
            r1.<init>()
            java.lang.String r2 = "TextView.set_visible"
            p000.C0680fe.m4727a((java.lang.String) r2, (p000.C1617pg) r1)
            r0.add(r1)
            mg r0 = r11.f6156o0
            java.util.ArrayList<pg> r0 = r0.f10229s0
            gi$c r1 = new gi$c
            r1.<init>()
            java.lang.String r3 = "TextView.set_bounds"
            p000.C0680fe.m4727a((java.lang.String) r3, (p000.C1617pg) r1)
            r0.add(r1)
            mg r0 = r11.f6156o0
            java.util.ArrayList<pg> r0 = r0.f10229s0
            gi$d r1 = new gi$d
            r1.<init>()
            java.lang.String r4 = "TextView.set_font_color"
            p000.C0680fe.m4727a((java.lang.String) r4, (p000.C1617pg) r1)
            r0.add(r1)
            mg r0 = r11.f6156o0
            java.util.ArrayList<pg> r0 = r0.f10229s0
            gi$e r1 = new gi$e
            r1.<init>()
            java.lang.String r5 = "TextView.set_background_color"
            p000.C0680fe.m4727a((java.lang.String) r5, (p000.C1617pg) r1)
            r0.add(r1)
            mg r0 = r11.f6156o0
            java.util.ArrayList<pg> r0 = r0.f10229s0
            gi$f r1 = new gi$f
            r1.<init>()
            java.lang.String r6 = "TextView.set_typeface"
            p000.C0680fe.m4727a((java.lang.String) r6, (p000.C1617pg) r1)
            r0.add(r1)
            mg r0 = r11.f6156o0
            java.util.ArrayList<pg> r0 = r0.f10229s0
            gi$g r1 = new gi$g
            r1.<init>()
            java.lang.String r7 = "TextView.set_font_size"
            p000.C0680fe.m4727a((java.lang.String) r7, (p000.C1617pg) r1)
            r0.add(r1)
            mg r0 = r11.f6156o0
            java.util.ArrayList<pg> r0 = r0.f10229s0
            gi$h r1 = new gi$h
            r1.<init>()
            java.lang.String r8 = "TextView.set_font_style"
            p000.C0680fe.m4727a((java.lang.String) r8, (p000.C1617pg) r1)
            r0.add(r1)
            mg r0 = r11.f6156o0
            java.util.ArrayList<pg> r0 = r0.f10229s0
            gi$i r1 = new gi$i
            r1.<init>()
            java.lang.String r9 = "TextView.get_text"
            p000.C0680fe.m4727a((java.lang.String) r9, (p000.C1617pg) r1)
            r0.add(r1)
            mg r0 = r11.f6156o0
            java.util.ArrayList<pg> r0 = r0.f10229s0
            gi$j r1 = new gi$j
            r1.<init>()
            java.lang.String r10 = "TextView.set_text"
            p000.C0680fe.m4727a((java.lang.String) r10, (p000.C1617pg) r1)
            r0.add(r1)
            mg r0 = r11.f6156o0
            java.util.ArrayList<pg> r0 = r0.f10229s0
            gi$a r1 = new gi$a
            r1.<init>()
            java.lang.String r10 = "TextView.align"
            p000.C0680fe.m4727a((java.lang.String) r10, (p000.C1617pg) r1)
            r0.add(r1)
            mg r0 = r11.f6156o0
            java.util.ArrayList<java.lang.String> r0 = r0.f10230t0
            r0.add(r2)
            mg r0 = r11.f6156o0
            java.util.ArrayList<java.lang.String> r0 = r0.f10230t0
            r0.add(r3)
            mg r0 = r11.f6156o0
            java.util.ArrayList<java.lang.String> r0 = r0.f10230t0
            r0.add(r4)
            mg r0 = r11.f6156o0
            java.util.ArrayList<java.lang.String> r0 = r0.f10230t0
            r0.add(r5)
            mg r0 = r11.f6156o0
            java.util.ArrayList<java.lang.String> r0 = r0.f10230t0
            r0.add(r6)
            mg r0 = r11.f6156o0
            java.util.ArrayList<java.lang.String> r0 = r0.f10230t0
            r0.add(r7)
            mg r0 = r11.f6156o0
            java.util.ArrayList<java.lang.String> r0 = r0.f10230t0
            r0.add(r8)
            mg r0 = r11.f6156o0
            java.util.ArrayList<java.lang.String> r0 = r0.f10230t0
            r0.add(r9)
            mg r0 = r11.f6156o0
            java.util.ArrayList<java.lang.String> r0 = r0.f10230t0
            java.lang.String r1 = "TextView.set_text"
            r0.add(r1)
            mg r0 = r11.f6156o0
            java.util.ArrayList<java.lang.String> r0 = r0.f10230t0
            java.lang.String r1 = "TextView.align"
            r0.add(r1)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0775gi.mo6105a():void");
    }

    /* renamed from: b */
    public void mo6107b(C1249lg lgVar) {
        JSONObject jSONObject = new JSONObject();
        C0680fe.m4785a(jSONObject, "text", getText().toString());
        lgVar.mo8413a(jSONObject).mo8414a();
    }

    /* renamed from: c */
    public boolean mo6108c(C1249lg lgVar) {
        JSONObject jSONObject = lgVar.f9623b;
        return jSONObject.optInt("id") == this.f6142a0 && jSONObject.optInt("container_id") == this.f6156o0.f10220j0 && jSONObject.optString("ad_session_id").equals(this.f6156o0.f10222l0);
    }

    /* renamed from: d */
    public void mo6109d(C1249lg lgVar) {
        String optString = lgVar.f9623b.optString("background_color");
        this.f6152k0 = optString;
        setBackgroundColor(C1062ji.m7738f(optString));
    }

    /* renamed from: e */
    public void mo6110e(C1249lg lgVar) {
        JSONObject jSONObject = lgVar.f9623b;
        this.f6143b0 = jSONObject.optInt("x");
        this.f6144c0 = jSONObject.optInt("y");
        this.f6145d0 = jSONObject.optInt("width");
        this.f6146e0 = jSONObject.optInt("height");
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) getLayoutParams();
        layoutParams.setMargins(this.f6143b0, this.f6144c0, 0, 0);
        layoutParams.width = this.f6145d0;
        layoutParams.height = this.f6146e0;
        setLayoutParams(layoutParams);
    }

    /* renamed from: f */
    public void mo6111f(C1249lg lgVar) {
        String optString = lgVar.f9623b.optString("font_color");
        this.f6153l0 = optString;
        setTextColor(C1062ji.m7738f(optString));
    }

    /* renamed from: g */
    public void mo6112g(C1249lg lgVar) {
        int optInt = lgVar.f9623b.optInt("font_size");
        this.f6149h0 = optInt;
        setTextSize((float) optInt);
    }

    /* renamed from: h */
    public void mo6113h(C1249lg lgVar) {
        Typeface typeface;
        int i;
        int optInt = lgVar.f9623b.optInt("font_style");
        this.f6147f0 = optInt;
        if (optInt != 0) {
            i = 1;
            if (optInt != 1) {
                i = 2;
                if (optInt != 2) {
                    i = 3;
                    if (optInt != 3) {
                        return;
                    }
                }
            }
            typeface = getTypeface();
        } else {
            typeface = getTypeface();
            i = 0;
        }
        setTypeface(typeface, i);
    }

    /* renamed from: i */
    public void mo6114i(C1249lg lgVar) {
        String optString = lgVar.f9623b.optString("text");
        this.f6154m0 = optString;
        setText(optString);
    }

    /* renamed from: j */
    public void mo6115j(C1249lg lgVar) {
        Typeface typeface;
        int optInt = lgVar.f9623b.optInt("font_family");
        this.f6148g0 = optInt;
        if (optInt == 0) {
            typeface = Typeface.DEFAULT;
        } else if (optInt == 1) {
            typeface = Typeface.SERIF;
        } else if (optInt == 2) {
            typeface = Typeface.SANS_SERIF;
        } else if (optInt == 3) {
            typeface = Typeface.MONOSPACE;
        } else {
            return;
        }
        setTypeface(typeface);
    }

    /* renamed from: k */
    public void mo6116k(C1249lg lgVar) {
        setVisibility(lgVar.f9623b.optBoolean("visible") ? 0 : 4);
    }

    @SuppressLint({"ClickableViewAccessibility"})
    public boolean onTouchEvent(MotionEvent motionEvent) {
        String str;
        String str2;
        String str3;
        String str4;
        String str5;
        MotionEvent motionEvent2 = motionEvent;
        C2120vg a = C0680fe.m4730a();
        C1422ng f = a.mo11965f();
        int action = motionEvent.getAction() & 255;
        if (action != 0 && action != 1 && action != 3 && action != 2 && action != 5 && action != 6) {
            return false;
        }
        int x = (int) motionEvent.getX();
        int y = (int) motionEvent.getY();
        JSONObject jSONObject = new JSONObject();
        C0680fe.m4784a(jSONObject, "view_id", this.f6142a0);
        C0680fe.m4785a(jSONObject, "ad_session_id", this.f6155n0);
        C0680fe.m4784a(jSONObject, "container_x", this.f6143b0 + x);
        C0680fe.m4784a(jSONObject, "container_y", this.f6144c0 + y);
        C0680fe.m4784a(jSONObject, "view_x", x);
        C0680fe.m4784a(jSONObject, "view_y", y);
        C0680fe.m4784a(jSONObject, "id", this.f6156o0.getId());
        String str6 = "AdContainer.on_touch_began";
        if (action != 0) {
            String str7 = "AdContainer.on_touch_cancelled";
            if (action == 1) {
                str4 = "m_type";
                if (!this.f6156o0.f10231u0) {
                    a.f16048m = f.f11074d.get(this.f6155n0);
                }
                if (x <= 0 || x >= getWidth() || y <= 0 || y >= getHeight()) {
                    str2 = str4;
                    try {
                        jSONObject.put("m_target", this.f6156o0.f10221k0);
                    } catch (JSONException e) {
                        JSONException jSONException = e;
                        StringBuilder a2 = C0789gk.m5562a("JSON Error in ADCMessage constructor: ");
                        a2.append(jSONException.toString());
                        C0869hj.f6827i.mo6566a(a2.toString());
                    }
                    if (jSONObject == null) {
                        jSONObject = new JSONObject();
                    }
                    str = str7;
                    C0680fe.m4785a(jSONObject, str2, str);
                    C0680fe.m4730a().mo11970k().mo9679a(jSONObject);
                    return true;
                }
                try {
                    jSONObject.put("m_target", this.f6156o0.f10221k0);
                } catch (JSONException e2) {
                    JSONException jSONException2 = e2;
                    StringBuilder a3 = C0789gk.m5562a("JSON Error in ADCMessage constructor: ");
                    a3.append(jSONException2.toString());
                    C0869hj.f6827i.mo6566a(a3.toString());
                }
                if (jSONObject == null) {
                    jSONObject = new JSONObject();
                }
                str5 = "AdContainer.on_touch_ended";
            } else if (action != 2) {
                if (action == 3) {
                    str4 = "m_type";
                    try {
                        jSONObject.put("m_target", this.f6156o0.f10221k0);
                    } catch (JSONException e3) {
                        JSONException jSONException3 = e3;
                        StringBuilder a4 = C0789gk.m5562a("JSON Error in ADCMessage constructor: ");
                        a4.append(jSONException3.toString());
                        C0869hj.f6827i.mo6566a(a4.toString());
                    }
                    if (jSONObject == null) {
                        jSONObject = new JSONObject();
                        str = str7;
                    } else {
                        str2 = str4;
                        str = str7;
                        C0680fe.m4785a(jSONObject, str2, str);
                        C0680fe.m4730a().mo11970k().mo9679a(jSONObject);
                        return true;
                    }
                } else if (action == 5) {
                    str4 = "m_type";
                    int action2 = (motionEvent.getAction() & 65280) >> 8;
                    C0680fe.m4784a(jSONObject, "container_x", ((int) motionEvent2.getX(action2)) + this.f6143b0);
                    C0680fe.m4784a(jSONObject, "container_y", ((int) motionEvent2.getY(action2)) + this.f6144c0);
                    C0680fe.m4784a(jSONObject, "view_x", (int) motionEvent2.getX(action2));
                    C0680fe.m4784a(jSONObject, "view_y", (int) motionEvent2.getY(action2));
                    try {
                        jSONObject.put("m_target", this.f6156o0.f10221k0);
                    } catch (JSONException e4) {
                        JSONException jSONException4 = e4;
                        StringBuilder a5 = C0789gk.m5562a("JSON Error in ADCMessage constructor: ");
                        a5.append(jSONException4.toString());
                        C0869hj.f6827i.mo6566a(a5.toString());
                    }
                    if (jSONObject == null) {
                        jSONObject = new JSONObject();
                        str = str6;
                    } else {
                        str3 = str4;
                    }
                } else if (action != 6) {
                    return true;
                } else {
                    int action3 = (motionEvent.getAction() & 65280) >> 8;
                    int x2 = (int) motionEvent2.getX(action3);
                    int y2 = (int) motionEvent2.getY(action3);
                    str4 = "m_type";
                    C0680fe.m4784a(jSONObject, "container_x", ((int) motionEvent2.getX(action3)) + this.f6143b0);
                    C0680fe.m4784a(jSONObject, "container_y", ((int) motionEvent2.getY(action3)) + this.f6144c0);
                    C0680fe.m4784a(jSONObject, "view_x", (int) motionEvent2.getX(action3));
                    C0680fe.m4784a(jSONObject, "view_y", (int) motionEvent2.getY(action3));
                    if (!this.f6156o0.f10231u0) {
                        a.f16048m = f.f11074d.get(this.f6155n0);
                    }
                    if (x2 <= 0 || x2 >= getWidth() || y2 <= 0 || y2 >= getHeight()) {
                        try {
                            jSONObject.put("m_target", this.f6156o0.f10221k0);
                        } catch (JSONException e5) {
                            JSONException jSONException5 = e5;
                            StringBuilder a6 = C0789gk.m5562a("JSON Error in ADCMessage constructor: ");
                            a6.append(jSONException5.toString());
                            C0869hj.f6827i.mo6566a(a6.toString());
                        }
                        if (jSONObject == null) {
                            jSONObject = new JSONObject();
                        }
                        str = str7;
                    } else {
                        try {
                            jSONObject.put("m_target", this.f6156o0.f10221k0);
                        } catch (JSONException e6) {
                            JSONException jSONException6 = e6;
                            StringBuilder a7 = C0789gk.m5562a("JSON Error in ADCMessage constructor: ");
                            a7.append(jSONException6.toString());
                            C0869hj.f6827i.mo6566a(a7.toString());
                        }
                        if (jSONObject == null) {
                            jSONObject = new JSONObject();
                        }
                        str5 = "AdContainer.on_touch_ended";
                    }
                }
                str2 = str4;
                C0680fe.m4785a(jSONObject, str2, str);
                C0680fe.m4730a().mo11970k().mo9679a(jSONObject);
                return true;
            } else {
                str4 = "m_type";
                try {
                    jSONObject.put("m_target", this.f6156o0.f10221k0);
                } catch (JSONException e7) {
                    JSONException jSONException7 = e7;
                    StringBuilder a8 = C0789gk.m5562a("JSON Error in ADCMessage constructor: ");
                    a8.append(jSONException7.toString());
                    C0869hj.f6827i.mo6566a(a8.toString());
                }
                if (jSONObject == null) {
                    jSONObject = new JSONObject();
                }
                str5 = "AdContainer.on_touch_moved";
            }
            C0680fe.m4785a(jSONObject, str4, str5);
            C0680fe.m4730a().mo11970k().mo9679a(jSONObject);
            return true;
        }
        str3 = "m_type";
        try {
            jSONObject.put("m_target", this.f6156o0.f10221k0);
        } catch (JSONException e8) {
            JSONException jSONException8 = e8;
            StringBuilder a9 = C0789gk.m5562a("JSON Error in ADCMessage constructor: ");
            a9.append(jSONException8.toString());
            C0869hj.f6827i.mo6566a(a9.toString());
        }
        if (jSONObject == null) {
            jSONObject = new JSONObject();
        }
        str = str6;
        C0680fe.m4785a(jSONObject, str2, str);
        C0680fe.m4730a().mo11970k().mo9679a(jSONObject);
        return true;
    }

    /* renamed from: a */
    public void mo6106a(C1249lg lgVar) {
        JSONObject jSONObject = lgVar.f9623b;
        this.f6150i0 = jSONObject.optInt("x");
        this.f6151j0 = jSONObject.optInt("y");
        setGravity(mo6104a(true, this.f6150i0) | mo6104a(false, this.f6151j0));
    }
}
