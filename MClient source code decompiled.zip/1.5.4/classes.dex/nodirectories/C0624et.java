package p000;

import android.content.Context;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.HandlerThread;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.concurrent.LinkedBlockingQueue;
import p000.C1173kq;

/* renamed from: et */
public final class C0624et implements C1173kq.C1174a, C1173kq.C1175b {

    /* renamed from: a */
    public C1637ps f4806a;

    /* renamed from: b */
    public final String f4807b;

    /* renamed from: c */
    public final String f4808c;

    /* renamed from: d */
    public final int f4809d = 1;

    /* renamed from: e */
    public final LinkedBlockingQueue<C2468zs> f4810e;

    /* renamed from: f */
    public final HandlerThread f4811f;

    /* renamed from: g */
    public final C0965is f4812g;

    /* renamed from: h */
    public final long f4813h;

    public C0624et(Context context, String str, String str2, C0965is isVar) {
        this.f4807b = str;
        this.f4808c = str2;
        this.f4812g = isVar;
        this.f4811f = new HandlerThread("GassDGClient");
        this.f4811f.start();
        this.f4813h = System.currentTimeMillis();
        this.f4806a = new C1637ps(context, this.f4811f.getLooper(), this, this);
        this.f4810e = new LinkedBlockingQueue<>();
        this.f4806a.mo8069a();
    }

    /* renamed from: b */
    public static C2468zs m4290b() {
        return new C2468zs(1, (byte[]) null);
    }

    /* renamed from: a */
    public final void mo5241a() {
        C1637ps psVar = this.f4806a;
        if (psVar == null) {
            return;
        }
        if (psVar.mo8081i() || this.f4806a.mo8082j()) {
            this.f4806a.mo8076b();
        }
    }

    /* renamed from: a */
    public final void mo4473a(int i) {
        try {
            this.f4810e.put(m4290b());
        } catch (InterruptedException unused) {
        }
    }

    /* renamed from: a */
    public final void mo5242a(int i, long j, Exception exc) {
        C0965is isVar = this.f4812g;
        if (isVar != null) {
            isVar.mo7255a(i, System.currentTimeMillis() - j, exc);
        }
    }

    /* renamed from: a */
    public final void mo395a(Bundle bundle) {
        C1876ss ssVar;
        try {
            ssVar = this.f4806a.mo10109m();
        } catch (DeadObjectException | IllegalStateException unused) {
            ssVar = null;
        }
        if (ssVar != null) {
            try {
                C2299xs xsVar = new C2299xs(1, this.f4809d, this.f4807b, this.f4808c);
                C2068us usVar = (C2068us) ssVar;
                Parcel a = usVar.mo10675a();
                sj2.m12849a(a, (Parcelable) xsVar);
                Parcel a2 = usVar.mo10676a(3, a);
                a2.recycle();
                this.f4810e.put((C2468zs) sj2.m12847a(a2, C2468zs.CREATOR));
            } catch (Throwable th) {
                mo5241a();
                this.f4811f.quit();
                throw th;
            }
            mo5241a();
            this.f4811f.quit();
        }
    }

    /* renamed from: a */
    public final void mo396a(C2230wp wpVar) {
        try {
            this.f4810e.put(m4290b());
        } catch (InterruptedException unused) {
        }
    }
}
