package p000;

import android.view.View;

/* renamed from: dd */
public class C0531dd {

    /* renamed from: a */
    public final C0533b f3813a;

    /* renamed from: b */
    public C0532a f3814b = new C0532a();

    /* renamed from: dd$a */
    public static class C0532a {

        /* renamed from: a */
        public int f3815a = 0;

        /* renamed from: b */
        public int f3816b;

        /* renamed from: c */
        public int f3817c;

        /* renamed from: d */
        public int f3818d;

        /* renamed from: e */
        public int f3819e;

        /* renamed from: a */
        public int mo4741a(int i, int i2) {
            if (i > i2) {
                return 1;
            }
            return i == i2 ? 2 : 4;
        }

        /* renamed from: a */
        public boolean mo4742a() {
            int i = this.f3815a;
            if ((i & 7) != 0 && (i & (mo4741a(this.f3818d, this.f3816b) << 0)) == 0) {
                return false;
            }
            int i2 = this.f3815a;
            if ((i2 & 112) != 0 && (i2 & (mo4741a(this.f3818d, this.f3817c) << 4)) == 0) {
                return false;
            }
            int i3 = this.f3815a;
            if ((i3 & 1792) != 0 && (i3 & (mo4741a(this.f3819e, this.f3816b) << 8)) == 0) {
                return false;
            }
            int i4 = this.f3815a;
            return (i4 & 28672) == 0 || (i4 & (mo4741a(this.f3819e, this.f3817c) << 12)) != 0;
        }
    }

    /* renamed from: dd$b */
    public interface C0533b {
        /* renamed from: a */
        int mo1965a();

        /* renamed from: a */
        int mo1966a(View view);

        /* renamed from: a */
        View mo1967a(int i);

        /* renamed from: b */
        int mo1968b();

        /* renamed from: b */
        int mo1969b(View view);
    }

    public C0531dd(C0533b bVar) {
        this.f3813a = bVar;
    }

    /* renamed from: a */
    public View mo4739a(int i, int i2, int i3, int i4) {
        int b = this.f3813a.mo1968b();
        int a = this.f3813a.mo1965a();
        int i5 = i2 > i ? 1 : -1;
        View view = null;
        while (i != i2) {
            View a2 = this.f3813a.mo1967a(i);
            int a3 = this.f3813a.mo1966a(a2);
            int b2 = this.f3813a.mo1969b(a2);
            C0532a aVar = this.f3814b;
            aVar.f3816b = b;
            aVar.f3817c = a;
            aVar.f3818d = a3;
            aVar.f3819e = b2;
            if (i3 != 0) {
                aVar.f3815a = 0;
                aVar.f3815a |= i3;
                if (aVar.mo4742a()) {
                    return a2;
                }
            }
            if (i4 != 0) {
                C0532a aVar2 = this.f3814b;
                aVar2.f3815a = 0;
                aVar2.f3815a |= i4;
                if (aVar2.mo4742a()) {
                    view = a2;
                }
            }
            i += i5;
        }
        return view;
    }

    /* renamed from: a */
    public boolean mo4740a(View view, int i) {
        C0532a aVar = this.f3814b;
        int b = this.f3813a.mo1968b();
        int a = this.f3813a.mo1965a();
        int a2 = this.f3813a.mo1966a(view);
        int b2 = this.f3813a.mo1969b(view);
        aVar.f3816b = b;
        aVar.f3817c = a;
        aVar.f3818d = a2;
        aVar.f3819e = b2;
        if (i == 0) {
            return false;
        }
        C0532a aVar2 = this.f3814b;
        aVar2.f3815a = 0;
        aVar2.f3815a |= i;
        return aVar2.mo4742a();
    }
}
