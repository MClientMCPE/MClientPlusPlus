package p000;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;

/* renamed from: fs */
public final class C0718fs extends v03 implements C0623es {
    public C0718fs(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.dynamite.IDynamiteLoader");
    }

    /* renamed from: a */
    public final C2232wr mo5769a(C2232wr wrVar, String str, int i) {
        Parcel a = mo11787a();
        x03.m15445a(a, (IInterface) wrVar);
        a.writeString(str);
        a.writeInt(i);
        return C0789gk.m5564a(mo11788a(2, a));
    }

    /* renamed from: b */
    public final C2232wr mo5770b(C2232wr wrVar, String str, int i) {
        Parcel a = mo11787a();
        x03.m15445a(a, (IInterface) wrVar);
        a.writeString(str);
        a.writeInt(i);
        return C0789gk.m5564a(mo11788a(4, a));
    }
}
