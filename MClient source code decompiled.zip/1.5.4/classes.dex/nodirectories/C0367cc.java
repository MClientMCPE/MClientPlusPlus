package p000;

import java.io.FileDescriptor;
import java.io.PrintWriter;

/* renamed from: cc */
public abstract class C0367cc {
    /* renamed from: a */
    public static <T extends C1509ob & C0296bc> C0367cc m2419a(T t) {
        return new C0527dc(t, ((C0296bc) t).mo638d());
    }

    @Deprecated
    /* renamed from: a */
    public abstract void mo2889a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);
}
