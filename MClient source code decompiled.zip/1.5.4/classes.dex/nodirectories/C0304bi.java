package p000;

/* renamed from: bi */
public class C0304bi implements C1617pg {

    /* renamed from: a */
    public final /* synthetic */ C0868hi f1967a;

    public C0304bi(C0868hi hiVar) {
        this.f1967a = hiVar;
    }

    /* renamed from: a */
    public void mo532a(C1249lg lgVar) {
        if (this.f1967a.mo6550c(lgVar)) {
            this.f1967a.mo6557j(lgVar);
        }
    }
}
