package p000;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import p000.C1919tg;

/* renamed from: dh */
public class C0542dh {

    /* renamed from: a */
    public final SQLiteDatabase f3851a;

    /* renamed from: b */
    public final C1919tg f3852b;

    /* renamed from: dh$a */
    public static class C0543a {

        /* renamed from: a */
        public final String f3853a;

        /* renamed from: b */
        public final String f3854b;

        /* renamed from: c */
        public final String f3855c;

        public C0543a(String[] strArr) {
            this.f3853a = strArr[1];
            this.f3854b = strArr[2];
            this.f3855c = strArr[4];
        }
    }

    public C0542dh(SQLiteDatabase sQLiteDatabase, C1919tg tgVar) {
        this.f3851a = sQLiteDatabase;
        this.f3852b = tgVar;
    }

    /* JADX WARNING: Removed duplicated region for block: B:8:0x0045  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public java.util.ArrayList<java.lang.String> mo4785a() {
        /*
            r4 = this;
            android.database.sqlite.SQLiteDatabase r0 = r4.f3851a
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "SELECT name FROM sqlite_master  WHERE type='"
            r1.append(r2)
            java.lang.String r2 = "table"
            r1.append(r2)
            java.lang.String r2 = "' ORDER BY name"
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r2 = 0
            android.database.Cursor r0 = r0.rawQuery(r1, r2)
            java.util.ArrayList r1 = new java.util.ArrayList
            r1.<init>()
            if (r0 == 0) goto L_0x003a
            boolean r2 = r0.moveToFirst()
            if (r2 == 0) goto L_0x003a
        L_0x002c:
            r2 = 0
            java.lang.String r2 = r0.getString(r2)
            r1.add(r2)
            boolean r2 = r0.moveToNext()
            if (r2 != 0) goto L_0x002c
        L_0x003a:
            r0.close()
            int r0 = r1.size()
            int r0 = r0 + -1
        L_0x0043:
            if (r0 < 0) goto L_0x0061
            java.lang.Object r2 = r1.get(r0)
            java.lang.String r2 = (java.lang.String) r2
            java.lang.String r3 = "android_"
            boolean r3 = r2.startsWith(r3)
            if (r3 != 0) goto L_0x005b
            java.lang.String r3 = "sqlite_"
            boolean r2 = r2.startsWith(r3)
            if (r2 == 0) goto L_0x005e
        L_0x005b:
            r1.remove(r0)
        L_0x005e:
            int r0 = r0 + -1
            goto L_0x0043
        L_0x0061:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: p000.C0542dh.mo4785a():java.util.ArrayList");
    }

    /* renamed from: a */
    public final void mo4786a(String str) {
        SQLiteDatabase sQLiteDatabase = this.f3851a;
        sQLiteDatabase.execSQL("DROP INDEX " + str);
    }

    /* renamed from: b */
    public final void mo4789b(String str) {
        SQLiteDatabase sQLiteDatabase = this.f3851a;
        sQLiteDatabase.execSQL("DROP TABLE " + str);
    }

    /* renamed from: b */
    public final void mo4790b(C1919tg.C1920a aVar) {
        String str;
        StringBuilder a = C0789gk.m5562a("CREATE TABLE ");
        a.append(aVar.f14901b);
        a.append(" (");
        for (int i = 0; i < aVar.f14905f.size(); i++) {
            C1919tg.C1921b bVar = aVar.f14905f.get(i);
            a.append(bVar.f14909a);
            a.append(" ");
            a.append(bVar.f14910b);
            Object obj = bVar.f14911c;
            if (obj != null) {
                if (obj instanceof Boolean) {
                    str = ((Boolean) obj).booleanValue() ? "1" : "0";
                } else if (obj instanceof String) {
                    StringBuilder a2 = C0789gk.m5562a("'");
                    a2.append(bVar.f14911c);
                    a2.append("'");
                    str = a2.toString();
                } else {
                    str = obj.toString();
                }
                a.append(" DEFAULT ");
                a.append(str);
            }
            if (i < aVar.f14905f.size() - 1) {
                a.append(", ");
            }
        }
        a.append(")");
        this.f3851a.execSQL(a.toString());
    }

    /* renamed from: c */
    public ArrayList<String[]> mo4791c(String str) {
        Cursor rawQuery = this.f3851a.rawQuery(str, (String[]) null);
        ArrayList<String[]> arrayList = new ArrayList<>();
        if (rawQuery == null || !rawQuery.moveToFirst()) {
            rawQuery.close();
            return arrayList;
        }
        do {
            int columnCount = rawQuery.getColumnCount();
            String[] strArr = new String[columnCount];
            for (int i = 0; i < columnCount; i++) {
                strArr[i] = rawQuery.getString(i);
            }
            arrayList.add(strArr);
        } while (rawQuery.moveToNext());
        rawQuery.close();
        return arrayList;
    }

    /* renamed from: c */
    public final void mo4792c(C1919tg.C1920a aVar) {
        boolean z;
        boolean z2;
        boolean z3;
        String str = aVar.f14901b;
        ArrayList arrayList = new ArrayList();
        Iterator<String[]> it = mo4791c("PRAGMA table_info(" + str + ")").iterator();
        while (it.hasNext()) {
            String[] next = it.next();
            C0543a aVar2 = next.length >= 5 ? new C0543a(next) : null;
            if (aVar2 != null) {
                arrayList.add(aVar2);
            }
        }
        ArrayList arrayList2 = new ArrayList();
        boolean z4 = false;
        for (C1919tg.C1921b next2 : aVar.f14905f) {
            int size = arrayList.size() - 1;
            while (true) {
                if (size < 0) {
                    z2 = false;
                    z3 = false;
                    break;
                }
                C0543a aVar3 = (C0543a) arrayList.get(size);
                if (C0680fe.m4835c((Object) aVar3.f3853a, (Object) next2.f14909a)) {
                    arrayList2.add(next2.f14909a);
                    boolean z5 = C0680fe.m4835c((Object) aVar3.f3853a, (Object) next2.f14909a) && C0680fe.m4835c((Object) aVar3.f3854b, (Object) next2.f14910b) && C0680fe.m4835c((Object) aVar3.f3855c, next2.f14911c);
                    arrayList.remove(size);
                    z3 = z5;
                    z2 = true;
                } else {
                    size--;
                }
            }
            if (!z2 || !z3) {
                z4 = true;
            }
        }
        if (arrayList.size() > 0) {
            z4 = true;
        }
        if (z4) {
            String str2 = aVar.f14901b;
            this.f3851a.execSQL("ALTER TABLE " + str2 + " RENAME TO " + "manager_tmp_table");
            mo4790b(aVar);
            String str3 = aVar.f14901b;
            String join = TextUtils.join(", ", arrayList2);
            this.f3851a.execSQL("INSERT INTO " + str3 + " (" + join + ") SELECT " + join + " FROM " + "manager_tmp_table");
            mo4789b("manager_tmp_table");
            mo4787a(aVar);
            return;
        }
        List<C1919tg.C1922c> a = aVar.mo11293a();
        ArrayList<String[]> c = mo4791c("PRAGMA index_list(" + aVar.f14901b + ")");
        ArrayList arrayList3 = new ArrayList();
        Iterator<String[]> it2 = c.iterator();
        while (it2.hasNext()) {
            String[] next3 = it2.next();
            if (next3.length >= 3) {
                arrayList3.add(next3[1]);
            }
        }
        for (C1919tg.C1922c next4 : a) {
            if (arrayList3.contains(next4.f14912a)) {
                String str4 = aVar.f14901b;
                ArrayList<String[]> c2 = mo4791c("PRAGMA index_info(" + next4.f14912a + ")");
                if (next4.f14913b.length == c2.size()) {
                    int i = 0;
                    z = false;
                    while (true) {
                        String[] strArr = next4.f14913b;
                        if (i >= strArr.length) {
                            break;
                        }
                        if (!C0680fe.m4835c((Object) strArr[i], (Object) c2.get(i)[2])) {
                            z = true;
                        }
                        i++;
                    }
                } else {
                    z = true;
                }
                if (z) {
                    mo4786a(next4.f14912a);
                    mo4788a(next4, str4);
                }
            } else {
                mo4788a(next4, aVar.f14901b);
            }
            arrayList3.remove(next4.f14912a);
        }
        Iterator it3 = arrayList3.iterator();
        while (it3.hasNext()) {
            mo4786a((String) it3.next());
        }
    }

    /* renamed from: a */
    public final void mo4787a(C1919tg.C1920a aVar) {
        for (C1919tg.C1922c a : aVar.f14906g) {
            mo4788a(a, aVar.f14901b);
        }
    }

    /* renamed from: a */
    public final void mo4788a(C1919tg.C1922c cVar, String str) {
        String join = TextUtils.join(", ", cVar.f14913b);
        StringBuilder a = C0789gk.m5562a("CREATE INDEX ");
        a.append(cVar.f14912a);
        a.append(" ON ");
        a.append(str);
        a.append("(");
        this.f3851a.execSQL(C0789gk.m5559a(a, join, ")"));
    }
}
