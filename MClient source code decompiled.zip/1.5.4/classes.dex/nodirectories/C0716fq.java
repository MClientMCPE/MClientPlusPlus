package p000;

/* renamed from: fq */
public class C0716fq {
}
