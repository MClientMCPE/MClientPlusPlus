package p000;

import org.json.JSONObject;

/* renamed from: ah */
public class C0106ah implements C1617pg {

    /* renamed from: ah$a */
    public class C0107a implements Runnable {

        /* renamed from: X */
        public final /* synthetic */ String f472X;

        /* renamed from: Y */
        public final /* synthetic */ String f473Y;

        public C0107a(C0106ah ahVar, String str, String str2) {
            this.f472X = str;
            this.f473Y = str2;
        }

        public void run() {
            try {
                C1616pf pfVar = C0680fe.m4730a().f16051p.get(this.f472X);
                if (pfVar != null) {
                    ((C0373ch) pfVar).mo2933a(new C1527of(this.f472X, this.f473Y));
                }
            } catch (RuntimeException unused) {
            }
        }
    }

    public C0106ah() {
        C0680fe.m4727a("CustomMessage.controller_send", (C1617pg) this);
    }

    /* renamed from: a */
    public void mo532a(C1249lg lgVar) {
        JSONObject jSONObject = lgVar.f9623b;
        C1062ji.m7720a((Runnable) new C0107a(this, jSONObject.optString("type"), jSONObject.optString("message")));
    }
}
