package com.microsoft.xal.androidjava;

public class PresenceManager {
    public static void attach() {
    }

    public static native void pausePresence();

    public static native void resumePresence();
}
