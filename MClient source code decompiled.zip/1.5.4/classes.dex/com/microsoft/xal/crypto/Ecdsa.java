package com.microsoft.xal.crypto;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.Security;
import java.security.Signature;
import java.security.interfaces.ECPrivateKey;
import java.security.interfaces.ECPublicKey;
import java.security.spec.ECGenParameterSpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

public final class Ecdsa {
    public static final String PREF_FILE_NAME = "xbox_live_ecdsa";
    public static final String PREF_PRIVATE_KEY = "private_key";
    public static final String PREF_PUBLIC_KEY = "public_key";
    public static final String PREF_UNIQUE_ID = "unique_id";
    public KeyPair keyPair;
    public String uniqueId;

    static {
        Security.addProvider(new hb4());
    }

    public Ecdsa() {
    }

    public Ecdsa(String str, KeyPair keyPair2) {
        this.uniqueId = str;
        this.keyPair = keyPair2;
    }

    public static byte[] derToP1363(byte[] bArr) {
        int i = (bArr[1] & 128) != 0 ? 3 : 2;
        byte b = bArr[i + 1];
        int i2 = i + 2 + b;
        byte b2 = bArr[i2 + 1];
        int min = Math.min(b, 32);
        int min2 = Math.min(b2, 32);
        byte[] bArr2 = new byte[(min + min2)];
        System.arraycopy(bArr, i2 - min, bArr2, 0, min);
        System.arraycopy(bArr, ((i2 + 2) + b2) - min2, bArr2, min, min2);
        return bArr2;
    }

    public static Ecdsa restoreKeyAndId(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREF_FILE_NAME, 0);
        if (sharedPreferences.contains(PREF_UNIQUE_ID) && sharedPreferences.contains(PREF_PRIVATE_KEY) && sharedPreferences.contains(PREF_PUBLIC_KEY)) {
            try {
                String string = sharedPreferences.getString(PREF_UNIQUE_ID, (String) null);
                byte[] decode = Base64.decode(sharedPreferences.getString(PREF_PRIVATE_KEY, (String) null), 0);
                byte[] decode2 = Base64.decode(sharedPreferences.getString(PREF_PUBLIC_KEY, (String) null), 0);
                KeyFactory instance = KeyFactory.getInstance("ECDSA", "SC");
                KeyPair keyPair2 = new KeyPair(instance.generatePublic(new X509EncodedKeySpec(decode2)), instance.generatePrivate(new PKCS8EncodedKeySpec(decode)));
                if ((keyPair2.getPrivate() instanceof ECPrivateKey) && (keyPair2.getPublic() instanceof ECPublicKey)) {
                    return new Ecdsa(string, keyPair2);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    public void generateKey(String str) {
        KeyPairGenerator instance = KeyPairGenerator.getInstance("ECDSA", "SC");
        instance.initialize(new ECGenParameterSpec("secp256r1"));
        this.keyPair = instance.generateKeyPair();
        this.uniqueId = str;
    }

    public EccPubKey getPublicKey() {
        ECPublicKey eCPublicKey = (ECPublicKey) this.keyPair.getPublic();
        if (eCPublicKey != null) {
            return new EccPubKey(eCPublicKey);
        }
        return null;
    }

    public String getUniqueId() {
        return this.uniqueId;
    }

    public byte[] sign(byte[] bArr) {
        Signature instance = Signature.getInstance("NONEwithECDSA", "SC");
        instance.initSign(this.keyPair.getPrivate());
        instance.update(bArr);
        return derToP1363(instance.sign());
    }

    public boolean storeKeyPairAndId(Context context, String str) {
        SharedPreferences.Editor edit = context.getSharedPreferences(PREF_FILE_NAME, 0).edit();
        edit.putString(PREF_UNIQUE_ID, str);
        edit.putString(PREF_PRIVATE_KEY, Base64.encodeToString(this.keyPair.getPrivate().getEncoded(), 3));
        edit.putString(PREF_PUBLIC_KEY, Base64.encodeToString(this.keyPair.getPublic().getEncoded(), 3));
        return edit.commit();
    }
}
