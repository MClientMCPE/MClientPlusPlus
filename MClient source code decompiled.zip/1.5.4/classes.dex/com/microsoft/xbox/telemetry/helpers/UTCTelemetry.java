package com.microsoft.xbox.telemetry.helpers;

public class UTCTelemetry {
    public static native void WriteEvent(String str);
}
