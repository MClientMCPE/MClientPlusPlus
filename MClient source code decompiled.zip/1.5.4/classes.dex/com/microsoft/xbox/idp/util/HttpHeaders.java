package com.microsoft.xbox.idp.util;

public class HttpHeaders {
}
