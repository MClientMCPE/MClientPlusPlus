package com.microsoft.xbox.idp.util;

public class AuthFlowResult {
    public static native void delete(long j);

    public static native String getAgeGroup(long j);

    public static native String getGamerTag(long j);

    public static native String getPrivileges(long j);

    public static native String getRpsTicket(long j);

    public static native String getUserEnforcementRestrictions(long j);

    public static native String getUserId(long j);

    public static native String getUserSettingsRestrictions(long j);

    public static native String getUserTitleRestrictions(long j);
}
