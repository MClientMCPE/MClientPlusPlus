package com.microsoft.xbox.idp.interop;

import android.app.Activity;
import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.InvocationTargetException;
import java.util.Locale;
import p000.ty3;
import p002io.mrarm.yurai.YuraiActivity;
import p002io.mrarm.yurai.xbox.CLLInstance;

public class Interop {
    public static final int AUTH_FLOW_CANCEL = 1;
    public static final int AUTH_FLOW_ERROR = 2;
    public static final int AUTH_FLOW_SUCCESS = 0;

    public static class Callback {
    }

    public interface ErrorCallback {
        void onError(int i, int i2, String str);
    }

    public interface EventInitializationCallback extends ErrorCallback {
        void onSuccess();
    }

    public interface XBLoginCallback extends ErrorCallback {
        void onLogin(long j, boolean z);
    }

    public static class XBLogoutCallback {
    }

    public static void ClearIntent() {
        Log.d("xbox/idp", "ClearIntent");
    }

    public static String GetLiveXTokenCallback(boolean z) {
        Log.d("xbox/idp", "GetLiveXTokenCallback");
        return get_uploader_x_token_callback(z);
    }

    public static String GetLocalStoragePath(Context context) {
        Log.d("xbox/idp", "GetLocalStoragePath");
        return context.getFilesDir().getPath();
    }

    public static String GetXTokenCallback(String str) {
        return get_supporting_x_token_callback(str);
    }

    public static void InitCLL(Context context, String str) {
        Log.d("xbox/idp", "InitCLL");
        if (ty3.f15219c == null) {
            File file = new File(context.getFilesDir(), "cll_events");
            File file2 = new File(context.getCacheDir(), "cll");
            file.mkdirs();
            file2.mkdirs();
            String str2 = str;
            ty3.f15219c = new CLLInstance(str2, file.getAbsolutePath(), file2.getAbsolutePath(), "com.mojang.minecraftpe", ((ay3) ((YuraiActivity) ty3.f15217a.get()).mo7119c()).f1604a);
        }
    }

    public static void InvokeAuthFlow(long j, Activity activity, boolean z) {
        InvokeAuthFlow(j, activity, z, (String) null);
    }

    public static void InvokeAuthFlow(final long j, final Activity activity, boolean z, String str) {
        Log.d("xbox/idp", "InvokeAuthFlow");
        activity.runOnUiThread(new Runnable() {
            public void run() {
                ty3.m13664a((Context) activity, j);
            }
        });
    }

    public static void InvokeBrokeredMSA(Context context, boolean z) {
        Log.d("xbox/idp", "InvokeBrokeredMSA");
    }

    public static void InvokeEventInitialization(long j, String str, EventInitializationCallback eventInitializationCallback) {
        Log.d("xbox/idp", "InvokeEventInitialization");
        invoke_event_initialization(j, str, eventInitializationCallback);
    }

    public static void InvokeLatestIntent(Activity activity, Object obj) {
        Log.d("xbox/idp", "InvokeLatestIntent");
    }

    public static void InvokeMSA(Context context, int i, boolean z, String str) {
        Log.d("xbox/idp", "InvokeMSA " + i);
        if (i == 1) {
            ty3.C1954a a = ty3.m13663a(context, str);
            String str2 = a.f15222c;
            if (str2 == null) {
                str2 = "";
            }
            ticket_callback(str2, i, a.f15220a, a.f15221b);
        } else if (i == 6) {
            CLLInstance cLLInstance = ty3.f15219c;
            if (cLLInstance != null) {
                cLLInstance.mo7234a((String) null);
            }
            sign_out_callback();
        }
    }

    public static void InvokeXBLogin(long j, String str, XBLoginCallback xBLoginCallback) {
        Log.d("xbox/idp", "InvokeXBLogin");
        invoke_xb_login(j, str, xBLoginCallback);
    }

    public static void InvokeXBLogout(long j, XBLogoutCallback xBLogoutCallback) {
        Log.d("xbox/idp", "InvokeXBLogout");
    }

    public static void InvokeXTokenCallback(long j, Callback callback) {
        Log.d("xbox/idp", "InvokeXTokenCallback");
    }

    public static void LogCLL(String str, String str2, String str3) {
        Log.d("xbox/idp", "LogCLL: " + str + ", " + str2 + " = " + str3);
        CLLInstance cLLInstance = ty3.f15219c;
        if (cLLInstance != null) {
            cLLInstance.mo7235a(str, str2, str3);
        }
    }

    public static void LogTelemetrySignIn(String str, String str2) {
        Log.d("xbox/idp", "LogTelemetrySignIn: " + str + str2);
    }

    public static void NotificationRegisterCallback(String str, boolean z) {
        Log.d("xbox/idp", "NotificationRegisterCallback");
    }

    public static String ReadConfigFile(Context context) {
        Log.d("xbox/idp", "ReadConfigFile");
        YuraiActivity a = ty3.m13662a();
        if (a != null) {
            try {
                AssetManager gameAssetManager = a.getGameAssetManager();
                try {
                    InputStream inputStream = (InputStream) oy3.f12166a.invoke(gameAssetManager, new Object[]{"res/raw/xboxservices.config"});
                    ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                    byte[] bArr = new byte[4096];
                    while (true) {
                        int read = inputStream.read(bArr);
                        if (read < 0) {
                            return byteArrayOutputStream.toString();
                        }
                        byteArrayOutputStream.write(bArr, 0, read);
                    }
                } catch (IllegalAccessException e) {
                    e = e;
                    throw new RuntimeException(e);
                } catch (IllegalArgumentException e2) {
                    e = e2;
                    throw new RuntimeException(e);
                } catch (InvocationTargetException e3) {
                    e = e3;
                    throw new RuntimeException(e);
                }
            } catch (IOException e4) {
                throw new RuntimeException(e4);
            }
        } else {
            throw new RuntimeException("readConfigFile must be called after the game is started");
        }
    }

    public static void RegisterWithGNS(Context context) {
        Log.d("xbox/idp", "RegisterWithGNS");
    }

    public static native void auth_flow_callback(long j, int i, String str);

    public static native boolean deinitializeInterop();

    public static native void gamertag_updated_callback(String str);

    public static Context getApplicationContext() {
        Log.d("xbox/idp", "getApplicationContext");
        YuraiActivity a = ty3.m13662a();
        if (a != null) {
            return a.getApplicationContext();
        }
        return null;
    }

    public static String getLocale() {
        Log.d("xbox/idp", "getLocale");
        return Locale.getDefault().toString();
    }

    public static String getSystemProxy() {
        Log.d("xbox/idp", "getSystemProxy");
        String property = System.getProperty("http.proxyPort");
        if (property == null) {
            return "";
        }
        StringBuilder a = C0789gk.m5562a("http://");
        a.append(System.getProperty("http.proxyHost"));
        a.append(":");
        a.append(property);
        String sb = a.toString();
        Log.d("xbox/idp", "getSystemProxy returning " + sb);
        return sb;
    }

    public static native String get_supporting_x_token_callback(String str);

    public static native String get_title_telemetry_device_id();

    public static native String get_title_telemetry_session_id();

    public static native String get_uploader_x_token_callback(boolean z);

    public static native boolean initializeInterop(Context context);

    public static native void invoke_event_initialization(long j, String str, EventInitializationCallback eventInitializationCallback);

    public static native void invoke_x_token_acquisition(long j, Callback callback);

    public static native void invoke_xb_login(long j, String str, XBLoginCallback xBLoginCallback);

    public static native void invoke_xb_logout(long j, XBLogoutCallback xBLogoutCallback);

    public static native void notificiation_registration_callback(String str, boolean z);

    public static native void sign_out_callback();

    public static native void ticket_callback(String str, int i, int i2, String str2);
}
