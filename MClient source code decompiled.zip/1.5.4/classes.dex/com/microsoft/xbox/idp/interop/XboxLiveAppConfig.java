package com.microsoft.xbox.idp.interop;

public class XboxLiveAppConfig {

    /* renamed from: id */
    public final long f3388id = create();

    public static native long create();

    public static native void delete(long j);

    public static native String getEnvironment(long j);

    public static native int getOverrideTitleId(long j);

    public static native String getProxy(long j);

    public static native String getSandbox(long j);

    public static native String getScid(long j);

    public static native int getTitleId(long j);

    public static native void setEnvironment(long j, String str);

    public static native void setOverrideTitleId(long j, int i);

    public static native void setProxy(long j, String str);

    public static native void setSandbox(long j, String str);

    public void finalize() {
        delete(this.f3388id);
        super.finalize();
    }
}
