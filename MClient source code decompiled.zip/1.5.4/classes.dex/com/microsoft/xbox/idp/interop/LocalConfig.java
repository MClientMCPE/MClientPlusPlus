package com.microsoft.xbox.idp.interop;

public class LocalConfig {

    /* renamed from: id */
    public final long f3387id = create();

    public static native long create();

    public static native void delete(long j);

    public static native String getCid(long j);

    public void finalize() {
        delete(this.f3387id);
        super.finalize();
    }

    public String getCid() {
        return getCid(this.f3387id);
    }
}
