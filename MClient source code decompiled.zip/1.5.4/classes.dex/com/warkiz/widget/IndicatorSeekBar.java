package com.warkiz.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;
import android.view.WindowManager;
import android.widget.TextView;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.math.BigDecimal;

public class IndicatorSeekBar extends View {

    /* renamed from: A0 */
    public float[] f3396A0;

    /* renamed from: A1 */
    public int f3397A1;

    /* renamed from: B0 */
    public boolean f3398B0;

    /* renamed from: B1 */
    public boolean f3399B1;

    /* renamed from: C0 */
    public boolean f3400C0;

    /* renamed from: C1 */
    public float f3401C1;

    /* renamed from: D0 */
    public boolean f3402D0;

    /* renamed from: D1 */
    public int f3403D1;

    /* renamed from: E0 */
    public int f3404E0;

    /* renamed from: E1 */
    public boolean f3405E1;

    /* renamed from: F0 */
    public String[] f3406F0;

    /* renamed from: F1 */
    public boolean f3407F1;

    /* renamed from: G0 */
    public float[] f3408G0;

    /* renamed from: H0 */
    public float[] f3409H0;

    /* renamed from: I0 */
    public float f3410I0;

    /* renamed from: J0 */
    public int f3411J0;

    /* renamed from: K0 */
    public Typeface f3412K0;

    /* renamed from: L0 */
    public int f3413L0;

    /* renamed from: M0 */
    public int f3414M0;

    /* renamed from: N0 */
    public int f3415N0;

    /* renamed from: O0 */
    public CharSequence[] f3416O0;

    /* renamed from: P0 */
    public ee3 f3417P0;

    /* renamed from: Q0 */
    public int f3418Q0;

    /* renamed from: R0 */
    public int f3419R0;

    /* renamed from: S0 */
    public boolean f3420S0;

    /* renamed from: T0 */
    public int f3421T0;

    /* renamed from: U0 */
    public View f3422U0;

    /* renamed from: V0 */
    public View f3423V0;

    /* renamed from: W0 */
    public int f3424W0;

    /* renamed from: X0 */
    public ge3 f3425X0;

    /* renamed from: Y0 */
    public float[] f3426Y0;

    /* renamed from: Z0 */
    public int f3427Z0;

    /* renamed from: a0 */
    public Context f3428a0;

    /* renamed from: a1 */
    public int f3429a1;

    /* renamed from: b0 */
    public Paint f3430b0;

    /* renamed from: b1 */
    public int f3431b1;

    /* renamed from: c0 */
    public TextPaint f3432c0;

    /* renamed from: c1 */
    public float f3433c1;

    /* renamed from: d0 */
    public he3 f3434d0;

    /* renamed from: d1 */
    public Bitmap f3435d1;

    /* renamed from: e0 */
    public Rect f3436e0;

    /* renamed from: e1 */
    public Bitmap f3437e1;

    /* renamed from: f0 */
    public float f3438f0;

    /* renamed from: f1 */
    public Drawable f3439f1;

    /* renamed from: g0 */
    public float f3440g0;

    /* renamed from: g1 */
    public int f3441g1;

    /* renamed from: h0 */
    public float f3442h0;

    /* renamed from: h1 */
    public boolean f3443h1;

    /* renamed from: i0 */
    public float f3444i0;

    /* renamed from: i1 */
    public boolean f3445i1;

    /* renamed from: j0 */
    public boolean f3446j0;

    /* renamed from: j1 */
    public int f3447j1;

    /* renamed from: k0 */
    public ne3 f3448k0;

    /* renamed from: k1 */
    public boolean f3449k1;

    /* renamed from: l0 */
    public int f3450l0;

    /* renamed from: l1 */
    public RectF f3451l1;

    /* renamed from: m0 */
    public int f3452m0;

    /* renamed from: m1 */
    public RectF f3453m1;

    /* renamed from: n0 */
    public int f3454n0;

    /* renamed from: n1 */
    public int f3455n1;

    /* renamed from: o0 */
    public int f3456o0;

    /* renamed from: o1 */
    public int f3457o1;

    /* renamed from: p0 */
    public float f3458p0;

    /* renamed from: p1 */
    public int f3459p1;

    /* renamed from: q0 */
    public float f3460q0;

    /* renamed from: q1 */
    public int f3461q1;

    /* renamed from: r0 */
    public boolean f3462r0;

    /* renamed from: r1 */
    public int[] f3463r1;

    /* renamed from: s0 */
    public float f3464s0;

    /* renamed from: s1 */
    public boolean f3465s1;

    /* renamed from: t0 */
    public float f3466t0;

    /* renamed from: t1 */
    public float f3467t1;

    /* renamed from: u0 */
    public float f3468u0;

    /* renamed from: u1 */
    public float f3469u1;

    /* renamed from: v0 */
    public boolean f3470v0;

    /* renamed from: v1 */
    public Bitmap f3471v1;

    /* renamed from: w0 */
    public int f3472w0;

    /* renamed from: w1 */
    public int f3473w1;

    /* renamed from: x0 */
    public boolean f3474x0;

    /* renamed from: x1 */
    public int f3475x1;

    /* renamed from: y0 */
    public boolean f3476y0;

    /* renamed from: y1 */
    public Drawable f3477y1;

    /* renamed from: z0 */
    public boolean f3478z0;

    /* renamed from: z1 */
    public Bitmap f3479z1;

    /* renamed from: com.warkiz.widget.IndicatorSeekBar$a */
    public class C0486a implements Runnable {
        public C0486a() {
        }

        public void run() {
            IndicatorSeekBar.this.requestLayout();
        }
    }

    public IndicatorSeekBar(Context context) {
        this(context, (AttributeSet) null);
    }

    public IndicatorSeekBar(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f3442h0 = -1.0f;
        this.f3444i0 = -1.0f;
        this.f3472w0 = 1;
        this.f3428a0 = context;
        mo4378a(this.f3428a0, attributeSet);
        mo4383b();
    }

    public IndicatorSeekBar(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f3442h0 = -1.0f;
        this.f3444i0 = -1.0f;
        this.f3472w0 = 1;
        this.f3428a0 = context;
        mo4378a(this.f3428a0, attributeSet);
        mo4383b();
    }

    public IndicatorSeekBar(be3 be3) {
        super(be3.f1883a);
        this.f3442h0 = -1.0f;
        this.f3444i0 = -1.0f;
        this.f3472w0 = 1;
        this.f3428a0 = be3.f1883a;
        int a = t53.m13070a(this.f3428a0, 16.0f);
        setPadding(a, getPaddingTop(), a, getPaddingBottom());
        mo4382a(be3);
        mo4383b();
    }

    private float getAmplitude() {
        float f = this.f3464s0;
        float f2 = this.f3466t0;
        if (f - f2 > 0.0f) {
            return f - f2;
        }
        return 1.0f;
    }

    private int getClosestIndex() {
        int i = 0;
        float abs = Math.abs(this.f3464s0 - this.f3466t0);
        int i2 = 0;
        while (true) {
            float[] fArr = this.f3396A0;
            if (i >= fArr.length) {
                return i2;
            }
            float abs2 = Math.abs(fArr[i] - this.f3468u0);
            if (abs2 <= abs) {
                i2 = i;
                abs = abs2;
            }
            i++;
        }
    }

    private int getLeftSideTickColor() {
        return this.f3398B0 ? this.f3429a1 : this.f3431b1;
    }

    private int getLeftSideTickTextsColor() {
        return this.f3398B0 ? this.f3414M0 : this.f3413L0;
    }

    private int getLeftSideTrackSize() {
        return this.f3398B0 ? this.f3455n1 : this.f3457o1;
    }

    private int getRightSideTickColor() {
        return this.f3398B0 ? this.f3431b1 : this.f3429a1;
    }

    private int getRightSideTickTextsColor() {
        return this.f3398B0 ? this.f3413L0 : this.f3414M0;
    }

    private int getRightSideTrackSize() {
        return this.f3398B0 ? this.f3457o1 : this.f3455n1;
    }

    private float getThumbCenterX() {
        return (this.f3398B0 ? this.f3453m1 : this.f3451l1).right;
    }

    private int getThumbPosOnTick() {
        if (this.f3427Z0 != 0) {
            return Math.round((getThumbCenterX() - ((float) this.f3450l0)) / this.f3460q0);
        }
        return 0;
    }

    private float getThumbPosOnTickFloat() {
        if (this.f3427Z0 != 0) {
            return (getThumbCenterX() - ((float) this.f3450l0)) / this.f3460q0;
        }
        return 0.0f;
    }

    /* access modifiers changed from: private */
    public void setSeekListener(boolean z) {
        String[] strArr;
        if (this.f3434d0 != null) {
            boolean z2 = true;
            if (!this.f3470v0 ? Math.round(this.f3440g0) == Math.round(this.f3468u0) : this.f3440g0 == this.f3468u0) {
                z2 = false;
            }
            if (z2) {
                he3 he3 = this.f3434d0;
                if (this.f3448k0 == null) {
                    this.f3448k0 = new ne3(this);
                }
                this.f3448k0.f11053a = getProgress();
                this.f3448k0.f11054b = getProgressFloat();
                this.f3448k0.f11055c = z;
                if (this.f3427Z0 > 2) {
                    int thumbPosOnTick = getThumbPosOnTick();
                    if (this.f3400C0 && (strArr = this.f3406F0) != null) {
                        this.f3448k0.f11057e = strArr[thumbPosOnTick];
                    }
                    if (this.f3398B0) {
                        this.f3448k0.f11056d = (this.f3427Z0 - thumbPosOnTick) - 1;
                    } else {
                        this.f3448k0.f11056d = thumbPosOnTick;
                    }
                }
                he3.mo6530a(this.f3448k0);
            }
        }
    }

    /* renamed from: a */
    public final int mo4374a(Drawable drawable, int i) {
        return Math.round(((((float) i) * 1.0f) * ((float) drawable.getIntrinsicHeight())) / ((float) drawable.getIntrinsicWidth()));
    }

    /* renamed from: a */
    public final Bitmap mo4375a(Drawable drawable, boolean z) {
        int i;
        if (drawable == null) {
            return null;
        }
        int a = t53.m13070a(this.f3428a0, 30.0f);
        if (drawable.getIntrinsicWidth() > a) {
            int i2 = z ? this.f3475x1 : this.f3447j1;
            i = mo4374a(drawable, i2);
            if (i2 > a) {
                i = mo4374a(drawable, a);
            } else {
                a = i2;
            }
        } else {
            a = drawable.getIntrinsicWidth();
            i = drawable.getIntrinsicHeight();
        }
        Bitmap createBitmap = Bitmap.createBitmap(a, i, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);
        return createBitmap;
    }

    /* renamed from: a */
    public final String mo4376a(float f) {
        return this.f3470v0 ? de3.m3605a((double) f, this.f3472w0) : String.valueOf(Math.round(f));
    }

    /* renamed from: a */
    public final void mo4377a() {
        int i = this.f3427Z0;
        if (i < 0 || i > 50) {
            StringBuilder a = C0789gk.m5562a("the Argument: TICK COUNT must be limited between (0-50), Now is ");
            a.append(this.f3427Z0);
            throw new IllegalArgumentException(a.toString());
        } else if (i != 0) {
            this.f3426Y0 = new float[i];
            if (this.f3400C0) {
                this.f3409H0 = new float[i];
                this.f3408G0 = new float[i];
            }
            this.f3396A0 = new float[this.f3427Z0];
            int i2 = 0;
            while (true) {
                float[] fArr = this.f3396A0;
                if (i2 < fArr.length) {
                    float f = this.f3466t0;
                    float f2 = (this.f3464s0 - f) * ((float) i2);
                    int i3 = this.f3427Z0;
                    fArr[i2] = (f2 / ((float) (i3 + -1 > 0 ? i3 - 1 : 1))) + f;
                    i2++;
                } else {
                    return;
                }
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:20:0x019b  */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x01ab  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo4378a(android.content.Context r4, android.util.AttributeSet r5) {
        /*
            r3 = this;
            be3 r0 = new be3
            r0.<init>(r4)
            if (r5 != 0) goto L_0x000b
            r3.mo4382a((p000.be3) r0)
            return
        L_0x000b:
            int[] r1 = p000.me3.IndicatorSeekBar
            android.content.res.TypedArray r4 = r4.obtainStyledAttributes(r5, r1)
            int r5 = p000.me3.IndicatorSeekBar_isb_max
            float r1 = r0.f1884b
            float r5 = r4.getFloat(r5, r1)
            r3.f3464s0 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_min
            float r1 = r0.f1885c
            float r5 = r4.getFloat(r5, r1)
            r3.f3466t0 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_progress
            float r1 = r0.f1886d
            float r5 = r4.getFloat(r5, r1)
            r3.f3468u0 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_progress_value_float
            boolean r1 = r0.f1887e
            boolean r5 = r4.getBoolean(r5, r1)
            r3.f3470v0 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_user_seekable
            boolean r1 = r0.f1890h
            boolean r5 = r4.getBoolean(r5, r1)
            r3.f3474x0 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_clear_default_padding
            boolean r1 = r0.f1892j
            boolean r5 = r4.getBoolean(r5, r1)
            r3.f3446j0 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_only_thumb_draggable
            boolean r1 = r0.f1891i
            boolean r5 = r4.getBoolean(r5, r1)
            r3.f3476y0 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_seek_smoothly
            boolean r1 = r0.f1888f
            boolean r5 = r4.getBoolean(r5, r1)
            r3.f3478z0 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_r2l
            boolean r1 = r0.f1889g
            boolean r5 = r4.getBoolean(r5, r1)
            r3.f3398B0 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_track_background_size
            int r1 = r0.f1899q
            int r5 = r4.getDimensionPixelSize(r5, r1)
            r3.f3455n1 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_track_progress_size
            int r1 = r0.f1901s
            int r5 = r4.getDimensionPixelSize(r5, r1)
            r3.f3457o1 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_track_background_color
            int r1 = r0.f1900r
            int r5 = r4.getColor(r5, r1)
            r3.f3459p1 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_track_progress_color
            int r1 = r0.f1902t
            int r5 = r4.getColor(r5, r1)
            r3.f3461q1 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_track_rounded_corners
            boolean r1 = r0.f1903u
            boolean r5 = r4.getBoolean(r5, r1)
            r3.f3449k1 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_thumb_size
            int r1 = r0.f1906x
            int r5 = r4.getDimensionPixelSize(r5, r1)
            r3.f3475x1 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_thumb_drawable
            android.graphics.drawable.Drawable r5 = r4.getDrawable(r5)
            r3.f3477y1 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_thumb_adjust_auto
            r1 = 1
            boolean r5 = r4.getBoolean(r5, r1)
            r3.f3407F1 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_thumb_color
            android.content.res.ColorStateList r5 = r4.getColorStateList(r5)
            int r2 = r0.f1907y
            r3.mo4379a((android.content.res.ColorStateList) r5, (int) r2)
            int r5 = p000.me3.IndicatorSeekBar_isb_show_thumb_text
            boolean r2 = r0.f1905w
            boolean r5 = r4.getBoolean(r5, r2)
            r3.f3399B1 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_thumb_text_color
            int r2 = r0.f1904v
            int r5 = r4.getColor(r5, r2)
            r3.f3403D1 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_ticks_count
            int r2 = r0.f1875H
            int r5 = r4.getInt(r5, r2)
            r3.f3427Z0 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_show_tick_marks_type
            int r2 = r0.f1876I
            int r5 = r4.getInt(r5, r2)
            r3.f3441g1 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_tick_marks_size
            int r2 = r0.f1878K
            int r5 = r4.getDimensionPixelSize(r5, r2)
            r3.f3447j1 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_tick_marks_color
            android.content.res.ColorStateList r5 = r4.getColorStateList(r5)
            int r2 = r0.f1877J
            r3.mo4385b(r5, r2)
            int r5 = p000.me3.IndicatorSeekBar_isb_tick_marks_drawable
            android.graphics.drawable.Drawable r5 = r4.getDrawable(r5)
            r3.f3439f1 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_tick_marks_swept_hide
            boolean r2 = r0.f1881N
            boolean r5 = r4.getBoolean(r5, r2)
            r3.f3445i1 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_tick_marks_ends_hide
            boolean r2 = r0.f1880M
            boolean r5 = r4.getBoolean(r5, r2)
            r3.f3443h1 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_show_tick_texts
            boolean r2 = r0.f1869B
            boolean r5 = r4.getBoolean(r5, r2)
            r3.f3400C0 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_tick_texts_size
            int r2 = r0.f1871D
            int r5 = r4.getDimensionPixelSize(r5, r2)
            r3.f3411J0 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_tick_texts_color
            android.content.res.ColorStateList r5 = r4.getColorStateList(r5)
            int r2 = r0.f1870C
            r3.mo4388c(r5, r2)
            int r5 = p000.me3.IndicatorSeekBar_isb_tick_texts_array
            java.lang.CharSequence[] r5 = r4.getTextArray(r5)
            r3.f3416O0 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_tick_texts_typeface
            r2 = -1
            int r5 = r4.getInt(r5, r2)
            android.graphics.Typeface r2 = r0.f1873F
            if (r5 == 0) goto L_0x0165
            if (r5 == r1) goto L_0x0162
            r1 = 2
            if (r5 == r1) goto L_0x015f
            r1 = 3
            if (r5 == r1) goto L_0x015c
            if (r2 != 0) goto L_0x0159
            goto L_0x0165
        L_0x0159:
            r3.f3412K0 = r2
            goto L_0x0169
        L_0x015c:
            android.graphics.Typeface r5 = android.graphics.Typeface.SERIF
            goto L_0x0167
        L_0x015f:
            android.graphics.Typeface r5 = android.graphics.Typeface.SANS_SERIF
            goto L_0x0167
        L_0x0162:
            android.graphics.Typeface r5 = android.graphics.Typeface.MONOSPACE
            goto L_0x0167
        L_0x0165:
            android.graphics.Typeface r5 = android.graphics.Typeface.DEFAULT
        L_0x0167:
            r3.f3412K0 = r5
        L_0x0169:
            int r5 = p000.me3.IndicatorSeekBar_isb_show_indicator
            int r1 = r0.f1893k
            int r5 = r4.getInt(r5, r1)
            r3.f3424W0 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_indicator_color
            int r1 = r0.f1894l
            int r5 = r4.getColor(r5, r1)
            r3.f3418Q0 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_indicator_text_size
            int r1 = r0.f1896n
            int r5 = r4.getDimensionPixelSize(r5, r1)
            r3.f3421T0 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_indicator_text_color
            int r0 = r0.f1895m
            int r5 = r4.getColor(r5, r0)
            r3.f3419R0 = r5
            int r5 = p000.me3.IndicatorSeekBar_isb_indicator_content_layout
            r0 = 0
            int r5 = r4.getResourceId(r5, r0)
            r1 = 0
            if (r5 <= 0) goto L_0x01a3
            android.content.Context r2 = r3.f3428a0
            android.view.View r5 = android.view.View.inflate(r2, r5, r1)
            r3.f3422U0 = r5
        L_0x01a3:
            int r5 = p000.me3.IndicatorSeekBar_isb_indicator_top_content_layout
            int r5 = r4.getResourceId(r5, r0)
            if (r5 <= 0) goto L_0x01b3
            android.content.Context r0 = r3.f3428a0
            android.view.View r5 = android.view.View.inflate(r0, r5, r1)
            r3.f3423V0 = r5
        L_0x01b3:
            r4.recycle()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.warkiz.widget.IndicatorSeekBar.mo4378a(android.content.Context, android.util.AttributeSet):void");
    }

    /* renamed from: a */
    public final void mo4379a(ColorStateList colorStateList, int i) {
        if (colorStateList == null) {
            this.f3473w1 = i;
            this.f3397A1 = this.f3473w1;
            return;
        }
        try {
            int[][] iArr = null;
            int[] iArr2 = null;
            for (Field field : colorStateList.getClass().getDeclaredFields()) {
                field.setAccessible(true);
                if ("mStateSpecs".equals(field.getName())) {
                    iArr = (int[][]) field.get(colorStateList);
                }
                if ("mColors".equals(field.getName())) {
                    iArr2 = (int[]) field.get(colorStateList);
                }
            }
            if (iArr != null && iArr2 != null) {
                if (iArr.length == 1) {
                    this.f3473w1 = iArr2[0];
                    this.f3397A1 = this.f3473w1;
                } else if (iArr.length == 2) {
                    for (int i2 = 0; i2 < iArr.length; i2++) {
                        int[] iArr3 = iArr[i2];
                        if (iArr3.length == 0) {
                            this.f3397A1 = iArr2[i2];
                        } else if (iArr3[0] == 16842919) {
                            this.f3473w1 = iArr2[i2];
                        } else {
                            throw new IllegalArgumentException("the selector color file you set for the argument: isb_thumb_color is in wrong format.");
                        }
                    }
                } else {
                    throw new IllegalArgumentException("the selector color file you set for the argument: isb_thumb_color is in wrong format.");
                }
            }
        } catch (Exception unused) {
            throw new RuntimeException("Something wrong happened when parseing thumb selector color.");
        }
    }

    /* renamed from: a */
    public final void mo4380a(Canvas canvas) {
        int i;
        Paint paint;
        Bitmap bitmap;
        float f;
        Bitmap bitmap2;
        float f2;
        if (!this.f3405E1) {
            float thumbCenterX = getThumbCenterX();
            if (this.f3477y1 != null) {
                if (this.f3471v1 == null || this.f3479z1 == null) {
                    mo4394f();
                }
                if (this.f3471v1 == null || this.f3479z1 == null) {
                    throw new IllegalArgumentException("the format of the selector thumb drawable is wrong!");
                }
                this.f3430b0.setAlpha(255);
                if (this.f3462r0) {
                    bitmap2 = this.f3479z1;
                    f2 = thumbCenterX - (((float) bitmap2.getWidth()) / 2.0f);
                    f = this.f3451l1.top;
                    bitmap = this.f3479z1;
                } else {
                    bitmap2 = this.f3471v1;
                    f2 = thumbCenterX - (((float) bitmap2.getWidth()) / 2.0f);
                    f = this.f3451l1.top;
                    bitmap = this.f3471v1;
                }
                canvas.drawBitmap(bitmap2, f2, f - (((float) bitmap.getHeight()) / 2.0f), this.f3430b0);
                return;
            }
            if (this.f3462r0) {
                paint = this.f3430b0;
                i = this.f3397A1;
            } else {
                paint = this.f3430b0;
                i = this.f3473w1;
            }
            paint.setColor(i);
            canvas.drawCircle(thumbCenterX, this.f3451l1.top, this.f3462r0 ? this.f3469u1 : this.f3467t1, this.f3430b0);
        }
    }

    /* renamed from: a */
    public final void mo4382a(be3 be3) {
        this.f3464s0 = be3.f1884b;
        this.f3466t0 = be3.f1885c;
        this.f3468u0 = be3.f1886d;
        this.f3470v0 = be3.f1887e;
        this.f3427Z0 = be3.f1875H;
        this.f3478z0 = be3.f1888f;
        this.f3398B0 = be3.f1889g;
        this.f3474x0 = be3.f1890h;
        this.f3446j0 = be3.f1892j;
        this.f3476y0 = be3.f1891i;
        this.f3424W0 = be3.f1893k;
        this.f3418Q0 = be3.f1894l;
        this.f3419R0 = be3.f1895m;
        this.f3421T0 = be3.f1896n;
        this.f3422U0 = be3.f1897o;
        this.f3423V0 = be3.f1898p;
        this.f3455n1 = be3.f1899q;
        this.f3459p1 = be3.f1900r;
        this.f3457o1 = be3.f1901s;
        this.f3461q1 = be3.f1902t;
        this.f3449k1 = be3.f1903u;
        this.f3475x1 = be3.f1906x;
        this.f3477y1 = be3.f1868A;
        this.f3403D1 = be3.f1904v;
        mo4379a(be3.f1908z, be3.f1907y);
        this.f3399B1 = be3.f1905w;
        this.f3441g1 = be3.f1876I;
        this.f3447j1 = be3.f1878K;
        this.f3439f1 = be3.f1879L;
        this.f3443h1 = be3.f1880M;
        this.f3445i1 = be3.f1881N;
        mo4385b(be3.f1882O, be3.f1877J);
        this.f3400C0 = be3.f1869B;
        this.f3411J0 = be3.f1871D;
        this.f3416O0 = be3.f1872E;
        this.f3412K0 = be3.f1873F;
        mo4388c(be3.f1874G, be3.f1870C);
    }

    /* renamed from: b */
    public final void mo4383b() {
        float f;
        mo4387c();
        int i = this.f3455n1;
        int i2 = this.f3457o1;
        if (i > i2) {
            this.f3455n1 = i2;
        }
        if (this.f3477y1 == null) {
            this.f3467t1 = ((float) this.f3475x1) / 2.0f;
            f = this.f3467t1 * 1.2f;
        } else {
            this.f3467t1 = ((float) Math.min(t53.m13070a(this.f3428a0, 30.0f), this.f3475x1)) / 2.0f;
            f = this.f3467t1;
        }
        this.f3469u1 = f;
        this.f3433c1 = ((float) (this.f3439f1 == null ? this.f3447j1 : Math.min(t53.m13070a(this.f3428a0, 30.0f), this.f3447j1))) / 2.0f;
        this.f3438f0 = Math.max(this.f3469u1, this.f3433c1) * 2.0f;
        if (this.f3430b0 == null) {
            this.f3430b0 = new Paint();
        }
        if (this.f3449k1) {
            this.f3430b0.setStrokeCap(Paint.Cap.ROUND);
        }
        this.f3430b0.setAntiAlias(true);
        int i3 = this.f3455n1;
        if (i3 > this.f3457o1) {
            this.f3457o1 = i3;
        }
        if (mo4405h()) {
            if (this.f3432c0 == null) {
                this.f3432c0 = new TextPaint();
                this.f3432c0.setAntiAlias(true);
                this.f3432c0.setTextAlign(Paint.Align.CENTER);
                this.f3432c0.setTextSize((float) this.f3411J0);
            }
            if (this.f3436e0 == null) {
                this.f3436e0 = new Rect();
            }
            this.f3432c0.setTypeface(this.f3412K0);
            this.f3432c0.getTextBounds("j", 0, 1, this.f3436e0);
            this.f3404E0 = t53.m13070a(this.f3428a0, 3.0f) + this.f3436e0.height();
        }
        this.f3440g0 = this.f3468u0;
        mo4377a();
        this.f3451l1 = new RectF();
        this.f3453m1 = new RectF();
        if (!this.f3446j0) {
            int a = t53.m13070a(this.f3428a0, 16.0f);
            if (getPaddingLeft() == 0) {
                setPadding(a, getPaddingTop(), getPaddingRight(), getPaddingBottom());
            }
            if (getPaddingRight() == 0) {
                setPadding(getPaddingLeft(), getPaddingTop(), a, getPaddingBottom());
            }
        }
        int i4 = this.f3424W0;
        if (i4 != 0 && this.f3417P0 == null) {
            this.f3417P0 = new ee3(this.f3428a0, this, this.f3418Q0, i4, this.f3421T0, this.f3419R0, this.f3422U0, this.f3423V0);
            this.f3422U0 = this.f3417P0.f4437m;
        }
    }

    /* renamed from: b */
    public final void mo4384b(float f) {
        RectF rectF;
        RectF rectF2;
        if (this.f3398B0) {
            this.f3453m1.right = ((1.0f - ((f - this.f3466t0) / getAmplitude())) * this.f3458p0) + ((float) this.f3450l0);
            rectF = this.f3451l1;
            rectF2 = this.f3453m1;
        } else {
            this.f3451l1.right = (((f - this.f3466t0) * this.f3458p0) / getAmplitude()) + ((float) this.f3450l0);
            rectF = this.f3453m1;
            rectF2 = this.f3451l1;
        }
        rectF.left = rectF2.right;
    }

    /* renamed from: b */
    public final void mo4385b(ColorStateList colorStateList, int i) {
        if (colorStateList == null) {
            this.f3431b1 = i;
            this.f3429a1 = this.f3431b1;
            return;
        }
        try {
            int[][] iArr = null;
            int[] iArr2 = null;
            for (Field field : colorStateList.getClass().getDeclaredFields()) {
                field.setAccessible(true);
                if ("mStateSpecs".equals(field.getName())) {
                    iArr = (int[][]) field.get(colorStateList);
                }
                if ("mColors".equals(field.getName())) {
                    iArr2 = (int[]) field.get(colorStateList);
                }
            }
            if (iArr != null && iArr2 != null) {
                if (iArr.length == 1) {
                    this.f3431b1 = iArr2[0];
                    this.f3429a1 = this.f3431b1;
                } else if (iArr.length == 2) {
                    for (int i2 = 0; i2 < iArr.length; i2++) {
                        int[] iArr3 = iArr[i2];
                        if (iArr3.length == 0) {
                            this.f3429a1 = iArr2[i2];
                        } else if (iArr3[0] == 16842913) {
                            this.f3431b1 = iArr2[i2];
                        } else {
                            throw new IllegalArgumentException("the selector color file you set for the argument: isb_tick_marks_color is in wrong format.");
                        }
                    }
                } else {
                    throw new IllegalArgumentException("the selector color file you set for the argument: isb_tick_marks_color is in wrong format.");
                }
            }
        } catch (Exception e) {
            StringBuilder a = C0789gk.m5562a("Something wrong happened when parsing thumb selector color.");
            a.append(e.getMessage());
            throw new RuntimeException(a.toString());
        }
    }

    /* renamed from: b */
    public final void mo4386b(Canvas canvas) {
        int i;
        Paint paint;
        float f;
        float f2;
        float f3;
        float f4;
        Bitmap bitmap;
        if (this.f3427Z0 == 0) {
            return;
        }
        if (this.f3441g1 != 0 || this.f3439f1 != null) {
            float thumbCenterX = getThumbCenterX();
            for (int i2 = 0; i2 < this.f3426Y0.length; i2++) {
                float thumbPosOnTickFloat = getThumbPosOnTickFloat();
                if ((!this.f3445i1 || thumbCenterX < this.f3426Y0[i2]) && ((!this.f3443h1 || !(i2 == 0 || i2 == this.f3426Y0.length - 1)) && (i2 != getThumbPosOnTick() || this.f3427Z0 <= 2 || this.f3478z0))) {
                    float f5 = (float) i2;
                    if (f5 <= thumbPosOnTickFloat) {
                        paint = this.f3430b0;
                        i = getLeftSideTickColor();
                    } else {
                        paint = this.f3430b0;
                        i = getRightSideTickColor();
                    }
                    paint.setColor(i);
                    if (this.f3439f1 != null) {
                        if (this.f3437e1 == null || this.f3435d1 == null) {
                            mo4395g();
                        }
                        Bitmap bitmap2 = this.f3437e1;
                        if (bitmap2 == null || (bitmap = this.f3435d1) == null) {
                            throw new IllegalArgumentException("the format of the selector TickMarks drawable is wrong!");
                        } else if (f5 <= thumbPosOnTickFloat) {
                            canvas.drawBitmap(bitmap2, this.f3426Y0[i2] - (((float) bitmap.getWidth()) / 2.0f), this.f3451l1.top - (((float) this.f3435d1.getHeight()) / 2.0f), this.f3430b0);
                        } else {
                            canvas.drawBitmap(bitmap, this.f3426Y0[i2] - (((float) bitmap.getWidth()) / 2.0f), this.f3451l1.top - (((float) this.f3435d1.getHeight()) / 2.0f), this.f3430b0);
                        }
                    } else {
                        int i3 = this.f3441g1;
                        if (i3 == 1) {
                            canvas.drawCircle(this.f3426Y0[i2], this.f3451l1.top, this.f3433c1, this.f3430b0);
                        } else {
                            if (i3 == 3) {
                                int a = t53.m13070a(this.f3428a0, 1.0f);
                                int leftSideTrackSize = thumbCenterX >= this.f3426Y0[i2] ? getLeftSideTrackSize() : getRightSideTrackSize();
                                float[] fArr = this.f3426Y0;
                                float f6 = (float) a;
                                f4 = fArr[i2] - f6;
                                float f7 = this.f3451l1.top;
                                float f8 = ((float) leftSideTrackSize) / 2.0f;
                                f3 = f7 - f8;
                                f2 = fArr[i2] + f6;
                                f = f7 + f8;
                            } else if (i3 == 2) {
                                float[] fArr2 = this.f3426Y0;
                                float f9 = fArr2[i2];
                                int i4 = this.f3447j1;
                                f4 = f9 - (((float) i4) / 2.0f);
                                float f10 = this.f3451l1.top;
                                f3 = f10 - (((float) i4) / 2.0f);
                                f2 = (((float) i4) / 2.0f) + fArr2[i2];
                                f = (((float) i4) / 2.0f) + f10;
                            }
                            canvas.drawRect(f4, f3, f2, f, this.f3430b0);
                        }
                    }
                }
            }
        }
    }

    /* renamed from: c */
    public final void mo4387c() {
        float f = this.f3464s0;
        float f2 = this.f3466t0;
        if (f >= f2) {
            if (this.f3468u0 < f2) {
                this.f3468u0 = f2;
            }
            float f3 = this.f3468u0;
            float f4 = this.f3464s0;
            if (f3 > f4) {
                this.f3468u0 = f4;
                return;
            }
            return;
        }
        throw new IllegalArgumentException("the Argument: MAX's value must be larger than MIN's.");
    }

    /* renamed from: c */
    public final void mo4388c(ColorStateList colorStateList, int i) {
        if (colorStateList == null) {
            this.f3414M0 = i;
            int i2 = this.f3414M0;
            this.f3413L0 = i2;
            this.f3415N0 = i2;
            return;
        }
        try {
            int[][] iArr = null;
            int[] iArr2 = null;
            for (Field field : colorStateList.getClass().getDeclaredFields()) {
                field.setAccessible(true);
                if ("mStateSpecs".equals(field.getName())) {
                    iArr = (int[][]) field.get(colorStateList);
                }
                if ("mColors".equals(field.getName())) {
                    iArr2 = (int[]) field.get(colorStateList);
                }
            }
            if (iArr != null && iArr2 != null) {
                if (iArr.length == 1) {
                    this.f3414M0 = iArr2[0];
                    int i3 = this.f3414M0;
                    this.f3413L0 = i3;
                    this.f3415N0 = i3;
                } else if (iArr.length == 3) {
                    for (int i4 = 0; i4 < iArr.length; i4++) {
                        int[] iArr3 = iArr[i4];
                        if (iArr3.length == 0) {
                            this.f3414M0 = iArr2[i4];
                        } else {
                            int i5 = iArr3[0];
                            if (i5 == 16842913) {
                                this.f3413L0 = iArr2[i4];
                            } else if (i5 == 16843623) {
                                this.f3415N0 = iArr2[i4];
                            } else {
                                throw new IllegalArgumentException("the selector color file you set for the argument: isb_tick_texts_color is in wrong format.");
                            }
                        }
                    }
                } else {
                    throw new IllegalArgumentException("the selector color file you set for the argument: isb_tick_texts_color is in wrong format.");
                }
            }
        } catch (Exception unused) {
            throw new RuntimeException("Something wrong happened when parseing thumb selector color.");
        }
    }

    /* renamed from: c */
    public final void mo4389c(Canvas canvas) {
        int i;
        TextPaint textPaint;
        if (this.f3406F0 != null) {
            float thumbPosOnTickFloat = getThumbPosOnTickFloat();
            int i2 = 0;
            while (true) {
                String[] strArr = this.f3406F0;
                if (i2 < strArr.length) {
                    if (!this.f3402D0 || i2 == 0 || i2 == strArr.length - 1) {
                        if (i2 == getThumbPosOnTick() && ((float) i2) == thumbPosOnTickFloat) {
                            textPaint = this.f3432c0;
                            i = this.f3415N0;
                        } else if (((float) i2) < thumbPosOnTickFloat) {
                            textPaint = this.f3432c0;
                            i = getLeftSideTickTextsColor();
                        } else {
                            textPaint = this.f3432c0;
                            i = getRightSideTickTextsColor();
                        }
                        textPaint.setColor(i);
                        int length = this.f3398B0 ? (this.f3406F0.length - i2) - 1 : i2;
                        String[] strArr2 = this.f3406F0;
                        if (i2 == 0) {
                            canvas.drawText(strArr2[length], (this.f3408G0[length] / 2.0f) + this.f3409H0[i2], this.f3410I0, this.f3432c0);
                        } else if (i2 == strArr2.length - 1) {
                            canvas.drawText(strArr2[length], this.f3409H0[i2] - (this.f3408G0[length] / 2.0f), this.f3410I0, this.f3432c0);
                        } else {
                            canvas.drawText(strArr2[length], this.f3409H0[i2], this.f3410I0, this.f3432c0);
                        }
                    }
                    i2++;
                } else {
                    return;
                }
            }
        }
    }

    /* renamed from: d */
    public final void mo4390d() {
        this.f3454n0 = getMeasuredWidth();
        int i = Build.VERSION.SDK_INT;
        this.f3450l0 = getPaddingStart();
        this.f3452m0 = getPaddingEnd();
        this.f3456o0 = getPaddingTop();
        this.f3458p0 = (float) ((this.f3454n0 - this.f3450l0) - this.f3452m0);
        float f = this.f3458p0;
        int i2 = this.f3427Z0;
        int i3 = 1;
        if (i2 - 1 > 0) {
            i3 = i2 - 1;
        }
        this.f3460q0 = f / ((float) i3);
    }

    /* renamed from: d */
    public final void mo4391d(Canvas canvas) {
        int i;
        Paint paint;
        int i2;
        Paint paint2;
        if (this.f3465s1) {
            int i3 = this.f3427Z0;
            int i4 = i3 + -1 > 0 ? i3 - 1 : 1;
            for (int i5 = 0; i5 < i4; i5++) {
                if (this.f3398B0) {
                    paint = this.f3430b0;
                    i = this.f3463r1[(i4 - i5) - 1];
                } else {
                    paint = this.f3430b0;
                    i = this.f3463r1[i5];
                }
                paint.setColor(i);
                float thumbPosOnTickFloat = getThumbPosOnTickFloat();
                float f = (float) i5;
                if (f < thumbPosOnTickFloat) {
                    int i6 = i5 + 1;
                    if (thumbPosOnTickFloat < ((float) i6)) {
                        float thumbCenterX = getThumbCenterX();
                        this.f3430b0.setStrokeWidth((float) getLeftSideTrackSize());
                        float f2 = this.f3426Y0[i5];
                        RectF rectF = this.f3451l1;
                        Canvas canvas2 = canvas;
                        canvas2.drawLine(f2, rectF.top, thumbCenterX, rectF.bottom, this.f3430b0);
                        this.f3430b0.setStrokeWidth((float) getRightSideTrackSize());
                        RectF rectF2 = this.f3451l1;
                        canvas2.drawLine(thumbCenterX, rectF2.top, this.f3426Y0[i6], rectF2.bottom, this.f3430b0);
                    }
                }
                if (f < thumbPosOnTickFloat) {
                    paint2 = this.f3430b0;
                    i2 = getLeftSideTrackSize();
                } else {
                    paint2 = this.f3430b0;
                    i2 = getRightSideTrackSize();
                }
                paint2.setStrokeWidth((float) i2);
                float[] fArr = this.f3426Y0;
                float f3 = fArr[i5];
                RectF rectF3 = this.f3451l1;
                canvas.drawLine(f3, rectF3.top, fArr[i5 + 1], rectF3.bottom, this.f3430b0);
            }
            return;
        }
        this.f3430b0.setColor(this.f3461q1);
        this.f3430b0.setStrokeWidth((float) this.f3457o1);
        RectF rectF4 = this.f3451l1;
        canvas.drawLine(rectF4.left, rectF4.top, rectF4.right, rectF4.bottom, this.f3430b0);
        this.f3430b0.setColor(this.f3459p1);
        this.f3430b0.setStrokeWidth((float) this.f3455n1);
        RectF rectF5 = this.f3453m1;
        canvas.drawLine(rectF5.left, rectF5.top, rectF5.right, rectF5.bottom, this.f3430b0);
    }

    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        ViewParent parent = getParent();
        if (parent == null) {
            return super.dispatchTouchEvent(motionEvent);
        }
        int action = motionEvent.getAction();
        if (action == 0) {
            parent.requestDisallowInterceptTouchEvent(true);
        } else if (action == 1 || action == 3) {
            parent.requestDisallowInterceptTouchEvent(false);
        }
        return super.dispatchTouchEvent(motionEvent);
    }

    /* renamed from: e */
    public final void mo4393e() {
        int i = this.f3427Z0;
        if (i != 0) {
            if (this.f3400C0) {
                this.f3406F0 = new String[i];
            }
            int i2 = 0;
            while (i2 < this.f3426Y0.length) {
                if (this.f3400C0) {
                    String[] strArr = this.f3406F0;
                    CharSequence[] charSequenceArr = this.f3416O0;
                    strArr[i2] = charSequenceArr == null ? mo4376a(this.f3396A0[i2]) : i2 < charSequenceArr.length ? String.valueOf(charSequenceArr[i2]) : "";
                    TextPaint textPaint = this.f3432c0;
                    String[] strArr2 = this.f3406F0;
                    textPaint.getTextBounds(strArr2[i2], 0, strArr2[i2].length(), this.f3436e0);
                    this.f3408G0[i2] = (float) this.f3436e0.width();
                    this.f3409H0[i2] = (this.f3460q0 * ((float) i2)) + ((float) this.f3450l0);
                }
                this.f3426Y0[i2] = (this.f3460q0 * ((float) i2)) + ((float) this.f3450l0);
                i2++;
            }
        }
    }

    /* renamed from: f */
    public final void mo4394f() {
        Drawable drawable = this.f3477y1;
        if (drawable != null) {
            if (drawable instanceof StateListDrawable) {
                try {
                    StateListDrawable stateListDrawable = (StateListDrawable) drawable;
                    Class<?> cls = stateListDrawable.getClass();
                    int intValue = ((Integer) cls.getMethod("getStateCount", new Class[0]).invoke(stateListDrawable, new Object[0])).intValue();
                    if (intValue == 2) {
                        Method method = cls.getMethod("getStateSet", new Class[]{Integer.TYPE});
                        Method method2 = cls.getMethod("getStateDrawable", new Class[]{Integer.TYPE});
                        for (int i = 0; i < intValue; i++) {
                            int[] iArr = (int[]) method.invoke(stateListDrawable, new Object[]{Integer.valueOf(i)});
                            if (iArr.length <= 0) {
                                this.f3471v1 = mo4375a((Drawable) method2.invoke(stateListDrawable, new Object[]{Integer.valueOf(i)}), true);
                            } else if (iArr[0] == 16842919) {
                                this.f3479z1 = mo4375a((Drawable) method2.invoke(stateListDrawable, new Object[]{Integer.valueOf(i)}), true);
                            } else {
                                throw new IllegalArgumentException("the state of the selector thumb drawable is wrong!");
                            }
                        }
                        return;
                    }
                    throw new IllegalArgumentException("the format of the selector thumb drawable is wrong!");
                } catch (Exception unused) {
                    drawable = this.f3477y1;
                }
            }
            this.f3471v1 = mo4375a(drawable, true);
            this.f3479z1 = this.f3471v1;
        }
    }

    /* renamed from: g */
    public final void mo4395g() {
        Drawable drawable = this.f3439f1;
        if (drawable instanceof StateListDrawable) {
            StateListDrawable stateListDrawable = (StateListDrawable) drawable;
            try {
                Class<?> cls = stateListDrawable.getClass();
                int intValue = ((Integer) cls.getMethod("getStateCount", new Class[0]).invoke(stateListDrawable, new Object[0])).intValue();
                if (intValue == 2) {
                    Method method = cls.getMethod("getStateSet", new Class[]{Integer.TYPE});
                    Method method2 = cls.getMethod("getStateDrawable", new Class[]{Integer.TYPE});
                    for (int i = 0; i < intValue; i++) {
                        int[] iArr = (int[]) method.invoke(stateListDrawable, new Object[]{Integer.valueOf(i)});
                        if (iArr.length <= 0) {
                            this.f3435d1 = mo4375a((Drawable) method2.invoke(stateListDrawable, new Object[]{Integer.valueOf(i)}), false);
                        } else if (iArr[0] == 16842913) {
                            this.f3437e1 = mo4375a((Drawable) method2.invoke(stateListDrawable, new Object[]{Integer.valueOf(i)}), false);
                        } else {
                            throw new IllegalArgumentException("the state of the selector TickMarks drawable is wrong!");
                        }
                    }
                    return;
                }
                throw new IllegalArgumentException("the format of the selector TickMarks drawable is wrong!");
            } catch (Exception unused) {
                drawable = this.f3439f1;
            }
        }
        this.f3435d1 = mo4375a(drawable, false);
        this.f3437e1 = this.f3435d1;
    }

    public ee3 getIndicator() {
        return this.f3417P0;
    }

    public View getIndicatorContentView() {
        return this.f3422U0;
    }

    public String getIndicatorTextString() {
        ge3 ge3 = this.f3425X0;
        return ge3 != null ? ge3.mo6076a(this.f3468u0) : mo4376a(this.f3468u0);
    }

    public float getMax() {
        return this.f3464s0;
    }

    public float getMin() {
        return this.f3466t0;
    }

    public he3 getOnSeekChangeListener() {
        return this.f3434d0;
    }

    public int getProgress() {
        return Math.round(this.f3468u0);
    }

    public synchronized float getProgressFloat() {
        return BigDecimal.valueOf((double) this.f3468u0).setScale(this.f3472w0, 4).floatValue();
    }

    public int getTickCount() {
        return this.f3427Z0;
    }

    /* renamed from: h */
    public final boolean mo4405h() {
        return this.f3399B1 || (this.f3427Z0 != 0 && this.f3400C0);
    }

    /* renamed from: i */
    public final void mo4406i() {
        if (this.f3398B0) {
            RectF rectF = this.f3453m1;
            float f = (float) this.f3450l0;
            rectF.left = f;
            rectF.top = ((float) this.f3456o0) + this.f3469u1;
            rectF.right = ((1.0f - ((this.f3468u0 - this.f3466t0) / getAmplitude())) * this.f3458p0) + f;
            RectF rectF2 = this.f3453m1;
            float f2 = rectF2.top;
            rectF2.bottom = f2;
            RectF rectF3 = this.f3451l1;
            rectF3.left = rectF2.right;
            rectF3.top = f2;
            rectF3.right = (float) (this.f3454n0 - this.f3452m0);
            rectF3.bottom = rectF2.bottom;
        } else {
            RectF rectF4 = this.f3451l1;
            rectF4.left = (float) this.f3450l0;
            rectF4.top = ((float) this.f3456o0) + this.f3469u1;
            rectF4.right = (((this.f3468u0 - this.f3466t0) * this.f3458p0) / getAmplitude()) + ((float) this.f3450l0);
            RectF rectF5 = this.f3451l1;
            rectF5.bottom = rectF5.top;
            RectF rectF6 = this.f3453m1;
            rectF6.left = rectF5.right;
            float f3 = rectF5.bottom;
            rectF6.top = f3;
            rectF6.right = (float) (this.f3454n0 - this.f3452m0);
            rectF6.bottom = f3;
        }
        if (mo4405h()) {
            this.f3432c0.getTextBounds("j", 0, 1, this.f3436e0);
            this.f3410I0 = ((float) this.f3456o0) + this.f3438f0 + ((float) Math.round(((float) this.f3436e0.height()) - this.f3432c0.descent())) + ((float) t53.m13070a(this.f3428a0, 3.0f));
            this.f3401C1 = this.f3410I0;
        }
        if (this.f3426Y0 != null) {
            mo4393e();
            if (this.f3427Z0 > 2) {
                this.f3468u0 = this.f3396A0[getClosestIndex()];
                this.f3440g0 = this.f3468u0;
            }
            mo4384b(this.f3468u0);
        }
    }

    /* renamed from: j */
    public final void mo4407j() {
        ee3 ee3;
        int i;
        int i2;
        if (this.f3420S0 && (ee3 = this.f3417P0) != null) {
            String indicatorTextString = getIndicatorTextString();
            View view = ee3.f4437m;
            if (view instanceof ce3) {
                ((ce3) view).setProgress(indicatorTextString);
            } else {
                TextView textView = ee3.f4428d;
                if (textView != null) {
                    textView.setText(indicatorTextString);
                }
            }
            this.f3422U0.measure(0, 0);
            int measuredWidth = this.f3422U0.getMeasuredWidth();
            float thumbCenterX = getThumbCenterX();
            if (this.f3444i0 == -1.0f) {
                DisplayMetrics displayMetrics = new DisplayMetrics();
                WindowManager windowManager = (WindowManager) this.f3428a0.getSystemService("window");
                if (windowManager != null) {
                    windowManager.getDefaultDisplay().getMetrics(displayMetrics);
                    this.f3444i0 = (float) displayMetrics.widthPixels;
                }
            }
            float f = (float) (measuredWidth / 2);
            int i3 = this.f3454n0;
            if (f + thumbCenterX > ((float) i3)) {
                int i4 = i3 - measuredWidth;
                i2 = (int) ((thumbCenterX - ((float) i4)) - f);
                i = i4;
            } else if (thumbCenterX - f < 0.0f) {
                i2 = -((int) (f - thumbCenterX));
                i = 0;
            } else {
                i = (int) (getThumbCenterX() - f);
                i2 = 0;
            }
            ee3 ee32 = this.f3417P0;
            ee32.mo5105a(ee32.f4436l, i, -1, -1, -1);
            ee3 ee33 = this.f3417P0;
            ee33.mo5105a(ee33.f4427c, i2, -1, -1, -1);
        }
    }

    public synchronized void onDraw(Canvas canvas) {
        mo4391d(canvas);
        mo4386b(canvas);
        mo4389c(canvas);
        mo4380a(canvas);
        if (this.f3399B1) {
            if (!this.f3400C0 || this.f3427Z0 <= 2) {
                this.f3432c0.setColor(this.f3403D1);
                canvas.drawText(mo4376a(this.f3468u0), getThumbCenterX(), this.f3401C1, this.f3432c0);
            }
        }
    }

    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        setMeasuredDimension(View.resolveSize(t53.m13070a(this.f3428a0, 170.0f), i), Math.round(this.f3438f0 + ((float) getPaddingTop()) + ((float) getPaddingBottom())) + this.f3404E0);
        mo4390d();
        mo4406i();
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable instanceof Bundle) {
            Bundle bundle = (Bundle) parcelable;
            setProgress(bundle.getFloat("isb_progress"));
            super.onRestoreInstanceState(bundle.getParcelable("isb_instance_state"));
            return;
        }
        super.onRestoreInstanceState(parcelable);
    }

    public Parcelable onSaveInstanceState() {
        Bundle bundle = new Bundle();
        bundle.putParcelable("isb_instance_state", super.onSaveInstanceState());
        bundle.putFloat("isb_progress", this.f3468u0);
        return bundle;
    }

    public void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        post(new C0486a());
    }

    /* JADX WARNING: Code restructure failed: missing block: B:9:0x001a, code lost:
        if (r0 != 3) goto L_0x0106;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r11) {
        /*
            r10 = this;
            boolean r0 = r10.f3474x0
            r1 = 0
            if (r0 == 0) goto L_0x010b
            boolean r0 = r10.isEnabled()
            if (r0 != 0) goto L_0x000d
            goto L_0x010b
        L_0x000d:
            int r0 = r11.getAction()
            r2 = 1
            if (r0 == 0) goto L_0x0075
            r3 = 3
            r4 = 2
            if (r0 == r2) goto L_0x0023
            if (r0 == r4) goto L_0x001e
            if (r0 == r3) goto L_0x0023
            goto L_0x0106
        L_0x001e:
            r10.mo4381a((android.view.MotionEvent) r11)
            goto L_0x0106
        L_0x0023:
            r10.f3462r0 = r1
            he3 r0 = r10.f3434d0
            if (r0 == 0) goto L_0x002c
            r0.mo6531b(r10)
        L_0x002c:
            int r0 = r10.f3427Z0
            if (r0 < r3) goto L_0x0061
            boolean r0 = r10.f3478z0
            if (r0 != 0) goto L_0x0035
            goto L_0x0061
        L_0x0035:
            boolean r0 = r10.f3407F1
            if (r0 != 0) goto L_0x003a
            goto L_0x0061
        L_0x003a:
            int r0 = r10.getClosestIndex()
            float r3 = r10.f3468u0
            float[] r4 = new float[r4]
            r5 = 0
            r4[r1] = r5
            float[] r1 = r10.f3396A0
            r1 = r1[r0]
            float r1 = r3 - r1
            float r1 = java.lang.Math.abs(r1)
            r4[r2] = r1
            android.animation.ValueAnimator r1 = android.animation.ValueAnimator.ofFloat(r4)
            r1.start()
            fe3 r4 = new fe3
            r4.<init>(r10, r3, r0)
            r1.addUpdateListener(r4)
            r1 = 1
        L_0x0061:
            if (r1 != 0) goto L_0x0066
            r10.invalidate()
        L_0x0066:
            ee3 r0 = r10.f3417P0
            if (r0 == 0) goto L_0x0106
            android.widget.PopupWindow r0 = r0.f4429e
            if (r0 != 0) goto L_0x0070
            goto L_0x0106
        L_0x0070:
            r0.dismiss()
            goto L_0x0106
        L_0x0075:
            r10.performClick()
            float r0 = r11.getX()
            float r3 = r11.getY()
            float r4 = r10.f3442h0
            r5 = -1082130432(0xffffffffbf800000, float:-1.0)
            int r4 = (r4 > r5 ? 1 : (r4 == r5 ? 0 : -1))
            if (r4 != 0) goto L_0x0093
            android.content.Context r4 = r10.f3428a0
            r5 = 1084227584(0x40a00000, float:5.0)
            int r4 = p000.t53.m13070a((android.content.Context) r4, (float) r5)
            float r4 = (float) r4
            r10.f3442h0 = r4
        L_0x0093:
            int r4 = r10.f3450l0
            float r4 = (float) r4
            float r5 = r10.f3442h0
            r6 = 1073741824(0x40000000, float:2.0)
            float r5 = r5 * r6
            float r4 = r4 - r5
            int r4 = (r0 > r4 ? 1 : (r0 == r4 ? 0 : -1))
            if (r4 < 0) goto L_0x00ae
            int r4 = r10.f3454n0
            int r7 = r10.f3452m0
            int r4 = r4 - r7
            float r4 = (float) r4
            float r5 = r5 + r4
            int r4 = (r0 > r5 ? 1 : (r0 == r5 ? 0 : -1))
            if (r4 > 0) goto L_0x00ae
            r4 = 1
            goto L_0x00af
        L_0x00ae:
            r4 = 0
        L_0x00af:
            android.graphics.RectF r5 = r10.f3451l1
            float r5 = r5.top
            float r7 = r10.f3469u1
            float r8 = r5 - r7
            float r9 = r10.f3442h0
            float r8 = r8 - r9
            int r8 = (r3 > r8 ? 1 : (r3 == r8 ? 0 : -1))
            if (r8 < 0) goto L_0x00c6
            float r5 = r5 + r7
            float r5 = r5 + r9
            int r3 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1))
            if (r3 > 0) goto L_0x00c6
            r3 = 1
            goto L_0x00c7
        L_0x00c6:
            r3 = 0
        L_0x00c7:
            if (r4 == 0) goto L_0x00cd
            if (r3 == 0) goto L_0x00cd
            r3 = 1
            goto L_0x00ce
        L_0x00cd:
            r3 = 0
        L_0x00ce:
            if (r3 == 0) goto L_0x0106
            boolean r3 = r10.f3476y0
            if (r3 == 0) goto L_0x00f9
            float r3 = r10.f3468u0
            r10.mo4384b((float) r3)
            boolean r3 = r10.f3398B0
            if (r3 == 0) goto L_0x00e0
            android.graphics.RectF r3 = r10.f3453m1
            goto L_0x00e2
        L_0x00e0:
            android.graphics.RectF r3 = r10.f3451l1
        L_0x00e2:
            float r3 = r3.right
            int r4 = r10.f3475x1
            float r4 = (float) r4
            float r4 = r4 / r6
            float r5 = r3 - r4
            int r5 = (r5 > r0 ? 1 : (r5 == r0 ? 0 : -1))
            if (r5 > 0) goto L_0x00f5
            float r4 = r4 + r3
            int r0 = (r0 > r4 ? 1 : (r0 == r4 ? 0 : -1))
            if (r0 > 0) goto L_0x00f5
            r0 = 1
            goto L_0x00f6
        L_0x00f5:
            r0 = 0
        L_0x00f6:
            if (r0 != 0) goto L_0x00f9
            return r1
        L_0x00f9:
            r10.f3462r0 = r2
            he3 r0 = r10.f3434d0
            if (r0 == 0) goto L_0x0102
            r0.mo6529a((com.warkiz.widget.IndicatorSeekBar) r10)
        L_0x0102:
            r10.mo4381a((android.view.MotionEvent) r11)
            return r2
        L_0x0106:
            boolean r11 = super.onTouchEvent(r11)
            return r11
        L_0x010b:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.warkiz.widget.IndicatorSeekBar.onTouchEvent(android.view.MotionEvent):boolean");
    }

    public boolean performClick() {
        return super.performClick();
    }

    public void setDecimalScale(int i) {
        this.f3472w0 = i;
    }

    public void setEnabled(boolean z) {
        float f;
        if (z != isEnabled()) {
            super.setEnabled(z);
            if (isEnabled()) {
                f = 1.0f;
                setAlpha(1.0f);
                if (!this.f3420S0) {
                    return;
                }
            } else {
                f = 0.3f;
                setAlpha(0.3f);
                if (!this.f3420S0) {
                    return;
                }
            }
            this.f3422U0.setAlpha(f);
        }
    }

    public void setFloatProgress(boolean z) {
        this.f3470v0 = z;
    }

    public void setIndicatorStayAlways(boolean z) {
        this.f3420S0 = z;
    }

    public void setIndicatorTextCallback(ge3 ge3) {
        this.f3425X0 = ge3;
        mo4393e();
        mo4407j();
    }

    public synchronized void setMax(float f) {
        this.f3464s0 = Math.max(this.f3466t0, f);
        mo4387c();
        mo4377a();
        mo4406i();
        invalidate();
        mo4407j();
    }

    public synchronized void setMin(float f) {
        this.f3466t0 = Math.min(this.f3464s0, f);
        mo4387c();
        mo4377a();
        mo4406i();
        invalidate();
        mo4407j();
    }

    public void setOnSeekChangeListener(he3 he3) {
        this.f3434d0 = he3;
    }

    public synchronized void setProgress(float f) {
        this.f3440g0 = this.f3468u0;
        if (f < this.f3466t0) {
            f = this.f3466t0;
        } else if (f > this.f3464s0) {
            f = this.f3464s0;
        }
        this.f3468u0 = f;
        if (!this.f3478z0 && this.f3427Z0 > 2) {
            this.f3468u0 = this.f3396A0[getClosestIndex()];
        }
        setSeekListener(false);
        mo4384b(this.f3468u0);
        postInvalidate();
        mo4407j();
    }

    public void setR2L(boolean z) {
        this.f3398B0 = z;
        requestLayout();
        invalidate();
        mo4407j();
    }

    public void setThumbAdjustAuto(boolean z) {
        this.f3407F1 = z;
    }

    public void setThumbDrawable(Drawable drawable) {
        if (drawable == null) {
            this.f3477y1 = null;
            this.f3471v1 = null;
            this.f3479z1 = null;
        } else {
            this.f3477y1 = drawable;
            this.f3467t1 = ((float) Math.min(t53.m13070a(this.f3428a0, 30.0f), this.f3475x1)) / 2.0f;
            this.f3469u1 = this.f3467t1;
            this.f3438f0 = Math.max(this.f3469u1, this.f3433c1) * 2.0f;
            mo4394f();
        }
        requestLayout();
        invalidate();
    }

    public synchronized void setTickCount(int i) {
        if (this.f3427Z0 < 0 || this.f3427Z0 > 50) {
            throw new IllegalArgumentException("the Argument: TICK COUNT must be limited between (0-50), Now is " + this.f3427Z0);
        }
        this.f3427Z0 = i;
        mo4377a();
        mo4393e();
        mo4390d();
        mo4406i();
        invalidate();
        mo4407j();
    }

    public void setTickMarksDrawable(Drawable drawable) {
        if (drawable == null) {
            this.f3439f1 = null;
            this.f3435d1 = null;
            this.f3437e1 = null;
        } else {
            this.f3439f1 = drawable;
            this.f3433c1 = ((float) Math.min(t53.m13070a(this.f3428a0, 30.0f), this.f3447j1)) / 2.0f;
            this.f3438f0 = Math.max(this.f3469u1, this.f3433c1) * 2.0f;
            mo4395g();
        }
        invalidate();
    }

    public void setUserSeekAble(boolean z) {
        this.f3474x0 = z;
    }

    /* JADX WARNING: Removed duplicated region for block: B:13:0x0041  */
    /* JADX WARNING: Removed duplicated region for block: B:16:0x0070  */
    /* JADX WARNING: Removed duplicated region for block: B:17:0x0075  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo4381a(android.view.MotionEvent r8) {
        /*
            r7 = this;
            float r0 = r8.getX()
            int r1 = r7.f3450l0
            float r2 = (float) r1
            int r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r0 >= 0) goto L_0x000c
            goto L_0x001a
        L_0x000c:
            float r0 = r8.getX()
            int r1 = r7.f3454n0
            int r2 = r7.f3452m0
            int r1 = r1 - r2
            float r2 = (float) r1
            int r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r0 <= 0) goto L_0x001c
        L_0x001a:
            float r8 = (float) r1
            goto L_0x0020
        L_0x001c:
            float r8 = r8.getX()
        L_0x0020:
            int r0 = r7.f3427Z0
            r1 = 2
            if (r0 <= r1) goto L_0x003d
            boolean r0 = r7.f3478z0
            if (r0 != 0) goto L_0x003d
            int r0 = r7.f3450l0
            float r0 = (float) r0
            float r8 = r8 - r0
            float r0 = r7.f3460q0
            float r8 = r8 / r0
            int r8 = java.lang.Math.round(r8)
            float r0 = r7.f3460q0
            float r8 = (float) r8
            float r0 = r0 * r8
            int r8 = r7.f3450l0
            float r8 = (float) r8
            float r8 = r8 + r0
        L_0x003d:
            boolean r0 = r7.f3398B0
            if (r0 == 0) goto L_0x004a
            float r0 = r7.f3458p0
            float r0 = r0 - r8
            int r8 = r7.f3450l0
            int r8 = r8 * 2
            float r8 = (float) r8
            float r8 = r8 + r0
        L_0x004a:
            float r0 = r7.f3468u0
            r7.f3440g0 = r0
            float r0 = r7.f3466t0
            float r1 = r7.getAmplitude()
            int r2 = r7.f3450l0
            float r2 = (float) r2
            float r8 = r8 - r2
            float r8 = r8 * r1
            float r1 = r7.f3458p0
            float r8 = r8 / r1
            float r8 = r8 + r0
            r7.f3468u0 = r8
            float r8 = r7.f3468u0
            r7.mo4384b((float) r8)
            r8 = 1
            r7.setSeekListener(r8)
            r7.invalidate()
            boolean r0 = r7.f3420S0
            if (r0 == 0) goto L_0x0075
            r7.mo4407j()
            goto L_0x0126
        L_0x0075:
            ee3 r0 = r7.f3417P0
            if (r0 != 0) goto L_0x007b
            goto L_0x0126
        L_0x007b:
            android.widget.PopupWindow r1 = r0.f4429e
            r2 = 26
            r3 = 0
            if (r1 == 0) goto L_0x0083
            goto L_0x00b8
        L_0x0083:
            int r1 = r0.f4434j
            if (r1 == 0) goto L_0x00b8
            android.view.View r1 = r0.f4436l
            if (r1 == 0) goto L_0x00b8
            r1.measure(r3, r3)
            android.view.View r1 = r0.f4436l
            int r4 = android.os.Build.VERSION.SDK_INT
            r5 = 23
            if (r4 >= r5) goto L_0x00a2
            android.widget.FrameLayout r1 = new android.widget.FrameLayout
            android.content.Context r4 = r0.f4433i
            r1.<init>(r4)
            android.view.View r4 = r0.f4436l
            r1.addView(r4)
        L_0x00a2:
            android.widget.PopupWindow r4 = new android.widget.PopupWindow
            r5 = -1
            r6 = -2
            r4.<init>(r1, r5, r6, r3)
            r0.f4429e = r4
            int r1 = android.os.Build.VERSION.SDK_INT
            android.widget.PopupWindow r0 = r0.f4429e
            if (r1 < r2) goto L_0x00b4
            int r1 = p000.le3.SimpleFadeAnimation
            goto L_0x00b5
        L_0x00b4:
            r1 = 0
        L_0x00b5:
            r0.setAnimationStyle(r1)
        L_0x00b8:
            ee3 r0 = r7.f3417P0
            android.widget.PopupWindow r0 = r0.f4429e
            if (r0 == 0) goto L_0x00c5
            boolean r0 = r0.isShowing()
            if (r0 == 0) goto L_0x00c5
            goto L_0x00c6
        L_0x00c5:
            r8 = 0
        L_0x00c6:
            if (r8 == 0) goto L_0x00d2
            ee3 r8 = r7.f3417P0
            float r0 = r7.getThumbCenterX()
            r8.mo5103a((float) r0)
            goto L_0x0126
        L_0x00d2:
            ee3 r8 = r7.f3417P0
            float r0 = r7.getThumbCenterX()
            com.warkiz.widget.IndicatorSeekBar r1 = r8.f4435k
            boolean r1 = r1.isEnabled()
            if (r1 == 0) goto L_0x0126
            com.warkiz.widget.IndicatorSeekBar r1 = r8.f4435k
            int r1 = r1.getVisibility()
            if (r1 == 0) goto L_0x00e9
            goto L_0x0126
        L_0x00e9:
            r8.mo5107b()
            android.widget.PopupWindow r1 = r8.f4429e
            if (r1 == 0) goto L_0x0123
            android.widget.LinearLayout r1 = r8.f4430f
            r1.measure(r3, r3)
            android.widget.PopupWindow r1 = r8.f4429e
            com.warkiz.widget.IndicatorSeekBar r4 = r8.f4435k
            int r5 = r4.getMeasuredHeight()
            android.widget.LinearLayout r6 = r8.f4430f
            int r6 = r6.getMeasuredHeight()
            int r6 = r6 + r5
            com.warkiz.widget.IndicatorSeekBar r5 = r8.f4435k
            int r5 = r5.getPaddingTop()
            int r6 = r6 - r5
            int r5 = r8.f4431g
            int r6 = r6 + r5
            int r5 = -r6
            int r6 = android.os.Build.VERSION.SDK_INT
            if (r6 < r2) goto L_0x0117
            r1.showAsDropDown(r4, r3, r5)
            goto L_0x0123
        L_0x0117:
            ae3 r2 = new ae3
            android.content.Context r6 = r4.getContext()
            r2.<init>(r6, r4)
            r1.showAsDropDown(r2, r3, r5)
        L_0x0123:
            r8.mo5103a((float) r0)
        L_0x0126:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.warkiz.widget.IndicatorSeekBar.mo4381a(android.view.MotionEvent):void");
    }
}
