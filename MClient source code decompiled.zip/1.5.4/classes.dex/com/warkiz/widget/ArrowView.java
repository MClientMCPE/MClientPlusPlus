package com.warkiz.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

public class ArrowView extends View {

    /* renamed from: a0 */
    public final int f3392a0;

    /* renamed from: b0 */
    public final int f3393b0;

    /* renamed from: c0 */
    public final Path f3394c0;

    /* renamed from: d0 */
    public final Paint f3395d0;

    public ArrowView(Context context) {
        this(context, (AttributeSet) null);
    }

    public ArrowView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ArrowView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f3392a0 = t53.m13070a(context, 12.0f);
        this.f3393b0 = t53.m13070a(context, 7.0f);
        this.f3394c0 = new Path();
        this.f3394c0.moveTo(0.0f, 0.0f);
        this.f3394c0.lineTo((float) this.f3392a0, 0.0f);
        this.f3394c0.lineTo(((float) this.f3392a0) / 2.0f, (float) this.f3393b0);
        this.f3394c0.close();
        this.f3395d0 = new Paint();
        this.f3395d0.setAntiAlias(true);
        this.f3395d0.setStrokeWidth(1.0f);
    }

    public void onDraw(Canvas canvas) {
        canvas.drawPath(this.f3394c0, this.f3395d0);
    }

    public void onMeasure(int i, int i2) {
        setMeasuredDimension(this.f3392a0, this.f3393b0);
    }

    public void setColor(int i) {
        this.f3395d0.setColor(i);
        invalidate();
    }
}
