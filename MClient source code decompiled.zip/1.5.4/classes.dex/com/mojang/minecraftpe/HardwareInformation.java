package com.mojang.minecraftpe;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Build;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import java.util.Random;

public class HardwareInformation {
    public static final char[] HEX_CHARS = "0123456789abcdef".toCharArray();
    public Context ctx;

    /* renamed from: pm */
    public PackageManager f3390pm;

    public HardwareInformation(Context context) {
        this.ctx = context;
        this.f3390pm = context.getPackageManager();
    }

    public static String generateHexNumber(int i) {
        StringBuilder sb = new StringBuilder(i);
        Random random = new Random();
        for (int i2 = 0; i2 < i; i2++) {
            char[] cArr = HEX_CHARS;
            sb.append(cArr[random.nextInt(cArr.length)]);
        }
        return sb.toString();
    }

    public static String getAndroidVersion() {
        StringBuilder a = C0789gk.m5562a("Android ");
        a.append(Build.VERSION.RELEASE);
        return a.toString();
    }

    public static String getBoard() {
        return Build.BOARD;
    }

    public static String getCPUFeatures() {
        return "";
    }

    public static String getCPUName() {
        return "";
    }

    public static String getCPUType() {
        return Build.VERSION.SDK_INT >= 21 ? TextUtils.join(" ", Build.SUPPORTED_ABIS) : Build.CPU_ABI;
    }

    public static String getDeviceModelName() {
        String str = Build.MANUFACTURER;
        String str2 = Build.MODEL;
        return str2.startsWith(str) ? str2.toUpperCase() : C0789gk.m5558a(str, " ", str2);
    }

    public static int getNumCores() {
        return 2;
    }

    public static String getSerialNumber() {
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences((Context) MainActivity.currentMainActivity.get());
        String string = defaultSharedPreferences.getString("fake_hardware.serial_number", (String) null);
        if (string != null) {
            return string;
        }
        String generateHexNumber = generateHexNumber(8);
        defaultSharedPreferences.edit().putString("fake_hardware.serial_number", generateHexNumber).apply();
        return generateHexNumber;
    }

    public String getInstallerPackageName() {
        try {
            return this.f3390pm.getInstallerPackageName("com.mojang.minecraftpe");
        } catch (IllegalArgumentException unused) {
            return "";
        }
    }

    public boolean getIsRooted() {
        return false;
    }

    public String getSecureId() {
        SharedPreferences defaultSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this.ctx);
        String string = defaultSharedPreferences.getString("fake_hardware.secure_android_id", (String) null);
        if (string != null) {
            return string;
        }
        String generateHexNumber = generateHexNumber(16);
        defaultSharedPreferences.edit().putString("fake_hardware.secure_android_id", generateHexNumber).apply();
        return generateHexNumber;
    }

    public int getSignaturesHashCode() {
        int i = 0;
        try {
            Signature[] signatureArr = this.f3390pm.getPackageInfo("com.mojang.minecraftpe", 64).signatures;
            int length = signatureArr.length;
            int i2 = 0;
            while (i < length) {
                try {
                    i2 ^= signatureArr[i].hashCode();
                    i++;
                } catch (PackageManager.NameNotFoundException unused) {
                    return i2;
                }
            }
            return i2;
        } catch (PackageManager.NameNotFoundException unused2) {
            return 0;
        }
    }
}
