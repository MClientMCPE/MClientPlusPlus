package com.mojang.minecraftpe;

public class CrashManager {
    public String getCrashUploadURI() {
        return "http://localhost:1234/";
    }

    public String getExceptionUploadURI() {
        return "http://localhost:1234/";
    }

    public String uploadCrashFile(String str, String str2, String str3) {
        return null;
    }
}
