package com.mojang.minecraftpe.packagesource;

public class StubPackageSource extends PackageSource {
    public final PackageSourceListener listener;

    public StubPackageSource(PackageSourceListener packageSourceListener) {
        this.listener = packageSourceListener;
    }

    public void abortDownload() {
    }

    public void destructor() {
    }

    public void downloadFiles(String str, long j, boolean z, boolean z2) {
        this.listener.onDownloadStateChanged(false, false, false, false, true, 0, 8);
    }

    public String getDownloadDirectoryPath() {
        return null;
    }

    public String getMountPath(String str) {
        return null;
    }

    public void mountFiles(String str) {
    }

    public void pauseDownload() {
    }

    public void resumeDownload() {
    }

    public void resumeDownloadOnCell() {
    }

    public void unmountFiles(String str) {
    }
}
