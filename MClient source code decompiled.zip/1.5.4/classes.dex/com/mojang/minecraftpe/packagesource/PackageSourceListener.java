package com.mojang.minecraftpe.packagesource;

public interface PackageSourceListener {
    void onDownloadStateChanged(boolean z, boolean z2, boolean z3, boolean z4, boolean z5, int i, int i2);
}
