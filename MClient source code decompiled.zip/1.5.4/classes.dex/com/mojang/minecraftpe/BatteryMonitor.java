package com.mojang.minecraftpe;

public class BatteryMonitor {
    public int getBatteryLevel() {
        return -1;
    }

    public int getBatteryScale() {
        return -1;
    }

    public int getBatteryStatus() {
        return -1;
    }

    public int getBatteryTemperature() {
        return -1;
    }
}
