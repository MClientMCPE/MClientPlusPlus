package com.mojang.minecraftpe.store;

public class Product {
    public String mCurrencyCode;
    public String mId;
    public String mPrice;
    public String mUnformattedPrice;
}
