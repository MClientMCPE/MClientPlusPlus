package com.mojang.minecraftpe.store;

public class ExtraLicenseResponseData {
    public long getRetryAttempts() {
        return 0;
    }

    public long getRetryUntilTime() {
        return 0;
    }

    public long getValidationTime() {
        return 0;
    }
}
