package com.mojang.minecraftpe.store;

import android.util.Log;

public class StubStore implements Store {
    public final StoreListener listener;
    public Product[] products;

    public StubStore(StoreListener storeListener) {
        this.listener = storeListener;
        storeListener.onStoreInitialized(true);
    }

    public void acknowledgePurchase(String str, String str2) {
        Log.i("StubStore", "acknowledgePurchase: " + str + " " + str2);
    }

    public void destructor() {
    }

    public ExtraLicenseResponseData getExtraLicenseData() {
        return new ExtraLicenseResponseData();
    }

    public String getProductSkuPrefix() {
        return "";
    }

    public String getRealmsSkuPrefix() {
        return "";
    }

    public String getStoreId() {
        return "android.googleplay";
    }

    public boolean hasVerifiedLicense() {
        return true;
    }

    public void purchase(String str, boolean z, String str2) {
        Log.i("StubStore", "purchase: " + str + " " + z + " " + str2);
        this.listener.onPurchaseFailed(str);
    }

    public void queryProducts(String[] strArr) {
        StringBuilder a = C0789gk.m5562a("queryProducts: ");
        a.append(strArr.length);
        Log.i("StubStore", a.toString());
        Product[] productArr = new Product[strArr.length];
        for (int i = 0; i < strArr.length; i++) {
            productArr[i] = new Product();
            productArr[i].mId = strArr[i];
            productArr[i].mPrice = "PRICELESS";
            productArr[i].mUnformattedPrice = "PRICELESS";
            productArr[i].mCurrencyCode = "YEN";
        }
        this.products = productArr;
        this.listener.onQueryProductsSuccess(productArr);
    }

    public void queryPurchases() {
        Log.i("StubStore", "queryPurchases");
        this.listener.onQueryPurchasesSuccess(new Purchase[0]);
    }

    public boolean receivedLicenseResponse() {
        return true;
    }
}
