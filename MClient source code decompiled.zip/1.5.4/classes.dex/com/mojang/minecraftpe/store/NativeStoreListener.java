package com.mojang.minecraftpe.store;

public class NativeStoreListener implements StoreListener {

    /* renamed from: id */
    public final long f3391id;

    public NativeStoreListener(long j) {
        this.f3391id = j;
    }

    public native void onPurchaseCanceled(long j, String str);

    public void onPurchaseCanceled(String str) {
        onPurchaseCanceled(this.f3391id, str);
    }

    public native void onPurchaseFailed(long j, String str);

    public void onPurchaseFailed(String str) {
        onPurchaseFailed(this.f3391id, str);
    }

    public native void onPurchaseSuccessful(long j, String str);

    public void onPurchaseSuccessful(String str) {
        onPurchaseSuccessful(this.f3391id, str);
    }

    public void onQueryProductsFail() {
        onQueryProductsFail(this.f3391id);
    }

    public native void onQueryProductsFail(long j);

    public native void onQueryProductsSuccess(long j, Product[] productArr);

    public void onQueryProductsSuccess(Product[] productArr) {
        onQueryProductsSuccess(this.f3391id, productArr);
    }

    public void onQueryPurchasesFail() {
        onQueryPurchasesFail(this.f3391id);
    }

    public native void onQueryPurchasesFail(long j);

    public native void onQueryPurchasesSuccess(long j, Purchase[] purchaseArr);

    public void onQueryPurchasesSuccess(Purchase[] purchaseArr) {
        onQueryPurchasesSuccess(this.f3391id, purchaseArr);
    }

    public native void onStoreInitialized(long j, boolean z);

    public void onStoreInitialized(boolean z) {
        onStoreInitialized(this.f3391id, z);
    }
}
