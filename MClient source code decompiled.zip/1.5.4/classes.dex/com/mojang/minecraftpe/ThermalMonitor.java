package com.mojang.minecraftpe;

public class ThermalMonitor {
    public boolean getLowPowerModeEnabled() {
        return false;
    }
}
