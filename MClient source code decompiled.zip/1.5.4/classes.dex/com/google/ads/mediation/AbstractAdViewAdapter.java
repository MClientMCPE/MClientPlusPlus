package com.google.ads.mediation;

import android.content.Context;
import android.location.Location;
import android.os.Bundle;
import android.os.RemoteException;
import android.view.View;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.mediation.MediationBannerAdapter;
import com.google.android.gms.ads.mediation.MediationInterstitialAdapter;
import com.google.android.gms.ads.mediation.MediationNativeAdapter;
import com.google.android.gms.ads.reward.mediation.MediationRewardedVideoAdAdapter;
import com.google.android.gms.internal.ads.zzbfy;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;
import p000.C0115am;
import p000.C0379cm;
import p000.C0706fl;
import p000.C2156vl;
import p000.C2368yl;
import p000.C2459zl;

public abstract class AbstractAdViewAdapter implements MediationBannerAdapter, MediationNativeAdapter, C2464zo, C1172kp, MediationRewardedVideoAdAdapter, zzbfy {
    public static final String AD_UNIT_ID_PARAMETER = "pubid";
    public C0871hl zzlq;
    public C1166kl zzlr;
    public C0616el zzls;
    public Context zzlt;
    public C1166kl zzlu;
    public C1542op zzlv;
    public final C1471np zzlw = new C2152vk(this);

    /* renamed from: com.google.ads.mediation.AbstractAdViewAdapter$a */
    public static class C0387a extends C2161vo {

        /* renamed from: p */
        public final C2368yl f2838p;

        public C0387a(C2368yl ylVar) {
            String str;
            String str2;
            String str3;
            String str4;
            String str5;
            this.f2838p = ylVar;
            this.f16366h = ylVar.mo12967b().toString();
            C2381yv yvVar = (C2381yv) ylVar;
            this.f16367i = yvVar.f18033b;
            String str6 = null;
            try {
                str = yvVar.f18032a.mo8611u();
            } catch (RemoteException e) {
                C0680fe.m4830c("", (Throwable) e);
                str = null;
            }
            this.f16368j = str.toString();
            this.f16369k = yvVar.f18034c;
            try {
                str2 = yvVar.f18032a.mo8612v();
            } catch (RemoteException e2) {
                C0680fe.m4830c("", (Throwable) e2);
                str2 = null;
            }
            this.f16370l = str2.toString();
            if (ylVar.mo12968c() != null) {
                this.f16371m = ylVar.mo12968c().doubleValue();
            }
            try {
                str3 = yvVar.f18032a.mo8606G();
            } catch (RemoteException e3) {
                C0680fe.m4830c("", (Throwable) e3);
                str3 = null;
            }
            if (str3 != null) {
                try {
                    str5 = yvVar.f18032a.mo8606G();
                } catch (RemoteException e4) {
                    C0680fe.m4830c("", (Throwable) e4);
                    str5 = null;
                }
                this.f16372n = str5.toString();
            }
            try {
                str4 = yvVar.f18032a.mo8605B();
            } catch (RemoteException e5) {
                C0680fe.m4830c("", (Throwable) e5);
                str4 = null;
            }
            if (str4 != null) {
                try {
                    str6 = yvVar.f18032a.mo8605B();
                } catch (RemoteException e6) {
                    C0680fe.m4830c("", (Throwable) e6);
                }
                this.f16373o = str6.toString();
            }
            this.f15666a = true;
            this.f15667b = true;
            try {
                if (yvVar.f18032a.getVideoController() != null) {
                    yvVar.f18035d.mo8797a(yvVar.f18032a.getVideoController());
                }
            } catch (RemoteException e7) {
                C0680fe.m4830c("Exception occurred while getting video controller", (Throwable) e7);
            }
            this.f15671f = yvVar.f18035d;
        }

        /* renamed from: a */
        public final void mo3086a(View view) {
            if (view instanceof C2225wl) {
                ((C2225wl) view).setNativeAd(this.f2838p);
            }
            C2291xl xlVar = C2291xl.f17295c.get(view);
            if (xlVar != null) {
                xlVar.mo12618a((C2232wr) this.f2838p.mo4487a());
            }
        }
    }

    /* renamed from: com.google.ads.mediation.AbstractAdViewAdapter$b */
    public static class C0388b extends C0263ap {

        /* renamed from: s */
        public final C0379cm f2839s;

        /* JADX WARNING: Removed duplicated region for block: B:38:0x007f A[Catch:{ RemoteException -> 0x0084 }] */
        /* JADX WARNING: Removed duplicated region for block: B:45:0x0097 A[Catch:{ RemoteException -> 0x00a3 }] */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public C0388b(p000.C0379cm r8) {
            /*
                r7 = this;
                java.lang.String r0 = ""
                r7.<init>()
                r7.f2839s = r8
                java.lang.String r1 = r8.mo2969a()
                r7.f1476a = r1
                ix r8 = (p000.C0974ix) r8
                java.util.List<ul$b> r1 = r8.f8008b
                r7.f1477b = r1
                r1 = 0
                hx r2 = r8.f8007a     // Catch:{ RemoteException -> 0x001b }
                java.lang.String r2 = r2.mo6738u()     // Catch:{ RemoteException -> 0x001b }
                goto L_0x0020
            L_0x001b:
                r2 = move-exception
                p000.C0680fe.m4830c((java.lang.String) r0, (java.lang.Throwable) r2)
                r2 = r1
            L_0x0020:
                r7.f1478c = r2
                mv r2 = r8.f8009c
                r7.f1479d = r2
                hx r2 = r8.f8007a     // Catch:{ RemoteException -> 0x002d }
                java.lang.String r2 = r2.mo6739v()     // Catch:{ RemoteException -> 0x002d }
                goto L_0x0032
            L_0x002d:
                r2 = move-exception
                p000.C0680fe.m4830c((java.lang.String) r0, (java.lang.Throwable) r2)
                r2 = r1
            L_0x0032:
                r7.f1480e = r2
                hx r2 = r8.f8007a     // Catch:{ RemoteException -> 0x003b }
                java.lang.String r2 = r2.mo6731F()     // Catch:{ RemoteException -> 0x003b }
                goto L_0x0040
            L_0x003b:
                r2 = move-exception
                p000.C0680fe.m4830c((java.lang.String) r0, (java.lang.Throwable) r2)
                r2 = r1
            L_0x0040:
                r7.f1481f = r2
                hx r2 = r8.f8007a     // Catch:{ RemoteException -> 0x0054 }
                double r2 = r2.mo6742y()     // Catch:{ RemoteException -> 0x0054 }
                r4 = -4616189618054758400(0xbff0000000000000, double:-1.0)
                int r6 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
                if (r6 != 0) goto L_0x004f
                goto L_0x0058
            L_0x004f:
                java.lang.Double r2 = java.lang.Double.valueOf(r2)     // Catch:{ RemoteException -> 0x0054 }
                goto L_0x0059
            L_0x0054:
                r2 = move-exception
                p000.C0680fe.m4830c((java.lang.String) r0, (java.lang.Throwable) r2)
            L_0x0058:
                r2 = r1
            L_0x0059:
                r7.f1482g = r2
                hx r2 = r8.f8007a     // Catch:{ RemoteException -> 0x0062 }
                java.lang.String r2 = r2.mo6732G()     // Catch:{ RemoteException -> 0x0062 }
                goto L_0x0067
            L_0x0062:
                r2 = move-exception
                p000.C0680fe.m4830c((java.lang.String) r0, (java.lang.Throwable) r2)
                r2 = r1
            L_0x0067:
                r7.f1483h = r2
                hx r2 = r8.f8007a     // Catch:{ RemoteException -> 0x0070 }
                java.lang.String r2 = r2.mo6730B()     // Catch:{ RemoteException -> 0x0070 }
                goto L_0x0075
            L_0x0070:
                r2 = move-exception
                p000.C0680fe.m4830c((java.lang.String) r0, (java.lang.Throwable) r2)
                r2 = r1
            L_0x0075:
                r7.f1484i = r2
                hx r2 = r8.f8007a     // Catch:{ RemoteException -> 0x0084 }
                wr r2 = r2.mo6743z()     // Catch:{ RemoteException -> 0x0084 }
                if (r2 == 0) goto L_0x0088
                java.lang.Object r1 = p000.C2298xr.m15922z(r2)     // Catch:{ RemoteException -> 0x0084 }
                goto L_0x0088
            L_0x0084:
                r2 = move-exception
                p000.C0680fe.m4830c((java.lang.String) r0, (java.lang.Throwable) r2)
            L_0x0088:
                r7.f1489n = r1
                r0 = 1
                r7.f1491p = r0
                r7.f1492q = r0
                hx r0 = r8.f8007a     // Catch:{ RemoteException -> 0x00a3 }
                cy2 r0 = r0.getVideoController()     // Catch:{ RemoteException -> 0x00a3 }
                if (r0 == 0) goto L_0x00a9
                ml r0 = r8.f8010d     // Catch:{ RemoteException -> 0x00a3 }
                hx r1 = r8.f8007a     // Catch:{ RemoteException -> 0x00a3 }
                cy2 r1 = r1.getVideoController()     // Catch:{ RemoteException -> 0x00a3 }
                r0.mo8797a((p000.cy2) r1)     // Catch:{ RemoteException -> 0x00a3 }
                goto L_0x00a9
            L_0x00a3:
                r0 = move-exception
                java.lang.String r1 = "Exception occurred while getting video controller"
                p000.C0680fe.m4830c((java.lang.String) r1, (java.lang.Throwable) r0)
            L_0x00a9:
                ml r8 = r8.f8010d
                r7.f1485j = r8
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.ads.mediation.AbstractAdViewAdapter.C0388b.<init>(cm):void");
        }

        /* renamed from: a */
        public final void mo2100a(View view, Map<String, View> map, Map<String, View> map2) {
            if (view instanceof C0549dm) {
                ((C0549dm) view).setNativeAd(this.f2839s);
                return;
            }
            C2291xl xlVar = C2291xl.f17295c.get(view);
            if (xlVar != null) {
                xlVar.mo12618a((C2232wr) this.f2839s.mo2970b());
            }
        }
    }

    /* renamed from: com.google.ads.mediation.AbstractAdViewAdapter$c */
    public static class C0389c extends C2229wo {

        /* renamed from: n */
        public final C2459zl f2840n;

        public C0389c(C2459zl zlVar) {
            String str;
            String str2;
            this.f2840n = zlVar;
            this.f16817h = zlVar.mo4488b().toString();
            C0497cw cwVar = (C0497cw) zlVar;
            this.f16818i = cwVar.f3581b;
            String str3 = null;
            try {
                str = cwVar.f3580a.mo2676u();
            } catch (RemoteException e) {
                C0680fe.m4830c("", (Throwable) e);
                str = null;
            }
            this.f16819j = str.toString();
            C1370mv mvVar = cwVar.f3582c;
            if (mvVar != null) {
                this.f16820k = mvVar;
            }
            try {
                str2 = cwVar.f3580a.mo2677v();
            } catch (RemoteException e2) {
                C0680fe.m4830c("", (Throwable) e2);
                str2 = null;
            }
            this.f16821l = str2.toString();
            try {
                str3 = cwVar.f3580a.mo2671F();
            } catch (RemoteException e3) {
                C0680fe.m4830c("", (Throwable) e3);
            }
            this.f16822m = str3.toString();
            this.f15666a = true;
            this.f15667b = true;
            try {
                if (cwVar.f3580a.getVideoController() != null) {
                    cwVar.f3583d.mo8797a(cwVar.f3580a.getVideoController());
                }
            } catch (RemoteException e4) {
                C0680fe.m4830c("Exception occurred while getting video controller", (Throwable) e4);
            }
            this.f15671f = cwVar.f3583d;
        }

        /* renamed from: a */
        public final void mo3086a(View view) {
            if (view instanceof C2225wl) {
                ((C2225wl) view).setNativeAd(this.f2840n);
            }
            C2291xl xlVar = C2291xl.f17295c.get(view);
            if (xlVar != null) {
                xlVar.mo12618a((C2232wr) this.f2840n.mo4487a());
            }
        }
    }

    /* renamed from: com.google.ads.mediation.AbstractAdViewAdapter$d */
    public static final class C0390d extends C0548dl implements iv2 {

        /* renamed from: X */
        public final AbstractAdViewAdapter f2841X;

        /* renamed from: Y */
        public final C1711qo f2842Y;

        public C0390d(AbstractAdViewAdapter abstractAdViewAdapter, C1711qo qoVar) {
            this.f2841X = abstractAdViewAdapter;
            this.f2842Y = qoVar;
        }

        /* renamed from: a */
        public final void mo3087a() {
            ((o40) this.f2842Y).mo9506b((MediationInterstitialAdapter) this.f2841X);
        }

        /* renamed from: a */
        public final void mo3088a(int i) {
            ((o40) this.f2842Y).mo9498a((MediationInterstitialAdapter) this.f2841X, i);
        }

        /* renamed from: c */
        public final void mo3089c() {
            ((o40) this.f2842Y).mo9509c((MediationInterstitialAdapter) this.f2841X);
        }

        /* renamed from: d */
        public final void mo3090d() {
            ((o40) this.f2842Y).mo9512d((MediationInterstitialAdapter) this.f2841X);
        }

        /* renamed from: e */
        public final void mo3091e() {
            ((o40) this.f2842Y).mo9515e((MediationInterstitialAdapter) this.f2841X);
        }

        /* renamed from: k */
        public final void mo2882k() {
            ((o40) this.f2842Y).mo9497a((MediationInterstitialAdapter) this.f2841X);
        }
    }

    /* renamed from: com.google.ads.mediation.AbstractAdViewAdapter$e */
    public static final class C0391e extends C0548dl implements C1538ol, iv2 {

        /* renamed from: X */
        public final AbstractAdViewAdapter f2843X;

        /* renamed from: Y */
        public final C1347mo f2844Y;

        public C0391e(AbstractAdViewAdapter abstractAdViewAdapter, C1347mo moVar) {
            this.f2843X = abstractAdViewAdapter;
            this.f2844Y = moVar;
        }

        /* renamed from: a */
        public final void mo3087a() {
            ((o40) this.f2844Y).mo9505b((MediationBannerAdapter) this.f2843X);
        }

        /* renamed from: a */
        public final void mo3088a(int i) {
            ((o40) this.f2844Y).mo9495a((MediationBannerAdapter) this.f2843X, i);
        }

        /* renamed from: a */
        public final void mo2876a(String str, String str2) {
            ((o40) this.f2844Y).mo9496a((MediationBannerAdapter) this.f2843X, str, str2);
        }

        /* renamed from: c */
        public final void mo3089c() {
            ((o40) this.f2844Y).mo9508c((MediationBannerAdapter) this.f2843X);
        }

        /* renamed from: d */
        public final void mo3090d() {
            ((o40) this.f2844Y).mo9511d((MediationBannerAdapter) this.f2843X);
        }

        /* renamed from: e */
        public final void mo3091e() {
            ((o40) this.f2844Y).mo9514e((MediationBannerAdapter) this.f2843X);
        }

        /* renamed from: k */
        public final void mo2882k() {
            ((o40) this.f2844Y).mo9494a((MediationBannerAdapter) this.f2843X);
        }
    }

    /* renamed from: com.google.ads.mediation.AbstractAdViewAdapter$f */
    public static final class C0392f extends C0548dl implements C2368yl.C2369a, C2459zl.C2460a, C0115am.C0116a, C0115am.C0117b, C0379cm.C0381b {

        /* renamed from: X */
        public final AbstractAdViewAdapter f2845X;

        /* renamed from: Y */
        public final C1872so f2846Y;

        public C0392f(AbstractAdViewAdapter abstractAdViewAdapter, C1872so soVar) {
            this.f2845X = abstractAdViewAdapter;
            this.f2846Y = soVar;
        }

        /* renamed from: a */
        public final void mo3087a() {
            ((o40) this.f2846Y).mo9507b((MediationNativeAdapter) this.f2845X);
        }

        /* renamed from: a */
        public final void mo3088a(int i) {
            ((o40) this.f2846Y).mo9500a((MediationNativeAdapter) this.f2845X, i);
        }

        /* renamed from: b */
        public final void mo3092b() {
            ((o40) this.f2846Y).mo9510c((MediationNativeAdapter) this.f2845X);
        }

        /* renamed from: c */
        public final void mo3089c() {
            ((o40) this.f2846Y).mo9513d((MediationNativeAdapter) this.f2845X);
        }

        /* renamed from: d */
        public final void mo3090d() {
        }

        /* renamed from: e */
        public final void mo3091e() {
            ((o40) this.f2846Y).mo9516e((MediationNativeAdapter) this.f2845X);
        }

        /* renamed from: k */
        public final void mo2882k() {
            ((o40) this.f2846Y).mo9499a((MediationNativeAdapter) this.f2845X);
        }
    }

    private final C0706fl zza(Context context, C1089jo joVar, Bundle bundle, Bundle bundle2) {
        C0706fl.C0707a aVar = new C0706fl.C0707a();
        Date b = joVar.mo7684b();
        if (b != null) {
            aVar.f5465a.f10734g = b;
        }
        int g = joVar.mo7689g();
        if (g != 0) {
            aVar.f5465a.f10737j = g;
        }
        Set<String> d = joVar.mo7686d();
        if (d != null) {
            for (String add : d) {
                aVar.f5465a.f10728a.add(add);
            }
        }
        Location f = joVar.mo7688f();
        if (f != null) {
            aVar.f5465a.f10738k = f;
        }
        if (joVar.mo7685c()) {
            af0 af0 = kw2.f9317j.f9318a;
            aVar.mo5727a(af0.m468a(context));
        }
        if (joVar.mo7687e() != -1) {
            int i = 1;
            if (joVar.mo7687e() != 1) {
                i = 0;
            }
            aVar.f5465a.f10742o = i;
        }
        aVar.f5465a.f10743p = joVar.mo7683a();
        aVar.mo5726a(AdMobAdapter.class, zza(bundle, bundle2));
        return new C0706fl(aVar, (C1940tp) null);
    }

    public String getAdUnitId(Bundle bundle) {
        return bundle.getString(AD_UNIT_ID_PARAMETER);
    }

    public View getBannerView() {
        return this.zzlq;
    }

    public Bundle getInterstitialAdapterInfo() {
        Bundle bundle = new Bundle();
        bundle.putInt("capabilities", 1);
        return bundle;
    }

    public cy2 getVideoController() {
        C1342ml videoController;
        C0871hl hlVar = this.zzlq;
        if (hlVar == null || (videoController = hlVar.getVideoController()) == null) {
            return null;
        }
        return videoController.mo8796a();
    }

    public void initialize(Context context, C1089jo joVar, String str, C1542op opVar, Bundle bundle, Bundle bundle2) {
        this.zzlt = context.getApplicationContext();
        this.zzlv = opVar;
        ((m90) this.zzlv).mo8655e(this);
    }

    public boolean isInitialized() {
        return this.zzlv != null;
    }

    public void loadAd(C1089jo joVar, Bundle bundle, Bundle bundle2) {
        Context context = this.zzlt;
        if (context == null || this.zzlv == null) {
            C0680fe.m4890n("AdMobAdapter.loadAd called before initialize.");
            return;
        }
        this.zzlu = new C1166kl(context);
        C1166kl klVar = this.zzlu;
        klVar.f9148a.f11601j = true;
        klVar.mo8034a(getAdUnitId(bundle));
        C1166kl klVar2 = this.zzlu;
        klVar2.f9148a.mo9381a(this.zzlw);
        C1166kl klVar3 = this.zzlu;
        klVar3.f9148a.mo9380a((C1265lp) new C2224wk(this));
        this.zzlu.mo8033a(zza(this.zzlt, joVar, bundle2, bundle));
    }

    public void onDestroy() {
        C0871hl hlVar = this.zzlq;
        if (hlVar != null) {
            hlVar.mo7054a();
            this.zzlq = null;
        }
        if (this.zzlr != null) {
            this.zzlr = null;
        }
        if (this.zzls != null) {
            this.zzls = null;
        }
        if (this.zzlu != null) {
            this.zzlu = null;
        }
    }

    public void onImmersiveModeUpdated(boolean z) {
        C1166kl klVar = this.zzlr;
        if (klVar != null) {
            klVar.f9148a.mo9382a(z);
        }
        C1166kl klVar2 = this.zzlu;
        if (klVar2 != null) {
            klVar2.f9148a.mo9382a(z);
        }
    }

    public void onPause() {
        C0871hl hlVar = this.zzlq;
        if (hlVar != null) {
            hlVar.mo7056b();
        }
    }

    public void onResume() {
        C0871hl hlVar = this.zzlq;
        if (hlVar != null) {
            hlVar.mo7057c();
        }
    }

    public void requestBannerAd(Context context, C1347mo moVar, Bundle bundle, C0790gl glVar, C1089jo joVar, Bundle bundle2) {
        this.zzlq = new C0871hl(context);
        this.zzlq.setAdSize(new C0790gl(glVar.f6214a, glVar.f6215b));
        this.zzlq.setAdUnitId(getAdUnitId(bundle));
        this.zzlq.setAdListener(new C0391e(this, moVar));
        this.zzlq.mo7055a(zza(context, joVar, bundle2, bundle));
    }

    public void requestInterstitialAd(Context context, C1711qo qoVar, Bundle bundle, C1089jo joVar, Bundle bundle2) {
        this.zzlr = new C1166kl(context);
        this.zzlr.mo8034a(getAdUnitId(bundle));
        this.zzlr.mo8032a((C0548dl) new C0390d(this, qoVar));
        this.zzlr.mo8033a(zza(context, joVar, bundle2, bundle));
    }

    public void requestNativeAd(Context context, C1872so soVar, Bundle bundle, C2295xo xoVar, Bundle bundle2) {
        C2156vl vlVar;
        C0616el elVar;
        rz2 rz2;
        C0392f fVar = new C0392f(this, soVar);
        String string = bundle.getString(AD_UNIT_ID_PARAMETER);
        C0680fe.m4697a(context, (Object) "context cannot be null");
        rw2 a = kw2.f9317j.f9319b.mo13373a(context, string, new n30());
        try {
            a.mo10759a((mw2) new nv2(fVar));
        } catch (RemoteException e) {
            C0680fe.m4844d("Failed to set AdListener.", (Throwable) e);
        }
        t40 t40 = (t40) xoVar;
        if (t40.f14672g == null) {
            vlVar = null;
        } else {
            C2156vl.C2157a aVar = new C2156vl.C2157a();
            C0496cv cvVar = t40.f14672g;
            aVar.f16172a = cvVar.f3560Y;
            aVar.f16173b = cvVar.f3561Z;
            aVar.f16175d = cvVar.f3562a0;
            if (cvVar.f3559X >= 2) {
                aVar.f16177f = cvVar.f3563b0;
            }
            C0496cv cvVar2 = t40.f14672g;
            if (cvVar2.f3559X >= 3 && (rz2 = cvVar2.f3564c0) != null) {
                aVar.f16176e = new C1467nl(rz2);
            }
            vlVar = new C2156vl(aVar, (C0617em) null);
        }
        if (vlVar != null) {
            try {
                a.mo10753a(new C0496cv(vlVar));
            } catch (RemoteException e2) {
                C0680fe.m4844d("Failed to specify native ad options", (Throwable) e2);
            }
        }
        List<String> list = t40.f14673h;
        boolean z = false;
        if (list != null && list.contains("6")) {
            try {
                a.mo10761a((C2240ww) new C1782rx(fVar));
            } catch (RemoteException e3) {
                C0680fe.m4844d("Failed to add google native ad listener", (Throwable) e3);
            }
        }
        List<String> list2 = t40.f14673h;
        if (list2 != null && (list2.contains("2") || t40.f14673h.contains("6"))) {
            try {
                a.mo10756a((C1100jw) new C1372mx(fVar));
            } catch (RemoteException e4) {
                C0680fe.m4844d("Failed to add app install ad listener", (Throwable) e4);
            }
        }
        List<String> list3 = t40.f14673h;
        if (list3 != null && (list3.contains("1") || t40.f14673h.contains("6"))) {
            try {
                a.mo10757a((C1191kw) new C1649px(fVar));
            } catch (RemoteException e5) {
                C0680fe.m4844d("Failed to add content ad listener", (Throwable) e5);
            }
        }
        List<String> list4 = t40.f14673h;
        if (list4 != null && list4.contains("3")) {
            z = true;
        }
        if (z) {
            for (String next : t40.f14675j.keySet()) {
                C0392f fVar2 = t40.f14675j.get(next).booleanValue() ? fVar : null;
                try {
                    a.mo10755a(next, new C1722qx(fVar), fVar2 == null ? null : new C1574ox(fVar2));
                } catch (RemoteException e6) {
                    C0680fe.m4844d("Failed to add custom template ad listener", (Throwable) e6);
                }
            }
        }
        try {
            elVar = new C0616el(context, a.mo10763m0());
        } catch (RemoteException e7) {
            C0680fe.m4830c("Failed to build AdLoader.", (Throwable) e7);
            elVar = null;
        }
        this.zzls = elVar;
        this.zzls.mo5204a(zza(context, xoVar, bundle2, bundle));
    }

    public void showInterstitial() {
        this.zzlr.f9148a.mo9384c();
    }

    public void showVideo() {
        this.zzlu.mo8031a();
    }

    public abstract Bundle zza(Bundle bundle, Bundle bundle2);
}
