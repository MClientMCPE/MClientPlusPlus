package com.google.ads.mediation.customevent;

import android.app.Activity;

@Deprecated
public interface CustomEventInterstitial extends C1707qk {
    void requestInterstitialAd(C1866sk skVar, Activity activity, String str, String str2, C1165kk kkVar, Object obj);

    void showInterstitial();
}
