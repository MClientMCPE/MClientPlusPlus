package com.google.ads.mediation.customevent;

import android.app.Activity;

@Deprecated
public interface CustomEventBanner extends C1707qk {
    void requestBannerAd(C1764rk rkVar, Activity activity, String str, String str2, C1067jk jkVar, C1165kk kkVar, Object obj);
}
