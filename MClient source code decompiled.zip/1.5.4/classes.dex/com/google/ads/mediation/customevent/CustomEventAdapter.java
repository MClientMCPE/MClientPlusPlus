package com.google.ads.mediation.customevent;

import android.app.Activity;
import android.view.View;
import com.google.ads.mediation.MediationBannerAdapter;
import com.google.ads.mediation.MediationInterstitialAdapter;
import com.google.android.gms.common.annotation.KeepName;

@KeepName
public final class CustomEventAdapter implements MediationBannerAdapter<C0620ep, C2058uk>, MediationInterstitialAdapter<C0620ep, C2058uk> {

    /* renamed from: a */
    public View f2847a;

    /* renamed from: b */
    public CustomEventBanner f2848b;

    /* renamed from: c */
    public CustomEventInterstitial f2849c;

    /* renamed from: com.google.ads.mediation.customevent.CustomEventAdapter$a */
    public class C0393a implements C1866sk {
        public C0393a(CustomEventAdapter customEventAdapter, CustomEventAdapter customEventAdapter2, C1464nk nkVar) {
        }
    }

    /* renamed from: com.google.ads.mediation.customevent.CustomEventAdapter$b */
    public static final class C0394b implements C1764rk {
        public C0394b(CustomEventAdapter customEventAdapter, C1340mk mkVar) {
        }
    }

    /* renamed from: a */
    public static <T> T m2690a(String str) {
        try {
            return Class.forName(str).newInstance();
        } catch (Throwable th) {
            String message = th.getMessage();
            StringBuilder sb = new StringBuilder(C0789gk.m5548a(message, C0789gk.m5548a(str, 46)));
            sb.append("Could not instantiate custom event adapter: ");
            sb.append(str);
            sb.append(". ");
            sb.append(message);
            C0680fe.m4893p(sb.toString());
            return null;
        }
    }

    public final void destroy() {
        CustomEventBanner customEventBanner = this.f2848b;
        if (customEventBanner != null) {
            customEventBanner.destroy();
        }
        CustomEventInterstitial customEventInterstitial = this.f2849c;
        if (customEventInterstitial != null) {
            customEventInterstitial.destroy();
        }
    }

    public final Class<C0620ep> getAdditionalParametersType() {
        return C0620ep.class;
    }

    public final View getBannerView() {
        return this.f2847a;
    }

    public final Class<C2058uk> getServerParametersType() {
        return C2058uk.class;
    }

    public final void requestBannerAd(C1340mk mkVar, Activity activity, C2058uk ukVar, C1067jk jkVar, C1165kk kkVar, C0620ep epVar) {
        Object obj;
        this.f2848b = (CustomEventBanner) m2690a(ukVar.f15622b);
        if (this.f2848b == null) {
            ((v40) mkVar).mo11836a((MediationBannerAdapter<?, ?>) this, C0870hk.INTERNAL_ERROR);
            return;
        }
        if (epVar == null) {
            obj = null;
        } else {
            obj = epVar.f4740a.get(ukVar.f15621a);
        }
        Activity activity2 = activity;
        this.f2848b.requestBannerAd(new C0394b(this, mkVar), activity2, ukVar.f15621a, ukVar.f15623c, jkVar, kkVar, obj);
    }

    public final void requestInterstitialAd(C1464nk nkVar, Activity activity, C2058uk ukVar, C1165kk kkVar, C0620ep epVar) {
        Object obj;
        this.f2849c = (CustomEventInterstitial) m2690a(ukVar.f15622b);
        if (this.f2849c == null) {
            ((v40) nkVar).mo11837a((MediationInterstitialAdapter<?, ?>) this, C0870hk.INTERNAL_ERROR);
            return;
        }
        if (epVar == null) {
            obj = null;
        } else {
            obj = epVar.f4740a.get(ukVar.f15621a);
        }
        Activity activity2 = activity;
        this.f2849c.requestInterstitialAd(new C0393a(this, this, nkVar), activity2, ukVar.f15621a, ukVar.f15623c, kkVar, obj);
    }

    public final void showInterstitial() {
        this.f2849c.showInterstitial();
    }
}
