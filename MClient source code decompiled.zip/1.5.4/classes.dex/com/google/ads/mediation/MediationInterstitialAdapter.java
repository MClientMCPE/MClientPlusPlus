package com.google.ads.mediation;

import android.app.Activity;
import p000.C1535ok;
import p000.C1627pk;

@Deprecated
public interface MediationInterstitialAdapter<ADDITIONAL_PARAMETERS extends C1627pk, SERVER_PARAMETERS extends C1535ok> extends C1256lk<ADDITIONAL_PARAMETERS, SERVER_PARAMETERS> {
    void requestInterstitialAd(C1464nk nkVar, Activity activity, SERVER_PARAMETERS server_parameters, C1165kk kkVar, ADDITIONAL_PARAMETERS additional_parameters);

    void showInterstitial();
}
