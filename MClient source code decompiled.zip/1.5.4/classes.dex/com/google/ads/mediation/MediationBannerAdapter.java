package com.google.ads.mediation;

import android.app.Activity;
import android.view.View;
import p000.C1535ok;
import p000.C1627pk;

@Deprecated
public interface MediationBannerAdapter<ADDITIONAL_PARAMETERS extends C1627pk, SERVER_PARAMETERS extends C1535ok> extends C1256lk<ADDITIONAL_PARAMETERS, SERVER_PARAMETERS> {
    View getBannerView();

    void requestBannerAd(C1340mk mkVar, Activity activity, SERVER_PARAMETERS server_parameters, C1067jk jkVar, C1165kk kkVar, ADDITIONAL_PARAMETERS additional_parameters);
}
