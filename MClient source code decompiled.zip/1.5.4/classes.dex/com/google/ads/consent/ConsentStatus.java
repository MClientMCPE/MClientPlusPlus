package com.google.ads.consent;

public enum ConsentStatus {
    UNKNOWN,
    NON_PERSONALIZED,
    PERSONALIZED
}
