package com.google.ads.consent;

public interface ConsentInfoUpdateListener {
    /* renamed from: a */
    void mo3046a(ConsentStatus consentStatus);

    /* renamed from: a */
    void mo3047a(String str);
}
