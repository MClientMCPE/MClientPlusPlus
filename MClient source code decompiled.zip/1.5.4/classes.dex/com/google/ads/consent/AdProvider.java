package com.google.ads.consent;

public final class AdProvider {
    @s93("company_id")

    /* renamed from: id */
    public String f2836id;
    @s93("company_name")
    public String name;
    @s93("policy_url")
    public String privacyPolicyUrlString;

    /* renamed from: a */
    public String mo3005a() {
        return this.f2836id;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || AdProvider.class != obj.getClass()) {
            return false;
        }
        return this.f2836id.equals(((AdProvider) obj).f2836id);
    }

    public int hashCode() {
        return this.f2836id.hashCode();
    }
}
