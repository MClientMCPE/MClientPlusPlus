package com.google.ads.consent;

import java.util.HashSet;

public class ConsentData {
    public static final String SDK_PLATFORM = "android";
    public static final String SDK_VERSION = "1.0.8";
    @s93("providers")
    public HashSet<AdProvider> adProviders = new HashSet<>();
    @s93("consent_source")
    public String consentSource;
    @s93("consent_state")
    public ConsentStatus consentStatus = ConsentStatus.UNKNOWN;
    @s93("consented_providers")
    public HashSet<AdProvider> consentedAdProviders = new HashSet<>();
    @s93("has_any_npa_pub_id")
    public boolean hasNonPersonalizedPublisherId = false;
    @s93("is_request_in_eea_or_unknown")
    public boolean isRequestLocationInEeaOrUnknown = false;
    @s93("pub_ids")
    public HashSet<String> publisherIds = new HashSet<>();
    @s93("raw_response")
    public String rawResponse = "";
    @s93("plat")
    public final String sdkPlatformString = SDK_PLATFORM;
    @s93("version")
    public final String sdkVersionString = SDK_VERSION;
    @s93("tag_for_under_age_of_consent")
    public Boolean underAgeOfConsent = false;

    /* renamed from: a */
    public HashSet<AdProvider> mo3008a() {
        return this.adProviders;
    }

    /* renamed from: a */
    public void mo3009a(ConsentStatus consentStatus2) {
        this.consentStatus = consentStatus2;
    }

    /* renamed from: a */
    public void mo3010a(String str) {
        this.consentSource = str;
    }

    /* renamed from: a */
    public void mo3011a(HashSet<AdProvider> hashSet) {
        this.adProviders = hashSet;
    }

    /* renamed from: a */
    public void mo3012a(boolean z) {
        this.hasNonPersonalizedPublisherId = z;
    }

    /* renamed from: b */
    public ConsentStatus mo3013b() {
        return this.consentStatus;
    }

    /* renamed from: b */
    public void mo3014b(String str) {
        this.rawResponse = str;
    }

    /* renamed from: b */
    public void mo3015b(HashSet<AdProvider> hashSet) {
        this.consentedAdProviders = hashSet;
    }

    /* renamed from: b */
    public void mo3016b(boolean z) {
        this.isRequestLocationInEeaOrUnknown = z;
    }

    /* renamed from: c */
    public HashSet<AdProvider> mo3017c() {
        return this.consentedAdProviders;
    }

    /* renamed from: c */
    public void mo3018c(HashSet<String> hashSet) {
        this.publisherIds = hashSet;
    }

    /* renamed from: d */
    public String mo3019d() {
        return this.sdkPlatformString;
    }

    /* renamed from: e */
    public String mo3020e() {
        return this.sdkVersionString;
    }

    /* renamed from: f */
    public boolean mo3021f() {
        return this.hasNonPersonalizedPublisherId;
    }

    /* renamed from: g */
    public boolean mo3022g() {
        return this.isRequestLocationInEeaOrUnknown;
    }

    /* renamed from: h */
    public boolean mo3023h() {
        return this.underAgeOfConsent.booleanValue();
    }
}
