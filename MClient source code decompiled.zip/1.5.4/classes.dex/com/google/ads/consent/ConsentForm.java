package com.google.ads.consent;

import android.annotation.TargetApi;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.text.TextUtils;
import android.util.Base64;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.ByteArrayOutputStream;
import java.net.URL;
import java.util.HashMap;

public class ConsentForm {
    public final boolean adFreeOption;
    public final URL appPrivacyPolicyURL;
    public final Context context;
    public final Dialog dialog;
    public final ConsentFormListener listener;
    public LoadState loadState;
    public final boolean nonPersonalizedAdsOption;
    public final boolean personalizedAdsOption;
    public final WebView webView;

    public static class Builder {
        public boolean adFreeOption = false;
        public final URL appPrivacyPolicyURL;
        public final Context context;
        public ConsentFormListener listener;
        public boolean nonPersonalizedAdsOption = false;
        public boolean personalizedAdsOption = false;

        public Builder(Context context2, URL url) {
            this.context = context2;
            this.appPrivacyPolicyURL = url;
            if (this.appPrivacyPolicyURL == null) {
                throw new IllegalArgumentException("Must provide valid app privacy policy url to create a ConsentForm");
            }
        }

        /* renamed from: a */
        public Builder mo3038a(ConsentFormListener consentFormListener) {
            this.listener = consentFormListener;
            return this;
        }

        /* renamed from: a */
        public ConsentForm mo3039a() {
            return new ConsentForm(this, (C03841) null);
        }

        /* renamed from: b */
        public Builder mo3040b() {
            this.nonPersonalizedAdsOption = true;
            return this;
        }

        /* renamed from: c */
        public Builder mo3041c() {
            this.personalizedAdsOption = true;
            return this;
        }
    }

    public enum LoadState {
        NOT_READY,
        LOADING,
        LOADED
    }

    public /* synthetic */ ConsentForm(Builder builder, C03841 r3) {
        this.context = builder.context;
        this.listener = builder.listener == null ? new ConsentFormListener() {
        } : builder.listener;
        this.personalizedAdsOption = builder.personalizedAdsOption;
        this.nonPersonalizedAdsOption = builder.nonPersonalizedAdsOption;
        this.adFreeOption = builder.adFreeOption;
        this.appPrivacyPolicyURL = builder.appPrivacyPolicyURL;
        this.dialog = new Dialog(this.context, 16973840);
        this.loadState = LoadState.NOT_READY;
        this.webView = new WebView(this.context);
        this.webView.setBackgroundColor(0);
        this.dialog.setContentView(this.webView);
        this.dialog.setCancelable(false);
        this.webView.getSettings().setJavaScriptEnabled(true);
        this.webView.setWebViewClient(new WebViewClient() {
            public boolean isInternalRedirect;

            /* renamed from: a */
            public final void mo3030a(String str) {
                if (mo3031b(str)) {
                    this.isInternalRedirect = true;
                    Uri parse = Uri.parse(str);
                    String queryParameter = parse.getQueryParameter("action");
                    String queryParameter2 = parse.getQueryParameter("status");
                    String queryParameter3 = parse.getQueryParameter("url");
                    char c = 65535;
                    int hashCode = queryParameter.hashCode();
                    if (hashCode != -1370505102) {
                        if (hashCode != 150940456) {
                            if (hashCode == 1671672458 && queryParameter.equals("dismiss")) {
                                c = 1;
                            }
                        } else if (queryParameter.equals("browser")) {
                            c = 2;
                        }
                    } else if (queryParameter.equals("load_complete")) {
                        c = 0;
                    }
                    if (c == 0) {
                        ConsentForm.this.mo3028b(queryParameter2);
                    } else if (c == 1) {
                        this.isInternalRedirect = false;
                        ConsentForm.this.mo3026a(queryParameter2);
                    } else if (c == 2) {
                        ConsentForm.this.mo3029c(queryParameter3);
                    }
                }
            }

            /* renamed from: b */
            public final boolean mo3031b(String str) {
                return !TextUtils.isEmpty(str) && str.startsWith("consent://");
            }

            public void onLoadResource(WebView webView, String str) {
                mo3030a(str);
            }

            public void onPageFinished(WebView webView, String str) {
                if (!this.isInternalRedirect) {
                    ConsentForm.this.mo3025a(webView);
                }
                super.onPageFinished(webView, str);
            }

            public void onReceivedError(WebView webView, WebResourceRequest webResourceRequest, WebResourceError webResourceError) {
                super.onReceivedError(webView, webResourceRequest, webResourceError);
                ConsentForm consentForm = ConsentForm.this;
                consentForm.loadState = LoadState.NOT_READY;
                consentForm.listener.mo3044a(webResourceError.toString());
            }

            @TargetApi(24)
            public boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest webResourceRequest) {
                String uri = webResourceRequest.getUrl().toString();
                if (!mo3031b(uri)) {
                    return false;
                }
                mo3030a(uri);
                return true;
            }

            public boolean shouldOverrideUrlLoading(WebView webView, String str) {
                if (!mo3031b(str)) {
                    return false;
                }
                mo3030a(str);
                return true;
            }
        });
    }

    /* renamed from: a */
    public void mo3024a() {
        LoadState loadState2 = this.loadState;
        if (loadState2 == LoadState.LOADING) {
            this.listener.mo3044a("Cannot simultaneously load multiple consent forms.");
        } else if (loadState2 == LoadState.LOADED) {
            this.listener.mo3042a();
        } else {
            this.loadState = LoadState.LOADING;
            this.webView.loadUrl("file:///android_asset/consentform.html");
        }
    }

    /* renamed from: a */
    public final void mo3025a(WebView webView2) {
        HashMap hashMap = new HashMap();
        Context context2 = this.context;
        hashMap.put("app_name", context2.getApplicationInfo().loadLabel(context2.getPackageManager()).toString());
        Context context3 = this.context;
        Drawable applicationIcon = context3.getPackageManager().getApplicationIcon(context3.getApplicationInfo());
        Bitmap createBitmap = Bitmap.createBitmap(applicationIcon.getIntrinsicWidth(), applicationIcon.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(createBitmap);
        applicationIcon.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        applicationIcon.draw(canvas);
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        createBitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
        String valueOf = String.valueOf(Base64.encodeToString(byteArrayOutputStream.toByteArray(), 0));
        hashMap.put("app_icon", valueOf.length() != 0 ? "data:image/png;base64,".concat(valueOf) : new String("data:image/png;base64,"));
        hashMap.put("offer_personalized", Boolean.valueOf(this.personalizedAdsOption));
        hashMap.put("offer_non_personalized", Boolean.valueOf(this.nonPersonalizedAdsOption));
        hashMap.put("offer_ad_free", Boolean.valueOf(this.adFreeOption));
        hashMap.put("is_request_in_eea_or_unknown", Boolean.valueOf(ConsentInformation.m2647a(this.context).mo3059e()));
        hashMap.put("app_privacy_url", this.appPrivacyPolicyURL);
        ConsentData h = ConsentInformation.m2647a(this.context).mo3062h();
        hashMap.put("plat", h.mo3019d());
        hashMap.put("consent_info", h);
        String a = new x83().mo12471a((Object) hashMap);
        HashMap hashMap2 = new HashMap();
        hashMap2.put("info", a);
        HashMap hashMap3 = new HashMap();
        hashMap3.put("args", hashMap2);
        webView2.loadUrl(String.format("javascript:%s(%s)", new Object[]{"setUpConsentDialog", new x83().mo12471a((Object) hashMap3)}));
    }

    /* renamed from: a */
    public final void mo3026a(String str) {
        ConsentStatus consentStatus;
        this.loadState = LoadState.NOT_READY;
        this.dialog.dismiss();
        if (TextUtils.isEmpty(str)) {
            this.listener.mo3044a("No information provided.");
        } else if (str.contains("Error")) {
            this.listener.mo3044a(str);
        } else {
            char c = 65535;
            int hashCode = str.hashCode();
            boolean z = false;
            if (hashCode != -1152655096) {
                if (hashCode != -258041904) {
                    if (hashCode == 1666911234 && str.equals("non_personalized")) {
                        c = 1;
                    }
                } else if (str.equals("personalized")) {
                    c = 0;
                }
            } else if (str.equals("ad_free")) {
                c = 2;
            }
            if (c == 0) {
                consentStatus = ConsentStatus.PERSONALIZED;
            } else if (c != 1) {
                consentStatus = ConsentStatus.UNKNOWN;
                if (c == 2) {
                    z = true;
                }
            } else {
                consentStatus = ConsentStatus.NON_PERSONALIZED;
            }
            ConsentInformation.m2647a(this.context).mo3051a(consentStatus, "form");
            this.listener.mo3043a(consentStatus, Boolean.valueOf(z));
        }
    }

    /* renamed from: b */
    public void mo3027b() {
        ConsentFormListener consentFormListener;
        String str;
        if (this.loadState != LoadState.LOADED) {
            consentFormListener = this.listener;
            str = "Consent form is not ready to be displayed.";
        } else if (ConsentInformation.m2647a(this.context).mo3060f()) {
            consentFormListener = this.listener;
            str = "Error: tagged for under age of consent";
        } else {
            this.dialog.getWindow().setLayout(-1, -1);
            this.dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            this.dialog.setOnShowListener(new DialogInterface.OnShowListener() {
                public void onShow(DialogInterface dialogInterface) {
                    ConsentForm.this.listener.mo3045b();
                }
            });
            this.dialog.show();
            if (!this.dialog.isShowing()) {
                this.listener.mo3044a("Consent form could not be displayed.");
                return;
            }
            return;
        }
        consentFormListener.mo3044a(str);
    }

    /* renamed from: b */
    public final void mo3028b(String str) {
        if (TextUtils.isEmpty(str)) {
            this.loadState = LoadState.NOT_READY;
            this.listener.mo3044a("No information");
        } else if (str.contains("Error")) {
            this.loadState = LoadState.NOT_READY;
            this.listener.mo3044a(str);
        } else {
            this.loadState = LoadState.LOADED;
            this.listener.mo3042a();
        }
    }

    /* renamed from: c */
    public final void mo3029c(String str) {
        if (TextUtils.isEmpty(str)) {
            this.listener.mo3044a("No valid URL for browser navigation.");
            return;
        }
        try {
            this.context.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
        } catch (ActivityNotFoundException unused) {
            this.listener.mo3044a("No Activity found to handle browser intent.");
        }
    }
}
