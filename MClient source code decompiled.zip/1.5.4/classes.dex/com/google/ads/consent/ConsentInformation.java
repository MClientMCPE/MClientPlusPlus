package com.google.ads.consent;

import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Type;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

public class ConsentInformation {
    public static final String CONSENT_DATA_KEY = "consent_string";
    public static final String MOBILE_ADS_SERVER_URL = "https://adservice.google.com/getconfig/pubvendors";
    public static final String PREFERENCES_FILE_KEY = "mobileads_consent";
    public static final String TAG = "ConsentInformation";
    public static ConsentInformation instance;
    public final Context context;
    public DebugGeography debugGeography = DebugGeography.DEBUG_GEOGRAPHY_DISABLED;
    public String hashedDeviceId = mo3057c();
    public List<String> testDevices = new ArrayList();

    public static class AdNetworkLookupResponse {
        @s93("company_ids")
        public List<String> companyIds;
        @s93("ad_network_id")

        /* renamed from: id */
        public String f2837id;
        @s93("is_npa")
        public boolean isNPA;
        @s93("lookup_failed")
        public boolean lookupFailed;
        @s93("not_found")
        public boolean notFound;
    }

    public static class ConsentInfoUpdateResponse {
        public String responseInfo;
        public boolean success;

        public ConsentInfoUpdateResponse(boolean z, String str) {
            this.success = z;
            this.responseInfo = str;
        }
    }

    public static class ConsentInfoUpdateTask extends AsyncTask<Void, Void, ConsentInfoUpdateResponse> {
        public static final String UPDATE_SUCCESS = "Consent update successful.";
        public final ConsentInformation consentInformation;
        public final ConsentInfoUpdateListener listener;
        public final List<String> publisherIds;
        public final String url;

        public ConsentInfoUpdateTask(String str, ConsentInformation consentInformation2, List<String> list, ConsentInfoUpdateListener consentInfoUpdateListener) {
            this.url = str;
            this.listener = consentInfoUpdateListener;
            this.publisherIds = list;
            this.consentInformation = consentInformation2;
        }

        /* renamed from: a */
        public ConsentInfoUpdateResponse mo3063a() {
            String join = TextUtils.join(",", this.publisherIds);
            ConsentData h = this.consentInformation.mo3062h();
            Uri.Builder appendQueryParameter = Uri.parse(this.url).buildUpon().appendQueryParameter("pubs", join).appendQueryParameter("es", "2").appendQueryParameter("plat", h.mo3019d()).appendQueryParameter("v", h.mo3020e());
            if (this.consentInformation.mo3061g() && this.consentInformation.mo3056b() != DebugGeography.DEBUG_GEOGRAPHY_DISABLED) {
                appendQueryParameter = appendQueryParameter.appendQueryParameter("debug_geo", this.consentInformation.mo3056b().mo3068a().toString());
            }
            try {
                HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(appendQueryParameter.build().toString()).openConnection();
                if (httpURLConnection.getResponseCode() != 200) {
                    return new ConsentInfoUpdateResponse(false, httpURLConnection.getResponseMessage());
                }
                String a = mo3064a(httpURLConnection.getInputStream());
                httpURLConnection.disconnect();
                this.consentInformation.mo3053a(a, this.publisherIds);
                return new ConsentInfoUpdateResponse(true, UPDATE_SUCCESS);
            } catch (Exception e) {
                return new ConsentInfoUpdateResponse(false, e.getLocalizedMessage());
            }
        }

        /* renamed from: a */
        public final String mo3064a(InputStream inputStream) {
            byte[] bArr = new byte[1024];
            StringBuilder sb = new StringBuilder();
            BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);
            while (true) {
                try {
                    int read = bufferedInputStream.read(bArr);
                    if (read != -1) {
                        sb.append(new String(bArr, 0, read));
                    } else {
                        try {
                            break;
                        } catch (IOException e) {
                            Log.e(ConsentInformation.TAG, e.getLocalizedMessage());
                        }
                    }
                } catch (IOException e2) {
                    Log.e(ConsentInformation.TAG, e2.getLocalizedMessage());
                    try {
                        bufferedInputStream.close();
                    } catch (IOException e3) {
                        Log.e(ConsentInformation.TAG, e3.getLocalizedMessage());
                    }
                    return null;
                } catch (Throwable th) {
                    try {
                        bufferedInputStream.close();
                    } catch (IOException e4) {
                        Log.e(ConsentInformation.TAG, e4.getLocalizedMessage());
                    }
                    throw th;
                }
            }
            bufferedInputStream.close();
            return sb.toString();
        }

        /* renamed from: a */
        public void onPostExecute(ConsentInfoUpdateResponse consentInfoUpdateResponse) {
            if (consentInfoUpdateResponse.success) {
                this.listener.mo3046a(this.consentInformation.mo3048a());
            } else {
                this.listener.mo3047a(consentInfoUpdateResponse.responseInfo);
            }
        }

        public /* bridge */ /* synthetic */ Object doInBackground(Object[] objArr) {
            Void[] voidArr = (Void[]) objArr;
            return mo3063a();
        }
    }

    public static class ServerResponse {
        @s93("ad_network_ids")
        public List<AdNetworkLookupResponse> adNetworkLookupResponses;
        public List<AdProvider> companies;
        @s93("is_request_in_eea_or_unknown")
        public Boolean isRequestLocationInEeaOrUnknown;
    }

    public ConsentInformation(Context context2) {
        this.context = context2.getApplicationContext();
    }

    /* renamed from: a */
    public static synchronized ConsentInformation m2647a(Context context2) {
        ConsentInformation consentInformation;
        synchronized (ConsentInformation.class) {
            if (instance == null) {
                instance = new ConsentInformation(context2);
            }
            consentInformation = instance;
        }
        return consentInformation;
    }

    /* renamed from: a */
    public synchronized ConsentStatus mo3048a() {
        return mo3062h().mo3013b();
    }

    /* renamed from: a */
    public final void mo3049a(ConsentData consentData) {
        SharedPreferences.Editor edit = this.context.getSharedPreferences(PREFERENCES_FILE_KEY, 0).edit();
        edit.putString(CONSENT_DATA_KEY, new x83().mo12471a((Object) consentData));
        edit.apply();
    }

    /* renamed from: a */
    public synchronized void mo3051a(ConsentStatus consentStatus, String str) {
        ConsentData h = mo3062h();
        h.mo3015b(consentStatus == ConsentStatus.UNKNOWN ? new HashSet<>() : h.mo3008a());
        h.mo3010a(str);
        h.mo3009a(consentStatus);
        mo3049a(h);
    }

    /* renamed from: a */
    public void mo3052a(String str) {
        this.testDevices.add(str);
    }

    /* renamed from: a */
    public final synchronized void mo3053a(String str, List<String> list) {
        boolean z;
        HashSet hashSet;
        Class cls = ServerResponse.class;
        ServerResponse serverResponse = (ServerResponse) t53.m13090a(cls).cast(new x83().mo12469a(str, (Type) cls));
        mo3050a(serverResponse);
        HashSet hashSet2 = new HashSet();
        List<AdNetworkLookupResponse> list2 = serverResponse.adNetworkLookupResponses;
        boolean z2 = true;
        if (list2 != null) {
            z = false;
            for (AdNetworkLookupResponse next : list2) {
                if (next.isNPA) {
                    List<String> list3 = next.companyIds;
                    if (list3 != null) {
                        hashSet2.addAll(list3);
                    }
                    z = true;
                }
            }
        } else {
            z = false;
        }
        List<AdProvider> list4 = serverResponse.companies;
        if (list4 == null) {
            hashSet = new HashSet();
        } else if (z) {
            ArrayList arrayList = new ArrayList();
            for (AdProvider next2 : list4) {
                if (hashSet2.contains(next2.mo3005a())) {
                    arrayList.add(next2);
                }
            }
            hashSet = new HashSet(arrayList);
        } else {
            hashSet = new HashSet(list4);
        }
        ConsentData h = mo3062h();
        if (h.mo3021f() == z) {
            z2 = false;
        }
        h.mo3012a(z);
        h.mo3014b(str);
        h.mo3018c(new HashSet(list));
        h.mo3011a((HashSet<AdProvider>) hashSet);
        h.mo3016b(serverResponse.isRequestLocationInEeaOrUnknown.booleanValue());
        if (!serverResponse.isRequestLocationInEeaOrUnknown.booleanValue()) {
            mo3049a(h);
            return;
        }
        if (!h.mo3017c().containsAll(h.mo3008a()) || z2) {
            h.mo3010a("sdk");
            h.mo3009a(ConsentStatus.UNKNOWN);
            h.mo3015b((HashSet<AdProvider>) new HashSet());
        }
        mo3049a(h);
    }

    /* renamed from: a */
    public void mo3054a(String[] strArr, ConsentInfoUpdateListener consentInfoUpdateListener) {
        mo3055a(strArr, MOBILE_ADS_SERVER_URL, consentInfoUpdateListener);
    }

    /* renamed from: a */
    public void mo3055a(String[] strArr, String str, ConsentInfoUpdateListener consentInfoUpdateListener) {
        String str2;
        if (mo3061g()) {
            str2 = "This request is sent from a test device.";
        } else {
            String c = mo3057c();
            str2 = C0789gk.m5553a(C0789gk.m5548a(c, 93), "Use ConsentInformation.getInstance(context).addTestDevice(\"", c, "\") to get test ads on this device.");
        }
        Log.i(TAG, str2);
        new ConsentInfoUpdateTask(str, this, Arrays.asList(strArr), consentInfoUpdateListener).execute(new Void[0]);
    }

    /* renamed from: b */
    public DebugGeography mo3056b() {
        return this.debugGeography;
    }

    /* renamed from: c */
    public String mo3057c() {
        ContentResolver contentResolver = this.context.getContentResolver();
        String string = contentResolver == null ? null : Settings.Secure.getString(contentResolver, "android_id");
        if (string == null || mo3058d()) {
            string = "emulator";
        }
        int i = 0;
        while (i < 3) {
            try {
                MessageDigest instance2 = MessageDigest.getInstance("MD5");
                instance2.update(string.getBytes());
                return String.format("%032X", new Object[]{new BigInteger(1, instance2.digest())});
            } catch (NoSuchAlgorithmException unused) {
                i++;
            } catch (ArithmeticException unused2) {
                return null;
            }
        }
        return null;
    }

    /* renamed from: d */
    public final boolean mo3058d() {
        return Build.FINGERPRINT.startsWith("generic") || Build.FINGERPRINT.startsWith("unknown") || Build.MODEL.contains("google_sdk") || Build.MODEL.contains("Emulator") || Build.MODEL.contains("Android SDK built for x86") || Build.MANUFACTURER.contains("Genymotion") || (Build.BRAND.startsWith("generic") && Build.DEVICE.startsWith("generic")) || "google_sdk".equals(Build.PRODUCT);
    }

    /* renamed from: e */
    public boolean mo3059e() {
        return mo3062h().mo3022g();
    }

    /* renamed from: f */
    public synchronized boolean mo3060f() {
        return mo3062h().mo3023h();
    }

    /* renamed from: g */
    public boolean mo3061g() {
        return mo3058d() || this.testDevices.contains(this.hashedDeviceId);
    }

    /* renamed from: h */
    public ConsentData mo3062h() {
        String string = this.context.getSharedPreferences(PREFERENCES_FILE_KEY, 0).getString(CONSENT_DATA_KEY, "");
        return TextUtils.isEmpty(string) ? new ConsentData() : (ConsentData) new x83().mo12468a(string, ConsentData.class);
    }

    /* renamed from: a */
    public final void mo3050a(ServerResponse serverResponse) {
        Boolean bool = serverResponse.isRequestLocationInEeaOrUnknown;
        if (bool == null) {
            throw new Exception("Could not parse Event FE preflight response.");
        } else if (serverResponse.companies == null && bool.booleanValue()) {
            throw new Exception("Could not parse Event FE preflight response.");
        } else if (serverResponse.isRequestLocationInEeaOrUnknown.booleanValue()) {
            HashSet hashSet = new HashSet();
            HashSet hashSet2 = new HashSet();
            for (AdNetworkLookupResponse next : serverResponse.adNetworkLookupResponses) {
                if (next.lookupFailed) {
                    hashSet.add(next.f2837id);
                }
                if (next.notFound) {
                    hashSet2.add(next.f2837id);
                }
            }
            if (!hashSet.isEmpty() || !hashSet2.isEmpty()) {
                StringBuilder sb = new StringBuilder("Response error.");
                if (!hashSet.isEmpty()) {
                    sb.append(String.format(" Lookup failure for: %s.", new Object[]{TextUtils.join(",", hashSet)}));
                }
                if (!hashSet2.isEmpty()) {
                    sb.append(String.format(" Publisher Ids not found: %s", new Object[]{TextUtils.join(",", hashSet2)}));
                }
                throw new Exception(sb.toString());
            }
        }
    }
}
