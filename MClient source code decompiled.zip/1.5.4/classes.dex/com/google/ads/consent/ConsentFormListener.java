package com.google.ads.consent;

public abstract class ConsentFormListener {
    /* renamed from: a */
    public void mo3042a() {
    }

    /* renamed from: a */
    public void mo3043a(ConsentStatus consentStatus, Boolean bool) {
    }

    /* renamed from: a */
    public void mo3044a(String str) {
    }

    /* renamed from: b */
    public void mo3045b() {
    }
}
