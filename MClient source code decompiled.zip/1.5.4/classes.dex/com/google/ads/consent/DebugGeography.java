package com.google.ads.consent;

public enum DebugGeography {
    DEBUG_GEOGRAPHY_DISABLED(0),
    DEBUG_GEOGRAPHY_EEA(1),
    DEBUG_GEOGRAPHY_NOT_EEA(2);
    
    public final int value;

    /* access modifiers changed from: public */
    DebugGeography(int i) {
        this.value = i;
    }

    /* renamed from: a */
    public Integer mo3068a() {
        return Integer.valueOf(this.value);
    }
}
