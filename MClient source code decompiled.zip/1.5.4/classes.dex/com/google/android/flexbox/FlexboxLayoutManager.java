package com.google.android.flexbox;

import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import p000.C0111al;

public class FlexboxLayoutManager extends RecyclerView.C0232o implements C2290xk, RecyclerView.C0249z.C0251b {

    /* renamed from: P0 */
    public static final Rect f2877P0 = new Rect();

    /* renamed from: A0 */
    public C0401d f2878A0;

    /* renamed from: B0 */
    public C0398b f2879B0 = new C0398b((C0397a) null);

    /* renamed from: C0 */
    public C2344yc f2880C0;

    /* renamed from: D0 */
    public C2344yc f2881D0;

    /* renamed from: E0 */
    public C0402e f2882E0;

    /* renamed from: F0 */
    public int f2883F0 = -1;

    /* renamed from: G0 */
    public int f2884G0 = RecyclerView.UNDEFINED_DURATION;

    /* renamed from: H0 */
    public int f2885H0 = RecyclerView.UNDEFINED_DURATION;

    /* renamed from: I0 */
    public int f2886I0 = RecyclerView.UNDEFINED_DURATION;

    /* renamed from: J0 */
    public boolean f2887J0;

    /* renamed from: K0 */
    public SparseArray<View> f2888K0 = new SparseArray<>();

    /* renamed from: L0 */
    public final Context f2889L0;

    /* renamed from: M0 */
    public View f2890M0;

    /* renamed from: N0 */
    public int f2891N0 = -1;

    /* renamed from: O0 */
    public C0111al.C0113b f2892O0 = new C0111al.C0113b();

    /* renamed from: p0 */
    public int f2893p0;

    /* renamed from: q0 */
    public int f2894q0;

    /* renamed from: r0 */
    public int f2895r0;

    /* renamed from: s0 */
    public int f2896s0;

    /* renamed from: t0 */
    public int f2897t0 = -1;

    /* renamed from: u0 */
    public boolean f2898u0;

    /* renamed from: v0 */
    public boolean f2899v0;

    /* renamed from: w0 */
    public List<C2458zk> f2900w0 = new ArrayList();

    /* renamed from: x0 */
    public final C0111al f2901x0 = new C0111al(this);

    /* renamed from: y0 */
    public RecyclerView.C0244v f2902y0;

    /* renamed from: z0 */
    public RecyclerView.C0212a0 f2903z0;

    /* renamed from: com.google.android.flexbox.FlexboxLayoutManager$b */
    public class C0398b {

        /* renamed from: a */
        public int f2904a;

        /* renamed from: b */
        public int f2905b;

        /* renamed from: c */
        public int f2906c;

        /* renamed from: d */
        public int f2907d = 0;

        /* renamed from: e */
        public boolean f2908e;

        /* renamed from: f */
        public boolean f2909f;

        /* renamed from: g */
        public boolean f2910g;

        public /* synthetic */ C0398b(C0397a aVar) {
        }

        /* renamed from: a */
        public static /* synthetic */ void m2796a(C0398b bVar) {
            int i;
            if (FlexboxLayoutManager.this.mo3117a() || !FlexboxLayoutManager.this.f2898u0) {
                if (!bVar.f2908e) {
                    i = FlexboxLayoutManager.this.f2880C0.mo12243f();
                    bVar.f2906c = i;
                }
            } else if (!bVar.f2908e) {
                i = FlexboxLayoutManager.this.mo1954p() - FlexboxLayoutManager.this.f2880C0.mo12243f();
                bVar.f2906c = i;
            }
            i = FlexboxLayoutManager.this.f2880C0.mo12235b();
            bVar.f2906c = i;
        }

        /* JADX WARNING: Code restructure failed: missing block: B:2:0x0018, code lost:
            r1 = r5.f2911h;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:7:0x0028, code lost:
            r1 = r5.f2911h;
         */
        /* renamed from: b */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public static /* synthetic */ void m2797b(com.google.android.flexbox.FlexboxLayoutManager.C0398b r5) {
            /*
                r0 = -1
                r5.f2904a = r0
                r5.f2905b = r0
                r0 = -2147483648(0xffffffff80000000, float:-0.0)
                r5.f2906c = r0
                r0 = 0
                r5.f2909f = r0
                r5.f2910g = r0
                com.google.android.flexbox.FlexboxLayoutManager r1 = com.google.android.flexbox.FlexboxLayoutManager.this
                boolean r1 = r1.mo3117a()
                r2 = 2
                r3 = 1
                if (r1 == 0) goto L_0x0028
                com.google.android.flexbox.FlexboxLayoutManager r1 = com.google.android.flexbox.FlexboxLayoutManager.this
                int r4 = r1.f2894q0
                if (r4 != 0) goto L_0x0025
                int r1 = r1.f2893p0
                if (r1 != r3) goto L_0x0039
                goto L_0x0038
            L_0x0025:
                if (r4 != r2) goto L_0x0039
                goto L_0x0038
            L_0x0028:
                com.google.android.flexbox.FlexboxLayoutManager r1 = com.google.android.flexbox.FlexboxLayoutManager.this
                int r4 = r1.f2894q0
                if (r4 != 0) goto L_0x0036
                int r1 = r1.f2893p0
                r2 = 3
                if (r1 != r2) goto L_0x0039
                goto L_0x0038
            L_0x0036:
                if (r4 != r2) goto L_0x0039
            L_0x0038:
                r0 = 1
            L_0x0039:
                r5.f2908e = r0
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.flexbox.FlexboxLayoutManager.C0398b.m2797b(com.google.android.flexbox.FlexboxLayoutManager$b):void");
        }

        public String toString() {
            StringBuilder a = C0789gk.m5562a("AnchorInfo{mPosition=");
            a.append(this.f2904a);
            a.append(", mFlexLinePosition=");
            a.append(this.f2905b);
            a.append(", mCoordinate=");
            a.append(this.f2906c);
            a.append(", mPerpendicularCoordinate=");
            a.append(this.f2907d);
            a.append(", mLayoutFromEnd=");
            a.append(this.f2908e);
            a.append(", mValid=");
            a.append(this.f2909f);
            a.append(", mAssignedFromSavedState=");
            a.append(this.f2910g);
            a.append('}');
            return a.toString();
        }
    }

    /* renamed from: com.google.android.flexbox.FlexboxLayoutManager$c */
    public static class C0399c extends RecyclerView.C0237p implements C2367yk {
        public static final Parcelable.Creator<C0399c> CREATOR = new C0400a();

        /* renamed from: b0 */
        public float f2912b0 = 0.0f;

        /* renamed from: c0 */
        public float f2913c0 = 1.0f;

        /* renamed from: d0 */
        public int f2914d0 = -1;

        /* renamed from: e0 */
        public float f2915e0 = -1.0f;

        /* renamed from: f0 */
        public int f2916f0;

        /* renamed from: g0 */
        public int f2917g0;

        /* renamed from: h0 */
        public int f2918h0 = 16777215;

        /* renamed from: i0 */
        public int f2919i0 = 16777215;

        /* renamed from: j0 */
        public boolean f2920j0;

        /* renamed from: com.google.android.flexbox.FlexboxLayoutManager$c$a */
        public static class C0400a implements Parcelable.Creator<C0399c> {
            public Object createFromParcel(Parcel parcel) {
                return new C0399c(parcel);
            }

            public Object[] newArray(int i) {
                return new C0399c[i];
            }
        }

        public C0399c(int i, int i2) {
            super(i, i2);
        }

        public C0399c(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public C0399c(Parcel parcel) {
            super(-2, -2);
            this.f2912b0 = parcel.readFloat();
            this.f2913c0 = parcel.readFloat();
            this.f2914d0 = parcel.readInt();
            this.f2915e0 = parcel.readFloat();
            this.f2916f0 = parcel.readInt();
            this.f2917g0 = parcel.readInt();
            this.f2918h0 = parcel.readInt();
            this.f2919i0 = parcel.readInt();
            this.f2920j0 = parcel.readByte() != 0;
            this.bottomMargin = parcel.readInt();
            this.leftMargin = parcel.readInt();
            this.rightMargin = parcel.readInt();
            this.topMargin = parcel.readInt();
            this.height = parcel.readInt();
            this.width = parcel.readInt();
        }

        /* renamed from: a */
        public float mo3161a() {
            return this.f2912b0;
        }

        /* renamed from: a */
        public void mo3162a(int i) {
            this.f2917g0 = i;
        }

        /* renamed from: b */
        public float mo3163b() {
            return this.f2915e0;
        }

        /* renamed from: b */
        public void mo3164b(int i) {
            this.f2916f0 = i;
        }

        /* renamed from: c */
        public int mo3165c() {
            return this.f2914d0;
        }

        /* renamed from: d */
        public float mo3166d() {
            return this.f2913c0;
        }

        public int describeContents() {
            return 0;
        }

        /* renamed from: e */
        public int mo3168e() {
            return this.rightMargin;
        }

        /* renamed from: f */
        public int mo3169f() {
            return this.f2917g0;
        }

        /* renamed from: g */
        public int mo3170g() {
            return this.f2916f0;
        }

        public int getHeight() {
            return this.height;
        }

        public int getOrder() {
            return 1;
        }

        public int getWidth() {
            return this.width;
        }

        /* renamed from: h */
        public boolean mo3174h() {
            return this.f2920j0;
        }

        /* renamed from: i */
        public int mo3175i() {
            return this.f2919i0;
        }

        /* renamed from: j */
        public int mo3176j() {
            return this.bottomMargin;
        }

        /* renamed from: k */
        public int mo3177k() {
            return this.leftMargin;
        }

        /* renamed from: l */
        public int mo3178l() {
            return this.f2918h0;
        }

        /* renamed from: m */
        public int mo3179m() {
            return this.topMargin;
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeFloat(this.f2912b0);
            parcel.writeFloat(this.f2913c0);
            parcel.writeInt(this.f2914d0);
            parcel.writeFloat(this.f2915e0);
            parcel.writeInt(this.f2916f0);
            parcel.writeInt(this.f2917g0);
            parcel.writeInt(this.f2918h0);
            parcel.writeInt(this.f2919i0);
            parcel.writeByte(this.f2920j0 ? (byte) 1 : 0);
            parcel.writeInt(this.bottomMargin);
            parcel.writeInt(this.leftMargin);
            parcel.writeInt(this.rightMargin);
            parcel.writeInt(this.topMargin);
            parcel.writeInt(this.height);
            parcel.writeInt(this.width);
        }
    }

    /* renamed from: com.google.android.flexbox.FlexboxLayoutManager$d */
    public static class C0401d {

        /* renamed from: a */
        public int f2921a;

        /* renamed from: b */
        public boolean f2922b;

        /* renamed from: c */
        public int f2923c;

        /* renamed from: d */
        public int f2924d;

        /* renamed from: e */
        public int f2925e;

        /* renamed from: f */
        public int f2926f;

        /* renamed from: g */
        public int f2927g;

        /* renamed from: h */
        public int f2928h = 1;

        /* renamed from: i */
        public int f2929i = 1;

        /* renamed from: j */
        public boolean f2930j;

        public /* synthetic */ C0401d(C0397a aVar) {
        }

        public String toString() {
            StringBuilder a = C0789gk.m5562a("LayoutState{mAvailable=");
            a.append(this.f2921a);
            a.append(", mFlexLinePosition=");
            a.append(this.f2923c);
            a.append(", mPosition=");
            a.append(this.f2924d);
            a.append(", mOffset=");
            a.append(this.f2925e);
            a.append(", mScrollingOffset=");
            a.append(this.f2926f);
            a.append(", mLastScrollDelta=");
            a.append(this.f2927g);
            a.append(", mItemDirection=");
            a.append(this.f2928h);
            a.append(", mLayoutDirection=");
            a.append(this.f2929i);
            a.append('}');
            return a.toString();
        }
    }

    /* renamed from: com.google.android.flexbox.FlexboxLayoutManager$e */
    public static class C0402e implements Parcelable {
        public static final Parcelable.Creator<C0402e> CREATOR = new C0403a();

        /* renamed from: X */
        public int f2931X;

        /* renamed from: Y */
        public int f2932Y;

        /* renamed from: com.google.android.flexbox.FlexboxLayoutManager$e$a */
        public static class C0403a implements Parcelable.Creator<C0402e> {
            public Object createFromParcel(Parcel parcel) {
                return new C0402e(parcel, (C0397a) null);
            }

            public Object[] newArray(int i) {
                return new C0402e[i];
            }
        }

        public C0402e() {
        }

        public /* synthetic */ C0402e(Parcel parcel, C0397a aVar) {
            this.f2931X = parcel.readInt();
            this.f2932Y = parcel.readInt();
        }

        public int describeContents() {
            return 0;
        }

        public String toString() {
            StringBuilder a = C0789gk.m5562a("SavedState{mAnchorPosition=");
            a.append(this.f2931X);
            a.append(", mAnchorOffset=");
            a.append(this.f2932Y);
            a.append('}');
            return a.toString();
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeInt(this.f2931X);
            parcel.writeInt(this.f2932Y);
        }

        public /* synthetic */ C0402e(C0402e eVar, C0397a aVar) {
            this.f2931X = eVar.f2931X;
            this.f2932Y = eVar.f2932Y;
        }
    }

    public FlexboxLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        int i3;
        RecyclerView.C0232o.C0236d a = RecyclerView.C0232o.m1222a(context, attributeSet, i, i2);
        int i4 = a.f1367a;
        if (i4 != 0) {
            i3 = i4 == 1 ? a.f1369c ? 3 : 2 : i3;
            mo3208s(1);
            mo3206q(4);
            mo1888a(true);
            this.f2889L0 = context;
        } else if (a.f1369c) {
            mo3207r(1);
            mo3208s(1);
            mo3206q(4);
            mo1888a(true);
            this.f2889L0 = context;
        } else {
            i3 = 0;
        }
        mo3207r(i3);
        mo3208s(1);
        mo3206q(4);
        mo1888a(true);
        this.f2889L0 = context;
    }

    /* renamed from: a */
    private boolean m2728a(View view, int i, int i2, RecyclerView.C0237p pVar) {
        return view.isLayoutRequested() || !mo1961w() || !m2730d(view.getWidth(), i, pVar.width) || !m2730d(view.getHeight(), i2, pVar.height);
    }

    /* renamed from: d */
    public static boolean m2730d(int i, int i2, int i3) {
        int mode = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i2);
        if (i3 > 0 && i != i3) {
            return false;
        }
        if (mode == Integer.MIN_VALUE) {
            return size >= i;
        }
        if (mode != 0) {
            return mode == 1073741824 && size == i;
        }
        return true;
    }

    /* renamed from: B */
    public Parcelable mo1533B() {
        C0402e eVar = this.f2882E0;
        if (eVar != null) {
            return new C0402e(eVar, (C0397a) null);
        }
        C0402e eVar2 = new C0402e();
        if (mo1921f() > 0) {
            View g = mo1925g(0);
            eVar2.f2931X = mo1949m(g);
            eVar2.f2932Y = this.f2880C0.mo12240d(g) - this.f2880C0.mo12243f();
        } else {
            eVar2.f2931X = -1;
        }
        return eVar2;
    }

    /* renamed from: J */
    public final void mo3183J() {
        this.f2900w0.clear();
        C0398b.m2797b(this.f2879B0);
        this.f2879B0.f2907d = 0;
    }

    /* renamed from: K */
    public final void mo3184K() {
        C2344yc ycVar;
        if (this.f2880C0 == null) {
            if (mo3117a()) {
                if (this.f2894q0 == 0) {
                    this.f2880C0 = new C2210wc(this);
                    ycVar = new C2266xc(this);
                } else {
                    this.f2880C0 = new C2266xc(this);
                    ycVar = new C2210wc(this);
                }
            } else if (this.f2894q0 == 0) {
                this.f2880C0 = new C2266xc(this);
                ycVar = new C2210wc(this);
            } else {
                this.f2880C0 = new C2210wc(this);
                ycVar = new C2266xc(this);
            }
            this.f2881D0 = ycVar;
        }
    }

    /* renamed from: L */
    public int mo3185L() {
        View a = mo3190a(0, mo1921f(), false);
        if (a == null) {
            return -1;
        }
        return mo1949m(a);
    }

    /* renamed from: M */
    public int mo3186M() {
        View a = mo3190a(mo1921f() - 1, -1, false);
        if (a == null) {
            return -1;
        }
        return mo1949m(a);
    }

    /* renamed from: N */
    public final void mo3187N() {
        int j = mo3117a() ? mo1939j() : mo1956q();
        this.f2878A0.f2922b = j == 0 || j == Integer.MIN_VALUE;
    }

    /* renamed from: a */
    public int mo3105a(int i, int i2, int i3) {
        return RecyclerView.C0232o.m1221a(mo1936i(), mo1939j(), i2, i3, mo1570c());
    }

    /* renamed from: a */
    public final int mo3188a(int i, RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var, boolean z) {
        int i2;
        int b;
        if (!mo3117a() && this.f2898u0) {
            int f = i - this.f2880C0.mo12243f();
            if (f <= 0) {
                return 0;
            }
            i2 = mo3198c(f, vVar, a0Var);
        } else {
            int b2 = this.f2880C0.mo12235b() - i;
            if (b2 <= 0) {
                return 0;
            }
            i2 = -mo3198c(-b2, vVar, a0Var);
        }
        int i3 = i + i2;
        if (!z || (b = this.f2880C0.mo12235b() - i3) <= 0) {
            return i2;
        }
        this.f2880C0.mo12234a(b);
        return b + i2;
    }

    /* renamed from: a */
    public int mo3106a(View view) {
        int l;
        int n;
        if (mo3117a()) {
            l = mo1953o(view);
            n = mo1917e(view);
        } else {
            l = mo1946l(view);
            n = mo1951n(view);
        }
        return n + l;
    }

    /* renamed from: a */
    public int mo3107a(View view, int i, int i2) {
        int o;
        int e;
        if (mo3117a()) {
            o = mo1946l(view);
            e = mo1951n(view);
        } else {
            o = mo1953o(view);
            e = mo1917e(view);
        }
        return e + o;
    }

    /* renamed from: a */
    public int mo1549a(RecyclerView.C0212a0 a0Var) {
        return mo3200h(a0Var);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:15:0x0039, code lost:
        r8 = r2.f2923c;
     */
    /* JADX WARNING: Removed duplicated region for block: B:116:0x02d1  */
    /* JADX WARNING: Removed duplicated region for block: B:60:0x011a  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final int mo3189a(androidx.recyclerview.widget.RecyclerView.C0244v r32, androidx.recyclerview.widget.RecyclerView.C0212a0 r33, com.google.android.flexbox.FlexboxLayoutManager.C0401d r34) {
        /*
            r31 = this;
            r0 = r31
            r1 = r32
            r2 = r34
            int r3 = r2.f2926f
            r4 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r3 == r4) goto L_0x0016
            int r4 = r2.f2921a
            if (r4 >= 0) goto L_0x0013
            int r3 = r3 + r4
            r2.f2926f = r3
        L_0x0013:
            r0.mo3193a((androidx.recyclerview.widget.RecyclerView.C0244v) r1, (com.google.android.flexbox.FlexboxLayoutManager.C0401d) r2)
        L_0x0016:
            int r3 = r2.f2921a
            boolean r4 = r31.mo3117a()
            r5 = 0
            r5 = r3
            r6 = 0
        L_0x001f:
            if (r5 > 0) goto L_0x002c
            com.google.android.flexbox.FlexboxLayoutManager$d r7 = r0.f2878A0
            boolean r7 = r7.f2922b
            if (r7 == 0) goto L_0x0028
            goto L_0x002c
        L_0x0028:
            r26 = r3
            goto L_0x0432
        L_0x002c:
            java.util.List<zk> r7 = r0.f2900w0
            int r8 = r2.f2924d
            r9 = 1
            if (r8 < 0) goto L_0x0045
            int r10 = r33.mo1790a()
            if (r8 >= r10) goto L_0x0045
            int r8 = r2.f2923c
            if (r8 < 0) goto L_0x0045
            int r7 = r7.size()
            if (r8 >= r7) goto L_0x0045
            r7 = 1
            goto L_0x0046
        L_0x0045:
            r7 = 0
        L_0x0046:
            if (r7 == 0) goto L_0x0028
            java.util.List<zk> r7 = r0.f2900w0
            int r8 = r2.f2923c
            java.lang.Object r7 = r7.get(r8)
            zk r7 = (p000.C2458zk) r7
            int r8 = r7.f18445o
            r2.f2924d = r8
            boolean r8 = r31.mo3117a()
            java.lang.String r10 = "Invalid justifyContent is set: "
            r11 = 3
            r12 = 2
            r13 = -1
            if (r8 == 0) goto L_0x020f
            int r8 = r31.getPaddingLeft()
            int r16 = r31.getPaddingRight()
            int r17 = r31.mo1954p()
            int r14 = r2.f2925e
            int r15 = r2.f2929i
            if (r15 != r13) goto L_0x0076
            int r13 = r7.f18437g
            int r14 = r14 - r13
        L_0x0076:
            r20 = r14
            int r15 = r2.f2924d
            int r13 = r0.f2895r0
            if (r13 == 0) goto L_0x00ff
            if (r13 == r9) goto L_0x00f3
            if (r13 == r12) goto L_0x00e3
            if (r13 == r11) goto L_0x00cd
            r9 = 4
            if (r13 == r9) goto L_0x00b3
            r9 = 5
            if (r13 != r9) goto L_0x00a0
            int r9 = r7.f18438h
            if (r9 == 0) goto L_0x0098
            int r10 = r7.f18435e
            int r10 = r17 - r10
            float r10 = (float) r10
            int r9 = r9 + 1
            float r9 = (float) r9
            float r10 = r10 / r9
            goto L_0x0099
        L_0x0098:
            r10 = 0
        L_0x0099:
            float r8 = (float) r8
            float r8 = r8 + r10
            int r9 = r17 - r16
            float r9 = (float) r9
            float r9 = r9 - r10
            goto L_0x0104
        L_0x00a0:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.StringBuilder r2 = p000.C0789gk.m5562a((java.lang.String) r10)
            int r3 = r0.f2895r0
            r2.append(r3)
            java.lang.String r2 = r2.toString()
            r1.<init>(r2)
            throw r1
        L_0x00b3:
            int r9 = r7.f18438h
            if (r9 == 0) goto L_0x00bf
            int r10 = r7.f18435e
            int r10 = r17 - r10
            float r10 = (float) r10
            float r9 = (float) r9
            float r10 = r10 / r9
            goto L_0x00c1
        L_0x00bf:
            r9 = 0
            r10 = 0
        L_0x00c1:
            float r8 = (float) r8
            r9 = 1073741824(0x40000000, float:2.0)
            float r9 = r10 / r9
            float r8 = r8 + r9
            int r11 = r17 - r16
            float r11 = (float) r11
            float r9 = r11 - r9
            goto L_0x0104
        L_0x00cd:
            float r8 = (float) r8
            int r10 = r7.f18438h
            if (r10 == r9) goto L_0x00d6
            int r10 = r10 + -1
            float r14 = (float) r10
            goto L_0x00d8
        L_0x00d6:
            r14 = 1065353216(0x3f800000, float:1.0)
        L_0x00d8:
            int r9 = r7.f18435e
            int r9 = r17 - r9
            float r9 = (float) r9
            float r10 = r9 / r14
            int r9 = r17 - r16
            float r9 = (float) r9
            goto L_0x0104
        L_0x00e3:
            float r8 = (float) r8
            int r9 = r7.f18435e
            int r9 = r17 - r9
            float r9 = (float) r9
            r10 = 1073741824(0x40000000, float:2.0)
            float r9 = r9 / r10
            float r8 = r8 + r9
            int r10 = r17 - r16
            float r10 = (float) r10
            float r10 = r10 - r9
            r9 = r10
            goto L_0x0103
        L_0x00f3:
            int r9 = r7.f18435e
            int r17 = r17 - r9
            int r10 = r17 + r16
            float r10 = (float) r10
            int r9 = r9 - r8
            float r8 = (float) r9
            r9 = r8
            r8 = r10
            goto L_0x0103
        L_0x00ff:
            float r8 = (float) r8
            int r9 = r17 - r16
            float r9 = (float) r9
        L_0x0103:
            r10 = 0
        L_0x0104:
            com.google.android.flexbox.FlexboxLayoutManager$b r11 = r0.f2879B0
            int r11 = r11.f2907d
            float r11 = (float) r11
            float r8 = r8 - r11
            float r9 = r9 - r11
            r11 = 0
            float r17 = java.lang.Math.max(r10, r11)
            int r14 = r7.f18438h
            r10 = 0
            r11 = r9
            r9 = r8
            r8 = r15
        L_0x0116:
            int r12 = r15 + r14
            if (r8 >= r12) goto L_0x01fc
            android.view.View r13 = r0.mo3108a((int) r8)
            if (r13 != 0) goto L_0x0128
            r26 = r3
            r22 = r14
            r19 = r15
            goto L_0x01f2
        L_0x0128:
            int r12 = r2.f2929i
            r16 = r14
            r14 = 1
            if (r12 != r14) goto L_0x0138
            android.graphics.Rect r12 = f2877P0
            r0.mo1877a((android.view.View) r13, (android.graphics.Rect) r12)
            r0.mo1908c((android.view.View) r13)
            goto L_0x0142
        L_0x0138:
            android.graphics.Rect r12 = f2877P0
            r0.mo1877a((android.view.View) r13, (android.graphics.Rect) r12)
            r0.mo1899b((android.view.View) r13, (int) r10)
            int r10 = r10 + 1
        L_0x0142:
            r18 = r10
            al r10 = r0.f2901x0
            long[] r12 = r10.f549d
            r19 = r15
            r14 = r12[r8]
            int r10 = r10.mo589b((long) r14)
            al r12 = r0.f2901x0
            int r12 = r12.mo572a((long) r14)
            android.view.ViewGroup$LayoutParams r14 = r13.getLayoutParams()
            r15 = r14
            com.google.android.flexbox.FlexboxLayoutManager$c r15 = (com.google.android.flexbox.FlexboxLayoutManager.C0399c) r15
            boolean r14 = r0.m2728a((android.view.View) r13, (int) r10, (int) r12, (androidx.recyclerview.widget.RecyclerView.C0237p) r15)
            if (r14 == 0) goto L_0x0166
            r13.measure(r10, r12)
        L_0x0166:
            int r10 = r15.leftMargin
            int r12 = r0.mo1946l((android.view.View) r13)
            int r12 = r12 + r10
            float r10 = (float) r12
            float r9 = r9 + r10
            int r10 = r15.rightMargin
            int r12 = r0.mo1951n(r13)
            int r12 = r12 + r10
            float r10 = (float) r12
            float r21 = r11 - r10
            int r10 = r0.mo1953o(r13)
            int r14 = r10 + r20
            boolean r10 = r0.f2898u0
            if (r10 == 0) goto L_0x019d
            al r10 = r0.f2901x0
            int r11 = java.lang.Math.round(r21)
            int r12 = r13.getMeasuredWidth()
            int r11 = r11 - r12
            int r12 = java.lang.Math.round(r21)
            int r22 = r13.getMeasuredHeight()
            int r22 = r22 + r14
            r23 = r12
            r24 = r22
            goto L_0x01b6
        L_0x019d:
            al r10 = r0.f2901x0
            int r11 = java.lang.Math.round(r9)
            int r12 = java.lang.Math.round(r9)
            int r22 = r13.getMeasuredWidth()
            int r22 = r22 + r12
            int r12 = r13.getMeasuredHeight()
            int r12 = r12 + r14
            r24 = r12
            r23 = r22
        L_0x01b6:
            r22 = r11
            r11 = r13
            r12 = r7
            r25 = r13
            r13 = r22
            r22 = r16
            r26 = r3
            r3 = r15
            r15 = r23
            r16 = r24
            r10.mo582a((android.view.View) r11, (p000.C2458zk) r12, (int) r13, (int) r14, (int) r15, (int) r16)
            int r10 = r25.getMeasuredWidth()
            int r11 = r3.rightMargin
            int r10 = r10 + r11
            r11 = r25
            int r12 = r0.mo1951n(r11)
            int r12 = r12 + r10
            float r10 = (float) r12
            float r10 = r10 + r17
            float r10 = r10 + r9
            int r9 = r11.getMeasuredWidth()
            int r3 = r3.leftMargin
            int r9 = r9 + r3
            int r3 = r0.mo1946l((android.view.View) r11)
            int r3 = r3 + r9
            float r3 = (float) r3
            float r3 = r3 + r17
            float r21 = r21 - r3
            r9 = r10
            r10 = r18
            r11 = r21
        L_0x01f2:
            int r8 = r8 + 1
            r15 = r19
            r14 = r22
            r3 = r26
            goto L_0x0116
        L_0x01fc:
            r26 = r3
            int r3 = r2.f2923c
            com.google.android.flexbox.FlexboxLayoutManager$d r8 = r0.f2878A0
            int r8 = r8.f2929i
            int r3 = r3 + r8
            r2.f2923c = r3
            int r3 = r7.f18437g
            r18 = r4
            r19 = r5
            goto L_0x040a
        L_0x020f:
            r26 = r3
            int r3 = r31.getPaddingTop()
            int r8 = r31.getPaddingBottom()
            int r9 = r31.mo1936i()
            int r11 = r2.f2925e
            int r14 = r2.f2929i
            if (r14 != r13) goto L_0x022d
            int r13 = r7.f18437g
            int r14 = r11 - r13
            int r11 = r11 + r13
            r20 = r11
            r21 = r14
            goto L_0x0231
        L_0x022d:
            r20 = r11
            r21 = r20
        L_0x0231:
            int r15 = r2.f2924d
            int r11 = r0.f2895r0
            if (r11 == 0) goto L_0x02b6
            r13 = 1
            if (r11 == r13) goto L_0x02a9
            if (r11 == r12) goto L_0x029b
            r12 = 3
            if (r11 == r12) goto L_0x0285
            r12 = 4
            if (r11 == r12) goto L_0x026d
            r12 = 5
            if (r11 != r12) goto L_0x025a
            int r10 = r7.f18438h
            if (r10 == 0) goto L_0x0253
            int r11 = r7.f18435e
            int r11 = r9 - r11
            float r11 = (float) r11
            int r10 = r10 + 1
            float r10 = (float) r10
            float r11 = r11 / r10
            goto L_0x0254
        L_0x0253:
            r11 = 0
        L_0x0254:
            float r3 = (float) r3
            float r3 = r3 + r11
            int r9 = r9 - r8
            float r8 = (float) r9
            float r8 = r8 - r11
            goto L_0x02ba
        L_0x025a:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.StringBuilder r2 = p000.C0789gk.m5562a((java.lang.String) r10)
            int r3 = r0.f2895r0
            r2.append(r3)
            java.lang.String r2 = r2.toString()
            r1.<init>(r2)
            throw r1
        L_0x026d:
            int r10 = r7.f18438h
            if (r10 == 0) goto L_0x0279
            int r11 = r7.f18435e
            int r11 = r9 - r11
            float r11 = (float) r11
            float r10 = (float) r10
            float r11 = r11 / r10
            goto L_0x027b
        L_0x0279:
            r10 = 0
            r11 = 0
        L_0x027b:
            float r3 = (float) r3
            r10 = 1073741824(0x40000000, float:2.0)
            float r10 = r11 / r10
            float r3 = r3 + r10
            int r9 = r9 - r8
            float r8 = (float) r9
            float r8 = r8 - r10
            goto L_0x02ba
        L_0x0285:
            float r3 = (float) r3
            int r10 = r7.f18438h
            r11 = 1
            if (r10 == r11) goto L_0x028f
            int r10 = r10 + -1
            float r14 = (float) r10
            goto L_0x0291
        L_0x028f:
            r14 = 1065353216(0x3f800000, float:1.0)
        L_0x0291:
            int r10 = r7.f18435e
            int r10 = r9 - r10
            float r10 = (float) r10
            float r11 = r10 / r14
            int r9 = r9 - r8
            float r8 = (float) r9
            goto L_0x02ba
        L_0x029b:
            float r3 = (float) r3
            int r10 = r7.f18435e
            int r10 = r9 - r10
            float r10 = (float) r10
            r11 = 1073741824(0x40000000, float:2.0)
            float r10 = r10 / r11
            float r3 = r3 + r10
            int r9 = r9 - r8
            float r8 = (float) r9
            float r8 = r8 - r10
            goto L_0x02b9
        L_0x02a9:
            int r10 = r7.f18435e
            int r9 = r9 - r10
            int r9 = r9 + r8
            float r8 = (float) r9
            int r10 = r10 - r3
            float r3 = (float) r10
            r30 = r8
            r8 = r3
            r3 = r30
            goto L_0x02b9
        L_0x02b6:
            float r3 = (float) r3
            int r9 = r9 - r8
            float r8 = (float) r9
        L_0x02b9:
            r11 = 0
        L_0x02ba:
            com.google.android.flexbox.FlexboxLayoutManager$b r9 = r0.f2879B0
            int r9 = r9.f2907d
            float r9 = (float) r9
            float r3 = r3 - r9
            float r8 = r8 - r9
            r9 = 0
            float r9 = java.lang.Math.max(r11, r9)
            int r14 = r7.f18438h
            r10 = 0
            r10 = r8
            r11 = 0
            r8 = r3
            r3 = r15
        L_0x02cd:
            int r12 = r15 + r14
            if (r3 >= r12) goto L_0x03fb
            android.view.View r13 = r0.mo3108a((int) r3)
            if (r13 != 0) goto L_0x02e1
            r18 = r4
            r19 = r5
            r28 = r14
            r29 = r15
            goto L_0x03ef
        L_0x02e1:
            al r12 = r0.f2901x0
            r16 = r14
            long[] r14 = r12.f549d
            r18 = r4
            r19 = r5
            r4 = r14[r3]
            int r12 = r12.mo589b((long) r4)
            al r14 = r0.f2901x0
            int r4 = r14.mo572a((long) r4)
            android.view.ViewGroup$LayoutParams r5 = r13.getLayoutParams()
            com.google.android.flexbox.FlexboxLayoutManager$c r5 = (com.google.android.flexbox.FlexboxLayoutManager.C0399c) r5
            boolean r14 = r0.m2728a((android.view.View) r13, (int) r12, (int) r4, (androidx.recyclerview.widget.RecyclerView.C0237p) r5)
            if (r14 == 0) goto L_0x0306
            r13.measure(r12, r4)
        L_0x0306:
            int r4 = r5.topMargin
            int r12 = r0.mo1953o(r13)
            int r12 = r12 + r4
            float r4 = (float) r12
            float r8 = r8 + r4
            int r4 = r5.rightMargin
            int r12 = r0.mo1917e((android.view.View) r13)
            int r12 = r12 + r4
            float r4 = (float) r12
            float r4 = r10 - r4
            int r10 = r2.f2929i
            r12 = 1
            if (r10 != r12) goto L_0x0327
            android.graphics.Rect r10 = f2877P0
            r0.mo1877a((android.view.View) r13, (android.graphics.Rect) r10)
            r0.mo1908c((android.view.View) r13)
            goto L_0x0331
        L_0x0327:
            android.graphics.Rect r10 = f2877P0
            r0.mo1877a((android.view.View) r13, (android.graphics.Rect) r10)
            r0.mo1899b((android.view.View) r13, (int) r11)
            int r11 = r11 + 1
        L_0x0331:
            r22 = r11
            int r10 = r0.mo1946l((android.view.View) r13)
            int r10 = r10 + r21
            int r11 = r0.mo1951n(r13)
            int r11 = r20 - r11
            boolean r14 = r0.f2898u0
            if (r14 == 0) goto L_0x037d
            boolean r10 = r0.f2899v0
            if (r10 == 0) goto L_0x035e
            al r10 = r0.f2901x0
            int r12 = r13.getMeasuredWidth()
            int r12 = r11 - r12
            int r17 = java.lang.Math.round(r4)
            int r23 = r13.getMeasuredHeight()
            int r17 = r17 - r23
            int r23 = java.lang.Math.round(r4)
            goto L_0x0374
        L_0x035e:
            al r10 = r0.f2901x0
            int r12 = r13.getMeasuredWidth()
            int r12 = r11 - r12
            int r17 = java.lang.Math.round(r8)
            int r23 = java.lang.Math.round(r8)
            int r24 = r13.getMeasuredHeight()
            int r23 = r24 + r23
        L_0x0374:
            r24 = r11
            r25 = r23
            r23 = r17
            r17 = r12
            goto L_0x03b7
        L_0x037d:
            boolean r11 = r0.f2899v0
            if (r11 == 0) goto L_0x0398
            al r11 = r0.f2901x0
            int r12 = java.lang.Math.round(r4)
            int r17 = r13.getMeasuredHeight()
            int r12 = r12 - r17
            int r17 = r13.getMeasuredWidth()
            int r17 = r17 + r10
            int r23 = java.lang.Math.round(r4)
            goto L_0x03ae
        L_0x0398:
            al r11 = r0.f2901x0
            int r12 = java.lang.Math.round(r8)
            int r17 = r13.getMeasuredWidth()
            int r17 = r17 + r10
            int r23 = java.lang.Math.round(r8)
            int r24 = r13.getMeasuredHeight()
            int r23 = r24 + r23
        L_0x03ae:
            r24 = r17
            r25 = r23
            r17 = r10
            r10 = r11
            r23 = r12
        L_0x03b7:
            r11 = r13
            r12 = r7
            r27 = r13
            r13 = r14
            r28 = r16
            r14 = r17
            r29 = r15
            r15 = r23
            r16 = r24
            r17 = r25
            r10.mo583a((android.view.View) r11, (p000.C2458zk) r12, (boolean) r13, (int) r14, (int) r15, (int) r16, (int) r17)
            int r10 = r27.getMeasuredHeight()
            int r11 = r5.topMargin
            int r10 = r10 + r11
            r11 = r27
            int r12 = r0.mo1917e((android.view.View) r11)
            int r12 = r12 + r10
            float r10 = (float) r12
            float r10 = r10 + r9
            float r10 = r10 + r8
            int r8 = r11.getMeasuredHeight()
            int r5 = r5.bottomMargin
            int r8 = r8 + r5
            int r5 = r0.mo1953o(r11)
            int r5 = r5 + r8
            float r5 = (float) r5
            float r5 = r5 + r9
            float r4 = r4 - r5
            r8 = r10
            r11 = r22
            r10 = r4
        L_0x03ef:
            int r3 = r3 + 1
            r4 = r18
            r5 = r19
            r14 = r28
            r15 = r29
            goto L_0x02cd
        L_0x03fb:
            r18 = r4
            r19 = r5
            int r3 = r2.f2923c
            com.google.android.flexbox.FlexboxLayoutManager$d r4 = r0.f2878A0
            int r4 = r4.f2929i
            int r3 = r3 + r4
            r2.f2923c = r3
            int r3 = r7.f18437g
        L_0x040a:
            int r6 = r6 + r3
            if (r18 != 0) goto L_0x041d
            boolean r3 = r0.f2898u0
            if (r3 == 0) goto L_0x041d
            int r3 = r2.f2925e
            int r4 = r7.f18437g
            int r5 = r2.f2929i
            int r4 = r4 * r5
            int r3 = r3 - r4
            r2.f2925e = r3
            goto L_0x0428
        L_0x041d:
            int r3 = r2.f2925e
            int r4 = r7.f18437g
            int r5 = r2.f2929i
            int r4 = r4 * r5
            int r4 = r4 + r3
            r2.f2925e = r4
        L_0x0428:
            int r3 = r7.f18437g
            int r5 = r19 - r3
            r4 = r18
            r3 = r26
            goto L_0x001f
        L_0x0432:
            int r3 = r2.f2921a
            int r3 = r3 - r6
            r2.f2921a = r3
            int r3 = r2.f2926f
            r4 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r3 == r4) goto L_0x044c
            int r3 = r3 + r6
            r2.f2926f = r3
            int r3 = r2.f2921a
            if (r3 >= 0) goto L_0x0449
            int r4 = r2.f2926f
            int r4 = r4 + r3
            r2.f2926f = r4
        L_0x0449:
            r0.mo3193a((androidx.recyclerview.widget.RecyclerView.C0244v) r1, (com.google.android.flexbox.FlexboxLayoutManager.C0401d) r2)
        L_0x044c:
            int r1 = r2.f2921a
            int r3 = r26 - r1
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.flexbox.FlexboxLayoutManager.mo3189a(androidx.recyclerview.widget.RecyclerView$v, androidx.recyclerview.widget.RecyclerView$a0, com.google.android.flexbox.FlexboxLayoutManager$d):int");
    }

    /* renamed from: a */
    public final View mo3191a(View view, C2458zk zkVar) {
        boolean a = mo3117a();
        int i = zkVar.f18438h;
        for (int i2 = 1; i2 < i; i2++) {
            View g = mo1925g(i2);
            if (!(g == null || g.getVisibility() == 8)) {
                if (!this.f2898u0 || a) {
                    if (this.f2880C0.mo12240d(view) <= this.f2880C0.mo12240d(g)) {
                    }
                } else if (this.f2880C0.mo12233a(view) >= this.f2880C0.mo12233a(g)) {
                }
                view = g;
            }
        }
        return view;
    }

    /* renamed from: a */
    public RecyclerView.C0237p mo1497a(Context context, AttributeSet attributeSet) {
        return new C0399c(context, attributeSet);
    }

    /* renamed from: a */
    public void mo3110a(int i, View view) {
        this.f2888K0.put(i, view);
    }

    /* renamed from: a */
    public void mo1556a(Parcelable parcelable) {
        if (parcelable instanceof C0402e) {
            this.f2882E0 = (C0402e) parcelable;
            mo1868E();
        }
    }

    /* renamed from: a */
    public void mo3113a(View view, int i, int i2, C2458zk zkVar) {
        int i3;
        int i4;
        mo1877a(view, f2877P0);
        if (mo3117a()) {
            i3 = mo1946l(view);
            i4 = mo1951n(view);
        } else {
            i3 = mo1953o(view);
            i4 = mo1917e(view);
        }
        int i5 = i4 + i3;
        zkVar.f18435e += i5;
        zkVar.f18436f += i5;
    }

    /* renamed from: a */
    public void mo1881a(RecyclerView.C0221g gVar, RecyclerView.C0221g gVar2) {
        mo1867D();
    }

    /* renamed from: a */
    public final void mo3192a(RecyclerView.C0244v vVar, int i, int i2) {
        while (i2 >= i) {
            mo1872a(i2, vVar);
            i2--;
        }
    }

    /* renamed from: a */
    public void mo1505a(RecyclerView recyclerView, int i, int i2) {
        super.mo1505a(recyclerView, i, i2);
        mo3209t(i);
    }

    /* renamed from: a */
    public void mo1506a(RecyclerView recyclerView, int i, int i2, int i3) {
        super.mo1506a(recyclerView, i, i2, i3);
        mo3209t(Math.min(i, i2));
    }

    /* renamed from: a */
    public void mo1507a(RecyclerView recyclerView, int i, int i2, Object obj) {
        super.mo1507a(recyclerView, i, i2, obj);
        mo3209t(i);
    }

    /* renamed from: a */
    public void mo3114a(C2458zk zkVar) {
    }

    /* renamed from: a */
    public boolean mo3117a() {
        int i = this.f2893p0;
        return i == 0 || i == 1;
    }

    /* renamed from: a */
    public boolean mo1508a(RecyclerView.C0237p pVar) {
        return pVar instanceof C0399c;
    }

    /* renamed from: b */
    public int mo3120b(int i, int i2, int i3) {
        return RecyclerView.C0232o.m1221a(mo1954p(), mo1956q(), i2, i3, mo1567b());
    }

    /* renamed from: b */
    public final int mo3195b(int i, RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var, boolean z) {
        int i2;
        int f;
        if (mo3117a() || !this.f2898u0) {
            int f2 = i - this.f2880C0.mo12243f();
            if (f2 <= 0) {
                return 0;
            }
            i2 = -mo3198c(f2, vVar, a0Var);
        } else {
            int b = this.f2880C0.mo12235b() - i;
            if (b <= 0) {
                return 0;
            }
            i2 = mo3198c(-b, vVar, a0Var);
        }
        int i3 = i + i2;
        if (!z || (f = i3 - this.f2880C0.mo12243f()) <= 0) {
            return i2;
        }
        this.f2880C0.mo12234a(-f);
        return i2 - f;
    }

    /* renamed from: b */
    public int mo1510b(RecyclerView.C0212a0 a0Var) {
        return mo3201i(a0Var);
    }

    /* renamed from: b */
    public View mo3121b(int i) {
        return mo3108a(i);
    }

    /* renamed from: b */
    public final View mo3196b(View view, C2458zk zkVar) {
        boolean a = mo3117a();
        int f = (mo1921f() - zkVar.f18438h) - 1;
        for (int f2 = mo1921f() - 2; f2 > f; f2--) {
            View g = mo1925g(f2);
            if (!(g == null || g.getVisibility() == 8)) {
                if (!this.f2898u0 || a) {
                    if (this.f2880C0.mo12233a(view) >= this.f2880C0.mo12233a(g)) {
                    }
                } else if (this.f2880C0.mo12240d(view) <= this.f2880C0.mo12240d(g)) {
                }
                view = g;
            }
        }
        return view;
    }

    /* renamed from: b */
    public void mo1905b(RecyclerView recyclerView) {
        super.mo1905b(recyclerView);
        this.f2890M0 = (View) recyclerView.getParent();
    }

    /* renamed from: b */
    public void mo1514b(RecyclerView recyclerView, int i, int i2) {
        super.mo1514b(recyclerView, i, i2);
        mo3209t(i);
    }

    /* renamed from: b */
    public void mo1565b(RecyclerView recyclerView, RecyclerView.C0244v vVar) {
        mo1964z();
        if (this.f2887J0) {
            mo1903b(vVar);
            vVar.mo1985a();
        }
    }

    /* renamed from: b */
    public boolean mo1567b() {
        if (this.f2894q0 == 0) {
            return mo3117a();
        }
        if (mo3117a()) {
            int p = mo1954p();
            View view = this.f2890M0;
            return p > (view != null ? view.getWidth() : 0);
        }
    }

    /* renamed from: c */
    public final int mo3198c(int i, RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var) {
        int i2;
        int i3;
        C0401d dVar;
        if (mo1921f() == 0 || i == 0) {
            return 0;
        }
        mo3184K();
        this.f2878A0.f2930j = true;
        boolean z = !mo3117a() && this.f2898u0;
        int i4 = (!z ? i <= 0 : i >= 0) ? -1 : 1;
        int abs = Math.abs(i);
        this.f2878A0.f2929i = i4;
        boolean a = mo3117a();
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(mo1954p(), mo1956q());
        int makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(mo1936i(), mo1939j());
        boolean z2 = !a && this.f2898u0;
        if (i4 == 1) {
            View g = mo1925g(mo1921f() - 1);
            this.f2878A0.f2925e = this.f2880C0.mo12233a(g);
            int m = mo1949m(g);
            View b = mo3196b(g, this.f2900w0.get(this.f2901x0.f548c[m]));
            C0401d dVar2 = this.f2878A0;
            dVar2.f2928h = 1;
            dVar2.f2924d = m + dVar2.f2928h;
            int[] iArr = this.f2901x0.f548c;
            int length = iArr.length;
            int i5 = dVar2.f2924d;
            if (length <= i5) {
                dVar2.f2923c = -1;
            } else {
                dVar2.f2923c = iArr[i5];
            }
            if (z2) {
                this.f2878A0.f2925e = this.f2880C0.mo12240d(b);
                this.f2878A0.f2926f = this.f2880C0.mo12243f() + (-this.f2880C0.mo12240d(b));
                dVar = this.f2878A0;
                i3 = dVar.f2926f;
                if (i3 < 0) {
                    i3 = 0;
                }
            } else {
                this.f2878A0.f2925e = this.f2880C0.mo12233a(b);
                dVar = this.f2878A0;
                i3 = this.f2880C0.mo12233a(b) - this.f2880C0.mo12235b();
            }
            dVar.f2926f = i3;
            int i6 = this.f2878A0.f2923c;
            if ((i6 == -1 || i6 > this.f2900w0.size() - 1) && this.f2878A0.f2924d <= getFlexItemCount()) {
                int i7 = abs - this.f2878A0.f2926f;
                this.f2892O0.mo600a();
                if (i7 > 0) {
                    C0111al alVar = this.f2901x0;
                    C0111al.C0113b bVar = this.f2892O0;
                    C0401d dVar3 = this.f2878A0;
                    if (a) {
                        alVar.mo579a(bVar, makeMeasureSpec, makeMeasureSpec2, i7, dVar3.f2924d, -1, this.f2900w0);
                    } else {
                        alVar.mo579a(bVar, makeMeasureSpec2, makeMeasureSpec, i7, dVar3.f2924d, -1, this.f2900w0);
                    }
                    this.f2901x0.mo592b(makeMeasureSpec, makeMeasureSpec2, this.f2878A0.f2924d);
                    this.f2901x0.mo599e(this.f2878A0.f2924d);
                }
            }
        } else {
            View g2 = mo1925g(0);
            this.f2878A0.f2925e = this.f2880C0.mo12240d(g2);
            int m2 = mo1949m(g2);
            View a2 = mo3191a(g2, this.f2900w0.get(this.f2901x0.f548c[m2]));
            this.f2878A0.f2928h = 1;
            int i8 = this.f2901x0.f548c[m2];
            if (i8 == -1) {
                i8 = 0;
            }
            if (i8 > 0) {
                this.f2878A0.f2924d = m2 - this.f2900w0.get(i8 - 1).f18438h;
            } else {
                this.f2878A0.f2924d = -1;
            }
            this.f2878A0.f2923c = i8 > 0 ? i8 - 1 : 0;
            C0401d dVar4 = this.f2878A0;
            C2344yc ycVar = this.f2880C0;
            if (z2) {
                dVar4.f2925e = ycVar.mo12233a(a2);
                this.f2878A0.f2926f = this.f2880C0.mo12233a(a2) - this.f2880C0.mo12235b();
                C0401d dVar5 = this.f2878A0;
                int i9 = dVar5.f2926f;
                if (i9 < 0) {
                    i9 = 0;
                }
                dVar5.f2926f = i9;
            } else {
                dVar4.f2925e = ycVar.mo12240d(a2);
                this.f2878A0.f2926f = this.f2880C0.mo12243f() + (-this.f2880C0.mo12240d(a2));
            }
        }
        C0401d dVar6 = this.f2878A0;
        int i10 = dVar6.f2926f;
        dVar6.f2921a = abs - i10;
        int a3 = mo3189a(vVar, a0Var, dVar6) + i10;
        if (a3 < 0) {
            return 0;
        }
        if (z) {
            if (abs > a3) {
                i2 = (-i4) * a3;
                this.f2880C0.mo12234a(-i2);
                this.f2878A0.f2927g = i2;
                return i2;
            }
        } else if (abs > a3) {
            i2 = i4 * a3;
            this.f2880C0.mo12234a(-i2);
            this.f2878A0.f2927g = i2;
            return i2;
        }
        i2 = i;
        this.f2880C0.mo12234a(-i2);
        this.f2878A0.f2927g = i2;
        return i2;
    }

    /* renamed from: c */
    public int mo1515c(RecyclerView.C0212a0 a0Var) {
        return mo3202j(a0Var);
    }

    /* renamed from: c */
    public PointF mo1569c(int i) {
        if (mo1921f() == 0) {
            return null;
        }
        int i2 = i < mo1949m(mo1925g(0)) ? -1 : 1;
        return mo3117a() ? new PointF(0.0f, (float) i2) : new PointF((float) i2, 0.0f);
    }

    /* renamed from: c */
    public void mo1911c(RecyclerView recyclerView, int i, int i2) {
        super.mo1911c(recyclerView, i, i2);
        mo3209t(i);
    }

    /* renamed from: c */
    public boolean mo1570c() {
        if (this.f2894q0 == 0) {
            return !mo3117a();
        }
        if (mo3117a()) {
            return true;
        }
        int i = mo1936i();
        View view = this.f2890M0;
        return i > (view != null ? view.getHeight() : 0);
    }

    /* renamed from: d */
    public int mo1571d(RecyclerView.C0212a0 a0Var) {
        return mo3200h(a0Var);
    }

    /* renamed from: d */
    public RecyclerView.C0237p mo1520d() {
        return new C0399c(-2, -2);
    }

    /* renamed from: e */
    public int mo1521e(RecyclerView.C0212a0 a0Var) {
        return mo3201i(a0Var);
    }

    /* renamed from: e */
    public final View mo3199e(int i, int i2, int i3) {
        mo3184K();
        View view = null;
        if (this.f2878A0 == null) {
            this.f2878A0 = new C0401d((C0397a) null);
        }
        int f = this.f2880C0.mo12243f();
        int b = this.f2880C0.mo12235b();
        int i4 = i2 > i ? 1 : -1;
        View view2 = null;
        while (i != i2) {
            View g = mo1925g(i);
            int m = mo1949m(g);
            if (m >= 0 && m < i3) {
                if (((RecyclerView.C0237p) g.getLayoutParams()).mo1972p()) {
                    if (view2 == null) {
                        view2 = g;
                    }
                } else if (this.f2880C0.mo12240d(g) >= f && this.f2880C0.mo12233a(g) <= b) {
                    return g;
                } else {
                    if (view == null) {
                        view = g;
                    }
                }
            }
            i += i4;
        }
        return view != null ? view : view2;
    }

    /* renamed from: f */
    public int mo1522f(RecyclerView.C0212a0 a0Var) {
        return mo3202j(a0Var);
    }

    /* renamed from: g */
    public void mo1523g(RecyclerView.C0212a0 a0Var) {
        this.f2882E0 = null;
        this.f2883F0 = -1;
        this.f2884G0 = RecyclerView.UNDEFINED_DURATION;
        this.f2891N0 = -1;
        C0398b.m2797b(this.f2879B0);
        this.f2888K0.clear();
    }

    public int getAlignContent() {
        return 5;
    }

    public int getAlignItems() {
        return this.f2896s0;
    }

    public int getFlexDirection() {
        return this.f2893p0;
    }

    public int getFlexItemCount() {
        return this.f2903z0.mo1790a();
    }

    public List<C2458zk> getFlexLinesInternal() {
        return this.f2900w0;
    }

    public int getFlexWrap() {
        return this.f2894q0;
    }

    public int getLargestMainSize() {
        if (this.f2900w0.size() == 0) {
            return 0;
        }
        int i = RecyclerView.UNDEFINED_DURATION;
        int size = this.f2900w0.size();
        for (int i2 = 0; i2 < size; i2++) {
            i = Math.max(i, this.f2900w0.get(i2).f18435e);
        }
        return i;
    }

    public int getMaxLine() {
        return this.f2897t0;
    }

    public int getSumOfCrossSize() {
        int size = this.f2900w0.size();
        int i = 0;
        for (int i2 = 0; i2 < size; i2++) {
            i += this.f2900w0.get(i2).f18437g;
        }
        return i;
    }

    /* renamed from: h */
    public final int mo3200h(RecyclerView.C0212a0 a0Var) {
        if (mo1921f() == 0) {
            return 0;
        }
        int a = a0Var.mo1790a();
        mo3184K();
        View n = mo3203n(a);
        View o = mo3204o(a);
        if (a0Var.mo1790a() == 0 || n == null || o == null) {
            return 0;
        }
        return Math.min(this.f2880C0.mo12245g(), this.f2880C0.mo12233a(o) - this.f2880C0.mo12240d(n));
    }

    /* renamed from: i */
    public final int mo3201i(RecyclerView.C0212a0 a0Var) {
        if (mo1921f() == 0) {
            return 0;
        }
        int a = a0Var.mo1790a();
        View n = mo3203n(a);
        View o = mo3204o(a);
        if (!(a0Var.mo1790a() == 0 || n == null || o == null)) {
            int m = mo1949m(n);
            int m2 = mo1949m(o);
            int abs = Math.abs(this.f2880C0.mo12233a(o) - this.f2880C0.mo12240d(n));
            int[] iArr = this.f2901x0.f548c;
            int i = iArr[m];
            if (!(i == 0 || i == -1)) {
                return Math.round((((float) i) * (((float) abs) / ((float) ((iArr[m2] - i) + 1)))) + ((float) (this.f2880C0.mo12243f() - this.f2880C0.mo12240d(n))));
            }
        }
        return 0;
    }

    /* renamed from: j */
    public final int mo3202j(RecyclerView.C0212a0 a0Var) {
        if (mo1921f() == 0) {
            return 0;
        }
        int a = a0Var.mo1790a();
        View n = mo3203n(a);
        View o = mo3204o(a);
        if (a0Var.mo1790a() == 0 || n == null || o == null) {
            return 0;
        }
        int L = mo3185L();
        return (int) ((((float) Math.abs(this.f2880C0.mo12233a(o) - this.f2880C0.mo12240d(n))) / ((float) ((mo3186M() - L) + 1))) * ((float) a0Var.mo1790a()));
    }

    /* renamed from: m */
    public void mo1582m(int i) {
        this.f2883F0 = i;
        this.f2884G0 = RecyclerView.UNDEFINED_DURATION;
        C0402e eVar = this.f2882E0;
        if (eVar != null) {
            eVar.f2931X = -1;
        }
        mo1868E();
    }

    /* renamed from: n */
    public final View mo3203n(int i) {
        int i2;
        View e = mo3199e(0, mo1921f(), i);
        if (e == null || (i2 = this.f2901x0.f548c[mo1949m(e)]) == -1) {
            return null;
        }
        return mo3191a(e, this.f2900w0.get(i2));
    }

    /* renamed from: o */
    public final View mo3204o(int i) {
        View e = mo3199e(mo1921f() - 1, -1, i);
        if (e == null) {
            return null;
        }
        return mo3196b(e, this.f2900w0.get(this.f2901x0.f548c[mo1949m(e)]));
    }

    /* renamed from: p */
    public final int mo3205p(int i) {
        int i2;
        boolean z = false;
        if (mo1921f() == 0 || i == 0) {
            return 0;
        }
        mo3184K();
        boolean a = mo3117a();
        View view = this.f2890M0;
        int width = a ? view.getWidth() : view.getHeight();
        int p = a ? mo1954p() : mo1936i();
        if (mo1945l() == 1) {
            z = true;
        }
        if (z) {
            int abs = Math.abs(i);
            if (i < 0) {
                return -Math.min((p + this.f2879B0.f2907d) - width, abs);
            }
            i2 = this.f2879B0.f2907d;
            if (i2 + i <= 0) {
                return i;
            }
        } else if (i > 0) {
            return Math.min((p - this.f2879B0.f2907d) - width, i);
        } else {
            i2 = this.f2879B0.f2907d;
            if (i2 + i >= 0) {
                return i;
            }
        }
        return -i2;
    }

    /* renamed from: q */
    public void mo3206q(int i) {
        int i2 = this.f2896s0;
        if (i2 != i) {
            if (i2 == 4 || i == 4) {
                mo1867D();
                mo3183J();
            }
            this.f2896s0 = i;
            mo1868E();
        }
    }

    /* renamed from: r */
    public void mo3207r(int i) {
        if (this.f2893p0 != i) {
            mo1867D();
            this.f2893p0 = i;
            this.f2880C0 = null;
            this.f2881D0 = null;
            mo3183J();
            mo1868E();
        }
    }

    /* renamed from: s */
    public void mo3208s(int i) {
        if (i != 2) {
            int i2 = this.f2894q0;
            if (i2 != i) {
                if (i2 == 0 || i == 0) {
                    mo1867D();
                    mo3183J();
                }
                this.f2894q0 = i;
                this.f2880C0 = null;
                this.f2881D0 = null;
                mo1868E();
                return;
            }
            return;
        }
        throw new UnsupportedOperationException("wrap_reverse is not supported in FlexboxLayoutManager");
    }

    public void setFlexLines(List<C2458zk> list) {
        this.f2900w0 = list;
    }

    /* renamed from: t */
    public final void mo3209t(int i) {
        if (i < mo3186M()) {
            int f = mo1921f();
            this.f2901x0.mo596c(f);
            this.f2901x0.mo598d(f);
            this.f2901x0.mo591b(f);
            if (i < this.f2901x0.f548c.length) {
                this.f2891N0 = i;
                View g = mo1925g(0);
                if (g != null) {
                    this.f2883F0 = mo1949m(g);
                    if (mo3117a() || !this.f2898u0) {
                        this.f2884G0 = this.f2880C0.mo12240d(g) - this.f2880C0.mo12243f();
                        return;
                    }
                    this.f2884G0 = this.f2880C0.mo12237c() + this.f2880C0.mo12233a(g);
                }
            }
        }
    }

    /* renamed from: b */
    public int mo1509b(int i, RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var) {
        if (mo3117a() || (this.f2894q0 == 0 && !mo3117a())) {
            int c = mo3198c(i, vVar, a0Var);
            this.f2888K0.clear();
            return c;
        }
        int p = mo3205p(i);
        this.f2879B0.f2907d += p;
        this.f2881D0.mo12234a(-p);
        return p;
    }

    /* renamed from: b */
    public final void mo3197b(C0398b bVar, boolean z, boolean z2) {
        C0401d dVar;
        int i;
        int i2;
        if (z2) {
            mo3187N();
        } else {
            this.f2878A0.f2922b = false;
        }
        if (mo3117a() || !this.f2898u0) {
            dVar = this.f2878A0;
            i = bVar.f2906c;
        } else {
            dVar = this.f2878A0;
            i = this.f2890M0.getWidth() - bVar.f2906c;
        }
        dVar.f2921a = i - this.f2880C0.mo12243f();
        C0401d dVar2 = this.f2878A0;
        dVar2.f2924d = bVar.f2904a;
        dVar2.f2928h = 1;
        dVar2.f2929i = -1;
        dVar2.f2925e = bVar.f2906c;
        dVar2.f2926f = RecyclerView.UNDEFINED_DURATION;
        int i3 = bVar.f2905b;
        dVar2.f2923c = i3;
        if (z && i3 > 0 && this.f2900w0.size() > (i2 = bVar.f2905b)) {
            C0401d dVar3 = this.f2878A0;
            dVar3.f2923c--;
            dVar3.f2924d -= this.f2900w0.get(i2).f18438h;
        }
    }

    /* renamed from: a */
    public final View mo3190a(int i, int i2, boolean z) {
        int i3 = i2;
        int i4 = i;
        int i5 = i3 > i4 ? 1 : -1;
        while (i4 != i3) {
            View g = mo1925g(i4);
            int paddingLeft = getPaddingLeft();
            int paddingTop = getPaddingTop();
            int p = mo1954p() - getPaddingRight();
            int i6 = mo1936i() - getPaddingBottom();
            int g2 = mo1924g(g) - ((RecyclerView.C0237p) g.getLayoutParams()).leftMargin;
            int k = mo1943k(g) - ((RecyclerView.C0237p) g.getLayoutParams()).topMargin;
            int j = mo1940j(g) + ((RecyclerView.C0237p) g.getLayoutParams()).rightMargin;
            int f = mo1922f(g) + ((RecyclerView.C0237p) g.getLayoutParams()).bottomMargin;
            boolean z2 = false;
            boolean z3 = paddingLeft <= g2 && p >= j;
            boolean z4 = g2 >= p || j >= paddingLeft;
            boolean z5 = paddingTop <= k && i6 >= f;
            boolean z6 = k >= i6 || f >= paddingTop;
            if (!z ? !(!z4 || !z6) : !(!z3 || !z5)) {
                z2 = true;
            }
            if (z2) {
                return g;
            }
            i4 += i5;
        }
        return null;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:29:0x0057, code lost:
        if (r0.f2894q0 == 2) goto L_0x0065;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x0063, code lost:
        if (r0.f2894q0 == 2) goto L_0x0065;
     */
    /* JADX WARNING: Removed duplicated region for block: B:105:0x01a8  */
    /* JADX WARNING: Removed duplicated region for block: B:108:0x01b1  */
    /* JADX WARNING: Removed duplicated region for block: B:134:0x0220  */
    /* JADX WARNING: Removed duplicated region for block: B:137:0x0226  */
    /* JADX WARNING: Removed duplicated region for block: B:140:0x0235  */
    /* JADX WARNING: Removed duplicated region for block: B:149:0x026a  */
    /* JADX WARNING: Removed duplicated region for block: B:150:0x026c  */
    /* JADX WARNING: Removed duplicated region for block: B:152:0x026f  */
    /* JADX WARNING: Removed duplicated region for block: B:160:0x0288  */
    /* JADX WARNING: Removed duplicated region for block: B:187:0x030d  */
    /* JADX WARNING: Removed duplicated region for block: B:199:0x037c  */
    /* JADX WARNING: Removed duplicated region for block: B:200:0x0385  */
    /* JADX WARNING: Removed duplicated region for block: B:203:0x0394  */
    /* JADX WARNING: Removed duplicated region for block: B:207:0x03cb  */
    /* JADX WARNING: Removed duplicated region for block: B:215:0x0420  */
    /* JADX WARNING: Removed duplicated region for block: B:216:0x0438  */
    /* JADX WARNING: Removed duplicated region for block: B:219:0x0455  */
    /* JADX WARNING: Removed duplicated region for block: B:224:? A[RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x0071  */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x0090  */
    /* JADX WARNING: Removed duplicated region for block: B:63:0x00cf  */
    /* renamed from: c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo1517c(androidx.recyclerview.widget.RecyclerView.C0244v r22, androidx.recyclerview.widget.RecyclerView.C0212a0 r23) {
        /*
            r21 = this;
            r0 = r21
            r1 = r22
            r2 = r23
            r0.f2902y0 = r1
            r0.f2903z0 = r2
            int r3 = r23.mo1790a()
            if (r3 != 0) goto L_0x0015
            boolean r4 = r2.f1296h
            if (r4 == 0) goto L_0x0015
            return
        L_0x0015:
            int r4 = r21.mo1945l()
            int r5 = r0.f2893p0
            r6 = 2
            r7 = 1
            r8 = 0
            if (r5 == 0) goto L_0x005a
            if (r5 == r7) goto L_0x004e
            if (r5 == r6) goto L_0x003d
            r9 = 3
            if (r5 == r9) goto L_0x002a
            r0.f2898u0 = r8
            goto L_0x0067
        L_0x002a:
            if (r4 != r7) goto L_0x002e
            r4 = 1
            goto L_0x002f
        L_0x002e:
            r4 = 0
        L_0x002f:
            r0.f2898u0 = r4
            int r4 = r0.f2894q0
            if (r4 != r6) goto L_0x003a
            boolean r4 = r0.f2898u0
            r4 = r4 ^ r7
            r0.f2898u0 = r4
        L_0x003a:
            r0.f2899v0 = r7
            goto L_0x006a
        L_0x003d:
            if (r4 != r7) goto L_0x0041
            r4 = 1
            goto L_0x0042
        L_0x0041:
            r4 = 0
        L_0x0042:
            r0.f2898u0 = r4
            int r4 = r0.f2894q0
            if (r4 != r6) goto L_0x0067
            boolean r4 = r0.f2898u0
            r4 = r4 ^ r7
            r0.f2898u0 = r4
            goto L_0x0067
        L_0x004e:
            if (r4 == r7) goto L_0x0052
            r4 = 1
            goto L_0x0053
        L_0x0052:
            r4 = 0
        L_0x0053:
            r0.f2898u0 = r4
            int r4 = r0.f2894q0
            if (r4 != r6) goto L_0x0067
            goto L_0x0065
        L_0x005a:
            if (r4 != r7) goto L_0x005e
            r4 = 1
            goto L_0x005f
        L_0x005e:
            r4 = 0
        L_0x005f:
            r0.f2898u0 = r4
            int r4 = r0.f2894q0
            if (r4 != r6) goto L_0x0067
        L_0x0065:
            r4 = 1
            goto L_0x0068
        L_0x0067:
            r4 = 0
        L_0x0068:
            r0.f2899v0 = r4
        L_0x006a:
            r21.mo3184K()
            com.google.android.flexbox.FlexboxLayoutManager$d r4 = r0.f2878A0
            if (r4 != 0) goto L_0x0079
            com.google.android.flexbox.FlexboxLayoutManager$d r4 = new com.google.android.flexbox.FlexboxLayoutManager$d
            r5 = 0
            r4.<init>(r5)
            r0.f2878A0 = r4
        L_0x0079:
            al r4 = r0.f2901x0
            r4.mo596c(r3)
            al r4 = r0.f2901x0
            r4.mo598d(r3)
            al r4 = r0.f2901x0
            r4.mo591b((int) r3)
            com.google.android.flexbox.FlexboxLayoutManager$d r4 = r0.f2878A0
            r4.f2930j = r8
            com.google.android.flexbox.FlexboxLayoutManager$e r4 = r0.f2882E0
            if (r4 == 0) goto L_0x00a1
            int r4 = r4.f2931X
            if (r4 < 0) goto L_0x0098
            if (r4 >= r3) goto L_0x0098
            r4 = 1
            goto L_0x0099
        L_0x0098:
            r4 = 0
        L_0x0099:
            if (r4 == 0) goto L_0x00a1
            com.google.android.flexbox.FlexboxLayoutManager$e r4 = r0.f2882E0
            int r4 = r4.f2931X
            r0.f2883F0 = r4
        L_0x00a1:
            com.google.android.flexbox.FlexboxLayoutManager$b r4 = r0.f2879B0
            boolean r4 = r4.f2909f
            r5 = -2147483648(0xffffffff80000000, float:-0.0)
            r6 = -1
            if (r4 == 0) goto L_0x00b2
            int r4 = r0.f2883F0
            if (r4 != r6) goto L_0x00b2
            com.google.android.flexbox.FlexboxLayoutManager$e r4 = r0.f2882E0
            if (r4 == 0) goto L_0x0293
        L_0x00b2:
            com.google.android.flexbox.FlexboxLayoutManager$b r4 = r0.f2879B0
            com.google.android.flexbox.FlexboxLayoutManager.C0398b.m2797b(r4)
            com.google.android.flexbox.FlexboxLayoutManager$b r4 = r0.f2879B0
            com.google.android.flexbox.FlexboxLayoutManager$e r9 = r0.f2882E0
            boolean r10 = r2.f1296h
            if (r10 != 0) goto L_0x01ac
            int r10 = r0.f2883F0
            if (r10 != r6) goto L_0x00c5
            goto L_0x01ac
        L_0x00c5:
            if (r10 < 0) goto L_0x01a8
            int r11 = r23.mo1790a()
            if (r10 < r11) goto L_0x00cf
            goto L_0x01a8
        L_0x00cf:
            int r10 = r0.f2883F0
            r4.f2904a = r10
            al r10 = r0.f2901x0
            int[] r10 = r10.f548c
            int r11 = r4.f2904a
            r10 = r10[r11]
            r4.f2905b = r10
            com.google.android.flexbox.FlexboxLayoutManager$e r10 = r0.f2882E0
            if (r10 == 0) goto L_0x0101
            int r11 = r23.mo1790a()
            int r10 = r10.f2931X
            if (r10 < 0) goto L_0x00ed
            if (r10 >= r11) goto L_0x00ed
            r10 = 1
            goto L_0x00ee
        L_0x00ed:
            r10 = 0
        L_0x00ee:
            if (r10 == 0) goto L_0x0101
            yc r10 = r0.f2880C0
            int r10 = r10.mo12243f()
            int r9 = r9.f2932Y
            int r10 = r10 + r9
            r4.f2906c = r10
            r4.f2910g = r7
            r4.f2905b = r6
            goto L_0x01a6
        L_0x0101:
            int r9 = r0.f2884G0
            if (r9 != r5) goto L_0x0187
            int r9 = r0.f2883F0
            android.view.View r9 = r0.mo1574f((int) r9)
            if (r9 == 0) goto L_0x016c
            yc r10 = r0.f2880C0
            int r10 = r10.mo12236b(r9)
            yc r11 = r0.f2880C0
            int r11 = r11.mo12245g()
            if (r10 <= r11) goto L_0x011c
            goto L_0x0183
        L_0x011c:
            yc r10 = r0.f2880C0
            int r10 = r10.mo12240d(r9)
            yc r11 = r0.f2880C0
            int r11 = r11.mo12243f()
            int r10 = r10 - r11
            if (r10 >= 0) goto L_0x0137
            yc r9 = r0.f2880C0
            int r9 = r9.mo12243f()
            r4.f2906c = r9
            r4.f2908e = r8
            goto L_0x01a6
        L_0x0137:
            yc r10 = r0.f2880C0
            int r10 = r10.mo12235b()
            yc r11 = r0.f2880C0
            int r11 = r11.mo12233a((android.view.View) r9)
            int r10 = r10 - r11
            if (r10 >= 0) goto L_0x0151
            yc r9 = r0.f2880C0
            int r9 = r9.mo12235b()
            r4.f2906c = r9
            r4.f2908e = r7
            goto L_0x01a6
        L_0x0151:
            boolean r10 = r4.f2908e
            if (r10 == 0) goto L_0x0163
            yc r10 = r0.f2880C0
            int r9 = r10.mo12233a((android.view.View) r9)
            yc r10 = r0.f2880C0
            int r10 = r10.mo12898h()
            int r10 = r10 + r9
            goto L_0x0169
        L_0x0163:
            yc r10 = r0.f2880C0
            int r10 = r10.mo12240d(r9)
        L_0x0169:
            r4.f2906c = r10
            goto L_0x01a6
        L_0x016c:
            int r9 = r21.mo1921f()
            if (r9 <= 0) goto L_0x0183
            android.view.View r9 = r0.mo1925g((int) r8)
            int r9 = r0.mo1949m((android.view.View) r9)
            int r10 = r0.f2883F0
            if (r10 >= r9) goto L_0x0180
            r9 = 1
            goto L_0x0181
        L_0x0180:
            r9 = 0
        L_0x0181:
            r4.f2908e = r9
        L_0x0183:
            com.google.android.flexbox.FlexboxLayoutManager.C0398b.m2796a(r4)
            goto L_0x01a6
        L_0x0187:
            boolean r9 = r21.mo3117a()
            if (r9 != 0) goto L_0x019b
            boolean r9 = r0.f2898u0
            if (r9 == 0) goto L_0x019b
            int r9 = r0.f2884G0
            yc r10 = r0.f2880C0
            int r10 = r10.mo12237c()
            int r9 = r9 - r10
            goto L_0x01a4
        L_0x019b:
            yc r9 = r0.f2880C0
            int r9 = r9.mo12243f()
            int r10 = r0.f2884G0
            int r9 = r9 + r10
        L_0x01a4:
            r4.f2906c = r9
        L_0x01a6:
            r9 = 1
            goto L_0x01ad
        L_0x01a8:
            r0.f2883F0 = r6
            r0.f2884G0 = r5
        L_0x01ac:
            r9 = 0
        L_0x01ad:
            if (r9 == 0) goto L_0x01b1
            goto L_0x028f
        L_0x01b1:
            int r9 = r21.mo1921f()
            if (r9 != 0) goto L_0x01b9
            goto L_0x0284
        L_0x01b9:
            boolean r9 = r4.f2908e
            if (r9 == 0) goto L_0x01c6
            int r9 = r23.mo1790a()
            android.view.View r9 = r0.mo3204o(r9)
            goto L_0x01ce
        L_0x01c6:
            int r9 = r23.mo1790a()
            android.view.View r9 = r0.mo3203n(r9)
        L_0x01ce:
            if (r9 == 0) goto L_0x0284
            com.google.android.flexbox.FlexboxLayoutManager r10 = com.google.android.flexbox.FlexboxLayoutManager.this
            int r11 = r10.f2894q0
            if (r11 != 0) goto L_0x01d9
            yc r10 = r10.f2881D0
            goto L_0x01db
        L_0x01d9:
            yc r10 = r10.f2880C0
        L_0x01db:
            com.google.android.flexbox.FlexboxLayoutManager r11 = com.google.android.flexbox.FlexboxLayoutManager.this
            boolean r11 = r11.mo3117a()
            if (r11 != 0) goto L_0x01f7
            com.google.android.flexbox.FlexboxLayoutManager r11 = com.google.android.flexbox.FlexboxLayoutManager.this
            boolean r11 = r11.f2898u0
            if (r11 == 0) goto L_0x01f7
            boolean r11 = r4.f2908e
            if (r11 == 0) goto L_0x01f2
            int r11 = r10.mo12240d(r9)
            goto L_0x01ff
        L_0x01f2:
            int r10 = r10.mo12233a((android.view.View) r9)
            goto L_0x0209
        L_0x01f7:
            boolean r11 = r4.f2908e
            if (r11 == 0) goto L_0x0205
            int r11 = r10.mo12233a((android.view.View) r9)
        L_0x01ff:
            int r10 = r10.mo12898h()
            int r10 = r10 + r11
            goto L_0x0209
        L_0x0205:
            int r10 = r10.mo12240d(r9)
        L_0x0209:
            r4.f2906c = r10
            com.google.android.flexbox.FlexboxLayoutManager r10 = com.google.android.flexbox.FlexboxLayoutManager.this
            int r10 = r10.mo1949m((android.view.View) r9)
            r4.f2904a = r10
            r4.f2910g = r8
            com.google.android.flexbox.FlexboxLayoutManager r10 = com.google.android.flexbox.FlexboxLayoutManager.this
            al r10 = r10.f2901x0
            int[] r10 = r10.f548c
            int r11 = r4.f2904a
            if (r11 == r6) goto L_0x0220
            goto L_0x0221
        L_0x0220:
            r11 = 0
        L_0x0221:
            r10 = r10[r11]
            if (r10 == r6) goto L_0x0226
            goto L_0x0227
        L_0x0226:
            r10 = 0
        L_0x0227:
            r4.f2905b = r10
            com.google.android.flexbox.FlexboxLayoutManager r10 = com.google.android.flexbox.FlexboxLayoutManager.this
            java.util.List<zk> r10 = r10.f2900w0
            int r10 = r10.size()
            int r11 = r4.f2905b
            if (r10 <= r11) goto L_0x0243
            com.google.android.flexbox.FlexboxLayoutManager r10 = com.google.android.flexbox.FlexboxLayoutManager.this
            java.util.List<zk> r10 = r10.f2900w0
            java.lang.Object r10 = r10.get(r11)
            zk r10 = (p000.C2458zk) r10
            int r10 = r10.f18445o
            r4.f2904a = r10
        L_0x0243:
            boolean r10 = r2.f1296h
            if (r10 != 0) goto L_0x0282
            boolean r10 = r21.mo1488I()
            if (r10 == 0) goto L_0x0282
            yc r10 = r0.f2880C0
            int r10 = r10.mo12240d(r9)
            yc r11 = r0.f2880C0
            int r11 = r11.mo12235b()
            if (r10 >= r11) goto L_0x026c
            yc r10 = r0.f2880C0
            int r9 = r10.mo12233a((android.view.View) r9)
            yc r10 = r0.f2880C0
            int r10 = r10.mo12243f()
            if (r9 >= r10) goto L_0x026a
            goto L_0x026c
        L_0x026a:
            r9 = 0
            goto L_0x026d
        L_0x026c:
            r9 = 1
        L_0x026d:
            if (r9 == 0) goto L_0x0282
            boolean r9 = r4.f2908e
            if (r9 == 0) goto L_0x027a
            yc r9 = r0.f2880C0
            int r9 = r9.mo12235b()
            goto L_0x0280
        L_0x027a:
            yc r9 = r0.f2880C0
            int r9 = r9.mo12243f()
        L_0x0280:
            r4.f2906c = r9
        L_0x0282:
            r9 = 1
            goto L_0x0285
        L_0x0284:
            r9 = 0
        L_0x0285:
            if (r9 == 0) goto L_0x0288
            goto L_0x028f
        L_0x0288:
            com.google.android.flexbox.FlexboxLayoutManager.C0398b.m2796a(r4)
            r4.f2904a = r8
            r4.f2905b = r8
        L_0x028f:
            com.google.android.flexbox.FlexboxLayoutManager$b r4 = r0.f2879B0
            r4.f2909f = r7
        L_0x0293:
            r21.mo1882a((androidx.recyclerview.widget.RecyclerView.C0244v) r22)
            com.google.android.flexbox.FlexboxLayoutManager$b r4 = r0.f2879B0
            boolean r9 = r4.f2908e
            if (r9 == 0) goto L_0x02a0
            r0.mo3197b((com.google.android.flexbox.FlexboxLayoutManager.C0398b) r4, (boolean) r8, (boolean) r7)
            goto L_0x02a3
        L_0x02a0:
            r0.mo3194a((com.google.android.flexbox.FlexboxLayoutManager.C0398b) r4, (boolean) r8, (boolean) r7)
        L_0x02a3:
            int r4 = r21.mo1954p()
            int r9 = r21.mo1956q()
            int r4 = android.view.View.MeasureSpec.makeMeasureSpec(r4, r9)
            int r9 = r21.mo1936i()
            int r10 = r21.mo1939j()
            int r9 = android.view.View.MeasureSpec.makeMeasureSpec(r9, r10)
            int r10 = r21.mo1954p()
            int r11 = r21.mo1936i()
            boolean r12 = r21.mo3117a()
            if (r12 == 0) goto L_0x02e5
            int r12 = r0.f2885H0
            if (r12 == r5) goto L_0x02d1
            if (r12 == r10) goto L_0x02d1
            r5 = 1
            goto L_0x02d2
        L_0x02d1:
            r5 = 0
        L_0x02d2:
            com.google.android.flexbox.FlexboxLayoutManager$d r12 = r0.f2878A0
            boolean r13 = r12.f2922b
            if (r13 == 0) goto L_0x0301
            android.content.Context r12 = r0.f2889L0
            android.content.res.Resources r12 = r12.getResources()
            android.util.DisplayMetrics r12 = r12.getDisplayMetrics()
            int r12 = r12.heightPixels
            goto L_0x0303
        L_0x02e5:
            int r12 = r0.f2886I0
            if (r12 == r5) goto L_0x02ed
            if (r12 == r11) goto L_0x02ed
            r5 = 1
            goto L_0x02ee
        L_0x02ed:
            r5 = 0
        L_0x02ee:
            com.google.android.flexbox.FlexboxLayoutManager$d r12 = r0.f2878A0
            boolean r13 = r12.f2922b
            if (r13 == 0) goto L_0x0301
            android.content.Context r12 = r0.f2889L0
            android.content.res.Resources r12 = r12.getResources()
            android.util.DisplayMetrics r12 = r12.getDisplayMetrics()
            int r12 = r12.widthPixels
            goto L_0x0303
        L_0x0301:
            int r12 = r12.f2921a
        L_0x0303:
            r17 = r12
            r0.f2885H0 = r10
            r0.f2886I0 = r11
            int r10 = r0.f2891N0
            if (r10 != r6) goto L_0x0378
            int r10 = r0.f2883F0
            if (r10 != r6) goto L_0x0313
            if (r5 == 0) goto L_0x0378
        L_0x0313:
            com.google.android.flexbox.FlexboxLayoutManager$b r3 = r0.f2879B0
            boolean r3 = r3.f2908e
            if (r3 == 0) goto L_0x031b
            goto L_0x041a
        L_0x031b:
            java.util.List<zk> r3 = r0.f2900w0
            r3.clear()
            al$b r3 = r0.f2892O0
            r3.mo600a()
            boolean r3 = r21.mo3117a()
            al r10 = r0.f2901x0
            al$b r11 = r0.f2892O0
            if (r3 == 0) goto L_0x0342
            com.google.android.flexbox.FlexboxLayoutManager$b r3 = r0.f2879B0
            int r3 = r3.f2904a
            java.util.List<zk> r5 = r0.f2900w0
            r15 = 0
            r12 = r4
            r13 = r9
            r14 = r17
            r16 = r3
            r17 = r5
            r10.mo579a((p000.C0111al.C0113b) r11, (int) r12, (int) r13, (int) r14, (int) r15, (int) r16, (java.util.List<p000.C2458zk>) r17)
            goto L_0x0354
        L_0x0342:
            com.google.android.flexbox.FlexboxLayoutManager$b r3 = r0.f2879B0
            int r3 = r3.f2904a
            java.util.List<zk> r5 = r0.f2900w0
            r15 = 0
            r12 = r9
            r13 = r4
            r14 = r17
            r16 = r3
            r17 = r5
            r10.mo579a((p000.C0111al.C0113b) r11, (int) r12, (int) r13, (int) r14, (int) r15, (int) r16, (java.util.List<p000.C2458zk>) r17)
        L_0x0354:
            al$b r3 = r0.f2892O0
            java.util.List<zk> r3 = r3.f551a
            r0.f2900w0 = r3
            al r3 = r0.f2901x0
            r3.mo592b((int) r4, (int) r9, (int) r8)
            al r3 = r0.f2901x0
            r3.mo599e(r8)
            com.google.android.flexbox.FlexboxLayoutManager$b r3 = r0.f2879B0
            al r4 = r0.f2901x0
            int[] r4 = r4.f548c
            int r5 = r3.f2904a
            r4 = r4[r5]
            r3.f2905b = r4
            com.google.android.flexbox.FlexboxLayoutManager$d r4 = r0.f2878A0
            int r3 = r3.f2905b
            r4.f2923c = r3
            goto L_0x041a
        L_0x0378:
            int r5 = r0.f2891N0
            if (r5 == r6) goto L_0x0385
            com.google.android.flexbox.FlexboxLayoutManager$b r6 = r0.f2879B0
            int r6 = r6.f2904a
            int r5 = java.lang.Math.min(r5, r6)
            goto L_0x0389
        L_0x0385:
            com.google.android.flexbox.FlexboxLayoutManager$b r5 = r0.f2879B0
            int r5 = r5.f2904a
        L_0x0389:
            al$b r6 = r0.f2892O0
            r6.mo600a()
            boolean r6 = r21.mo3117a()
            if (r6 == 0) goto L_0x03cb
            java.util.List<zk> r6 = r0.f2900w0
            int r6 = r6.size()
            if (r6 <= 0) goto L_0x03b3
            al r3 = r0.f2901x0
            java.util.List<zk> r6 = r0.f2900w0
            r3.mo584a((java.util.List<p000.C2458zk>) r6, (int) r5)
            al r3 = r0.f2901x0
            al$b r6 = r0.f2892O0
            com.google.android.flexbox.FlexboxLayoutManager$b r10 = r0.f2879B0
            int r10 = r10.f2904a
            java.util.List<zk> r11 = r0.f2900w0
            r13 = r3
            r15 = r4
            r14 = r6
            r16 = r9
            goto L_0x03e9
        L_0x03b3:
            al r6 = r0.f2901x0
            r6.mo591b((int) r3)
            al r10 = r0.f2901x0
            al$b r11 = r0.f2892O0
            r15 = 0
            java.util.List<zk> r3 = r0.f2900w0
            r16 = -1
            r12 = r4
            r13 = r9
            r14 = r17
            r17 = r3
            r10.mo579a((p000.C0111al.C0113b) r11, (int) r12, (int) r13, (int) r14, (int) r15, (int) r16, (java.util.List<p000.C2458zk>) r17)
            goto L_0x040a
        L_0x03cb:
            java.util.List<zk> r6 = r0.f2900w0
            int r6 = r6.size()
            if (r6 <= 0) goto L_0x03f3
            al r3 = r0.f2901x0
            java.util.List<zk> r6 = r0.f2900w0
            r3.mo584a((java.util.List<p000.C2458zk>) r6, (int) r5)
            al r3 = r0.f2901x0
            al$b r6 = r0.f2892O0
            com.google.android.flexbox.FlexboxLayoutManager$b r10 = r0.f2879B0
            int r10 = r10.f2904a
            java.util.List<zk> r11 = r0.f2900w0
            r13 = r3
            r16 = r4
            r14 = r6
            r15 = r9
        L_0x03e9:
            r19 = r10
            r20 = r11
            r18 = r5
            r13.mo579a((p000.C0111al.C0113b) r14, (int) r15, (int) r16, (int) r17, (int) r18, (int) r19, (java.util.List<p000.C2458zk>) r20)
            goto L_0x040a
        L_0x03f3:
            al r6 = r0.f2901x0
            r6.mo591b((int) r3)
            al r10 = r0.f2901x0
            al$b r11 = r0.f2892O0
            r15 = 0
            java.util.List<zk> r3 = r0.f2900w0
            r16 = -1
            r12 = r9
            r13 = r4
            r14 = r17
            r17 = r3
            r10.mo579a((p000.C0111al.C0113b) r11, (int) r12, (int) r13, (int) r14, (int) r15, (int) r16, (java.util.List<p000.C2458zk>) r17)
        L_0x040a:
            al$b r3 = r0.f2892O0
            java.util.List<zk> r3 = r3.f551a
            r0.f2900w0 = r3
            al r3 = r0.f2901x0
            r3.mo592b((int) r4, (int) r9, (int) r5)
            al r3 = r0.f2901x0
            r3.mo599e(r5)
        L_0x041a:
            com.google.android.flexbox.FlexboxLayoutManager$b r3 = r0.f2879B0
            boolean r3 = r3.f2908e
            if (r3 == 0) goto L_0x0438
            com.google.android.flexbox.FlexboxLayoutManager$d r3 = r0.f2878A0
            r0.mo3189a((androidx.recyclerview.widget.RecyclerView.C0244v) r1, (androidx.recyclerview.widget.RecyclerView.C0212a0) r2, (com.google.android.flexbox.FlexboxLayoutManager.C0401d) r3)
            com.google.android.flexbox.FlexboxLayoutManager$d r3 = r0.f2878A0
            int r3 = r3.f2925e
            com.google.android.flexbox.FlexboxLayoutManager$b r4 = r0.f2879B0
            r0.mo3194a((com.google.android.flexbox.FlexboxLayoutManager.C0398b) r4, (boolean) r7, (boolean) r8)
            com.google.android.flexbox.FlexboxLayoutManager$d r4 = r0.f2878A0
            r0.mo3189a((androidx.recyclerview.widget.RecyclerView.C0244v) r1, (androidx.recyclerview.widget.RecyclerView.C0212a0) r2, (com.google.android.flexbox.FlexboxLayoutManager.C0401d) r4)
            com.google.android.flexbox.FlexboxLayoutManager$d r4 = r0.f2878A0
            int r4 = r4.f2925e
            goto L_0x044f
        L_0x0438:
            com.google.android.flexbox.FlexboxLayoutManager$d r3 = r0.f2878A0
            r0.mo3189a((androidx.recyclerview.widget.RecyclerView.C0244v) r1, (androidx.recyclerview.widget.RecyclerView.C0212a0) r2, (com.google.android.flexbox.FlexboxLayoutManager.C0401d) r3)
            com.google.android.flexbox.FlexboxLayoutManager$d r3 = r0.f2878A0
            int r4 = r3.f2925e
            com.google.android.flexbox.FlexboxLayoutManager$b r3 = r0.f2879B0
            r0.mo3197b((com.google.android.flexbox.FlexboxLayoutManager.C0398b) r3, (boolean) r7, (boolean) r8)
            com.google.android.flexbox.FlexboxLayoutManager$d r3 = r0.f2878A0
            r0.mo3189a((androidx.recyclerview.widget.RecyclerView.C0244v) r1, (androidx.recyclerview.widget.RecyclerView.C0212a0) r2, (com.google.android.flexbox.FlexboxLayoutManager.C0401d) r3)
            com.google.android.flexbox.FlexboxLayoutManager$d r3 = r0.f2878A0
            int r3 = r3.f2925e
        L_0x044f:
            int r5 = r21.mo1921f()
            if (r5 <= 0) goto L_0x046c
            com.google.android.flexbox.FlexboxLayoutManager$b r5 = r0.f2879B0
            boolean r5 = r5.f2908e
            if (r5 == 0) goto L_0x0464
            int r4 = r0.mo3188a((int) r4, (androidx.recyclerview.widget.RecyclerView.C0244v) r1, (androidx.recyclerview.widget.RecyclerView.C0212a0) r2, (boolean) r7)
            int r4 = r4 + r3
            r0.mo3195b(r4, r1, r2, r8)
            goto L_0x046c
        L_0x0464:
            int r3 = r0.mo3195b(r3, r1, r2, r7)
            int r3 = r3 + r4
            r0.mo3188a((int) r3, (androidx.recyclerview.widget.RecyclerView.C0244v) r1, (androidx.recyclerview.widget.RecyclerView.C0212a0) r2, (boolean) r8)
        L_0x046c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.flexbox.FlexboxLayoutManager.mo1517c(androidx.recyclerview.widget.RecyclerView$v, androidx.recyclerview.widget.RecyclerView$a0):void");
    }

    /* renamed from: a */
    public View mo3108a(int i) {
        View view = this.f2888K0.get(i);
        return view != null ? view : this.f2902y0.mo1984a(i, false, RecyclerView.FOREVER_NS).f1316X;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:29:0x008b, code lost:
        r0 = r3;
     */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo3193a(androidx.recyclerview.widget.RecyclerView.C0244v r12, com.google.android.flexbox.FlexboxLayoutManager.C0401d r13) {
        /*
            r11 = this;
            boolean r0 = r13.f2930j
            if (r0 != 0) goto L_0x0005
            return
        L_0x0005:
            int r0 = r13.f2929i
            r1 = 1
            r2 = 0
            r3 = -1
            if (r0 != r3) goto L_0x0091
            int r0 = r13.f2926f
            if (r0 >= 0) goto L_0x0012
            goto L_0x0110
        L_0x0012:
            yc r0 = r11.f2880C0
            r0.mo12232a()
            int r0 = r13.f2926f
            int r0 = r11.mo1921f()
            if (r0 != 0) goto L_0x0021
            goto L_0x0110
        L_0x0021:
            int r4 = r0 + -1
            android.view.View r5 = r11.mo1925g((int) r4)
            al r6 = r11.f2901x0
            int[] r6 = r6.f548c
            int r5 = r11.mo1949m((android.view.View) r5)
            r5 = r6[r5]
            if (r5 != r3) goto L_0x0035
            goto L_0x0110
        L_0x0035:
            java.util.List<zk> r3 = r11.f2900w0
            java.lang.Object r3 = r3.get(r5)
            zk r3 = (p000.C2458zk) r3
            r6 = r5
            r5 = r3
            r3 = r0
            r0 = r4
        L_0x0041:
            if (r0 < 0) goto L_0x008b
            android.view.View r7 = r11.mo1925g((int) r0)
            int r8 = r13.f2926f
            boolean r9 = r11.mo3117a()
            if (r9 != 0) goto L_0x005c
            boolean r9 = r11.f2898u0
            if (r9 == 0) goto L_0x005c
            yc r9 = r11.f2880C0
            int r9 = r9.mo12233a((android.view.View) r7)
            if (r9 > r8) goto L_0x006d
            goto L_0x006b
        L_0x005c:
            yc r9 = r11.f2880C0
            int r9 = r9.mo12240d(r7)
            yc r10 = r11.f2880C0
            int r10 = r10.mo12232a()
            int r10 = r10 - r8
            if (r9 < r10) goto L_0x006d
        L_0x006b:
            r8 = 1
            goto L_0x006e
        L_0x006d:
            r8 = 0
        L_0x006e:
            if (r8 == 0) goto L_0x008b
            int r8 = r5.f18445o
            int r7 = r11.mo1949m((android.view.View) r7)
            if (r8 != r7) goto L_0x0088
            if (r6 > 0) goto L_0x007b
            goto L_0x008c
        L_0x007b:
            int r3 = r13.f2929i
            int r6 = r6 + r3
            java.util.List<zk> r3 = r11.f2900w0
            java.lang.Object r3 = r3.get(r6)
            zk r3 = (p000.C2458zk) r3
            r5 = r3
            r3 = r0
        L_0x0088:
            int r0 = r0 + -1
            goto L_0x0041
        L_0x008b:
            r0 = r3
        L_0x008c:
            r11.mo3192a((androidx.recyclerview.widget.RecyclerView.C0244v) r12, (int) r0, (int) r4)
            goto L_0x0110
        L_0x0091:
            int r0 = r13.f2926f
            if (r0 >= 0) goto L_0x0097
            goto L_0x0110
        L_0x0097:
            int r0 = r11.mo1921f()
            if (r0 != 0) goto L_0x009f
            goto L_0x0110
        L_0x009f:
            android.view.View r4 = r11.mo1925g((int) r2)
            al r5 = r11.f2901x0
            int[] r5 = r5.f548c
            int r4 = r11.mo1949m((android.view.View) r4)
            r4 = r5[r4]
            if (r4 != r3) goto L_0x00b0
            goto L_0x0110
        L_0x00b0:
            java.util.List<zk> r5 = r11.f2900w0
            java.lang.Object r5 = r5.get(r4)
            zk r5 = (p000.C2458zk) r5
            r6 = r4
            r3 = 0
            r4 = -1
        L_0x00bb:
            if (r3 >= r0) goto L_0x010c
            android.view.View r7 = r11.mo1925g((int) r3)
            int r8 = r13.f2926f
            boolean r9 = r11.mo3117a()
            if (r9 != 0) goto L_0x00dd
            boolean r9 = r11.f2898u0
            if (r9 == 0) goto L_0x00dd
            yc r9 = r11.f2880C0
            int r9 = r9.mo12232a()
            yc r10 = r11.f2880C0
            int r10 = r10.mo12240d(r7)
            int r9 = r9 - r10
            if (r9 > r8) goto L_0x00e7
            goto L_0x00e5
        L_0x00dd:
            yc r9 = r11.f2880C0
            int r9 = r9.mo12233a((android.view.View) r7)
            if (r9 > r8) goto L_0x00e7
        L_0x00e5:
            r8 = 1
            goto L_0x00e8
        L_0x00e7:
            r8 = 0
        L_0x00e8:
            if (r8 == 0) goto L_0x010c
            int r8 = r5.f18446p
            int r7 = r11.mo1949m((android.view.View) r7)
            if (r8 != r7) goto L_0x0109
            java.util.List<zk> r4 = r11.f2900w0
            int r4 = r4.size()
            int r4 = r4 - r1
            if (r6 < r4) goto L_0x00fc
            goto L_0x010d
        L_0x00fc:
            int r4 = r13.f2929i
            int r6 = r6 + r4
            java.util.List<zk> r4 = r11.f2900w0
            java.lang.Object r4 = r4.get(r6)
            zk r4 = (p000.C2458zk) r4
            r5 = r4
            r4 = r3
        L_0x0109:
            int r3 = r3 + 1
            goto L_0x00bb
        L_0x010c:
            r3 = r4
        L_0x010d:
            r11.mo3192a((androidx.recyclerview.widget.RecyclerView.C0244v) r12, (int) r2, (int) r3)
        L_0x0110:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.flexbox.FlexboxLayoutManager.mo3193a(androidx.recyclerview.widget.RecyclerView$v, com.google.android.flexbox.FlexboxLayoutManager$d):void");
    }

    /* renamed from: a */
    public int mo1492a(int i, RecyclerView.C0244v vVar, RecyclerView.C0212a0 a0Var) {
        if (!mo3117a() || (this.f2894q0 == 0 && mo3117a())) {
            int c = mo3198c(i, vVar, a0Var);
            this.f2888K0.clear();
            return c;
        }
        int p = mo3205p(i);
        this.f2879B0.f2907d += p;
        this.f2881D0.mo12234a(-p);
        return p;
    }

    /* renamed from: a */
    public void mo1561a(RecyclerView recyclerView, RecyclerView.C0212a0 a0Var, int i) {
        C1913tc tcVar = new C1913tc(recyclerView.getContext());
        tcVar.f1391a = i;
        mo1904b((RecyclerView.C0249z) tcVar);
    }

    /* renamed from: a */
    public final void mo3194a(C0398b bVar, boolean z, boolean z2) {
        C0401d dVar;
        int b;
        int i;
        int i2;
        if (z2) {
            mo3187N();
        } else {
            this.f2878A0.f2922b = false;
        }
        if (mo3117a() || !this.f2898u0) {
            dVar = this.f2878A0;
            b = this.f2880C0.mo12235b();
            i = bVar.f2906c;
        } else {
            dVar = this.f2878A0;
            b = bVar.f2906c;
            i = getPaddingRight();
        }
        dVar.f2921a = b - i;
        C0401d dVar2 = this.f2878A0;
        dVar2.f2924d = bVar.f2904a;
        dVar2.f2928h = 1;
        dVar2.f2929i = 1;
        dVar2.f2925e = bVar.f2906c;
        dVar2.f2926f = RecyclerView.UNDEFINED_DURATION;
        dVar2.f2923c = bVar.f2905b;
        if (z && this.f2900w0.size() > 1 && (i2 = bVar.f2905b) >= 0 && i2 < this.f2900w0.size() - 1) {
            C0401d dVar3 = this.f2878A0;
            dVar3.f2923c++;
            dVar3.f2924d += this.f2900w0.get(bVar.f2905b).f18438h;
        }
    }
}
