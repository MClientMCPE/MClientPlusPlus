package com.google.android.flexbox;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import p000.C0111al;

public class FlexboxLayout extends ViewGroup implements C2290xk {

    /* renamed from: a0 */
    public int f2850a0;

    /* renamed from: b0 */
    public int f2851b0;

    /* renamed from: c0 */
    public int f2852c0;

    /* renamed from: d0 */
    public int f2853d0;

    /* renamed from: e0 */
    public int f2854e0;

    /* renamed from: f0 */
    public int f2855f0;

    /* renamed from: g0 */
    public Drawable f2856g0;

    /* renamed from: h0 */
    public Drawable f2857h0;

    /* renamed from: i0 */
    public int f2858i0;

    /* renamed from: j0 */
    public int f2859j0;

    /* renamed from: k0 */
    public int f2860k0;

    /* renamed from: l0 */
    public int f2861l0;

    /* renamed from: m0 */
    public int[] f2862m0;

    /* renamed from: n0 */
    public SparseIntArray f2863n0;

    /* renamed from: o0 */
    public C0111al f2864o0;

    /* renamed from: p0 */
    public List<C2458zk> f2865p0;

    /* renamed from: q0 */
    public C0111al.C0113b f2866q0;

    /* renamed from: com.google.android.flexbox.FlexboxLayout$a */
    public static class C0395a extends ViewGroup.MarginLayoutParams implements C2367yk {
        public static final Parcelable.Creator<C0395a> CREATOR = new C0396a();

        /* renamed from: X */
        public int f2867X = 1;

        /* renamed from: Y */
        public float f2868Y = 0.0f;

        /* renamed from: Z */
        public float f2869Z = 1.0f;

        /* renamed from: a0 */
        public int f2870a0 = -1;

        /* renamed from: b0 */
        public float f2871b0 = -1.0f;

        /* renamed from: c0 */
        public int f2872c0 = -1;

        /* renamed from: d0 */
        public int f2873d0 = -1;

        /* renamed from: e0 */
        public int f2874e0 = 16777215;

        /* renamed from: f0 */
        public int f2875f0 = 16777215;

        /* renamed from: g0 */
        public boolean f2876g0;

        /* renamed from: com.google.android.flexbox.FlexboxLayout$a$a */
        public static class C0396a implements Parcelable.Creator<C0395a> {
            public Object createFromParcel(Parcel parcel) {
                return new C0395a(parcel);
            }

            public Object[] newArray(int i) {
                return new C0395a[i];
            }
        }

        public C0395a(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0311bl.FlexboxLayout_Layout);
            this.f2867X = obtainStyledAttributes.getInt(C0311bl.FlexboxLayout_Layout_layout_order, 1);
            this.f2868Y = obtainStyledAttributes.getFloat(C0311bl.FlexboxLayout_Layout_layout_flexGrow, 0.0f);
            this.f2869Z = obtainStyledAttributes.getFloat(C0311bl.FlexboxLayout_Layout_layout_flexShrink, 1.0f);
            this.f2870a0 = obtainStyledAttributes.getInt(C0311bl.FlexboxLayout_Layout_layout_alignSelf, -1);
            this.f2871b0 = obtainStyledAttributes.getFraction(C0311bl.FlexboxLayout_Layout_layout_flexBasisPercent, 1, 1, -1.0f);
            this.f2872c0 = obtainStyledAttributes.getDimensionPixelSize(C0311bl.FlexboxLayout_Layout_layout_minWidth, -1);
            this.f2873d0 = obtainStyledAttributes.getDimensionPixelSize(C0311bl.FlexboxLayout_Layout_layout_minHeight, -1);
            this.f2874e0 = obtainStyledAttributes.getDimensionPixelSize(C0311bl.FlexboxLayout_Layout_layout_maxWidth, 16777215);
            this.f2875f0 = obtainStyledAttributes.getDimensionPixelSize(C0311bl.FlexboxLayout_Layout_layout_maxHeight, 16777215);
            this.f2876g0 = obtainStyledAttributes.getBoolean(C0311bl.FlexboxLayout_Layout_layout_wrapBefore, false);
            obtainStyledAttributes.recycle();
        }

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C0395a(Parcel parcel) {
            super(0, 0);
            boolean z = false;
            this.f2867X = parcel.readInt();
            this.f2868Y = parcel.readFloat();
            this.f2869Z = parcel.readFloat();
            this.f2870a0 = parcel.readInt();
            this.f2871b0 = parcel.readFloat();
            this.f2872c0 = parcel.readInt();
            this.f2873d0 = parcel.readInt();
            this.f2874e0 = parcel.readInt();
            this.f2875f0 = parcel.readInt();
            this.f2876g0 = parcel.readByte() != 0 ? true : z;
            this.bottomMargin = parcel.readInt();
            this.leftMargin = parcel.readInt();
            this.rightMargin = parcel.readInt();
            this.topMargin = parcel.readInt();
            this.height = parcel.readInt();
            this.width = parcel.readInt();
        }

        public C0395a(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public C0395a(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        public C0395a(C0395a aVar) {
            super(aVar);
            this.f2867X = aVar.f2867X;
            this.f2868Y = aVar.f2868Y;
            this.f2869Z = aVar.f2869Z;
            this.f2870a0 = aVar.f2870a0;
            this.f2871b0 = aVar.f2871b0;
            this.f2872c0 = aVar.f2872c0;
            this.f2873d0 = aVar.f2873d0;
            this.f2874e0 = aVar.f2874e0;
            this.f2875f0 = aVar.f2875f0;
            this.f2876g0 = aVar.f2876g0;
        }

        /* renamed from: a */
        public float mo3161a() {
            return this.f2868Y;
        }

        /* renamed from: a */
        public void mo3162a(int i) {
            this.f2873d0 = i;
        }

        /* renamed from: b */
        public float mo3163b() {
            return this.f2871b0;
        }

        /* renamed from: b */
        public void mo3164b(int i) {
            this.f2872c0 = i;
        }

        /* renamed from: c */
        public int mo3165c() {
            return this.f2870a0;
        }

        /* renamed from: d */
        public float mo3166d() {
            return this.f2869Z;
        }

        public int describeContents() {
            return 0;
        }

        /* renamed from: e */
        public int mo3168e() {
            return this.rightMargin;
        }

        /* renamed from: f */
        public int mo3169f() {
            return this.f2873d0;
        }

        /* renamed from: g */
        public int mo3170g() {
            return this.f2872c0;
        }

        public int getHeight() {
            return this.height;
        }

        public int getOrder() {
            return this.f2867X;
        }

        public int getWidth() {
            return this.width;
        }

        /* renamed from: h */
        public boolean mo3174h() {
            return this.f2876g0;
        }

        /* renamed from: i */
        public int mo3175i() {
            return this.f2875f0;
        }

        /* renamed from: j */
        public int mo3176j() {
            return this.bottomMargin;
        }

        /* renamed from: k */
        public int mo3177k() {
            return this.leftMargin;
        }

        /* renamed from: l */
        public int mo3178l() {
            return this.f2874e0;
        }

        /* renamed from: m */
        public int mo3179m() {
            return this.topMargin;
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeInt(this.f2867X);
            parcel.writeFloat(this.f2868Y);
            parcel.writeFloat(this.f2869Z);
            parcel.writeInt(this.f2870a0);
            parcel.writeFloat(this.f2871b0);
            parcel.writeInt(this.f2872c0);
            parcel.writeInt(this.f2873d0);
            parcel.writeInt(this.f2874e0);
            parcel.writeInt(this.f2875f0);
            parcel.writeByte(this.f2876g0 ? (byte) 1 : 0);
            parcel.writeInt(this.bottomMargin);
            parcel.writeInt(this.leftMargin);
            parcel.writeInt(this.rightMargin);
            parcel.writeInt(this.topMargin);
            parcel.writeInt(this.height);
            parcel.writeInt(this.width);
        }
    }

    public FlexboxLayout(Context context) {
        this(context, (AttributeSet) null);
    }

    public FlexboxLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public FlexboxLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f2855f0 = -1;
        this.f2864o0 = new C0111al(this);
        this.f2865p0 = new ArrayList();
        this.f2866q0 = new C0111al.C0113b();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0311bl.FlexboxLayout, i, 0);
        this.f2850a0 = obtainStyledAttributes.getInt(C0311bl.FlexboxLayout_flexDirection, 0);
        this.f2851b0 = obtainStyledAttributes.getInt(C0311bl.FlexboxLayout_flexWrap, 0);
        this.f2852c0 = obtainStyledAttributes.getInt(C0311bl.FlexboxLayout_justifyContent, 0);
        this.f2853d0 = obtainStyledAttributes.getInt(C0311bl.FlexboxLayout_alignItems, 0);
        this.f2854e0 = obtainStyledAttributes.getInt(C0311bl.FlexboxLayout_alignContent, 0);
        this.f2855f0 = obtainStyledAttributes.getInt(C0311bl.FlexboxLayout_maxLine, -1);
        Drawable drawable = obtainStyledAttributes.getDrawable(C0311bl.FlexboxLayout_dividerDrawable);
        if (drawable != null) {
            setDividerDrawableHorizontal(drawable);
            setDividerDrawableVertical(drawable);
        }
        Drawable drawable2 = obtainStyledAttributes.getDrawable(C0311bl.FlexboxLayout_dividerDrawableHorizontal);
        if (drawable2 != null) {
            setDividerDrawableHorizontal(drawable2);
        }
        Drawable drawable3 = obtainStyledAttributes.getDrawable(C0311bl.FlexboxLayout_dividerDrawableVertical);
        if (drawable3 != null) {
            setDividerDrawableVertical(drawable3);
        }
        int i2 = obtainStyledAttributes.getInt(C0311bl.FlexboxLayout_showDivider, 0);
        if (i2 != 0) {
            this.f2859j0 = i2;
            this.f2858i0 = i2;
        }
        int i3 = obtainStyledAttributes.getInt(C0311bl.FlexboxLayout_showDividerVertical, 0);
        if (i3 != 0) {
            this.f2859j0 = i3;
        }
        int i4 = obtainStyledAttributes.getInt(C0311bl.FlexboxLayout_showDividerHorizontal, 0);
        if (i4 != 0) {
            this.f2858i0 = i4;
        }
        obtainStyledAttributes.recycle();
    }

    /* renamed from: a */
    public int mo3105a(int i, int i2, int i3) {
        return ViewGroup.getChildMeasureSpec(i, i2, i3);
    }

    /* renamed from: a */
    public int mo3106a(View view) {
        return 0;
    }

    /* renamed from: a */
    public int mo3107a(View view, int i, int i2) {
        int i3;
        int i4 = 0;
        if (mo3117a()) {
            if (mo3118a(i, i2)) {
                i4 = 0 + this.f2861l0;
            }
            if ((this.f2859j0 & 4) <= 0) {
                return i4;
            }
            i3 = this.f2861l0;
        } else {
            if (mo3118a(i, i2)) {
                i4 = 0 + this.f2860k0;
            }
            if ((this.f2858i0 & 4) <= 0) {
                return i4;
            }
            i3 = this.f2860k0;
        }
        return i4 + i3;
    }

    /* renamed from: a */
    public View mo3108a(int i) {
        return getChildAt(i);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:16:0x0059, code lost:
        if (r1 < r4) goto L_0x006f;
     */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x007d  */
    /* JADX WARNING: Removed duplicated region for block: B:33:0x0098  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo3109a(int r9, int r10, int r11, int r12) {
        /*
            r8 = this;
            int r0 = android.view.View.MeasureSpec.getMode(r10)
            int r1 = android.view.View.MeasureSpec.getSize(r10)
            int r2 = android.view.View.MeasureSpec.getMode(r11)
            int r3 = android.view.View.MeasureSpec.getSize(r11)
            if (r9 == 0) goto L_0x003b
            r4 = 1
            if (r9 == r4) goto L_0x003b
            r4 = 2
            if (r9 == r4) goto L_0x0028
            r4 = 3
            if (r9 != r4) goto L_0x001c
            goto L_0x0028
        L_0x001c:
            java.lang.IllegalArgumentException r10 = new java.lang.IllegalArgumentException
            java.lang.String r11 = "Invalid flex direction: "
            java.lang.String r9 = p000.C0789gk.m5568b((java.lang.String) r11, (int) r9)
            r10.<init>(r9)
            throw r10
        L_0x0028:
            int r9 = r8.getLargestMainSize()
            int r4 = r8.getSumOfCrossSize()
            int r5 = r8.getPaddingLeft()
            int r5 = r5 + r4
            int r4 = r8.getPaddingRight()
            int r4 = r4 + r5
            goto L_0x004d
        L_0x003b:
            int r9 = r8.getSumOfCrossSize()
            int r4 = r8.getPaddingTop()
            int r4 = r4 + r9
            int r9 = r8.getPaddingBottom()
            int r9 = r9 + r4
            int r4 = r8.getLargestMainSize()
        L_0x004d:
            r5 = 16777216(0x1000000, float:2.3509887E-38)
            r6 = 1073741824(0x40000000, float:2.0)
            r7 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r0 == r7) goto L_0x006d
            if (r0 == 0) goto L_0x0068
            if (r0 != r6) goto L_0x005c
            if (r1 >= r4) goto L_0x0075
            goto L_0x006f
        L_0x005c:
            java.lang.IllegalStateException r9 = new java.lang.IllegalStateException
            java.lang.String r10 = "Unknown width mode is set: "
            java.lang.String r10 = p000.C0789gk.m5568b((java.lang.String) r10, (int) r0)
            r9.<init>(r10)
            throw r9
        L_0x0068:
            int r10 = android.view.View.resolveSizeAndState(r4, r10, r12)
            goto L_0x0079
        L_0x006d:
            if (r1 >= r4) goto L_0x0074
        L_0x006f:
            int r12 = android.view.View.combineMeasuredStates(r12, r5)
            goto L_0x0075
        L_0x0074:
            r1 = r4
        L_0x0075:
            int r10 = android.view.View.resolveSizeAndState(r1, r10, r12)
        L_0x0079:
            r0 = 256(0x100, float:3.59E-43)
            if (r2 == r7) goto L_0x0098
            if (r2 == 0) goto L_0x009f
            if (r2 != r6) goto L_0x008c
            if (r3 >= r9) goto L_0x0087
            int r12 = android.view.View.combineMeasuredStates(r12, r0)
        L_0x0087:
            int r9 = android.view.View.resolveSizeAndState(r3, r11, r12)
            goto L_0x00a3
        L_0x008c:
            java.lang.IllegalStateException r9 = new java.lang.IllegalStateException
            java.lang.String r10 = "Unknown height mode is set: "
            java.lang.String r10 = p000.C0789gk.m5568b((java.lang.String) r10, (int) r2)
            r9.<init>(r10)
            throw r9
        L_0x0098:
            if (r3 >= r9) goto L_0x009f
            int r12 = android.view.View.combineMeasuredStates(r12, r0)
            r9 = r3
        L_0x009f:
            int r9 = android.view.View.resolveSizeAndState(r9, r11, r12)
        L_0x00a3:
            r8.setMeasuredDimension(r10, r9)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.flexbox.FlexboxLayout.mo3109a(int, int, int, int):void");
    }

    /* renamed from: a */
    public void mo3110a(int i, View view) {
    }

    /* renamed from: a */
    public final void mo3111a(Canvas canvas, int i, int i2, int i3) {
        Drawable drawable = this.f2856g0;
        if (drawable != null) {
            drawable.setBounds(i, i2, i3 + i, this.f2860k0 + i2);
            this.f2856g0.draw(canvas);
        }
    }

    /* renamed from: a */
    public final void mo3112a(Canvas canvas, boolean z, boolean z2) {
        int paddingLeft = getPaddingLeft();
        int max = Math.max(0, (getWidth() - getPaddingRight()) - paddingLeft);
        int size = this.f2865p0.size();
        for (int i = 0; i < size; i++) {
            C2458zk zkVar = this.f2865p0.get(i);
            for (int i2 = 0; i2 < zkVar.f18438h; i2++) {
                int i3 = zkVar.f18445o + i2;
                View c = mo3124c(i3);
                if (!(c == null || c.getVisibility() == 8)) {
                    C0395a aVar = (C0395a) c.getLayoutParams();
                    if (mo3118a(i3, i2)) {
                        mo3122b(canvas, z ? c.getRight() + aVar.rightMargin : (c.getLeft() - aVar.leftMargin) - this.f2861l0, zkVar.f18432b, zkVar.f18437g);
                    }
                    if (i2 == zkVar.f18438h - 1 && (this.f2859j0 & 4) > 0) {
                        mo3122b(canvas, z ? (c.getLeft() - aVar.leftMargin) - this.f2861l0 : c.getRight() + aVar.rightMargin, zkVar.f18432b, zkVar.f18437g);
                    }
                }
            }
            if (mo3126d(i)) {
                mo3111a(canvas, paddingLeft, z2 ? zkVar.f18434d : zkVar.f18432b - this.f2860k0, max);
            }
            if (mo3127e(i) && (this.f2858i0 & 4) > 0) {
                mo3111a(canvas, paddingLeft, z2 ? zkVar.f18432b - this.f2860k0 : zkVar.f18434d, max);
            }
        }
    }

    /* renamed from: a */
    public void mo3113a(View view, int i, int i2, C2458zk zkVar) {
        int i3;
        int i4;
        if (mo3118a(i, i2)) {
            if (mo3117a()) {
                i4 = zkVar.f18435e;
                i3 = this.f2861l0;
            } else {
                i4 = zkVar.f18435e;
                i3 = this.f2860k0;
            }
            zkVar.f18435e = i4 + i3;
            zkVar.f18436f += i3;
        }
    }

    /* renamed from: a */
    public void mo3114a(C2458zk zkVar) {
        int i;
        int i2;
        if (mo3117a()) {
            if ((this.f2859j0 & 4) > 0) {
                i2 = zkVar.f18435e;
                i = this.f2861l0;
            } else {
                return;
            }
        } else if ((this.f2858i0 & 4) > 0) {
            i2 = zkVar.f18435e;
            i = this.f2860k0;
        } else {
            return;
        }
        zkVar.f18435e = i2 + i;
        zkVar.f18436f += i;
    }

    /* JADX WARNING: Removed duplicated region for block: B:40:0x00d7  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo3115a(boolean r26, int r27, int r28, int r29, int r30) {
        /*
            r25 = this;
            r0 = r25
            int r1 = r25.getPaddingLeft()
            int r2 = r25.getPaddingRight()
            int r3 = r30 - r28
            int r4 = r29 - r27
            int r5 = r25.getPaddingBottom()
            int r3 = r3 - r5
            int r5 = r25.getPaddingTop()
            java.util.List<zk> r6 = r0.f2865p0
            int r6 = r6.size()
            r7 = 0
        L_0x001e:
            if (r7 >= r6) goto L_0x01d6
            java.util.List<zk> r8 = r0.f2865p0
            java.lang.Object r8 = r8.get(r7)
            zk r8 = (p000.C2458zk) r8
            boolean r9 = r0.mo3126d(r7)
            if (r9 == 0) goto L_0x0032
            int r9 = r0.f2860k0
            int r3 = r3 - r9
            int r5 = r5 + r9
        L_0x0032:
            int r9 = r0.f2852c0
            r10 = 4
            r11 = 2
            r12 = 0
            r13 = 1
            if (r9 == 0) goto L_0x00c6
            if (r9 == r13) goto L_0x00be
            r14 = 1073741824(0x40000000, float:2.0)
            if (r9 == r11) goto L_0x00a8
            r11 = 3
            if (r9 == r11) goto L_0x0090
            if (r9 == r10) goto L_0x0076
            r10 = 5
            if (r9 != r10) goto L_0x0061
            int r9 = r8.mo13328a()
            if (r9 == 0) goto L_0x0058
            int r10 = r8.f18435e
            int r10 = r4 - r10
            float r10 = (float) r10
            int r9 = r9 + 1
            float r9 = (float) r9
            float r10 = r10 / r9
            goto L_0x0059
        L_0x0058:
            r10 = 0
        L_0x0059:
            float r9 = (float) r1
            float r9 = r9 + r10
            int r11 = r4 - r2
            float r11 = (float) r11
            float r11 = r11 - r10
            goto L_0x00cd
        L_0x0061:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.String r2 = "Invalid justifyContent is set: "
            java.lang.StringBuilder r2 = p000.C0789gk.m5562a((java.lang.String) r2)
            int r3 = r0.f2852c0
            r2.append(r3)
            java.lang.String r2 = r2.toString()
            r1.<init>(r2)
            throw r1
        L_0x0076:
            int r9 = r8.mo13328a()
            if (r9 == 0) goto L_0x0084
            int r10 = r8.f18435e
            int r10 = r4 - r10
            float r10 = (float) r10
            float r9 = (float) r9
            float r10 = r10 / r9
            goto L_0x0086
        L_0x0084:
            r9 = 0
            r10 = 0
        L_0x0086:
            float r9 = (float) r1
            float r11 = r10 / r14
            float r9 = r9 + r11
            int r13 = r4 - r2
            float r13 = (float) r13
            float r11 = r13 - r11
            goto L_0x00cd
        L_0x0090:
            float r9 = (float) r1
            int r10 = r8.mo13328a()
            if (r10 == r13) goto L_0x009b
            int r10 = r10 + -1
            float r10 = (float) r10
            goto L_0x009d
        L_0x009b:
            r10 = 1065353216(0x3f800000, float:1.0)
        L_0x009d:
            int r11 = r8.f18435e
            int r11 = r4 - r11
            float r11 = (float) r11
            float r10 = r11 / r10
            int r11 = r4 - r2
            float r11 = (float) r11
            goto L_0x00cd
        L_0x00a8:
            float r9 = (float) r1
            int r10 = r8.f18435e
            int r11 = r4 - r10
            float r11 = (float) r11
            float r11 = r11 / r14
            float r11 = r11 + r9
            int r9 = r4 - r2
            float r9 = (float) r9
            int r10 = r4 - r10
            float r10 = (float) r10
            float r10 = r10 / r14
            float r9 = r9 - r10
            r24 = r11
            r11 = r9
            r9 = r24
            goto L_0x00cc
        L_0x00be:
            int r9 = r8.f18435e
            int r10 = r4 - r9
            int r10 = r10 + r2
            float r10 = (float) r10
            int r9 = r9 - r1
            goto L_0x00c9
        L_0x00c6:
            float r10 = (float) r1
            int r9 = r4 - r2
        L_0x00c9:
            float r9 = (float) r9
            r11 = r9
            r9 = r10
        L_0x00cc:
            r10 = 0
        L_0x00cd:
            float r16 = java.lang.Math.max(r10, r12)
            r10 = 0
            r15 = 0
        L_0x00d3:
            int r10 = r8.f18438h
            if (r15 >= r10) goto L_0x01cc
            int r10 = r8.f18445o
            int r10 = r10 + r15
            android.view.View r17 = r0.mo3124c(r10)
            if (r17 == 0) goto L_0x01c4
            int r12 = r17.getVisibility()
            r13 = 8
            if (r12 != r13) goto L_0x00ea
            goto L_0x01c4
        L_0x00ea:
            android.view.ViewGroup$LayoutParams r12 = r17.getLayoutParams()
            r14 = r12
            com.google.android.flexbox.FlexboxLayout$a r14 = (com.google.android.flexbox.FlexboxLayout.C0395a) r14
            int r12 = r14.leftMargin
            float r12 = (float) r12
            float r9 = r9 + r12
            int r12 = r14.rightMargin
            float r12 = (float) r12
            float r11 = r11 - r12
            boolean r10 = r0.mo3118a((int) r10, (int) r15)
            if (r10 == 0) goto L_0x010b
            int r10 = r0.f2861l0
            float r12 = (float) r10
            float r9 = r9 + r12
            float r11 = r11 - r12
            r18 = r9
            r20 = r10
            r19 = r11
            goto L_0x0112
        L_0x010b:
            r10 = 0
            r18 = r9
            r19 = r11
            r20 = 0
        L_0x0112:
            int r9 = r8.f18438h
            int r9 = r9 + -1
            if (r15 != r9) goto L_0x0123
            int r9 = r0.f2859j0
            r9 = r9 & 4
            if (r9 <= 0) goto L_0x0123
            int r9 = r0.f2861l0
            r21 = r9
            goto L_0x0126
        L_0x0123:
            r9 = 0
            r21 = 0
        L_0x0126:
            int r9 = r0.f2851b0
            r10 = 2
            if (r9 != r10) goto L_0x015c
            al r9 = r0.f2864o0
            if (r26 == 0) goto L_0x0143
            int r10 = java.lang.Math.round(r19)
            int r11 = r17.getMeasuredWidth()
            int r10 = r10 - r11
            int r11 = r17.getMeasuredHeight()
            int r11 = r3 - r11
            int r12 = java.lang.Math.round(r19)
            goto L_0x0156
        L_0x0143:
            int r10 = java.lang.Math.round(r18)
            int r11 = r17.getMeasuredHeight()
            int r11 = r3 - r11
            int r12 = java.lang.Math.round(r18)
            int r13 = r17.getMeasuredWidth()
            int r12 = r12 + r13
        L_0x0156:
            r23 = r3
            r13 = r11
            r22 = r12
            goto L_0x0185
        L_0x015c:
            al r9 = r0.f2864o0
            if (r26 == 0) goto L_0x016e
            int r10 = java.lang.Math.round(r19)
            int r11 = r17.getMeasuredWidth()
            int r10 = r10 - r11
            int r11 = java.lang.Math.round(r19)
            goto L_0x017b
        L_0x016e:
            int r10 = java.lang.Math.round(r18)
            int r11 = java.lang.Math.round(r18)
            int r12 = r17.getMeasuredWidth()
            int r11 = r11 + r12
        L_0x017b:
            int r12 = r17.getMeasuredHeight()
            int r12 = r12 + r5
            r13 = r5
            r22 = r11
            r23 = r12
        L_0x0185:
            r12 = r10
            r10 = r17
            r11 = r8
            r0 = r14
            r14 = r22
            r22 = r15
            r15 = r23
            r9.mo582a((android.view.View) r10, (p000.C2458zk) r11, (int) r12, (int) r13, (int) r14, (int) r15)
            int r9 = r17.getMeasuredWidth()
            float r9 = (float) r9
            float r9 = r9 + r16
            int r10 = r0.rightMargin
            float r10 = (float) r10
            float r9 = r9 + r10
            float r15 = r9 + r18
            int r9 = r17.getMeasuredWidth()
            float r9 = (float) r9
            float r9 = r9 + r16
            int r0 = r0.leftMargin
            float r0 = (float) r0
            float r9 = r9 + r0
            float r19 = r19 - r9
            r12 = 0
            r14 = 0
            if (r26 == 0) goto L_0x01b6
            r13 = r20
            r11 = r21
            goto L_0x01ba
        L_0x01b6:
            r11 = r20
            r13 = r21
        L_0x01ba:
            r9 = r8
            r10 = r17
            r9.mo13329a(r10, r11, r12, r13, r14)
            r9 = r15
            r11 = r19
            goto L_0x01c6
        L_0x01c4:
            r22 = r15
        L_0x01c6:
            int r15 = r22 + 1
            r0 = r25
            goto L_0x00d3
        L_0x01cc:
            int r0 = r8.f18437g
            int r5 = r5 + r0
            int r3 = r3 - r0
            int r7 = r7 + 1
            r0 = r25
            goto L_0x001e
        L_0x01d6:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.flexbox.FlexboxLayout.mo3115a(boolean, int, int, int, int):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:40:0x00d7  */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo3116a(boolean r28, boolean r29, int r30, int r31, int r32, int r33) {
        /*
            r27 = this;
            r0 = r27
            int r1 = r27.getPaddingTop()
            int r2 = r27.getPaddingBottom()
            int r3 = r27.getPaddingRight()
            int r4 = r27.getPaddingLeft()
            int r5 = r32 - r30
            int r6 = r33 - r31
            int r5 = r5 - r3
            java.util.List<zk> r3 = r0.f2865p0
            int r3 = r3.size()
            r7 = 0
        L_0x001e:
            if (r7 >= r3) goto L_0x01e3
            java.util.List<zk> r8 = r0.f2865p0
            java.lang.Object r8 = r8.get(r7)
            zk r8 = (p000.C2458zk) r8
            boolean r9 = r0.mo3126d(r7)
            if (r9 == 0) goto L_0x0032
            int r9 = r0.f2861l0
            int r4 = r4 + r9
            int r5 = r5 - r9
        L_0x0032:
            int r9 = r0.f2852c0
            r10 = 4
            r11 = 0
            r12 = 1
            if (r9 == 0) goto L_0x00c6
            if (r9 == r12) goto L_0x00be
            r13 = 2
            r14 = 1073741824(0x40000000, float:2.0)
            if (r9 == r13) goto L_0x00a8
            r13 = 3
            if (r9 == r13) goto L_0x0090
            if (r9 == r10) goto L_0x0076
            r10 = 5
            if (r9 != r10) goto L_0x0061
            int r9 = r8.mo13328a()
            if (r9 == 0) goto L_0x0058
            int r10 = r8.f18435e
            int r10 = r6 - r10
            float r10 = (float) r10
            int r9 = r9 + 1
            float r9 = (float) r9
            float r10 = r10 / r9
            goto L_0x0059
        L_0x0058:
            r10 = 0
        L_0x0059:
            float r9 = (float) r1
            float r9 = r9 + r10
            int r12 = r6 - r2
            float r12 = (float) r12
            float r12 = r12 - r10
            goto L_0x00cd
        L_0x0061:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.String r2 = "Invalid justifyContent is set: "
            java.lang.StringBuilder r2 = p000.C0789gk.m5562a((java.lang.String) r2)
            int r3 = r0.f2852c0
            r2.append(r3)
            java.lang.String r2 = r2.toString()
            r1.<init>(r2)
            throw r1
        L_0x0076:
            int r9 = r8.mo13328a()
            if (r9 == 0) goto L_0x0084
            int r10 = r8.f18435e
            int r10 = r6 - r10
            float r10 = (float) r10
            float r9 = (float) r9
            float r10 = r10 / r9
            goto L_0x0086
        L_0x0084:
            r9 = 0
            r10 = 0
        L_0x0086:
            float r9 = (float) r1
            float r12 = r10 / r14
            float r9 = r9 + r12
            int r13 = r6 - r2
            float r13 = (float) r13
            float r12 = r13 - r12
            goto L_0x00cd
        L_0x0090:
            float r9 = (float) r1
            int r10 = r8.mo13328a()
            if (r10 == r12) goto L_0x009b
            int r10 = r10 + -1
            float r10 = (float) r10
            goto L_0x009d
        L_0x009b:
            r10 = 1065353216(0x3f800000, float:1.0)
        L_0x009d:
            int r12 = r8.f18435e
            int r12 = r6 - r12
            float r12 = (float) r12
            float r10 = r12 / r10
            int r12 = r6 - r2
            float r12 = (float) r12
            goto L_0x00cd
        L_0x00a8:
            float r9 = (float) r1
            int r10 = r8.f18435e
            int r12 = r6 - r10
            float r12 = (float) r12
            float r12 = r12 / r14
            float r12 = r12 + r9
            int r9 = r6 - r2
            float r9 = (float) r9
            int r10 = r6 - r10
            float r10 = (float) r10
            float r10 = r10 / r14
            float r9 = r9 - r10
            r26 = r12
            r12 = r9
            r9 = r26
            goto L_0x00cc
        L_0x00be:
            int r9 = r8.f18435e
            int r10 = r6 - r9
            int r10 = r10 + r2
            float r10 = (float) r10
            int r9 = r9 - r1
            goto L_0x00c9
        L_0x00c6:
            float r10 = (float) r1
            int r9 = r6 - r2
        L_0x00c9:
            float r9 = (float) r9
            r12 = r9
            r9 = r10
        L_0x00cc:
            r10 = 0
        L_0x00cd:
            float r17 = java.lang.Math.max(r10, r11)
            r10 = 0
            r15 = 0
        L_0x00d3:
            int r10 = r8.f18438h
            if (r15 >= r10) goto L_0x01d9
            int r10 = r8.f18445o
            int r10 = r10 + r15
            android.view.View r18 = r0.mo3124c(r10)
            if (r18 == 0) goto L_0x01d1
            int r11 = r18.getVisibility()
            r13 = 8
            if (r11 != r13) goto L_0x00ea
            goto L_0x01d1
        L_0x00ea:
            android.view.ViewGroup$LayoutParams r11 = r18.getLayoutParams()
            r14 = r11
            com.google.android.flexbox.FlexboxLayout$a r14 = (com.google.android.flexbox.FlexboxLayout.C0395a) r14
            int r11 = r14.topMargin
            float r11 = (float) r11
            float r9 = r9 + r11
            int r11 = r14.bottomMargin
            float r11 = (float) r11
            float r12 = r12 - r11
            boolean r10 = r0.mo3118a((int) r10, (int) r15)
            if (r10 == 0) goto L_0x010b
            int r10 = r0.f2860k0
            float r11 = (float) r10
            float r9 = r9 + r11
            float r12 = r12 - r11
            r19 = r9
            r21 = r10
            r20 = r12
            goto L_0x0112
        L_0x010b:
            r10 = 0
            r19 = r9
            r20 = r12
            r21 = 0
        L_0x0112:
            int r9 = r8.f18438h
            int r9 = r9 + -1
            if (r15 != r9) goto L_0x0123
            int r9 = r0.f2858i0
            r9 = r9 & 4
            if (r9 <= 0) goto L_0x0123
            int r9 = r0.f2860k0
            r22 = r9
            goto L_0x0126
        L_0x0123:
            r9 = 0
            r22 = 0
        L_0x0126:
            al r9 = r0.f2864o0
            if (r28 == 0) goto L_0x0160
            r10 = 1
            int r11 = r18.getMeasuredWidth()
            int r11 = r5 - r11
            if (r29 == 0) goto L_0x0149
            int r12 = java.lang.Math.round(r20)
            int r13 = r18.getMeasuredHeight()
            int r12 = r12 - r13
            int r13 = java.lang.Math.round(r20)
            r23 = r5
            r16 = r12
            r24 = r13
            r12 = 1
            r13 = r11
            goto L_0x0191
        L_0x0149:
            int r12 = java.lang.Math.round(r19)
            int r13 = java.lang.Math.round(r19)
            int r16 = r18.getMeasuredHeight()
            int r16 = r16 + r13
            r23 = r5
            r13 = r11
            r24 = r16
            r16 = r12
            r12 = 1
            goto L_0x0191
        L_0x0160:
            r10 = 0
            if (r29 == 0) goto L_0x0176
            int r11 = java.lang.Math.round(r20)
            int r12 = r18.getMeasuredHeight()
            int r11 = r11 - r12
            int r12 = r18.getMeasuredWidth()
            int r12 = r12 + r4
            int r13 = java.lang.Math.round(r20)
            goto L_0x0189
        L_0x0176:
            int r11 = java.lang.Math.round(r19)
            int r12 = r18.getMeasuredWidth()
            int r12 = r12 + r4
            int r13 = java.lang.Math.round(r19)
            int r16 = r18.getMeasuredHeight()
            int r13 = r16 + r13
        L_0x0189:
            r16 = r11
            r23 = r12
            r24 = r13
            r12 = 0
            r13 = r4
        L_0x0191:
            r10 = r18
            r11 = r8
            r0 = r14
            r14 = r16
            r25 = r15
            r15 = r23
            r16 = r24
            r9.mo583a((android.view.View) r10, (p000.C2458zk) r11, (boolean) r12, (int) r13, (int) r14, (int) r15, (int) r16)
            int r9 = r18.getMeasuredHeight()
            float r9 = (float) r9
            float r9 = r9 + r17
            int r10 = r0.bottomMargin
            float r10 = (float) r10
            float r9 = r9 + r10
            float r15 = r9 + r19
            int r9 = r18.getMeasuredHeight()
            float r9 = (float) r9
            float r9 = r9 + r17
            int r0 = r0.topMargin
            float r0 = (float) r0
            float r9 = r9 + r0
            float r20 = r20 - r9
            r11 = 0
            r13 = 0
            if (r29 == 0) goto L_0x01c3
            r14 = r21
            r12 = r22
            goto L_0x01c7
        L_0x01c3:
            r12 = r21
            r14 = r22
        L_0x01c7:
            r9 = r8
            r10 = r18
            r9.mo13329a(r10, r11, r12, r13, r14)
            r9 = r15
            r12 = r20
            goto L_0x01d3
        L_0x01d1:
            r25 = r15
        L_0x01d3:
            int r15 = r25 + 1
            r0 = r27
            goto L_0x00d3
        L_0x01d9:
            int r0 = r8.f18437g
            int r4 = r4 + r0
            int r5 = r5 - r0
            int r7 = r7 + 1
            r0 = r27
            goto L_0x001e
        L_0x01e3:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.flexbox.FlexboxLayout.mo3116a(boolean, boolean, int, int, int, int):void");
    }

    /* renamed from: a */
    public boolean mo3117a() {
        int i = this.f2850a0;
        return i == 0 || i == 1;
    }

    /* renamed from: a */
    public final boolean mo3118a(int i, int i2) {
        boolean z;
        int i3 = 1;
        while (true) {
            if (i3 > i2) {
                z = true;
                break;
            }
            View c = mo3124c(i - i3);
            if (c != null && c.getVisibility() != 8) {
                z = false;
                break;
            }
            i3++;
        }
        if (z) {
            if (mo3117a()) {
                if ((this.f2859j0 & 1) != 0) {
                    return true;
                }
                return false;
            } else if ((this.f2858i0 & 1) != 0) {
                return true;
            } else {
                return false;
            }
        } else if (mo3117a()) {
            if ((this.f2859j0 & 2) != 0) {
                return true;
            }
            return false;
        } else if ((this.f2858i0 & 2) != 0) {
            return true;
        } else {
            return false;
        }
    }

    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        if (this.f2863n0 == null) {
            this.f2863n0 = new SparseIntArray(getChildCount());
        }
        C0111al alVar = this.f2864o0;
        SparseIntArray sparseIntArray = this.f2863n0;
        int flexItemCount = alVar.f546a.getFlexItemCount();
        List<C0111al.C0114c> a = alVar.mo574a(flexItemCount);
        C0111al.C0114c cVar = new C0111al.C0114c((C0111al.C0112a) null);
        if (view == null || !(layoutParams instanceof C2367yk)) {
            cVar.f554Y = 1;
        } else {
            cVar.f554Y = ((C2367yk) layoutParams).getOrder();
        }
        if (i == -1 || i == flexItemCount || i >= alVar.f546a.getFlexItemCount()) {
            cVar.f553X = flexItemCount;
        } else {
            cVar.f553X = i;
            for (int i2 = i; i2 < flexItemCount; i2++) {
                a.get(i2).f553X++;
            }
        }
        a.add(cVar);
        this.f2862m0 = alVar.mo587a(flexItemCount + 1, a, sparseIntArray);
        super.addView(view, i, layoutParams);
    }

    /* renamed from: b */
    public int mo3120b(int i, int i2, int i3) {
        return ViewGroup.getChildMeasureSpec(i, i2, i3);
    }

    /* renamed from: b */
    public View mo3121b(int i) {
        return mo3124c(i);
    }

    /* renamed from: b */
    public final void mo3122b(Canvas canvas, int i, int i2, int i3) {
        Drawable drawable = this.f2857h0;
        if (drawable != null) {
            drawable.setBounds(i, i2, this.f2861l0 + i, i3 + i2);
            this.f2857h0.draw(canvas);
        }
    }

    /* renamed from: b */
    public final void mo3123b(Canvas canvas, boolean z, boolean z2) {
        int paddingTop = getPaddingTop();
        int max = Math.max(0, (getHeight() - getPaddingBottom()) - paddingTop);
        int size = this.f2865p0.size();
        for (int i = 0; i < size; i++) {
            C2458zk zkVar = this.f2865p0.get(i);
            for (int i2 = 0; i2 < zkVar.f18438h; i2++) {
                int i3 = zkVar.f18445o + i2;
                View c = mo3124c(i3);
                if (!(c == null || c.getVisibility() == 8)) {
                    C0395a aVar = (C0395a) c.getLayoutParams();
                    if (mo3118a(i3, i2)) {
                        mo3111a(canvas, zkVar.f18431a, z2 ? c.getBottom() + aVar.bottomMargin : (c.getTop() - aVar.topMargin) - this.f2860k0, zkVar.f18437g);
                    }
                    if (i2 == zkVar.f18438h - 1 && (this.f2858i0 & 4) > 0) {
                        mo3111a(canvas, zkVar.f18431a, z2 ? (c.getTop() - aVar.topMargin) - this.f2860k0 : c.getBottom() + aVar.bottomMargin, zkVar.f18437g);
                    }
                }
            }
            if (mo3126d(i)) {
                mo3122b(canvas, z ? zkVar.f18433c : zkVar.f18431a - this.f2861l0, paddingTop, max);
            }
            if (mo3127e(i) && (this.f2859j0 & 4) > 0) {
                mo3122b(canvas, z ? zkVar.f18431a - this.f2861l0 : zkVar.f18433c, paddingTop, max);
            }
        }
    }

    /* renamed from: c */
    public View mo3124c(int i) {
        if (i < 0) {
            return null;
        }
        int[] iArr = this.f2862m0;
        if (i >= iArr.length) {
            return null;
        }
        return getChildAt(iArr[i]);
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0395a;
    }

    /* renamed from: d */
    public final boolean mo3126d(int i) {
        boolean z;
        if (i < 0 || i >= this.f2865p0.size()) {
            return false;
        }
        int i2 = 0;
        while (true) {
            if (i2 >= i) {
                z = true;
                break;
            } else if (this.f2865p0.get(i2).mo13328a() > 0) {
                z = false;
                break;
            } else {
                i2++;
            }
        }
        if (z) {
            if (mo3117a()) {
                if ((this.f2858i0 & 1) != 0) {
                    return true;
                }
                return false;
            } else if ((this.f2859j0 & 1) != 0) {
                return true;
            } else {
                return false;
            }
        } else if (mo3117a()) {
            if ((this.f2858i0 & 2) != 0) {
                return true;
            }
            return false;
        } else if ((this.f2859j0 & 2) != 0) {
            return true;
        } else {
            return false;
        }
    }

    /* renamed from: e */
    public final boolean mo3127e(int i) {
        if (i < 0 || i >= this.f2865p0.size()) {
            return false;
        }
        for (int i2 = i + 1; i2 < this.f2865p0.size(); i2++) {
            if (this.f2865p0.get(i2).mo13328a() > 0) {
                return false;
            }
        }
        return mo3117a() ? (this.f2858i0 & 4) != 0 : (this.f2859j0 & 4) != 0;
    }

    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0395a ? new C0395a((C0395a) layoutParams) : layoutParams instanceof ViewGroup.MarginLayoutParams ? new C0395a((ViewGroup.MarginLayoutParams) layoutParams) : new C0395a(layoutParams);
    }

    public C0395a generateLayoutParams(AttributeSet attributeSet) {
        return new C0395a(getContext(), attributeSet);
    }

    public int getAlignContent() {
        return this.f2854e0;
    }

    public int getAlignItems() {
        return this.f2853d0;
    }

    public Drawable getDividerDrawableHorizontal() {
        return this.f2856g0;
    }

    public Drawable getDividerDrawableVertical() {
        return this.f2857h0;
    }

    public int getFlexDirection() {
        return this.f2850a0;
    }

    public int getFlexItemCount() {
        return getChildCount();
    }

    public List<C2458zk> getFlexLines() {
        ArrayList arrayList = new ArrayList(this.f2865p0.size());
        for (C2458zk next : this.f2865p0) {
            if (next.mo13328a() != 0) {
                arrayList.add(next);
            }
        }
        return arrayList;
    }

    public List<C2458zk> getFlexLinesInternal() {
        return this.f2865p0;
    }

    public int getFlexWrap() {
        return this.f2851b0;
    }

    public int getJustifyContent() {
        return this.f2852c0;
    }

    public int getLargestMainSize() {
        int i = RecyclerView.UNDEFINED_DURATION;
        for (C2458zk zkVar : this.f2865p0) {
            i = Math.max(i, zkVar.f18435e);
        }
        return i;
    }

    public int getMaxLine() {
        return this.f2855f0;
    }

    public int getShowDividerHorizontal() {
        return this.f2858i0;
    }

    public int getShowDividerVertical() {
        return this.f2859j0;
    }

    public int getSumOfCrossSize() {
        int size = this.f2865p0.size();
        int i = 0;
        for (int i2 = 0; i2 < size; i2++) {
            C2458zk zkVar = this.f2865p0.get(i2);
            if (mo3126d(i2)) {
                i += mo3117a() ? this.f2860k0 : this.f2861l0;
            }
            if (mo3127e(i2)) {
                i += mo3117a() ? this.f2860k0 : this.f2861l0;
            }
            i += zkVar.f18437g;
        }
        return i;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:32:0x0047, code lost:
        if (r6.f2851b0 == 2) goto L_0x0053;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:37:0x0051, code lost:
        if (r6.f2851b0 == 2) goto L_0x0053;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onDraw(android.graphics.Canvas r7) {
        /*
            r6 = this;
            android.graphics.drawable.Drawable r0 = r6.f2857h0
            if (r0 != 0) goto L_0x0009
            android.graphics.drawable.Drawable r0 = r6.f2856g0
            if (r0 != 0) goto L_0x0009
            return
        L_0x0009:
            int r0 = r6.f2858i0
            if (r0 != 0) goto L_0x0012
            int r0 = r6.f2859j0
            if (r0 != 0) goto L_0x0012
            return
        L_0x0012:
            int r0 = p000.C2189w7.m15018m(r6)
            int r1 = r6.f2850a0
            r2 = 2
            r3 = 0
            r4 = 1
            if (r1 == 0) goto L_0x004a
            if (r1 == r4) goto L_0x0040
            if (r1 == r2) goto L_0x0032
            r5 = 3
            if (r1 == r5) goto L_0x0025
            goto L_0x0057
        L_0x0025:
            if (r0 != r4) goto L_0x0028
            r3 = 1
        L_0x0028:
            int r0 = r6.f2851b0
            if (r0 != r2) goto L_0x002e
            r3 = r3 ^ 1
        L_0x002e:
            r6.mo3123b((android.graphics.Canvas) r7, (boolean) r3, (boolean) r4)
            goto L_0x0057
        L_0x0032:
            if (r0 != r4) goto L_0x0035
            goto L_0x0036
        L_0x0035:
            r4 = 0
        L_0x0036:
            int r0 = r6.f2851b0
            if (r0 != r2) goto L_0x003c
            r4 = r4 ^ 1
        L_0x003c:
            r6.mo3123b((android.graphics.Canvas) r7, (boolean) r4, (boolean) r3)
            goto L_0x0057
        L_0x0040:
            if (r0 == r4) goto L_0x0044
            r0 = 1
            goto L_0x0045
        L_0x0044:
            r0 = 0
        L_0x0045:
            int r1 = r6.f2851b0
            if (r1 != r2) goto L_0x0054
            goto L_0x0053
        L_0x004a:
            if (r0 != r4) goto L_0x004e
            r0 = 1
            goto L_0x004f
        L_0x004e:
            r0 = 0
        L_0x004f:
            int r1 = r6.f2851b0
            if (r1 != r2) goto L_0x0054
        L_0x0053:
            r3 = 1
        L_0x0054:
            r6.mo3112a((android.graphics.Canvas) r7, (boolean) r0, (boolean) r3)
        L_0x0057:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.flexbox.FlexboxLayout.onDraw(android.graphics.Canvas):void");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:22:0x004a, code lost:
        if (r10 != 1) goto L_0x004f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x004d, code lost:
        if (r10 == 1) goto L_0x004f;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:25:0x0052, code lost:
        r1 = false;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onLayout(boolean r10, int r11, int r12, int r13, int r14) {
        /*
            r9 = this;
            int r10 = p000.C2189w7.m15018m(r9)
            int r0 = r9.f2850a0
            r1 = 0
            r2 = 1
            if (r0 == 0) goto L_0x004d
            if (r0 == r2) goto L_0x004a
            r3 = 2
            if (r0 == r3) goto L_0x0034
            r4 = 3
            if (r0 != r4) goto L_0x001f
            if (r10 != r2) goto L_0x0015
            r1 = 1
        L_0x0015:
            int r10 = r9.f2851b0
            if (r10 != r3) goto L_0x001b
            r1 = r1 ^ 1
        L_0x001b:
            r10 = 1
            r3 = r1
            r4 = 1
            goto L_0x0041
        L_0x001f:
            java.lang.IllegalStateException r10 = new java.lang.IllegalStateException
            java.lang.String r11 = "Invalid flex direction is set: "
            java.lang.StringBuilder r11 = p000.C0789gk.m5562a((java.lang.String) r11)
            int r12 = r9.f2850a0
            r11.append(r12)
            java.lang.String r11 = r11.toString()
            r10.<init>(r11)
            throw r10
        L_0x0034:
            if (r10 != r2) goto L_0x0037
            r1 = 1
        L_0x0037:
            int r10 = r9.f2851b0
            if (r10 != r3) goto L_0x003e
            r10 = r1 ^ 1
            r1 = r10
        L_0x003e:
            r10 = 0
            r3 = r1
            r4 = 0
        L_0x0041:
            r2 = r9
            r5 = r11
            r6 = r12
            r7 = r13
            r8 = r14
            r2.mo3116a(r3, r4, r5, r6, r7, r8)
            goto L_0x005c
        L_0x004a:
            if (r10 == r2) goto L_0x0052
            goto L_0x004f
        L_0x004d:
            if (r10 != r2) goto L_0x0052
        L_0x004f:
            r10 = 1
            r1 = 1
            goto L_0x0054
        L_0x0052:
            r10 = 0
            r1 = 0
        L_0x0054:
            r0 = r9
            r2 = r11
            r3 = r12
            r4 = r13
            r5 = r14
            r0.mo3115a(r1, r2, r3, r4, r5)
        L_0x005c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.flexbox.FlexboxLayout.onLayout(boolean, int, int, int, int):void");
    }

    /* JADX WARNING: Removed duplicated region for block: B:15:0x004a  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x00ec  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r15, int r16) {
        /*
            r14 = this;
            r0 = r14
            r9 = r15
            r10 = r16
            android.util.SparseIntArray r1 = r0.f2863n0
            if (r1 != 0) goto L_0x0013
            android.util.SparseIntArray r1 = new android.util.SparseIntArray
            int r2 = r14.getChildCount()
            r1.<init>(r2)
            r0.f2863n0 = r1
        L_0x0013:
            al r1 = r0.f2864o0
            android.util.SparseIntArray r2 = r0.f2863n0
            xk r3 = r1.f546a
            int r3 = r3.getFlexItemCount()
            int r4 = r2.size()
            r5 = 1
            r11 = 0
            if (r4 == r3) goto L_0x0026
            goto L_0x0042
        L_0x0026:
            r4 = 0
        L_0x0027:
            if (r4 >= r3) goto L_0x0047
            xk r6 = r1.f546a
            android.view.View r6 = r6.mo3108a((int) r4)
            if (r6 != 0) goto L_0x0032
            goto L_0x0044
        L_0x0032:
            android.view.ViewGroup$LayoutParams r6 = r6.getLayoutParams()
            yk r6 = (p000.C2367yk) r6
            int r6 = r6.getOrder()
            int r7 = r2.get(r4)
            if (r6 == r7) goto L_0x0044
        L_0x0042:
            r1 = 1
            goto L_0x0048
        L_0x0044:
            int r4 = r4 + 1
            goto L_0x0027
        L_0x0047:
            r1 = 0
        L_0x0048:
            if (r1 == 0) goto L_0x005e
            al r1 = r0.f2864o0
            android.util.SparseIntArray r2 = r0.f2863n0
            xk r3 = r1.f546a
            int r3 = r3.getFlexItemCount()
            java.util.List r4 = r1.mo574a((int) r3)
            int[] r1 = r1.mo587a((int) r3, (java.util.List<p000.C0111al.C0114c>) r4, (android.util.SparseIntArray) r2)
            r0.f2862m0 = r1
        L_0x005e:
            int r1 = r0.f2850a0
            r12 = 3
            r13 = 2
            if (r1 == 0) goto L_0x00c3
            if (r1 == r5) goto L_0x00c3
            if (r1 == r13) goto L_0x0080
            if (r1 != r12) goto L_0x006b
            goto L_0x0080
        L_0x006b:
            java.lang.IllegalStateException r1 = new java.lang.IllegalStateException
            java.lang.String r2 = "Invalid value for the flex direction is set: "
            java.lang.StringBuilder r2 = p000.C0789gk.m5562a((java.lang.String) r2)
            int r3 = r0.f2850a0
            r2.append(r3)
            java.lang.String r2 = r2.toString()
            r1.<init>(r2)
            throw r1
        L_0x0080:
            java.util.List<zk> r1 = r0.f2865p0
            r1.clear()
            al$b r1 = r0.f2866q0
            r1.mo600a()
            al r1 = r0.f2864o0
            al$b r2 = r0.f2866q0
            r5 = 2147483647(0x7fffffff, float:NaN)
            r6 = 0
            r7 = -1
            r8 = 0
            r3 = r16
            r4 = r15
            r1.mo579a((p000.C0111al.C0113b) r2, (int) r3, (int) r4, (int) r5, (int) r6, (int) r7, (java.util.List<p000.C2458zk>) r8)
            al$b r1 = r0.f2866q0
            java.util.List<zk> r1 = r1.f551a
            r0.f2865p0 = r1
            al r1 = r0.f2864o0
            r1.mo592b((int) r15, (int) r10, (int) r11)
            al r1 = r0.f2864o0
            int r2 = r14.getPaddingLeft()
            int r3 = r14.getPaddingRight()
            int r3 = r3 + r2
            r1.mo576a((int) r15, (int) r10, (int) r3)
            al r1 = r0.f2864o0
            r1.mo599e(r11)
            int r1 = r0.f2850a0
            al$b r2 = r0.f2866q0
            int r2 = r2.f552b
            r14.mo3109a((int) r1, (int) r15, (int) r10, (int) r2)
            goto L_0x0177
        L_0x00c3:
            java.util.List<zk> r1 = r0.f2865p0
            r1.clear()
            al$b r1 = r0.f2866q0
            r1.mo600a()
            al r1 = r0.f2864o0
            al$b r2 = r0.f2866q0
            r5 = 2147483647(0x7fffffff, float:NaN)
            r6 = 0
            r7 = -1
            r8 = 0
            r3 = r15
            r4 = r16
            r1.mo579a((p000.C0111al.C0113b) r2, (int) r3, (int) r4, (int) r5, (int) r6, (int) r7, (java.util.List<p000.C2458zk>) r8)
            al$b r1 = r0.f2866q0
            java.util.List<zk> r1 = r1.f551a
            r0.f2865p0 = r1
            al r1 = r0.f2864o0
            r1.mo592b((int) r15, (int) r10, (int) r11)
            int r1 = r0.f2853d0
            if (r1 != r12) goto L_0x015b
            java.util.List<zk> r1 = r0.f2865p0
            java.util.Iterator r1 = r1.iterator()
        L_0x00f2:
            boolean r2 = r1.hasNext()
            if (r2 == 0) goto L_0x015b
            java.lang.Object r2 = r1.next()
            zk r2 = (p000.C2458zk) r2
            r3 = 0
            r4 = -2147483648(0xffffffff80000000, float:-0.0)
        L_0x0101:
            int r5 = r2.f18438h
            if (r3 >= r5) goto L_0x0158
            int r5 = r2.f18445o
            int r5 = r5 + r3
            android.view.View r5 = r14.mo3124c(r5)
            if (r5 == 0) goto L_0x0155
            int r6 = r5.getVisibility()
            r7 = 8
            if (r6 != r7) goto L_0x0117
            goto L_0x0155
        L_0x0117:
            android.view.ViewGroup$LayoutParams r6 = r5.getLayoutParams()
            com.google.android.flexbox.FlexboxLayout$a r6 = (com.google.android.flexbox.FlexboxLayout.C0395a) r6
            int r7 = r0.f2851b0
            if (r7 == r13) goto L_0x0137
            int r7 = r2.f18442l
            int r8 = r5.getBaseline()
            int r7 = r7 - r8
            int r8 = r6.topMargin
            int r7 = java.lang.Math.max(r7, r8)
            int r5 = r5.getMeasuredHeight()
            int r5 = r5 + r7
            int r6 = r6.bottomMargin
            int r5 = r5 + r6
            goto L_0x0151
        L_0x0137:
            int r7 = r2.f18442l
            int r8 = r5.getMeasuredHeight()
            int r7 = r7 - r8
            int r8 = r5.getBaseline()
            int r8 = r8 + r7
            int r7 = r6.bottomMargin
            int r7 = java.lang.Math.max(r8, r7)
            int r5 = r5.getMeasuredHeight()
            int r6 = r6.topMargin
            int r5 = r5 + r6
            int r5 = r5 + r7
        L_0x0151:
            int r4 = java.lang.Math.max(r4, r5)
        L_0x0155:
            int r3 = r3 + 1
            goto L_0x0101
        L_0x0158:
            r2.f18437g = r4
            goto L_0x00f2
        L_0x015b:
            al r1 = r0.f2864o0
            int r2 = r14.getPaddingTop()
            int r3 = r14.getPaddingBottom()
            int r3 = r3 + r2
            r1.mo576a((int) r15, (int) r10, (int) r3)
            al r1 = r0.f2864o0
            r1.mo599e(r11)
            int r1 = r0.f2850a0
            al$b r2 = r0.f2866q0
            int r2 = r2.f552b
            r14.mo3109a((int) r1, (int) r15, (int) r10, (int) r2)
        L_0x0177:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.flexbox.FlexboxLayout.onMeasure(int, int):void");
    }

    public void setAlignContent(int i) {
        if (this.f2854e0 != i) {
            this.f2854e0 = i;
            requestLayout();
        }
    }

    public void setAlignItems(int i) {
        if (this.f2853d0 != i) {
            this.f2853d0 = i;
            requestLayout();
        }
    }

    public void setDividerDrawable(Drawable drawable) {
        setDividerDrawableHorizontal(drawable);
        setDividerDrawableVertical(drawable);
    }

    public void setDividerDrawableHorizontal(Drawable drawable) {
        if (drawable != this.f2856g0) {
            this.f2856g0 = drawable;
            boolean z = false;
            this.f2860k0 = drawable != null ? drawable.getIntrinsicHeight() : 0;
            if (this.f2856g0 == null && this.f2857h0 == null) {
                z = true;
            }
            setWillNotDraw(z);
            requestLayout();
        }
    }

    public void setDividerDrawableVertical(Drawable drawable) {
        if (drawable != this.f2857h0) {
            this.f2857h0 = drawable;
            boolean z = false;
            this.f2861l0 = drawable != null ? drawable.getIntrinsicWidth() : 0;
            if (this.f2856g0 == null && this.f2857h0 == null) {
                z = true;
            }
            setWillNotDraw(z);
            requestLayout();
        }
    }

    public void setFlexDirection(int i) {
        if (this.f2850a0 != i) {
            this.f2850a0 = i;
            requestLayout();
        }
    }

    public void setFlexLines(List<C2458zk> list) {
        this.f2865p0 = list;
    }

    public void setFlexWrap(int i) {
        if (this.f2851b0 != i) {
            this.f2851b0 = i;
            requestLayout();
        }
    }

    public void setJustifyContent(int i) {
        if (this.f2852c0 != i) {
            this.f2852c0 = i;
            requestLayout();
        }
    }

    public void setMaxLine(int i) {
        if (this.f2855f0 != i) {
            this.f2855f0 = i;
            requestLayout();
        }
    }

    public void setShowDivider(int i) {
        setShowDividerVertical(i);
        setShowDividerHorizontal(i);
    }

    public void setShowDividerHorizontal(int i) {
        if (i != this.f2858i0) {
            this.f2858i0 = i;
            requestLayout();
        }
    }

    public void setShowDividerVertical(int i) {
        if (i != this.f2859j0) {
            this.f2859j0 = i;
            requestLayout();
        }
    }
}
