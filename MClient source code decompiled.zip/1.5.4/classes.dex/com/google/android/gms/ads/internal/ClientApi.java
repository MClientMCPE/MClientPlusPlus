package com.google.android.gms.ads.internal;

import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.widget.FrameLayout;
import com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel;
import java.util.HashMap;

public class ClientApi extends jx2 {
    /* renamed from: a */
    public final C1647pv mo3243a(C2232wr wrVar, C2232wr wrVar2) {
        return new t31((FrameLayout) C2298xr.m15922z(wrVar), (FrameLayout) C2298xr.m15922z(wrVar2), 19649000);
    }

    /* renamed from: a */
    public final rw2 mo3244a(C2232wr wrVar, String str, r30 r30, int i) {
        Context context = (Context) C2298xr.m15922z(wrVar);
        return new zk1(hm0.m6396a(context, r30, i), context, str);
    }

    /* renamed from: a */
    public final y80 mo3245a(C2232wr wrVar, r30 r30, int i) {
        Context context = (Context) C2298xr.m15922z(wrVar);
        un0 i2 = hm0.m6396a(context, r30, i).mo631i();
        if (context != null) {
            i2.f15659a = context;
            C0680fe.m4755a(i2.f15659a, Context.class);
            return new tn0(i2.f15661c, i2.f15659a, i2.f15660b, (zm0) null).f15094f.get();
        }
        throw new NullPointerException();
    }

    /* renamed from: a */
    public final yw2 mo3247a(C2232wr wrVar, tv2 tv2, String str, r30 r30, int i) {
        Context context = (Context) C2298xr.m15922z(wrVar);
        return new el1(hm0.m6396a(context, r30, i), context, tv2, str);
    }

    /* renamed from: b */
    public final r90 mo3248b(C2232wr wrVar, String str, r30 r30, int i) {
        Context context = (Context) C2298xr.m15922z(wrVar);
        un0 i2 = hm0.m6396a(context, r30, i).mo631i();
        if (context != null) {
            i2.f15659a = context;
            i2.f15660b = str;
            C0680fe.m4755a(i2.f15659a, Context.class);
            return new tn0(i2.f15661c, i2.f15659a, i2.f15660b, (zm0) null).f15096h.get();
        }
        throw new NullPointerException();
    }

    /* renamed from: b */
    public final C1778rv mo3249b(C2232wr wrVar, C2232wr wrVar2, C2232wr wrVar3) {
        return new u31((View) C2298xr.m15922z(wrVar), (HashMap) C2298xr.m15922z(wrVar2), (HashMap) C2298xr.m15922z(wrVar3));
    }

    /* renamed from: b */
    public final yw2 mo3250b(C2232wr wrVar, tv2 tv2, String str, r30 r30, int i) {
        Context context = (Context) C2298xr.m15922z(wrVar);
        return new bl1(hm0.m6396a(context, r30, i), context, tv2, str);
    }

    /* renamed from: c */
    public final nx2 mo3251c(C2232wr wrVar, int i) {
        return ((an0) hm0.m6395a((Context) C2298xr.m15922z(wrVar), i)).f609u.get();
    }

    /* renamed from: d */
    public final q60 mo3253d(C2232wr wrVar) {
        Activity activity = (Activity) C2298xr.m15922z(wrVar);
        AdOverlayInfoParcel a = AdOverlayInfoParcel.m2827a(activity.getIntent());
        if (a == null) {
            return new C0713fn(activity);
        }
        int i = a.f2945h0;
        return i != 1 ? i != 2 ? i != 3 ? i != 4 ? new C0713fn(activity) : new C0950in(activity, a) : new C1469nn(activity) : new C1263ln(activity) : new C0793gn(activity);
    }

    /* renamed from: n */
    public final a70 mo3254n(C2232wr wrVar) {
        return null;
    }

    /* renamed from: u */
    public final nx2 mo3255u(C2232wr wrVar) {
        return null;
    }

    /* renamed from: c */
    public final yw2 mo3252c(C2232wr wrVar, tv2 tv2, String str, r30 r30, int i) {
        Context context = (Context) C2298xr.m15922z(wrVar);
        ln0 e = hm0.m6396a(context, r30, i).mo627e();
        if (str != null) {
            e.f9731b = str;
            if (context != null) {
                e.f9730a = context;
                C0680fe.m4755a(e.f9730a, Context.class);
                C0680fe.m4755a(e.f9731b, String.class);
                return new kn0(e.f9732c, e.f9730a, e.f9731b, (zm0) null).f9180f.get();
            }
            throw new NullPointerException();
        }
        throw new NullPointerException();
    }

    /* renamed from: a */
    public final yw2 mo3246a(C2232wr wrVar, tv2 tv2, String str, int i) {
        return new C2462zn((Context) C2298xr.m15922z(wrVar), tv2, str, new nf0(19649000, i, true, false, false));
    }
}
