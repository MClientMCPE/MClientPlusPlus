package com.google.android.gms.ads.mediation;

import android.content.Context;
import android.os.Bundle;

public interface MediationInterstitialAdapter extends C1171ko {
    void requestInterstitialAd(Context context, C1711qo qoVar, Bundle bundle, C1089jo joVar, Bundle bundle2);

    void showInterstitial();
}
