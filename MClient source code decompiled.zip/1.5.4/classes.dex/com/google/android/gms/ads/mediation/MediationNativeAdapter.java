package com.google.android.gms.ads.mediation;

import android.content.Context;
import android.os.Bundle;

public interface MediationNativeAdapter extends C1171ko {
    void requestNativeAd(Context context, C1872so soVar, Bundle bundle, C2295xo xoVar, Bundle bundle2);
}
