package com.google.android.gms.ads;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.os.RemoteException;
import android.view.View;
import android.view.ViewGroup;

public final class AdActivity extends Activity {

    /* renamed from: X */
    public q60 f2933X;

    /* renamed from: a */
    public final void mo3221a() {
        q60 q60 = this.f2933X;
        if (q60 != null) {
            try {
                q60.mo7074R0();
            } catch (RemoteException e) {
                C0680fe.m4859e("#007 Could not call remote method.", (Throwable) e);
            }
        }
    }

    public final void onActivityResult(int i, int i2, Intent intent) {
        try {
            this.f2933X.mo7076a(i, i2, intent);
        } catch (Exception e) {
            C0680fe.m4859e("#007 Could not call remote method.", (Throwable) e);
        }
        super.onActivityResult(i, i2, intent);
    }

    public final void onBackPressed() {
        boolean z = true;
        try {
            if (this.f2933X != null) {
                z = this.f2933X.mo7078e1();
            }
        } catch (RemoteException e) {
            C0680fe.m4859e("#007 Could not call remote method.", (Throwable) e);
        }
        if (z) {
            super.onBackPressed();
        }
    }

    public final void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        try {
            this.f2933X.mo7080m(new C2298xr(configuration));
        } catch (RemoteException e) {
            C0680fe.m4859e("#007 Could not call remote method.", (Throwable) e);
        }
    }

    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f2933X = kw2.f9317j.f9319b.mo13372a(this);
        q60 q60 = this.f2933X;
        if (q60 == null) {
            e = null;
        } else {
            try {
                q60.mo5746c(bundle);
                return;
            } catch (RemoteException e) {
                e = e;
            }
        }
        C0680fe.m4859e("#007 Could not call remote method.", (Throwable) e);
        finish();
    }

    public final void onDestroy() {
        try {
            if (this.f2933X != null) {
                this.f2933X.onDestroy();
            }
        } catch (RemoteException e) {
            C0680fe.m4859e("#007 Could not call remote method.", (Throwable) e);
        }
        super.onDestroy();
    }

    public final void onPause() {
        try {
            if (this.f2933X != null) {
                this.f2933X.onPause();
            }
        } catch (RemoteException e) {
            C0680fe.m4859e("#007 Could not call remote method.", (Throwable) e);
            finish();
        }
        super.onPause();
    }

    public final void onRestart() {
        super.onRestart();
        try {
            if (this.f2933X != null) {
                this.f2933X.mo7073I0();
            }
        } catch (RemoteException e) {
            C0680fe.m4859e("#007 Could not call remote method.", (Throwable) e);
            finish();
        }
    }

    public final void onResume() {
        super.onResume();
        try {
            if (this.f2933X != null) {
                this.f2933X.onResume();
            }
        } catch (RemoteException e) {
            C0680fe.m4859e("#007 Could not call remote method.", (Throwable) e);
            finish();
        }
    }

    public final void onSaveInstanceState(Bundle bundle) {
        try {
            if (this.f2933X != null) {
                this.f2933X.mo7077b(bundle);
            }
        } catch (RemoteException e) {
            C0680fe.m4859e("#007 Could not call remote method.", (Throwable) e);
            finish();
        }
        super.onSaveInstanceState(bundle);
    }

    public final void onStart() {
        super.onStart();
        try {
            if (this.f2933X != null) {
                this.f2933X.mo7079h1();
            }
        } catch (RemoteException e) {
            C0680fe.m4859e("#007 Could not call remote method.", (Throwable) e);
            finish();
        }
    }

    public final void onStop() {
        try {
            if (this.f2933X != null) {
                this.f2933X.mo7085x0();
            }
        } catch (RemoteException e) {
            C0680fe.m4859e("#007 Could not call remote method.", (Throwable) e);
            finish();
        }
        super.onStop();
    }

    public final void setContentView(int i) {
        super.setContentView(i);
        mo3221a();
    }

    public final void setContentView(View view) {
        super.setContentView(view);
        mo3221a();
    }

    public final void setContentView(View view, ViewGroup.LayoutParams layoutParams) {
        super.setContentView(view, layoutParams);
        mo3221a();
    }
}
