package com.google.android.gms.ads.mediation.rtb;

public abstract class RtbAdapter extends C0714fo {
    public abstract void collectSignals(C0962ip ipVar, C1090jp jpVar);
}
