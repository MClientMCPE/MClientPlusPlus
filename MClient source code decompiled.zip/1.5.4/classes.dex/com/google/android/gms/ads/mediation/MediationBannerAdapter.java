package com.google.android.gms.ads.mediation;

import android.content.Context;
import android.os.Bundle;
import android.view.View;

public interface MediationBannerAdapter extends C1171ko {
    View getBannerView();

    void requestBannerAd(Context context, C1347mo moVar, Bundle bundle, C0790gl glVar, C1089jo joVar, Bundle bundle2);
}
