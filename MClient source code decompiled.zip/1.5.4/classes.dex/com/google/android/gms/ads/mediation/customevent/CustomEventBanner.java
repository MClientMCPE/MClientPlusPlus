package com.google.android.gms.ads.mediation.customevent;

import android.content.Context;
import android.os.Bundle;

public interface CustomEventBanner extends C0490cp {
    void requestBannerAd(Context context, C0552dp dpVar, String str, C0790gl glVar, C1089jo joVar, Bundle bundle);
}
