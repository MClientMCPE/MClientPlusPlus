package com.google.android.gms.ads.mediation.customevent;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import com.google.android.gms.ads.mediation.MediationBannerAdapter;
import com.google.android.gms.ads.mediation.MediationInterstitialAdapter;
import com.google.android.gms.ads.mediation.MediationNativeAdapter;
import com.google.android.gms.ads.reward.mediation.MediationRewardedVideoAdAdapter;
import com.google.android.gms.common.annotation.KeepName;

@KeepName
public final class CustomEventAdapter implements MediationBannerAdapter, MediationInterstitialAdapter, MediationNativeAdapter {

    /* renamed from: a */
    public View f2951a;

    /* renamed from: b */
    public CustomEventBanner f2952b;

    /* renamed from: c */
    public CustomEventInterstitial f2953c;

    /* renamed from: d */
    public CustomEventNative f2954d;

    /* renamed from: com.google.android.gms.ads.mediation.customevent.CustomEventAdapter$a */
    public static final class C0404a implements C0552dp {
        public C0404a(CustomEventAdapter customEventAdapter, C1347mo moVar) {
        }
    }

    /* renamed from: com.google.android.gms.ads.mediation.customevent.CustomEventAdapter$b */
    public static class C0405b implements C0875hp {
        public C0405b(CustomEventAdapter customEventAdapter, C1872so soVar) {
        }
    }

    /* renamed from: com.google.android.gms.ads.mediation.customevent.CustomEventAdapter$c */
    public class C0406c implements C0715fp {
        public C0406c(CustomEventAdapter customEventAdapter, CustomEventAdapter customEventAdapter2, C1711qo qoVar) {
        }
    }

    /* renamed from: a */
    public static <T> T m2828a(String str) {
        try {
            return Class.forName(str).newInstance();
        } catch (Throwable th) {
            String message = th.getMessage();
            StringBuilder sb = new StringBuilder(C0789gk.m5548a(message, C0789gk.m5548a(str, 46)));
            sb.append("Could not instantiate custom event adapter: ");
            sb.append(str);
            sb.append(". ");
            sb.append(message);
            C0680fe.m4893p(sb.toString());
            return null;
        }
    }

    public final View getBannerView() {
        return this.f2951a;
    }

    public final void onDestroy() {
        CustomEventBanner customEventBanner = this.f2952b;
        if (customEventBanner != null) {
            customEventBanner.onDestroy();
        }
        CustomEventInterstitial customEventInterstitial = this.f2953c;
        if (customEventInterstitial != null) {
            customEventInterstitial.onDestroy();
        }
        CustomEventNative customEventNative = this.f2954d;
        if (customEventNative != null) {
            customEventNative.onDestroy();
        }
    }

    public final void onPause() {
        CustomEventBanner customEventBanner = this.f2952b;
        if (customEventBanner != null) {
            customEventBanner.onPause();
        }
        CustomEventInterstitial customEventInterstitial = this.f2953c;
        if (customEventInterstitial != null) {
            customEventInterstitial.onPause();
        }
        CustomEventNative customEventNative = this.f2954d;
        if (customEventNative != null) {
            customEventNative.onPause();
        }
    }

    public final void onResume() {
        CustomEventBanner customEventBanner = this.f2952b;
        if (customEventBanner != null) {
            customEventBanner.onResume();
        }
        CustomEventInterstitial customEventInterstitial = this.f2953c;
        if (customEventInterstitial != null) {
            customEventInterstitial.onResume();
        }
        CustomEventNative customEventNative = this.f2954d;
        if (customEventNative != null) {
            customEventNative.onResume();
        }
    }

    public final void requestBannerAd(Context context, C1347mo moVar, Bundle bundle, C0790gl glVar, C1089jo joVar, Bundle bundle2) {
        this.f2952b = (CustomEventBanner) m2828a(bundle.getString("class_name"));
        if (this.f2952b == null) {
            ((o40) moVar).mo9495a((MediationBannerAdapter) this, 0);
            return;
        }
        this.f2952b.requestBannerAd(context, new C0404a(this, moVar), bundle.getString(MediationRewardedVideoAdAdapter.CUSTOM_EVENT_SERVER_PARAMETER_FIELD), glVar, joVar, bundle2 == null ? null : bundle2.getBundle(bundle.getString("class_name")));
    }

    public final void requestInterstitialAd(Context context, C1711qo qoVar, Bundle bundle, C1089jo joVar, Bundle bundle2) {
        this.f2953c = (CustomEventInterstitial) m2828a(bundle.getString("class_name"));
        if (this.f2953c == null) {
            ((o40) qoVar).mo9498a((MediationInterstitialAdapter) this, 0);
            return;
        }
        this.f2953c.requestInterstitialAd(context, new C0406c(this, this, qoVar), bundle.getString(MediationRewardedVideoAdAdapter.CUSTOM_EVENT_SERVER_PARAMETER_FIELD), joVar, bundle2 == null ? null : bundle2.getBundle(bundle.getString("class_name")));
    }

    public final void requestNativeAd(Context context, C1872so soVar, Bundle bundle, C2295xo xoVar, Bundle bundle2) {
        this.f2954d = (CustomEventNative) m2828a(bundle.getString("class_name"));
        if (this.f2954d == null) {
            ((o40) soVar).mo9500a((MediationNativeAdapter) this, 0);
            return;
        }
        this.f2954d.requestNativeAd(context, new C0405b(this, soVar), bundle.getString(MediationRewardedVideoAdAdapter.CUSTOM_EVENT_SERVER_PARAMETER_FIELD), xoVar, bundle2 == null ? null : bundle2.getBundle(bundle.getString("class_name")));
    }

    public final void showInterstitial() {
        this.f2953c.showInterstitial();
    }
}
