package com.google.android.gms.ads.internal.overlay;

import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.ReflectedParcelable;
import p000.C2232wr;

public final class AdOverlayInfoParcel extends C1874sq implements ReflectedParcelable {
    public static final Parcelable.Creator<AdOverlayInfoParcel> CREATOR = new C0118an();

    /* renamed from: X */
    public final C1766rm f2935X;

    /* renamed from: Y */
    public final iv2 f2936Y;

    /* renamed from: Z */
    public final C0382cn f2937Z;

    /* renamed from: a0 */
    public final wj0 f2938a0;

    /* renamed from: b0 */
    public final C2241wx f2939b0;

    /* renamed from: c0 */
    public final String f2940c0;

    /* renamed from: d0 */
    public final boolean f2941d0;

    /* renamed from: e0 */
    public final String f2942e0;

    /* renamed from: f0 */
    public final C0873hn f2943f0;

    /* renamed from: g0 */
    public final int f2944g0;

    /* renamed from: h0 */
    public final int f2945h0;

    /* renamed from: i0 */
    public final String f2946i0;

    /* renamed from: j0 */
    public final nf0 f2947j0;

    /* renamed from: k0 */
    public final String f2948k0;

    /* renamed from: l0 */
    public final C2063un f2949l0;

    /* renamed from: m0 */
    public final C2076ux f2950m0;

    public AdOverlayInfoParcel(C0382cn cnVar, wj0 wj0, int i, nf0 nf0, String str, C2063un unVar, String str2, String str3) {
        this.f2935X = null;
        this.f2936Y = null;
        this.f2937Z = cnVar;
        this.f2938a0 = wj0;
        this.f2950m0 = null;
        this.f2939b0 = null;
        this.f2940c0 = str2;
        this.f2941d0 = false;
        this.f2942e0 = str3;
        this.f2943f0 = null;
        this.f2944g0 = i;
        this.f2945h0 = 1;
        this.f2946i0 = null;
        this.f2947j0 = nf0;
        this.f2948k0 = str;
        this.f2949l0 = unVar;
    }

    public AdOverlayInfoParcel(iv2 iv2, C0382cn cnVar, C0873hn hnVar, wj0 wj0, boolean z, int i, nf0 nf0) {
        this.f2935X = null;
        this.f2936Y = iv2;
        this.f2937Z = cnVar;
        this.f2938a0 = wj0;
        this.f2950m0 = null;
        this.f2939b0 = null;
        this.f2940c0 = null;
        this.f2941d0 = z;
        this.f2942e0 = null;
        this.f2943f0 = hnVar;
        this.f2944g0 = i;
        this.f2945h0 = 2;
        this.f2946i0 = null;
        this.f2947j0 = nf0;
        this.f2948k0 = null;
        this.f2949l0 = null;
    }

    public AdOverlayInfoParcel(iv2 iv2, C0382cn cnVar, C2076ux uxVar, C2241wx wxVar, C0873hn hnVar, wj0 wj0, boolean z, int i, String str, String str2, nf0 nf0) {
        this.f2935X = null;
        this.f2936Y = iv2;
        this.f2937Z = cnVar;
        this.f2938a0 = wj0;
        this.f2950m0 = uxVar;
        this.f2939b0 = wxVar;
        this.f2940c0 = str2;
        this.f2941d0 = z;
        this.f2942e0 = str;
        this.f2943f0 = hnVar;
        this.f2944g0 = i;
        this.f2945h0 = 3;
        this.f2946i0 = null;
        this.f2947j0 = nf0;
        this.f2948k0 = null;
        this.f2949l0 = null;
    }

    public AdOverlayInfoParcel(iv2 iv2, C0382cn cnVar, C2076ux uxVar, C2241wx wxVar, C0873hn hnVar, wj0 wj0, boolean z, int i, String str, nf0 nf0) {
        this.f2935X = null;
        this.f2936Y = iv2;
        this.f2937Z = cnVar;
        this.f2938a0 = wj0;
        this.f2950m0 = uxVar;
        this.f2939b0 = wxVar;
        this.f2940c0 = null;
        this.f2941d0 = z;
        this.f2942e0 = null;
        this.f2943f0 = hnVar;
        this.f2944g0 = i;
        this.f2945h0 = 3;
        this.f2946i0 = str;
        this.f2947j0 = nf0;
        this.f2948k0 = null;
        this.f2949l0 = null;
    }

    public AdOverlayInfoParcel(C1766rm rmVar, IBinder iBinder, IBinder iBinder2, IBinder iBinder3, IBinder iBinder4, String str, boolean z, String str2, IBinder iBinder5, int i, int i2, String str3, nf0 nf0, String str4, C2063un unVar, IBinder iBinder6) {
        this.f2935X = rmVar;
        this.f2936Y = (iv2) C2298xr.m15922z(C2232wr.C2233a.m15345a(iBinder));
        this.f2937Z = (C0382cn) C2298xr.m15922z(C2232wr.C2233a.m15345a(iBinder2));
        this.f2938a0 = (wj0) C2298xr.m15922z(C2232wr.C2233a.m15345a(iBinder3));
        this.f2950m0 = (C2076ux) C2298xr.m15922z(C2232wr.C2233a.m15345a(iBinder6));
        this.f2939b0 = (C2241wx) C2298xr.m15922z(C2232wr.C2233a.m15345a(iBinder4));
        this.f2940c0 = str;
        this.f2941d0 = z;
        this.f2942e0 = str2;
        this.f2943f0 = (C0873hn) C2298xr.m15922z(C2232wr.C2233a.m15345a(iBinder5));
        this.f2944g0 = i;
        this.f2945h0 = i2;
        this.f2946i0 = str3;
        this.f2947j0 = nf0;
        this.f2948k0 = str4;
        this.f2949l0 = unVar;
    }

    public AdOverlayInfoParcel(C1766rm rmVar, iv2 iv2, C0382cn cnVar, C0873hn hnVar, nf0 nf0) {
        this.f2935X = rmVar;
        this.f2936Y = iv2;
        this.f2937Z = cnVar;
        this.f2938a0 = null;
        this.f2950m0 = null;
        this.f2939b0 = null;
        this.f2940c0 = null;
        this.f2941d0 = false;
        this.f2942e0 = null;
        this.f2943f0 = hnVar;
        this.f2944g0 = -1;
        this.f2945h0 = 4;
        this.f2946i0 = null;
        this.f2947j0 = nf0;
        this.f2948k0 = null;
        this.f2949l0 = null;
    }

    /* renamed from: a */
    public static AdOverlayInfoParcel m2827a(Intent intent) {
        try {
            Bundle bundleExtra = intent.getBundleExtra("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo");
            bundleExtra.setClassLoader(AdOverlayInfoParcel.class.getClassLoader());
            return (AdOverlayInfoParcel) bundleExtra.getParcelable("com.google.android.gms.ads.inernal.overlay.AdOverlayInfo");
        } catch (Exception unused) {
            return null;
        }
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a = C0680fe.m4661a(parcel);
        C0680fe.m4748a(parcel, 2, (Parcelable) this.f2935X, i, false);
        C0680fe.m4747a(parcel, 3, new C2298xr(this.f2936Y).asBinder(), false);
        C0680fe.m4747a(parcel, 4, new C2298xr(this.f2937Z).asBinder(), false);
        C0680fe.m4747a(parcel, 5, new C2298xr(this.f2938a0).asBinder(), false);
        C0680fe.m4747a(parcel, 6, new C2298xr(this.f2939b0).asBinder(), false);
        C0680fe.m4749a(parcel, 7, this.f2940c0, false);
        C0680fe.m4751a(parcel, 8, this.f2941d0);
        C0680fe.m4749a(parcel, 9, this.f2942e0, false);
        C0680fe.m4747a(parcel, 10, new C2298xr(this.f2943f0).asBinder(), false);
        C0680fe.m4744a(parcel, 11, this.f2944g0);
        C0680fe.m4744a(parcel, 12, this.f2945h0);
        C0680fe.m4749a(parcel, 13, this.f2946i0, false);
        C0680fe.m4748a(parcel, 14, (Parcelable) this.f2947j0, i, false);
        C0680fe.m4749a(parcel, 16, this.f2948k0, false);
        C0680fe.m4748a(parcel, 17, (Parcelable) this.f2949l0, i, false);
        C0680fe.m4747a(parcel, 18, new C2298xr(this.f2950m0).asBinder(), false);
        C0680fe.m4891o(parcel, a);
    }
}
