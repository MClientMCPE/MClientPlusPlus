package com.google.android.gms.ads.mediation.customevent;

import android.content.Context;
import android.os.Bundle;

public interface CustomEventNative extends C0490cp {
    void requestNativeAd(Context context, C0875hp hpVar, String str, C2295xo xoVar, Bundle bundle);
}
