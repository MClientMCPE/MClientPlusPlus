package com.google.android.gms.ads;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.ProviderInfo;
import android.database.Cursor;
import android.net.Uri;

public class MobileAdsInitProvider extends ContentProvider {

    /* renamed from: X */
    public final vy2 f2934X = new vy2();

    public void attachInfo(Context context, ProviderInfo providerInfo) {
        this.f2934X.attachInfo(context, providerInfo);
    }

    public int delete(Uri uri, String str, String[] strArr) {
        this.f2934X.delete(uri, str, strArr);
        return 0;
    }

    public String getType(Uri uri) {
        this.f2934X.getType(uri);
        return null;
    }

    public Uri insert(Uri uri, ContentValues contentValues) {
        this.f2934X.insert(uri, contentValues);
        return null;
    }

    public boolean onCreate() {
        this.f2934X.onCreate();
        return false;
    }

    public Cursor query(Uri uri, String[] strArr, String str, String[] strArr2, String str2) {
        this.f2934X.query(uri, strArr, str, strArr2, str2);
        return null;
    }

    public int update(Uri uri, ContentValues contentValues, String str, String[] strArr) {
        this.f2934X.update(uri, contentValues, str, strArr);
        return 0;
    }
}
