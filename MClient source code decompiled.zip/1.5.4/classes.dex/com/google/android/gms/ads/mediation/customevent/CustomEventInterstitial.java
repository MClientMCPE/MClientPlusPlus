package com.google.android.gms.ads.mediation.customevent;

import android.content.Context;
import android.os.Bundle;

public interface CustomEventInterstitial extends C0490cp {
    void requestInterstitialAd(Context context, C0715fp fpVar, String str, C1089jo joVar, Bundle bundle);

    void showInterstitial();
}
