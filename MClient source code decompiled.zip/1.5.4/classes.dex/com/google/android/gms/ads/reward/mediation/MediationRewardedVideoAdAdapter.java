package com.google.android.gms.ads.reward.mediation;

import android.content.Context;
import android.os.Bundle;

public interface MediationRewardedVideoAdAdapter extends C1171ko {
    public static final String CUSTOM_EVENT_SERVER_PARAMETER_FIELD = "parameter";

    void initialize(Context context, C1089jo joVar, String str, C1542op opVar, Bundle bundle, Bundle bundle2);

    boolean isInitialized();

    void loadAd(C1089jo joVar, Bundle bundle, Bundle bundle2);

    void showVideo();
}
