package com.google.android.gms.dynamite;

import android.content.Context;
import android.database.Cursor;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.util.DynamiteApi;
import java.lang.reflect.Field;

public final class DynamiteModule {

    /* renamed from: b */
    public static Boolean f2962b = null;

    /* renamed from: c */
    public static C0623es f2963c = null;

    /* renamed from: d */
    public static C0798gs f2964d = null;

    /* renamed from: e */
    public static String f2965e = null;

    /* renamed from: f */
    public static int f2966f = -1;

    /* renamed from: g */
    public static final ThreadLocal<C0411c> f2967g = new ThreadLocal<>();

    /* renamed from: h */
    public static final C0408b.C0409a f2968h = new C2467zr();

    /* renamed from: i */
    public static final C0408b f2969i = new C0266as();

    /* renamed from: j */
    public static final C0408b f2970j = new C0318bs();

    /* renamed from: k */
    public static final C0408b f2971k = new C0493cs();

    /* renamed from: a */
    public final Context f2972a;

    @DynamiteApi
    public static class DynamiteLoaderClassLoader {
        public static ClassLoader sClassLoader;
    }

    /* renamed from: com.google.android.gms.dynamite.DynamiteModule$a */
    public static class C0407a extends Exception {
        public /* synthetic */ C0407a(String str, C2467zr zrVar) {
            super(str);
        }

        public /* synthetic */ C0407a(String str, Throwable th, C2467zr zrVar) {
            super(str, th);
        }
    }

    /* renamed from: com.google.android.gms.dynamite.DynamiteModule$b */
    public interface C0408b {

        /* renamed from: com.google.android.gms.dynamite.DynamiteModule$b$a */
        public interface C0409a {
            /* renamed from: a */
            int mo3272a(Context context, String str);

            /* renamed from: a */
            int mo3273a(Context context, String str, boolean z);
        }

        /* renamed from: com.google.android.gms.dynamite.DynamiteModule$b$b */
        public static class C0410b {

            /* renamed from: a */
            public int f2973a = 0;

            /* renamed from: b */
            public int f2974b = 0;

            /* renamed from: c */
            public int f2975c = 0;
        }

        /* renamed from: a */
        C0410b mo2131a(Context context, String str, C0409a aVar);
    }

    /* renamed from: com.google.android.gms.dynamite.DynamiteModule$c */
    public static class C0411c {

        /* renamed from: a */
        public Cursor f2976a;

        public C0411c() {
        }

        public /* synthetic */ C0411c(C2467zr zrVar) {
        }
    }

    /* renamed from: com.google.android.gms.dynamite.DynamiteModule$d */
    public static class C0412d implements C0408b.C0409a {

        /* renamed from: a */
        public final int f2977a;

        public C0412d(int i) {
            this.f2977a = i;
        }

        /* renamed from: a */
        public final int mo3272a(Context context, String str) {
            return this.f2977a;
        }

        /* renamed from: a */
        public final int mo3273a(Context context, String str, boolean z) {
            return 0;
        }
    }

    public DynamiteModule(Context context) {
        C0680fe.m4695a(context);
        this.f2972a = context;
    }

    /* renamed from: a */
    public static int m2829a(Context context, String str) {
        try {
            ClassLoader classLoader = context.getApplicationContext().getClassLoader();
            StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 61);
            sb.append("com.google.android.gms.dynamite.descriptors.");
            sb.append(str);
            sb.append(".ModuleDescriptor");
            Class<?> loadClass = classLoader.loadClass(sb.toString());
            Field declaredField = loadClass.getDeclaredField("MODULE_ID");
            Field declaredField2 = loadClass.getDeclaredField("MODULE_VERSION");
            if (declaredField.get((Object) null).equals(str)) {
                return declaredField2.getInt((Object) null);
            }
            String valueOf = String.valueOf(declaredField.get((Object) null));
            StringBuilder sb2 = new StringBuilder(valueOf.length() + 51 + String.valueOf(str).length());
            sb2.append("Module descriptor id '");
            sb2.append(valueOf);
            sb2.append("' didn't match expected id '");
            sb2.append(str);
            sb2.append("'");
            Log.e("DynamiteModule", sb2.toString());
            return 0;
        } catch (ClassNotFoundException unused) {
            StringBuilder sb3 = new StringBuilder(C0789gk.m5548a(str, 45));
            sb3.append("Local module descriptor class for ");
            sb3.append(str);
            sb3.append(" not found.");
            Log.w("DynamiteModule", sb3.toString());
            return 0;
        } catch (Exception e) {
            String valueOf2 = String.valueOf(e.getMessage());
            Log.e("DynamiteModule", valueOf2.length() != 0 ? "Failed to load module descriptor class: ".concat(valueOf2) : new String("Failed to load module descriptor class: "));
            return 0;
        }
    }

    /*  JADX ERROR: IndexOutOfBoundsException in pass: RegionMakerVisitor
        java.lang.IndexOutOfBoundsException: Index 0 out of bounds for length 0
        	at java.base/jdk.internal.util.Preconditions.outOfBounds(Preconditions.java:64)
        	at java.base/jdk.internal.util.Preconditions.outOfBoundsCheckIndex(Preconditions.java:70)
        	at java.base/jdk.internal.util.Preconditions.checkIndex(Preconditions.java:248)
        	at java.base/java.util.Objects.checkIndex(Objects.java:372)
        	at java.base/java.util.ArrayList.get(ArrayList.java:458)
        	at jadx.core.dex.nodes.InsnNode.getArg(InsnNode.java:101)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:611)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverseMonitorExits(RegionMaker.java:619)
        	at jadx.core.dex.visitors.regions.RegionMaker.processMonitorEnter(RegionMaker.java:561)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:133)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMaker.processIf(RegionMaker.java:693)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:123)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMaker.processMonitorEnter(RegionMaker.java:598)
        	at jadx.core.dex.visitors.regions.RegionMaker.traverse(RegionMaker.java:133)
        	at jadx.core.dex.visitors.regions.RegionMaker.makeRegion(RegionMaker.java:86)
        	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:49)
        */
    /* JADX WARNING: Unknown top exception splitter block from list: {B:23:0x0050=Splitter:B:23:0x0050, B:18:0x0035=Splitter:B:18:0x0035, B:35:0x0079=Splitter:B:35:0x0079} */
    /* renamed from: a */
    public static int m2830a(android.content.Context r8, java.lang.String r9, boolean r10) {
        /*
            java.lang.Class<com.google.android.gms.dynamite.DynamiteModule> r0 = com.google.android.gms.dynamite.DynamiteModule.class
            monitor-enter(r0)     // Catch:{ all -> 0x00e9 }
            java.lang.Boolean r1 = f2962b     // Catch:{ all -> 0x00e6 }
            if (r1 != 0) goto L_0x00b3
            android.content.Context r1 = r8.getApplicationContext()     // Catch:{ ClassNotFoundException -> 0x008e, IllegalAccessException -> 0x008c, NoSuchFieldException -> 0x008a }
            java.lang.ClassLoader r1 = r1.getClassLoader()     // Catch:{ ClassNotFoundException -> 0x008e, IllegalAccessException -> 0x008c, NoSuchFieldException -> 0x008a }
            java.lang.Class<com.google.android.gms.dynamite.DynamiteModule$DynamiteLoaderClassLoader> r2 = com.google.android.gms.dynamite.DynamiteModule.DynamiteLoaderClassLoader.class
            java.lang.String r2 = r2.getName()     // Catch:{ ClassNotFoundException -> 0x008e, IllegalAccessException -> 0x008c, NoSuchFieldException -> 0x008a }
            java.lang.Class r1 = r1.loadClass(r2)     // Catch:{ ClassNotFoundException -> 0x008e, IllegalAccessException -> 0x008c, NoSuchFieldException -> 0x008a }
            java.lang.String r2 = "sClassLoader"
            java.lang.reflect.Field r2 = r1.getDeclaredField(r2)     // Catch:{ ClassNotFoundException -> 0x008e, IllegalAccessException -> 0x008c, NoSuchFieldException -> 0x008a }
            monitor-enter(r1)     // Catch:{ ClassNotFoundException -> 0x008e, IllegalAccessException -> 0x008c, NoSuchFieldException -> 0x008a }
            r3 = 0
            java.lang.Object r4 = r2.get(r3)     // Catch:{ all -> 0x0087 }
            java.lang.ClassLoader r4 = (java.lang.ClassLoader) r4     // Catch:{ all -> 0x0087 }
            if (r4 == 0) goto L_0x0038
            java.lang.ClassLoader r2 = java.lang.ClassLoader.getSystemClassLoader()     // Catch:{ all -> 0x0087 }
            if (r4 != r2) goto L_0x0032
        L_0x002f:
            java.lang.Boolean r2 = java.lang.Boolean.FALSE     // Catch:{ all -> 0x0087 }
            goto L_0x0084
        L_0x0032:
            m2835a((java.lang.ClassLoader) r4)     // Catch:{ a -> 0x0035 }
        L_0x0035:
            java.lang.Boolean r2 = java.lang.Boolean.TRUE     // Catch:{ all -> 0x0087 }
            goto L_0x0084
        L_0x0038:
            java.lang.String r4 = "com.google.android.gms"
            android.content.Context r5 = r8.getApplicationContext()     // Catch:{ all -> 0x0087 }
            java.lang.String r5 = r5.getPackageName()     // Catch:{ all -> 0x0087 }
            boolean r4 = r4.equals(r5)     // Catch:{ all -> 0x0087 }
            if (r4 == 0) goto L_0x0050
            java.lang.ClassLoader r4 = java.lang.ClassLoader.getSystemClassLoader()     // Catch:{ all -> 0x0087 }
            r2.set(r3, r4)     // Catch:{ all -> 0x0087 }
            goto L_0x002f
        L_0x0050:
            int r4 = m2839c(r8, r9, r10)     // Catch:{ a -> 0x007c }
            java.lang.String r5 = f2965e     // Catch:{ a -> 0x007c }
            if (r5 == 0) goto L_0x0079
            java.lang.String r5 = f2965e     // Catch:{ a -> 0x007c }
            boolean r5 = r5.isEmpty()     // Catch:{ a -> 0x007c }
            if (r5 == 0) goto L_0x0061
            goto L_0x0079
        L_0x0061:
            ds r5 = new ds     // Catch:{ a -> 0x007c }
            java.lang.String r6 = f2965e     // Catch:{ a -> 0x007c }
            java.lang.ClassLoader r7 = java.lang.ClassLoader.getSystemClassLoader()     // Catch:{ a -> 0x007c }
            r5.<init>(r6, r7)     // Catch:{ a -> 0x007c }
            m2835a((java.lang.ClassLoader) r5)     // Catch:{ a -> 0x007c }
            r2.set(r3, r5)     // Catch:{ a -> 0x007c }
            java.lang.Boolean r5 = java.lang.Boolean.TRUE     // Catch:{ a -> 0x007c }
            f2962b = r5     // Catch:{ a -> 0x007c }
            monitor-exit(r1)     // Catch:{ all -> 0x0087 }
            monitor-exit(r0)     // Catch:{ all -> 0x00e6 }
            return r4
        L_0x0079:
            monitor-exit(r1)     // Catch:{ all -> 0x0087 }
            monitor-exit(r0)     // Catch:{ all -> 0x00e6 }
            return r4
        L_0x007c:
            java.lang.ClassLoader r4 = java.lang.ClassLoader.getSystemClassLoader()     // Catch:{ all -> 0x0087 }
            r2.set(r3, r4)     // Catch:{ all -> 0x0087 }
            goto L_0x002f
        L_0x0084:
            monitor-exit(r1)     // Catch:{ all -> 0x0087 }
            r1 = r2
            goto L_0x00b1
        L_0x0087:
            r2 = move-exception
            monitor-exit(r1)     // Catch:{ all -> 0x0087 }
            throw r2     // Catch:{ ClassNotFoundException -> 0x008e, IllegalAccessException -> 0x008c, NoSuchFieldException -> 0x008a }
        L_0x008a:
            r1 = move-exception
            goto L_0x008f
        L_0x008c:
            r1 = move-exception
            goto L_0x008f
        L_0x008e:
            r1 = move-exception
        L_0x008f:
            java.lang.String r2 = "DynamiteModule"
            java.lang.String r1 = java.lang.String.valueOf(r1)     // Catch:{ all -> 0x00e6 }
            int r3 = r1.length()     // Catch:{ all -> 0x00e6 }
            int r3 = r3 + 30
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch:{ all -> 0x00e6 }
            r4.<init>(r3)     // Catch:{ all -> 0x00e6 }
            java.lang.String r3 = "Failed to load module via V2: "
            r4.append(r3)     // Catch:{ all -> 0x00e6 }
            r4.append(r1)     // Catch:{ all -> 0x00e6 }
            java.lang.String r1 = r4.toString()     // Catch:{ all -> 0x00e6 }
            android.util.Log.w(r2, r1)     // Catch:{ all -> 0x00e6 }
            java.lang.Boolean r1 = java.lang.Boolean.FALSE     // Catch:{ all -> 0x00e6 }
        L_0x00b1:
            f2962b = r1     // Catch:{ all -> 0x00e6 }
        L_0x00b3:
            monitor-exit(r0)     // Catch:{ all -> 0x00e6 }
            boolean r0 = r1.booleanValue()     // Catch:{ all -> 0x00e9 }
            if (r0 == 0) goto L_0x00e1
            int r8 = m2839c(r8, r9, r10)     // Catch:{ a -> 0x00bf }
            return r8
        L_0x00bf:
            r9 = move-exception
            java.lang.String r10 = "DynamiteModule"
            java.lang.String r0 = "Failed to retrieve remote module version: "
            java.lang.String r9 = r9.getMessage()     // Catch:{ all -> 0x00e9 }
            java.lang.String r9 = java.lang.String.valueOf(r9)     // Catch:{ all -> 0x00e9 }
            int r1 = r9.length()     // Catch:{ all -> 0x00e9 }
            if (r1 == 0) goto L_0x00d7
            java.lang.String r9 = r0.concat(r9)     // Catch:{ all -> 0x00e9 }
            goto L_0x00dc
        L_0x00d7:
            java.lang.String r9 = new java.lang.String     // Catch:{ all -> 0x00e9 }
            r9.<init>(r0)     // Catch:{ all -> 0x00e9 }
        L_0x00dc:
            android.util.Log.w(r10, r9)     // Catch:{ all -> 0x00e9 }
            r8 = 0
            return r8
        L_0x00e1:
            int r8 = m2837b((android.content.Context) r8, (java.lang.String) r9, (boolean) r10)     // Catch:{ all -> 0x00e9 }
            return r8
        L_0x00e6:
            r9 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x00e6 }
            throw r9     // Catch:{ all -> 0x00e9 }
        L_0x00e9:
            r9 = move-exception
            p000.C0797gr.m5622a(r8, r9)
            goto L_0x00ef
        L_0x00ee:
            throw r9
        L_0x00ef:
            goto L_0x00ee
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.dynamite.DynamiteModule.m2830a(android.content.Context, java.lang.String, boolean):int");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:16:0x007a, code lost:
        if (r11 != null) goto L_0x007c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x008f, code lost:
        if (r11 != null) goto L_0x007c;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:38:0x00c8, code lost:
        if (r11 != null) goto L_0x007c;
     */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static com.google.android.gms.dynamite.DynamiteModule m2831a(android.content.Context r10, com.google.android.gms.dynamite.DynamiteModule.C0408b r11, java.lang.String r12) {
        /*
            java.lang.String r0 = ":"
            java.lang.String r1 = "DynamiteModule"
            java.lang.ThreadLocal<com.google.android.gms.dynamite.DynamiteModule$c> r2 = f2967g
            java.lang.Object r2 = r2.get()
            com.google.android.gms.dynamite.DynamiteModule$c r2 = (com.google.android.gms.dynamite.DynamiteModule.C0411c) r2
            com.google.android.gms.dynamite.DynamiteModule$c r3 = new com.google.android.gms.dynamite.DynamiteModule$c
            r4 = 0
            r3.<init>(r4)
            java.lang.ThreadLocal<com.google.android.gms.dynamite.DynamiteModule$c> r5 = f2967g
            r5.set(r3)
            com.google.android.gms.dynamite.DynamiteModule$b$a r5 = f2968h     // Catch:{ all -> 0x0116 }
            com.google.android.gms.dynamite.DynamiteModule$b$b r5 = r11.mo2131a(r10, r12, r5)     // Catch:{ all -> 0x0116 }
            int r6 = r5.f2973a     // Catch:{ all -> 0x0116 }
            int r7 = r5.f2974b     // Catch:{ all -> 0x0116 }
            java.lang.String r8 = java.lang.String.valueOf(r12)     // Catch:{ all -> 0x0116 }
            int r8 = r8.length()     // Catch:{ all -> 0x0116 }
            int r8 = r8 + 68
            java.lang.String r9 = java.lang.String.valueOf(r12)     // Catch:{ all -> 0x0116 }
            int r9 = r9.length()     // Catch:{ all -> 0x0116 }
            int r8 = r8 + r9
            java.lang.StringBuilder r9 = new java.lang.StringBuilder     // Catch:{ all -> 0x0116 }
            r9.<init>(r8)     // Catch:{ all -> 0x0116 }
            java.lang.String r8 = "Considering local module "
            r9.append(r8)     // Catch:{ all -> 0x0116 }
            r9.append(r12)     // Catch:{ all -> 0x0116 }
            r9.append(r0)     // Catch:{ all -> 0x0116 }
            r9.append(r6)     // Catch:{ all -> 0x0116 }
            java.lang.String r6 = " and remote module "
            r9.append(r6)     // Catch:{ all -> 0x0116 }
            r9.append(r12)     // Catch:{ all -> 0x0116 }
            r9.append(r0)     // Catch:{ all -> 0x0116 }
            r9.append(r7)     // Catch:{ all -> 0x0116 }
            java.lang.String r0 = r9.toString()     // Catch:{ all -> 0x0116 }
            android.util.Log.i(r1, r0)     // Catch:{ all -> 0x0116 }
            int r0 = r5.f2975c     // Catch:{ all -> 0x0116 }
            if (r0 == 0) goto L_0x00ec
            r6 = -1
            if (r0 != r6) goto L_0x0067
            int r0 = r5.f2973a     // Catch:{ all -> 0x0116 }
            if (r0 == 0) goto L_0x00ec
        L_0x0067:
            int r0 = r5.f2975c     // Catch:{ all -> 0x0116 }
            r7 = 1
            if (r0 != r7) goto L_0x0070
            int r0 = r5.f2974b     // Catch:{ all -> 0x0116 }
            if (r0 == 0) goto L_0x00ec
        L_0x0070:
            int r0 = r5.f2975c     // Catch:{ all -> 0x0116 }
            if (r0 != r6) goto L_0x0085
            com.google.android.gms.dynamite.DynamiteModule r10 = m2840c(r10, r12)     // Catch:{ all -> 0x0116 }
            android.database.Cursor r11 = r3.f2976a
            if (r11 == 0) goto L_0x007f
        L_0x007c:
            r11.close()
        L_0x007f:
            java.lang.ThreadLocal<com.google.android.gms.dynamite.DynamiteModule$c> r11 = f2967g
            r11.set(r2)
            return r10
        L_0x0085:
            if (r0 != r7) goto L_0x00d3
            int r0 = r5.f2974b     // Catch:{ a -> 0x0092 }
            com.google.android.gms.dynamite.DynamiteModule r10 = m2832a((android.content.Context) r10, (java.lang.String) r12, (int) r0)     // Catch:{ a -> 0x0092 }
            android.database.Cursor r11 = r3.f2976a
            if (r11 == 0) goto L_0x007f
            goto L_0x007c
        L_0x0092:
            r0 = move-exception
            java.lang.String r7 = "Failed to load remote module: "
            java.lang.String r8 = r0.getMessage()     // Catch:{ all -> 0x0116 }
            java.lang.String r8 = java.lang.String.valueOf(r8)     // Catch:{ all -> 0x0116 }
            int r9 = r8.length()     // Catch:{ all -> 0x0116 }
            if (r9 == 0) goto L_0x00a8
            java.lang.String r7 = r7.concat(r8)     // Catch:{ all -> 0x0116 }
            goto L_0x00ae
        L_0x00a8:
            java.lang.String r8 = new java.lang.String     // Catch:{ all -> 0x0116 }
            r8.<init>(r7)     // Catch:{ all -> 0x0116 }
            r7 = r8
        L_0x00ae:
            android.util.Log.w(r1, r7)     // Catch:{ all -> 0x0116 }
            int r1 = r5.f2973a     // Catch:{ all -> 0x0116 }
            if (r1 == 0) goto L_0x00cb
            com.google.android.gms.dynamite.DynamiteModule$d r5 = new com.google.android.gms.dynamite.DynamiteModule$d     // Catch:{ all -> 0x0116 }
            r5.<init>(r1)     // Catch:{ all -> 0x0116 }
            com.google.android.gms.dynamite.DynamiteModule$b$b r11 = r11.mo2131a(r10, r12, r5)     // Catch:{ all -> 0x0116 }
            int r11 = r11.f2975c     // Catch:{ all -> 0x0116 }
            if (r11 != r6) goto L_0x00cb
            com.google.android.gms.dynamite.DynamiteModule r10 = m2840c(r10, r12)     // Catch:{ all -> 0x0116 }
            android.database.Cursor r11 = r3.f2976a
            if (r11 == 0) goto L_0x007f
            goto L_0x007c
        L_0x00cb:
            com.google.android.gms.dynamite.DynamiteModule$a r10 = new com.google.android.gms.dynamite.DynamiteModule$a     // Catch:{ all -> 0x0116 }
            java.lang.String r11 = "Remote load failed. No local fallback found."
            r10.<init>(r11, r0, r4)     // Catch:{ all -> 0x0116 }
            throw r10     // Catch:{ all -> 0x0116 }
        L_0x00d3:
            com.google.android.gms.dynamite.DynamiteModule$a r10 = new com.google.android.gms.dynamite.DynamiteModule$a     // Catch:{ all -> 0x0116 }
            r11 = 47
            java.lang.StringBuilder r12 = new java.lang.StringBuilder     // Catch:{ all -> 0x0116 }
            r12.<init>(r11)     // Catch:{ all -> 0x0116 }
            java.lang.String r11 = "VersionPolicy returned invalid code:"
            r12.append(r11)     // Catch:{ all -> 0x0116 }
            r12.append(r0)     // Catch:{ all -> 0x0116 }
            java.lang.String r11 = r12.toString()     // Catch:{ all -> 0x0116 }
            r10.<init>(r11, r4)     // Catch:{ all -> 0x0116 }
            throw r10     // Catch:{ all -> 0x0116 }
        L_0x00ec:
            com.google.android.gms.dynamite.DynamiteModule$a r10 = new com.google.android.gms.dynamite.DynamiteModule$a     // Catch:{ all -> 0x0116 }
            int r11 = r5.f2973a     // Catch:{ all -> 0x0116 }
            int r12 = r5.f2974b     // Catch:{ all -> 0x0116 }
            r0 = 91
            java.lang.StringBuilder r1 = new java.lang.StringBuilder     // Catch:{ all -> 0x0116 }
            r1.<init>(r0)     // Catch:{ all -> 0x0116 }
            java.lang.String r0 = "No acceptable module found. Local version is "
            r1.append(r0)     // Catch:{ all -> 0x0116 }
            r1.append(r11)     // Catch:{ all -> 0x0116 }
            java.lang.String r11 = " and remote version is "
            r1.append(r11)     // Catch:{ all -> 0x0116 }
            r1.append(r12)     // Catch:{ all -> 0x0116 }
            java.lang.String r11 = "."
            r1.append(r11)     // Catch:{ all -> 0x0116 }
            java.lang.String r11 = r1.toString()     // Catch:{ all -> 0x0116 }
            r10.<init>(r11, r4)     // Catch:{ all -> 0x0116 }
            throw r10     // Catch:{ all -> 0x0116 }
        L_0x0116:
            r10 = move-exception
            android.database.Cursor r11 = r3.f2976a
            if (r11 == 0) goto L_0x011e
            r11.close()
        L_0x011e:
            java.lang.ThreadLocal<com.google.android.gms.dynamite.DynamiteModule$c> r11 = f2967g
            r11.set(r2)
            goto L_0x0125
        L_0x0124:
            throw r10
        L_0x0125:
            goto L_0x0124
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.dynamite.DynamiteModule.m2831a(android.content.Context, com.google.android.gms.dynamite.DynamiteModule$b, java.lang.String):com.google.android.gms.dynamite.DynamiteModule");
    }

    /* renamed from: a */
    public static DynamiteModule m2832a(Context context, String str, int i) {
        Boolean bool;
        C2232wr wrVar;
        try {
            synchronized (DynamiteModule.class) {
                bool = f2962b;
            }
            if (bool == null) {
                throw new C0407a("Failed to determine which loading route to use.", (C2467zr) null);
            } else if (bool.booleanValue()) {
                return m2838b(context, str, i);
            } else {
                StringBuilder sb = new StringBuilder(String.valueOf(str).length() + 51);
                sb.append("Selected remote version of ");
                sb.append(str);
                sb.append(", version >= ");
                sb.append(i);
                Log.i("DynamiteModule", sb.toString());
                C0623es a = m2833a(context);
                if (a != null) {
                    C0718fs fsVar = (C0718fs) a;
                    Parcel a2 = fsVar.mo11788a(6, fsVar.mo11787a());
                    int readInt = a2.readInt();
                    a2.recycle();
                    if (readInt >= 2) {
                        wrVar = fsVar.mo5770b(new C2298xr(context), str, i);
                    } else {
                        Log.w("DynamiteModule", "Dynamite loader version < 2, falling back to createModuleContext");
                        wrVar = fsVar.mo5769a(new C2298xr(context), str, i);
                    }
                    if (C2298xr.m15922z(wrVar) != null) {
                        return new DynamiteModule((Context) C2298xr.m15922z(wrVar));
                    }
                    throw new C0407a("Failed to load remote module.", (C2467zr) null);
                }
                throw new C0407a("Failed to create IDynamiteLoader.", (C2467zr) null);
            }
        } catch (RemoteException e) {
            throw new C0407a("Failed to load remote module.", e, (C2467zr) null);
        } catch (C0407a e2) {
            throw e2;
        } catch (Throwable th) {
            C0797gr.m5622a(context, th);
            throw new C0407a("Failed to load remote module.", th, (C2467zr) null);
        }
    }

    /* renamed from: a */
    public static Boolean m2834a() {
        Boolean valueOf;
        synchronized (DynamiteModule.class) {
            valueOf = Boolean.valueOf(f2966f >= 2);
        }
        return valueOf;
    }

    /* JADX WARNING: type inference failed for: r1v5, types: [android.os.IInterface] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void m2835a(java.lang.ClassLoader r3) {
        /*
            r0 = 0
            java.lang.String r1 = "com.google.android.gms.dynamiteloader.DynamiteLoaderV2"
            java.lang.Class r3 = r3.loadClass(r1)     // Catch:{ ClassNotFoundException -> 0x0039, IllegalAccessException -> 0x0037, InstantiationException -> 0x0035, InvocationTargetException -> 0x0033, NoSuchMethodException -> 0x0031 }
            r1 = 0
            java.lang.Class[] r2 = new java.lang.Class[r1]     // Catch:{ ClassNotFoundException -> 0x0039, IllegalAccessException -> 0x0037, InstantiationException -> 0x0035, InvocationTargetException -> 0x0033, NoSuchMethodException -> 0x0031 }
            java.lang.reflect.Constructor r3 = r3.getConstructor(r2)     // Catch:{ ClassNotFoundException -> 0x0039, IllegalAccessException -> 0x0037, InstantiationException -> 0x0035, InvocationTargetException -> 0x0033, NoSuchMethodException -> 0x0031 }
            java.lang.Object[] r1 = new java.lang.Object[r1]     // Catch:{ ClassNotFoundException -> 0x0039, IllegalAccessException -> 0x0037, InstantiationException -> 0x0035, InvocationTargetException -> 0x0033, NoSuchMethodException -> 0x0031 }
            java.lang.Object r3 = r3.newInstance(r1)     // Catch:{ ClassNotFoundException -> 0x0039, IllegalAccessException -> 0x0037, InstantiationException -> 0x0035, InvocationTargetException -> 0x0033, NoSuchMethodException -> 0x0031 }
            android.os.IBinder r3 = (android.os.IBinder) r3     // Catch:{ ClassNotFoundException -> 0x0039, IllegalAccessException -> 0x0037, InstantiationException -> 0x0035, InvocationTargetException -> 0x0033, NoSuchMethodException -> 0x0031 }
            if (r3 != 0) goto L_0x001a
            r3 = r0
            goto L_0x002e
        L_0x001a:
            java.lang.String r1 = "com.google.android.gms.dynamite.IDynamiteLoaderV2"
            android.os.IInterface r1 = r3.queryLocalInterface(r1)     // Catch:{ ClassNotFoundException -> 0x0039, IllegalAccessException -> 0x0037, InstantiationException -> 0x0035, InvocationTargetException -> 0x0033, NoSuchMethodException -> 0x0031 }
            boolean r2 = r1 instanceof p000.C0798gs     // Catch:{ ClassNotFoundException -> 0x0039, IllegalAccessException -> 0x0037, InstantiationException -> 0x0035, InvocationTargetException -> 0x0033, NoSuchMethodException -> 0x0031 }
            if (r2 == 0) goto L_0x0028
            r3 = r1
            gs r3 = (p000.C0798gs) r3     // Catch:{ ClassNotFoundException -> 0x0039, IllegalAccessException -> 0x0037, InstantiationException -> 0x0035, InvocationTargetException -> 0x0033, NoSuchMethodException -> 0x0031 }
            goto L_0x002e
        L_0x0028:
            hs r1 = new hs     // Catch:{ ClassNotFoundException -> 0x0039, IllegalAccessException -> 0x0037, InstantiationException -> 0x0035, InvocationTargetException -> 0x0033, NoSuchMethodException -> 0x0031 }
            r1.<init>(r3)     // Catch:{ ClassNotFoundException -> 0x0039, IllegalAccessException -> 0x0037, InstantiationException -> 0x0035, InvocationTargetException -> 0x0033, NoSuchMethodException -> 0x0031 }
            r3 = r1
        L_0x002e:
            f2964d = r3     // Catch:{ ClassNotFoundException -> 0x0039, IllegalAccessException -> 0x0037, InstantiationException -> 0x0035, InvocationTargetException -> 0x0033, NoSuchMethodException -> 0x0031 }
            return
        L_0x0031:
            r3 = move-exception
            goto L_0x003a
        L_0x0033:
            r3 = move-exception
            goto L_0x003a
        L_0x0035:
            r3 = move-exception
            goto L_0x003a
        L_0x0037:
            r3 = move-exception
            goto L_0x003a
        L_0x0039:
            r3 = move-exception
        L_0x003a:
            com.google.android.gms.dynamite.DynamiteModule$a r1 = new com.google.android.gms.dynamite.DynamiteModule$a
            java.lang.String r2 = "Failed to instantiate dynamite loader"
            r1.<init>(r2, r3, r0)
            throw r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.dynamite.DynamiteModule.m2835a(java.lang.ClassLoader):void");
    }

    /* renamed from: b */
    public static int m2836b(Context context, String str) {
        return m2830a(context, str, false);
    }

    /* renamed from: b */
    public static int m2837b(Context context, String str, boolean z) {
        C0623es a = m2833a(context);
        if (a == null) {
            return 0;
        }
        C0718fs fsVar = (C0718fs) a;
        try {
            Parcel a2 = fsVar.mo11788a(6, fsVar.mo11787a());
            int readInt = a2.readInt();
            a2.recycle();
            if (readInt >= 2) {
                C2298xr xrVar = new C2298xr(context);
                C0718fs fsVar2 = (C0718fs) a;
                Parcel a3 = fsVar2.mo11787a();
                x03.m15445a(a3, (IInterface) xrVar);
                a3.writeString(str);
                a3.writeInt(z);
                Parcel a4 = fsVar2.mo11788a(5, a3);
                int readInt2 = a4.readInt();
                a4.recycle();
                return readInt2;
            }
            Log.w("DynamiteModule", "IDynamite loader version < 2, falling back to getModuleVersion2");
            C2298xr xrVar2 = new C2298xr(context);
            C0718fs fsVar3 = (C0718fs) a;
            Parcel a5 = fsVar3.mo11787a();
            x03.m15445a(a5, (IInterface) xrVar2);
            a5.writeString(str);
            a5.writeInt(z ? 1 : 0);
            Parcel a6 = fsVar3.mo11788a(3, a5);
            int readInt3 = a6.readInt();
            a6.recycle();
            return readInt3;
        } catch (RemoteException e) {
            String valueOf = String.valueOf(e.getMessage());
            Log.w("DynamiteModule", valueOf.length() != 0 ? "Failed to retrieve remote module version: ".concat(valueOf) : new String("Failed to retrieve remote module version: "));
            return 0;
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:56:0x00b0  */
    /* renamed from: c */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static int m2839c(android.content.Context r8, java.lang.String r9, boolean r10) {
        /*
            r0 = 0
            android.content.ContentResolver r1 = r8.getContentResolver()     // Catch:{ Exception -> 0x009d, all -> 0x009b }
            if (r10 == 0) goto L_0x000a
            java.lang.String r8 = "api_force_staging"
            goto L_0x000c
        L_0x000a:
            java.lang.String r8 = "api"
        L_0x000c:
            int r10 = r8.length()     // Catch:{ Exception -> 0x009d, all -> 0x009b }
            int r10 = r10 + 42
            java.lang.String r2 = java.lang.String.valueOf(r9)     // Catch:{ Exception -> 0x009d, all -> 0x009b }
            int r2 = r2.length()     // Catch:{ Exception -> 0x009d, all -> 0x009b }
            int r10 = r10 + r2
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ Exception -> 0x009d, all -> 0x009b }
            r2.<init>(r10)     // Catch:{ Exception -> 0x009d, all -> 0x009b }
            java.lang.String r10 = "content://com.google.android.gms.chimera/"
            r2.append(r10)     // Catch:{ Exception -> 0x009d, all -> 0x009b }
            r2.append(r8)     // Catch:{ Exception -> 0x009d, all -> 0x009b }
            java.lang.String r8 = "/"
            r2.append(r8)     // Catch:{ Exception -> 0x009d, all -> 0x009b }
            r2.append(r9)     // Catch:{ Exception -> 0x009d, all -> 0x009b }
            java.lang.String r8 = r2.toString()     // Catch:{ Exception -> 0x009d, all -> 0x009b }
            android.net.Uri r2 = android.net.Uri.parse(r8)     // Catch:{ Exception -> 0x009d, all -> 0x009b }
            r3 = 0
            r4 = 0
            r5 = 0
            r6 = 0
            android.database.Cursor r8 = r1.query(r2, r3, r4, r5, r6)     // Catch:{ Exception -> 0x009d, all -> 0x009b }
            if (r8 == 0) goto L_0x0083
            boolean r9 = r8.moveToFirst()     // Catch:{ Exception -> 0x0096, all -> 0x0092 }
            if (r9 == 0) goto L_0x0083
            r9 = 0
            int r9 = r8.getInt(r9)     // Catch:{ Exception -> 0x0096, all -> 0x0092 }
            if (r9 <= 0) goto L_0x007d
            java.lang.Class<com.google.android.gms.dynamite.DynamiteModule> r10 = com.google.android.gms.dynamite.DynamiteModule.class
            monitor-enter(r10)     // Catch:{ Exception -> 0x0096, all -> 0x0092 }
            r1 = 2
            java.lang.String r1 = r8.getString(r1)     // Catch:{ all -> 0x007a }
            f2965e = r1     // Catch:{ all -> 0x007a }
            java.lang.String r1 = "loaderVersion"
            int r1 = r8.getColumnIndex(r1)     // Catch:{ all -> 0x007a }
            if (r1 < 0) goto L_0x0067
            int r1 = r8.getInt(r1)     // Catch:{ all -> 0x007a }
            f2966f = r1     // Catch:{ all -> 0x007a }
        L_0x0067:
            monitor-exit(r10)     // Catch:{ all -> 0x007a }
            java.lang.ThreadLocal<com.google.android.gms.dynamite.DynamiteModule$c> r10 = f2967g     // Catch:{ Exception -> 0x0096, all -> 0x0092 }
            java.lang.Object r10 = r10.get()     // Catch:{ Exception -> 0x0096, all -> 0x0092 }
            com.google.android.gms.dynamite.DynamiteModule$c r10 = (com.google.android.gms.dynamite.DynamiteModule.C0411c) r10     // Catch:{ Exception -> 0x0096, all -> 0x0092 }
            if (r10 == 0) goto L_0x007d
            android.database.Cursor r1 = r10.f2976a     // Catch:{ Exception -> 0x0096, all -> 0x0092 }
            if (r1 != 0) goto L_0x007d
            r10.f2976a = r8     // Catch:{ Exception -> 0x0096, all -> 0x0092 }
            r8 = r0
            goto L_0x007d
        L_0x007a:
            r9 = move-exception
            monitor-exit(r10)     // Catch:{ all -> 0x007a }
            throw r9     // Catch:{ Exception -> 0x0096, all -> 0x0092 }
        L_0x007d:
            if (r8 == 0) goto L_0x0082
            r8.close()
        L_0x0082:
            return r9
        L_0x0083:
            java.lang.String r9 = "DynamiteModule"
            java.lang.String r10 = "Failed to retrieve remote module version."
            android.util.Log.w(r9, r10)     // Catch:{ Exception -> 0x0096, all -> 0x0092 }
            com.google.android.gms.dynamite.DynamiteModule$a r9 = new com.google.android.gms.dynamite.DynamiteModule$a     // Catch:{ Exception -> 0x0096, all -> 0x0092 }
            java.lang.String r10 = "Failed to connect to dynamite module ContentResolver."
            r9.<init>(r10, r0)     // Catch:{ Exception -> 0x0096, all -> 0x0092 }
            throw r9     // Catch:{ Exception -> 0x0096, all -> 0x0092 }
        L_0x0092:
            r9 = move-exception
            r0 = r8
            r8 = r9
            goto L_0x00ae
        L_0x0096:
            r9 = move-exception
            r7 = r9
            r9 = r8
            r8 = r7
            goto L_0x009f
        L_0x009b:
            r8 = move-exception
            goto L_0x00ae
        L_0x009d:
            r8 = move-exception
            r9 = r0
        L_0x009f:
            boolean r10 = r8 instanceof com.google.android.gms.dynamite.DynamiteModule.C0407a     // Catch:{ all -> 0x00ac }
            if (r10 == 0) goto L_0x00a4
            throw r8     // Catch:{ all -> 0x00ac }
        L_0x00a4:
            com.google.android.gms.dynamite.DynamiteModule$a r10 = new com.google.android.gms.dynamite.DynamiteModule$a     // Catch:{ all -> 0x00ac }
            java.lang.String r1 = "V2 version check failed"
            r10.<init>(r1, r8, r0)     // Catch:{ all -> 0x00ac }
            throw r10     // Catch:{ all -> 0x00ac }
        L_0x00ac:
            r8 = move-exception
            r0 = r9
        L_0x00ae:
            if (r0 == 0) goto L_0x00b3
            r0.close()
        L_0x00b3:
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.dynamite.DynamiteModule.m2839c(android.content.Context, java.lang.String, boolean):int");
    }

    /* renamed from: c */
    public static DynamiteModule m2840c(Context context, String str) {
        String valueOf = String.valueOf(str);
        Log.i("DynamiteModule", valueOf.length() != 0 ? "Selected local version of ".concat(valueOf) : new String("Selected local version of "));
        return new DynamiteModule(context.getApplicationContext());
    }

    /* renamed from: a */
    public final IBinder mo3271a(String str) {
        try {
            return (IBinder) this.f2972a.getClassLoader().loadClass(str).newInstance();
        } catch (ClassNotFoundException | IllegalAccessException | InstantiationException e) {
            String valueOf = String.valueOf(str);
            throw new C0407a(valueOf.length() != 0 ? "Failed to instantiate module class: ".concat(valueOf) : new String("Failed to instantiate module class: "), e, (C2467zr) null);
        }
    }

    /* JADX WARNING: type inference failed for: r1v8, types: [android.os.IInterface] */
    /* JADX WARNING: Multi-variable type inference failed */
    /* JADX WARNING: No exception handlers in catch block: Catch:{  } */
    /* JADX WARNING: Unknown variable types count: 1 */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static p000.C0623es m2833a(android.content.Context r7) {
        /*
            java.lang.Class<com.google.android.gms.dynamite.DynamiteModule> r0 = com.google.android.gms.dynamite.DynamiteModule.class
            monitor-enter(r0)
            es r1 = f2963c     // Catch:{ all -> 0x00b7 }
            if (r1 == 0) goto L_0x000b
            es r7 = f2963c     // Catch:{ all -> 0x00b7 }
            monitor-exit(r0)     // Catch:{ all -> 0x00b7 }
            return r7
        L_0x000b:
            r1 = 12451000(0xbdfcb8, float:1.7447567E-38)
            int r1 = p000.C0264aq.m1544a(r7, r1)     // Catch:{ all -> 0x00b7 }
            r2 = 1
            r3 = 18
            if (r1 != r3) goto L_0x0018
            goto L_0x0057
        L_0x0018:
            if (r1 != r2) goto L_0x0056
            java.lang.String r4 = "com.google.android.gms"
            boolean r5 = p000.C0680fe.m4865f()     // Catch:{ all -> 0x00b7 }
            if (r5 == 0) goto L_0x0049
            android.content.pm.PackageManager r5 = r7.getPackageManager()     // Catch:{ Exception -> 0x0056 }
            android.content.pm.PackageInstaller r5 = r5.getPackageInstaller()     // Catch:{ Exception -> 0x0056 }
            java.util.List r5 = r5.getAllSessions()     // Catch:{ Exception -> 0x0056 }
            java.util.Iterator r5 = r5.iterator()     // Catch:{ all -> 0x00b7 }
        L_0x0032:
            boolean r6 = r5.hasNext()     // Catch:{ all -> 0x00b7 }
            if (r6 == 0) goto L_0x0049
            java.lang.Object r6 = r5.next()     // Catch:{ all -> 0x00b7 }
            android.content.pm.PackageInstaller$SessionInfo r6 = (android.content.pm.PackageInstaller.SessionInfo) r6     // Catch:{ all -> 0x00b7 }
            java.lang.String r6 = r6.getAppPackageName()     // Catch:{ all -> 0x00b7 }
            boolean r6 = r4.equals(r6)     // Catch:{ all -> 0x00b7 }
            if (r6 == 0) goto L_0x0032
            goto L_0x0057
        L_0x0049:
            android.content.pm.PackageManager r2 = r7.getPackageManager()     // Catch:{ all -> 0x00b7 }
            r5 = 8192(0x2000, float:1.14794E-41)
            android.content.pm.ApplicationInfo r2 = r2.getApplicationInfo(r4, r5)     // Catch:{  }
            boolean r2 = r2.enabled     // Catch:{  }
            goto L_0x0057
        L_0x0056:
            r2 = 0
        L_0x0057:
            if (r2 == 0) goto L_0x005b
            r1 = 18
        L_0x005b:
            r2 = 0
            if (r1 == 0) goto L_0x0060
            monitor-exit(r0)     // Catch:{ all -> 0x00b7 }
            return r2
        L_0x0060:
            java.lang.String r1 = "com.google.android.gms"
            r3 = 3
            android.content.Context r7 = r7.createPackageContext(r1, r3)     // Catch:{ Exception -> 0x0095 }
            java.lang.ClassLoader r7 = r7.getClassLoader()     // Catch:{ Exception -> 0x0095 }
            java.lang.String r1 = "com.google.android.gms.chimera.container.DynamiteLoaderImpl"
            java.lang.Class r7 = r7.loadClass(r1)     // Catch:{ Exception -> 0x0095 }
            java.lang.Object r7 = r7.newInstance()     // Catch:{ Exception -> 0x0095 }
            android.os.IBinder r7 = (android.os.IBinder) r7     // Catch:{ Exception -> 0x0095 }
            if (r7 != 0) goto L_0x007b
            r7 = r2
            goto L_0x008f
        L_0x007b:
            java.lang.String r1 = "com.google.android.gms.dynamite.IDynamiteLoader"
            android.os.IInterface r1 = r7.queryLocalInterface(r1)     // Catch:{ Exception -> 0x0095 }
            boolean r3 = r1 instanceof p000.C0623es     // Catch:{ Exception -> 0x0095 }
            if (r3 == 0) goto L_0x0089
            r7 = r1
            es r7 = (p000.C0623es) r7     // Catch:{ Exception -> 0x0095 }
            goto L_0x008f
        L_0x0089:
            fs r1 = new fs     // Catch:{ Exception -> 0x0095 }
            r1.<init>(r7)     // Catch:{ Exception -> 0x0095 }
            r7 = r1
        L_0x008f:
            if (r7 == 0) goto L_0x00b5
            f2963c = r7     // Catch:{ Exception -> 0x0095 }
            monitor-exit(r0)     // Catch:{ all -> 0x00b7 }
            return r7
        L_0x0095:
            r7 = move-exception
            java.lang.String r1 = "DynamiteModule"
            java.lang.String r3 = "Failed to load IDynamiteLoader from GmsCore: "
            java.lang.String r7 = r7.getMessage()     // Catch:{ all -> 0x00b7 }
            java.lang.String r7 = java.lang.String.valueOf(r7)     // Catch:{ all -> 0x00b7 }
            int r4 = r7.length()     // Catch:{ all -> 0x00b7 }
            if (r4 == 0) goto L_0x00ad
            java.lang.String r7 = r3.concat(r7)     // Catch:{ all -> 0x00b7 }
            goto L_0x00b2
        L_0x00ad:
            java.lang.String r7 = new java.lang.String     // Catch:{ all -> 0x00b7 }
            r7.<init>(r3)     // Catch:{ all -> 0x00b7 }
        L_0x00b2:
            android.util.Log.e(r1, r7)     // Catch:{ all -> 0x00b7 }
        L_0x00b5:
            monitor-exit(r0)     // Catch:{ all -> 0x00b7 }
            return r2
        L_0x00b7:
            r7 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x00b7 }
            goto L_0x00bb
        L_0x00ba:
            throw r7
        L_0x00bb:
            goto L_0x00ba
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.dynamite.DynamiteModule.m2833a(android.content.Context):es");
    }

    /* renamed from: b */
    public static DynamiteModule m2838b(Context context, String str, int i) {
        C0798gs gsVar;
        C2232wr wrVar;
        StringBuilder sb = new StringBuilder(C0789gk.m5548a(str, 51));
        sb.append("Selected remote version of ");
        sb.append(str);
        sb.append(", version >= ");
        sb.append(i);
        Log.i("DynamiteModule", sb.toString());
        synchronized (DynamiteModule.class) {
            gsVar = f2964d;
        }
        if (gsVar != null) {
            C0411c cVar = f2967g.get();
            if (cVar == null || cVar.f2976a == null) {
                throw new C0407a("No result cursor", (C2467zr) null);
            }
            Context applicationContext = context.getApplicationContext();
            Cursor cursor = cVar.f2976a;
            new C2298xr(null);
            if (m2834a().booleanValue()) {
                Log.v("DynamiteModule", "Dynamite loader version >= 2, using loadModule2NoCrashUtils");
                C2298xr xrVar = new C2298xr(applicationContext);
                C2298xr xrVar2 = new C2298xr(cursor);
                C0878hs hsVar = (C0878hs) gsVar;
                Parcel a = hsVar.mo11787a();
                x03.m15445a(a, (IInterface) xrVar);
                a.writeString(str);
                a.writeInt(i);
                x03.m15445a(a, (IInterface) xrVar2);
                wrVar = C0789gk.m5564a(hsVar.mo11788a(3, a));
            } else {
                Log.w("DynamiteModule", "Dynamite loader version < 2, falling back to loadModule2");
                C2298xr xrVar3 = new C2298xr(applicationContext);
                C2298xr xrVar4 = new C2298xr(cursor);
                C0878hs hsVar2 = (C0878hs) gsVar;
                Parcel a2 = hsVar2.mo11787a();
                x03.m15445a(a2, (IInterface) xrVar3);
                a2.writeString(str);
                a2.writeInt(i);
                x03.m15445a(a2, (IInterface) xrVar4);
                wrVar = C0789gk.m5564a(hsVar2.mo11788a(2, a2));
            }
            Context context2 = (Context) C2298xr.m15922z(wrVar);
            if (context2 != null) {
                return new DynamiteModule(context2);
            }
            throw new C0407a("Failed to get module context", (C2467zr) null);
        }
        throw new C0407a("DynamiteLoaderV2 was not cached.", (C2467zr) null);
    }
}
