package com.google.android.gms.internal.ads;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.text.TextUtils;
import com.google.android.gms.ads.internal.overlay.AdOverlayInfoParcel;
import com.google.android.gms.ads.mediation.MediationInterstitialAdapter;

public final class zzany implements MediationInterstitialAdapter {

    /* renamed from: a */
    public Activity f2978a;

    /* renamed from: b */
    public C1711qo f2979b;

    /* renamed from: c */
    public Uri f2980c;

    public final void onDestroy() {
        C0680fe.m4886l("Destroying AdMobCustomTabsAdapter adapter.");
    }

    public final void onPause() {
        C0680fe.m4886l("Pausing AdMobCustomTabsAdapter adapter.");
    }

    public final void onResume() {
        C0680fe.m4886l("Resuming AdMobCustomTabsAdapter adapter.");
    }

    public final void requestInterstitialAd(Context context, C1711qo qoVar, Bundle bundle, C1089jo joVar, Bundle bundle2) {
        this.f2979b = qoVar;
        if (this.f2979b == null) {
            C0680fe.m4893p("Listener not set for mediation. Returning.");
        } else if (!(context instanceof Activity)) {
            C0680fe.m4893p("AdMobCustomTabs can only work with Activity context. Bailing out.");
            ((o40) this.f2979b).mo9498a((MediationInterstitialAdapter) this, 0);
        } else {
            if (!(C0680fe.m4874h(context))) {
                C0680fe.m4893p("Default browser does not support custom tabs. Bailing out.");
                ((o40) this.f2979b).mo9498a((MediationInterstitialAdapter) this, 0);
                return;
            }
            String string = bundle.getString("tab_url");
            if (TextUtils.isEmpty(string)) {
                C0680fe.m4893p("The tab_url retrieved from mediation metadata is empty. Bailing out.");
                ((o40) this.f2979b).mo9498a((MediationInterstitialAdapter) this, 0);
                return;
            }
            this.f2978a = (Activity) context;
            this.f2980c = Uri.parse(string);
            ((o40) this.f2979b).mo9512d((MediationInterstitialAdapter) this);
        }
    }

    public final void showInterstitial() {
        Intent intent = new Intent("android.intent.action.VIEW");
        Bundle bundle = new Bundle();
        int i = Build.VERSION.SDK_INT;
        bundle.putBinder("android.support.customtabs.extra.SESSION", (IBinder) null);
        intent.putExtras(bundle);
        intent.putExtra("android.support.customtabs.extra.EXTRA_ENABLE_INSTANT_APPS", true);
        C1307m4 m4Var = new C1307m4(intent, (Bundle) null);
        m4Var.f9981a.setData(this.f2980c);
        xc0.f17110h.post(new c60(this, new AdOverlayInfoParcel(new C1766rm(m4Var.f9981a), (iv2) null, new z50(this), (C0873hn) null, new nf0(0, 0, false))));
        C0619eo.f4708B.f4716g.f3808j.mo6508a();
    }
}
