package com.google.android.gms.internal.ads;

import android.os.Bundle;
import com.google.android.gms.ads.mediation.MediationBannerAdapter;

public interface zzbfw extends MediationBannerAdapter {
    Bundle zzsn();
}
