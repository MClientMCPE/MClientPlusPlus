package com.google.android.gms.common.api.internal;

import androidx.annotation.Keep;

public class LifecycleCallback {
    @Keep
    public static C0796gq getChimeraLifecycleFragmentImpl(C0716fq fqVar) {
        throw new IllegalStateException("Method not available in SDK.");
    }
}
