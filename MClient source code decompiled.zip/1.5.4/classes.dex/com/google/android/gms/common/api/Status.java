package com.google.android.gms.common.api;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable;
import com.google.android.gms.common.internal.ReflectedParcelable;
import java.util.Arrays;

public final class Status extends C1874sq implements C0553dq, ReflectedParcelable {
    public static final Parcelable.Creator<Status> CREATOR = new C0963iq();

    /* renamed from: b0 */
    public static final Status f2957b0 = new Status(0, (String) null);

    /* renamed from: X */
    public final int f2958X;

    /* renamed from: Y */
    public final int f2959Y;

    /* renamed from: Z */
    public final String f2960Z;

    /* renamed from: a0 */
    public final PendingIntent f2961a0;

    static {
        new Status(14, (String) null);
        new Status(8, (String) null);
        new Status(15, (String) null);
        new Status(16, (String) null);
        new Status(17, (String) null);
        new Status(18, (String) null);
    }

    public Status(int i, int i2, String str, PendingIntent pendingIntent) {
        this.f2958X = i;
        this.f2959Y = i2;
        this.f2960Z = str;
        this.f2961a0 = pendingIntent;
    }

    public Status(int i, String str) {
        this.f2958X = 1;
        this.f2959Y = i;
        this.f2960Z = str;
        this.f2961a0 = null;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof Status)) {
            return false;
        }
        Status status = (Status) obj;
        return this.f2958X == status.f2958X && this.f2959Y == status.f2959Y && C0680fe.m4835c((Object) this.f2960Z, (Object) status.f2960Z) && C0680fe.m4835c((Object) this.f2961a0, (Object) status.f2961a0);
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f2958X), Integer.valueOf(this.f2959Y), this.f2960Z, this.f2961a0});
    }

    public final String toString() {
        C1770rq d = C0680fe.m4840d((Object) this);
        String str = this.f2960Z;
        if (str == null) {
            int i = this.f2959Y;
            switch (i) {
                case -1:
                    str = "SUCCESS_CACHE";
                    break;
                case 0:
                    str = "SUCCESS";
                    break;
                case 2:
                    str = "SERVICE_VERSION_UPDATE_REQUIRED";
                    break;
                case 3:
                    str = "SERVICE_DISABLED";
                    break;
                case 4:
                    str = "SIGN_IN_REQUIRED";
                    break;
                case 5:
                    str = "INVALID_ACCOUNT";
                    break;
                case 6:
                    str = "RESOLUTION_REQUIRED";
                    break;
                case 7:
                    str = "NETWORK_ERROR";
                    break;
                case 8:
                    str = "INTERNAL_ERROR";
                    break;
                case 10:
                    str = "DEVELOPER_ERROR";
                    break;
                case 13:
                    str = "ERROR";
                    break;
                case 14:
                    str = "INTERRUPTED";
                    break;
                case 15:
                    str = "TIMEOUT";
                    break;
                case 16:
                    str = "CANCELED";
                    break;
                case 17:
                    str = "API_NOT_CONNECTED";
                    break;
                case 18:
                    str = "DEAD_CLIENT";
                    break;
                default:
                    str = C0789gk.m5551a(32, "unknown status code: ", i);
                    break;
            }
        }
        d.mo10724a("statusCode", str);
        d.mo10724a("resolution", this.f2961a0);
        return d.toString();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a = C0680fe.m4661a(parcel);
        C0680fe.m4744a(parcel, 1, this.f2959Y);
        C0680fe.m4749a(parcel, 2, this.f2960Z, false);
        C0680fe.m4748a(parcel, 3, (Parcelable) this.f2961a0, i, false);
        C0680fe.m4744a(parcel, 1000, this.f2958X);
        C0680fe.m4891o(parcel, a);
    }
}
