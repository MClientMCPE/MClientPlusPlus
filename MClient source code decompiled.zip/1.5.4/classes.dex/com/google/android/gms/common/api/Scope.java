package com.google.android.gms.common.api;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import com.google.android.gms.common.internal.ReflectedParcelable;

public final class Scope extends C1874sq implements ReflectedParcelable {
    public static final Parcelable.Creator<Scope> CREATOR = new C0876hq();

    /* renamed from: X */
    public final int f2955X;

    /* renamed from: Y */
    public final String f2956Y;

    public Scope(int i, String str) {
        if (!TextUtils.isEmpty(str)) {
            this.f2955X = i;
            this.f2956Y = str;
            return;
        }
        throw new IllegalArgumentException("scopeUri must not be null or empty");
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Scope)) {
            return false;
        }
        return this.f2956Y.equals(((Scope) obj).f2956Y);
    }

    public final int hashCode() {
        return this.f2956Y.hashCode();
    }

    public final String toString() {
        return this.f2956Y;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int a = C0680fe.m4661a(parcel);
        C0680fe.m4744a(parcel, 1, this.f2955X);
        C0680fe.m4749a(parcel, 2, this.f2956Y, false);
        C0680fe.m4891o(parcel, a);
    }
}
