package com.google.android.material.behavior;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewPropertyAnimator;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

public class HideBottomViewOnScrollBehavior<V extends View> extends CoordinatorLayout.C0174c<V> {

    /* renamed from: a */
    public int f3011a = 0;

    /* renamed from: b */
    public int f3012b = 2;

    /* renamed from: c */
    public int f3013c = 0;

    /* renamed from: d */
    public ViewPropertyAnimator f3014d;

    /* renamed from: com.google.android.material.behavior.HideBottomViewOnScrollBehavior$a */
    public class C0417a extends AnimatorListenerAdapter {
        public C0417a() {
        }

        public void onAnimationEnd(Animator animator) {
            HideBottomViewOnScrollBehavior.this.f3014d = null;
        }
    }

    public HideBottomViewOnScrollBehavior() {
    }

    public HideBottomViewOnScrollBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    /* renamed from: a */
    public void mo3350a(V v) {
        if (this.f3012b != 1) {
            ViewPropertyAnimator viewPropertyAnimator = this.f3014d;
            if (viewPropertyAnimator != null) {
                viewPropertyAnimator.cancel();
                v.clearAnimation();
            }
            this.f3012b = 1;
            mo3352a(v, this.f3011a + this.f3013c, 175, m33.f9976c);
        }
    }

    /* renamed from: a */
    public void mo3351a(V v, int i) {
        this.f3013c = i;
        if (this.f3012b == 1) {
            v.setTranslationY((float) (this.f3011a + this.f3013c));
        }
    }

    /* renamed from: a */
    public final void mo3352a(V v, int i, long j, TimeInterpolator timeInterpolator) {
        this.f3014d = v.animate().translationY((float) i).setInterpolator(timeInterpolator).setDuration(j).setListener(new C0417a());
    }

    /* renamed from: a */
    public void mo1257a(CoordinatorLayout coordinatorLayout, V v, View view, int i, int i2, int i3, int i4) {
        if (i2 > 0) {
            mo3350a(v);
        } else if (i2 < 0) {
            mo3353b(v);
        }
    }

    /* renamed from: a */
    public boolean mo203a(CoordinatorLayout coordinatorLayout, V v, int i) {
        this.f3011a = v.getMeasuredHeight() + ((ViewGroup.MarginLayoutParams) v.getLayoutParams()).bottomMargin;
        super.mo203a(coordinatorLayout, v, i);
        return false;
    }

    /* renamed from: a */
    public boolean mo1269a(CoordinatorLayout coordinatorLayout, V v, View view, View view2, int i) {
        return i == 2;
    }

    /* renamed from: b */
    public void mo3353b(V v) {
        if (this.f3012b != 2) {
            ViewPropertyAnimator viewPropertyAnimator = this.f3014d;
            if (viewPropertyAnimator != null) {
                viewPropertyAnimator.cancel();
                v.clearAnimation();
            }
            this.f3012b = 2;
            mo3352a(v, 0, 225, m33.f9977d);
        }
    }
}
