package com.google.android.material.bottomappbar;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.behavior.HideBottomViewOnScrollBehavior;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import p000.f73;

public class BottomAppBar extends Toolbar implements CoordinatorLayout.C0173b {

    /* renamed from: P0 */
    public final int f3032P0;

    /* renamed from: Q0 */
    public final f73 f3033Q0;

    /* renamed from: R0 */
    public Animator f3034R0;

    /* renamed from: S0 */
    public Animator f3035S0;

    /* renamed from: T0 */
    public int f3036T0;

    /* renamed from: U0 */
    public int f3037U0;

    /* renamed from: V0 */
    public boolean f3038V0;

    /* renamed from: W0 */
    public int f3039W0;

    /* renamed from: X0 */
    public ArrayList<C0422a> f3040X0;

    /* renamed from: Y0 */
    public boolean f3041Y0;

    /* renamed from: Z0 */
    public Behavior f3042Z0;

    /* renamed from: a1 */
    public int f3043a1;

    /* renamed from: b1 */
    public AnimatorListenerAdapter f3044b1;

    public static class Behavior extends HideBottomViewOnScrollBehavior<BottomAppBar> {

        /* renamed from: e */
        public final Rect f3045e = new Rect();

        /* renamed from: f */
        public WeakReference<BottomAppBar> f3046f;

        /* renamed from: g */
        public int f3047g;

        /* renamed from: h */
        public final View.OnLayoutChangeListener f3048h = new C0421a();

        /* renamed from: com.google.android.material.bottomappbar.BottomAppBar$Behavior$a */
        public class C0421a implements View.OnLayoutChangeListener {
            public C0421a() {
            }

            public void onLayoutChange(View view, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8) {
                BottomAppBar bottomAppBar = (BottomAppBar) Behavior.this.f3046f.get();
                if (bottomAppBar == null || !(view instanceof FloatingActionButton)) {
                    view.removeOnLayoutChangeListener(this);
                    return;
                }
                FloatingActionButton floatingActionButton = (FloatingActionButton) view;
                floatingActionButton.mo3724b(Behavior.this.f3045e);
                int height = Behavior.this.f3045e.height();
                bottomAppBar.mo3373e(height);
                CoordinatorLayout.C0177f fVar = (CoordinatorLayout.C0177f) view.getLayoutParams();
                if (Behavior.this.f3047g == 0) {
                    int dimensionPixelOffset = bottomAppBar.getResources().getDimensionPixelOffset(d33.mtrl_bottomappbar_fab_bottom_margin);
                    fVar.bottomMargin = bottomAppBar.getBottomInset() + (dimensionPixelOffset - ((floatingActionButton.getMeasuredHeight() - height) / 2));
                }
            }
        }

        public Behavior() {
        }

        public Behavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        /* renamed from: a */
        public boolean mo203a(CoordinatorLayout coordinatorLayout, BottomAppBar bottomAppBar, int i) {
            this.f3046f = new WeakReference<>(bottomAppBar);
            View c = bottomAppBar.mo3384r();
            if (c != null && !C2189w7.m15031z(c)) {
                CoordinatorLayout.C0177f fVar = (CoordinatorLayout.C0177f) c.getLayoutParams();
                fVar.f1041d = 49;
                this.f3047g = fVar.bottomMargin;
                if (c instanceof FloatingActionButton) {
                    FloatingActionButton floatingActionButton = (FloatingActionButton) c;
                    floatingActionButton.addOnLayoutChangeListener(this.f3048h);
                    floatingActionButton.mo3717a((Animator.AnimatorListener) bottomAppBar.f3044b1);
                    floatingActionButton.mo3723b((Animator.AnimatorListener) new j43(bottomAppBar));
                    floatingActionButton.mo3720a((v33<? extends FloatingActionButton>) null);
                }
                bottomAppBar.mo3394t();
            }
            coordinatorLayout.mo1213c((View) bottomAppBar, i);
            super.mo203a(coordinatorLayout, bottomAppBar, i);
            return false;
        }

        /* renamed from: a */
        public boolean mo1274b(CoordinatorLayout coordinatorLayout, BottomAppBar bottomAppBar, View view, View view2, int i, int i2) {
            return bottomAppBar.getHideOnScroll() && super.mo1274b(coordinatorLayout, bottomAppBar, view, view2, i, i2);
        }
    }

    /* renamed from: com.google.android.material.bottomappbar.BottomAppBar$a */
    public interface C0422a {
        /* renamed from: a */
        void mo3398a(BottomAppBar bottomAppBar);

        /* renamed from: b */
        void mo3399b(BottomAppBar bottomAppBar);
    }

    /* renamed from: com.google.android.material.bottomappbar.BottomAppBar$b */
    public static class C0423b extends C1904t8 {
        public static final Parcelable.Creator<C0423b> CREATOR = new C0424a();

        /* renamed from: Z */
        public int f3050Z;

        /* renamed from: a0 */
        public boolean f3051a0;

        /* renamed from: com.google.android.material.bottomappbar.BottomAppBar$b$a */
        public static class C0424a implements Parcelable.ClassLoaderCreator<C0423b> {
            public Object createFromParcel(Parcel parcel) {
                return new C0423b(parcel, (ClassLoader) null);
            }

            public Object[] newArray(int i) {
                return new C0423b[i];
            }

            public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new C0423b(parcel, classLoader);
            }
        }

        public C0423b(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f3050Z = parcel.readInt();
            this.f3051a0 = parcel.readInt() != 0;
        }

        public C0423b(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeParcelable(this.f14707X, i);
            parcel.writeInt(this.f3050Z);
            parcel.writeInt(this.f3051a0 ? 1 : 0);
        }
    }

    /* renamed from: e */
    public static /* synthetic */ void m2928e(BottomAppBar bottomAppBar) {
        ArrayList<C0422a> arrayList;
        int i = bottomAppBar.f3039W0 - 1;
        bottomAppBar.f3039W0 = i;
        if (i == 0 && (arrayList = bottomAppBar.f3040X0) != null) {
            Iterator<C0422a> it = arrayList.iterator();
            while (it.hasNext()) {
                it.next().mo3398a(bottomAppBar);
            }
        }
    }

    private ActionMenuView getActionMenuView() {
        for (int i = 0; i < getChildCount(); i++) {
            View childAt = getChildAt(i);
            if (childAt instanceof ActionMenuView) {
                return (ActionMenuView) childAt;
            }
        }
        return null;
    }

    /* access modifiers changed from: private */
    public int getBottomInset() {
        return this.f3043a1;
    }

    /* access modifiers changed from: private */
    public float getFabTranslationX() {
        return mo3372d(this.f3036T0);
    }

    private float getFabTranslationY() {
        return -getTopEdgeTreatment().f8912a0;
    }

    private k43 getTopEdgeTreatment() {
        return (k43) this.f3033Q0.f5079X.f5101a.f8130i;
    }

    /* renamed from: a */
    public int mo3370a(ActionMenuView actionMenuView, int i, boolean z) {
        boolean z2 = C2189w7.m15018m(this) == 1;
        int measuredWidth = z2 ? getMeasuredWidth() : 0;
        for (int i2 = 0; i2 < getChildCount(); i2++) {
            View childAt = getChildAt(i2);
            if ((childAt.getLayoutParams() instanceof Toolbar.C0166e) && (((Toolbar.C0166e) childAt.getLayoutParams()).f10754a & 8388615) == 8388611) {
                measuredWidth = z2 ? Math.min(measuredWidth, childAt.getLeft()) : Math.max(measuredWidth, childAt.getRight());
            }
        }
        int right = measuredWidth - (z2 ? actionMenuView.getRight() : actionMenuView.getLeft());
        if (i != 1 || !z) {
            return 0;
        }
        return right;
    }

    /* renamed from: c */
    public void mo3371c(int i) {
        FloatingActionButton q = mo3383q();
        if (q != null && !q.mo3727b()) {
            mo3382p();
            q.mo3718a((FloatingActionButton.C0445a) new g43(this, i));
        }
    }

    /* renamed from: d */
    public final float mo3372d(int i) {
        int i2 = 1;
        boolean z = C2189w7.m15018m(this) == 1;
        if (i != 1) {
            return 0.0f;
        }
        int measuredWidth = (getMeasuredWidth() / 2) - this.f3032P0;
        if (z) {
            i2 = -1;
        }
        return (float) (measuredWidth * i2);
    }

    public ColorStateList getBackgroundTint() {
        return this.f3033Q0.f5079X.f5107g;
    }

    public Behavior getBehavior() {
        if (this.f3042Z0 == null) {
            this.f3042Z0 = new Behavior();
        }
        return this.f3042Z0;
    }

    public float getCradleVerticalOffset() {
        return getTopEdgeTreatment().f8912a0;
    }

    public int getFabAlignmentMode() {
        return this.f3036T0;
    }

    public int getFabAnimationMode() {
        return this.f3037U0;
    }

    public float getFabCradleMargin() {
        return getTopEdgeTreatment().f8910Y;
    }

    public float getFabCradleRoundedCornerRadius() {
        return getTopEdgeTreatment().f8909X;
    }

    public boolean getHideOnScroll() {
        return this.f3038V0;
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        t53.m13106a((View) this, this.f3033Q0);
        if (getParent() instanceof ViewGroup) {
            ((ViewGroup) getParent()).setClipChildren(false);
        }
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int i5;
        super.onLayout(z, i, i2, i3, i4);
        if (z) {
            Animator animator = this.f3035S0;
            if (animator != null) {
                animator.cancel();
            }
            Animator animator2 = this.f3034R0;
            if (animator2 != null) {
                animator2.cancel();
            }
            mo3394t();
        }
        ActionMenuView actionMenuView = getActionMenuView();
        if (actionMenuView != null) {
            actionMenuView.setAlpha(1.0f);
            if (!mo3385s()) {
                i5 = mo3370a(actionMenuView, 0, false);
            } else {
                i5 = mo3370a(actionMenuView, this.f3036T0, this.f3041Y0);
            }
            actionMenuView.setTranslationX((float) i5);
        }
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof C0423b)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        C0423b bVar = (C0423b) parcelable;
        super.onRestoreInstanceState(bVar.f14707X);
        this.f3036T0 = bVar.f3050Z;
        this.f3041Y0 = bVar.f3051a0;
    }

    public Parcelable onSaveInstanceState() {
        C0423b bVar = new C0423b(super.onSaveInstanceState());
        bVar.f3050Z = this.f3036T0;
        bVar.f3051a0 = this.f3041Y0;
        return bVar;
    }

    /* renamed from: p */
    public final void mo3382p() {
        ArrayList<C0422a> arrayList;
        int i = this.f3039W0;
        this.f3039W0 = i + 1;
        if (i == 0 && (arrayList = this.f3040X0) != null) {
            Iterator<C0422a> it = arrayList.iterator();
            while (it.hasNext()) {
                it.next().mo3399b(this);
            }
        }
    }

    /* renamed from: q */
    public final FloatingActionButton mo3383q() {
        View r = mo3384r();
        if (r instanceof FloatingActionButton) {
            return (FloatingActionButton) r;
        }
        return null;
    }

    /* JADX WARNING: Removed duplicated region for block: B:6:0x001e  */
    /* renamed from: r */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.view.View mo3384r() {
        /*
            r4 = this;
            android.view.ViewParent r0 = r4.getParent()
            boolean r0 = r0 instanceof androidx.coordinatorlayout.widget.CoordinatorLayout
            r1 = 0
            if (r0 != 0) goto L_0x000a
            return r1
        L_0x000a:
            android.view.ViewParent r0 = r4.getParent()
            androidx.coordinatorlayout.widget.CoordinatorLayout r0 = (androidx.coordinatorlayout.widget.CoordinatorLayout) r0
            java.util.List r0 = r0.mo1211c((android.view.View) r4)
            java.util.Iterator r0 = r0.iterator()
        L_0x0018:
            boolean r2 = r0.hasNext()
            if (r2 == 0) goto L_0x002d
            java.lang.Object r2 = r0.next()
            android.view.View r2 = (android.view.View) r2
            boolean r3 = r2 instanceof com.google.android.material.floatingactionbutton.FloatingActionButton
            if (r3 != 0) goto L_0x002c
            boolean r3 = r2 instanceof com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
            if (r3 == 0) goto L_0x0018
        L_0x002c:
            return r2
        L_0x002d:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.bottomappbar.BottomAppBar.mo3384r():android.view.View");
    }

    /* renamed from: s */
    public final boolean mo3385s() {
        FloatingActionButton q = mo3383q();
        return q != null && q.mo3729c();
    }

    public void setBackgroundTint(ColorStateList colorStateList) {
        C0815h0.m5802a((Drawable) this.f3033Q0, colorStateList);
    }

    public void setCradleVerticalOffset(float f) {
        if (f != getCradleVerticalOffset()) {
            getTopEdgeTreatment().f8912a0 = f;
            this.f3033Q0.invalidateSelf();
            mo3394t();
        }
    }

    public void setElevation(float f) {
        f73 f73 = this.f3033Q0;
        f73.C0668b bVar = f73.f5079X;
        if (bVar.f5115o != f) {
            bVar.f5115o = f;
            f73.mo5496l();
        }
        f73 f732 = this.f3033Q0;
        getBehavior().mo3351a(this, f732.f5079X.f5118r - f732.mo5483f());
    }

    public void setFabAlignmentMode(int i) {
        boolean z;
        int i2;
        if (this.f3036T0 != i && C2189w7.m15031z(this)) {
            Animator animator = this.f3034R0;
            if (animator != null) {
                animator.cancel();
            }
            ArrayList arrayList = new ArrayList();
            if (this.f3037U0 == 1) {
                ObjectAnimator ofFloat = ObjectAnimator.ofFloat(mo3383q(), "translationX", new float[]{mo3372d(i)});
                ofFloat.setDuration(300);
                arrayList.add(ofFloat);
            } else {
                mo3371c(i);
            }
            AnimatorSet animatorSet = new AnimatorSet();
            animatorSet.playTogether(arrayList);
            this.f3034R0 = animatorSet;
            this.f3034R0.addListener(new f43(this));
            this.f3034R0.start();
        }
        boolean z2 = this.f3041Y0;
        if (C2189w7.m15031z(this)) {
            Animator animator2 = this.f3035S0;
            if (animator2 != null) {
                animator2.cancel();
            }
            ArrayList arrayList2 = new ArrayList();
            if (!mo3385s()) {
                i2 = 0;
                z = false;
            } else {
                z = z2;
                i2 = i;
            }
            ActionMenuView actionMenuView = getActionMenuView();
            if (actionMenuView != null) {
                ObjectAnimator ofFloat2 = ObjectAnimator.ofFloat(actionMenuView, "alpha", new float[]{1.0f});
                if (Math.abs(actionMenuView.getTranslationX() - ((float) mo3370a(actionMenuView, i2, z))) > 1.0f) {
                    ObjectAnimator ofFloat3 = ObjectAnimator.ofFloat(actionMenuView, "alpha", new float[]{0.0f});
                    ofFloat3.addListener(new i43(this, actionMenuView, i2, z));
                    AnimatorSet animatorSet2 = new AnimatorSet();
                    animatorSet2.setDuration(150);
                    animatorSet2.playSequentially(new Animator[]{ofFloat3, ofFloat2});
                    arrayList2.add(animatorSet2);
                } else if (actionMenuView.getAlpha() < 1.0f) {
                    arrayList2.add(ofFloat2);
                }
            }
            AnimatorSet animatorSet3 = new AnimatorSet();
            animatorSet3.playTogether(arrayList2);
            this.f3035S0 = animatorSet3;
            this.f3035S0.addListener(new h43(this));
            this.f3035S0.start();
        }
        this.f3036T0 = i;
    }

    public void setFabAnimationMode(int i) {
        this.f3037U0 = i;
    }

    public void setFabCradleMargin(float f) {
        if (f != getFabCradleMargin()) {
            getTopEdgeTreatment().f8910Y = f;
            this.f3033Q0.invalidateSelf();
        }
    }

    public void setFabCradleRoundedCornerRadius(float f) {
        if (f != getFabCradleRoundedCornerRadius()) {
            getTopEdgeTreatment().f8909X = f;
            this.f3033Q0.invalidateSelf();
        }
    }

    public void setHideOnScroll(boolean z) {
        this.f3038V0 = z;
    }

    public void setSubtitle(CharSequence charSequence) {
    }

    public void setTitle(CharSequence charSequence) {
    }

    /* renamed from: t */
    public final void mo3394t() {
        getTopEdgeTreatment().f8913b0 = getFabTranslationX();
        View r = mo3384r();
        this.f3033Q0.mo5476b((!this.f3041Y0 || !mo3385s()) ? 0.0f : 1.0f);
        if (r != null) {
            r.setTranslationY(getFabTranslationY());
            r.setTranslationX(getFabTranslationX());
        }
    }

    /* renamed from: e */
    public boolean mo3373e(int i) {
        float f = (float) i;
        if (f == getTopEdgeTreatment().f8911Z) {
            return false;
        }
        getTopEdgeTreatment().f8911Z = f;
        this.f3033Q0.invalidateSelf();
        return true;
    }
}
