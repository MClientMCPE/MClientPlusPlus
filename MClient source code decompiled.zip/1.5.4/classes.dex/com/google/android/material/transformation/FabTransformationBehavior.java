package com.google.android.material.transformation;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Pair;
import android.util.Property;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.ViewGroup;
import android.widget.ImageView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;
import p000.u43;

public abstract class FabTransformationBehavior extends ExpandableTransformationBehavior {

    /* renamed from: c */
    public final Rect f3371c = new Rect();

    /* renamed from: d */
    public final RectF f3372d = new RectF();

    /* renamed from: e */
    public final RectF f3373e = new RectF();

    /* renamed from: f */
    public final int[] f3374f = new int[2];

    /* renamed from: g */
    public float f3375g;

    /* renamed from: h */
    public float f3376h;

    /* renamed from: com.google.android.material.transformation.FabTransformationBehavior$a */
    public class C0476a extends AnimatorListenerAdapter {

        /* renamed from: a */
        public final /* synthetic */ boolean f3377a;

        /* renamed from: b */
        public final /* synthetic */ View f3378b;

        /* renamed from: c */
        public final /* synthetic */ View f3379c;

        public C0476a(FabTransformationBehavior fabTransformationBehavior, boolean z, View view, View view2) {
            this.f3377a = z;
            this.f3378b = view;
            this.f3379c = view2;
        }

        public void onAnimationEnd(Animator animator) {
            if (!this.f3377a) {
                this.f3378b.setVisibility(4);
                this.f3379c.setAlpha(1.0f);
                this.f3379c.setVisibility(0);
            }
        }

        public void onAnimationStart(Animator animator) {
            if (this.f3377a) {
                this.f3378b.setVisibility(0);
                this.f3379c.setAlpha(0.0f);
                this.f3379c.setVisibility(4);
            }
        }
    }

    /* renamed from: com.google.android.material.transformation.FabTransformationBehavior$b */
    public static class C0477b {

        /* renamed from: a */
        public s33 f3380a;

        /* renamed from: b */
        public u33 f3381b;
    }

    public FabTransformationBehavior() {
    }

    public FabTransformationBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    /* renamed from: a */
    public final float mo4100a(View view, View view2, u33 u33) {
        float f;
        float f2;
        RectF rectF = this.f3372d;
        RectF rectF2 = this.f3373e;
        mo4106a(view, rectF);
        rectF.offset(this.f3375g, this.f3376h);
        mo4106a(view2, rectF2);
        float f3 = 0.0f;
        int i = u33.f15319a & 7;
        if (i == 1) {
            f2 = rectF2.centerX();
            f = rectF.centerX();
        } else if (i != 3) {
            if (i == 5) {
                f2 = rectF2.right;
                f = rectF.right;
            }
            return f3 + u33.f15320b;
        } else {
            f2 = rectF2.left;
            f = rectF.left;
        }
        f3 = f2 - f;
        return f3 + u33.f15320b;
    }

    /* renamed from: a */
    public final Pair<t33, t33> mo4102a(float f, float f2, boolean z, C0477b bVar) {
        String str;
        s33 s33;
        t33 t33;
        if (f == 0.0f || f2 == 0.0f) {
            t33 = bVar.f3380a.mo10841a("translationXLinear");
            s33 = bVar.f3380a;
            str = "translationYLinear";
        } else if ((!z || f2 >= 0.0f) && (z || f2 <= 0.0f)) {
            t33 = bVar.f3380a.mo10841a("translationXCurveDownwards");
            s33 = bVar.f3380a;
            str = "translationYCurveDownwards";
        } else {
            t33 = bVar.f3380a.mo10841a("translationXCurveUpwards");
            s33 = bVar.f3380a;
            str = "translationYCurveUpwards";
        }
        return new Pair<>(t33, s33.mo10841a(str));
    }

    /* renamed from: a */
    public final ViewGroup mo4103a(View view) {
        if (view instanceof ViewGroup) {
            return (ViewGroup) view;
        }
        return null;
    }

    /* renamed from: a */
    public abstract C0477b mo4104a(Context context, boolean z);

    /* renamed from: a */
    public final void mo4105a(View view, long j, int i, int i2, float f, List<Animator> list) {
        if (Build.VERSION.SDK_INT >= 21 && j > 0) {
            Animator createCircularReveal = ViewAnimationUtils.createCircularReveal(view, i, i2, f, f);
            createCircularReveal.setStartDelay(0);
            createCircularReveal.setDuration(j);
            list.add(createCircularReveal);
        }
    }

    /* renamed from: a */
    public final void mo4106a(View view, RectF rectF) {
        rectF.set(0.0f, 0.0f, (float) view.getWidth(), (float) view.getHeight());
        int[] iArr = this.f3374f;
        view.getLocationInWindow(iArr);
        rectF.offsetTo((float) iArr[0], (float) iArr[1]);
        rectF.offset((float) ((int) (-view.getTranslationX())), (float) ((int) (-view.getTranslationY())));
    }

    /* renamed from: a */
    public void mo1254a(CoordinatorLayout.C0177f fVar) {
        if (fVar.f1045h == 0) {
            fVar.f1045h = 80;
        }
    }

    /* renamed from: a */
    public boolean mo1267a(CoordinatorLayout coordinatorLayout, View view, View view2) {
        if (view.getVisibility() == 8) {
            throw new IllegalStateException("This behavior cannot be attached to a GONE view. Set the view to INVISIBLE instead.");
        } else if (!(view2 instanceof FloatingActionButton)) {
            return false;
        } else {
            int expandedComponentIdHint = ((FloatingActionButton) view2).getExpandedComponentIdHint();
            return expandedComponentIdHint == 0 || expandedComponentIdHint == view.getId();
        }
    }

    /* renamed from: b */
    public final float mo4110b(View view, View view2, u33 u33) {
        float f;
        float f2;
        RectF rectF = this.f3372d;
        RectF rectF2 = this.f3373e;
        mo4106a(view, rectF);
        rectF.offset(this.f3375g, this.f3376h);
        mo4106a(view2, rectF2);
        float f3 = 0.0f;
        int i = u33.f15319a & 112;
        if (i == 16) {
            f2 = rectF2.centerY();
            f = rectF.centerY();
        } else if (i != 48) {
            if (i == 80) {
                f2 = rectF2.bottom;
                f = rectF.bottom;
            }
            return f3 + u33.f15321c;
        } else {
            f2 = rectF2.top;
            f = rectF.top;
        }
        f3 = f2 - f;
        return f3 + u33.f15321c;
    }

    @TargetApi(21)
    /* renamed from: b */
    public final void mo4111b(View view, View view2, boolean z, boolean z2, C0477b bVar, List list) {
        ObjectAnimator objectAnimator;
        float i = C2189w7.m15014i(view2) - C2189w7.m15014i(view);
        if (z) {
            if (!z2) {
                view2.setTranslationZ(-i);
            }
            objectAnimator = ObjectAnimator.ofFloat(view2, View.TRANSLATION_Z, new float[]{0.0f});
        } else {
            objectAnimator = ObjectAnimator.ofFloat(view2, View.TRANSLATION_Z, new float[]{-i});
        }
        bVar.f3380a.mo10841a("elevation").mo11138a(objectAnimator);
        list.add(objectAnimator);
    }

    /* renamed from: a */
    public final float mo4101a(C0477b bVar, t33 t33, float f, float f2) {
        long j = t33.f14659a;
        long j2 = t33.f14660b;
        t33 a = bVar.f3380a.mo10841a("expansion");
        return m33.m9016a(f, f2, t33.mo11137a().getInterpolation(((float) (((a.f14659a + a.f14660b) + 17) - j)) / ((float) j2)));
    }

    /* renamed from: b */
    public AnimatorSet mo4098b(View view, View view2, boolean z, boolean z2) {
        ArrayList arrayList;
        C0477b bVar;
        u43 u43;
        ArrayList arrayList2;
        Animator animator;
        t33 t33;
        ObjectAnimator objectAnimator;
        View view3 = view;
        View view4 = view2;
        boolean z3 = z;
        C0477b a = mo4104a(view2.getContext(), z3);
        if (z3) {
            this.f3375g = view.getTranslationX();
            this.f3376h = view.getTranslationY();
        }
        ArrayList arrayList3 = new ArrayList();
        ArrayList arrayList4 = new ArrayList();
        if (Build.VERSION.SDK_INT >= 21) {
            mo4111b(view, view2, z, z2, a, arrayList3);
        }
        RectF rectF = this.f3372d;
        RectF rectF2 = rectF;
        mo4108a(view, view2, z, z2, a, arrayList3, rectF);
        float width = rectF2.width();
        float height = rectF2.height();
        float a2 = mo4100a(view3, view4, a.f3381b);
        float b = mo4110b(view3, view4, a.f3381b);
        Pair<t33, t33> a3 = mo4102a(a2, b, z3, a);
        t33 t332 = (t33) a3.first;
        t33 t333 = (t33) a3.second;
        Property property = View.TRANSLATION_X;
        float[] fArr = new float[1];
        if (!z3) {
            a2 = this.f3375g;
        }
        fArr[0] = a2;
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(view3, property, fArr);
        Property property2 = View.TRANSLATION_Y;
        float[] fArr2 = new float[1];
        if (!z3) {
            b = this.f3376h;
        }
        fArr2[0] = b;
        ObjectAnimator ofFloat2 = ObjectAnimator.ofFloat(view3, property2, fArr2);
        t332.mo11138a(ofFloat);
        t333.mo11138a(ofFloat2);
        arrayList3.add(ofFloat);
        arrayList3.add(ofFloat2);
        boolean z4 = view4 instanceof u43;
        if (z4 && (view3 instanceof ImageView)) {
            u43 u432 = (u43) view4;
            Drawable drawable = ((ImageView) view3).getDrawable();
            if (drawable != null) {
                drawable.mutate();
                if (z3) {
                    if (!z2) {
                        drawable.setAlpha(255);
                    }
                    objectAnimator = ObjectAnimator.ofInt(drawable, p33.f12238b, new int[]{0});
                } else {
                    objectAnimator = ObjectAnimator.ofInt(drawable, p33.f12238b, new int[]{255});
                }
                objectAnimator.addUpdateListener(new i83(this, view4));
                a.f3380a.mo10841a("iconFade").mo11138a(objectAnimator);
                arrayList3.add(objectAnimator);
                arrayList4.add(new j83(this, u432, drawable));
            }
        }
        if (!z4) {
            bVar = a;
            arrayList = arrayList4;
        } else {
            u43 u433 = (u43) view4;
            u33 u33 = a.f3381b;
            RectF rectF3 = this.f3372d;
            RectF rectF4 = this.f3373e;
            mo4106a(view3, rectF3);
            rectF3.offset(this.f3375g, this.f3376h);
            mo4106a(view4, rectF4);
            rectF4.offset(-mo4100a(view3, view4, u33), 0.0f);
            float centerX = rectF3.centerX() - rectF4.left;
            u33 u332 = a.f3381b;
            RectF rectF5 = this.f3372d;
            RectF rectF6 = this.f3373e;
            mo4106a(view3, rectF5);
            rectF5.offset(this.f3375g, this.f3376h);
            mo4106a(view4, rectF6);
            rectF6.offset(0.0f, -mo4110b(view3, view4, u332));
            float centerY = rectF5.centerY() - rectF6.top;
            ((FloatingActionButton) view3).mo3722a(this.f3371c);
            float width2 = ((float) this.f3371c.width()) / 2.0f;
            t33 a4 = a.f3380a.mo10841a("expansion");
            if (z3) {
                if (!z2) {
                    u433.setRevealInfo(new u43.C1979e(centerX, centerY, width2));
                }
                if (z2) {
                    width2 = u433.getRevealInfo().f15331c;
                }
                float a5 = t53.m13067a(centerX, centerY, 0.0f, 0.0f);
                float a6 = t53.m13067a(centerX, centerY, width, 0.0f);
                float a7 = t53.m13067a(centerX, centerY, width, height);
                float a8 = t53.m13067a(centerX, centerY, 0.0f, height);
                if (a5 > a6 && a5 > a7 && a5 > a8) {
                    a7 = a5;
                } else if (a6 > a7 && a6 > a8) {
                    a7 = a6;
                } else if (a7 <= a8) {
                    a7 = a8;
                }
                Animator a9 = C0680fe.m4675a(u433, centerX, centerY, a7);
                a9.addListener(new k83(this, u433));
                animator = a9;
                t33 = a4;
                mo4105a(view2, a4.f14659a, (int) centerX, (int) centerY, width2, (List<Animator>) arrayList3);
                bVar = a;
                arrayList2 = arrayList4;
                u43 = u433;
            } else {
                t33 = a4;
                float f = u433.getRevealInfo().f15331c;
                animator = C0680fe.m4675a(u433, centerX, centerY, width2);
                int i = (int) centerX;
                int i2 = (int) centerY;
                float f2 = width2;
                mo4105a(view2, t33.f14659a, i, i2, f, (List<Animator>) arrayList3);
                long j = t33.f14659a;
                long j2 = t33.f14660b;
                s33 s33 = a.f3380a;
                int i3 = s33.f13937a.f5965Z;
                bVar = a;
                long j3 = 0;
                int i4 = 0;
                while (i4 < i3) {
                    int i5 = i3;
                    t33 e = s33.f13937a.mo5982e(i4);
                    j3 = Math.max(j3, e.f14659a + e.f14660b);
                    i4++;
                    i3 = i5;
                    arrayList4 = arrayList4;
                    u433 = u433;
                    s33 = s33;
                }
                arrayList2 = arrayList4;
                u43 = u433;
                if (Build.VERSION.SDK_INT >= 21) {
                    long j4 = j + j2;
                    if (j4 < j3) {
                        Animator createCircularReveal = ViewAnimationUtils.createCircularReveal(view4, i, i2, f2, f2);
                        createCircularReveal.setStartDelay(j4);
                        createCircularReveal.setDuration(j3 - j4);
                        arrayList3.add(createCircularReveal);
                    }
                }
            }
            Animator animator2 = animator;
            t33.mo11138a(animator2);
            arrayList3.add(animator2);
            arrayList = arrayList2;
            arrayList.add(new r43(u43));
        }
        mo4107a(view, view2, z, z2, bVar, (List) arrayList3);
        mo4109a(view2, z, z2, bVar, arrayList3);
        AnimatorSet animatorSet = new AnimatorSet();
        C0680fe.m4737a(animatorSet, (List<Animator>) arrayList3);
        animatorSet.addListener(new C0476a(this, z, view4, view));
        int size = arrayList.size();
        for (int i6 = 0; i6 < size; i6++) {
            animatorSet.addListener((Animator.AnimatorListener) arrayList.get(i6));
        }
        return animatorSet;
    }

    /* renamed from: a */
    public final void mo4109a(View view, boolean z, boolean z2, C0477b bVar, List list) {
        ViewGroup viewGroup;
        ObjectAnimator objectAnimator;
        if (view instanceof ViewGroup) {
            if (!(view instanceof u43) || t43.f14677a != 0) {
                View findViewById = view.findViewById(f33.mtrl_child_content_container);
                if (findViewById != null) {
                    viewGroup = mo4103a(findViewById);
                } else {
                    if ((view instanceof m83) || (view instanceof l83)) {
                        view = ((ViewGroup) view).getChildAt(0);
                    }
                    viewGroup = mo4103a(view);
                }
                if (viewGroup != null) {
                    if (z) {
                        if (!z2) {
                            o33.f11675a.set(viewGroup, Float.valueOf(0.0f));
                        }
                        objectAnimator = ObjectAnimator.ofFloat(viewGroup, o33.f11675a, new float[]{1.0f});
                    } else {
                        objectAnimator = ObjectAnimator.ofFloat(viewGroup, o33.f11675a, new float[]{0.0f});
                    }
                    bVar.f3380a.mo10841a("contentFade").mo11138a(objectAnimator);
                    list.add(objectAnimator);
                }
            }
        }
    }

    /* renamed from: a */
    public final void mo4107a(View view, View view2, boolean z, boolean z2, C0477b bVar, List list) {
        ObjectAnimator objectAnimator;
        if (view2 instanceof u43) {
            u43 u43 = (u43) view2;
            ColorStateList f = C2189w7.m15008f(view);
            int colorForState = f != null ? f.getColorForState(view.getDrawableState(), f.getDefaultColor()) : 0;
            int i = 16777215 & colorForState;
            if (z) {
                if (!z2) {
                    u43.setCircularRevealScrimColor(colorForState);
                }
                objectAnimator = ObjectAnimator.ofInt(u43, u43.C1978d.f15328a, new int[]{i});
            } else {
                objectAnimator = ObjectAnimator.ofInt(u43, u43.C1978d.f15328a, new int[]{colorForState});
            }
            objectAnimator.setEvaluator(n33.f10884a);
            bVar.f3380a.mo10841a("color").mo11138a(objectAnimator);
            list.add(objectAnimator);
        }
    }

    /* renamed from: a */
    public final void mo4108a(View view, View view2, boolean z, boolean z2, C0477b bVar, List list, RectF rectF) {
        ObjectAnimator objectAnimator;
        ObjectAnimator objectAnimator2;
        float a = mo4100a(view, view2, bVar.f3381b);
        float b = mo4110b(view, view2, bVar.f3381b);
        Pair<t33, t33> a2 = mo4102a(a, b, z, bVar);
        t33 t33 = (t33) a2.first;
        t33 t332 = (t33) a2.second;
        if (z) {
            if (!z2) {
                view2.setTranslationX(-a);
                view2.setTranslationY(-b);
            }
            objectAnimator2 = ObjectAnimator.ofFloat(view2, View.TRANSLATION_X, new float[]{0.0f});
            objectAnimator = ObjectAnimator.ofFloat(view2, View.TRANSLATION_Y, new float[]{0.0f});
            float a3 = mo4101a(bVar, t33, -a, 0.0f);
            float a4 = mo4101a(bVar, t332, -b, 0.0f);
            Rect rect = this.f3371c;
            view2.getWindowVisibleDisplayFrame(rect);
            RectF rectF2 = this.f3372d;
            rectF2.set(rect);
            RectF rectF3 = this.f3373e;
            mo4106a(view2, rectF3);
            rectF3.offset(a3, a4);
            rectF3.intersect(rectF2);
            rectF.set(rectF3);
        } else {
            objectAnimator2 = ObjectAnimator.ofFloat(view2, View.TRANSLATION_X, new float[]{-a});
            objectAnimator = ObjectAnimator.ofFloat(view2, View.TRANSLATION_Y, new float[]{-b});
        }
        t33.mo11138a(objectAnimator2);
        t332.mo11138a(objectAnimator);
        list.add(objectAnimator2);
        list.add(objectAnimator);
    }
}
