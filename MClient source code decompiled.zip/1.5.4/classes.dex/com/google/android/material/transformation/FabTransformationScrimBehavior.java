package com.google.android.material.transformation;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import java.util.List;

public class FabTransformationScrimBehavior extends ExpandableTransformationBehavior {

    /* renamed from: c */
    public final t33 f3382c = new t33(75, 150);

    /* renamed from: d */
    public final t33 f3383d = new t33(0, 150);

    /* renamed from: com.google.android.material.transformation.FabTransformationScrimBehavior$a */
    public class C0478a extends AnimatorListenerAdapter {

        /* renamed from: a */
        public final /* synthetic */ boolean f3384a;

        /* renamed from: b */
        public final /* synthetic */ View f3385b;

        public C0478a(FabTransformationScrimBehavior fabTransformationScrimBehavior, boolean z, View view) {
            this.f3384a = z;
            this.f3385b = view;
        }

        public void onAnimationEnd(Animator animator) {
            if (!this.f3384a) {
                this.f3385b.setVisibility(4);
            }
        }

        public void onAnimationStart(Animator animator) {
            if (this.f3384a) {
                this.f3385b.setVisibility(0);
            }
        }
    }

    public FabTransformationScrimBehavior() {
    }

    public FabTransformationScrimBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    /* renamed from: a */
    public final void mo4114a(View view, boolean z, boolean z2, List list) {
        ObjectAnimator objectAnimator;
        t33 t33 = z ? this.f3382c : this.f3383d;
        if (z) {
            if (!z2) {
                view.setAlpha(0.0f);
            }
            objectAnimator = ObjectAnimator.ofFloat(view, View.ALPHA, new float[]{1.0f});
        } else {
            objectAnimator = ObjectAnimator.ofFloat(view, View.ALPHA, new float[]{0.0f});
        }
        t33.mo11138a(objectAnimator);
        list.add(objectAnimator);
    }

    /* renamed from: a */
    public boolean mo1267a(CoordinatorLayout coordinatorLayout, View view, View view2) {
        return view2 instanceof FloatingActionButton;
    }

    /* renamed from: b */
    public AnimatorSet mo4098b(View view, View view2, boolean z, boolean z2) {
        ArrayList arrayList = new ArrayList();
        new ArrayList();
        mo4114a(view2, z, z2, arrayList);
        AnimatorSet animatorSet = new AnimatorSet();
        C0680fe.m4737a(animatorSet, (List<Animator>) arrayList);
        animatorSet.addListener(new C0478a(this, z, view2));
        return animatorSet;
    }

    /* renamed from: b */
    public boolean mo1272b(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
        return false;
    }
}
