package com.google.android.material.transformation;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewTreeObserver;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import java.util.List;

public abstract class ExpandableBehavior extends CoordinatorLayout.C0174c<View> {

    /* renamed from: a */
    public int f3364a = 0;

    /* renamed from: com.google.android.material.transformation.ExpandableBehavior$a */
    public class C0474a implements ViewTreeObserver.OnPreDrawListener {

        /* renamed from: X */
        public final /* synthetic */ View f3365X;

        /* renamed from: Y */
        public final /* synthetic */ int f3366Y;

        /* renamed from: Z */
        public final /* synthetic */ y53 f3367Z;

        public C0474a(View view, int i, y53 y53) {
            this.f3365X = view;
            this.f3366Y = i;
            this.f3367Z = y53;
        }

        public boolean onPreDraw() {
            this.f3365X.getViewTreeObserver().removeOnPreDrawListener(this);
            ExpandableBehavior expandableBehavior = ExpandableBehavior.this;
            if (expandableBehavior.f3364a == this.f3366Y) {
                y53 y53 = this.f3367Z;
                expandableBehavior.mo4094a((View) y53, this.f3365X, y53.mo3721a(), false);
            }
            return false;
        }
    }

    public ExpandableBehavior() {
    }

    public ExpandableBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    /* renamed from: a */
    public abstract boolean mo4094a(View view, View view2, boolean z, boolean z2);

    /* renamed from: a */
    public boolean mo203a(CoordinatorLayout coordinatorLayout, View view, int i) {
        y53 c;
        if (C2189w7.m15031z(view) || (c = mo4096c(coordinatorLayout, view)) == null || !mo4095a(c.mo3721a())) {
            return false;
        }
        this.f3364a = c.mo3721a() ? 1 : 2;
        view.getViewTreeObserver().addOnPreDrawListener(new C0474a(view, this.f3364a, c));
        return false;
    }

    /* renamed from: a */
    public final boolean mo4095a(boolean z) {
        if (!z) {
            return this.f3364a == 1;
        }
        int i = this.f3364a;
        return i == 0 || i == 2;
    }

    /* renamed from: b */
    public boolean mo1273b(CoordinatorLayout coordinatorLayout, View view, View view2) {
        y53 y53 = (y53) view2;
        if (!mo4095a(y53.mo3721a())) {
            return false;
        }
        this.f3364a = y53.mo3721a() ? 1 : 2;
        return mo4094a((View) y53, view, y53.mo3721a(), true);
    }

    /* renamed from: c */
    public y53 mo4096c(CoordinatorLayout coordinatorLayout, View view) {
        List<View> b = coordinatorLayout.mo1206b(view);
        int size = b.size();
        for (int i = 0; i < size; i++) {
            View view2 = b.get(i);
            if (mo1267a(coordinatorLayout, view, view2)) {
                return (y53) view2;
            }
        }
        return null;
    }
}
