package com.google.android.material.transformation;

import android.content.Context;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewParent;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.transformation.FabTransformationBehavior;
import java.util.HashMap;
import java.util.Map;

public class FabTransformationSheetBehavior extends FabTransformationBehavior {

    /* renamed from: i */
    public Map<View, Integer> f3386i;

    public FabTransformationSheetBehavior() {
    }

    public FabTransformationSheetBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    /* renamed from: a */
    public FabTransformationBehavior.C0477b mo4104a(Context context, boolean z) {
        int i = z ? a33.mtrl_fab_transformation_sheet_expand_spec : a33.mtrl_fab_transformation_sheet_collapse_spec;
        FabTransformationBehavior.C0477b bVar = new FabTransformationBehavior.C0477b();
        bVar.f3380a = s33.m12445a(context, i);
        bVar.f3381b = new u33(17, 0.0f, 0.0f);
        return bVar;
    }

    /* renamed from: a */
    public boolean mo4094a(View view, View view2, boolean z, boolean z2) {
        int i;
        ViewParent parent = view2.getParent();
        if (parent instanceof CoordinatorLayout) {
            CoordinatorLayout coordinatorLayout = (CoordinatorLayout) parent;
            int childCount = coordinatorLayout.getChildCount();
            int i2 = Build.VERSION.SDK_INT;
            if (z) {
                this.f3386i = new HashMap(childCount);
            }
            for (int i3 = 0; i3 < childCount; i3++) {
                View childAt = coordinatorLayout.getChildAt(i3);
                boolean z3 = (childAt.getLayoutParams() instanceof CoordinatorLayout.C0177f) && (((CoordinatorLayout.C0177f) childAt.getLayoutParams()).f1038a instanceof FabTransformationScrimBehavior);
                if (childAt != view2 && !z3) {
                    if (!z) {
                        Map<View, Integer> map = this.f3386i;
                        if (map != null && map.containsKey(childAt)) {
                            i = this.f3386i.get(childAt).intValue();
                        }
                    } else {
                        int i4 = Build.VERSION.SDK_INT;
                        this.f3386i.put(childAt, Integer.valueOf(childAt.getImportantForAccessibility()));
                        i = 4;
                    }
                    C2189w7.m15013h(childAt, i);
                }
            }
            if (!z) {
                this.f3386i = null;
            }
        }
        super.mo4094a(view, view2, z, z2);
        return true;
    }
}
