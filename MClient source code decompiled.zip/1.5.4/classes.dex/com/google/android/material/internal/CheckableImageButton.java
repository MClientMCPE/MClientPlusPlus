package com.google.android.material.internal;

import android.content.Context;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Checkable;
import android.widget.ImageButton;

public class CheckableImageButton extends C0983j2 implements Checkable {

    /* renamed from: f0 */
    public static final int[] f3182f0 = {16842912};

    /* renamed from: c0 */
    public boolean f3183c0;

    /* renamed from: d0 */
    public boolean f3184d0;

    /* renamed from: e0 */
    public boolean f3185e0;

    /* renamed from: com.google.android.material.internal.CheckableImageButton$a */
    public class C0448a extends C0757g7 {
        public C0448a() {
            super(C0757g7.f6013c);
        }

        /* renamed from: a */
        public void mo1378a(View view, C0759g8 g8Var) {
            this.f6014a.onInitializeAccessibilityNodeInfo(view, g8Var.f6028a);
            g8Var.f6028a.setCheckable(CheckableImageButton.this.mo3807a());
            g8Var.f6028a.setChecked(CheckableImageButton.this.isChecked());
        }

        /* renamed from: b */
        public void mo1380b(View view, AccessibilityEvent accessibilityEvent) {
            this.f6014a.onInitializeAccessibilityEvent(view, accessibilityEvent);
            accessibilityEvent.setChecked(CheckableImageButton.this.isChecked());
        }
    }

    /* renamed from: com.google.android.material.internal.CheckableImageButton$b */
    public static class C0449b extends C1904t8 {
        public static final Parcelable.Creator<C0449b> CREATOR = new C0450a();

        /* renamed from: Z */
        public boolean f3187Z;

        /* renamed from: com.google.android.material.internal.CheckableImageButton$b$a */
        public static class C0450a implements Parcelable.ClassLoaderCreator<C0449b> {
            public Object createFromParcel(Parcel parcel) {
                return new C0449b(parcel, (ClassLoader) null);
            }

            public Object[] newArray(int i) {
                return new C0449b[i];
            }

            public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new C0449b(parcel, classLoader);
            }
        }

        public C0449b(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f3187Z = parcel.readInt() != 1 ? false : true;
        }

        public C0449b(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeParcelable(this.f14707X, i);
            parcel.writeInt(this.f3187Z ? 1 : 0);
        }
    }

    public CheckableImageButton(Context context) {
        this(context, (AttributeSet) null);
    }

    public CheckableImageButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0502d.imageButtonStyle);
    }

    public CheckableImageButton(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f3184d0 = true;
        this.f3185e0 = true;
        C2189w7.m14988a((View) this, (C0757g7) new C0448a());
    }

    /* renamed from: a */
    public boolean mo3807a() {
        return this.f3184d0;
    }

    public boolean isChecked() {
        return this.f3183c0;
    }

    public int[] onCreateDrawableState(int i) {
        return this.f3183c0 ? ImageButton.mergeDrawableStates(super.onCreateDrawableState(i + f3182f0.length), f3182f0) : super.onCreateDrawableState(i);
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof C0449b)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        C0449b bVar = (C0449b) parcelable;
        super.onRestoreInstanceState(bVar.f14707X);
        setChecked(bVar.f3187Z);
    }

    public Parcelable onSaveInstanceState() {
        C0449b bVar = new C0449b(super.onSaveInstanceState());
        bVar.f3187Z = this.f3183c0;
        return bVar;
    }

    public void setCheckable(boolean z) {
        if (this.f3184d0 != z) {
            this.f3184d0 = z;
            sendAccessibilityEvent(0);
        }
    }

    public void setChecked(boolean z) {
        if (this.f3184d0 && this.f3183c0 != z) {
            this.f3183c0 = z;
            refreshDrawableState();
            sendAccessibilityEvent(2048);
        }
    }

    public void setPressable(boolean z) {
        this.f3185e0 = z;
    }

    public void setPressed(boolean z) {
        if (this.f3185e0) {
            super.setPressed(z);
        }
    }

    public void toggle() {
        setChecked(!this.f3183c0);
    }
}
