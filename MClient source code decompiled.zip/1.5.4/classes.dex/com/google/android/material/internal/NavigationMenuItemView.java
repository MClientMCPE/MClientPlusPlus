package com.google.android.material.internal;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStub;
import android.widget.CheckedTextView;
import android.widget.FrameLayout;
import p000.C0639f3;
import p000.C1655q1;

public class NavigationMenuItemView extends l63 implements C1655q1.C1656a {

    /* renamed from: F0 */
    public static final int[] f3188F0 = {16842912};

    /* renamed from: A0 */
    public C1115k1 f3189A0;

    /* renamed from: B0 */
    public ColorStateList f3190B0;

    /* renamed from: C0 */
    public boolean f3191C0;

    /* renamed from: D0 */
    public Drawable f3192D0;

    /* renamed from: E0 */
    public final C0757g7 f3193E0;

    /* renamed from: v0 */
    public int f3194v0;

    /* renamed from: w0 */
    public boolean f3195w0;

    /* renamed from: x0 */
    public boolean f3196x0;

    /* renamed from: y0 */
    public final CheckedTextView f3197y0;

    /* renamed from: z0 */
    public FrameLayout f3198z0;

    /* renamed from: com.google.android.material.internal.NavigationMenuItemView$a */
    public class C0451a extends C0757g7 {
        public C0451a() {
            super(C0757g7.f6013c);
        }

        /* renamed from: a */
        public void mo1378a(View view, C0759g8 g8Var) {
            this.f6014a.onInitializeAccessibilityNodeInfo(view, g8Var.f6028a);
            g8Var.f6028a.setCheckable(NavigationMenuItemView.this.f3196x0);
        }
    }

    public NavigationMenuItemView(Context context) {
        this(context, (AttributeSet) null);
    }

    public NavigationMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public NavigationMenuItemView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f3193E0 = new C0451a();
        setOrientation(0);
        LayoutInflater.from(context).inflate(h33.design_navigation_menu_item, this, true);
        setIconSize(context.getResources().getDimensionPixelSize(d33.design_navigation_icon_size));
        this.f3197y0 = (CheckedTextView) findViewById(f33.design_menu_item_text);
        this.f3197y0.setDuplicateParentStateEnabled(true);
        C2189w7.m14988a((View) this.f3197y0, this.f3193E0);
    }

    private void setActionView(View view) {
        if (view != null) {
            if (this.f3198z0 == null) {
                this.f3198z0 = (FrameLayout) ((ViewStub) findViewById(f33.design_menu_item_action_area_stub)).inflate();
            }
            this.f3198z0.removeAllViews();
            this.f3198z0.addView(view);
        }
    }

    /* renamed from: a */
    public void mo716a(C1115k1 k1Var, int i) {
        int i2;
        C0639f3.C0640a aVar;
        StateListDrawable stateListDrawable;
        this.f3189A0 = k1Var;
        setVisibility(k1Var.isVisible() ? 0 : 8);
        boolean z = true;
        if (getBackground() == null) {
            TypedValue typedValue = new TypedValue();
            if (getContext().getTheme().resolveAttribute(C0502d.colorControlHighlight, typedValue, true)) {
                stateListDrawable = new StateListDrawable();
                stateListDrawable.addState(f3188F0, new ColorDrawable(typedValue.data));
                stateListDrawable.addState(ViewGroup.EMPTY_STATE_SET, new ColorDrawable(0));
            } else {
                stateListDrawable = null;
            }
            C2189w7.m14987a((View) this, (Drawable) stateListDrawable);
        }
        setCheckable(k1Var.isCheckable());
        setChecked(k1Var.isChecked());
        setEnabled(k1Var.isEnabled());
        setTitle(k1Var.f8787e);
        setIcon(k1Var.getIcon());
        setActionView(k1Var.getActionView());
        setContentDescription(k1Var.f8800r);
        C0815h0.m5806a((View) this, k1Var.f8801s);
        C1115k1 k1Var2 = this.f3189A0;
        if (!(k1Var2.f8787e == null && k1Var2.getIcon() == null && this.f3189A0.getActionView() != null)) {
            z = false;
        }
        if (z) {
            this.f3197y0.setVisibility(8);
            FrameLayout frameLayout = this.f3198z0;
            if (frameLayout != null) {
                aVar = (C0639f3.C0640a) frameLayout.getLayoutParams();
                i2 = -1;
            } else {
                return;
            }
        } else {
            this.f3197y0.setVisibility(0);
            FrameLayout frameLayout2 = this.f3198z0;
            if (frameLayout2 != null) {
                aVar = (C0639f3.C0640a) frameLayout2.getLayoutParams();
                i2 = -2;
            } else {
                return;
            }
        }
        aVar.width = i2;
        this.f3198z0.setLayoutParams(aVar);
    }

    public C1115k1 getItemData() {
        return this.f3189A0;
    }

    /* renamed from: i */
    public boolean mo718i() {
        return false;
    }

    public int[] onCreateDrawableState(int i) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i + 1);
        C1115k1 k1Var = this.f3189A0;
        if (k1Var != null && k1Var.isCheckable() && this.f3189A0.isChecked()) {
            ViewGroup.mergeDrawableStates(onCreateDrawableState, f3188F0);
        }
        return onCreateDrawableState;
    }

    public void setCheckable(boolean z) {
        refreshDrawableState();
        if (this.f3196x0 != z) {
            this.f3196x0 = z;
            this.f3193E0.mo6018a((View) this.f3197y0, 2048);
        }
    }

    public void setChecked(boolean z) {
        refreshDrawableState();
        this.f3197y0.setChecked(z);
    }

    public void setHorizontalPadding(int i) {
        setPadding(i, 0, i, 0);
    }

    public void setIcon(Drawable drawable) {
        if (drawable != null) {
            if (this.f3191C0) {
                Drawable.ConstantState constantState = drawable.getConstantState();
                if (constantState != null) {
                    drawable = constantState.newDrawable();
                }
                drawable = C0815h0.m5858e(drawable).mutate();
                C0815h0.m5802a(drawable, this.f3190B0);
            }
            int i = this.f3194v0;
            drawable.setBounds(0, 0, i, i);
        } else if (this.f3195w0) {
            if (this.f3192D0 == null) {
                Resources resources = getResources();
                int i2 = e33.navigation_empty_icon;
                this.f3192D0 = Build.VERSION.SDK_INT >= 21 ? resources.getDrawable(i2, getContext().getTheme()) : resources.getDrawable(i2);
                Drawable drawable2 = this.f3192D0;
                if (drawable2 != null) {
                    int i3 = this.f3194v0;
                    drawable2.setBounds(0, 0, i3, i3);
                }
            }
            drawable = this.f3192D0;
        }
        CheckedTextView checkedTextView = this.f3197y0;
        int i4 = Build.VERSION.SDK_INT;
        checkedTextView.setCompoundDrawablesRelative(drawable, (Drawable) null, (Drawable) null, (Drawable) null);
    }

    public void setIconPadding(int i) {
        this.f3197y0.setCompoundDrawablePadding(i);
    }

    public void setIconSize(int i) {
        this.f3194v0 = i;
    }

    public void setIconTintList(ColorStateList colorStateList) {
        this.f3190B0 = colorStateList;
        this.f3191C0 = this.f3190B0 != null;
        C1115k1 k1Var = this.f3189A0;
        if (k1Var != null) {
            setIcon(k1Var.getIcon());
        }
    }

    public void setMaxLines(int i) {
        this.f3197y0.setMaxLines(i);
    }

    public void setNeedsEmptyIcon(boolean z) {
        this.f3195w0 = z;
    }

    public void setTextAppearance(int i) {
        C0815h0.m5857d(this.f3197y0, i);
    }

    public void setTextColor(ColorStateList colorStateList) {
        this.f3197y0.setTextColor(colorStateList);
    }

    public void setTitle(CharSequence charSequence) {
        this.f3197y0.setText(charSequence);
    }
}
