package com.google.android.material.button;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Button;
import android.widget.Checkable;
import android.widget.CompoundButton;
import android.widget.TextView;
import java.util.Iterator;
import java.util.LinkedHashSet;
import p000.f73;

public class MaterialButton extends C0507d2 implements Checkable, m73 {

    /* renamed from: n0 */
    public static final int[] f3105n0 = {16842911};

    /* renamed from: o0 */
    public static final int[] f3106o0 = {16842912};

    /* renamed from: p0 */
    public static final int f3107p0 = k33.Widget_MaterialComponents_Button;

    /* renamed from: c0 */
    public final m43 f3108c0;

    /* renamed from: d0 */
    public final LinkedHashSet<C0433a> f3109d0;

    /* renamed from: e0 */
    public PorterDuff.Mode f3110e0;

    /* renamed from: f0 */
    public ColorStateList f3111f0;

    /* renamed from: g0 */
    public Drawable f3112g0;

    /* renamed from: h0 */
    public int f3113h0;

    /* renamed from: i0 */
    public int f3114i0;

    /* renamed from: j0 */
    public int f3115j0;

    /* renamed from: k0 */
    public boolean f3116k0;

    /* renamed from: l0 */
    public boolean f3117l0;

    /* renamed from: m0 */
    public int f3118m0;

    /* renamed from: com.google.android.material.button.MaterialButton$a */
    public interface C0433a {
        /* renamed from: a */
        void mo3496a(MaterialButton materialButton, boolean z);
    }

    /* renamed from: com.google.android.material.button.MaterialButton$b */
    public interface C0434b {
    }

    public MaterialButton(Context context) {
        this(context, (AttributeSet) null);
    }

    public MaterialButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, b33.materialButtonStyle);
    }

    public MaterialButton(Context context, AttributeSet attributeSet, int i) {
        super(o63.m10327b(context, attributeSet, i, f3107p0), attributeSet, i);
        this.f3109d0 = new LinkedHashSet<>();
        boolean z = false;
        this.f3116k0 = false;
        this.f3117l0 = false;
        Context context2 = getContext();
        TypedArray b = o63.m10328b(context2, attributeSet, l33.MaterialButton, i, f3107p0, new int[0]);
        this.f3115j0 = b.getDimensionPixelSize(l33.MaterialButton_iconPadding, 0);
        this.f3110e0 = t53.m13079a(b.getInt(l33.MaterialButton_iconTintMode, -1), PorterDuff.Mode.SRC_IN);
        this.f3111f0 = t53.m13077a(getContext(), b, l33.MaterialButton_iconTint);
        this.f3112g0 = t53.m13122b(getContext(), b, l33.MaterialButton_icon);
        this.f3118m0 = b.getInteger(l33.MaterialButton_iconGravity, 1);
        this.f3113h0 = b.getDimensionPixelSize(l33.MaterialButton_iconSize, 0);
        this.f3108c0 = new m43(this, j73.m7354a(context2, attributeSet, i, f3107p0).mo7445a());
        this.f3108c0.mo8575a(b);
        b.recycle();
        setCompoundDrawablePadding(this.f3115j0);
        mo3439a(this.f3112g0 != null ? true : z);
    }

    private String getA11yClassName() {
        return (mo3440a() ? CompoundButton.class : Button.class).getName();
    }

    /* renamed from: a */
    public boolean mo3440a() {
        m43 m43 = this.f3108c0;
        return m43 != null && m43.f10007q;
    }

    /* renamed from: b */
    public final boolean mo3441b() {
        m43 m43 = this.f3108c0;
        return m43 != null && !m43.f10005o;
    }

    /* renamed from: c */
    public final void mo3442c() {
        if (this.f3112g0 != null && getLayout() != null) {
            int i = this.f3118m0;
            boolean z = true;
            if (i == 1 || i == 3) {
                this.f3114i0 = 0;
                mo3439a(false);
                return;
            }
            TextPaint paint = getPaint();
            String charSequence = getText().toString();
            if (getTransformationMethod() != null) {
                charSequence = getTransformationMethod().getTransformation(charSequence, this).toString();
            }
            int min = Math.min((int) paint.measureText(charSequence), getLayout().getEllipsizedWidth());
            int i2 = this.f3113h0;
            if (i2 == 0) {
                i2 = this.f3112g0.getIntrinsicWidth();
            }
            int measuredWidth = (((((getMeasuredWidth() - min) - C2189w7.m15022q(this)) - i2) - this.f3115j0) - C2189w7.m15023r(this)) / 2;
            boolean z2 = C2189w7.m15018m(this) == 1;
            if (this.f3118m0 != 4) {
                z = false;
            }
            if (z2 != z) {
                measuredWidth = -measuredWidth;
            }
            if (this.f3114i0 != measuredWidth) {
                this.f3114i0 = measuredWidth;
                mo3439a(false);
            }
        }
    }

    public ColorStateList getBackgroundTintList() {
        return getSupportBackgroundTintList();
    }

    public PorterDuff.Mode getBackgroundTintMode() {
        return getSupportBackgroundTintMode();
    }

    public int getCornerRadius() {
        if (mo3441b()) {
            return this.f3108c0.f9997g;
        }
        return 0;
    }

    public Drawable getIcon() {
        return this.f3112g0;
    }

    public int getIconGravity() {
        return this.f3118m0;
    }

    public int getIconPadding() {
        return this.f3115j0;
    }

    public int getIconSize() {
        return this.f3113h0;
    }

    public ColorStateList getIconTint() {
        return this.f3111f0;
    }

    public PorterDuff.Mode getIconTintMode() {
        return this.f3110e0;
    }

    public ColorStateList getRippleColor() {
        if (mo3441b()) {
            return this.f3108c0.f10002l;
        }
        return null;
    }

    public j73 getShapeAppearanceModel() {
        if (mo3441b()) {
            return this.f3108c0.f9992b;
        }
        throw new IllegalStateException("Attempted to get ShapeAppearanceModel from a MaterialButton which has an overwritten background.");
    }

    public ColorStateList getStrokeColor() {
        if (mo3441b()) {
            return this.f3108c0.f10001k;
        }
        return null;
    }

    public int getStrokeWidth() {
        if (mo3441b()) {
            return this.f3108c0.f9998h;
        }
        return 0;
    }

    public ColorStateList getSupportBackgroundTintList() {
        if (mo3441b()) {
            return this.f3108c0.f10000j;
        }
        return super.getSupportBackgroundTintList();
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        if (mo3441b()) {
            return this.f3108c0.f9999i;
        }
        return super.getSupportBackgroundTintMode();
    }

    public boolean isChecked() {
        return this.f3116k0;
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        t53.m13106a((View) this, this.f3108c0.mo8577b());
    }

    public int[] onCreateDrawableState(int i) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i + 2);
        if (mo3440a()) {
            Button.mergeDrawableStates(onCreateDrawableState, f3105n0);
        }
        if (isChecked()) {
            Button.mergeDrawableStates(onCreateDrawableState, f3106o0);
        }
        return onCreateDrawableState;
    }

    public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        super.onInitializeAccessibilityEvent(accessibilityEvent);
        accessibilityEvent.setClassName(getA11yClassName());
        accessibilityEvent.setChecked(isChecked());
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(getA11yClassName());
        accessibilityNodeInfo.setCheckable(mo3440a());
        accessibilityNodeInfo.setChecked(isChecked());
        accessibilityNodeInfo.setClickable(isClickable());
    }

    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        m43 m43;
        super.onLayout(z, i, i2, i3, i4);
        if (Build.VERSION.SDK_INT == 21 && (m43 = this.f3108c0) != null) {
            int i5 = i4 - i2;
            int i6 = i3 - i;
            Drawable drawable = m43.f10003m;
            if (drawable != null) {
                drawable.setBounds(m43.f9993c, m43.f9995e, i6 - m43.f9994d, i5 - m43.f9996f);
            }
        }
    }

    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        mo3442c();
    }

    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        super.onTextChanged(charSequence, i, i2, i3);
        mo3442c();
    }

    public boolean performClick() {
        toggle();
        return super.performClick();
    }

    public void setBackground(Drawable drawable) {
        setBackgroundDrawable(drawable);
    }

    public void setBackgroundColor(int i) {
        if (mo3441b()) {
            m43 m43 = this.f3108c0;
            if (m43.mo8577b() != null) {
                m43.mo8577b().setTint(i);
                return;
            }
            return;
        }
        super.setBackgroundColor(i);
    }

    public void setBackgroundDrawable(Drawable drawable) {
        if (mo3441b()) {
            if (drawable != getBackground()) {
                Log.w("MaterialButton", "Do not set the background; MaterialButton manages its own background drawable.");
                m43 m43 = this.f3108c0;
                m43.f10005o = true;
                m43.f9991a.setSupportBackgroundTintList(m43.f10000j);
                m43.f9991a.setSupportBackgroundTintMode(m43.f9999i);
            } else {
                getBackground().setState(drawable.getState());
                return;
            }
        }
        super.setBackgroundDrawable(drawable);
    }

    public void setBackgroundResource(int i) {
        setBackgroundDrawable(i != 0 ? C1206l0.m8461c(getContext(), i) : null);
    }

    public void setBackgroundTintList(ColorStateList colorStateList) {
        setSupportBackgroundTintList(colorStateList);
    }

    public void setBackgroundTintMode(PorterDuff.Mode mode) {
        setSupportBackgroundTintMode(mode);
    }

    public void setCheckable(boolean z) {
        if (mo3441b()) {
            this.f3108c0.f10007q = z;
        }
    }

    public void setChecked(boolean z) {
        if (mo3440a() && isEnabled() && this.f3116k0 != z) {
            this.f3116k0 = z;
            refreshDrawableState();
            if (!this.f3117l0) {
                this.f3117l0 = true;
                Iterator it = this.f3109d0.iterator();
                while (it.hasNext()) {
                    ((C0433a) it.next()).mo3496a(this, this.f3116k0);
                }
                this.f3117l0 = false;
            }
        }
    }

    public void setCornerRadius(int i) {
        if (mo3441b()) {
            m43 m43 = this.f3108c0;
            if (!m43.f10006p || m43.f9997g != i) {
                m43.f9997g = i;
                m43.f10006p = true;
                m43.mo8576a(m43.f9992b.mo7439a((float) i));
            }
        }
    }

    public void setCornerRadiusResource(int i) {
        if (mo3441b()) {
            setCornerRadius(getResources().getDimensionPixelSize(i));
        }
    }

    public void setElevation(float f) {
        super.setElevation(f);
        if (mo3441b()) {
            f73 b = this.f3108c0.mo8577b();
            f73.C0668b bVar = b.f5079X;
            if (bVar.f5115o != f) {
                bVar.f5115o = f;
                b.mo5496l();
            }
        }
    }

    public void setIcon(Drawable drawable) {
        if (this.f3112g0 != drawable) {
            this.f3112g0 = drawable;
            mo3439a(true);
        }
    }

    public void setIconGravity(int i) {
        if (this.f3118m0 != i) {
            this.f3118m0 = i;
            mo3442c();
        }
    }

    public void setIconPadding(int i) {
        if (this.f3115j0 != i) {
            this.f3115j0 = i;
            setCompoundDrawablePadding(i);
        }
    }

    public void setIconResource(int i) {
        setIcon(i != 0 ? C1206l0.m8461c(getContext(), i) : null);
    }

    public void setIconSize(int i) {
        if (i < 0) {
            throw new IllegalArgumentException("iconSize cannot be less than 0");
        } else if (this.f3113h0 != i) {
            this.f3113h0 = i;
            mo3439a(true);
        }
    }

    public void setIconTint(ColorStateList colorStateList) {
        if (this.f3111f0 != colorStateList) {
            this.f3111f0 = colorStateList;
            mo3439a(false);
        }
    }

    public void setIconTintMode(PorterDuff.Mode mode) {
        if (this.f3110e0 != mode) {
            this.f3110e0 = mode;
            mo3439a(false);
        }
    }

    public void setIconTintResource(int i) {
        setIconTint(C1206l0.m8460b(getContext(), i));
    }

    public void setInternalBackground(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
    }

    public void setOnPressedChangeListenerInternal(C0434b bVar) {
    }

    public void setPressed(boolean z) {
        super.setPressed(z);
    }

    public void setRippleColor(ColorStateList colorStateList) {
        if (mo3441b()) {
            m43 m43 = this.f3108c0;
            if (m43.f10002l != colorStateList) {
                m43.f10002l = colorStateList;
                if (m43.f9990s && (m43.f9991a.getBackground() instanceof RippleDrawable)) {
                    ((RippleDrawable) m43.f9991a.getBackground()).setColor(w63.m14963a(colorStateList));
                } else if (!m43.f9990s && (m43.f9991a.getBackground() instanceof v63)) {
                    ((v63) m43.f9991a.getBackground()).setTintList(w63.m14963a(colorStateList));
                }
            }
        }
    }

    public void setRippleColorResource(int i) {
        if (mo3441b()) {
            setRippleColor(C1206l0.m8460b(getContext(), i));
        }
    }

    public void setShapeAppearanceModel(j73 j73) {
        if (mo3441b()) {
            this.f3108c0.mo8576a(j73);
            return;
        }
        throw new IllegalStateException("Attempted to set ShapeAppearanceModel on a MaterialButton which has an overwritten background.");
    }

    public void setShouldDrawSurfaceColorStroke(boolean z) {
        if (mo3441b()) {
            m43 m43 = this.f3108c0;
            m43.f10004n = z;
            m43.mo8579d();
        }
    }

    public void setStrokeColor(ColorStateList colorStateList) {
        if (mo3441b()) {
            m43 m43 = this.f3108c0;
            if (m43.f10001k != colorStateList) {
                m43.f10001k = colorStateList;
                m43.mo8579d();
            }
        }
    }

    public void setStrokeColorResource(int i) {
        if (mo3441b()) {
            setStrokeColor(C1206l0.m8460b(getContext(), i));
        }
    }

    public void setStrokeWidth(int i) {
        if (mo3441b()) {
            m43 m43 = this.f3108c0;
            if (m43.f9998h != i) {
                m43.f9998h = i;
                m43.mo8579d();
            }
        }
    }

    public void setStrokeWidthResource(int i) {
        if (mo3441b()) {
            setStrokeWidth(getResources().getDimensionPixelSize(i));
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        if (mo3441b()) {
            m43 m43 = this.f3108c0;
            if (m43.f10000j != colorStateList) {
                m43.f10000j = colorStateList;
                if (m43.mo8577b() != null) {
                    C0815h0.m5802a((Drawable) m43.mo8577b(), m43.f10000j);
                    return;
                }
                return;
            }
            return;
        }
        super.setSupportBackgroundTintList(colorStateList);
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        if (mo3441b()) {
            m43 m43 = this.f3108c0;
            if (m43.f9999i != mode) {
                m43.f9999i = mode;
                if (m43.mo8577b() != null && m43.f9999i != null) {
                    C0815h0.m5803a((Drawable) m43.mo8577b(), m43.f9999i);
                    return;
                }
                return;
            }
            return;
        }
        super.setSupportBackgroundTintMode(mode);
    }

    public void toggle() {
        setChecked(!this.f3116k0);
    }

    /* renamed from: a */
    public final void mo3439a(boolean z) {
        Drawable drawable = this.f3112g0;
        boolean z2 = false;
        if (drawable != null) {
            this.f3112g0 = C0815h0.m5858e(drawable).mutate();
            C0815h0.m5802a(this.f3112g0, this.f3111f0);
            PorterDuff.Mode mode = this.f3110e0;
            if (mode != null) {
                C0815h0.m5803a(this.f3112g0, mode);
            }
            int i = this.f3113h0;
            if (i == 0) {
                i = this.f3112g0.getIntrinsicWidth();
            }
            int i2 = this.f3113h0;
            if (i2 == 0) {
                i2 = this.f3112g0.getIntrinsicHeight();
            }
            Drawable drawable2 = this.f3112g0;
            int i3 = this.f3114i0;
            drawable2.setBounds(i3, 0, i + i3, i2);
        }
        int i4 = this.f3118m0;
        boolean z3 = i4 == 1 || i4 == 2;
        if (z) {
            Drawable drawable3 = this.f3112g0;
            if (z3) {
                int i5 = Build.VERSION.SDK_INT;
                setCompoundDrawablesRelative(drawable3, (Drawable) null, (Drawable) null, (Drawable) null);
                return;
            }
            int i6 = Build.VERSION.SDK_INT;
            setCompoundDrawablesRelative((Drawable) null, (Drawable) null, drawable3, (Drawable) null);
            return;
        }
        Drawable[] a = C0815h0.m5830a((TextView) this);
        Drawable drawable4 = a[0];
        Drawable drawable5 = a[2];
        if ((z3 && drawable4 != this.f3112g0) || (!z3 && drawable5 != this.f3112g0)) {
            z2 = true;
        }
        if (z2) {
            Drawable drawable6 = this.f3112g0;
            if (z3) {
                int i7 = Build.VERSION.SDK_INT;
                setCompoundDrawablesRelative(drawable6, (Drawable) null, (Drawable) null, (Drawable) null);
                return;
            }
            int i8 = Build.VERSION.SDK_INT;
            setCompoundDrawablesRelative((Drawable) null, (Drawable) null, drawable6, (Drawable) null);
        }
    }
}
