package com.google.android.material.snackbar;

import android.view.MotionEvent;
import android.view.View;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.behavior.SwipeDismissBehavior;

public class BaseTransientBottomBar$Behavior extends SwipeDismissBehavior<View> {

    /* renamed from: k */
    public final n73 f3200k = new n73(this);

    /* renamed from: a */
    public boolean mo3357a(View view) {
        return this.f3200k.mo9120a(view);
    }

    /* renamed from: a */
    public boolean mo1266a(CoordinatorLayout coordinatorLayout, View view, MotionEvent motionEvent) {
        this.f3200k.mo9119a(coordinatorLayout, view, motionEvent);
        return super.mo1266a(coordinatorLayout, view, motionEvent);
    }
}
