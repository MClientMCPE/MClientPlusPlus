package com.google.android.material.textfield;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewStructure;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.widget.AppCompatTextView;
import com.google.android.material.internal.CheckableImageButton;
import java.util.Iterator;
import java.util.LinkedHashSet;
import p000.h83;

public class TextInputLayout extends LinearLayout {

    /* renamed from: o1 */
    public static final int f3290o1 = k33.Widget_Design_TextInputLayout;

    /* renamed from: A0 */
    public int f3291A0;

    /* renamed from: B0 */
    public final Rect f3292B0;

    /* renamed from: C0 */
    public final Rect f3293C0;

    /* renamed from: D0 */
    public final RectF f3294D0;

    /* renamed from: E0 */
    public Typeface f3295E0;

    /* renamed from: F0 */
    public final CheckableImageButton f3296F0;

    /* renamed from: G0 */
    public ColorStateList f3297G0;

    /* renamed from: H0 */
    public boolean f3298H0;

    /* renamed from: I0 */
    public PorterDuff.Mode f3299I0;

    /* renamed from: J0 */
    public boolean f3300J0;

    /* renamed from: K0 */
    public Drawable f3301K0;

    /* renamed from: L0 */
    public View.OnLongClickListener f3302L0;

    /* renamed from: M0 */
    public final LinkedHashSet<C0470f> f3303M0;

    /* renamed from: N0 */
    public int f3304N0;

    /* renamed from: O0 */
    public final SparseArray<e83> f3305O0;

    /* renamed from: P0 */
    public final CheckableImageButton f3306P0;

    /* renamed from: Q0 */
    public final LinkedHashSet<C0471g> f3307Q0;

    /* renamed from: R0 */
    public ColorStateList f3308R0;

    /* renamed from: S0 */
    public boolean f3309S0;

    /* renamed from: T0 */
    public PorterDuff.Mode f3310T0;

    /* renamed from: U0 */
    public boolean f3311U0;

    /* renamed from: V0 */
    public Drawable f3312V0;

    /* renamed from: W0 */
    public Drawable f3313W0;

    /* renamed from: X0 */
    public final CheckableImageButton f3314X0;

    /* renamed from: Y0 */
    public View.OnLongClickListener f3315Y0;

    /* renamed from: Z0 */
    public ColorStateList f3316Z0;

    /* renamed from: a0 */
    public final FrameLayout f3317a0;

    /* renamed from: a1 */
    public ColorStateList f3318a1;

    /* renamed from: b0 */
    public final FrameLayout f3319b0;

    /* renamed from: b1 */
    public final int f3320b1;

    /* renamed from: c0 */
    public EditText f3321c0;

    /* renamed from: c1 */
    public final int f3322c1;

    /* renamed from: d0 */
    public CharSequence f3323d0;

    /* renamed from: d1 */
    public int f3324d1;

    /* renamed from: e0 */
    public final f83 f3325e0;

    /* renamed from: e1 */
    public int f3326e1;

    /* renamed from: f0 */
    public boolean f3327f0;

    /* renamed from: f1 */
    public final int f3328f1;

    /* renamed from: g0 */
    public int f3329g0;

    /* renamed from: g1 */
    public final int f3330g1;

    /* renamed from: h0 */
    public boolean f3331h0;

    /* renamed from: h1 */
    public final int f3332h1;

    /* renamed from: i0 */
    public TextView f3333i0;

    /* renamed from: i1 */
    public boolean f3334i1;

    /* renamed from: j0 */
    public int f3335j0;

    /* renamed from: j1 */
    public final i63 f3336j1;

    /* renamed from: k0 */
    public int f3337k0;

    /* renamed from: k1 */
    public boolean f3338k1;

    /* renamed from: l0 */
    public ColorStateList f3339l0;

    /* renamed from: l1 */
    public ValueAnimator f3340l1;

    /* renamed from: m0 */
    public ColorStateList f3341m0;

    /* renamed from: m1 */
    public boolean f3342m1;

    /* renamed from: n0 */
    public boolean f3343n0;

    /* renamed from: n1 */
    public boolean f3344n1;

    /* renamed from: o0 */
    public CharSequence f3345o0;

    /* renamed from: p0 */
    public boolean f3346p0;

    /* renamed from: q0 */
    public f73 f3347q0;

    /* renamed from: r0 */
    public f73 f3348r0;

    /* renamed from: s0 */
    public j73 f3349s0;

    /* renamed from: t0 */
    public final int f3350t0;

    /* renamed from: u0 */
    public int f3351u0;

    /* renamed from: v0 */
    public final int f3352v0;

    /* renamed from: w0 */
    public int f3353w0;

    /* renamed from: x0 */
    public final int f3354x0;

    /* renamed from: y0 */
    public final int f3355y0;

    /* renamed from: z0 */
    public int f3356z0;

    /* renamed from: com.google.android.material.textfield.TextInputLayout$a */
    public class C0465a implements TextWatcher {
        public C0465a() {
        }

        public void afterTextChanged(Editable editable) {
            TextInputLayout textInputLayout = TextInputLayout.this;
            textInputLayout.mo3959a(!textInputLayout.f3344n1);
            TextInputLayout textInputLayout2 = TextInputLayout.this;
            if (textInputLayout2.f3327f0) {
                textInputLayout2.mo3954a(editable.length());
            }
        }

        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }
    }

    /* renamed from: com.google.android.material.textfield.TextInputLayout$b */
    public class C0466b implements Runnable {
        public C0466b() {
        }

        public void run() {
            TextInputLayout.this.f3306P0.performClick();
            TextInputLayout.this.f3306P0.jumpDrawablesToCurrentState();
        }
    }

    /* renamed from: com.google.android.material.textfield.TextInputLayout$c */
    public class C0467c implements Runnable {
        public C0467c() {
        }

        public void run() {
            TextInputLayout.this.f3321c0.requestLayout();
        }
    }

    /* renamed from: com.google.android.material.textfield.TextInputLayout$d */
    public class C0468d implements ValueAnimator.AnimatorUpdateListener {
        public C0468d() {
        }

        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            TextInputLayout.this.f3336j1.mo6869c(((Float) valueAnimator.getAnimatedValue()).floatValue());
        }
    }

    /* renamed from: com.google.android.material.textfield.TextInputLayout$e */
    public static class C0469e extends C0757g7 {

        /* renamed from: d */
        public final TextInputLayout f3361d;

        public C0469e(TextInputLayout textInputLayout) {
            super(C0757g7.f6013c);
            this.f3361d = textInputLayout;
        }

        /* renamed from: a */
        public void mo1378a(View view, C0759g8 g8Var) {
            this.f6014a.onInitializeAccessibilityNodeInfo(view, g8Var.f6028a);
            EditText editText = this.f3361d.getEditText();
            Editable text = editText != null ? editText.getText() : null;
            CharSequence hint = this.f3361d.getHint();
            CharSequence error = this.f3361d.getError();
            CharSequence counterOverflowDescription = this.f3361d.getCounterOverflowDescription();
            boolean z = !TextUtils.isEmpty(text);
            boolean z2 = !TextUtils.isEmpty(hint);
            boolean z3 = !TextUtils.isEmpty(error);
            boolean z4 = false;
            boolean z5 = z3 || !TextUtils.isEmpty(counterOverflowDescription);
            if (z) {
                g8Var.f6028a.setText(text);
            } else if (z2) {
                g8Var.f6028a.setText(hint);
            }
            if (z2) {
                g8Var.mo6037a(hint);
                if (!z && z2) {
                    z4 = true;
                }
                if (Build.VERSION.SDK_INT >= 26) {
                    g8Var.f6028a.setShowingHintText(z4);
                } else {
                    g8Var.mo6036a(4, z4);
                }
            }
            if (z5) {
                if (!z3) {
                    error = counterOverflowDescription;
                }
                if (Build.VERSION.SDK_INT >= 21) {
                    g8Var.f6028a.setError(error);
                }
                int i = Build.VERSION.SDK_INT;
                g8Var.f6028a.setContentInvalid(true);
            }
        }
    }

    /* renamed from: com.google.android.material.textfield.TextInputLayout$f */
    public interface C0470f {
        /* renamed from: a */
        void mo2861a(TextInputLayout textInputLayout);
    }

    /* renamed from: com.google.android.material.textfield.TextInputLayout$g */
    public interface C0471g {
    }

    /* renamed from: com.google.android.material.textfield.TextInputLayout$h */
    public static class C0472h extends C1904t8 {
        public static final Parcelable.Creator<C0472h> CREATOR = new C0473a();

        /* renamed from: Z */
        public CharSequence f3362Z;

        /* renamed from: a0 */
        public boolean f3363a0;

        /* renamed from: com.google.android.material.textfield.TextInputLayout$h$a */
        public static class C0473a implements Parcelable.ClassLoaderCreator<C0472h> {
            public Object createFromParcel(Parcel parcel) {
                return new C0472h(parcel, (ClassLoader) null);
            }

            public Object[] newArray(int i) {
                return new C0472h[i];
            }

            public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new C0472h(parcel, classLoader);
            }
        }

        public C0472h(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f3362Z = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(parcel);
            this.f3363a0 = parcel.readInt() != 1 ? false : true;
        }

        public C0472h(Parcelable parcelable) {
            super(parcelable);
        }

        public String toString() {
            StringBuilder a = C0789gk.m5562a("TextInputLayout.SavedState{");
            a.append(Integer.toHexString(System.identityHashCode(this)));
            a.append(" error=");
            a.append(this.f3362Z);
            a.append("}");
            return a.toString();
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeParcelable(this.f14707X, i);
            TextUtils.writeToParcel(this.f3362Z, parcel, i);
            parcel.writeInt(this.f3363a0 ? 1 : 0);
        }
    }

    public TextInputLayout(Context context) {
        this(context, (AttributeSet) null);
    }

    public TextInputLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, b33.textInputStyle);
    }

    /* JADX WARNING: Illegal instructions before constructor call */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public TextInputLayout(android.content.Context r17, android.util.AttributeSet r18, int r19) {
        /*
            r16 = this;
            r0 = r16
            r7 = r18
            r8 = r19
            int r1 = f3290o1
            r2 = r17
            android.content.Context r1 = p000.o63.m10327b(r2, r7, r8, r1)
            r0.<init>(r1, r7, r8)
            f83 r1 = new f83
            r1.<init>(r0)
            r0.f3325e0 = r1
            android.graphics.Rect r1 = new android.graphics.Rect
            r1.<init>()
            r0.f3292B0 = r1
            android.graphics.Rect r1 = new android.graphics.Rect
            r1.<init>()
            r0.f3293C0 = r1
            android.graphics.RectF r1 = new android.graphics.RectF
            r1.<init>()
            r0.f3294D0 = r1
            java.util.LinkedHashSet r1 = new java.util.LinkedHashSet
            r1.<init>()
            r0.f3303M0 = r1
            r9 = 0
            r0.f3304N0 = r9
            android.util.SparseArray r1 = new android.util.SparseArray
            r1.<init>()
            r0.f3305O0 = r1
            java.util.LinkedHashSet r1 = new java.util.LinkedHashSet
            r1.<init>()
            r0.f3307Q0 = r1
            i63 r1 = new i63
            r1.<init>(r0)
            r0.f3336j1 = r1
            android.content.Context r10 = r16.getContext()
            r11 = 1
            r0.setOrientation(r11)
            r0.setWillNotDraw(r9)
            r0.setAddStatesFromChildren(r11)
            android.widget.FrameLayout r1 = new android.widget.FrameLayout
            r1.<init>(r10)
            r0.f3317a0 = r1
            android.widget.FrameLayout r1 = r0.f3317a0
            r1.setAddStatesFromChildren(r11)
            android.widget.FrameLayout r1 = r0.f3317a0
            r0.addView(r1)
            android.widget.FrameLayout r1 = new android.widget.FrameLayout
            r1.<init>(r10)
            r0.f3319b0 = r1
            android.widget.FrameLayout r1 = r0.f3319b0
            android.widget.FrameLayout$LayoutParams r2 = new android.widget.FrameLayout$LayoutParams
            r3 = -2
            r4 = 8388629(0x800015, float:1.1754973E-38)
            r2.<init>(r3, r3, r4)
            r1.setLayoutParams(r2)
            android.widget.FrameLayout r1 = r0.f3317a0
            android.widget.FrameLayout r2 = r0.f3319b0
            r1.addView(r2)
            i63 r1 = r0.f3336j1
            android.animation.TimeInterpolator r2 = p000.m33.f9974a
            r1.f7226M = r2
            r1.mo6873f()
            i63 r1 = r0.f3336j1
            android.animation.TimeInterpolator r2 = p000.m33.f9974a
            r1.f7225L = r2
            r1.mo6873f()
            i63 r1 = r0.f3336j1
            int r2 = r1.f7242h
            r3 = 8388659(0x800033, float:1.1755015E-38)
            if (r2 == r3) goto L_0x00a7
            r1.f7242h = r3
            r1.mo6873f()
        L_0x00a7:
            int[] r12 = p000.l33.TextInputLayout
            int r13 = f3290o1
            r1 = 5
            int[] r6 = new int[r1]
            int r1 = p000.l33.TextInputLayout_counterTextAppearance
            r6[r9] = r1
            int r1 = p000.l33.TextInputLayout_counterOverflowTextAppearance
            r6[r11] = r1
            int r1 = p000.l33.TextInputLayout_errorTextAppearance
            r14 = 2
            r6[r14] = r1
            int r1 = p000.l33.TextInputLayout_helperTextTextAppearance
            r15 = 3
            r6[r15] = r1
            r1 = 4
            int r2 = p000.l33.TextInputLayout_hintTextAppearance
            r6[r1] = r2
            p000.o63.m10324a(r10, r7, r8, r13)
            r1 = r10
            r2 = r18
            r3 = r12
            r4 = r19
            r5 = r13
            p000.o63.m10325a(r1, r2, r3, r4, r5, r6)
            y3 r1 = new y3
            android.content.res.TypedArray r2 = r10.obtainStyledAttributes(r7, r12, r8, r13)
            r1.<init>(r10, r2)
            int r2 = p000.l33.TextInputLayout_hintEnabled
            boolean r2 = r1.mo12735a((int) r2, (boolean) r11)
            r0.f3343n0 = r2
            int r2 = p000.l33.TextInputLayout_android_hint
            java.lang.CharSequence r2 = r1.mo12743e(r2)
            r0.setHint(r2)
            int r2 = p000.l33.TextInputLayout_hintAnimationEnabled
            boolean r2 = r1.mo12735a((int) r2, (boolean) r11)
            r0.f3338k1 = r2
            int r2 = f3290o1
            j73$b r2 = p000.j73.m7354a((android.content.Context) r10, (android.util.AttributeSet) r7, (int) r8, (int) r2)
            j73 r2 = r2.mo7445a()
            r0.f3349s0 = r2
            android.content.res.Resources r2 = r10.getResources()
            int r3 = p000.d33.mtrl_textinput_box_label_cutout_padding
            int r2 = r2.getDimensionPixelOffset(r3)
            r0.f3350t0 = r2
            int r2 = p000.l33.TextInputLayout_boxCollapsedPaddingTop
            int r2 = r1.mo12736b(r2, r9)
            r0.f3352v0 = r2
            int r2 = p000.l33.TextInputLayout_boxStrokeWidth
            android.content.res.Resources r3 = r10.getResources()
            int r4 = p000.d33.mtrl_textinput_box_stroke_width_default
            int r3 = r3.getDimensionPixelSize(r4)
            int r2 = r1.mo12738c(r2, r3)
            r0.f3354x0 = r2
            int r2 = p000.l33.TextInputLayout_boxStrokeWidthFocused
            android.content.res.Resources r3 = r10.getResources()
            int r4 = p000.d33.mtrl_textinput_box_stroke_width_focused
            int r3 = r3.getDimensionPixelSize(r4)
            int r2 = r1.mo12738c(r2, r3)
            r0.f3355y0 = r2
            int r2 = r0.f3354x0
            r0.f3353w0 = r2
            int r2 = p000.l33.TextInputLayout_boxCornerRadiusTopStart
            r3 = -1082130432(0xffffffffbf800000, float:-1.0)
            float r2 = r1.mo12731a((int) r2, (float) r3)
            int r4 = p000.l33.TextInputLayout_boxCornerRadiusTopEnd
            float r4 = r1.mo12731a((int) r4, (float) r3)
            int r5 = p000.l33.TextInputLayout_boxCornerRadiusBottomEnd
            float r5 = r1.mo12731a((int) r5, (float) r3)
            int r6 = p000.l33.TextInputLayout_boxCornerRadiusBottomStart
            float r3 = r1.mo12731a((int) r6, (float) r3)
            j73 r6 = r0.f3349s0
            j73$b r6 = r6.mo7442b()
            r7 = 0
            int r8 = (r2 > r7 ? 1 : (r2 == r7 ? 0 : -1))
            if (r8 < 0) goto L_0x0164
            r6.mo7448c((float) r2)
        L_0x0164:
            int r2 = (r4 > r7 ? 1 : (r4 == r7 ? 0 : -1))
            if (r2 < 0) goto L_0x016b
            r6.mo7450d((float) r4)
        L_0x016b:
            int r2 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r2 < 0) goto L_0x0172
            r6.mo7446b((float) r5)
        L_0x0172:
            int r2 = (r3 > r7 ? 1 : (r3 == r7 ? 0 : -1))
            if (r2 < 0) goto L_0x0179
            r6.mo7443a((float) r3)
        L_0x0179:
            j73 r2 = r6.mo7445a()
            r0.f3349s0 = r2
            int r2 = p000.l33.TextInputLayout_boxBackgroundColor
            android.content.res.ColorStateList r2 = p000.t53.m13078a((android.content.Context) r10, (p000.C2322y3) r1, (int) r2)
            r3 = 16843623(0x1010367, float:2.3696E-38)
            r4 = -16842910(0xfffffffffefeff62, float:-1.6947497E38)
            r5 = -1
            if (r2 == 0) goto L_0x01cc
            int r6 = r2.getDefaultColor()
            r0.f3326e1 = r6
            int r6 = r0.f3326e1
            r0.f3291A0 = r6
            boolean r6 = r2.isStateful()
            if (r6 == 0) goto L_0x01b1
            int[] r6 = new int[r11]
            r6[r9] = r4
            int r6 = r2.getColorForState(r6, r5)
            r0.f3328f1 = r6
            int[] r6 = new int[r11]
            r6[r9] = r3
            int r2 = r2.getColorForState(r6, r5)
            goto L_0x01c9
        L_0x01b1:
            int r2 = p000.c33.mtrl_filled_background_color
            android.content.res.ColorStateList r2 = p000.C1206l0.m8460b(r10, r2)
            int[] r6 = new int[r11]
            r6[r9] = r4
            int r6 = r2.getColorForState(r6, r5)
            r0.f3328f1 = r6
            int[] r6 = new int[r11]
            r6[r9] = r3
            int r2 = r2.getColorForState(r6, r5)
        L_0x01c9:
            r0.f3330g1 = r2
            goto L_0x01d4
        L_0x01cc:
            r0.f3291A0 = r9
            r0.f3326e1 = r9
            r0.f3328f1 = r9
            r0.f3330g1 = r9
        L_0x01d4:
            int r2 = p000.l33.TextInputLayout_android_textColorHint
            boolean r2 = r1.mo12745f(r2)
            if (r2 == 0) goto L_0x01e6
            int r2 = p000.l33.TextInputLayout_android_textColorHint
            android.content.res.ColorStateList r2 = r1.mo12733a(r2)
            r0.f3318a1 = r2
            r0.f3316Z0 = r2
        L_0x01e6:
            int r2 = p000.l33.TextInputLayout_boxStrokeColor
            android.content.res.ColorStateList r2 = p000.t53.m13078a((android.content.Context) r10, (p000.C2322y3) r1, (int) r2)
            if (r2 == 0) goto L_0x021c
            boolean r6 = r2.isStateful()
            if (r6 == 0) goto L_0x021c
            int r6 = r2.getDefaultColor()
            r0.f3320b1 = r6
            int[] r6 = new int[r11]
            r6[r9] = r4
            int r4 = r2.getColorForState(r6, r5)
            r0.f3332h1 = r4
            int[] r4 = new int[r11]
            r4[r9] = r3
            int r3 = r2.getColorForState(r4, r5)
            r0.f3322c1 = r3
            int[] r3 = new int[r11]
            r4 = 16842908(0x101009c, float:2.3693995E-38)
            r3[r9] = r4
            int r2 = r2.getColorForState(r3, r5)
            r0.f3324d1 = r2
            goto L_0x023c
        L_0x021c:
            int r2 = p000.l33.TextInputLayout_boxStrokeColor
            int r2 = r1.mo12732a((int) r2, (int) r9)
            r0.f3324d1 = r2
            int r2 = p000.c33.mtrl_textinput_default_box_stroke_color
            int r2 = p000.C2085v5.m14456a((android.content.Context) r10, (int) r2)
            r0.f3320b1 = r2
            int r2 = p000.c33.mtrl_textinput_disabled_color
            int r2 = p000.C2085v5.m14456a((android.content.Context) r10, (int) r2)
            r0.f3332h1 = r2
            int r2 = p000.c33.mtrl_textinput_hovered_box_stroke_color
            int r2 = p000.C2085v5.m14456a((android.content.Context) r10, (int) r2)
            r0.f3322c1 = r2
        L_0x023c:
            int r2 = p000.l33.TextInputLayout_hintTextAppearance
            int r2 = r1.mo12744f(r2, r5)
            if (r2 == r5) goto L_0x024d
            int r2 = p000.l33.TextInputLayout_hintTextAppearance
            int r2 = r1.mo12744f(r2, r9)
            r0.setHintTextAppearance(r2)
        L_0x024d:
            int r2 = p000.l33.TextInputLayout_errorTextAppearance
            int r2 = r1.mo12744f(r2, r9)
            int r3 = p000.l33.TextInputLayout_errorEnabled
            boolean r3 = r1.mo12735a((int) r3, (boolean) r9)
            android.content.Context r4 = r16.getContext()
            android.view.LayoutInflater r4 = android.view.LayoutInflater.from(r4)
            int r6 = p000.h33.design_text_input_end_icon
            android.widget.FrameLayout r7 = r0.f3317a0
            android.view.View r4 = r4.inflate(r6, r7, r9)
            com.google.android.material.internal.CheckableImageButton r4 = (com.google.android.material.internal.CheckableImageButton) r4
            r0.f3314X0 = r4
            android.widget.FrameLayout r4 = r0.f3317a0
            com.google.android.material.internal.CheckableImageButton r6 = r0.f3314X0
            r4.addView(r6)
            com.google.android.material.internal.CheckableImageButton r4 = r0.f3314X0
            r6 = 8
            r4.setVisibility(r6)
            int r4 = p000.l33.TextInputLayout_errorIconDrawable
            boolean r4 = r1.mo12745f(r4)
            if (r4 == 0) goto L_0x028c
            int r4 = p000.l33.TextInputLayout_errorIconDrawable
            android.graphics.drawable.Drawable r4 = r1.mo12737b(r4)
            r0.setErrorIconDrawable((android.graphics.drawable.Drawable) r4)
        L_0x028c:
            int r4 = p000.l33.TextInputLayout_errorIconTint
            boolean r4 = r1.mo12745f(r4)
            if (r4 == 0) goto L_0x029d
            int r4 = p000.l33.TextInputLayout_errorIconTint
            android.content.res.ColorStateList r4 = p000.t53.m13078a((android.content.Context) r10, (p000.C2322y3) r1, (int) r4)
            r0.setErrorIconTintList(r4)
        L_0x029d:
            int r4 = p000.l33.TextInputLayout_errorIconTintMode
            boolean r4 = r1.mo12745f(r4)
            r7 = 0
            if (r4 == 0) goto L_0x02b3
            int r4 = p000.l33.TextInputLayout_errorIconTintMode
            int r4 = r1.mo12740d(r4, r5)
            android.graphics.PorterDuff$Mode r4 = p000.t53.m13079a((int) r4, (android.graphics.PorterDuff.Mode) r7)
            r0.setErrorIconTintMode(r4)
        L_0x02b3:
            com.google.android.material.internal.CheckableImageButton r4 = r0.f3314X0
            android.content.res.Resources r8 = r16.getResources()
            int r12 = p000.j33.error_icon_content_description
            java.lang.CharSequence r8 = r8.getText(r12)
            r4.setContentDescription(r8)
            com.google.android.material.internal.CheckableImageButton r4 = r0.f3314X0
            p000.C2189w7.m15013h(r4, r14)
            com.google.android.material.internal.CheckableImageButton r4 = r0.f3314X0
            r4.setClickable(r9)
            com.google.android.material.internal.CheckableImageButton r4 = r0.f3314X0
            r4.setPressable(r9)
            com.google.android.material.internal.CheckableImageButton r4 = r0.f3314X0
            r4.setFocusable(r9)
            int r4 = p000.l33.TextInputLayout_helperTextTextAppearance
            int r4 = r1.mo12744f(r4, r9)
            int r8 = p000.l33.TextInputLayout_helperTextEnabled
            boolean r8 = r1.mo12735a((int) r8, (boolean) r9)
            int r12 = p000.l33.TextInputLayout_helperText
            java.lang.CharSequence r12 = r1.mo12743e(r12)
            int r13 = p000.l33.TextInputLayout_counterEnabled
            boolean r13 = r1.mo12735a((int) r13, (boolean) r9)
            int r15 = p000.l33.TextInputLayout_counterMaxLength
            int r15 = r1.mo12740d(r15, r5)
            r0.setCounterMaxLength(r15)
            int r15 = p000.l33.TextInputLayout_counterTextAppearance
            int r15 = r1.mo12744f(r15, r9)
            r0.f3337k0 = r15
            int r15 = p000.l33.TextInputLayout_counterOverflowTextAppearance
            int r15 = r1.mo12744f(r15, r9)
            r0.f3335j0 = r15
            android.content.Context r15 = r16.getContext()
            android.view.LayoutInflater r15 = android.view.LayoutInflater.from(r15)
            int r14 = p000.h33.design_text_input_start_icon
            android.widget.FrameLayout r5 = r0.f3317a0
            android.view.View r5 = r15.inflate(r14, r5, r9)
            com.google.android.material.internal.CheckableImageButton r5 = (com.google.android.material.internal.CheckableImageButton) r5
            r0.f3296F0 = r5
            android.widget.FrameLayout r5 = r0.f3317a0
            com.google.android.material.internal.CheckableImageButton r14 = r0.f3296F0
            r5.addView(r14)
            com.google.android.material.internal.CheckableImageButton r5 = r0.f3296F0
            r5.setVisibility(r6)
            r0.setStartIconOnClickListener(r7)
            r0.setStartIconOnLongClickListener(r7)
            int r5 = p000.l33.TextInputLayout_startIconDrawable
            boolean r5 = r1.mo12745f(r5)
            if (r5 == 0) goto L_0x0358
            int r5 = p000.l33.TextInputLayout_startIconDrawable
            android.graphics.drawable.Drawable r5 = r1.mo12737b(r5)
            r0.setStartIconDrawable((android.graphics.drawable.Drawable) r5)
            int r5 = p000.l33.TextInputLayout_startIconContentDescription
            boolean r5 = r1.mo12745f(r5)
            if (r5 == 0) goto L_0x034f
            int r5 = p000.l33.TextInputLayout_startIconContentDescription
            java.lang.CharSequence r5 = r1.mo12743e(r5)
            r0.setStartIconContentDescription((java.lang.CharSequence) r5)
        L_0x034f:
            int r5 = p000.l33.TextInputLayout_startIconCheckable
            boolean r5 = r1.mo12735a((int) r5, (boolean) r11)
            r0.setStartIconCheckable(r5)
        L_0x0358:
            int r5 = p000.l33.TextInputLayout_startIconTint
            boolean r5 = r1.mo12745f(r5)
            if (r5 == 0) goto L_0x0369
            int r5 = p000.l33.TextInputLayout_startIconTint
            android.content.res.ColorStateList r5 = p000.t53.m13078a((android.content.Context) r10, (p000.C2322y3) r1, (int) r5)
            r0.setStartIconTintList(r5)
        L_0x0369:
            int r5 = p000.l33.TextInputLayout_startIconTintMode
            boolean r5 = r1.mo12745f(r5)
            if (r5 == 0) goto L_0x037f
            int r5 = p000.l33.TextInputLayout_startIconTintMode
            r14 = -1
            int r5 = r1.mo12740d(r5, r14)
            android.graphics.PorterDuff$Mode r5 = p000.t53.m13079a((int) r5, (android.graphics.PorterDuff.Mode) r7)
            r0.setStartIconTintMode(r5)
        L_0x037f:
            r0.setHelperTextEnabled(r8)
            r0.setHelperText(r12)
            r0.setHelperTextTextAppearance(r4)
            r0.setErrorEnabled(r3)
            r0.setErrorTextAppearance(r2)
            int r2 = r0.f3337k0
            r0.setCounterTextAppearance(r2)
            int r2 = r0.f3335j0
            r0.setCounterOverflowTextAppearance(r2)
            int r2 = p000.l33.TextInputLayout_errorTextColor
            boolean r2 = r1.mo12745f(r2)
            if (r2 == 0) goto L_0x03a9
            int r2 = p000.l33.TextInputLayout_errorTextColor
            android.content.res.ColorStateList r2 = r1.mo12733a(r2)
            r0.setErrorTextColor(r2)
        L_0x03a9:
            int r2 = p000.l33.TextInputLayout_helperTextTextColor
            boolean r2 = r1.mo12745f(r2)
            if (r2 == 0) goto L_0x03ba
            int r2 = p000.l33.TextInputLayout_helperTextTextColor
            android.content.res.ColorStateList r2 = r1.mo12733a(r2)
            r0.setHelperTextColor(r2)
        L_0x03ba:
            int r2 = p000.l33.TextInputLayout_hintTextColor
            boolean r2 = r1.mo12745f(r2)
            if (r2 == 0) goto L_0x03cb
            int r2 = p000.l33.TextInputLayout_hintTextColor
            android.content.res.ColorStateList r2 = r1.mo12733a(r2)
            r0.setHintTextColor(r2)
        L_0x03cb:
            int r2 = p000.l33.TextInputLayout_counterTextColor
            boolean r2 = r1.mo12745f(r2)
            if (r2 == 0) goto L_0x03dc
            int r2 = p000.l33.TextInputLayout_counterTextColor
            android.content.res.ColorStateList r2 = r1.mo12733a(r2)
            r0.setCounterTextColor(r2)
        L_0x03dc:
            int r2 = p000.l33.TextInputLayout_counterOverflowTextColor
            boolean r2 = r1.mo12745f(r2)
            if (r2 == 0) goto L_0x03ed
            int r2 = p000.l33.TextInputLayout_counterOverflowTextColor
            android.content.res.ColorStateList r2 = r1.mo12733a(r2)
            r0.setCounterOverflowTextColor(r2)
        L_0x03ed:
            r0.setCounterEnabled(r13)
            int r2 = p000.l33.TextInputLayout_boxBackgroundMode
            int r2 = r1.mo12740d(r2, r9)
            r0.setBoxBackgroundMode(r2)
            android.content.Context r2 = r16.getContext()
            android.view.LayoutInflater r2 = android.view.LayoutInflater.from(r2)
            int r3 = p000.h33.design_text_input_end_icon
            android.widget.FrameLayout r4 = r0.f3319b0
            android.view.View r2 = r2.inflate(r3, r4, r9)
            com.google.android.material.internal.CheckableImageButton r2 = (com.google.android.material.internal.CheckableImageButton) r2
            r0.f3306P0 = r2
            android.widget.FrameLayout r2 = r0.f3319b0
            com.google.android.material.internal.CheckableImageButton r3 = r0.f3306P0
            r2.addView(r3)
            com.google.android.material.internal.CheckableImageButton r2 = r0.f3306P0
            r2.setVisibility(r6)
            android.util.SparseArray<e83> r2 = r0.f3305O0
            a83 r3 = new a83
            r3.<init>(r0)
            r4 = -1
            r2.append(r4, r3)
            android.util.SparseArray<e83> r2 = r0.f3305O0
            g83 r3 = new g83
            r3.<init>(r0)
            r2.append(r9, r3)
            android.util.SparseArray<e83> r2 = r0.f3305O0
            h83 r3 = new h83
            r3.<init>(r0)
            r2.append(r11, r3)
            android.util.SparseArray<e83> r2 = r0.f3305O0
            w73 r3 = new w73
            r3.<init>(r0)
            r4 = 2
            r2.append(r4, r3)
            android.util.SparseArray<e83> r2 = r0.f3305O0
            c83 r3 = new c83
            r3.<init>(r0)
            r4 = 3
            r2.append(r4, r3)
            int r2 = p000.l33.TextInputLayout_endIconMode
            boolean r2 = r1.mo12745f(r2)
            if (r2 == 0) goto L_0x048b
            int r2 = p000.l33.TextInputLayout_endIconMode
            int r2 = r1.mo12740d(r2, r9)
            r0.setEndIconMode(r2)
            int r2 = p000.l33.TextInputLayout_endIconDrawable
            boolean r2 = r1.mo12745f(r2)
            if (r2 == 0) goto L_0x0470
            int r2 = p000.l33.TextInputLayout_endIconDrawable
            android.graphics.drawable.Drawable r2 = r1.mo12737b(r2)
            r0.setEndIconDrawable((android.graphics.drawable.Drawable) r2)
        L_0x0470:
            int r2 = p000.l33.TextInputLayout_endIconContentDescription
            boolean r2 = r1.mo12745f(r2)
            if (r2 == 0) goto L_0x0481
            int r2 = p000.l33.TextInputLayout_endIconContentDescription
            java.lang.CharSequence r2 = r1.mo12743e(r2)
            r0.setEndIconContentDescription((java.lang.CharSequence) r2)
        L_0x0481:
            int r2 = p000.l33.TextInputLayout_endIconCheckable
            boolean r2 = r1.mo12735a((int) r2, (boolean) r11)
            r0.setEndIconCheckable(r2)
            goto L_0x04d5
        L_0x048b:
            int r2 = p000.l33.TextInputLayout_passwordToggleEnabled
            boolean r2 = r1.mo12745f(r2)
            if (r2 == 0) goto L_0x04d5
            int r2 = p000.l33.TextInputLayout_passwordToggleEnabled
            boolean r2 = r1.mo12735a((int) r2, (boolean) r9)
            r0.setEndIconMode(r2)
            int r2 = p000.l33.TextInputLayout_passwordToggleDrawable
            android.graphics.drawable.Drawable r2 = r1.mo12737b(r2)
            r0.setEndIconDrawable((android.graphics.drawable.Drawable) r2)
            int r2 = p000.l33.TextInputLayout_passwordToggleContentDescription
            java.lang.CharSequence r2 = r1.mo12743e(r2)
            r0.setEndIconContentDescription((java.lang.CharSequence) r2)
            int r2 = p000.l33.TextInputLayout_passwordToggleTint
            boolean r2 = r1.mo12745f(r2)
            if (r2 == 0) goto L_0x04bf
            int r2 = p000.l33.TextInputLayout_passwordToggleTint
            android.content.res.ColorStateList r2 = p000.t53.m13078a((android.content.Context) r10, (p000.C2322y3) r1, (int) r2)
            r0.setEndIconTintList(r2)
        L_0x04bf:
            int r2 = p000.l33.TextInputLayout_passwordToggleTintMode
            boolean r2 = r1.mo12745f(r2)
            if (r2 == 0) goto L_0x04d5
            int r2 = p000.l33.TextInputLayout_passwordToggleTintMode
            r3 = -1
            int r2 = r1.mo12740d(r2, r3)
            android.graphics.PorterDuff$Mode r2 = p000.t53.m13079a((int) r2, (android.graphics.PorterDuff.Mode) r7)
            r0.setEndIconTintMode(r2)
        L_0x04d5:
            int r2 = p000.l33.TextInputLayout_passwordToggleEnabled
            boolean r2 = r1.mo12745f(r2)
            if (r2 != 0) goto L_0x0504
            int r2 = p000.l33.TextInputLayout_endIconTint
            boolean r2 = r1.mo12745f(r2)
            if (r2 == 0) goto L_0x04ee
            int r2 = p000.l33.TextInputLayout_endIconTint
            android.content.res.ColorStateList r2 = p000.t53.m13078a((android.content.Context) r10, (p000.C2322y3) r1, (int) r2)
            r0.setEndIconTintList(r2)
        L_0x04ee:
            int r2 = p000.l33.TextInputLayout_endIconTintMode
            boolean r2 = r1.mo12745f(r2)
            if (r2 == 0) goto L_0x0504
            int r2 = p000.l33.TextInputLayout_endIconTintMode
            r3 = -1
            int r2 = r1.mo12740d(r2, r3)
            android.graphics.PorterDuff$Mode r2 = p000.t53.m13079a((int) r2, (android.graphics.PorterDuff.Mode) r7)
            r0.setEndIconTintMode(r2)
        L_0x0504:
            android.content.res.TypedArray r1 = r1.f17544b
            r1.recycle()
            int r1 = android.os.Build.VERSION.SDK_INT
            r2 = 2
            r0.setImportantForAccessibility(r2)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.textfield.TextInputLayout.<init>(android.content.Context, android.util.AttributeSet, int):void");
    }

    /* renamed from: a */
    public static void m3141a(ViewGroup viewGroup, boolean z) {
        int childCount = viewGroup.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = viewGroup.getChildAt(i);
            childAt.setEnabled(z);
            if (childAt instanceof ViewGroup) {
                m3141a((ViewGroup) childAt, z);
            }
        }
    }

    private e83 getEndIconDelegate() {
        e83 e83 = this.f3305O0.get(this.f3304N0);
        return e83 != null ? e83 : this.f3305O0.get(0);
    }

    private CheckableImageButton getEndIconToUpdateDummyDrawable() {
        if (this.f3314X0.getVisibility() == 0) {
            return this.f3314X0;
        }
        if (!mo3971g() || !mo4006h()) {
            return null;
        }
        return this.f3306P0;
    }

    private void setEditText(EditText editText) {
        if (this.f3321c0 == null) {
            if (this.f3304N0 != 3 && !(editText instanceof TextInputEditText)) {
                Log.i("TextInputLayout", "EditText added is not a TextInputEditText. Please switch to using that class instead.");
            }
            this.f3321c0 = editText;
            mo4010l();
            setTextInputAccessibilityDelegate(new C0469e(this));
            this.f3336j1.mo6867b(this.f3321c0.getTypeface());
            i63 i63 = this.f3336j1;
            float textSize = this.f3321c0.getTextSize();
            if (i63.f7243i != textSize) {
                i63.f7243i = textSize;
                i63.mo6873f();
            }
            int gravity = this.f3321c0.getGravity();
            i63 i632 = this.f3336j1;
            int i = (gravity & -113) | 48;
            if (i632.f7242h != i) {
                i632.f7242h = i;
                i632.mo6873f();
            }
            i63 i633 = this.f3336j1;
            if (i633.f7241g != gravity) {
                i633.f7241g = gravity;
                i633.mo6873f();
            }
            this.f3321c0.addTextChangedListener(new C0465a());
            if (this.f3316Z0 == null) {
                this.f3316Z0 = this.f3321c0.getHintTextColors();
            }
            if (this.f3343n0) {
                if (TextUtils.isEmpty(this.f3345o0)) {
                    this.f3323d0 = this.f3321c0.getHint();
                    setHint(this.f3323d0);
                    this.f3321c0.setHint((CharSequence) null);
                }
                this.f3346p0 = true;
            }
            if (this.f3333i0 != null) {
                mo3954a(this.f3321c0.getText().length());
            }
            mo4018p();
            this.f3325e0.mo5513a();
            this.f3296F0.bringToFront();
            this.f3319b0.bringToFront();
            this.f3314X0.bringToFront();
            Iterator it = this.f3303M0.iterator();
            while (it.hasNext()) {
                ((C0470f) it.next()).mo2861a(this);
            }
            mo3960a(false, true);
            return;
        }
        throw new IllegalArgumentException("We already have an EditText, can only have one");
    }

    private void setErrorIconVisible(boolean z) {
        int i = 0;
        this.f3314X0.setVisibility(z ? 0 : 8);
        FrameLayout frameLayout = this.f3319b0;
        if (z) {
            i = 8;
        }
        frameLayout.setVisibility(i);
        if (!mo3971g()) {
            mo4019q();
        }
    }

    private void setHintInternal(CharSequence charSequence) {
        if (!TextUtils.equals(charSequence, this.f3345o0)) {
            this.f3345o0 = charSequence;
            i63 i63 = this.f3336j1;
            if (charSequence == null || !TextUtils.equals(i63.f7258x, charSequence)) {
                i63.f7258x = charSequence;
                i63.f7259y = null;
                i63.mo6863b();
                i63.mo6873f();
            }
            if (!this.f3334i1) {
                mo4011m();
            }
        }
    }

    /* renamed from: a */
    public void mo3953a(float f) {
        if (this.f3336j1.f7237c != f) {
            if (this.f3340l1 == null) {
                this.f3340l1 = new ValueAnimator();
                this.f3340l1.setInterpolator(m33.f9975b);
                this.f3340l1.setDuration(167);
                this.f3340l1.addUpdateListener(new C0468d());
            }
            this.f3340l1.setFloatValues(new float[]{this.f3336j1.f7237c, f});
            this.f3340l1.start();
        }
    }

    /* renamed from: a */
    public void mo3955a(TextView textView, int i) {
        boolean z = true;
        try {
            C0815h0.m5857d(textView, i);
            if (Build.VERSION.SDK_INT < 23 || textView.getTextColors().getDefaultColor() != -65281) {
                z = false;
            }
        } catch (Exception unused) {
        }
        if (z) {
            C0815h0.m5857d(textView, k33.TextAppearance_AppCompat_Caption);
            textView.setTextColor(C2085v5.m14456a(getContext(), c33.design_error));
        }
    }

    /* renamed from: a */
    public final void mo3956a(CheckableImageButton checkableImageButton, boolean z, ColorStateList colorStateList, boolean z2, PorterDuff.Mode mode) {
        Drawable drawable = checkableImageButton.getDrawable();
        if (drawable != null && (z || z2)) {
            drawable = C0815h0.m5858e(drawable).mutate();
            if (z) {
                C0815h0.m5802a(drawable, colorStateList);
            }
            if (z2) {
                C0815h0.m5803a(drawable, mode);
            }
        }
        if (checkableImageButton.getDrawable() != drawable) {
            checkableImageButton.setImageDrawable(drawable);
        }
    }

    /* renamed from: a */
    public void mo3957a(C0470f fVar) {
        this.f3303M0.add(fVar);
        if (this.f3321c0 != null) {
            fVar.mo2861a(this);
        }
    }

    /* renamed from: a */
    public void mo3958a(C0471g gVar) {
        this.f3307Q0.add(gVar);
    }

    /* renamed from: a */
    public void mo3959a(boolean z) {
        mo3960a(z, false);
    }

    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        if (view instanceof EditText) {
            FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams(layoutParams);
            layoutParams2.gravity = (layoutParams2.gravity & -113) | 16;
            this.f3317a0.addView(view, layoutParams2);
            this.f3317a0.setLayoutParams(layoutParams);
            mo4020r();
            setEditText((EditText) view);
            return;
        }
        super.addView(view, i, layoutParams);
    }

    /* renamed from: b */
    public final void mo3962b() {
        mo3956a(this.f3306P0, this.f3309S0, this.f3308R0, this.f3311U0, this.f3310T0);
    }

    /* renamed from: c */
    public final void mo3963c() {
        mo3956a(this.f3296F0, this.f3298H0, this.f3297G0, this.f3300J0, this.f3299I0);
    }

    /* renamed from: d */
    public final int mo3964d() {
        float c;
        if (!this.f3343n0) {
            return 0;
        }
        int i = this.f3351u0;
        if (i == 0 || i == 1) {
            c = this.f3336j1.mo6868c();
        } else if (i != 2) {
            return 0;
        } else {
            c = this.f3336j1.mo6868c() / 2.0f;
        }
        return (int) c;
    }

    public void dispatchProvideAutofillStructure(ViewStructure viewStructure, int i) {
        EditText editText;
        if (this.f3323d0 == null || (editText = this.f3321c0) == null) {
            super.dispatchProvideAutofillStructure(viewStructure, i);
            return;
        }
        boolean z = this.f3346p0;
        this.f3346p0 = false;
        CharSequence hint = editText.getHint();
        this.f3321c0.setHint(this.f3323d0);
        try {
            super.dispatchProvideAutofillStructure(viewStructure, i);
        } finally {
            this.f3321c0.setHint(hint);
            this.f3346p0 = z;
        }
    }

    public void dispatchRestoreInstanceState(SparseArray<Parcelable> sparseArray) {
        this.f3344n1 = true;
        super.dispatchRestoreInstanceState(sparseArray);
        this.f3344n1 = false;
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (this.f3343n0) {
            this.f3336j1.mo6859a(canvas);
        }
        f73 f73 = this.f3348r0;
        if (f73 != null) {
            Rect bounds = f73.getBounds();
            bounds.top = bounds.bottom - this.f3353w0;
            this.f3348r0.draw(canvas);
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:9:0x0020, code lost:
        r1 = r2.f7245k;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void drawableStateChanged() {
        /*
            r4 = this;
            boolean r0 = r4.f3342m1
            if (r0 == 0) goto L_0x0005
            return
        L_0x0005:
            r0 = 1
            r4.f3342m1 = r0
            super.drawableStateChanged()
            int[] r1 = r4.getDrawableState()
            i63 r2 = r4.f3336j1
            r3 = 0
            if (r2 == 0) goto L_0x0037
            r2.f7221H = r1
            android.content.res.ColorStateList r1 = r2.f7246l
            if (r1 == 0) goto L_0x0020
            boolean r1 = r1.isStateful()
            if (r1 != 0) goto L_0x002a
        L_0x0020:
            android.content.res.ColorStateList r1 = r2.f7245k
            if (r1 == 0) goto L_0x002c
            boolean r1 = r1.isStateful()
            if (r1 == 0) goto L_0x002c
        L_0x002a:
            r1 = 1
            goto L_0x002d
        L_0x002c:
            r1 = 0
        L_0x002d:
            if (r1 == 0) goto L_0x0034
            r2.mo6873f()
            r1 = 1
            goto L_0x0035
        L_0x0034:
            r1 = 0
        L_0x0035:
            r1 = r1 | r3
            goto L_0x0038
        L_0x0037:
            r1 = 0
        L_0x0038:
            boolean r2 = p000.C2189w7.m15031z(r4)
            if (r2 == 0) goto L_0x0045
            boolean r2 = r4.isEnabled()
            if (r2 == 0) goto L_0x0045
            goto L_0x0046
        L_0x0045:
            r0 = 0
        L_0x0046:
            r4.mo3959a((boolean) r0)
            r4.mo4018p()
            r4.mo4021s()
            if (r1 == 0) goto L_0x0054
            r4.invalidate()
        L_0x0054:
            r4.f3342m1 = r3
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.textfield.TextInputLayout.drawableStateChanged():void");
    }

    /* renamed from: e */
    public final boolean mo3969e() {
        return this.f3353w0 > -1 && this.f3356z0 != 0;
    }

    /* renamed from: f */
    public final boolean mo3970f() {
        return this.f3343n0 && !TextUtils.isEmpty(this.f3345o0) && (this.f3347q0 instanceof b83);
    }

    /* renamed from: g */
    public final boolean mo3971g() {
        return this.f3304N0 != 0;
    }

    public int getBaseline() {
        EditText editText = this.f3321c0;
        if (editText == null) {
            return super.getBaseline();
        }
        return mo3964d() + getPaddingTop() + editText.getBaseline();
    }

    public f73 getBoxBackground() {
        int i = this.f3351u0;
        if (i == 1 || i == 2) {
            return this.f3347q0;
        }
        throw new IllegalStateException();
    }

    public int getBoxBackgroundColor() {
        return this.f3291A0;
    }

    public int getBoxBackgroundMode() {
        return this.f3351u0;
    }

    public float getBoxCornerRadiusBottomEnd() {
        f73 f73 = this.f3347q0;
        return f73.f5079X.f5101a.f8129h.mo251a(f73.mo5475b());
    }

    public float getBoxCornerRadiusBottomStart() {
        f73 f73 = this.f3347q0;
        return f73.f5079X.f5101a.f8128g.mo251a(f73.mo5475b());
    }

    public float getBoxCornerRadiusTopEnd() {
        f73 f73 = this.f3347q0;
        return f73.f5079X.f5101a.f8127f.mo251a(f73.mo5475b());
    }

    public float getBoxCornerRadiusTopStart() {
        return this.f3347q0.mo5490h();
    }

    public int getBoxStrokeColor() {
        return this.f3324d1;
    }

    public int getCounterMaxLength() {
        return this.f3329g0;
    }

    public CharSequence getCounterOverflowDescription() {
        TextView textView;
        if (!this.f3327f0 || !this.f3331h0 || (textView = this.f3333i0) == null) {
            return null;
        }
        return textView.getContentDescription();
    }

    public ColorStateList getCounterOverflowTextColor() {
        return this.f3339l0;
    }

    public ColorStateList getCounterTextColor() {
        return this.f3339l0;
    }

    public ColorStateList getDefaultHintTextColor() {
        return this.f3316Z0;
    }

    public EditText getEditText() {
        return this.f3321c0;
    }

    public CharSequence getEndIconContentDescription() {
        return this.f3306P0.getContentDescription();
    }

    public Drawable getEndIconDrawable() {
        return this.f3306P0.getDrawable();
    }

    public int getEndIconMode() {
        return this.f3304N0;
    }

    public CheckableImageButton getEndIconView() {
        return this.f3306P0;
    }

    public CharSequence getError() {
        f83 f83 = this.f3325e0;
        if (f83.f5168l) {
            return f83.f5167k;
        }
        return null;
    }

    public int getErrorCurrentTextColors() {
        return this.f3325e0.mo5526d();
    }

    public Drawable getErrorIconDrawable() {
        return this.f3314X0.getDrawable();
    }

    public final int getErrorTextCurrentColor() {
        return this.f3325e0.mo5526d();
    }

    public CharSequence getHelperText() {
        f83 f83 = this.f3325e0;
        if (f83.f5173q) {
            return f83.f5172p;
        }
        return null;
    }

    public int getHelperTextCurrentTextColor() {
        TextView textView = this.f3325e0.f5174r;
        if (textView != null) {
            return textView.getCurrentTextColor();
        }
        return -1;
    }

    public CharSequence getHint() {
        if (this.f3343n0) {
            return this.f3345o0;
        }
        return null;
    }

    public final float getHintCollapsedTextHeight() {
        return this.f3336j1.mo6868c();
    }

    public final int getHintCurrentCollapsedTextColor() {
        return this.f3336j1.mo6870d();
    }

    public ColorStateList getHintTextColor() {
        return this.f3318a1;
    }

    @Deprecated
    public CharSequence getPasswordVisibilityToggleContentDescription() {
        return this.f3306P0.getContentDescription();
    }

    @Deprecated
    public Drawable getPasswordVisibilityToggleDrawable() {
        return this.f3306P0.getDrawable();
    }

    public CharSequence getStartIconContentDescription() {
        return this.f3296F0.getContentDescription();
    }

    public Drawable getStartIconDrawable() {
        return this.f3296F0.getDrawable();
    }

    public Typeface getTypeface() {
        return this.f3295E0;
    }

    /* renamed from: h */
    public boolean mo4006h() {
        return this.f3319b0.getVisibility() == 0 && this.f3306P0.getVisibility() == 0;
    }

    /* renamed from: i */
    public boolean mo4007i() {
        return this.f3325e0.f5173q;
    }

    /* renamed from: j */
    public boolean mo4008j() {
        return this.f3346p0;
    }

    /* renamed from: k */
    public boolean mo4009k() {
        return this.f3296F0.getVisibility() == 0;
    }

    /* JADX WARNING: Removed duplicated region for block: B:27:0x006b  */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x0079  */
    /* JADX WARNING: Removed duplicated region for block: B:32:? A[RETURN, SYNTHETIC] */
    /* renamed from: l */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo4010l() {
        /*
            r4 = this;
            int r0 = r4.f3351u0
            r1 = 0
            r2 = 1
            if (r0 == 0) goto L_0x0051
            if (r0 == r2) goto L_0x0040
            r3 = 2
            if (r0 != r3) goto L_0x0027
            boolean r0 = r4.f3343n0
            if (r0 == 0) goto L_0x001d
            f73 r0 = r4.f3347q0
            boolean r0 = r0 instanceof p000.b83
            if (r0 != 0) goto L_0x001d
            b83 r0 = new b83
            j73 r3 = r4.f3349s0
            r0.<init>(r3)
            goto L_0x0024
        L_0x001d:
            f73 r0 = new f73
            j73 r3 = r4.f3349s0
            r0.<init>((p000.j73) r3)
        L_0x0024:
            r4.f3347q0 = r0
            goto L_0x0053
        L_0x0027:
            java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            int r2 = r4.f3351u0
            r1.append(r2)
            java.lang.String r2 = " is illegal; only @BoxBackgroundMode constants are supported."
            r1.append(r2)
            java.lang.String r1 = r1.toString()
            r0.<init>(r1)
            throw r0
        L_0x0040:
            f73 r0 = new f73
            j73 r1 = r4.f3349s0
            r0.<init>((p000.j73) r1)
            r4.f3347q0 = r0
            f73 r0 = new f73
            r0.<init>()
            r4.f3348r0 = r0
            goto L_0x0055
        L_0x0051:
            r4.f3347q0 = r1
        L_0x0053:
            r4.f3348r0 = r1
        L_0x0055:
            android.widget.EditText r0 = r4.f3321c0
            if (r0 == 0) goto L_0x0068
            f73 r1 = r4.f3347q0
            if (r1 == 0) goto L_0x0068
            android.graphics.drawable.Drawable r0 = r0.getBackground()
            if (r0 != 0) goto L_0x0068
            int r0 = r4.f3351u0
            if (r0 == 0) goto L_0x0068
            goto L_0x0069
        L_0x0068:
            r2 = 0
        L_0x0069:
            if (r2 == 0) goto L_0x0072
            android.widget.EditText r0 = r4.f3321c0
            f73 r1 = r4.f3347q0
            p000.C2189w7.m14987a((android.view.View) r0, (android.graphics.drawable.Drawable) r1)
        L_0x0072:
            r4.mo4021s()
            int r0 = r4.f3351u0
            if (r0 == 0) goto L_0x007c
            r4.mo4020r()
        L_0x007c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.textfield.TextInputLayout.mo4010l():void");
    }

    /* renamed from: m */
    public final void mo4011m() {
        if (mo3970f()) {
            RectF rectF = this.f3294D0;
            i63 i63 = this.f3336j1;
            boolean a = i63.mo6862a(i63.f7258x);
            Rect rect = i63.f7239e;
            rectF.left = !a ? (float) rect.left : ((float) rect.right) - i63.mo6856a();
            Rect rect2 = i63.f7239e;
            rectF.top = (float) rect2.top;
            rectF.right = !a ? i63.mo6856a() + rectF.left : (float) rect2.right;
            rectF.bottom = i63.mo6868c() + ((float) i63.f7239e.top);
            float f = rectF.left;
            float f2 = (float) this.f3350t0;
            rectF.left = f - f2;
            rectF.top -= f2;
            rectF.right += f2;
            rectF.bottom += f2;
            rectF.offset((float) (-getPaddingLeft()), 0.0f);
            ((b83) this.f3347q0).mo2362a(rectF);
        }
    }

    /* renamed from: n */
    public final void mo4012n() {
        if (this.f3333i0 != null) {
            EditText editText = this.f3321c0;
            mo3954a(editText == null ? 0 : editText.getText().length());
        }
    }

    /* renamed from: o */
    public final void mo4013o() {
        ColorStateList colorStateList;
        ColorStateList colorStateList2;
        TextView textView = this.f3333i0;
        if (textView != null) {
            mo3955a(textView, this.f3331h0 ? this.f3335j0 : this.f3337k0);
            if (!this.f3331h0 && (colorStateList2 = this.f3339l0) != null) {
                this.f3333i0.setTextColor(colorStateList2);
            }
            if (this.f3331h0 && (colorStateList = this.f3341m0) != null) {
                this.f3333i0.setTextColor(colorStateList);
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:19:0x0082  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x00b5  */
    /* JADX WARNING: Removed duplicated region for block: B:27:0x00c1  */
    /* JADX WARNING: Removed duplicated region for block: B:30:0x00db  */
    /* JADX WARNING: Removed duplicated region for block: B:31:0x00e1  */
    /* JADX WARNING: Removed duplicated region for block: B:36:0x00fe  */
    /* JADX WARNING: Removed duplicated region for block: B:37:0x0102  */
    /* JADX WARNING: Removed duplicated region for block: B:44:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onLayout(boolean r3, int r4, int r5, int r6, int r7) {
        /*
            r2 = this;
            super.onLayout(r3, r4, r5, r6, r7)
            android.widget.EditText r3 = r2.f3321c0
            if (r3 == 0) goto L_0x010e
            android.graphics.Rect r4 = r2.f3292B0
            p000.j63.m7343a((android.view.ViewGroup) r2, (android.view.View) r3, (android.graphics.Rect) r4)
            f73 r3 = r2.f3348r0
            if (r3 == 0) goto L_0x001d
            int r5 = r4.bottom
            int r6 = r2.f3355y0
            int r6 = r5 - r6
            int r7 = r4.left
            int r0 = r4.right
            r3.setBounds(r7, r6, r0, r5)
        L_0x001d:
            boolean r3 = r2.f3343n0
            if (r3 == 0) goto L_0x010e
            i63 r3 = r2.f3336j1
            android.widget.EditText r5 = r2.f3321c0
            if (r5 == 0) goto L_0x0108
            android.graphics.Rect r6 = r2.f3293C0
            int r7 = r4.bottom
            r6.bottom = r7
            int r7 = r2.f3351u0
            r0 = 1
            if (r7 == r0) goto L_0x005e
            r1 = 2
            if (r7 == r1) goto L_0x0043
            int r7 = r4.left
            int r5 = r5.getCompoundPaddingLeft()
            int r5 = r5 + r7
            r6.left = r5
            int r5 = r2.getPaddingTop()
            goto L_0x006c
        L_0x0043:
            int r7 = r4.left
            int r5 = r5.getPaddingLeft()
            int r5 = r5 + r7
            r6.left = r5
            int r5 = r4.top
            int r7 = r2.mo3964d()
            int r5 = r5 - r7
            r6.top = r5
            int r5 = r4.right
            android.widget.EditText r7 = r2.f3321c0
            int r7 = r7.getPaddingRight()
            goto L_0x0076
        L_0x005e:
            int r7 = r4.left
            int r5 = r5.getCompoundPaddingLeft()
            int r5 = r5 + r7
            r6.left = r5
            int r5 = r4.top
            int r7 = r2.f3352v0
            int r5 = r5 + r7
        L_0x006c:
            r6.top = r5
            int r5 = r4.right
            android.widget.EditText r7 = r2.f3321c0
            int r7 = r7.getCompoundPaddingRight()
        L_0x0076:
            int r5 = r5 - r7
            r6.right = r5
            r3.mo6860a((android.graphics.Rect) r6)
            i63 r3 = r2.f3336j1
            android.widget.EditText r5 = r2.f3321c0
            if (r5 == 0) goto L_0x0102
            android.graphics.Rect r5 = r2.f3293C0
            android.text.TextPaint r6 = r3.f7224K
            float r7 = r3.f7243i
            r6.setTextSize(r7)
            android.graphics.Typeface r7 = r3.f7254t
            r6.setTypeface(r7)
            android.text.TextPaint r6 = r3.f7224K
            float r6 = r6.ascent()
            float r6 = -r6
            int r7 = r4.left
            android.widget.EditText r1 = r2.f3321c0
            int r1 = r1.getCompoundPaddingLeft()
            int r1 = r1 + r7
            r5.left = r1
            int r7 = r2.f3351u0
            if (r7 != r0) goto L_0x00b2
            int r7 = android.os.Build.VERSION.SDK_INT
            android.widget.EditText r7 = r2.f3321c0
            int r7 = r7.getMinLines()
            if (r7 > r0) goto L_0x00b2
            r7 = 1
            goto L_0x00b3
        L_0x00b2:
            r7 = 0
        L_0x00b3:
            if (r7 == 0) goto L_0x00c1
            int r7 = r4.centerY()
            float r7 = (float) r7
            r1 = 1073741824(0x40000000, float:2.0)
            float r1 = r6 / r1
            float r7 = r7 - r1
            int r7 = (int) r7
            goto L_0x00ca
        L_0x00c1:
            int r7 = r4.top
            android.widget.EditText r1 = r2.f3321c0
            int r1 = r1.getCompoundPaddingTop()
            int r7 = r7 + r1
        L_0x00ca:
            r5.top = r7
            int r7 = r4.right
            android.widget.EditText r1 = r2.f3321c0
            int r1 = r1.getCompoundPaddingRight()
            int r7 = r7 - r1
            r5.right = r7
            int r7 = r2.f3351u0
            if (r7 != r0) goto L_0x00e1
            int r4 = r5.top
            float r4 = (float) r4
            float r4 = r4 + r6
            int r4 = (int) r4
            goto L_0x00ea
        L_0x00e1:
            int r4 = r4.bottom
            android.widget.EditText r6 = r2.f3321c0
            int r6 = r6.getCompoundPaddingBottom()
            int r4 = r4 - r6
        L_0x00ea:
            r5.bottom = r4
            r3.mo6866b((android.graphics.Rect) r5)
            i63 r3 = r2.f3336j1
            r3.mo6873f()
            boolean r3 = r2.mo3970f()
            if (r3 == 0) goto L_0x010e
            boolean r3 = r2.f3334i1
            if (r3 != 0) goto L_0x010e
            r2.mo4011m()
            goto L_0x010e
        L_0x0102:
            java.lang.IllegalStateException r3 = new java.lang.IllegalStateException
            r3.<init>()
            throw r3
        L_0x0108:
            java.lang.IllegalStateException r3 = new java.lang.IllegalStateException
            r3.<init>()
            throw r3
        L_0x010e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.textfield.TextInputLayout.onLayout(boolean, int, int, int, int):void");
    }

    public void onMeasure(int i, int i2) {
        int max;
        super.onMeasure(i, i2);
        boolean z = false;
        if (this.f3321c0 != null && this.f3321c0.getMeasuredHeight() < (max = Math.max(this.f3306P0.getMeasuredHeight(), this.f3296F0.getMeasuredHeight()))) {
            this.f3321c0.setMinimumHeight(max);
            z = true;
        }
        boolean q = mo4019q();
        if (z || q) {
            this.f3321c0.post(new C0467c());
        }
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof C0472h)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        C0472h hVar = (C0472h) parcelable;
        super.onRestoreInstanceState(hVar.f14707X);
        setError(hVar.f3362Z);
        if (hVar.f3363a0) {
            this.f3306P0.post(new C0466b());
        }
        requestLayout();
    }

    public Parcelable onSaveInstanceState() {
        C0472h hVar = new C0472h(super.onSaveInstanceState());
        if (this.f3325e0.mo5525c()) {
            hVar.f3362Z = getError();
        }
        hVar.f3363a0 = mo3971g() && this.f3306P0.isChecked();
        return hVar;
    }

    /* renamed from: p */
    public void mo4018p() {
        Drawable background;
        TextView textView;
        int currentTextColor;
        EditText editText = this.f3321c0;
        if (editText != null && this.f3351u0 == 0 && (background = editText.getBackground()) != null) {
            if (C0279b3.m1706a(background)) {
                background = background.mutate();
            }
            if (this.f3325e0.mo5525c()) {
                currentTextColor = this.f3325e0.mo5526d();
            } else if (!this.f3331h0 || (textView = this.f3333i0) == null) {
                C0815h0.m5799a(background);
                this.f3321c0.refreshDrawableState();
                return;
            } else {
                currentTextColor = textView.getCurrentTextColor();
            }
            background.setColorFilter(C0820h2.m5928a(currentTextColor, PorterDuff.Mode.SRC_IN));
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:28:0x008f  */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x00d4  */
    /* renamed from: q */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean mo4019q() {
        /*
            r11 = this;
            android.widget.EditText r0 = r11.f3321c0
            r1 = 0
            if (r0 != 0) goto L_0x0006
            return r1
        L_0x0006:
            android.graphics.drawable.Drawable r0 = r11.getStartIconDrawable()
            r2 = 1
            if (r0 == 0) goto L_0x000f
            r0 = 1
            goto L_0x0010
        L_0x000f:
            r0 = 0
        L_0x0010:
            r3 = 0
            r4 = 3
            r5 = 2
            if (r0 == 0) goto L_0x0067
            boolean r0 = r11.mo4009k()
            if (r0 == 0) goto L_0x0067
            com.google.android.material.internal.CheckableImageButton r0 = r11.f3296F0
            int r0 = r0.getMeasuredWidth()
            if (r0 <= 0) goto L_0x0067
            android.graphics.drawable.Drawable r0 = r11.f3301K0
            if (r0 != 0) goto L_0x004d
            android.graphics.drawable.ColorDrawable r0 = new android.graphics.drawable.ColorDrawable
            r0.<init>()
            r11.f3301K0 = r0
            com.google.android.material.internal.CheckableImageButton r0 = r11.f3296F0
            int r0 = r0.getMeasuredWidth()
            android.widget.EditText r6 = r11.f3321c0
            int r6 = r6.getPaddingLeft()
            int r0 = r0 - r6
            com.google.android.material.internal.CheckableImageButton r6 = r11.f3296F0
            android.view.ViewGroup$LayoutParams r6 = r6.getLayoutParams()
            android.view.ViewGroup$MarginLayoutParams r6 = (android.view.ViewGroup.MarginLayoutParams) r6
            int r6 = p000.C0815h0.m5774a((android.view.ViewGroup.MarginLayoutParams) r6)
            int r6 = r6 + r0
            android.graphics.drawable.Drawable r0 = r11.f3301K0
            r0.setBounds(r1, r1, r6, r2)
        L_0x004d:
            android.widget.EditText r0 = r11.f3321c0
            android.graphics.drawable.Drawable[] r0 = p000.C0815h0.m5830a((android.widget.TextView) r0)
            r6 = r0[r1]
            android.graphics.drawable.Drawable r7 = r11.f3301K0
            if (r6 == r7) goto L_0x0082
            android.widget.EditText r6 = r11.f3321c0
            r8 = r0[r2]
            r9 = r0[r5]
            r0 = r0[r4]
            int r10 = android.os.Build.VERSION.SDK_INT
            r6.setCompoundDrawablesRelative(r7, r8, r9, r0)
            goto L_0x0080
        L_0x0067:
            android.graphics.drawable.Drawable r0 = r11.f3301K0
            if (r0 == 0) goto L_0x0082
            android.widget.EditText r0 = r11.f3321c0
            android.graphics.drawable.Drawable[] r0 = p000.C0815h0.m5830a((android.widget.TextView) r0)
            android.widget.EditText r6 = r11.f3321c0
            r7 = r0[r2]
            r8 = r0[r5]
            r0 = r0[r4]
            int r9 = android.os.Build.VERSION.SDK_INT
            r6.setCompoundDrawablesRelative(r3, r7, r8, r0)
            r11.f3301K0 = r3
        L_0x0080:
            r0 = 1
            goto L_0x0083
        L_0x0082:
            r0 = 0
        L_0x0083:
            com.google.android.material.internal.CheckableImageButton r6 = r11.getEndIconToUpdateDummyDrawable()
            if (r6 == 0) goto L_0x00d4
            int r7 = r6.getMeasuredWidth()
            if (r7 <= 0) goto L_0x00d4
            android.graphics.drawable.Drawable r3 = r11.f3312V0
            if (r3 != 0) goto L_0x00b5
            android.graphics.drawable.ColorDrawable r3 = new android.graphics.drawable.ColorDrawable
            r3.<init>()
            r11.f3312V0 = r3
            int r3 = r6.getMeasuredWidth()
            android.widget.EditText r7 = r11.f3321c0
            int r7 = r7.getPaddingRight()
            int r3 = r3 - r7
            android.view.ViewGroup$LayoutParams r6 = r6.getLayoutParams()
            android.view.ViewGroup$MarginLayoutParams r6 = (android.view.ViewGroup.MarginLayoutParams) r6
            int r6 = p000.C0815h0.m5837b((android.view.ViewGroup.MarginLayoutParams) r6)
            int r6 = r6 + r3
            android.graphics.drawable.Drawable r3 = r11.f3312V0
            r3.setBounds(r1, r1, r6, r2)
        L_0x00b5:
            android.widget.EditText r3 = r11.f3321c0
            android.graphics.drawable.Drawable[] r3 = p000.C0815h0.m5830a((android.widget.TextView) r3)
            r6 = r3[r5]
            android.graphics.drawable.Drawable r7 = r11.f3312V0
            if (r6 == r7) goto L_0x00f6
            r0 = r3[r5]
            r11.f3313W0 = r0
            android.widget.EditText r0 = r11.f3321c0
            r1 = r3[r1]
            r5 = r3[r2]
            r3 = r3[r4]
            int r4 = android.os.Build.VERSION.SDK_INT
            r0.setCompoundDrawablesRelative(r1, r5, r7, r3)
            r0 = 1
            goto L_0x00f6
        L_0x00d4:
            android.graphics.drawable.Drawable r6 = r11.f3312V0
            if (r6 == 0) goto L_0x00f6
            android.widget.EditText r6 = r11.f3321c0
            android.graphics.drawable.Drawable[] r6 = p000.C0815h0.m5830a((android.widget.TextView) r6)
            r5 = r6[r5]
            android.graphics.drawable.Drawable r7 = r11.f3312V0
            if (r5 != r7) goto L_0x00f4
            android.widget.EditText r0 = r11.f3321c0
            r1 = r6[r1]
            r5 = r6[r2]
            android.graphics.drawable.Drawable r7 = r11.f3313W0
            r4 = r6[r4]
            int r6 = android.os.Build.VERSION.SDK_INT
            r0.setCompoundDrawablesRelative(r1, r5, r7, r4)
            r0 = 1
        L_0x00f4:
            r11.f3312V0 = r3
        L_0x00f6:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.textfield.TextInputLayout.mo4019q():boolean");
    }

    /* renamed from: r */
    public final void mo4020r() {
        if (this.f3351u0 != 1) {
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.f3317a0.getLayoutParams();
            int d = mo3964d();
            if (d != layoutParams.topMargin) {
                layoutParams.topMargin = d;
                this.f3317a0.requestLayout();
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:6:0x0012, code lost:
        r0 = r6.f3321c0;
     */
    /* renamed from: s */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo4021s() {
        /*
            r6 = this;
            f73 r0 = r6.f3347q0
            if (r0 == 0) goto L_0x00e4
            int r0 = r6.f3351u0
            if (r0 != 0) goto L_0x000a
            goto L_0x00e4
        L_0x000a:
            boolean r0 = r6.isFocused()
            r1 = 0
            r2 = 1
            if (r0 != 0) goto L_0x001f
            android.widget.EditText r0 = r6.f3321c0
            if (r0 == 0) goto L_0x001d
            boolean r0 = r0.hasFocus()
            if (r0 == 0) goto L_0x001d
            goto L_0x001f
        L_0x001d:
            r0 = 0
            goto L_0x0020
        L_0x001f:
            r0 = 1
        L_0x0020:
            boolean r3 = r6.isHovered()
            if (r3 != 0) goto L_0x0033
            android.widget.EditText r3 = r6.f3321c0
            if (r3 == 0) goto L_0x0031
            boolean r3 = r3.isHovered()
            if (r3 == 0) goto L_0x0031
            goto L_0x0033
        L_0x0031:
            r3 = 0
            goto L_0x0034
        L_0x0033:
            r3 = 1
        L_0x0034:
            boolean r4 = r6.isEnabled()
            if (r4 != 0) goto L_0x003f
            int r4 = r6.f3332h1
        L_0x003c:
            r6.f3356z0 = r4
            goto L_0x0068
        L_0x003f:
            f83 r4 = r6.f3325e0
            boolean r4 = r4.mo5525c()
            if (r4 == 0) goto L_0x004e
            f83 r4 = r6.f3325e0
            int r4 = r4.mo5526d()
            goto L_0x003c
        L_0x004e:
            boolean r4 = r6.f3331h0
            if (r4 == 0) goto L_0x005b
            android.widget.TextView r4 = r6.f3333i0
            if (r4 == 0) goto L_0x005b
            int r4 = r4.getCurrentTextColor()
            goto L_0x003c
        L_0x005b:
            if (r0 == 0) goto L_0x0060
            int r4 = r6.f3324d1
            goto L_0x003c
        L_0x0060:
            if (r3 == 0) goto L_0x0065
            int r4 = r6.f3322c1
            goto L_0x003c
        L_0x0065:
            int r4 = r6.f3320b1
            goto L_0x003c
        L_0x0068:
            f83 r4 = r6.f3325e0
            boolean r4 = r4.mo5525c()
            if (r4 == 0) goto L_0x007c
            e83 r4 = r6.getEndIconDelegate()
            boolean r4 = r4.mo2852b()
            if (r4 == 0) goto L_0x007c
            r4 = 1
            goto L_0x007d
        L_0x007c:
            r4 = 0
        L_0x007d:
            if (r4 == 0) goto L_0x00a0
            android.graphics.drawable.Drawable r4 = r6.getEndIconDrawable()
            if (r4 == 0) goto L_0x00a0
            android.graphics.drawable.Drawable r4 = r6.getEndIconDrawable()
            android.graphics.drawable.Drawable r4 = p000.C0815h0.m5858e(r4)
            android.graphics.drawable.Drawable r4 = r4.mutate()
            f83 r5 = r6.f3325e0
            int r5 = r5.mo5526d()
            p000.C0815h0.m5845b((android.graphics.drawable.Drawable) r4, (int) r5)
            com.google.android.material.internal.CheckableImageButton r5 = r6.f3306P0
            r5.setImageDrawable(r4)
            goto L_0x00a3
        L_0x00a0:
            r6.mo3962b()
        L_0x00a3:
            android.graphics.drawable.Drawable r4 = r6.getErrorIconDrawable()
            if (r4 == 0) goto L_0x00b6
            f83 r4 = r6.f3325e0
            boolean r5 = r4.f5168l
            if (r5 == 0) goto L_0x00b6
            boolean r4 = r4.mo5525c()
            if (r4 == 0) goto L_0x00b6
            r1 = 1
        L_0x00b6:
            r6.setErrorIconVisible(r1)
            if (r3 != 0) goto L_0x00bd
            if (r0 == 0) goto L_0x00c6
        L_0x00bd:
            boolean r0 = r6.isEnabled()
            if (r0 == 0) goto L_0x00c6
            int r0 = r6.f3355y0
            goto L_0x00c8
        L_0x00c6:
            int r0 = r6.f3354x0
        L_0x00c8:
            r6.f3353w0 = r0
            int r0 = r6.f3351u0
            if (r0 != r2) goto L_0x00e1
            boolean r0 = r6.isEnabled()
            if (r0 != 0) goto L_0x00d9
            int r0 = r6.f3328f1
        L_0x00d6:
            r6.f3291A0 = r0
            goto L_0x00e1
        L_0x00d9:
            if (r3 == 0) goto L_0x00de
            int r0 = r6.f3330g1
            goto L_0x00d6
        L_0x00de:
            int r0 = r6.f3326e1
            goto L_0x00d6
        L_0x00e1:
            r6.mo3952a()
        L_0x00e4:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.textfield.TextInputLayout.mo4021s():void");
    }

    public void setBoxBackgroundColor(int i) {
        if (this.f3291A0 != i) {
            this.f3291A0 = i;
            this.f3326e1 = i;
            mo3952a();
        }
    }

    public void setBoxBackgroundColorResource(int i) {
        setBoxBackgroundColor(C2085v5.m14456a(getContext(), i));
    }

    public void setBoxBackgroundMode(int i) {
        if (i != this.f3351u0) {
            this.f3351u0 = i;
            if (this.f3321c0 != null) {
                mo4010l();
            }
        }
    }

    public void setBoxStrokeColor(int i) {
        if (this.f3324d1 != i) {
            this.f3324d1 = i;
            mo4021s();
        }
    }

    public void setCounterEnabled(boolean z) {
        if (this.f3327f0 != z) {
            if (z) {
                this.f3333i0 = new AppCompatTextView(getContext());
                this.f3333i0.setId(f33.textinput_counter);
                Typeface typeface = this.f3295E0;
                if (typeface != null) {
                    this.f3333i0.setTypeface(typeface);
                }
                this.f3333i0.setMaxLines(1);
                this.f3325e0.mo5516a(this.f3333i0, 2);
                mo4013o();
                mo4012n();
            } else {
                this.f3325e0.mo5523b(this.f3333i0, 2);
                this.f3333i0 = null;
            }
            this.f3327f0 = z;
        }
    }

    public void setCounterMaxLength(int i) {
        if (this.f3329g0 != i) {
            if (i <= 0) {
                i = -1;
            }
            this.f3329g0 = i;
            if (this.f3327f0) {
                mo4012n();
            }
        }
    }

    public void setCounterOverflowTextAppearance(int i) {
        if (this.f3335j0 != i) {
            this.f3335j0 = i;
            mo4013o();
        }
    }

    public void setCounterOverflowTextColor(ColorStateList colorStateList) {
        if (this.f3341m0 != colorStateList) {
            this.f3341m0 = colorStateList;
            mo4013o();
        }
    }

    public void setCounterTextAppearance(int i) {
        if (this.f3337k0 != i) {
            this.f3337k0 = i;
            mo4013o();
        }
    }

    public void setCounterTextColor(ColorStateList colorStateList) {
        if (this.f3339l0 != colorStateList) {
            this.f3339l0 = colorStateList;
            mo4013o();
        }
    }

    public void setDefaultHintTextColor(ColorStateList colorStateList) {
        this.f3316Z0 = colorStateList;
        this.f3318a1 = colorStateList;
        if (this.f3321c0 != null) {
            mo3959a(false);
        }
    }

    public void setEnabled(boolean z) {
        m3141a((ViewGroup) this, z);
        super.setEnabled(z);
    }

    public void setEndIconActivated(boolean z) {
        this.f3306P0.setActivated(z);
    }

    public void setEndIconCheckable(boolean z) {
        this.f3306P0.setCheckable(z);
    }

    public void setEndIconContentDescription(int i) {
        setEndIconContentDescription(i != 0 ? getResources().getText(i) : null);
    }

    public void setEndIconContentDescription(CharSequence charSequence) {
        if (getEndIconContentDescription() != charSequence) {
            this.f3306P0.setContentDescription(charSequence);
        }
    }

    public void setEndIconDrawable(int i) {
        setEndIconDrawable(i != 0 ? C1206l0.m8461c(getContext(), i) : null);
    }

    public void setEndIconDrawable(Drawable drawable) {
        this.f3306P0.setImageDrawable(drawable);
    }

    public void setEndIconMode(int i) {
        int i2 = this.f3304N0;
        this.f3304N0 = i;
        setEndIconVisible(i != 0);
        if (getEndIconDelegate().mo2850a(this.f3351u0)) {
            getEndIconDelegate().mo272a();
            mo3962b();
            Iterator it = this.f3307Q0.iterator();
            while (it.hasNext()) {
                ((h83.C0842c) it.next()).mo6464a(this, i2);
            }
            return;
        }
        StringBuilder a = C0789gk.m5562a("The current box background mode ");
        a.append(this.f3351u0);
        a.append(" is not supported by the end icon mode ");
        a.append(i);
        throw new IllegalStateException(a.toString());
    }

    public void setEndIconOnClickListener(View.OnClickListener onClickListener) {
        CheckableImageButton checkableImageButton = this.f3306P0;
        View.OnLongClickListener onLongClickListener = this.f3315Y0;
        checkableImageButton.setOnClickListener(onClickListener);
        m3142a(checkableImageButton, onLongClickListener);
    }

    public void setEndIconOnLongClickListener(View.OnLongClickListener onLongClickListener) {
        this.f3315Y0 = onLongClickListener;
        CheckableImageButton checkableImageButton = this.f3306P0;
        checkableImageButton.setOnLongClickListener(onLongClickListener);
        m3142a(checkableImageButton, onLongClickListener);
    }

    public void setEndIconTintList(ColorStateList colorStateList) {
        if (this.f3308R0 != colorStateList) {
            this.f3308R0 = colorStateList;
            this.f3309S0 = true;
            mo3962b();
        }
    }

    public void setEndIconTintMode(PorterDuff.Mode mode) {
        if (this.f3310T0 != mode) {
            this.f3310T0 = mode;
            this.f3311U0 = true;
            mo3962b();
        }
    }

    public void setEndIconVisible(boolean z) {
        if (mo4006h() != z) {
            this.f3306P0.setVisibility(z ? 0 : 4);
            mo4019q();
        }
    }

    public void setError(CharSequence charSequence) {
        if (!this.f3325e0.f5168l) {
            if (!TextUtils.isEmpty(charSequence)) {
                setErrorEnabled(true);
            } else {
                return;
            }
        }
        if (!TextUtils.isEmpty(charSequence)) {
            f83 f83 = this.f3325e0;
            f83.mo5520b();
            f83.f5167k = charSequence;
            f83.f5169m.setText(charSequence);
            if (f83.f5165i != 1) {
                f83.f5166j = 1;
            }
            f83.mo5514a(f83.f5165i, f83.f5166j, f83.mo5519a(f83.f5169m, charSequence));
            return;
        }
        this.f3325e0.mo5527e();
    }

    public void setErrorEnabled(boolean z) {
        f83 f83 = this.f3325e0;
        if (f83.f5168l != z) {
            f83.mo5520b();
            if (z) {
                f83.f5169m = new AppCompatTextView(f83.f5157a);
                f83.f5169m.setId(f33.textinput_error);
                Typeface typeface = f83.f5177u;
                if (typeface != null) {
                    f83.f5169m.setTypeface(typeface);
                }
                f83.mo5521b(f83.f5170n);
                f83.mo5515a(f83.f5171o);
                f83.f5169m.setVisibility(4);
                C2189w7.m15011g(f83.f5169m, 1);
                f83.mo5516a(f83.f5169m, 0);
            } else {
                f83.mo5527e();
                f83.mo5523b(f83.f5169m, 0);
                f83.f5169m = null;
                f83.f5158b.mo4018p();
                f83.f5158b.mo4021s();
            }
            f83.f5168l = z;
        }
    }

    public void setErrorIconDrawable(int i) {
        setErrorIconDrawable(i != 0 ? C1206l0.m8461c(getContext(), i) : null);
    }

    public void setErrorIconDrawable(Drawable drawable) {
        this.f3314X0.setImageDrawable(drawable);
        setErrorIconVisible(drawable != null && this.f3325e0.f5168l);
    }

    public void setErrorIconTintList(ColorStateList colorStateList) {
        Drawable drawable = this.f3314X0.getDrawable();
        if (drawable != null) {
            drawable = C0815h0.m5858e(drawable).mutate();
            C0815h0.m5802a(drawable, colorStateList);
        }
        if (this.f3314X0.getDrawable() != drawable) {
            this.f3314X0.setImageDrawable(drawable);
        }
    }

    public void setErrorIconTintMode(PorterDuff.Mode mode) {
        Drawable drawable = this.f3314X0.getDrawable();
        if (drawable != null) {
            drawable = C0815h0.m5858e(drawable).mutate();
            C0815h0.m5803a(drawable, mode);
        }
        if (this.f3314X0.getDrawable() != drawable) {
            this.f3314X0.setImageDrawable(drawable);
        }
    }

    public void setErrorTextAppearance(int i) {
        f83 f83 = this.f3325e0;
        f83.f5170n = i;
        TextView textView = f83.f5169m;
        if (textView != null) {
            f83.f5158b.mo3955a(textView, i);
        }
    }

    public void setErrorTextColor(ColorStateList colorStateList) {
        f83 f83 = this.f3325e0;
        f83.f5171o = colorStateList;
        TextView textView = f83.f5169m;
        if (textView != null && colorStateList != null) {
            textView.setTextColor(colorStateList);
        }
    }

    public void setHelperText(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            if (!mo4007i()) {
                setHelperTextEnabled(true);
            }
            f83 f83 = this.f3325e0;
            f83.mo5520b();
            f83.f5172p = charSequence;
            f83.f5174r.setText(charSequence);
            if (f83.f5165i != 2) {
                f83.f5166j = 2;
            }
            f83.mo5514a(f83.f5165i, f83.f5166j, f83.mo5519a(f83.f5174r, charSequence));
        } else if (mo4007i()) {
            setHelperTextEnabled(false);
        }
    }

    public void setHelperTextColor(ColorStateList colorStateList) {
        f83 f83 = this.f3325e0;
        f83.f5176t = colorStateList;
        TextView textView = f83.f5174r;
        if (textView != null && colorStateList != null) {
            textView.setTextColor(colorStateList);
        }
    }

    public void setHelperTextEnabled(boolean z) {
        f83 f83 = this.f3325e0;
        if (f83.f5173q != z) {
            f83.mo5520b();
            if (z) {
                f83.f5174r = new AppCompatTextView(f83.f5157a);
                f83.f5174r.setId(f33.textinput_helper_text);
                Typeface typeface = f83.f5177u;
                if (typeface != null) {
                    f83.f5174r.setTypeface(typeface);
                }
                f83.f5174r.setVisibility(4);
                C2189w7.m15011g(f83.f5174r, 1);
                f83.mo5524c(f83.f5175s);
                f83.mo5522b(f83.f5176t);
                f83.mo5516a(f83.f5174r, 1);
            } else {
                f83.mo5520b();
                if (f83.f5165i == 2) {
                    f83.f5166j = 0;
                }
                f83.mo5514a(f83.f5165i, f83.f5166j, f83.mo5519a(f83.f5174r, (CharSequence) null));
                f83.mo5523b(f83.f5174r, 1);
                f83.f5174r = null;
                f83.f5158b.mo4018p();
                f83.f5158b.mo4021s();
            }
            f83.f5173q = z;
        }
    }

    public void setHelperTextTextAppearance(int i) {
        f83 f83 = this.f3325e0;
        f83.f5175s = i;
        TextView textView = f83.f5174r;
        if (textView != null) {
            C0815h0.m5857d(textView, i);
        }
    }

    public void setHint(CharSequence charSequence) {
        if (this.f3343n0) {
            setHintInternal(charSequence);
            sendAccessibilityEvent(2048);
        }
    }

    public void setHintAnimationEnabled(boolean z) {
        this.f3338k1 = z;
    }

    public void setHintEnabled(boolean z) {
        if (z != this.f3343n0) {
            this.f3343n0 = z;
            if (!this.f3343n0) {
                this.f3346p0 = false;
                if (!TextUtils.isEmpty(this.f3345o0) && TextUtils.isEmpty(this.f3321c0.getHint())) {
                    this.f3321c0.setHint(this.f3345o0);
                }
                setHintInternal((CharSequence) null);
            } else {
                CharSequence hint = this.f3321c0.getHint();
                if (!TextUtils.isEmpty(hint)) {
                    if (TextUtils.isEmpty(this.f3345o0)) {
                        setHint(hint);
                    }
                    this.f3321c0.setHint((CharSequence) null);
                }
                this.f3346p0 = true;
            }
            if (this.f3321c0 != null) {
                mo4020r();
            }
        }
    }

    public void setHintTextAppearance(int i) {
        i63 i63 = this.f3336j1;
        s63 s63 = new s63(i63.f7235a.getContext(), i);
        ColorStateList colorStateList = s63.f13978b;
        if (colorStateList != null) {
            i63.f7246l = colorStateList;
        }
        float f = s63.f13977a;
        if (f != 0.0f) {
            i63.f7244j = f;
        }
        ColorStateList colorStateList2 = s63.f13982f;
        if (colorStateList2 != null) {
            i63.f7230Q = colorStateList2;
        }
        i63.f7228O = s63.f13983g;
        i63.f7229P = s63.f13984h;
        i63.f7227N = s63.f13985i;
        r63 r63 = i63.f7257w;
        if (r63 != null) {
            r63.f13417c = true;
        }
        i63.f7257w = new r63(new h63(i63), s63.mo10876b());
        s63.mo10874a(i63.f7235a.getContext(), (u63) i63.f7257w);
        i63.mo6873f();
        this.f3318a1 = this.f3336j1.f7246l;
        if (this.f3321c0 != null) {
            mo3959a(false);
            mo4020r();
        }
    }

    public void setHintTextColor(ColorStateList colorStateList) {
        if (this.f3318a1 != colorStateList) {
            if (this.f3316Z0 == null) {
                i63 i63 = this.f3336j1;
                if (i63.f7246l != colorStateList) {
                    i63.f7246l = colorStateList;
                    i63.mo6873f();
                }
            }
            this.f3318a1 = colorStateList;
            if (this.f3321c0 != null) {
                mo3959a(false);
            }
        }
    }

    @Deprecated
    public void setPasswordVisibilityToggleContentDescription(int i) {
        setPasswordVisibilityToggleContentDescription(i != 0 ? getResources().getText(i) : null);
    }

    @Deprecated
    public void setPasswordVisibilityToggleContentDescription(CharSequence charSequence) {
        this.f3306P0.setContentDescription(charSequence);
    }

    @Deprecated
    public void setPasswordVisibilityToggleDrawable(int i) {
        setPasswordVisibilityToggleDrawable(i != 0 ? C1206l0.m8461c(getContext(), i) : null);
    }

    @Deprecated
    public void setPasswordVisibilityToggleDrawable(Drawable drawable) {
        this.f3306P0.setImageDrawable(drawable);
    }

    @Deprecated
    public void setPasswordVisibilityToggleEnabled(boolean z) {
        if (z && this.f3304N0 != 1) {
            setEndIconMode(1);
        } else if (!z) {
            setEndIconMode(0);
        }
    }

    @Deprecated
    public void setPasswordVisibilityToggleTintList(ColorStateList colorStateList) {
        this.f3308R0 = colorStateList;
        this.f3309S0 = true;
        mo3962b();
    }

    @Deprecated
    public void setPasswordVisibilityToggleTintMode(PorterDuff.Mode mode) {
        this.f3310T0 = mode;
        this.f3311U0 = true;
        mo3962b();
    }

    public void setStartIconCheckable(boolean z) {
        this.f3296F0.setCheckable(z);
    }

    public void setStartIconContentDescription(int i) {
        setStartIconContentDescription(i != 0 ? getResources().getText(i) : null);
    }

    public void setStartIconContentDescription(CharSequence charSequence) {
        if (getStartIconContentDescription() != charSequence) {
            this.f3296F0.setContentDescription(charSequence);
        }
    }

    public void setStartIconDrawable(int i) {
        setStartIconDrawable(i != 0 ? C1206l0.m8461c(getContext(), i) : null);
    }

    public void setStartIconDrawable(Drawable drawable) {
        this.f3296F0.setImageDrawable(drawable);
        if (drawable != null) {
            setStartIconVisible(true);
            mo3963c();
            return;
        }
        setStartIconVisible(false);
        setStartIconOnClickListener((View.OnClickListener) null);
        setStartIconOnLongClickListener((View.OnLongClickListener) null);
        setStartIconContentDescription((CharSequence) null);
    }

    public void setStartIconOnClickListener(View.OnClickListener onClickListener) {
        CheckableImageButton checkableImageButton = this.f3296F0;
        View.OnLongClickListener onLongClickListener = this.f3302L0;
        checkableImageButton.setOnClickListener(onClickListener);
        m3142a(checkableImageButton, onLongClickListener);
    }

    public void setStartIconOnLongClickListener(View.OnLongClickListener onLongClickListener) {
        this.f3302L0 = onLongClickListener;
        CheckableImageButton checkableImageButton = this.f3296F0;
        checkableImageButton.setOnLongClickListener(onLongClickListener);
        m3142a(checkableImageButton, onLongClickListener);
    }

    public void setStartIconTintList(ColorStateList colorStateList) {
        if (this.f3297G0 != colorStateList) {
            this.f3297G0 = colorStateList;
            this.f3298H0 = true;
            mo3963c();
        }
    }

    public void setStartIconTintMode(PorterDuff.Mode mode) {
        if (this.f3299I0 != mode) {
            this.f3299I0 = mode;
            this.f3300J0 = true;
            mo3963c();
        }
    }

    public void setStartIconVisible(boolean z) {
        if (mo4009k() != z) {
            this.f3296F0.setVisibility(z ? 0 : 8);
            mo4019q();
        }
    }

    public void setTextInputAccessibilityDelegate(C0469e eVar) {
        EditText editText = this.f3321c0;
        if (editText != null) {
            C2189w7.m14988a((View) editText, (C0757g7) eVar);
        }
    }

    public void setTypeface(Typeface typeface) {
        if (typeface != this.f3295E0) {
            this.f3295E0 = typeface;
            this.f3336j1.mo6867b(typeface);
            f83 f83 = this.f3325e0;
            if (typeface != f83.f5177u) {
                f83.f5177u = typeface;
                f83.mo5517a(f83.f5169m, typeface);
                f83.mo5517a(f83.f5174r, typeface);
            }
            TextView textView = this.f3333i0;
            if (textView != null) {
                textView.setTypeface(typeface);
            }
        }
    }

    /* renamed from: a */
    public final void mo3952a() {
        f73 f73 = this.f3347q0;
        if (f73 != null) {
            f73.setShapeAppearanceModel(this.f3349s0);
            if (this.f3351u0 == 2 && mo3969e()) {
                this.f3347q0.mo5468a((float) this.f3353w0, this.f3356z0);
            }
            int i = this.f3291A0;
            if (this.f3351u0 == 1) {
                i = C0588e6.m3951a(this.f3291A0, C0680fe.m4659a(getContext(), b33.colorSurface, 0));
            }
            this.f3291A0 = i;
            this.f3347q0.mo5471a(ColorStateList.valueOf(this.f3291A0));
            if (this.f3304N0 == 3) {
                this.f3321c0.getBackground().invalidateSelf();
            }
            if (this.f3348r0 != null) {
                if (mo3969e()) {
                    this.f3348r0.mo5471a(ColorStateList.valueOf(this.f3356z0));
                }
                invalidate();
            }
            invalidate();
        }
    }

    /* renamed from: a */
    public static void m3142a(CheckableImageButton checkableImageButton, View.OnLongClickListener onLongClickListener) {
        boolean v = C2189w7.m15027v(checkableImageButton);
        boolean z = false;
        int i = 1;
        boolean z2 = onLongClickListener != null;
        if (v || z2) {
            z = true;
        }
        checkableImageButton.setFocusable(z);
        checkableImageButton.setClickable(v);
        checkableImageButton.setPressable(v);
        checkableImageButton.setLongClickable(z2);
        if (!z) {
            i = 2;
        }
        int i2 = Build.VERSION.SDK_INT;
        checkableImageButton.setImportantForAccessibility(i);
    }

    /* renamed from: a */
    public void mo3954a(int i) {
        boolean z = this.f3331h0;
        if (this.f3329g0 == -1) {
            this.f3333i0.setText(String.valueOf(i));
            this.f3333i0.setContentDescription((CharSequence) null);
            this.f3331h0 = false;
        } else {
            if (C2189w7.m15004d(this.f3333i0) == 1) {
                TextView textView = this.f3333i0;
                int i2 = Build.VERSION.SDK_INT;
                textView.setAccessibilityLiveRegion(0);
            }
            this.f3331h0 = i > this.f3329g0;
            Context context = getContext();
            this.f3333i0.setContentDescription(context.getString(this.f3331h0 ? j33.character_counter_overflowed_content_description : j33.character_counter_content_description, new Object[]{Integer.valueOf(i), Integer.valueOf(this.f3329g0)}));
            if (z != this.f3331h0) {
                mo4013o();
                if (this.f3331h0) {
                    TextView textView2 = this.f3333i0;
                    int i3 = Build.VERSION.SDK_INT;
                    textView2.setAccessibilityLiveRegion(1);
                }
            }
            this.f3333i0.setText(getContext().getString(j33.character_counter_pattern, new Object[]{Integer.valueOf(i), Integer.valueOf(this.f3329g0)}));
        }
        if (this.f3321c0 != null && z != this.f3331h0) {
            mo3959a(false);
            mo4021s();
            mo4018p();
        }
    }

    /* renamed from: a */
    public final void mo3960a(boolean z, boolean z2) {
        i63 i63;
        ColorStateList colorStateList;
        TextView textView;
        boolean isEnabled = isEnabled();
        EditText editText = this.f3321c0;
        boolean z3 = editText != null && !TextUtils.isEmpty(editText.getText());
        EditText editText2 = this.f3321c0;
        boolean z4 = editText2 != null && editText2.hasFocus();
        boolean c = this.f3325e0.mo5525c();
        ColorStateList colorStateList2 = this.f3316Z0;
        if (colorStateList2 != null) {
            i63 i632 = this.f3336j1;
            if (i632.f7246l != colorStateList2) {
                i632.f7246l = colorStateList2;
                i632.mo6873f();
            }
            i63 i633 = this.f3336j1;
            ColorStateList colorStateList3 = this.f3316Z0;
            if (i633.f7245k != colorStateList3) {
                i633.f7245k = colorStateList3;
                i633.mo6873f();
            }
        }
        if (!isEnabled) {
            this.f3336j1.mo6865b(ColorStateList.valueOf(this.f3332h1));
            i63 i634 = this.f3336j1;
            ColorStateList valueOf = ColorStateList.valueOf(this.f3332h1);
            if (i634.f7245k != valueOf) {
                i634.f7245k = valueOf;
                i634.mo6873f();
            }
        } else if (c) {
            i63 i635 = this.f3336j1;
            TextView textView2 = this.f3325e0.f5169m;
            i635.mo6865b(textView2 != null ? textView2.getTextColors() : null);
        } else {
            if (this.f3331h0 && (textView = this.f3333i0) != null) {
                i63 = this.f3336j1;
                colorStateList = textView.getTextColors();
            } else if (z4 && (colorStateList = this.f3318a1) != null) {
                i63 = this.f3336j1;
            }
            i63.mo6865b(colorStateList);
        }
        if (z3 || (isEnabled() && (z4 || c))) {
            if (z2 || this.f3334i1) {
                ValueAnimator valueAnimator = this.f3340l1;
                if (valueAnimator != null && valueAnimator.isRunning()) {
                    this.f3340l1.cancel();
                }
                if (!z || !this.f3338k1) {
                    this.f3336j1.mo6869c(1.0f);
                } else {
                    mo3953a(1.0f);
                }
                this.f3334i1 = false;
                if (mo3970f()) {
                    mo4011m();
                }
            }
        } else if (z2 || !this.f3334i1) {
            ValueAnimator valueAnimator2 = this.f3340l1;
            if (valueAnimator2 != null && valueAnimator2.isRunning()) {
                this.f3340l1.cancel();
            }
            if (!z || !this.f3338k1) {
                this.f3336j1.mo6869c(0.0f);
            } else {
                mo3953a(0.0f);
            }
            if (mo3970f() && (!((b83) this.f3347q0).f1754u0.isEmpty()) && mo3970f()) {
                ((b83) this.f3347q0).mo2361a(0.0f, 0.0f, 0.0f, 0.0f);
            }
            this.f3334i1 = true;
        }
    }
}
