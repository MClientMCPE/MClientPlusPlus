package com.google.android.material.bottomsheet;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import p000.C0759g8;
import p000.C2330y8;
import p002io.mrarm.mctoolbox.p003ui.AppBottomSheetDialog;

public class BottomSheetBehavior<V extends View> extends CoordinatorLayout.C0174c<V> {

    /* renamed from: K */
    public static final int f3052K = k33.Widget_Design_BottomSheet_Modal;

    /* renamed from: A */
    public int f3053A;

    /* renamed from: B */
    public WeakReference<V> f3054B;

    /* renamed from: C */
    public WeakReference<View> f3055C;

    /* renamed from: D */
    public final ArrayList<C0428d> f3056D = new ArrayList<>();

    /* renamed from: E */
    public VelocityTracker f3057E;

    /* renamed from: F */
    public int f3058F;

    /* renamed from: G */
    public int f3059G;

    /* renamed from: H */
    public boolean f3060H;

    /* renamed from: I */
    public Map<View, Integer> f3061I;

    /* renamed from: J */
    public final C2330y8.C2333c f3062J = new C0426b();

    /* renamed from: a */
    public int f3063a = 0;

    /* renamed from: b */
    public boolean f3064b = true;

    /* renamed from: c */
    public float f3065c;

    /* renamed from: d */
    public int f3066d;

    /* renamed from: e */
    public boolean f3067e;

    /* renamed from: f */
    public int f3068f;

    /* renamed from: g */
    public boolean f3069g;

    /* renamed from: h */
    public f73 f3070h;

    /* renamed from: i */
    public j73 f3071i;

    /* renamed from: j */
    public boolean f3072j;

    /* renamed from: k */
    public BottomSheetBehavior<V>.C0633f f3073k = null;

    /* renamed from: l */
    public ValueAnimator f3074l;

    /* renamed from: m */
    public int f3075m;

    /* renamed from: n */
    public int f3076n;

    /* renamed from: o */
    public int f3077o;

    /* renamed from: p */
    public float f3078p = 0.5f;

    /* renamed from: q */
    public int f3079q;

    /* renamed from: r */
    public float f3080r = -1.0f;

    /* renamed from: s */
    public boolean f3081s;

    /* renamed from: t */
    public boolean f3082t;

    /* renamed from: u */
    public int f3083u = 4;

    /* renamed from: v */
    public C2330y8 f3084v;

    /* renamed from: w */
    public boolean f3085w;

    /* renamed from: x */
    public int f3086x;

    /* renamed from: y */
    public boolean f3087y;

    /* renamed from: z */
    public int f3088z;

    /* renamed from: com.google.android.material.bottomsheet.BottomSheetBehavior$a */
    public class C0425a implements Runnable {

        /* renamed from: X */
        public final /* synthetic */ View f3089X;

        /* renamed from: Y */
        public final /* synthetic */ int f3090Y;

        public C0425a(View view, int i) {
            this.f3089X = view;
            this.f3090Y = i;
        }

        public void run() {
            BottomSheetBehavior.this.mo3408a(this.f3089X, this.f3090Y);
        }
    }

    /* renamed from: com.google.android.material.bottomsheet.BottomSheetBehavior$b */
    public class C0426b extends C2330y8.C2333c {
        public C0426b() {
        }

        /* renamed from: a */
        public int mo3360a(View view, int i, int i2) {
            return view.getLeft();
        }

        /* JADX WARNING: Code restructure failed: missing block: B:27:0x007c, code lost:
            if (java.lang.Math.abs(r8 - r6.f3092a.f3077o) < java.lang.Math.abs(r8 - r6.f3092a.f3079q)) goto L_0x007e;
         */
        /* JADX WARNING: Code restructure failed: missing block: B:42:0x00cb, code lost:
            if (java.lang.Math.abs(r8 - r0) < java.lang.Math.abs(r8 - r6.f3092a.f3079q)) goto L_0x007e;
         */
        /* renamed from: a */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void mo3361a(android.view.View r7, float r8, float r9) {
            /*
                r6 = this;
                r0 = 0
                r1 = 4
                r2 = 6
                r3 = 3
                int r4 = (r9 > r0 ? 1 : (r9 == r0 ? 0 : -1))
                if (r4 >= 0) goto L_0x0022
                com.google.android.material.bottomsheet.BottomSheetBehavior r8 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r9 = r8.f3064b
                if (r9 == 0) goto L_0x0013
            L_0x000e:
                int r8 = r8.f3076n
            L_0x0010:
                r1 = 3
                goto L_0x00ce
            L_0x0013:
                int r8 = r7.getTop()
                com.google.android.material.bottomsheet.BottomSheetBehavior r9 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r0 = r9.f3077o
                if (r8 <= r0) goto L_0x001f
                r8 = r0
                goto L_0x0082
            L_0x001f:
                int r8 = r9.f3075m
                goto L_0x0010
            L_0x0022:
                com.google.android.material.bottomsheet.BottomSheetBehavior r4 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r5 = r4.f3081s
                if (r5 == 0) goto L_0x004b
                boolean r4 = r4.mo3413a((android.view.View) r7, (float) r9)
                if (r4 == 0) goto L_0x004b
                int r4 = r7.getTop()
                com.google.android.material.bottomsheet.BottomSheetBehavior r5 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r5 = r5.f3079q
                if (r4 > r5) goto L_0x0044
                float r4 = java.lang.Math.abs(r8)
                float r5 = java.lang.Math.abs(r9)
                int r4 = (r4 > r5 ? 1 : (r4 == r5 ? 0 : -1))
                if (r4 >= 0) goto L_0x004b
            L_0x0044:
                com.google.android.material.bottomsheet.BottomSheetBehavior r8 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r8 = r8.f3053A
                r1 = 5
                goto L_0x00ce
            L_0x004b:
                int r0 = (r9 > r0 ? 1 : (r9 == r0 ? 0 : -1))
                if (r0 == 0) goto L_0x0087
                float r8 = java.lang.Math.abs(r8)
                float r9 = java.lang.Math.abs(r9)
                int r8 = (r8 > r9 ? 1 : (r8 == r9 ? 0 : -1))
                if (r8 <= 0) goto L_0x005c
                goto L_0x0087
            L_0x005c:
                com.google.android.material.bottomsheet.BottomSheetBehavior r8 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r9 = r8.f3064b
                if (r9 == 0) goto L_0x0065
            L_0x0062:
                int r8 = r8.f3079q
                goto L_0x00ce
            L_0x0065:
                int r8 = r7.getTop()
                com.google.android.material.bottomsheet.BottomSheetBehavior r9 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r9 = r9.f3077o
                int r9 = r8 - r9
                int r9 = java.lang.Math.abs(r9)
                com.google.android.material.bottomsheet.BottomSheetBehavior r0 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r0 = r0.f3079q
                int r8 = r8 - r0
                int r8 = java.lang.Math.abs(r8)
                if (r9 >= r8) goto L_0x0084
            L_0x007e:
                com.google.android.material.bottomsheet.BottomSheetBehavior r8 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r8 = r8.f3077o
            L_0x0082:
                r1 = 6
                goto L_0x00ce
            L_0x0084:
                com.google.android.material.bottomsheet.BottomSheetBehavior r8 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                goto L_0x0062
            L_0x0087:
                int r8 = r7.getTop()
                com.google.android.material.bottomsheet.BottomSheetBehavior r9 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                boolean r0 = r9.f3064b
                if (r0 == 0) goto L_0x00a8
                int r9 = r9.f3076n
                int r9 = r8 - r9
                int r9 = java.lang.Math.abs(r9)
                com.google.android.material.bottomsheet.BottomSheetBehavior r0 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r0 = r0.f3079q
                int r8 = r8 - r0
                int r8 = java.lang.Math.abs(r8)
                if (r9 >= r8) goto L_0x0084
                com.google.android.material.bottomsheet.BottomSheetBehavior r8 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                goto L_0x000e
            L_0x00a8:
                int r0 = r9.f3077o
                if (r8 >= r0) goto L_0x00bc
                int r9 = r9.f3079q
                int r9 = r8 - r9
                int r9 = java.lang.Math.abs(r9)
                if (r8 >= r9) goto L_0x007e
                com.google.android.material.bottomsheet.BottomSheetBehavior r8 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r8 = r8.f3075m
                goto L_0x0010
            L_0x00bc:
                int r9 = r8 - r0
                int r9 = java.lang.Math.abs(r9)
                com.google.android.material.bottomsheet.BottomSheetBehavior r0 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                int r0 = r0.f3079q
                int r8 = r8 - r0
                int r8 = java.lang.Math.abs(r8)
                if (r9 >= r8) goto L_0x0084
                goto L_0x007e
            L_0x00ce:
                com.google.android.material.bottomsheet.BottomSheetBehavior r9 = com.google.android.material.bottomsheet.BottomSheetBehavior.this
                r0 = 1
                r9.mo3409a((android.view.View) r7, (int) r1, (int) r8, (boolean) r0)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.bottomsheet.BottomSheetBehavior.C0426b.mo3361a(android.view.View, float, float):void");
        }

        /* renamed from: a */
        public void mo3363a(View view, int i, int i2, int i3, int i4) {
            BottomSheetBehavior.this.mo3405a(i2);
        }

        /* renamed from: b */
        public int mo3431b(View view) {
            BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.this;
            return bottomSheetBehavior.f3081s ? bottomSheetBehavior.f3053A : bottomSheetBehavior.f3079q;
        }

        /* renamed from: b */
        public int mo3364b(View view, int i, int i2) {
            int a = BottomSheetBehavior.this.mo3425j();
            BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.this;
            return C0815h0.m5771a(i, a, bottomSheetBehavior.f3081s ? bottomSheetBehavior.f3053A : bottomSheetBehavior.f3079q);
        }

        /* renamed from: b */
        public void mo3365b(int i) {
            if (i == 1) {
                BottomSheetBehavior.this.mo3421f(1);
            }
        }

        /* renamed from: b */
        public boolean mo3366b(View view, int i) {
            BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.this;
            int i2 = bottomSheetBehavior.f3083u;
            if (i2 == 1 || bottomSheetBehavior.f3060H) {
                return false;
            }
            if (i2 == 3 && bottomSheetBehavior.f3058F == i) {
                WeakReference<View> weakReference = bottomSheetBehavior.f3055C;
                View view2 = weakReference != null ? (View) weakReference.get() : null;
                if (view2 != null && view2.canScrollVertically(-1)) {
                    return false;
                }
            }
            WeakReference<V> weakReference2 = BottomSheetBehavior.this.f3054B;
            return weakReference2 != null && weakReference2.get() == view;
        }
    }

    /* renamed from: com.google.android.material.bottomsheet.BottomSheetBehavior$c */
    public class C0427c implements C0910i8 {

        /* renamed from: a */
        public final /* synthetic */ int f3093a;

        public C0427c(int i) {
            this.f3093a = i;
        }
    }

    /* renamed from: com.google.android.material.bottomsheet.BottomSheetBehavior$d */
    public static abstract class C0428d {
        /* renamed from: a */
        public abstract void mo3432a(View view, float f);
    }

    /* renamed from: com.google.android.material.bottomsheet.BottomSheetBehavior$e */
    public static class C0429e extends C1904t8 {
        public static final Parcelable.Creator<C0429e> CREATOR = new C0430a();

        /* renamed from: Z */
        public final int f3095Z;

        /* renamed from: a0 */
        public int f3096a0;

        /* renamed from: b0 */
        public boolean f3097b0;

        /* renamed from: c0 */
        public boolean f3098c0;

        /* renamed from: d0 */
        public boolean f3099d0;

        /* renamed from: com.google.android.material.bottomsheet.BottomSheetBehavior$e$a */
        public static class C0430a implements Parcelable.ClassLoaderCreator<C0429e> {
            public Object createFromParcel(Parcel parcel) {
                return new C0429e(parcel, (ClassLoader) null);
            }

            public Object[] newArray(int i) {
                return new C0429e[i];
            }

            public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new C0429e(parcel, classLoader);
            }
        }

        public C0429e(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f3095Z = parcel.readInt();
            this.f3096a0 = parcel.readInt();
            boolean z = false;
            this.f3097b0 = parcel.readInt() == 1;
            this.f3098c0 = parcel.readInt() == 1;
            this.f3099d0 = parcel.readInt() == 1 ? true : z;
        }

        public C0429e(Parcelable parcelable, BottomSheetBehavior<?> bottomSheetBehavior) {
            super(parcelable);
            this.f3095Z = bottomSheetBehavior.f3083u;
            this.f3096a0 = bottomSheetBehavior.f3066d;
            this.f3097b0 = bottomSheetBehavior.f3064b;
            this.f3098c0 = bottomSheetBehavior.f3081s;
            this.f3099d0 = bottomSheetBehavior.f3082t;
        }

        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeParcelable(this.f14707X, i);
            parcel.writeInt(this.f3095Z);
            parcel.writeInt(this.f3096a0);
            parcel.writeInt(this.f3097b0 ? 1 : 0);
            parcel.writeInt(this.f3098c0 ? 1 : 0);
            parcel.writeInt(this.f3099d0 ? 1 : 0);
        }
    }

    /* renamed from: com.google.android.material.bottomsheet.BottomSheetBehavior$f */
    public class C0431f implements Runnable {

        /* renamed from: X */
        public final View f3100X;

        /* renamed from: Y */
        public boolean f3101Y;

        /* renamed from: Z */
        public int f3102Z;

        public C0431f(View view, int i) {
            this.f3100X = view;
            this.f3102Z = i;
        }

        public void run() {
            C2330y8 y8Var = BottomSheetBehavior.this.f3084v;
            if (y8Var == null || !y8Var.mo12813a(true)) {
                BottomSheetBehavior.this.mo3421f(this.f3102Z);
            } else {
                C2189w7.m14991a(this.f3100X, (Runnable) this);
            }
            this.f3101Y = false;
        }
    }

    public BottomSheetBehavior() {
    }

    /* JADX WARNING: Code restructure failed: missing block: B:9:0x007c, code lost:
        r10 = r10.data;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public BottomSheetBehavior(android.content.Context r9, android.util.AttributeSet r10) {
        /*
            r8 = this;
            r8.<init>(r9, r10)
            r0 = 0
            r8.f3063a = r0
            r1 = 1
            r8.f3064b = r1
            r2 = 0
            r8.f3073k = r2
            r3 = 1056964608(0x3f000000, float:0.5)
            r8.f3078p = r3
            r4 = -1082130432(0xffffffffbf800000, float:-1.0)
            r8.f3080r = r4
            r5 = 4
            r8.f3083u = r5
            java.util.ArrayList r5 = new java.util.ArrayList
            r5.<init>()
            r8.f3056D = r5
            com.google.android.material.bottomsheet.BottomSheetBehavior$b r5 = new com.google.android.material.bottomsheet.BottomSheetBehavior$b
            r5.<init>()
            r8.f3062J = r5
            int[] r5 = p000.l33.BottomSheetBehavior_Layout
            android.content.res.TypedArray r5 = r9.obtainStyledAttributes(r10, r5)
            int r6 = p000.l33.BottomSheetBehavior_Layout_shapeAppearance
            boolean r6 = r5.hasValue(r6)
            r8.f3069g = r6
            int r6 = p000.l33.BottomSheetBehavior_Layout_backgroundTint
            boolean r6 = r5.hasValue(r6)
            if (r6 == 0) goto L_0x0045
            int r2 = p000.l33.BottomSheetBehavior_Layout_backgroundTint
            android.content.res.ColorStateList r2 = p000.t53.m13077a((android.content.Context) r9, (android.content.res.TypedArray) r5, (int) r2)
            r8.mo3407a((android.content.Context) r9, (android.util.AttributeSet) r10, (boolean) r6, (android.content.res.ColorStateList) r2)
            goto L_0x0048
        L_0x0045:
            r8.mo3407a((android.content.Context) r9, (android.util.AttributeSet) r10, (boolean) r6, (android.content.res.ColorStateList) r2)
        L_0x0048:
            r10 = 2
            float[] r10 = new float[r10]
            r10 = {0, 1065353216} // fill-array
            android.animation.ValueAnimator r10 = android.animation.ValueAnimator.ofFloat(r10)
            r8.f3074l = r10
            android.animation.ValueAnimator r10 = r8.f3074l
            r6 = 500(0x1f4, double:2.47E-321)
            r10.setDuration(r6)
            android.animation.ValueAnimator r10 = r8.f3074l
            l43 r2 = new l43
            r2.<init>(r8)
            r10.addUpdateListener(r2)
            int r10 = android.os.Build.VERSION.SDK_INT
            r2 = 21
            if (r10 < r2) goto L_0x0073
            int r10 = p000.l33.BottomSheetBehavior_Layout_android_elevation
            float r10 = r5.getDimension(r10, r4)
            r8.f3080r = r10
        L_0x0073:
            int r10 = p000.l33.BottomSheetBehavior_Layout_behavior_peekHeight
            android.util.TypedValue r10 = r5.peekValue(r10)
            r2 = -1
            if (r10 == 0) goto L_0x0081
            int r10 = r10.data
            if (r10 != r2) goto L_0x0081
            goto L_0x0087
        L_0x0081:
            int r10 = p000.l33.BottomSheetBehavior_Layout_behavior_peekHeight
            int r10 = r5.getDimensionPixelSize(r10, r2)
        L_0x0087:
            r8.mo3416c((int) r10)
            int r10 = p000.l33.BottomSheetBehavior_Layout_behavior_hideable
            boolean r10 = r5.getBoolean(r10, r0)
            r8.mo3415b((boolean) r10)
            int r10 = p000.l33.BottomSheetBehavior_Layout_behavior_fitToContents
            boolean r10 = r5.getBoolean(r10, r1)
            r8.mo3412a((boolean) r10)
            int r10 = p000.l33.BottomSheetBehavior_Layout_behavior_skipCollapsed
            boolean r10 = r5.getBoolean(r10, r0)
            r8.mo3417c((boolean) r10)
            int r10 = p000.l33.BottomSheetBehavior_Layout_behavior_saveFlags
            int r10 = r5.getInt(r10, r0)
            r8.mo3418d((int) r10)
            int r10 = p000.l33.BottomSheetBehavior_Layout_behavior_halfExpandedRatio
            float r10 = r5.getFloat(r10, r3)
            r8.mo3404a((float) r10)
            int r10 = p000.l33.BottomSheetBehavior_Layout_behavior_expandedOffset
            int r10 = r5.getInt(r10, r0)
            r8.mo3414b((int) r10)
            r5.recycle()
            android.view.ViewConfiguration r9 = android.view.ViewConfiguration.get(r9)
            int r9 = r9.getScaledMaximumFlingVelocity()
            float r9 = (float) r9
            r8.f3065c = r9
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.bottomsheet.BottomSheetBehavior.<init>(android.content.Context, android.util.AttributeSet):void");
    }

    /* renamed from: b */
    public static <V extends View> BottomSheetBehavior<V> m2945b(V v) {
        ViewGroup.LayoutParams layoutParams = v.getLayoutParams();
        if (layoutParams instanceof CoordinatorLayout.C0177f) {
            CoordinatorLayout.C0174c cVar = ((CoordinatorLayout.C0177f) layoutParams).f1038a;
            if (cVar instanceof BottomSheetBehavior) {
                return (BottomSheetBehavior) cVar;
            }
            throw new IllegalArgumentException("The view is not associated with BottomSheetBehavior");
        }
        throw new IllegalArgumentException("The view is not a child of CoordinatorLayout");
    }

    /* renamed from: a */
    public View mo3403a(View view) {
        if (C2189w7.m14969A(view)) {
            return view;
        }
        if (!(view instanceof ViewGroup)) {
            return null;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View a = mo3403a(viewGroup.getChildAt(i));
            if (a != null) {
                return a;
            }
        }
        return null;
    }

    /* renamed from: a */
    public void mo3404a(float f) {
        if (f <= 0.0f || f >= 1.0f) {
            throw new IllegalArgumentException("ratio must be a float value between 0 and 1");
        }
        this.f3078p = f;
    }

    /* renamed from: a */
    public void mo3405a(int i) {
        float f;
        float f2;
        View view = (View) this.f3054B.get();
        if (view != null && !this.f3056D.isEmpty()) {
            int i2 = this.f3079q;
            if (i > i2) {
                f = (float) (i2 - i);
                f2 = (float) (this.f3053A - i2);
            } else {
                f = (float) (i2 - i);
                f2 = (float) (i2 - mo3425j());
            }
            float f3 = f / f2;
            for (int i3 = 0; i3 < this.f3056D.size(); i3++) {
                this.f3056D.get(i3).mo3432a(view, f3);
            }
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:14:0x0025  */
    /* JADX WARNING: Removed duplicated region for block: B:23:? A[RETURN, SYNTHETIC] */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo3406a(int r4, boolean r5) {
        /*
            r3 = this;
            r0 = 1
            r1 = 0
            r2 = -1
            if (r4 != r2) goto L_0x000c
            boolean r4 = r3.f3067e
            if (r4 != 0) goto L_0x0015
            r3.f3067e = r0
            goto L_0x001f
        L_0x000c:
            boolean r2 = r3.f3067e
            if (r2 != 0) goto L_0x0017
            int r2 = r3.f3066d
            if (r2 == r4) goto L_0x0015
            goto L_0x0017
        L_0x0015:
            r0 = 0
            goto L_0x001f
        L_0x0017:
            r3.f3067e = r1
            int r4 = java.lang.Math.max(r1, r4)
            r3.f3066d = r4
        L_0x001f:
            if (r0 == 0) goto L_0x0042
            java.lang.ref.WeakReference<V> r4 = r3.f3054B
            if (r4 == 0) goto L_0x0042
            r3.mo3424i()
            int r4 = r3.f3083u
            r0 = 4
            if (r4 != r0) goto L_0x0042
            java.lang.ref.WeakReference<V> r4 = r3.f3054B
            java.lang.Object r4 = r4.get()
            android.view.View r4 = (android.view.View) r4
            if (r4 == 0) goto L_0x0042
            if (r5 == 0) goto L_0x003f
            int r4 = r3.f3083u
            r3.mo3422g(r4)
            goto L_0x0042
        L_0x003f:
            r4.requestLayout()
        L_0x0042:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.bottomsheet.BottomSheetBehavior.mo3406a(int, boolean):void");
    }

    /* renamed from: a */
    public final void mo3407a(Context context, AttributeSet attributeSet, boolean z, ColorStateList colorStateList) {
        if (this.f3069g) {
            this.f3071i = j73.m7354a(context, attributeSet, b33.bottomSheetStyle, f3052K).mo7445a();
            this.f3070h = new f73(this.f3071i);
            f73 f73 = this.f3070h;
            f73.f5079X.f5102b = new w53(context);
            f73.mo5496l();
            if (!z || colorStateList == null) {
                TypedValue typedValue = new TypedValue();
                context.getTheme().resolveAttribute(16842801, typedValue, true);
                this.f3070h.setTint(typedValue.data);
                return;
            }
            this.f3070h.mo5471a(colorStateList);
        }
    }

    /* renamed from: a */
    public void mo3408a(View view, int i) {
        int i2;
        int i3;
        if (i == 4) {
            i2 = this.f3079q;
        } else if (i == 6) {
            i2 = this.f3077o;
            if (this.f3064b && i2 <= (i3 = this.f3076n)) {
                i = 3;
                i2 = i3;
            }
        } else if (i == 3) {
            i2 = mo3425j();
        } else if (!this.f3081s || i != 5) {
            throw new IllegalArgumentException(C0789gk.m5568b("Illegal state argument: ", i));
        } else {
            i2 = this.f3053A;
        }
        mo3409a(view, i, i2, false);
    }

    /* renamed from: a */
    public final void mo3410a(V v, C0759g8.C0760a aVar, int i) {
        C2189w7.m14989a(v, aVar, (CharSequence) null, new C0427c(i));
    }

    /* renamed from: a */
    public void mo1254a(CoordinatorLayout.C0177f fVar) {
        this.f3054B = null;
        this.f3084v = null;
    }

    /* renamed from: a */
    public void mo1259a(CoordinatorLayout coordinatorLayout, V v, View view, int i, int i2, int i3, int i4, int i5, int[] iArr) {
    }

    /* renamed from: a */
    public void mo1260a(CoordinatorLayout coordinatorLayout, V v, View view, int i, int i2, int[] iArr, int i3) {
        int i4;
        if (i3 != 1) {
            WeakReference<View> weakReference = this.f3055C;
            if (view == (weakReference != null ? (View) weakReference.get() : null)) {
                int top = v.getTop();
                int i5 = top - i2;
                if (i2 <= 0) {
                    if (i2 < 0 && !view.canScrollVertically(-1)) {
                        int i6 = this.f3079q;
                        if (i5 <= i6 || this.f3081s) {
                            iArr[1] = i2;
                            C2189w7.m15007e(v, -i2);
                            mo3421f(1);
                        } else {
                            iArr[1] = top - i6;
                            C2189w7.m15007e(v, -iArr[1]);
                            i4 = 4;
                        }
                    }
                    mo3405a(v.getTop());
                    this.f3086x = i2;
                    this.f3087y = true;
                } else if (i5 < mo3425j()) {
                    iArr[1] = top - mo3425j();
                    C2189w7.m15007e(v, -iArr[1]);
                    i4 = 3;
                } else {
                    iArr[1] = i2;
                    C2189w7.m15007e(v, -i2);
                    mo3421f(1);
                    mo3405a(v.getTop());
                    this.f3086x = i2;
                    this.f3087y = true;
                }
                mo3421f(i4);
                mo3405a(v.getTop());
                this.f3086x = i2;
                this.f3087y = true;
            }
        }
    }

    /* renamed from: a */
    public void mo3411a(C0428d dVar) {
        if (!this.f3056D.contains(dVar)) {
            this.f3056D.add(dVar);
        }
    }

    /* renamed from: a */
    public void mo3412a(boolean z) {
        if (this.f3064b != z) {
            this.f3064b = z;
            if (this.f3054B != null) {
                mo3424i();
            }
            mo3421f((!this.f3064b || this.f3083u != 6) ? this.f3083u : 3);
            mo3429n();
        }
    }

    /* renamed from: a */
    public boolean mo3413a(View view, float f) {
        if (this.f3082t) {
            return true;
        }
        if (view.getTop() < this.f3079q) {
            return false;
        }
        return Math.abs(((f * 0.1f) + ((float) view.getTop())) - ((float) this.f3079q)) / ((float) this.f3066d) > 0.5f;
    }

    /* renamed from: a */
    public boolean mo1268a(CoordinatorLayout coordinatorLayout, V v, View view, float f, float f2) {
        WeakReference<View> weakReference = this.f3055C;
        if (weakReference == null || view != weakReference.get()) {
            return false;
        }
        if (this.f3083u != 3) {
            return true;
        }
        super.mo1268a(coordinatorLayout, v, view, f, f2);
        return false;
    }

    /* renamed from: b */
    public void mo3414b(int i) {
        if (i >= 0) {
            this.f3075m = i;
            return;
        }
        throw new IllegalArgumentException("offset must be greater than or equal to 0");
    }

    /* renamed from: b */
    public void mo3415b(boolean z) {
        if (this.f3081s != z) {
            this.f3081s = z;
            if (!z && this.f3083u == 5) {
                mo3420e(4);
            }
            mo3429n();
        }
    }

    /* renamed from: b */
    public boolean mo1274b(CoordinatorLayout coordinatorLayout, V v, View view, View view2, int i, int i2) {
        this.f3086x = 0;
        this.f3087y = false;
        return (i & 2) != 0;
    }

    /* renamed from: c */
    public void mo3416c(int i) {
        mo3406a(i, false);
    }

    /* renamed from: c */
    public void mo3417c(boolean z) {
        this.f3082t = z;
    }

    /* renamed from: d */
    public void mo1276d() {
        super.mo1276d();
        this.f3054B = null;
        this.f3084v = null;
    }

    /* renamed from: d */
    public void mo3418d(int i) {
        this.f3063a = i;
    }

    /* renamed from: d */
    public final void mo3419d(boolean z) {
        int i;
        WeakReference<V> weakReference = this.f3054B;
        if (weakReference != null) {
            ViewParent parent = ((View) weakReference.get()).getParent();
            if (parent instanceof CoordinatorLayout) {
                CoordinatorLayout coordinatorLayout = (CoordinatorLayout) parent;
                int childCount = coordinatorLayout.getChildCount();
                int i2 = Build.VERSION.SDK_INT;
                if (z) {
                    if (this.f3061I == null) {
                        this.f3061I = new HashMap(childCount);
                    } else {
                        return;
                    }
                }
                for (int i3 = 0; i3 < childCount; i3++) {
                    View childAt = coordinatorLayout.getChildAt(i3);
                    if (childAt != this.f3054B.get()) {
                        if (!z) {
                            Map<View, Integer> map = this.f3061I;
                            if (map != null && map.containsKey(childAt)) {
                                i = this.f3061I.get(childAt).intValue();
                            }
                        } else {
                            int i4 = Build.VERSION.SDK_INT;
                            this.f3061I.put(childAt, Integer.valueOf(childAt.getImportantForAccessibility()));
                            i = 4;
                        }
                        C2189w7.m15013h(childAt, i);
                    }
                }
                if (!z) {
                    this.f3061I = null;
                }
            }
        }
    }

    /* renamed from: e */
    public void mo3420e(int i) {
        if (i != this.f3083u) {
            if (this.f3054B != null) {
                mo3422g(i);
            } else if (i == 4 || i == 3 || i == 6 || (this.f3081s && i == 5)) {
                this.f3083u = i;
            }
        }
    }

    /* renamed from: f */
    public void mo3421f(int i) {
        if (this.f3083u != i) {
            this.f3083u = i;
            WeakReference<V> weakReference = this.f3054B;
            if (weakReference != null && ((View) weakReference.get()) != null) {
                if (i == 6 || i == 3) {
                    mo3419d(true);
                } else if (i == 5 || i == 4) {
                    mo3419d(false);
                }
                mo3423h(i);
                for (int i2 = 0; i2 < this.f3056D.size(); i2++) {
                    AppBottomSheetDialog.C0952a aVar = (AppBottomSheetDialog.C0952a) this.f3056D.get(i2);
                    if (i == 5) {
                        AppBottomSheetDialog.this.dismiss();
                    }
                    aVar.f7814a.mo7151a(i != 3, true);
                }
                mo3429n();
            }
        }
    }

    /* renamed from: g */
    public final void mo3422g(int i) {
        View view = (View) this.f3054B.get();
        if (view != null) {
            ViewParent parent = view.getParent();
            if (parent == null || !parent.isLayoutRequested() || !C2189w7.m15030y(view)) {
                mo3408a(view, i);
            } else {
                view.post(new C0425a(view, i));
            }
        }
    }

    /* renamed from: h */
    public final void mo3423h(int i) {
        ValueAnimator valueAnimator;
        if (i != 2) {
            boolean z = i == 3;
            if (this.f3072j != z) {
                this.f3072j = z;
                if (this.f3070h != null && (valueAnimator = this.f3074l) != null) {
                    if (valueAnimator.isRunning()) {
                        this.f3074l.reverse();
                        return;
                    }
                    float f = z ? 0.0f : 1.0f;
                    this.f3074l.setFloatValues(new float[]{1.0f - f, f});
                    this.f3074l.start();
                }
            }
        }
    }

    /* renamed from: i */
    public final void mo3424i() {
        int max = this.f3067e ? Math.max(this.f3068f, this.f3053A - ((this.f3088z * 9) / 16)) : this.f3066d;
        if (this.f3064b) {
            this.f3079q = Math.max(this.f3053A - max, this.f3076n);
        } else {
            this.f3079q = this.f3053A - max;
        }
    }

    /* renamed from: j */
    public final int mo3425j() {
        return this.f3064b ? this.f3076n : this.f3075m;
    }

    /* renamed from: k */
    public int mo3426k() {
        if (this.f3067e) {
            return -1;
        }
        return this.f3066d;
    }

    /* renamed from: l */
    public boolean mo3427l() {
        return this.f3082t;
    }

    /* renamed from: m */
    public int mo3428m() {
        return this.f3083u;
    }

    /* renamed from: n */
    public final void mo3429n() {
        View view;
        C0759g8.C0760a aVar;
        WeakReference<V> weakReference = this.f3054B;
        if (weakReference != null && (view = (View) weakReference.get()) != null) {
            C2189w7.m15009f(view, 524288);
            C2189w7.m15009f(view, 262144);
            C2189w7.m15009f(view, 1048576);
            if (this.f3081s && this.f3083u != 5) {
                mo3410a(view, C0759g8.C0760a.f6034h, 5);
            }
            int i = this.f3083u;
            int i2 = 6;
            if (i == 3) {
                if (this.f3064b) {
                    i2 = 4;
                }
                aVar = C0759g8.C0760a.f6033g;
            } else if (i == 4) {
                if (this.f3064b) {
                    i2 = 3;
                }
                aVar = C0759g8.C0760a.f6032f;
            } else if (i == 6) {
                mo3410a(view, C0759g8.C0760a.f6033g, 4);
                mo3410a(view, C0759g8.C0760a.f6032f, 3);
                return;
            } else {
                return;
            }
            mo3410a(view, aVar, i2);
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r11v11, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v2, resolved type: android.view.View} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean mo1266a(androidx.coordinatorlayout.widget.CoordinatorLayout r10, V r11, android.view.MotionEvent r12) {
        /*
            r9 = this;
            boolean r0 = r11.isShown()
            r1 = 0
            r2 = 1
            if (r0 != 0) goto L_0x000b
            r9.f3085w = r2
            return r1
        L_0x000b:
            int r0 = r12.getActionMasked()
            r3 = 0
            r4 = -1
            if (r0 != 0) goto L_0x001e
            r9.f3058F = r4
            android.view.VelocityTracker r5 = r9.f3057E
            if (r5 == 0) goto L_0x001e
            r5.recycle()
            r9.f3057E = r3
        L_0x001e:
            android.view.VelocityTracker r5 = r9.f3057E
            if (r5 != 0) goto L_0x0028
            android.view.VelocityTracker r5 = android.view.VelocityTracker.obtain()
            r9.f3057E = r5
        L_0x0028:
            android.view.VelocityTracker r5 = r9.f3057E
            r5.addMovement(r12)
            r5 = 2
            if (r0 == 0) goto L_0x0041
            if (r0 == r2) goto L_0x0036
            r11 = 3
            if (r0 == r11) goto L_0x0036
            goto L_0x0084
        L_0x0036:
            r9.f3060H = r1
            r9.f3058F = r4
            boolean r11 = r9.f3085w
            if (r11 == 0) goto L_0x0084
            r9.f3085w = r1
            return r1
        L_0x0041:
            float r6 = r12.getX()
            int r6 = (int) r6
            float r7 = r12.getY()
            int r7 = (int) r7
            r9.f3059G = r7
            int r7 = r9.f3083u
            if (r7 == r5) goto L_0x0073
            java.lang.ref.WeakReference<android.view.View> r7 = r9.f3055C
            if (r7 == 0) goto L_0x005c
            java.lang.Object r7 = r7.get()
            android.view.View r7 = (android.view.View) r7
            goto L_0x005d
        L_0x005c:
            r7 = r3
        L_0x005d:
            if (r7 == 0) goto L_0x0073
            int r8 = r9.f3059G
            boolean r7 = r10.mo1205a((android.view.View) r7, (int) r6, (int) r8)
            if (r7 == 0) goto L_0x0073
            int r7 = r12.getActionIndex()
            int r7 = r12.getPointerId(r7)
            r9.f3058F = r7
            r9.f3060H = r2
        L_0x0073:
            int r7 = r9.f3058F
            if (r7 != r4) goto L_0x0081
            int r4 = r9.f3059G
            boolean r11 = r10.mo1205a((android.view.View) r11, (int) r6, (int) r4)
            if (r11 != 0) goto L_0x0081
            r11 = 1
            goto L_0x0082
        L_0x0081:
            r11 = 0
        L_0x0082:
            r9.f3085w = r11
        L_0x0084:
            boolean r11 = r9.f3085w
            if (r11 != 0) goto L_0x0093
            y8 r11 = r9.f3084v
            if (r11 == 0) goto L_0x0093
            boolean r11 = r11.mo12822c((android.view.MotionEvent) r12)
            if (r11 == 0) goto L_0x0093
            return r2
        L_0x0093:
            java.lang.ref.WeakReference<android.view.View> r11 = r9.f3055C
            if (r11 == 0) goto L_0x009e
            java.lang.Object r11 = r11.get()
            r3 = r11
            android.view.View r3 = (android.view.View) r3
        L_0x009e:
            if (r0 != r5) goto L_0x00d4
            if (r3 == 0) goto L_0x00d4
            boolean r11 = r9.f3085w
            if (r11 != 0) goto L_0x00d4
            int r11 = r9.f3083u
            if (r11 == r2) goto L_0x00d4
            float r11 = r12.getX()
            int r11 = (int) r11
            float r0 = r12.getY()
            int r0 = (int) r0
            boolean r10 = r10.mo1205a((android.view.View) r3, (int) r11, (int) r0)
            if (r10 != 0) goto L_0x00d4
            y8 r10 = r9.f3084v
            if (r10 == 0) goto L_0x00d4
            int r10 = r9.f3059G
            float r10 = (float) r10
            float r11 = r12.getY()
            float r10 = r10 - r11
            float r10 = java.lang.Math.abs(r10)
            y8 r11 = r9.f3084v
            int r11 = r11.f17623b
            float r11 = (float) r11
            int r10 = (r10 > r11 ? 1 : (r10 == r11 ? 0 : -1))
            if (r10 <= 0) goto L_0x00d4
            r1 = 1
        L_0x00d4:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.bottomsheet.BottomSheetBehavior.mo1266a(androidx.coordinatorlayout.widget.CoordinatorLayout, android.view.View, android.view.MotionEvent):boolean");
    }

    /* renamed from: b */
    public Parcelable mo1271b(CoordinatorLayout coordinatorLayout, V v) {
        return new C0429e((Parcelable) View.BaseSavedState.EMPTY_STATE, (BottomSheetBehavior<?>) this);
    }

    /* renamed from: b */
    public boolean mo1272b(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        if (!v.isShown()) {
            return false;
        }
        int actionMasked = motionEvent.getActionMasked();
        if (this.f3083u == 1 && actionMasked == 0) {
            return true;
        }
        C2330y8 y8Var = this.f3084v;
        if (y8Var != null) {
            y8Var.mo12808a(motionEvent);
        }
        if (actionMasked == 0) {
            this.f3058F = -1;
            VelocityTracker velocityTracker = this.f3057E;
            if (velocityTracker != null) {
                velocityTracker.recycle();
                this.f3057E = null;
            }
        }
        if (this.f3057E == null) {
            this.f3057E = VelocityTracker.obtain();
        }
        this.f3057E.addMovement(motionEvent);
        if (actionMasked == 2 && !this.f3085w) {
            float abs = Math.abs(((float) this.f3059G) - motionEvent.getY());
            C2330y8 y8Var2 = this.f3084v;
            if (abs > ((float) y8Var2.f17623b)) {
                y8Var2.mo12809a((View) v, motionEvent.getPointerId(motionEvent.getActionIndex()));
            }
        }
        return !this.f3085w;
    }

    /* renamed from: a */
    public boolean mo203a(CoordinatorLayout coordinatorLayout, V v, int i) {
        int i2;
        f73 f73;
        if (C2189w7.m15015j(coordinatorLayout) && !C2189w7.m15015j(v)) {
            v.setFitsSystemWindows(true);
        }
        if (this.f3054B == null) {
            this.f3068f = coordinatorLayout.getResources().getDimensionPixelSize(d33.design_bottom_sheet_peek_height_min);
            this.f3054B = new WeakReference<>(v);
            if (this.f3069g && (f73 = this.f3070h) != null) {
                int i3 = Build.VERSION.SDK_INT;
                v.setBackground(f73);
            }
            f73 f732 = this.f3070h;
            if (f732 != null) {
                float f = this.f3080r;
                if (f == -1.0f) {
                    f = C2189w7.m15014i(v);
                }
                f732.mo5467a(f);
                this.f3072j = this.f3083u == 3;
                this.f3070h.mo5476b(this.f3072j ? 0.0f : 1.0f);
            }
            mo3429n();
            if (C2189w7.m15016k(v) == 0) {
                int i4 = Build.VERSION.SDK_INT;
                v.setImportantForAccessibility(1);
            }
        }
        if (this.f3084v == null) {
            this.f3084v = new C2330y8(coordinatorLayout.getContext(), coordinatorLayout, this.f3062J);
        }
        int top = v.getTop();
        coordinatorLayout.mo1213c((View) v, i);
        this.f3088z = coordinatorLayout.getWidth();
        this.f3053A = coordinatorLayout.getHeight();
        this.f3076n = Math.max(0, this.f3053A - v.getHeight());
        this.f3077o = (int) ((1.0f - this.f3078p) * ((float) this.f3053A));
        mo3424i();
        int i5 = this.f3083u;
        if (i5 == 3) {
            i2 = mo3425j();
        } else if (i5 == 6) {
            i2 = this.f3077o;
        } else if (!this.f3081s || i5 != 5) {
            int i6 = this.f3083u;
            if (i6 == 4) {
                i2 = this.f3079q;
            } else {
                if (i6 == 1 || i6 == 2) {
                    C2189w7.m15007e(v, top - v.getTop());
                }
                this.f3055C = new WeakReference<>(mo3403a((View) v));
                return true;
            }
        } else {
            i2 = this.f3053A;
        }
        C2189w7.m15007e(v, i2);
        this.f3055C = new WeakReference<>(mo3403a((View) v));
        return true;
    }

    /* renamed from: a */
    public void mo1255a(CoordinatorLayout coordinatorLayout, V v, Parcelable parcelable) {
        C0429e eVar = (C0429e) parcelable;
        Parcelable parcelable2 = eVar.f14707X;
        int i = this.f3063a;
        if (i != 0) {
            if (i == -1 || (i & 1) == 1) {
                this.f3066d = eVar.f3096a0;
            }
            int i2 = this.f3063a;
            if (i2 == -1 || (i2 & 2) == 2) {
                this.f3064b = eVar.f3097b0;
            }
            int i3 = this.f3063a;
            if (i3 == -1 || (i3 & 4) == 4) {
                this.f3081s = eVar.f3098c0;
            }
            int i4 = this.f3063a;
            if (i4 == -1 || (i4 & 8) == 8) {
                this.f3082t = eVar.f3099d0;
            }
        }
        int i5 = eVar.f3095Z;
        if (i5 == 1 || i5 == 2) {
            this.f3083u = 4;
        } else {
            this.f3083u = i5;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:35:0x008c, code lost:
        if (java.lang.Math.abs(r4 - r1) < java.lang.Math.abs(r4 - r3.f3079q)) goto L_0x00ac;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:40:0x00aa, code lost:
        if (java.lang.Math.abs(r4 - r3.f3077o) < java.lang.Math.abs(r4 - r3.f3079q)) goto L_0x00ac;
     */
    /* renamed from: a */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo1256a(androidx.coordinatorlayout.widget.CoordinatorLayout r4, V r5, android.view.View r6, int r7) {
        /*
            r3 = this;
            int r4 = r5.getTop()
            int r7 = r3.mo3425j()
            r0 = 3
            if (r4 != r7) goto L_0x000f
            r3.mo3421f(r0)
            return
        L_0x000f:
            java.lang.ref.WeakReference<android.view.View> r4 = r3.f3055C
            if (r4 == 0) goto L_0x00b5
            java.lang.Object r4 = r4.get()
            if (r6 != r4) goto L_0x00b5
            boolean r4 = r3.f3087y
            if (r4 != 0) goto L_0x001f
            goto L_0x00b5
        L_0x001f:
            int r4 = r3.f3086x
            r6 = 6
            r7 = 4
            if (r4 <= 0) goto L_0x002b
            int r4 = r3.mo3425j()
            goto L_0x00af
        L_0x002b:
            boolean r4 = r3.f3081s
            if (r4 == 0) goto L_0x004e
            android.view.VelocityTracker r4 = r3.f3057E
            if (r4 != 0) goto L_0x0035
            r4 = 0
            goto L_0x0044
        L_0x0035:
            r1 = 1000(0x3e8, float:1.401E-42)
            float r2 = r3.f3065c
            r4.computeCurrentVelocity(r1, r2)
            android.view.VelocityTracker r4 = r3.f3057E
            int r1 = r3.f3058F
            float r4 = r4.getYVelocity(r1)
        L_0x0044:
            boolean r4 = r3.mo3413a((android.view.View) r5, (float) r4)
            if (r4 == 0) goto L_0x004e
            int r4 = r3.f3053A
            r0 = 5
            goto L_0x00af
        L_0x004e:
            int r4 = r3.f3086x
            if (r4 != 0) goto L_0x008f
            int r4 = r5.getTop()
            boolean r1 = r3.f3064b
            if (r1 == 0) goto L_0x006e
            int r6 = r3.f3076n
            int r6 = r4 - r6
            int r6 = java.lang.Math.abs(r6)
            int r1 = r3.f3079q
            int r4 = r4 - r1
            int r4 = java.lang.Math.abs(r4)
            if (r6 >= r4) goto L_0x0093
            int r4 = r3.f3076n
            goto L_0x00af
        L_0x006e:
            int r1 = r3.f3077o
            if (r4 >= r1) goto L_0x007f
            int r7 = r3.f3079q
            int r7 = r4 - r7
            int r7 = java.lang.Math.abs(r7)
            if (r4 >= r7) goto L_0x00ac
            int r4 = r3.f3075m
            goto L_0x00af
        L_0x007f:
            int r0 = r4 - r1
            int r0 = java.lang.Math.abs(r0)
            int r1 = r3.f3079q
            int r4 = r4 - r1
            int r4 = java.lang.Math.abs(r4)
            if (r0 >= r4) goto L_0x0093
            goto L_0x00ac
        L_0x008f:
            boolean r4 = r3.f3064b
            if (r4 == 0) goto L_0x0097
        L_0x0093:
            int r4 = r3.f3079q
            r0 = 4
            goto L_0x00af
        L_0x0097:
            int r4 = r5.getTop()
            int r0 = r3.f3077o
            int r0 = r4 - r0
            int r0 = java.lang.Math.abs(r0)
            int r1 = r3.f3079q
            int r4 = r4 - r1
            int r4 = java.lang.Math.abs(r4)
            if (r0 >= r4) goto L_0x0093
        L_0x00ac:
            int r4 = r3.f3077o
            r0 = 6
        L_0x00af:
            r6 = 0
            r3.mo3409a((android.view.View) r5, (int) r0, (int) r4, (boolean) r6)
            r3.f3087y = r6
        L_0x00b5:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.bottomsheet.BottomSheetBehavior.mo1256a(androidx.coordinatorlayout.widget.CoordinatorLayout, android.view.View, android.view.View, int):void");
    }

    /* renamed from: a */
    public void mo3409a(View view, int i, int i2, boolean z) {
        boolean z2;
        if (z) {
            z2 = this.f3084v.mo12819b(view.getLeft(), i2);
        } else {
            C2330y8 y8Var = this.f3084v;
            int left = view.getLeft();
            y8Var.f17640s = view;
            y8Var.f17624c = -1;
            z2 = y8Var.mo12811a(left, i2, 0, 0);
            if (!z2 && y8Var.f17622a == 0 && y8Var.f17640s != null) {
                y8Var.f17640s = null;
            }
        }
        if (z2) {
            mo3421f(2);
            mo3423h(i);
            if (this.f3073k == null) {
                this.f3073k = new C0431f(view, i);
            }
            BottomSheetBehavior<V>.C0633f fVar = this.f3073k;
            boolean z3 = fVar.f3101Y;
            fVar.f3102Z = i;
            if (!z3) {
                C2189w7.m14991a(view, (Runnable) fVar);
                this.f3073k.f3101Y = true;
                return;
            }
            return;
        }
        mo3421f(i);
    }
}
