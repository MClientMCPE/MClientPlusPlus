package com.google.android.material.bottomsheet;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

public class BottomSheetBehaviorMod<T extends View> extends BottomSheetBehavior<T> {

    /* renamed from: L */
    public C0432a f3104L;

    /* renamed from: com.google.android.material.bottomsheet.BottomSheetBehaviorMod$a */
    public interface C0432a {
        /* renamed from: a */
        boolean mo3438a(View view, float f);
    }

    public BottomSheetBehaviorMod() {
    }

    public BottomSheetBehaviorMod(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    /* renamed from: a */
    public void mo3437a(C0432a aVar) {
        this.f3104L = aVar;
    }

    /* renamed from: a */
    public boolean mo3413a(View view, float f) {
        if (!super.mo3413a(view, f)) {
            return false;
        }
        C0432a aVar = this.f3104L;
        if (aVar != null) {
            return aVar.mo3438a(view, f);
        }
        return true;
    }
}
