package com.google.android.material.tabs;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.RectF;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.PointerIcon;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import p000.C0681ff;
import p000.C1377n;
import p000.d43;

@C0681ff.C0684c
public class TabLayout extends HorizontalScrollView {

    /* renamed from: N0 */
    public static final C0590e7<C0461h> f3205N0 = new C0666f7(16);

    /* renamed from: A0 */
    public boolean f3206A0;

    /* renamed from: B0 */
    public boolean f3207B0;

    /* renamed from: C0 */
    public boolean f3208C0;

    /* renamed from: D0 */
    public final ArrayList<C0456e> f3209D0;

    /* renamed from: E0 */
    public C0456e f3210E0;

    /* renamed from: F0 */
    public final HashMap<C0455d<? extends C0461h>, C0456e> f3211F0;

    /* renamed from: G0 */
    public ValueAnimator f3212G0;

    /* renamed from: H0 */
    public C0681ff f3213H0;

    /* renamed from: I0 */
    public DataSetObserver f3214I0;

    /* renamed from: J0 */
    public C0462i f3215J0;

    /* renamed from: K0 */
    public C0454c f3216K0;

    /* renamed from: L0 */
    public boolean f3217L0;

    /* renamed from: M0 */
    public final C0590e7<C0463j> f3218M0;

    /* renamed from: a0 */
    public final ArrayList<C0461h> f3219a0;

    /* renamed from: b0 */
    public C0461h f3220b0;

    /* renamed from: c0 */
    public final RectF f3221c0;

    /* renamed from: d0 */
    public final C0458g f3222d0;

    /* renamed from: e0 */
    public int f3223e0;

    /* renamed from: f0 */
    public int f3224f0;

    /* renamed from: g0 */
    public int f3225g0;

    /* renamed from: h0 */
    public int f3226h0;

    /* renamed from: i0 */
    public int f3227i0;

    /* renamed from: j0 */
    public ColorStateList f3228j0;

    /* renamed from: k0 */
    public ColorStateList f3229k0;

    /* renamed from: l0 */
    public ColorStateList f3230l0;

    /* renamed from: m0 */
    public Drawable f3231m0;

    /* renamed from: n0 */
    public PorterDuff.Mode f3232n0;

    /* renamed from: o0 */
    public float f3233o0;

    /* renamed from: p0 */
    public float f3234p0;

    /* renamed from: q0 */
    public final int f3235q0;

    /* renamed from: r0 */
    public int f3236r0;

    /* renamed from: s0 */
    public final int f3237s0;

    /* renamed from: t0 */
    public final int f3238t0;

    /* renamed from: u0 */
    public final int f3239u0;

    /* renamed from: v0 */
    public int f3240v0;

    /* renamed from: w0 */
    public int f3241w0;

    /* renamed from: x0 */
    public int f3242x0;

    /* renamed from: y0 */
    public int f3243y0;

    /* renamed from: z0 */
    public int f3244z0;

    /* renamed from: com.google.android.material.tabs.TabLayout$a */
    public class C0452a implements C0456e {
        public C0452a(TabLayout tabLayout) {
        }

        /* renamed from: a */
        public void mo3911a(C0461h hVar) {
            throw null;
        }

        /* renamed from: b */
        public void mo3912b(C0461h hVar) {
            throw null;
        }

        /* renamed from: c */
        public void mo3913c(C0461h hVar) {
            throw null;
        }
    }

    /* renamed from: com.google.android.material.tabs.TabLayout$b */
    public class C0453b implements ValueAnimator.AnimatorUpdateListener {
        public C0453b() {
        }

        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            TabLayout.this.scrollTo(((Integer) valueAnimator.getAnimatedValue()).intValue(), 0);
        }
    }

    /* renamed from: com.google.android.material.tabs.TabLayout$c */
    public class C0454c implements C0681ff.C0687f {

        /* renamed from: a */
        public boolean f3246a;

        public C0454c() {
        }
    }

    @Deprecated
    /* renamed from: com.google.android.material.tabs.TabLayout$d */
    public interface C0455d<T extends C0461h> {
    }

    /* renamed from: com.google.android.material.tabs.TabLayout$e */
    public interface C0456e {
        /* renamed from: a */
        void mo3911a(C0461h hVar);

        /* renamed from: b */
        void mo3912b(C0461h hVar);

        /* renamed from: c */
        void mo3913c(C0461h hVar);
    }

    /* renamed from: com.google.android.material.tabs.TabLayout$f */
    public class C0457f extends DataSetObserver {
        public C0457f() {
        }

        public void onChanged() {
            TabLayout.this.mo3870f();
        }

        public void onInvalidated() {
            TabLayout.this.mo3870f();
        }
    }

    /* renamed from: com.google.android.material.tabs.TabLayout$h */
    public static class C0461h {

        /* renamed from: a */
        public Object f3266a;

        /* renamed from: b */
        public Drawable f3267b;

        /* renamed from: c */
        public CharSequence f3268c;

        /* renamed from: d */
        public CharSequence f3269d;

        /* renamed from: e */
        public int f3270e = -1;

        /* renamed from: f */
        public View f3271f;

        /* renamed from: g */
        public int f3272g = 1;

        /* renamed from: h */
        public TabLayout f3273h;

        /* renamed from: i */
        public C0463j f3274i;

        /* renamed from: a */
        public C0461h mo3926a(CharSequence charSequence) {
            if (TextUtils.isEmpty(this.f3269d) && !TextUtils.isEmpty(charSequence)) {
                this.f3274i.setContentDescription(charSequence);
            }
            this.f3268c = charSequence;
            mo3927a();
            return this;
        }

        /* renamed from: a */
        public void mo3927a() {
            C0463j jVar = this.f3274i;
            if (jVar != null) {
                jVar.mo3940e();
            }
        }
    }

    /* renamed from: com.google.android.material.tabs.TabLayout$i */
    public static class C0462i implements C0681ff.C0688g {

        /* renamed from: a */
        public final WeakReference<TabLayout> f3275a;

        /* renamed from: b */
        public int f3276b;

        /* renamed from: c */
        public int f3277c;

        public C0462i(TabLayout tabLayout) {
            this.f3275a = new WeakReference<>(tabLayout);
        }

        /* renamed from: a */
        public void mo3928a(int i) {
            TabLayout tabLayout = (TabLayout) this.f3275a.get();
            if (tabLayout != null && tabLayout.getSelectedTabPosition() != i && i < tabLayout.getTabCount()) {
                int i2 = this.f3277c;
                tabLayout.mo3864b(tabLayout.mo3861b(i), i2 == 0 || (i2 == 2 && this.f3276b == 0));
            }
        }

        /* renamed from: a */
        public void mo3929a(int i, float f, int i2) {
            TabLayout tabLayout = (TabLayout) this.f3275a.get();
            if (tabLayout != null) {
                boolean z = false;
                boolean z2 = this.f3277c != 2 || this.f3276b == 1;
                if (!(this.f3277c == 2 && this.f3276b == 0)) {
                    z = true;
                }
                tabLayout.mo3846a(i, f, z2, z);
            }
        }
    }

    /* renamed from: com.google.android.material.tabs.TabLayout$k */
    public static class C0464k implements C0456e {

        /* renamed from: a */
        public final C0681ff f3289a;

        public C0464k(C0681ff ffVar) {
            this.f3289a = ffVar;
        }

        /* renamed from: a */
        public void mo3911a(C0461h hVar) {
        }

        /* renamed from: b */
        public void mo3912b(C0461h hVar) {
        }

        /* renamed from: c */
        public void mo3913c(C0461h hVar) {
            this.f3289a.setCurrentItem(hVar.f3270e);
        }
    }

    public TabLayout(Context context) {
        this(context, (AttributeSet) null);
    }

    public TabLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, b33.tabStyle);
    }

    /* JADX INFO: finally extract failed */
    public TabLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f3219a0 = new ArrayList<>();
        this.f3221c0 = new RectF();
        this.f3236r0 = Integer.MAX_VALUE;
        this.f3209D0 = new ArrayList<>();
        this.f3211F0 = new HashMap<>();
        this.f3218M0 = new C0590e7<>(12);
        setHorizontalScrollBarEnabled(false);
        this.f3222d0 = new C0458g(context);
        super.addView(this.f3222d0, 0, new FrameLayout.LayoutParams(-2, -1));
        TypedArray b = o63.m10328b(context, attributeSet, l33.TabLayout, i, k33.Widget_Design_TabLayout, l33.TabLayout_tabTextAppearance);
        if (getBackground() instanceof ColorDrawable) {
            f73 f73 = new f73();
            f73.mo5471a(ColorStateList.valueOf(((ColorDrawable) getBackground()).getColor()));
            f73.f5079X.f5102b = new w53(context);
            f73.mo5496l();
            f73.mo5467a(C2189w7.m15014i(this));
            int i2 = Build.VERSION.SDK_INT;
            setBackground(f73);
        }
        C0458g gVar = this.f3222d0;
        int dimensionPixelSize = b.getDimensionPixelSize(l33.TabLayout_tabIndicatorHeight, -1);
        if (gVar.f3249a0 != dimensionPixelSize) {
            gVar.f3249a0 = dimensionPixelSize;
            C2189w7.m14972D(gVar);
        }
        C0458g gVar2 = this.f3222d0;
        int color = b.getColor(l33.TabLayout_tabIndicatorColor, 0);
        if (gVar2.f3250b0.getColor() != color) {
            gVar2.f3250b0.setColor(color);
            C2189w7.m14972D(gVar2);
        }
        setSelectedTabIndicator(t53.m13122b(context, b, l33.TabLayout_tabIndicator));
        setSelectedTabIndicatorGravity(b.getInt(l33.TabLayout_tabIndicatorGravity, 0));
        setTabIndicatorFullWidth(b.getBoolean(l33.TabLayout_tabIndicatorFullWidth, true));
        int dimensionPixelSize2 = b.getDimensionPixelSize(l33.TabLayout_tabPadding, 0);
        this.f3226h0 = dimensionPixelSize2;
        this.f3225g0 = dimensionPixelSize2;
        this.f3224f0 = dimensionPixelSize2;
        this.f3223e0 = dimensionPixelSize2;
        this.f3223e0 = b.getDimensionPixelSize(l33.TabLayout_tabPaddingStart, this.f3223e0);
        this.f3224f0 = b.getDimensionPixelSize(l33.TabLayout_tabPaddingTop, this.f3224f0);
        this.f3225g0 = b.getDimensionPixelSize(l33.TabLayout_tabPaddingEnd, this.f3225g0);
        this.f3226h0 = b.getDimensionPixelSize(l33.TabLayout_tabPaddingBottom, this.f3226h0);
        this.f3227i0 = b.getResourceId(l33.TabLayout_tabTextAppearance, k33.TextAppearance_Design_Tab);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(this.f3227i0, C1292m.TextAppearance);
        try {
            this.f3233o0 = (float) obtainStyledAttributes.getDimensionPixelSize(C1292m.TextAppearance_android_textSize, 0);
            this.f3228j0 = t53.m13077a(context, obtainStyledAttributes, C1292m.TextAppearance_android_textColor);
            obtainStyledAttributes.recycle();
            if (b.hasValue(l33.TabLayout_tabTextColor)) {
                this.f3228j0 = t53.m13077a(context, b, l33.TabLayout_tabTextColor);
            }
            if (b.hasValue(l33.TabLayout_tabSelectedTextColor)) {
                int color2 = b.getColor(l33.TabLayout_tabSelectedTextColor, 0);
                int defaultColor = this.f3228j0.getDefaultColor();
                this.f3228j0 = new ColorStateList(new int[][]{HorizontalScrollView.SELECTED_STATE_SET, HorizontalScrollView.EMPTY_STATE_SET}, new int[]{color2, defaultColor});
            }
            this.f3229k0 = t53.m13077a(context, b, l33.TabLayout_tabIconTint);
            this.f3232n0 = t53.m13079a(b.getInt(l33.TabLayout_tabIconTintMode, -1), (PorterDuff.Mode) null);
            this.f3230l0 = t53.m13077a(context, b, l33.TabLayout_tabRippleColor);
            this.f3242x0 = b.getInt(l33.TabLayout_tabIndicatorAnimationDuration, 300);
            this.f3237s0 = b.getDimensionPixelSize(l33.TabLayout_tabMinWidth, -1);
            this.f3238t0 = b.getDimensionPixelSize(l33.TabLayout_tabMaxWidth, -1);
            this.f3235q0 = b.getResourceId(l33.TabLayout_tabBackground, 0);
            this.f3240v0 = b.getDimensionPixelSize(l33.TabLayout_tabContentStart, 0);
            this.f3244z0 = b.getInt(l33.TabLayout_tabMode, 1);
            this.f3241w0 = b.getInt(l33.TabLayout_tabGravity, 0);
            this.f3206A0 = b.getBoolean(l33.TabLayout_tabInlineLabel, false);
            this.f3208C0 = b.getBoolean(l33.TabLayout_tabUnboundedRipple, false);
            b.recycle();
            Resources resources = getResources();
            this.f3234p0 = (float) resources.getDimensionPixelSize(d33.design_tab_text_size_2line);
            this.f3239u0 = resources.getDimensionPixelSize(d33.design_tab_scrollable_min_width);
            mo3843a();
        } catch (Throwable th) {
            obtainStyledAttributes.recycle();
            throw th;
        }
    }

    private int getDefaultHeight() {
        int size = this.f3219a0.size();
        boolean z = false;
        int i = 0;
        while (true) {
            if (i < size) {
                C0461h hVar = this.f3219a0.get(i);
                if (hVar != null && hVar.f3267b != null && !TextUtils.isEmpty(hVar.f3268c)) {
                    z = true;
                    break;
                }
                i++;
            } else {
                break;
            }
        }
        return (!z || this.f3206A0) ? 48 : 72;
    }

    private int getTabMinWidth() {
        int i = this.f3237s0;
        if (i != -1) {
            return i;
        }
        int i2 = this.f3244z0;
        if (i2 == 0 || i2 == 2) {
            return this.f3239u0;
        }
        return 0;
    }

    private int getTabScrollRange() {
        return Math.max(0, ((this.f3222d0.getWidth() - getWidth()) - getPaddingLeft()) - getPaddingRight());
    }

    private void setSelectedTabView(int i) {
        int childCount = this.f3222d0.getChildCount();
        if (i < childCount) {
            int i2 = 0;
            while (i2 < childCount) {
                View childAt = this.f3222d0.getChildAt(i2);
                boolean z = true;
                childAt.setSelected(i2 == i);
                if (i2 != i) {
                    z = false;
                }
                childAt.setActivated(z);
                i2++;
            }
        }
    }

    /* renamed from: a */
    public final int mo3841a(int i, float f) {
        int i2 = this.f3244z0;
        int i3 = 0;
        if (i2 != 0 && i2 != 2) {
            return 0;
        }
        View childAt = this.f3222d0.getChildAt(i);
        int i4 = i + 1;
        View childAt2 = i4 < this.f3222d0.getChildCount() ? this.f3222d0.getChildAt(i4) : null;
        int width = childAt != null ? childAt.getWidth() : 0;
        if (childAt2 != null) {
            i3 = childAt2.getWidth();
        }
        int left = ((width / 2) + childAt.getLeft()) - (getWidth() / 2);
        int i5 = (int) (((float) (width + i3)) * 0.5f * f);
        return C2189w7.m15018m(this) == 0 ? left + i5 : left - i5;
    }

    /* renamed from: a */
    public C0456e mo3842a(C0455d dVar) {
        if (dVar == null) {
            return null;
        }
        if (this.f3211F0.containsKey(dVar)) {
            return this.f3211F0.get(dVar);
        }
        C0452a aVar = new C0452a(this);
        this.f3211F0.put(dVar, aVar);
        return aVar;
    }

    /* renamed from: a */
    public final void mo3843a() {
        int i = this.f3244z0;
        C2189w7.m14983a(this.f3222d0, (i == 0 || i == 2) ? Math.max(0, this.f3240v0 - this.f3223e0) : 0, 0, 0, 0);
        int i2 = this.f3244z0;
        if (i2 == 0) {
            this.f3222d0.setGravity(8388611);
        } else if (i2 == 1 || i2 == 2) {
            this.f3222d0.setGravity(1);
        }
        mo3856a(true);
    }

    /* renamed from: a */
    public void mo3845a(int i, float f, boolean z) {
        mo3846a(i, f, z, true);
    }

    /* renamed from: a */
    public final void mo3848a(LinearLayout.LayoutParams layoutParams) {
        float f;
        if (this.f3244z0 == 1 && this.f3241w0 == 0) {
            layoutParams.width = 0;
            f = 1.0f;
        } else {
            layoutParams.width = -2;
            f = 0.0f;
        }
        layoutParams.weight = f;
    }

    /* renamed from: a */
    public void mo3849a(C0456e eVar) {
        if (!this.f3209D0.contains(eVar)) {
            this.f3209D0.add(eVar);
        }
    }

    /* renamed from: a */
    public void mo3850a(C0461h hVar) {
        mo3852a(hVar, this.f3219a0.isEmpty());
    }

    /* renamed from: a */
    public void mo3851a(C0461h hVar, int i, boolean z) {
        if (hVar.f3273h == this) {
            hVar.f3270e = i;
            this.f3219a0.add(i, hVar);
            int size = this.f3219a0.size();
            while (true) {
                i++;
                if (i >= size) {
                    break;
                }
                this.f3219a0.get(i).f3270e = i;
            }
            C0463j jVar = hVar.f3274i;
            jVar.setSelected(false);
            jVar.setActivated(false);
            C0458g gVar = this.f3222d0;
            int i2 = hVar.f3270e;
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-2, -1);
            mo3848a(layoutParams);
            gVar.addView(jVar, i2, layoutParams);
            if (z) {
                TabLayout tabLayout = hVar.f3273h;
                if (tabLayout != null) {
                    tabLayout.mo3867c(hVar);
                    return;
                }
                throw new IllegalArgumentException("Tab not attached to a TabLayout");
            }
            return;
        }
        throw new IllegalArgumentException("Tab belongs to a different TabLayout.");
    }

    /* renamed from: a */
    public void mo3852a(C0461h hVar, boolean z) {
        mo3851a(hVar, this.f3219a0.size(), z);
    }

    /* renamed from: a */
    public void mo3853a(C0603ef efVar, boolean z) {
        if (!z || efVar == null) {
            mo3870f();
            return;
        }
        if (this.f3214I0 == null) {
            this.f3214I0 = new C0457f();
        }
        throw null;
    }

    /* renamed from: a */
    public void mo3854a(C0681ff ffVar, boolean z) {
        mo3855a(ffVar, z, false);
    }

    /* renamed from: a */
    public void mo3856a(boolean z) {
        for (int i = 0; i < this.f3222d0.getChildCount(); i++) {
            View childAt = this.f3222d0.getChildAt(i);
            childAt.setMinimumWidth(getTabMinWidth());
            mo3848a((LinearLayout.LayoutParams) childAt.getLayoutParams());
            if (z) {
                childAt.requestLayout();
            }
        }
    }

    public void addView(View view) {
        mo3847a(view);
    }

    public void addView(View view, int i) {
        mo3847a(view);
    }

    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        mo3847a(view);
    }

    public void addView(View view, ViewGroup.LayoutParams layoutParams) {
        mo3847a(view);
    }

    /* renamed from: b */
    public C0461h mo3861b(int i) {
        if (i < 0 || i >= getTabCount()) {
            return null;
        }
        return this.f3219a0.get(i);
    }

    /* renamed from: b */
    public void mo3862b() {
        this.f3209D0.clear();
        this.f3211F0.clear();
    }

    /* renamed from: b */
    public void mo3863b(C0456e eVar) {
        this.f3209D0.remove(eVar);
    }

    /* renamed from: b */
    public void mo3864b(C0461h hVar, boolean z) {
        C0461h hVar2 = this.f3220b0;
        if (hVar2 != hVar) {
            int i = hVar != null ? hVar.f3270e : -1;
            if (z) {
                if ((hVar2 == null || hVar2.f3270e == -1) && i != -1) {
                    mo3845a(i, 0.0f, true);
                } else {
                    mo3844a(i);
                }
                if (i != -1) {
                    setSelectedTabView(i);
                }
            }
            this.f3220b0 = hVar;
            if (hVar2 != null) {
                for (int size = this.f3209D0.size() - 1; size >= 0; size--) {
                    this.f3209D0.get(size).mo3912b(hVar2);
                }
            }
            if (hVar != null) {
                for (int size2 = this.f3209D0.size() - 1; size2 >= 0; size2--) {
                    this.f3209D0.get(size2).mo3913c(hVar);
                }
            }
        } else if (hVar2 != null) {
            for (int size3 = this.f3209D0.size() - 1; size3 >= 0; size3--) {
                this.f3209D0.get(size3).mo3911a(hVar);
            }
            mo3844a(hVar.f3270e);
        }
    }

    /* renamed from: b */
    public boolean mo3865b(C0461h hVar) {
        return f3205N0.mo5049a(hVar);
    }

    /* renamed from: c */
    public C0461h mo3866c() {
        C0461h a = f3205N0.mo5048a();
        return a == null ? new C0461h() : a;
    }

    /* renamed from: c */
    public void mo3867c(C0461h hVar) {
        mo3864b(hVar, true);
    }

    /* renamed from: d */
    public final void mo3868d() {
        if (this.f3212G0 == null) {
            this.f3212G0 = new ValueAnimator();
            this.f3212G0.setInterpolator(m33.f9975b);
            this.f3212G0.setDuration((long) this.f3242x0);
            this.f3212G0.addUpdateListener(new C0453b());
        }
    }

    /* renamed from: e */
    public C0461h mo3869e() {
        CharSequence charSequence;
        C0461h c = mo3866c();
        c.f3273h = this;
        C0590e7<C0463j> e7Var = this.f3218M0;
        C0463j a = e7Var != null ? e7Var.mo5048a() : null;
        if (a == null) {
            a = new C0463j(getContext());
        }
        a.setTab(c);
        a.setFocusable(true);
        a.setMinimumWidth(getTabMinWidth());
        if (TextUtils.isEmpty(c.f3269d)) {
            charSequence = c.f3268c;
        } else {
            charSequence = c.f3269d;
        }
        a.setContentDescription(charSequence);
        c.f3274i = a;
        return c;
    }

    /* renamed from: f */
    public void mo3870f() {
        mo3871g();
    }

    /* renamed from: g */
    public void mo3871g() {
        for (int childCount = this.f3222d0.getChildCount() - 1; childCount >= 0; childCount--) {
            C0463j jVar = (C0463j) this.f3222d0.getChildAt(childCount);
            this.f3222d0.removeViewAt(childCount);
            if (jVar != null) {
                jVar.mo3934b();
                this.f3218M0.mo5049a(jVar);
            }
            requestLayout();
        }
        Iterator<C0461h> it = this.f3219a0.iterator();
        while (it.hasNext()) {
            C0461h next = it.next();
            it.remove();
            next.f3273h = null;
            next.f3274i = null;
            next.f3266a = null;
            next.f3267b = null;
            next.f3268c = null;
            next.f3269d = null;
            next.f3270e = -1;
            next.f3271f = null;
            mo3865b(next);
        }
        this.f3220b0 = null;
    }

    public FrameLayout.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return generateDefaultLayoutParams();
    }

    public int getSelectedTabPosition() {
        C0461h hVar = this.f3220b0;
        if (hVar != null) {
            return hVar.f3270e;
        }
        return -1;
    }

    public int getTabCount() {
        return this.f3219a0.size();
    }

    public int getTabGravity() {
        return this.f3241w0;
    }

    public ColorStateList getTabIconTint() {
        return this.f3229k0;
    }

    public int getTabIndicatorGravity() {
        return this.f3243y0;
    }

    public int getTabMaxWidth() {
        return this.f3236r0;
    }

    public int getTabMode() {
        return this.f3244z0;
    }

    public ColorStateList getTabRippleColor() {
        return this.f3230l0;
    }

    public Drawable getTabSelectedIndicator() {
        return this.f3231m0;
    }

    public ColorStateList getTabTextColors() {
        return this.f3228j0;
    }

    /* renamed from: h */
    public final void mo3883h() {
        int size = this.f3219a0.size();
        for (int i = 0; i < size; i++) {
            this.f3219a0.get(i).mo3927a();
        }
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        Drawable background = getBackground();
        if (background instanceof f73) {
            t53.m13106a((View) this, (f73) background);
        }
        if (this.f3213H0 == null) {
            ViewParent parent = getParent();
            if (parent instanceof C0681ff) {
                mo3855a((C0681ff) parent, true, true);
            }
        }
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (this.f3217L0) {
            setupWithViewPager((C0681ff) null);
            this.f3217L0 = false;
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:5:0x0013, code lost:
        r1 = (com.google.android.material.tabs.TabLayout.C0463j) r1;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onDraw(android.graphics.Canvas r8) {
        /*
            r7 = this;
            r0 = 0
        L_0x0001:
            com.google.android.material.tabs.TabLayout$g r1 = r7.f3222d0
            int r1 = r1.getChildCount()
            if (r0 >= r1) goto L_0x0034
            com.google.android.material.tabs.TabLayout$g r1 = r7.f3222d0
            android.view.View r1 = r1.getChildAt(r0)
            boolean r2 = r1 instanceof com.google.android.material.tabs.TabLayout.C0463j
            if (r2 == 0) goto L_0x0031
            com.google.android.material.tabs.TabLayout$j r1 = (com.google.android.material.tabs.TabLayout.C0463j) r1
            android.graphics.drawable.Drawable r2 = r1.f3286i0
            if (r2 == 0) goto L_0x0031
            int r3 = r1.getLeft()
            int r4 = r1.getTop()
            int r5 = r1.getRight()
            int r6 = r1.getBottom()
            r2.setBounds(r3, r4, r5, r6)
            android.graphics.drawable.Drawable r1 = r1.f3286i0
            r1.draw(r8)
        L_0x0031:
            int r0 = r0 + 1
            goto L_0x0001
        L_0x0034:
            super.onDraw(r8)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.tabs.TabLayout.onDraw(android.graphics.Canvas):void");
    }

    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0070, code lost:
        if (r0 != 2) goto L_0x008a;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:23:0x007b, code lost:
        if (r7.getMeasuredWidth() != getMeasuredWidth()) goto L_0x007d;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:24:0x007d, code lost:
        r4 = true;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:26:0x0087, code lost:
        if (r7.getMeasuredWidth() < getMeasuredWidth()) goto L_0x007d;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onMeasure(int r7, int r8) {
        /*
            r6 = this;
            android.content.Context r0 = r6.getContext()
            int r1 = r6.getDefaultHeight()
            float r0 = p000.t53.m13068a((android.content.Context) r0, (int) r1)
            int r0 = (int) r0
            int r1 = android.view.View.MeasureSpec.getMode(r8)
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = 1073741824(0x40000000, float:2.0)
            r4 = 0
            r5 = 1
            if (r1 == r2) goto L_0x002b
            if (r1 == 0) goto L_0x001c
            goto L_0x003e
        L_0x001c:
            int r8 = r6.getPaddingTop()
            int r8 = r8 + r0
            int r0 = r6.getPaddingBottom()
            int r0 = r0 + r8
            int r8 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r3)
            goto L_0x003e
        L_0x002b:
            int r1 = r6.getChildCount()
            if (r1 != r5) goto L_0x003e
            int r1 = android.view.View.MeasureSpec.getSize(r8)
            if (r1 < r0) goto L_0x003e
            android.view.View r1 = r6.getChildAt(r4)
            r1.setMinimumHeight(r0)
        L_0x003e:
            int r0 = android.view.View.MeasureSpec.getSize(r7)
            int r1 = android.view.View.MeasureSpec.getMode(r7)
            if (r1 == 0) goto L_0x005c
            int r1 = r6.f3238t0
            if (r1 <= 0) goto L_0x004d
            goto L_0x005a
        L_0x004d:
            float r0 = (float) r0
            android.content.Context r1 = r6.getContext()
            r2 = 56
            float r1 = p000.t53.m13068a((android.content.Context) r1, (int) r2)
            float r0 = r0 - r1
            int r1 = (int) r0
        L_0x005a:
            r6.f3236r0 = r1
        L_0x005c:
            super.onMeasure(r7, r8)
            int r7 = r6.getChildCount()
            if (r7 != r5) goto L_0x00aa
            android.view.View r7 = r6.getChildAt(r4)
            int r0 = r6.f3244z0
            if (r0 == 0) goto L_0x007f
            if (r0 == r5) goto L_0x0073
            r1 = 2
            if (r0 == r1) goto L_0x007f
            goto L_0x008a
        L_0x0073:
            int r0 = r7.getMeasuredWidth()
            int r1 = r6.getMeasuredWidth()
            if (r0 == r1) goto L_0x008a
        L_0x007d:
            r4 = 1
            goto L_0x008a
        L_0x007f:
            int r0 = r7.getMeasuredWidth()
            int r1 = r6.getMeasuredWidth()
            if (r0 >= r1) goto L_0x008a
            goto L_0x007d
        L_0x008a:
            if (r4 == 0) goto L_0x00aa
            int r0 = r6.getPaddingTop()
            int r1 = r6.getPaddingBottom()
            int r1 = r1 + r0
            android.view.ViewGroup$LayoutParams r0 = r7.getLayoutParams()
            int r0 = r0.height
            int r8 = android.widget.HorizontalScrollView.getChildMeasureSpec(r8, r1, r0)
            int r0 = r6.getMeasuredWidth()
            int r0 = android.view.View.MeasureSpec.makeMeasureSpec(r0, r3)
            r7.measure(r0, r8)
        L_0x00aa:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.tabs.TabLayout.onMeasure(int, int):void");
    }

    public void setElevation(float f) {
        super.setElevation(f);
        t53.m13105a((View) this, f);
    }

    public void setInlineLabel(boolean z) {
        if (this.f3206A0 != z) {
            this.f3206A0 = z;
            for (int i = 0; i < this.f3222d0.getChildCount(); i++) {
                View childAt = this.f3222d0.getChildAt(i);
                if (childAt instanceof C0463j) {
                    ((C0463j) childAt).mo3941f();
                }
            }
            mo3843a();
        }
    }

    public void setInlineLabelResource(int i) {
        setInlineLabel(getResources().getBoolean(i));
    }

    @Deprecated
    public void setOnTabSelectedListener(C0455d dVar) {
        mo3862b();
        mo3849a(mo3842a(dVar));
    }

    public void setScrollAnimatorListener(Animator.AnimatorListener animatorListener) {
        mo3868d();
        this.f3212G0.addListener(animatorListener);
    }

    public void setSelectedTabIndicator(int i) {
        setSelectedTabIndicator(i != 0 ? C1206l0.m8461c(getContext(), i) : null);
    }

    public void setSelectedTabIndicator(Drawable drawable) {
        if (this.f3231m0 != drawable) {
            this.f3231m0 = drawable;
            C2189w7.m14972D(this.f3222d0);
        }
    }

    public void setSelectedTabIndicatorColor(int i) {
        C0458g gVar = this.f3222d0;
        if (gVar.f3250b0.getColor() != i) {
            gVar.f3250b0.setColor(i);
            C2189w7.m14972D(gVar);
        }
    }

    public void setSelectedTabIndicatorGravity(int i) {
        if (this.f3243y0 != i) {
            this.f3243y0 = i;
            C2189w7.m14972D(this.f3222d0);
        }
    }

    @Deprecated
    public void setSelectedTabIndicatorHeight(int i) {
        C0458g gVar = this.f3222d0;
        if (gVar.f3249a0 != i) {
            gVar.f3249a0 = i;
            C2189w7.m14972D(gVar);
        }
    }

    public void setTabGravity(int i) {
        if (this.f3241w0 != i) {
            this.f3241w0 = i;
            mo3843a();
        }
    }

    public void setTabIconTint(ColorStateList colorStateList) {
        if (this.f3229k0 != colorStateList) {
            this.f3229k0 = colorStateList;
            mo3883h();
        }
    }

    public void setTabIconTintResource(int i) {
        setTabIconTint(C1206l0.m8460b(getContext(), i));
    }

    public void setTabIndicatorFullWidth(boolean z) {
        this.f3207B0 = z;
        C2189w7.m14972D(this.f3222d0);
    }

    public void setTabMode(int i) {
        if (i != this.f3244z0) {
            this.f3244z0 = i;
            mo3843a();
        }
    }

    public void setTabRippleColor(ColorStateList colorStateList) {
        if (this.f3230l0 != colorStateList) {
            this.f3230l0 = colorStateList;
            for (int i = 0; i < this.f3222d0.getChildCount(); i++) {
                View childAt = this.f3222d0.getChildAt(i);
                if (childAt instanceof C0463j) {
                    ((C0463j) childAt).mo3931a(getContext());
                }
            }
        }
    }

    public void setTabRippleColorResource(int i) {
        setTabRippleColor(C1206l0.m8460b(getContext(), i));
    }

    public void setTabTextColors(ColorStateList colorStateList) {
        if (this.f3228j0 != colorStateList) {
            this.f3228j0 = colorStateList;
            mo3883h();
        }
    }

    @Deprecated
    public void setTabsFromPagerAdapter(C0603ef efVar) {
        mo3853a(efVar, false);
    }

    public void setUnboundedRipple(boolean z) {
        if (this.f3208C0 != z) {
            this.f3208C0 = z;
            for (int i = 0; i < this.f3222d0.getChildCount(); i++) {
                View childAt = this.f3222d0.getChildAt(i);
                if (childAt instanceof C0463j) {
                    ((C0463j) childAt).mo3931a(getContext());
                }
            }
        }
    }

    public void setUnboundedRippleResource(int i) {
        setUnboundedRipple(getResources().getBoolean(i));
    }

    public void setupWithViewPager(C0681ff ffVar) {
        mo3854a(ffVar, true);
    }

    public boolean shouldDelayChildPressedState() {
        return getTabScrollRange() > 0;
    }

    /* renamed from: com.google.android.material.tabs.TabLayout$j */
    public final class C0463j extends LinearLayout {

        /* renamed from: a0 */
        public C0461h f3278a0;

        /* renamed from: b0 */
        public TextView f3279b0;

        /* renamed from: c0 */
        public ImageView f3280c0;

        /* renamed from: d0 */
        public View f3281d0;

        /* renamed from: e0 */
        public d43 f3282e0;

        /* renamed from: f0 */
        public View f3283f0;

        /* renamed from: g0 */
        public TextView f3284g0;

        /* renamed from: h0 */
        public ImageView f3285h0;

        /* renamed from: i0 */
        public Drawable f3286i0;

        /* renamed from: j0 */
        public int f3287j0 = 2;

        public C0463j(Context context) {
            super(context);
            mo3931a(context);
            int i = TabLayout.this.f3223e0;
            int i2 = TabLayout.this.f3224f0;
            int i3 = TabLayout.this.f3225g0;
            int i4 = TabLayout.this.f3226h0;
            int i5 = Build.VERSION.SDK_INT;
            setPaddingRelative(i, i2, i3, i4);
            setGravity(17);
            setOrientation(TabLayout.this.f3206A0 ^ true ? 1 : 0);
            setClickable(true);
            C1902t7 t7Var = Build.VERSION.SDK_INT >= 24 ? new C1902t7(PointerIcon.getSystemIcon(getContext(), 1002)) : new C1902t7((Object) null);
            if (Build.VERSION.SDK_INT >= 24) {
                setPointerIcon((PointerIcon) t7Var.f14701a);
            }
            C2189w7.m14988a((View) this, (C0757g7) null);
        }

        private d43 getBadge() {
            return this.f3282e0;
        }

        /* access modifiers changed from: private */
        public int getContentWidth() {
            int i = 0;
            int i2 = 0;
            boolean z = false;
            for (View view : new View[]{this.f3279b0, this.f3280c0, this.f3283f0}) {
                if (view != null && view.getVisibility() == 0) {
                    i2 = z ? Math.min(i2, view.getLeft()) : view.getLeft();
                    i = z ? Math.max(i, view.getRight()) : view.getRight();
                    z = true;
                }
            }
            return i - i2;
        }

        private d43 getOrCreateBadge() {
            if (this.f3282e0 == null) {
                Context context = getContext();
                int i = d43.f3693o0;
                int i2 = d43.f3692n0;
                d43 d43 = new d43(context);
                TypedArray b = o63.m10328b(context, (AttributeSet) null, l33.Badge, i, i2, new int[0]);
                int i3 = b.getInt(l33.Badge_maxCharacterCount, 4);
                if (d43.f3701e0.f3714b0 != i3) {
                    d43.C0513a aVar = d43.f3701e0;
                    aVar.f3714b0 = i3;
                    double a = (double) aVar.f3714b0;
                    Double.isNaN(a);
                    Double.isNaN(a);
                    Double.isNaN(a);
                    Double.isNaN(a);
                    Double.isNaN(a);
                    Double.isNaN(a);
                    d43.f3704h0 = ((int) Math.pow(10.0d, a - 1.0d)) - 1;
                    d43.f3696Z.f10923d = true;
                    d43.mo4641e();
                    d43.invalidateSelf();
                }
                if (b.hasValue(l33.Badge_number)) {
                    int max = Math.max(0, b.getInt(l33.Badge_number, 0));
                    d43.C0513a aVar2 = d43.f3701e0;
                    if (aVar2.f3713a0 != max) {
                        aVar2.f3713a0 = max;
                        d43.f3696Z.f10923d = true;
                        d43.mo4641e();
                        d43.invalidateSelf();
                    }
                }
                int a2 = d43.m3440a(context, b, l33.Badge_backgroundColor);
                d43.f3701e0.f3710X = a2;
                ColorStateList valueOf = ColorStateList.valueOf(a2);
                if (d43.f3695Y.mo5481d() != valueOf) {
                    d43.f3695Y.mo5471a(valueOf);
                    d43.invalidateSelf();
                }
                if (b.hasValue(l33.Badge_badgeTextColor)) {
                    int a3 = d43.m3440a(context, b, l33.Badge_badgeTextColor);
                    d43.f3701e0.f3711Y = a3;
                    if (d43.f3696Z.f10920a.getColor() != a3) {
                        d43.f3696Z.f10920a.setColor(a3);
                        d43.invalidateSelf();
                    }
                }
                int i4 = b.getInt(l33.Badge_badgeGravity, 8388661);
                d43.C0513a aVar3 = d43.f3701e0;
                if (aVar3.f3717e0 != i4) {
                    aVar3.f3717e0 = i4;
                    WeakReference<View> weakReference = d43.f3708l0;
                    if (!(weakReference == null || weakReference.get() == null)) {
                        View view = (View) d43.f3708l0.get();
                        WeakReference<ViewGroup> weakReference2 = d43.f3709m0;
                        d43.mo4636a(view, weakReference2 != null ? (ViewGroup) weakReference2.get() : null);
                    }
                }
                b.recycle();
                this.f3282e0 = d43;
            }
            mo3938d();
            d43 d432 = this.f3282e0;
            if (d432 != null) {
                return d432;
            }
            throw new IllegalStateException("Unable to create badge");
        }

        /* renamed from: a */
        public final FrameLayout mo3930a(View view) {
            if ((view == this.f3280c0 || view == this.f3279b0) && e43.f4259a) {
                return (FrameLayout) view.getParent();
            }
            return null;
        }

        /* JADX WARNING: type inference failed for: r2v3, types: [android.graphics.drawable.LayerDrawable] */
        /* JADX WARNING: type inference failed for: r0v3, types: [android.graphics.drawable.RippleDrawable] */
        /* JADX WARNING: Multi-variable type inference failed */
        /* renamed from: a */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final void mo3931a(android.content.Context r11) {
            /*
                r10 = this;
                com.google.android.material.tabs.TabLayout r0 = com.google.android.material.tabs.TabLayout.this
                int r0 = r0.f3235q0
                r1 = 0
                if (r0 == 0) goto L_0x0021
                android.graphics.drawable.Drawable r11 = p000.C1206l0.m8461c(r11, r0)
                r10.f3286i0 = r11
                android.graphics.drawable.Drawable r11 = r10.f3286i0
                if (r11 == 0) goto L_0x0023
                boolean r11 = r11.isStateful()
                if (r11 == 0) goto L_0x0023
                android.graphics.drawable.Drawable r11 = r10.f3286i0
                int[] r0 = r10.getDrawableState()
                r11.setState(r0)
                goto L_0x0023
            L_0x0021:
                r10.f3286i0 = r1
            L_0x0023:
                android.graphics.drawable.GradientDrawable r11 = new android.graphics.drawable.GradientDrawable
                r11.<init>()
                r0 = 0
                r11.setColor(r0)
                com.google.android.material.tabs.TabLayout r2 = com.google.android.material.tabs.TabLayout.this
                android.content.res.ColorStateList r2 = r2.f3230l0
                if (r2 == 0) goto L_0x010c
                android.graphics.drawable.GradientDrawable r2 = new android.graphics.drawable.GradientDrawable
                r2.<init>()
                r3 = 925353388(0x3727c5ac, float:1.0E-5)
                r2.setCornerRadius(r3)
                r3 = -1
                r2.setColor(r3)
                com.google.android.material.tabs.TabLayout r3 = com.google.android.material.tabs.TabLayout.this
                android.content.res.ColorStateList r3 = r3.f3230l0
                boolean r4 = p000.w63.f16569a
                r5 = 1
                r6 = 2
                if (r4 == 0) goto L_0x006d
                int[][] r4 = new int[r6][]
                int[] r7 = new int[r6]
                int[] r8 = p000.w63.f16578j
                r4[r0] = r8
                int[] r8 = p000.w63.f16574f
                int r8 = p000.w63.m14962a(r3, r8)
                r7[r0] = r8
                int[] r8 = android.util.StateSet.NOTHING
                r4[r5] = r8
                int[] r8 = p000.w63.f16570b
                int r3 = p000.w63.m14962a(r3, r8)
                r7[r5] = r3
                android.content.res.ColorStateList r3 = new android.content.res.ColorStateList
                r3.<init>(r4, r7)
                goto L_0x00dd
            L_0x006d:
                r4 = 10
                int[][] r7 = new int[r4][]
                int[] r4 = new int[r4]
                int[] r8 = p000.w63.f16574f
                r7[r0] = r8
                int r8 = p000.w63.m14962a(r3, r8)
                r4[r0] = r8
                int[] r8 = p000.w63.f16575g
                r7[r5] = r8
                int r8 = p000.w63.m14962a(r3, r8)
                r4[r5] = r8
                int[] r8 = p000.w63.f16576h
                r7[r6] = r8
                int r8 = p000.w63.m14962a(r3, r8)
                r4[r6] = r8
                r8 = 3
                int[] r9 = p000.w63.f16577i
                r7[r8] = r9
                int r9 = p000.w63.m14962a(r3, r9)
                r4[r8] = r9
                r8 = 4
                int[] r9 = p000.w63.f16578j
                r7[r8] = r9
                r4[r8] = r0
                r8 = 5
                int[] r9 = p000.w63.f16570b
                r7[r8] = r9
                int r9 = p000.w63.m14962a(r3, r9)
                r4[r8] = r9
                r8 = 6
                int[] r9 = p000.w63.f16571c
                r7[r8] = r9
                int r9 = p000.w63.m14962a(r3, r9)
                r4[r8] = r9
                r8 = 7
                int[] r9 = p000.w63.f16572d
                r7[r8] = r9
                int r9 = p000.w63.m14962a(r3, r9)
                r4[r8] = r9
                r8 = 8
                int[] r9 = p000.w63.f16573e
                r7[r8] = r9
                int r3 = p000.w63.m14962a(r3, r9)
                r4[r8] = r3
                r3 = 9
                int[] r8 = android.util.StateSet.NOTHING
                r7[r3] = r8
                r4[r3] = r0
                android.content.res.ColorStateList r3 = new android.content.res.ColorStateList
                r3.<init>(r7, r4)
            L_0x00dd:
                int r4 = android.os.Build.VERSION.SDK_INT
                r7 = 21
                if (r4 < r7) goto L_0x00f9
                android.graphics.drawable.RippleDrawable r0 = new android.graphics.drawable.RippleDrawable
                com.google.android.material.tabs.TabLayout r4 = com.google.android.material.tabs.TabLayout.this
                boolean r4 = r4.f3208C0
                if (r4 == 0) goto L_0x00ec
                r11 = r1
            L_0x00ec:
                com.google.android.material.tabs.TabLayout r4 = com.google.android.material.tabs.TabLayout.this
                boolean r4 = r4.f3208C0
                if (r4 == 0) goto L_0x00f3
                goto L_0x00f4
            L_0x00f3:
                r1 = r2
            L_0x00f4:
                r0.<init>(r3, r11, r1)
                r11 = r0
                goto L_0x010c
            L_0x00f9:
                android.graphics.drawable.Drawable r1 = p000.C0815h0.m5858e(r2)
                p000.C0815h0.m5802a((android.graphics.drawable.Drawable) r1, (android.content.res.ColorStateList) r3)
                android.graphics.drawable.LayerDrawable r2 = new android.graphics.drawable.LayerDrawable
                android.graphics.drawable.Drawable[] r3 = new android.graphics.drawable.Drawable[r6]
                r3[r0] = r11
                r3[r5] = r1
                r2.<init>(r3)
                r11 = r2
            L_0x010c:
                p000.C2189w7.m14987a((android.view.View) r10, (android.graphics.drawable.Drawable) r11)
                com.google.android.material.tabs.TabLayout r11 = com.google.android.material.tabs.TabLayout.this
                r11.invalidate()
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.tabs.TabLayout.C0463j.mo3931a(android.content.Context):void");
        }

        /* renamed from: a */
        public final boolean mo3933a() {
            return this.f3282e0 != null;
        }

        /* renamed from: b */
        public void mo3934b() {
            setTab((C0461h) null);
            setSelected(false);
        }

        /* renamed from: b */
        public final void mo3935b(View view) {
            if (mo3933a() && view != null) {
                setClipChildren(false);
                setClipToPadding(false);
                d43 d43 = this.f3282e0;
                FrameLayout a = mo3930a(view);
                e43.m3925b(d43, view, a);
                if (e43.f4259a) {
                    a.setForeground(d43);
                } else {
                    view.getOverlay().add(d43);
                }
                this.f3281d0 = view;
            }
        }

        /* renamed from: c */
        public final void mo3936c() {
            if (mo3933a() && this.f3281d0 != null) {
                setClipChildren(true);
                setClipToPadding(true);
                d43 d43 = this.f3282e0;
                View view = this.f3281d0;
                e43.m3924a(d43, view, mo3930a(view));
                this.f3281d0 = null;
            }
        }

        /* renamed from: c */
        public final void mo3937c(View view) {
            if (mo3933a() && view == this.f3281d0) {
                e43.m3925b(this.f3282e0, view, mo3930a(view));
            }
        }

        /* renamed from: d */
        public final void mo3938d() {
            C0461h hVar;
            View view;
            C0461h hVar2;
            if (mo3933a()) {
                if (this.f3283f0 == null) {
                    View view2 = this.f3280c0;
                    if (view2 == null || (hVar2 = this.f3278a0) == null || hVar2.f3267b == null) {
                        view2 = this.f3279b0;
                        if (!(view2 == null || (hVar = this.f3278a0) == null || hVar.f3272g != 1)) {
                            if (this.f3281d0 != view2) {
                                mo3936c();
                                view = this.f3279b0;
                            }
                            mo3937c(view2);
                            return;
                        }
                    } else {
                        if (this.f3281d0 != view2) {
                            mo3936c();
                            view = this.f3280c0;
                        }
                        mo3937c(view2);
                        return;
                    }
                    mo3935b(view);
                    return;
                }
                mo3936c();
            }
        }

        public void drawableStateChanged() {
            super.drawableStateChanged();
            int[] drawableState = getDrawableState();
            Drawable drawable = this.f3286i0;
            boolean z = false;
            if (drawable != null && drawable.isStateful()) {
                z = false | this.f3286i0.setState(drawableState);
            }
            if (z) {
                invalidate();
                TabLayout.this.invalidate();
            }
        }

        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v20, resolved type: com.google.android.material.tabs.TabLayout$j} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v23, resolved type: com.google.android.material.tabs.TabLayout$j} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v24, resolved type: android.widget.FrameLayout} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v25, resolved type: com.google.android.material.tabs.TabLayout$j} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v26, resolved type: com.google.android.material.tabs.TabLayout$j} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v27, resolved type: android.widget.FrameLayout} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v27, resolved type: com.google.android.material.tabs.TabLayout$j} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v33, resolved type: com.google.android.material.tabs.TabLayout$j} */
        /* JADX WARNING: Code restructure failed: missing block: B:74:0x0161, code lost:
            if ((r2.getSelectedTabPosition() == r0.f3270e) != false) goto L_0x016d;
         */
        /* JADX WARNING: Multi-variable type inference failed */
        /* renamed from: e */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final void mo3940e() {
            /*
                r7 = this;
                com.google.android.material.tabs.TabLayout$h r0 = r7.f3278a0
                r1 = 0
                if (r0 == 0) goto L_0x0008
                android.view.View r2 = r0.f3271f
                goto L_0x0009
            L_0x0008:
                r2 = r1
            L_0x0009:
                if (r2 == 0) goto L_0x0053
                android.view.ViewParent r3 = r2.getParent()
                if (r3 == r7) goto L_0x001b
                if (r3 == 0) goto L_0x0018
                android.view.ViewGroup r3 = (android.view.ViewGroup) r3
                r3.removeView(r2)
            L_0x0018:
                r7.addView(r2)
            L_0x001b:
                r7.f3283f0 = r2
                android.widget.TextView r3 = r7.f3279b0
                r4 = 8
                if (r3 == 0) goto L_0x0026
                r3.setVisibility(r4)
            L_0x0026:
                android.widget.ImageView r3 = r7.f3280c0
                if (r3 == 0) goto L_0x0032
                r3.setVisibility(r4)
                android.widget.ImageView r3 = r7.f3280c0
                r3.setImageDrawable(r1)
            L_0x0032:
                r3 = 16908308(0x1020014, float:2.3877285E-38)
                android.view.View r3 = r2.findViewById(r3)
                android.widget.TextView r3 = (android.widget.TextView) r3
                r7.f3284g0 = r3
                android.widget.TextView r3 = r7.f3284g0
                if (r3 == 0) goto L_0x0047
                int r3 = p000.C0815h0.m5838b((android.widget.TextView) r3)
                r7.f3287j0 = r3
            L_0x0047:
                r3 = 16908294(0x1020006, float:2.3877246E-38)
                android.view.View r2 = r2.findViewById(r3)
                android.widget.ImageView r2 = (android.widget.ImageView) r2
                r7.f3285h0 = r2
                goto L_0x0060
            L_0x0053:
                android.view.View r2 = r7.f3283f0
                if (r2 == 0) goto L_0x005c
                r7.removeView(r2)
                r7.f3283f0 = r1
            L_0x005c:
                r7.f3284g0 = r1
                r7.f3285h0 = r1
            L_0x0060:
                android.view.View r2 = r7.f3283f0
                r3 = 0
                if (r2 != 0) goto L_0x0131
                android.widget.ImageView r2 = r7.f3280c0
                r4 = -2
                if (r2 != 0) goto L_0x009b
                boolean r2 = p000.e43.f4259a
                if (r2 == 0) goto L_0x0083
                android.widget.FrameLayout r2 = new android.widget.FrameLayout
                android.content.Context r5 = r7.getContext()
                r2.<init>(r5)
                android.widget.FrameLayout$LayoutParams r5 = new android.widget.FrameLayout$LayoutParams
                r5.<init>(r4, r4)
                r2.setLayoutParams(r5)
                r7.addView(r2, r3)
                goto L_0x0084
            L_0x0083:
                r2 = r7
            L_0x0084:
                android.content.Context r5 = r7.getContext()
                android.view.LayoutInflater r5 = android.view.LayoutInflater.from(r5)
                int r6 = p000.h33.design_layout_tab_icon
                android.view.View r5 = r5.inflate(r6, r2, r3)
                android.widget.ImageView r5 = (android.widget.ImageView) r5
                r7.f3280c0 = r5
                android.widget.ImageView r5 = r7.f3280c0
                r2.addView(r5, r3)
            L_0x009b:
                if (r0 == 0) goto L_0x00a9
                android.graphics.drawable.Drawable r2 = r0.f3267b
                if (r2 == 0) goto L_0x00a9
                android.graphics.drawable.Drawable r1 = p000.C0815h0.m5858e(r2)
                android.graphics.drawable.Drawable r1 = r1.mutate()
            L_0x00a9:
                if (r1 == 0) goto L_0x00bb
                com.google.android.material.tabs.TabLayout r2 = com.google.android.material.tabs.TabLayout.this
                android.content.res.ColorStateList r2 = r2.f3229k0
                p000.C0815h0.m5802a((android.graphics.drawable.Drawable) r1, (android.content.res.ColorStateList) r2)
                com.google.android.material.tabs.TabLayout r2 = com.google.android.material.tabs.TabLayout.this
                android.graphics.PorterDuff$Mode r2 = r2.f3232n0
                if (r2 == 0) goto L_0x00bb
                p000.C0815h0.m5803a((android.graphics.drawable.Drawable) r1, (android.graphics.PorterDuff.Mode) r2)
            L_0x00bb:
                android.widget.TextView r1 = r7.f3279b0
                if (r1 != 0) goto L_0x00f8
                boolean r1 = p000.e43.f4259a
                if (r1 == 0) goto L_0x00d8
                android.widget.FrameLayout r1 = new android.widget.FrameLayout
                android.content.Context r2 = r7.getContext()
                r1.<init>(r2)
                android.widget.FrameLayout$LayoutParams r2 = new android.widget.FrameLayout$LayoutParams
                r2.<init>(r4, r4)
                r1.setLayoutParams(r2)
                r7.addView(r1)
                goto L_0x00d9
            L_0x00d8:
                r1 = r7
            L_0x00d9:
                android.content.Context r2 = r7.getContext()
                android.view.LayoutInflater r2 = android.view.LayoutInflater.from(r2)
                int r4 = p000.h33.design_layout_tab_text
                android.view.View r2 = r2.inflate(r4, r1, r3)
                android.widget.TextView r2 = (android.widget.TextView) r2
                r7.f3279b0 = r2
                android.widget.TextView r2 = r7.f3279b0
                r1.addView(r2)
                android.widget.TextView r1 = r7.f3279b0
                int r1 = p000.C0815h0.m5838b((android.widget.TextView) r1)
                r7.f3287j0 = r1
            L_0x00f8:
                android.widget.TextView r1 = r7.f3279b0
                com.google.android.material.tabs.TabLayout r2 = com.google.android.material.tabs.TabLayout.this
                int r2 = r2.f3227i0
                p000.C0815h0.m5857d(r1, r2)
                com.google.android.material.tabs.TabLayout r1 = com.google.android.material.tabs.TabLayout.this
                android.content.res.ColorStateList r1 = r1.f3228j0
                if (r1 == 0) goto L_0x010c
                android.widget.TextView r2 = r7.f3279b0
                r2.setTextColor(r1)
            L_0x010c:
                android.widget.TextView r1 = r7.f3279b0
                android.widget.ImageView r2 = r7.f3280c0
                r7.mo3932a((android.widget.TextView) r1, (android.widget.ImageView) r2)
                r7.mo3938d()
                android.widget.ImageView r1 = r7.f3280c0
                if (r1 != 0) goto L_0x011b
                goto L_0x0123
            L_0x011b:
                v73 r2 = new v73
                r2.<init>(r7, r1)
                r1.addOnLayoutChangeListener(r2)
            L_0x0123:
                android.widget.TextView r1 = r7.f3279b0
                if (r1 != 0) goto L_0x0128
                goto L_0x0140
            L_0x0128:
                v73 r2 = new v73
                r2.<init>(r7, r1)
                r1.addOnLayoutChangeListener(r2)
                goto L_0x0140
            L_0x0131:
                android.widget.TextView r1 = r7.f3284g0
                if (r1 != 0) goto L_0x0139
                android.widget.ImageView r1 = r7.f3285h0
                if (r1 == 0) goto L_0x0140
            L_0x0139:
                android.widget.TextView r1 = r7.f3284g0
                android.widget.ImageView r2 = r7.f3285h0
                r7.mo3932a((android.widget.TextView) r1, (android.widget.ImageView) r2)
            L_0x0140:
                if (r0 == 0) goto L_0x014f
                java.lang.CharSequence r1 = r0.f3269d
                boolean r1 = android.text.TextUtils.isEmpty(r1)
                if (r1 != 0) goto L_0x014f
                java.lang.CharSequence r1 = r0.f3269d
                r7.setContentDescription(r1)
            L_0x014f:
                r1 = 1
                if (r0 == 0) goto L_0x016c
                com.google.android.material.tabs.TabLayout r2 = r0.f3273h
                if (r2 == 0) goto L_0x0164
                int r2 = r2.getSelectedTabPosition()
                int r0 = r0.f3270e
                if (r2 != r0) goto L_0x0160
                r0 = 1
                goto L_0x0161
            L_0x0160:
                r0 = 0
            L_0x0161:
                if (r0 == 0) goto L_0x016c
                goto L_0x016d
            L_0x0164:
                java.lang.IllegalArgumentException r0 = new java.lang.IllegalArgumentException
                java.lang.String r1 = "Tab not attached to a TabLayout"
                r0.<init>(r1)
                throw r0
            L_0x016c:
                r1 = 0
            L_0x016d:
                r7.setSelected(r1)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.tabs.TabLayout.C0463j.mo3940e():void");
        }

        /* renamed from: f */
        public final void mo3941f() {
            ImageView imageView;
            TextView textView;
            setOrientation(TabLayout.this.f3206A0 ^ true ? 1 : 0);
            if (this.f3284g0 == null && this.f3285h0 == null) {
                textView = this.f3279b0;
                imageView = this.f3280c0;
            } else {
                textView = this.f3284g0;
                imageView = this.f3285h0;
            }
            mo3932a(textView, imageView);
        }

        public C0461h getTab() {
            return this.f3278a0;
        }

        public void onInitializeAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
            super.onInitializeAccessibilityEvent(accessibilityEvent);
            accessibilityEvent.setClassName(C1377n.C1380c.class.getName());
        }

        @TargetApi(14)
        public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
            Context context;
            super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
            accessibilityNodeInfo.setClassName(C1377n.C1380c.class.getName());
            d43 d43 = this.f3282e0;
            if (d43 != null && d43.isVisible()) {
                CharSequence contentDescription = getContentDescription();
                StringBuilder sb = new StringBuilder();
                sb.append(contentDescription);
                sb.append(", ");
                d43 d432 = this.f3282e0;
                Object obj = null;
                if (d432.isVisible()) {
                    if (!d432.mo4639d()) {
                        obj = d432.f3701e0.f3715c0;
                    } else if (d432.f3701e0.f3716d0 > 0 && (context = (Context) d432.f3694X.get()) != null) {
                        obj = context.getResources().getQuantityString(d432.f3701e0.f3716d0, d432.mo4638c(), new Object[]{Integer.valueOf(d432.mo4638c())});
                    }
                }
                sb.append(obj);
                accessibilityNodeInfo.setContentDescription(sb.toString());
            }
        }

        /* JADX WARNING: Code restructure failed: missing block: B:29:0x0096, code lost:
            if (((r0 / r2.getPaint().getTextSize()) * r2.getLineWidth(0)) > ((float) ((getMeasuredWidth() - getPaddingLeft()) - getPaddingRight()))) goto L_0x0098;
         */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void onMeasure(int r8, int r9) {
            /*
                r7 = this;
                int r0 = android.view.View.MeasureSpec.getSize(r8)
                int r1 = android.view.View.MeasureSpec.getMode(r8)
                com.google.android.material.tabs.TabLayout r2 = com.google.android.material.tabs.TabLayout.this
                int r2 = r2.getTabMaxWidth()
                if (r2 <= 0) goto L_0x001e
                if (r1 == 0) goto L_0x0014
                if (r0 <= r2) goto L_0x001e
            L_0x0014:
                com.google.android.material.tabs.TabLayout r8 = com.google.android.material.tabs.TabLayout.this
                int r8 = r8.f3236r0
                r0 = -2147483648(0xffffffff80000000, float:-0.0)
                int r8 = android.view.View.MeasureSpec.makeMeasureSpec(r8, r0)
            L_0x001e:
                super.onMeasure(r8, r9)
                android.widget.TextView r0 = r7.f3279b0
                if (r0 == 0) goto L_0x00a8
                com.google.android.material.tabs.TabLayout r0 = com.google.android.material.tabs.TabLayout.this
                float r0 = r0.f3233o0
                int r1 = r7.f3287j0
                android.widget.ImageView r2 = r7.f3280c0
                r3 = 1
                if (r2 == 0) goto L_0x0038
                int r2 = r2.getVisibility()
                if (r2 != 0) goto L_0x0038
                r1 = 1
                goto L_0x0046
            L_0x0038:
                android.widget.TextView r2 = r7.f3279b0
                if (r2 == 0) goto L_0x0046
                int r2 = r2.getLineCount()
                if (r2 <= r3) goto L_0x0046
                com.google.android.material.tabs.TabLayout r0 = com.google.android.material.tabs.TabLayout.this
                float r0 = r0.f3234p0
            L_0x0046:
                android.widget.TextView r2 = r7.f3279b0
                float r2 = r2.getTextSize()
                android.widget.TextView r4 = r7.f3279b0
                int r4 = r4.getLineCount()
                android.widget.TextView r5 = r7.f3279b0
                int r5 = p000.C0815h0.m5838b((android.widget.TextView) r5)
                int r6 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
                if (r6 != 0) goto L_0x0060
                if (r5 < 0) goto L_0x00a8
                if (r1 == r5) goto L_0x00a8
            L_0x0060:
                com.google.android.material.tabs.TabLayout r5 = com.google.android.material.tabs.TabLayout.this
                int r5 = r5.f3244z0
                r6 = 0
                if (r5 != r3) goto L_0x0099
                int r2 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
                if (r2 <= 0) goto L_0x0099
                if (r4 != r3) goto L_0x0099
                android.widget.TextView r2 = r7.f3279b0
                android.text.Layout r2 = r2.getLayout()
                if (r2 == 0) goto L_0x0098
                float r4 = r2.getLineWidth(r6)
                android.text.TextPaint r2 = r2.getPaint()
                float r2 = r2.getTextSize()
                float r2 = r0 / r2
                float r2 = r2 * r4
                int r4 = r7.getMeasuredWidth()
                int r5 = r7.getPaddingLeft()
                int r4 = r4 - r5
                int r5 = r7.getPaddingRight()
                int r4 = r4 - r5
                float r4 = (float) r4
                int r2 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
                if (r2 <= 0) goto L_0x0099
            L_0x0098:
                r3 = 0
            L_0x0099:
                if (r3 == 0) goto L_0x00a8
                android.widget.TextView r2 = r7.f3279b0
                r2.setTextSize(r6, r0)
                android.widget.TextView r0 = r7.f3279b0
                r0.setMaxLines(r1)
                super.onMeasure(r8, r9)
            L_0x00a8:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.tabs.TabLayout.C0463j.onMeasure(int, int):void");
        }

        public boolean performClick() {
            boolean performClick = super.performClick();
            if (this.f3278a0 == null) {
                return performClick;
            }
            if (!performClick) {
                playSoundEffect(0);
            }
            C0461h hVar = this.f3278a0;
            TabLayout tabLayout = hVar.f3273h;
            if (tabLayout != null) {
                tabLayout.mo3867c(hVar);
                return true;
            }
            throw new IllegalArgumentException("Tab not attached to a TabLayout");
        }

        public void setSelected(boolean z) {
            boolean z2 = isSelected() != z;
            super.setSelected(z);
            if (z2 && z) {
                int i = Build.VERSION.SDK_INT;
            }
            TextView textView = this.f3279b0;
            if (textView != null) {
                textView.setSelected(z);
            }
            ImageView imageView = this.f3280c0;
            if (imageView != null) {
                imageView.setSelected(z);
            }
            View view = this.f3283f0;
            if (view != null) {
                view.setSelected(z);
            }
        }

        public void setTab(C0461h hVar) {
            if (hVar != this.f3278a0) {
                this.f3278a0 = hVar;
                mo3940e();
            }
        }

        /* JADX WARNING: Code restructure failed: missing block: B:2:0x0005, code lost:
            r0 = r0.f3267b;
         */
        /* renamed from: a */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final void mo3932a(android.widget.TextView r7, android.widget.ImageView r8) {
            /*
                r6 = this;
                com.google.android.material.tabs.TabLayout$h r0 = r6.f3278a0
                r1 = 0
                if (r0 == 0) goto L_0x0012
                android.graphics.drawable.Drawable r0 = r0.f3267b
                if (r0 == 0) goto L_0x0012
                android.graphics.drawable.Drawable r0 = p000.C0815h0.m5858e(r0)
                android.graphics.drawable.Drawable r0 = r0.mutate()
                goto L_0x0013
            L_0x0012:
                r0 = r1
            L_0x0013:
                com.google.android.material.tabs.TabLayout$h r2 = r6.f3278a0
                if (r2 == 0) goto L_0x001a
                java.lang.CharSequence r2 = r2.f3268c
                goto L_0x001b
            L_0x001a:
                r2 = r1
            L_0x001b:
                r3 = 8
                r4 = 0
                if (r8 == 0) goto L_0x0032
                if (r0 == 0) goto L_0x002c
                r8.setImageDrawable(r0)
                r8.setVisibility(r4)
                r6.setVisibility(r4)
                goto L_0x0032
            L_0x002c:
                r8.setVisibility(r3)
                r8.setImageDrawable(r1)
            L_0x0032:
                boolean r0 = android.text.TextUtils.isEmpty(r2)
                r5 = 1
                r0 = r0 ^ r5
                if (r7 == 0) goto L_0x0056
                if (r0 == 0) goto L_0x0050
                r7.setText(r2)
                com.google.android.material.tabs.TabLayout$h r2 = r6.f3278a0
                int r2 = r2.f3272g
                if (r2 != r5) goto L_0x0049
                r7.setVisibility(r4)
                goto L_0x004c
            L_0x0049:
                r7.setVisibility(r3)
            L_0x004c:
                r6.setVisibility(r4)
                goto L_0x0056
            L_0x0050:
                r7.setVisibility(r3)
                r7.setText(r1)
            L_0x0056:
                if (r8 == 0) goto L_0x0096
                android.view.ViewGroup$LayoutParams r7 = r8.getLayoutParams()
                android.view.ViewGroup$MarginLayoutParams r7 = (android.view.ViewGroup.MarginLayoutParams) r7
                if (r0 == 0) goto L_0x0070
                int r2 = r8.getVisibility()
                if (r2 != 0) goto L_0x0070
                android.content.Context r2 = r6.getContext()
                float r2 = p000.t53.m13068a((android.content.Context) r2, (int) r3)
                int r2 = (int) r2
                goto L_0x0071
            L_0x0070:
                r2 = 0
            L_0x0071:
                com.google.android.material.tabs.TabLayout r3 = com.google.android.material.tabs.TabLayout.this
                boolean r3 = r3.f3206A0
                if (r3 == 0) goto L_0x0085
                int r3 = p000.C0815h0.m5774a((android.view.ViewGroup.MarginLayoutParams) r7)
                if (r2 == r3) goto L_0x0096
                int r3 = android.os.Build.VERSION.SDK_INT
                r7.setMarginEnd(r2)
                r7.bottomMargin = r4
                goto L_0x0090
            L_0x0085:
                int r3 = r7.bottomMargin
                if (r2 == r3) goto L_0x0096
                r7.bottomMargin = r2
                int r2 = android.os.Build.VERSION.SDK_INT
                r7.setMarginEnd(r4)
            L_0x0090:
                r8.setLayoutParams(r7)
                r8.requestLayout()
            L_0x0096:
                com.google.android.material.tabs.TabLayout$h r7 = r6.f3278a0
                if (r7 == 0) goto L_0x009d
                java.lang.CharSequence r7 = r7.f3269d
                goto L_0x009e
            L_0x009d:
                r7 = r1
            L_0x009e:
                if (r0 == 0) goto L_0x00a1
                r7 = r1
            L_0x00a1:
                p000.C0815h0.m5806a((android.view.View) r6, (java.lang.CharSequence) r7)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.tabs.TabLayout.C0463j.mo3932a(android.widget.TextView, android.widget.ImageView):void");
        }
    }

    /* renamed from: com.google.android.material.tabs.TabLayout$g */
    public class C0458g extends LinearLayout {

        /* renamed from: a0 */
        public int f3249a0;

        /* renamed from: b0 */
        public final Paint f3250b0;

        /* renamed from: c0 */
        public final GradientDrawable f3251c0;

        /* renamed from: d0 */
        public int f3252d0 = -1;

        /* renamed from: e0 */
        public float f3253e0;

        /* renamed from: f0 */
        public int f3254f0 = -1;

        /* renamed from: g0 */
        public int f3255g0 = -1;

        /* renamed from: h0 */
        public int f3256h0 = -1;

        /* renamed from: i0 */
        public ValueAnimator f3257i0;

        /* renamed from: com.google.android.material.tabs.TabLayout$g$a */
        public class C0459a implements ValueAnimator.AnimatorUpdateListener {

            /* renamed from: a */
            public final /* synthetic */ int f3259a;

            /* renamed from: b */
            public final /* synthetic */ int f3260b;

            /* renamed from: c */
            public final /* synthetic */ int f3261c;

            /* renamed from: d */
            public final /* synthetic */ int f3262d;

            public C0459a(int i, int i2, int i3, int i4) {
                this.f3259a = i;
                this.f3260b = i2;
                this.f3261c = i3;
                this.f3262d = i4;
            }

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                float animatedFraction = valueAnimator.getAnimatedFraction();
                C0458g gVar = C0458g.this;
                int a = m33.m9017a(this.f3259a, this.f3260b, animatedFraction);
                int a2 = m33.m9017a(this.f3261c, this.f3262d, animatedFraction);
                if (a != gVar.f3255g0 || a2 != gVar.f3256h0) {
                    gVar.f3255g0 = a;
                    gVar.f3256h0 = a2;
                    C2189w7.m14972D(gVar);
                }
            }
        }

        /* renamed from: com.google.android.material.tabs.TabLayout$g$b */
        public class C0460b extends AnimatorListenerAdapter {

            /* renamed from: a */
            public final /* synthetic */ int f3264a;

            public C0460b(int i) {
                this.f3264a = i;
            }

            public void onAnimationEnd(Animator animator) {
                C0458g gVar = C0458g.this;
                gVar.f3252d0 = this.f3264a;
                gVar.f3253e0 = 0.0f;
            }
        }

        public C0458g(Context context) {
            super(context);
            setWillNotDraw(false);
            this.f3250b0 = new Paint();
            this.f3251c0 = new GradientDrawable();
        }

        /* renamed from: a */
        public void mo3918a(int i, int i2) {
            ValueAnimator valueAnimator = this.f3257i0;
            if (valueAnimator != null && valueAnimator.isRunning()) {
                this.f3257i0.cancel();
            }
            View childAt = getChildAt(i);
            if (childAt == null) {
                mo3917a();
                return;
            }
            int left = childAt.getLeft();
            int right = childAt.getRight();
            TabLayout tabLayout = TabLayout.this;
            if (!tabLayout.f3207B0 && (childAt instanceof C0463j)) {
                mo3919a((C0463j) childAt, tabLayout.f3221c0);
                RectF rectF = TabLayout.this.f3221c0;
                left = (int) rectF.left;
                right = (int) rectF.right;
            }
            int i3 = left;
            int i4 = right;
            int i5 = this.f3255g0;
            int i6 = this.f3256h0;
            if (i5 != i3 || i6 != i4) {
                ValueAnimator valueAnimator2 = new ValueAnimator();
                this.f3257i0 = valueAnimator2;
                valueAnimator2.setInterpolator(m33.f9975b);
                valueAnimator2.setDuration((long) i2);
                valueAnimator2.setFloatValues(new float[]{0.0f, 1.0f});
                valueAnimator2.addUpdateListener(new C0459a(i5, i3, i6, i4));
                valueAnimator2.addListener(new C0460b(i));
                valueAnimator2.start();
            }
        }

        /* renamed from: a */
        public final void mo3919a(C0463j jVar, RectF rectF) {
            int a = jVar.getContentWidth();
            int a2 = (int) t53.m13068a(getContext(), 24);
            if (a < a2) {
                a = a2;
            }
            int right = (jVar.getRight() + jVar.getLeft()) / 2;
            int i = a / 2;
            rectF.set((float) (right - i), 0.0f, (float) (right + i), 0.0f);
        }

        /* JADX WARNING: Removed duplicated region for block: B:24:0x0049  */
        /* JADX WARNING: Removed duplicated region for block: B:27:0x005a  */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void draw(android.graphics.Canvas r6) {
            /*
                r5 = this;
                com.google.android.material.tabs.TabLayout r0 = com.google.android.material.tabs.TabLayout.this
                android.graphics.drawable.Drawable r0 = r0.f3231m0
                r1 = 0
                if (r0 == 0) goto L_0x000c
                int r0 = r0.getIntrinsicHeight()
                goto L_0x000d
            L_0x000c:
                r0 = 0
            L_0x000d:
                int r2 = r5.f3249a0
                if (r2 < 0) goto L_0x0012
                r0 = r2
            L_0x0012:
                com.google.android.material.tabs.TabLayout r2 = com.google.android.material.tabs.TabLayout.this
                int r2 = r2.f3243y0
                if (r2 == 0) goto L_0x0031
                r3 = 1
                r4 = 2
                if (r2 == r3) goto L_0x0023
                if (r2 == r4) goto L_0x003a
                r0 = 3
                if (r2 == r0) goto L_0x0036
                r0 = 0
                goto L_0x003a
            L_0x0023:
                int r1 = r5.getHeight()
                int r1 = r1 - r0
                int r1 = r1 / r4
                int r2 = r5.getHeight()
                int r2 = r2 + r0
                int r0 = r2 / 2
                goto L_0x003a
            L_0x0031:
                int r1 = r5.getHeight()
                int r1 = r1 - r0
            L_0x0036:
                int r0 = r5.getHeight()
            L_0x003a:
                int r2 = r5.f3255g0
                if (r2 < 0) goto L_0x0070
                int r3 = r5.f3256h0
                if (r3 <= r2) goto L_0x0070
                com.google.android.material.tabs.TabLayout r2 = com.google.android.material.tabs.TabLayout.this
                android.graphics.drawable.Drawable r2 = r2.f3231m0
                if (r2 == 0) goto L_0x0049
                goto L_0x004b
            L_0x0049:
                android.graphics.drawable.GradientDrawable r2 = r5.f3251c0
            L_0x004b:
                android.graphics.drawable.Drawable r2 = p000.C0815h0.m5858e(r2)
                int r3 = r5.f3255g0
                int r4 = r5.f3256h0
                r2.setBounds(r3, r1, r4, r0)
                android.graphics.Paint r0 = r5.f3250b0
                if (r0 == 0) goto L_0x006d
                int r1 = android.os.Build.VERSION.SDK_INT
                r3 = 21
                int r0 = r0.getColor()
                if (r1 != r3) goto L_0x006a
                android.graphics.PorterDuff$Mode r1 = android.graphics.PorterDuff.Mode.SRC_IN
                r2.setColorFilter(r0, r1)
                goto L_0x006d
            L_0x006a:
                p000.C0815h0.m5845b((android.graphics.drawable.Drawable) r2, (int) r0)
            L_0x006d:
                r2.draw(r6)
            L_0x0070:
                super.draw(r6)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.tabs.TabLayout.C0458g.draw(android.graphics.Canvas):void");
        }

        public void onLayout(boolean z, int i, int i2, int i3, int i4) {
            super.onLayout(z, i, i2, i3, i4);
            ValueAnimator valueAnimator = this.f3257i0;
            if (valueAnimator == null || !valueAnimator.isRunning()) {
                mo3917a();
                return;
            }
            this.f3257i0.cancel();
            mo3918a(this.f3252d0, Math.round((1.0f - this.f3257i0.getAnimatedFraction()) * ((float) this.f3257i0.getDuration())));
        }

        public void onMeasure(int i, int i2) {
            boolean z;
            super.onMeasure(i, i2);
            if (View.MeasureSpec.getMode(i) == 1073741824) {
                TabLayout tabLayout = TabLayout.this;
                if (tabLayout.f3241w0 == 1 || tabLayout.f3244z0 == 2) {
                    int childCount = getChildCount();
                    int i3 = 0;
                    for (int i4 = 0; i4 < childCount; i4++) {
                        View childAt = getChildAt(i4);
                        if (childAt.getVisibility() == 0) {
                            i3 = Math.max(i3, childAt.getMeasuredWidth());
                        }
                    }
                    if (i3 > 0) {
                        if (i3 * childCount <= getMeasuredWidth() - (((int) t53.m13068a(getContext(), 16)) * 2)) {
                            z = false;
                            for (int i5 = 0; i5 < childCount; i5++) {
                                LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) getChildAt(i5).getLayoutParams();
                                if (layoutParams.width != i3 || layoutParams.weight != 0.0f) {
                                    layoutParams.width = i3;
                                    layoutParams.weight = 0.0f;
                                    z = true;
                                }
                            }
                        } else {
                            TabLayout tabLayout2 = TabLayout.this;
                            tabLayout2.f3241w0 = 0;
                            tabLayout2.mo3856a(false);
                            z = true;
                        }
                        if (z) {
                            super.onMeasure(i, i2);
                        }
                    }
                }
            }
        }

        public void onRtlPropertiesChanged(int i) {
            super.onRtlPropertiesChanged(i);
            if (Build.VERSION.SDK_INT < 23 && this.f3254f0 != i) {
                requestLayout();
                this.f3254f0 = i;
            }
        }

        /* renamed from: a */
        public final void mo3917a() {
            int i;
            int i2;
            View childAt = getChildAt(this.f3252d0);
            int i3 = -1;
            if (childAt == null || childAt.getWidth() <= 0) {
                i = -1;
            } else {
                i = childAt.getLeft();
                int right = childAt.getRight();
                TabLayout tabLayout = TabLayout.this;
                if (tabLayout.f3207B0 || !(childAt instanceof C0463j)) {
                    i2 = right;
                } else {
                    mo3919a((C0463j) childAt, tabLayout.f3221c0);
                    RectF rectF = TabLayout.this.f3221c0;
                    i = (int) rectF.left;
                    i2 = (int) rectF.right;
                }
                if (this.f3253e0 <= 0.0f || this.f3252d0 >= getChildCount() - 1) {
                    i3 = i2;
                } else {
                    View childAt2 = getChildAt(this.f3252d0 + 1);
                    int left = childAt2.getLeft();
                    int right2 = childAt2.getRight();
                    TabLayout tabLayout2 = TabLayout.this;
                    if (!tabLayout2.f3207B0 && (childAt2 instanceof C0463j)) {
                        mo3919a((C0463j) childAt2, tabLayout2.f3221c0);
                        RectF rectF2 = TabLayout.this.f3221c0;
                        left = (int) rectF2.left;
                        right2 = (int) rectF2.right;
                    }
                    float f = this.f3253e0;
                    float f2 = 1.0f - f;
                    i = (int) ((((float) i) * f2) + (((float) left) * f));
                    i3 = (int) ((f2 * ((float) i2)) + (((float) right2) * f));
                }
            }
            if (i != this.f3255g0 || i3 != this.f3256h0) {
                this.f3255g0 = i;
                this.f3256h0 = i3;
                C2189w7.m14972D(this);
            }
        }
    }

    /* renamed from: a */
    public final void mo3847a(View view) {
        if (view instanceof u73) {
            u73 u73 = (u73) view;
            C0461h e = mo3869e();
            CharSequence charSequence = u73.f15362a0;
            if (charSequence != null) {
                e.mo3926a(charSequence);
            }
            Drawable drawable = u73.f15363b0;
            if (drawable != null) {
                e.f3267b = drawable;
                TabLayout tabLayout = e.f3273h;
                if (tabLayout.f3241w0 == 1 || tabLayout.f3244z0 == 2) {
                    e.f3273h.mo3856a(true);
                }
                e.mo3927a();
                if (e43.f4259a && e.f3274i.mo3933a() && e.f3274i.f3282e0.isVisible()) {
                    e.f3274i.invalidate();
                }
            }
            int i = u73.f15364c0;
            if (i != 0) {
                e.f3271f = LayoutInflater.from(e.f3274i.getContext()).inflate(i, e.f3274i, false);
                e.mo3927a();
            }
            if (!TextUtils.isEmpty(u73.getContentDescription())) {
                e.f3269d = u73.getContentDescription();
                e.mo3927a();
            }
            mo3850a(e);
            return;
        }
        throw new IllegalArgumentException("Only TabItem instances can be added to TabLayout");
    }

    /* renamed from: a */
    public final void mo3844a(int i) {
        boolean z;
        if (i != -1) {
            if (getWindowToken() != null && C2189w7.m15031z(this)) {
                C0458g gVar = this.f3222d0;
                int childCount = gVar.getChildCount();
                int i2 = 0;
                while (true) {
                    if (i2 >= childCount) {
                        z = false;
                        break;
                    } else if (gVar.getChildAt(i2).getWidth() <= 0) {
                        z = true;
                        break;
                    } else {
                        i2++;
                    }
                }
                if (!z) {
                    int scrollX = getScrollX();
                    int a = mo3841a(i, 0.0f);
                    if (scrollX != a) {
                        mo3868d();
                        this.f3212G0.setIntValues(new int[]{scrollX, a});
                        this.f3212G0.start();
                    }
                    this.f3222d0.mo3918a(i, this.f3242x0);
                    return;
                }
            }
            mo3845a(i, 0.0f, true);
        }
    }

    /* renamed from: a */
    public void mo3846a(int i, float f, boolean z, boolean z2) {
        int round = Math.round(((float) i) + f);
        if (round >= 0 && round < this.f3222d0.getChildCount()) {
            if (z2) {
                C0458g gVar = this.f3222d0;
                ValueAnimator valueAnimator = gVar.f3257i0;
                if (valueAnimator != null && valueAnimator.isRunning()) {
                    gVar.f3257i0.cancel();
                }
                gVar.f3252d0 = i;
                gVar.f3253e0 = f;
                gVar.mo3917a();
            }
            ValueAnimator valueAnimator2 = this.f3212G0;
            if (valueAnimator2 != null && valueAnimator2.isRunning()) {
                this.f3212G0.cancel();
            }
            scrollTo(mo3841a(i, f), 0);
            if (z) {
                setSelectedTabView(round);
            }
        }
    }

    /* renamed from: a */
    public final void mo3855a(C0681ff ffVar, boolean z, boolean z2) {
        C0681ff ffVar2 = this.f3213H0;
        if (ffVar2 != null) {
            C0462i iVar = this.f3215J0;
            if (iVar != null) {
                ffVar2.mo5583b((C0681ff.C0688g) iVar);
            }
            C0454c cVar = this.f3216K0;
            if (cVar != null) {
                this.f3213H0.mo5582b((C0681ff.C0687f) cVar);
            }
        }
        C0456e eVar = this.f3210E0;
        if (eVar != null) {
            mo3863b(eVar);
            this.f3210E0 = null;
        }
        if (ffVar != null) {
            this.f3213H0 = ffVar;
            if (this.f3215J0 == null) {
                this.f3215J0 = new C0462i(this);
            }
            C0462i iVar2 = this.f3215J0;
            iVar2.f3277c = 0;
            iVar2.f3276b = 0;
            ffVar.mo5573a((C0681ff.C0688g) iVar2);
            this.f3210E0 = new C0464k(ffVar);
            mo3849a(this.f3210E0);
            C0603ef adapter = ffVar.getAdapter();
            if (adapter != null) {
                mo3853a(adapter, z);
            }
            if (this.f3216K0 == null) {
                this.f3216K0 = new C0454c();
            }
            C0454c cVar2 = this.f3216K0;
            cVar2.f3246a = z;
            ffVar.mo5572a((C0681ff.C0687f) cVar2);
            mo3845a(ffVar.getCurrentItem(), 0.0f, true);
        } else {
            this.f3213H0 = null;
            mo3853a((C0603ef) null, false);
        }
        this.f3217L0 = z2;
    }
}
