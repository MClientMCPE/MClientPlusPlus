package com.google.android.material.chip;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.SpannableStringBuilder;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.PointerIcon;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;
import java.util.List;
import p000.C0045a7;
import p000.C0759g8;
import p000.f73;
import p000.q43;

public class Chip extends C0576e2 implements q43.C1667a, m73 {

    /* renamed from: t0 */
    public static final Rect f3119t0 = new Rect();

    /* renamed from: u0 */
    public static final int[] f3120u0 = {16842913};

    /* renamed from: v0 */
    public static final int[] f3121v0 = {16842911};

    /* renamed from: d0 */
    public q43 f3122d0;

    /* renamed from: e0 */
    public InsetDrawable f3123e0;

    /* renamed from: f0 */
    public RippleDrawable f3124f0;

    /* renamed from: g0 */
    public View.OnClickListener f3125g0;

    /* renamed from: h0 */
    public CompoundButton.OnCheckedChangeListener f3126h0;

    /* renamed from: i0 */
    public boolean f3127i0;

    /* renamed from: j0 */
    public boolean f3128j0;

    /* renamed from: k0 */
    public boolean f3129k0;

    /* renamed from: l0 */
    public boolean f3130l0;

    /* renamed from: m0 */
    public boolean f3131m0;

    /* renamed from: n0 */
    public int f3132n0;

    /* renamed from: o0 */
    public int f3133o0;

    /* renamed from: p0 */
    public final C0436b f3134p0;

    /* renamed from: q0 */
    public final Rect f3135q0;

    /* renamed from: r0 */
    public final RectF f3136r0;

    /* renamed from: s0 */
    public final u63 f3137s0;

    /* renamed from: com.google.android.material.chip.Chip$a */
    public class C0435a extends u63 {
        public C0435a() {
        }

        /* renamed from: a */
        public void mo3645a(int i) {
        }

        /* renamed from: a */
        public void mo3646a(Typeface typeface, boolean z) {
            CharSequence charSequence;
            Chip chip = Chip.this;
            q43 q43 = chip.f3122d0;
            if (q43.f12883z1) {
                charSequence = q43.f12823A0;
            } else {
                charSequence = chip.getText();
            }
            chip.setText(charSequence);
            Chip.this.requestLayout();
            Chip.this.invalidate();
        }
    }

    /* renamed from: com.google.android.material.chip.Chip$b */
    public class C0436b extends C1985u8 {
        public C0436b(Chip chip) {
            super(chip);
        }

        /* renamed from: a */
        public void mo3647a(int i, C0759g8 g8Var) {
            if (i == 1) {
                CharSequence closeIconContentDescription = Chip.this.getCloseIconContentDescription();
                if (closeIconContentDescription == null) {
                    CharSequence text = Chip.this.getText();
                    Context context = Chip.this.getContext();
                    int i2 = j33.mtrl_chip_close_icon_content_description;
                    Object[] objArr = new Object[1];
                    if (TextUtils.isEmpty(text)) {
                        text = "";
                    }
                    objArr[0] = text;
                    closeIconContentDescription = context.getString(i2, objArr).trim();
                }
                g8Var.f6028a.setContentDescription(closeIconContentDescription);
                g8Var.f6028a.setBoundsInParent(Chip.this.getCloseIconTouchBoundsInt());
                C0759g8.C0760a aVar = C0759g8.C0760a.f6031e;
                if (Build.VERSION.SDK_INT >= 21) {
                    g8Var.f6028a.addAction((AccessibilityNodeInfo.AccessibilityAction) aVar.f6035a);
                }
                g8Var.f6028a.setEnabled(Chip.this.isEnabled());
                return;
            }
            g8Var.f6028a.setContentDescription("");
            g8Var.f6028a.setBoundsInParent(Chip.f3119t0);
        }

        /* renamed from: a */
        public void mo3648a(List<Integer> list) {
            list.add(0);
            if (Chip.this.mo3499b() && Chip.this.mo3501d()) {
                list.add(1);
            }
        }

        /* renamed from: a */
        public boolean mo3649a(int i, int i2, Bundle bundle) {
            if (i2 != 16) {
                return false;
            }
            if (i == 0) {
                return Chip.this.performClick();
            }
            if (i == 1) {
                return Chip.this.mo3505e();
            }
            return false;
        }
    }

    public Chip(Context context) {
        this(context, (AttributeSet) null);
    }

    public Chip(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, b33.chipStyle);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:32:0x0108, code lost:
        r7 = r4.getResourceId(r7, 0);
     */
    /* JADX WARNING: Removed duplicated region for block: B:55:0x016a  */
    /* JADX WARNING: Removed duplicated region for block: B:72:0x02b6  */
    /* JADX WARNING: Removed duplicated region for block: B:75:0x02d5  */
    /* JADX WARNING: Removed duplicated region for block: B:76:0x02db  */
    /* JADX WARNING: Removed duplicated region for block: B:83:0x0309  */
    /* JADX WARNING: Removed duplicated region for block: B:86:0x0318  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public Chip(android.content.Context r12, android.util.AttributeSet r13, int r14) {
        /*
            r11 = this;
            r11.<init>(r12, r13, r14)
            android.graphics.Rect r0 = new android.graphics.Rect
            r0.<init>()
            r11.f3135q0 = r0
            android.graphics.RectF r0 = new android.graphics.RectF
            r0.<init>()
            r11.f3136r0 = r0
            com.google.android.material.chip.Chip$a r0 = new com.google.android.material.chip.Chip$a
            r0.<init>()
            r11.f3137s0 = r0
            r0 = 8388627(0x800013, float:1.175497E-38)
            r1 = 1
            if (r13 != 0) goto L_0x001f
            goto L_0x007f
        L_0x001f:
            java.lang.String r2 = "http://schemas.android.com/apk/res/android"
            java.lang.String r3 = "background"
            java.lang.String r3 = r13.getAttributeValue(r2, r3)
            java.lang.String r4 = "Chip"
            if (r3 == 0) goto L_0x0030
            java.lang.String r3 = "Do not set the background; Chip manages its own background drawable."
            android.util.Log.w(r4, r3)
        L_0x0030:
            java.lang.String r3 = "drawableLeft"
            java.lang.String r3 = r13.getAttributeValue(r2, r3)
            if (r3 != 0) goto L_0x0340
            java.lang.String r3 = "drawableStart"
            java.lang.String r3 = r13.getAttributeValue(r2, r3)
            if (r3 != 0) goto L_0x0338
            java.lang.String r3 = "drawableEnd"
            java.lang.String r3 = r13.getAttributeValue(r2, r3)
            java.lang.String r5 = "Please set end drawable using R.attr#closeIcon."
            if (r3 != 0) goto L_0x0332
            java.lang.String r3 = "drawableRight"
            java.lang.String r3 = r13.getAttributeValue(r2, r3)
            if (r3 != 0) goto L_0x032c
            java.lang.String r3 = "singleLine"
            boolean r3 = r13.getAttributeBooleanValue(r2, r3, r1)
            if (r3 == 0) goto L_0x0324
            java.lang.String r3 = "lines"
            int r3 = r13.getAttributeIntValue(r2, r3, r1)
            if (r3 != r1) goto L_0x0324
            java.lang.String r3 = "minLines"
            int r3 = r13.getAttributeIntValue(r2, r3, r1)
            if (r3 != r1) goto L_0x0324
            java.lang.String r3 = "maxLines"
            int r3 = r13.getAttributeIntValue(r2, r3, r1)
            if (r3 != r1) goto L_0x0324
            java.lang.String r3 = "gravity"
            int r2 = r13.getAttributeIntValue(r2, r3, r0)
            if (r2 == r0) goto L_0x007f
            java.lang.String r2 = "Chip text must be vertically center and start aligned"
            android.util.Log.w(r4, r2)
        L_0x007f:
            int r9 = p000.k33.Widget_MaterialComponents_Chip_Action
            q43 r2 = new q43
            r2.<init>(r12, r13, r14, r9)
            android.content.Context r5 = r2.f12850Z0
            int[] r7 = p000.l33.Chip
            r3 = 0
            int[] r10 = new int[r3]
            r6 = r13
            r8 = r14
            android.content.res.TypedArray r4 = p000.o63.m10328b(r5, r6, r7, r8, r9, r10)
            int r5 = p000.l33.Chip_shapeAppearance
            boolean r5 = r4.hasValue(r5)
            r2.f12826B1 = r5
            android.content.Context r5 = r2.f12850Z0
            int r6 = p000.l33.Chip_chipSurfaceColor
            android.content.res.ColorStateList r5 = p000.t53.m13077a((android.content.Context) r5, (android.content.res.TypedArray) r4, (int) r6)
            android.content.res.ColorStateList r6 = r2.f12870t0
            if (r6 == r5) goto L_0x00b0
            r2.f12870t0 = r5
            int[] r5 = r2.getState()
            r2.onStateChange(r5)
        L_0x00b0:
            android.content.Context r5 = r2.f12850Z0
            int r6 = p000.l33.Chip_chipBackgroundColor
            android.content.res.ColorStateList r5 = p000.t53.m13077a((android.content.Context) r5, (android.content.res.TypedArray) r4, (int) r6)
            r2.mo10202c((android.content.res.ColorStateList) r5)
            int r5 = p000.l33.Chip_chipMinHeight
            r6 = 0
            float r5 = r4.getDimension(r5, r6)
            r2.mo10214f((float) r5)
            int r5 = p000.l33.Chip_chipCornerRadius
            boolean r5 = r4.hasValue(r5)
            if (r5 == 0) goto L_0x00d6
            int r5 = p000.l33.Chip_chipCornerRadius
            float r5 = r4.getDimension(r5, r6)
            r2.mo10201c((float) r5)
        L_0x00d6:
            android.content.Context r5 = r2.f12850Z0
            int r7 = p000.l33.Chip_chipStrokeColor
            android.content.res.ColorStateList r5 = p000.t53.m13077a((android.content.Context) r5, (android.content.res.TypedArray) r4, (int) r7)
            r2.mo10211e((android.content.res.ColorStateList) r5)
            int r5 = p000.l33.Chip_chipStrokeWidth
            float r5 = r4.getDimension(r5, r6)
            r2.mo10222h((float) r5)
            android.content.Context r5 = r2.f12850Z0
            int r7 = p000.l33.Chip_rippleColor
            android.content.res.ColorStateList r5 = p000.t53.m13077a((android.content.Context) r5, (android.content.res.TypedArray) r4, (int) r7)
            r2.mo10217g((android.content.res.ColorStateList) r5)
            int r5 = p000.l33.Chip_android_text
            java.lang.CharSequence r5 = r4.getText(r5)
            r2.mo10192a((java.lang.CharSequence) r5)
            android.content.Context r5 = r2.f12850Z0
            int r7 = p000.l33.Chip_android_textAppearance
            boolean r8 = r4.hasValue(r7)
            if (r8 == 0) goto L_0x0114
            int r7 = r4.getResourceId(r7, r3)
            if (r7 == 0) goto L_0x0114
            s63 r8 = new s63
            r8.<init>(r5, r7)
            goto L_0x0115
        L_0x0114:
            r8 = 0
        L_0x0115:
            r2.mo10194a((p000.s63) r8)
            int r5 = p000.l33.Chip_android_ellipsize
            int r5 = r4.getInt(r5, r3)
            if (r5 == r1) goto L_0x012d
            r1 = 2
            if (r5 == r1) goto L_0x012a
            r1 = 3
            if (r5 == r1) goto L_0x0127
            goto L_0x0131
        L_0x0127:
            android.text.TextUtils$TruncateAt r1 = android.text.TextUtils.TruncateAt.END
            goto L_0x012f
        L_0x012a:
            android.text.TextUtils$TruncateAt r1 = android.text.TextUtils.TruncateAt.MIDDLE
            goto L_0x012f
        L_0x012d:
            android.text.TextUtils$TruncateAt r1 = android.text.TextUtils.TruncateAt.START
        L_0x012f:
            r2.f12881y1 = r1
        L_0x0131:
            int r1 = p000.l33.Chip_chipIconVisible
            boolean r1 = r4.getBoolean(r1, r3)
            r2.mo10205c((boolean) r1)
            java.lang.String r1 = "http://schemas.android.com/apk/res-auto"
            if (r13 == 0) goto L_0x0157
            java.lang.String r5 = "chipIconEnabled"
            java.lang.String r5 = r13.getAttributeValue(r1, r5)
            if (r5 == 0) goto L_0x0157
            java.lang.String r5 = "chipIconVisible"
            java.lang.String r5 = r13.getAttributeValue(r1, r5)
            if (r5 != 0) goto L_0x0157
            int r5 = p000.l33.Chip_chipIconEnabled
            boolean r5 = r4.getBoolean(r5, r3)
            r2.mo10205c((boolean) r5)
        L_0x0157:
            android.content.Context r5 = r2.f12850Z0
            int r7 = p000.l33.Chip_chipIcon
            android.graphics.drawable.Drawable r5 = p000.t53.m13122b((android.content.Context) r5, (android.content.res.TypedArray) r4, (int) r7)
            r2.mo10204c((android.graphics.drawable.Drawable) r5)
            int r5 = p000.l33.Chip_chipIconTint
            boolean r5 = r4.hasValue(r5)
            if (r5 == 0) goto L_0x0175
            android.content.Context r5 = r2.f12850Z0
            int r7 = p000.l33.Chip_chipIconTint
            android.content.res.ColorStateList r5 = p000.t53.m13077a((android.content.Context) r5, (android.content.res.TypedArray) r4, (int) r7)
            r2.mo10207d((android.content.res.ColorStateList) r5)
        L_0x0175:
            int r5 = p000.l33.Chip_chipIconSize
            float r5 = r4.getDimension(r5, r6)
            r2.mo10210e((float) r5)
            int r5 = p000.l33.Chip_closeIconVisible
            boolean r5 = r4.getBoolean(r5, r3)
            r2.mo10209d((boolean) r5)
            if (r13 == 0) goto L_0x01a2
            java.lang.String r5 = "closeIconEnabled"
            java.lang.String r5 = r13.getAttributeValue(r1, r5)
            if (r5 == 0) goto L_0x01a2
            java.lang.String r5 = "closeIconVisible"
            java.lang.String r5 = r13.getAttributeValue(r1, r5)
            if (r5 != 0) goto L_0x01a2
            int r5 = p000.l33.Chip_closeIconEnabled
            boolean r5 = r4.getBoolean(r5, r3)
            r2.mo10209d((boolean) r5)
        L_0x01a2:
            android.content.Context r5 = r2.f12850Z0
            int r7 = p000.l33.Chip_closeIcon
            android.graphics.drawable.Drawable r5 = p000.t53.m13122b((android.content.Context) r5, (android.content.res.TypedArray) r4, (int) r7)
            r2.mo10208d((android.graphics.drawable.Drawable) r5)
            android.content.Context r5 = r2.f12850Z0
            int r7 = p000.l33.Chip_closeIconTint
            android.content.res.ColorStateList r5 = p000.t53.m13077a((android.content.Context) r5, (android.content.res.TypedArray) r4, (int) r7)
            r2.mo10215f((android.content.res.ColorStateList) r5)
            int r5 = p000.l33.Chip_closeIconSize
            float r5 = r4.getDimension(r5, r6)
            r2.mo10225j(r5)
            int r5 = p000.l33.Chip_android_checkable
            boolean r5 = r4.getBoolean(r5, r3)
            r2.mo10195a((boolean) r5)
            int r5 = p000.l33.Chip_checkedIconVisible
            boolean r5 = r4.getBoolean(r5, r3)
            r2.mo10199b((boolean) r5)
            if (r13 == 0) goto L_0x01ee
            java.lang.String r5 = "checkedIconEnabled"
            java.lang.String r5 = r13.getAttributeValue(r1, r5)
            if (r5 == 0) goto L_0x01ee
            java.lang.String r5 = "checkedIconVisible"
            java.lang.String r1 = r13.getAttributeValue(r1, r5)
            if (r1 != 0) goto L_0x01ee
            int r1 = p000.l33.Chip_checkedIconEnabled
            boolean r1 = r4.getBoolean(r1, r3)
            r2.mo10199b((boolean) r1)
        L_0x01ee:
            android.content.Context r1 = r2.f12850Z0
            int r5 = p000.l33.Chip_checkedIcon
            android.graphics.drawable.Drawable r1 = p000.t53.m13122b((android.content.Context) r1, (android.content.res.TypedArray) r4, (int) r5)
            r2.mo10198b((android.graphics.drawable.Drawable) r1)
            android.content.Context r1 = r2.f12850Z0
            int r5 = p000.l33.Chip_showMotionSpec
            s33 r1 = p000.s33.m12446a(r1, r4, r5)
            r2.f12840P0 = r1
            android.content.Context r1 = r2.f12850Z0
            int r5 = p000.l33.Chip_hideMotionSpec
            s33 r1 = p000.s33.m12446a(r1, r4, r5)
            r2.f12841Q0 = r1
            int r1 = p000.l33.Chip_chipStartPadding
            float r1 = r4.getDimension(r1, r6)
            r2.mo10216g((float) r1)
            int r1 = p000.l33.Chip_iconStartPadding
            float r1 = r4.getDimension(r1, r6)
            r2.mo10229m(r1)
            int r1 = p000.l33.Chip_iconEndPadding
            float r1 = r4.getDimension(r1, r6)
            r2.mo10227l(r1)
            int r1 = p000.l33.Chip_textStartPadding
            float r1 = r4.getDimension(r1, r6)
            r2.mo10233o(r1)
            int r1 = p000.l33.Chip_textEndPadding
            float r1 = r4.getDimension(r1, r6)
            r2.mo10231n(r1)
            int r1 = p000.l33.Chip_closeIconStartPadding
            float r1 = r4.getDimension(r1, r6)
            r2.mo10226k(r1)
            int r1 = p000.l33.Chip_closeIconEndPadding
            float r1 = r4.getDimension(r1, r6)
            r2.mo10223i(r1)
            int r1 = p000.l33.Chip_chipEndPadding
            float r1 = r4.getDimension(r1, r6)
            r2.mo10206d((float) r1)
            int r1 = p000.l33.Chip_android_maxWidth
            r5 = 2147483647(0x7fffffff, float:NaN)
            int r1 = r4.getDimensionPixelSize(r1, r5)
            r2.f12824A1 = r1
            r4.recycle()
            int[] r7 = p000.l33.Chip
            int r9 = p000.k33.Widget_MaterialComponents_Chip_Action
            int[] r10 = new int[r3]
            r5 = r12
            r6 = r13
            r8 = r14
            android.content.res.TypedArray r1 = p000.o63.m10328b(r5, r6, r7, r8, r9, r10)
            int r4 = p000.l33.Chip_ensureMinTouchTargetSize
            boolean r4 = r1.getBoolean(r4, r3)
            r11.f3131m0 = r4
            android.content.Context r4 = r11.getContext()
            r5 = 48
            float r4 = p000.t53.m13068a((android.content.Context) r4, (int) r5)
            double r4 = (double) r4
            double r4 = java.lang.Math.ceil(r4)
            float r4 = (float) r4
            int r5 = p000.l33.Chip_chipMinTouchTargetSize
            float r4 = r1.getDimension(r5, r4)
            double r4 = (double) r4
            double r4 = java.lang.Math.ceil(r4)
            int r4 = (int) r4
            r11.f3133o0 = r4
            r1.recycle()
            r11.setChipDrawable(r2)
            float r1 = p000.C2189w7.m15014i(r11)
            r2.mo5467a((float) r1)
            int[] r6 = p000.l33.Chip
            int r8 = p000.k33.Widget_MaterialComponents_Chip_Action
            int[] r9 = new int[r3]
            r4 = r12
            r5 = r13
            r7 = r14
            android.content.res.TypedArray r13 = p000.o63.m10328b(r4, r5, r6, r7, r8, r9)
            int r14 = android.os.Build.VERSION.SDK_INT
            r1 = 23
            if (r14 >= r1) goto L_0x02bf
            int r14 = p000.l33.Chip_android_textColor
            android.content.res.ColorStateList r12 = p000.t53.m13077a((android.content.Context) r12, (android.content.res.TypedArray) r13, (int) r14)
            r11.setTextColor(r12)
        L_0x02bf:
            int r12 = p000.l33.Chip_shapeAppearance
            boolean r12 = r13.hasValue(r12)
            r13.recycle()
            com.google.android.material.chip.Chip$b r13 = new com.google.android.material.chip.Chip$b
            r13.<init>(r11)
            r11.f3134p0 = r13
            int r13 = android.os.Build.VERSION.SDK_INT
            r14 = 24
            if (r13 < r14) goto L_0x02db
            com.google.android.material.chip.Chip$b r13 = r11.f3134p0
            p000.C2189w7.m14988a((android.view.View) r11, (p000.C0757g7) r13)
            goto L_0x02de
        L_0x02db:
            r11.mo3538h()
        L_0x02de:
            if (r12 != 0) goto L_0x02ee
            int r12 = android.os.Build.VERSION.SDK_INT
            r13 = 21
            if (r12 < r13) goto L_0x02ee
            p43 r12 = new p43
            r12.<init>(r11)
            r11.setOutlineProvider(r12)
        L_0x02ee:
            boolean r12 = r11.f3127i0
            r11.setChecked(r12)
            java.lang.CharSequence r12 = r2.f12823A0
            r11.setText(r12)
            android.text.TextUtils$TruncateAt r12 = r2.f12881y1
            r11.setEllipsize(r12)
            r11.setIncludeFontPadding(r3)
            r11.mo3542l()
            q43 r12 = r11.f3122d0
            boolean r12 = r12.f12883z1
            if (r12 != 0) goto L_0x030c
            r11.setSingleLine()
        L_0x030c:
            r11.setGravity(r0)
            r11.mo3541k()
            boolean r12 = r11.mo3507g()
            if (r12 == 0) goto L_0x031d
            int r12 = r11.f3133o0
            r11.setMinHeight(r12)
        L_0x031d:
            int r12 = p000.C2189w7.m15018m(r11)
            r11.f3132n0 = r12
            return
        L_0x0324:
            java.lang.UnsupportedOperationException r12 = new java.lang.UnsupportedOperationException
            java.lang.String r13 = "Chip does not support multi-line text"
            r12.<init>(r13)
            throw r12
        L_0x032c:
            java.lang.UnsupportedOperationException r12 = new java.lang.UnsupportedOperationException
            r12.<init>(r5)
            throw r12
        L_0x0332:
            java.lang.UnsupportedOperationException r12 = new java.lang.UnsupportedOperationException
            r12.<init>(r5)
            throw r12
        L_0x0338:
            java.lang.UnsupportedOperationException r12 = new java.lang.UnsupportedOperationException
            java.lang.String r13 = "Please set start drawable using R.attr#chipIcon."
            r12.<init>(r13)
            throw r12
        L_0x0340:
            java.lang.UnsupportedOperationException r12 = new java.lang.UnsupportedOperationException
            java.lang.String r13 = "Please set left drawable using R.attr#chipIcon."
            r12.<init>(r13)
            throw r12
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.chip.Chip.<init>(android.content.Context, android.util.AttributeSet, int):void");
    }

    /* access modifiers changed from: private */
    public RectF getCloseIconTouchBounds() {
        this.f3136r0.setEmpty();
        if (mo3499b()) {
            q43 q43 = this.f3122d0;
            q43.mo10203c(q43.getBounds(), this.f3136r0);
        }
        return this.f3136r0;
    }

    /* access modifiers changed from: private */
    public Rect getCloseIconTouchBoundsInt() {
        RectF closeIconTouchBounds = getCloseIconTouchBounds();
        this.f3135q0.set((int) closeIconTouchBounds.left, (int) closeIconTouchBounds.top, (int) closeIconTouchBounds.right, (int) closeIconTouchBounds.bottom);
        return this.f3135q0;
    }

    private s63 getTextAppearance() {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            return q43.f12857g1.f10925f;
        }
        return null;
    }

    private void setCloseIconHovered(boolean z) {
        if (this.f3129k0 != z) {
            this.f3129k0 = z;
            refreshDrawableState();
        }
    }

    private void setCloseIconPressed(boolean z) {
        if (this.f3128j0 != z) {
            this.f3128j0 = z;
            refreshDrawableState();
        }
    }

    /* renamed from: a */
    public void mo3497a() {
        mo3498a(this.f3133o0);
        mo3539i();
        mo3541k();
        requestLayout();
        if (Build.VERSION.SDK_INT >= 21) {
            invalidateOutline();
        }
    }

    /* renamed from: a */
    public boolean mo3498a(int i) {
        this.f3133o0 = i;
        if (!mo3507g()) {
            mo3506f();
            return false;
        }
        int max = Math.max(0, i - ((int) this.f3122d0.f12874v0));
        int max2 = Math.max(0, i - this.f3122d0.getIntrinsicWidth());
        if (max2 > 0 || max > 0) {
            int i2 = max2 > 0 ? max2 / 2 : 0;
            int i3 = max > 0 ? max / 2 : 0;
            if (this.f3123e0 != null) {
                Rect rect = new Rect();
                this.f3123e0.getPadding(rect);
                if (rect.top == i3 && rect.bottom == i3 && rect.left == i2 && rect.right == i2) {
                    return true;
                }
            }
            int i4 = Build.VERSION.SDK_INT;
            if (getMinHeight() != i) {
                setMinHeight(i);
            }
            if (getMinWidth() != i) {
                setMinWidth(i);
            }
            this.f3123e0 = new InsetDrawable(this.f3122d0, i2, i3, i2, i3);
            return true;
        }
        mo3506f();
        return false;
    }

    /* renamed from: b */
    public final boolean mo3499b() {
        q43 q43 = this.f3122d0;
        return (q43 == null || q43.mo10236p() == null) ? false : true;
    }

    /* renamed from: c */
    public boolean mo3500c() {
        q43 q43 = this.f3122d0;
        return q43 != null && q43.f12837M0;
    }

    /* renamed from: d */
    public boolean mo3501d() {
        q43 q43 = this.f3122d0;
        return q43 != null && q43.f12831G0;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:34:0x009f, code lost:
        if (r1 != Integer.MIN_VALUE) goto L_0x00a1;
     */
    /* JADX WARNING: Removed duplicated region for block: B:15:0x0054  */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x00ac A[ORIG_RETURN, RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:41:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean dispatchHoverEvent(android.view.MotionEvent r9) {
        /*
            r8 = this;
            java.lang.Class<u8> r0 = p000.C1985u8.class
            int r1 = r9.getAction()
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = 10
            r4 = 0
            r5 = 1
            if (r1 != r3) goto L_0x0051
            java.lang.String r1 = "m"
            java.lang.reflect.Field r1 = r0.getDeclaredField(r1)     // Catch:{ NoSuchMethodException -> 0x0049, IllegalAccessException -> 0x0047, InvocationTargetException -> 0x0045, NoSuchFieldException -> 0x0043 }
            r1.setAccessible(r5)     // Catch:{ NoSuchMethodException -> 0x0049, IllegalAccessException -> 0x0047, InvocationTargetException -> 0x0045, NoSuchFieldException -> 0x0043 }
            com.google.android.material.chip.Chip$b r6 = r8.f3134p0     // Catch:{ NoSuchMethodException -> 0x0049, IllegalAccessException -> 0x0047, InvocationTargetException -> 0x0045, NoSuchFieldException -> 0x0043 }
            java.lang.Object r1 = r1.get(r6)     // Catch:{ NoSuchMethodException -> 0x0049, IllegalAccessException -> 0x0047, InvocationTargetException -> 0x0045, NoSuchFieldException -> 0x0043 }
            java.lang.Integer r1 = (java.lang.Integer) r1     // Catch:{ NoSuchMethodException -> 0x0049, IllegalAccessException -> 0x0047, InvocationTargetException -> 0x0045, NoSuchFieldException -> 0x0043 }
            int r1 = r1.intValue()     // Catch:{ NoSuchMethodException -> 0x0049, IllegalAccessException -> 0x0047, InvocationTargetException -> 0x0045, NoSuchFieldException -> 0x0043 }
            if (r1 == r2) goto L_0x0051
            java.lang.Class[] r1 = new java.lang.Class[r5]     // Catch:{ NoSuchMethodException -> 0x0049, IllegalAccessException -> 0x0047, InvocationTargetException -> 0x0045, NoSuchFieldException -> 0x0043 }
            java.lang.Class r6 = java.lang.Integer.TYPE     // Catch:{ NoSuchMethodException -> 0x0049, IllegalAccessException -> 0x0047, InvocationTargetException -> 0x0045, NoSuchFieldException -> 0x0043 }
            r1[r4] = r6     // Catch:{ NoSuchMethodException -> 0x0049, IllegalAccessException -> 0x0047, InvocationTargetException -> 0x0045, NoSuchFieldException -> 0x0043 }
            java.lang.String r6 = "f"
            java.lang.reflect.Method r0 = r0.getDeclaredMethod(r6, r1)     // Catch:{ NoSuchMethodException -> 0x0049, IllegalAccessException -> 0x0047, InvocationTargetException -> 0x0045, NoSuchFieldException -> 0x0043 }
            r0.setAccessible(r5)     // Catch:{ NoSuchMethodException -> 0x0049, IllegalAccessException -> 0x0047, InvocationTargetException -> 0x0045, NoSuchFieldException -> 0x0043 }
            com.google.android.material.chip.Chip$b r1 = r8.f3134p0     // Catch:{ NoSuchMethodException -> 0x0049, IllegalAccessException -> 0x0047, InvocationTargetException -> 0x0045, NoSuchFieldException -> 0x0043 }
            java.lang.Object[] r6 = new java.lang.Object[r5]     // Catch:{ NoSuchMethodException -> 0x0049, IllegalAccessException -> 0x0047, InvocationTargetException -> 0x0045, NoSuchFieldException -> 0x0043 }
            java.lang.Integer r7 = java.lang.Integer.valueOf(r2)     // Catch:{ NoSuchMethodException -> 0x0049, IllegalAccessException -> 0x0047, InvocationTargetException -> 0x0045, NoSuchFieldException -> 0x0043 }
            r6[r4] = r7     // Catch:{ NoSuchMethodException -> 0x0049, IllegalAccessException -> 0x0047, InvocationTargetException -> 0x0045, NoSuchFieldException -> 0x0043 }
            r0.invoke(r1, r6)     // Catch:{ NoSuchMethodException -> 0x0049, IllegalAccessException -> 0x0047, InvocationTargetException -> 0x0045, NoSuchFieldException -> 0x0043 }
            r0 = 1
            goto L_0x0052
        L_0x0043:
            r0 = move-exception
            goto L_0x004a
        L_0x0045:
            r0 = move-exception
            goto L_0x004a
        L_0x0047:
            r0 = move-exception
            goto L_0x004a
        L_0x0049:
            r0 = move-exception
        L_0x004a:
            java.lang.String r1 = "Unable to send Accessibility Exit event"
            java.lang.String r6 = "Chip"
            android.util.Log.e(r6, r1, r0)
        L_0x0051:
            r0 = 0
        L_0x0052:
            if (r0 != 0) goto L_0x00ac
            com.google.android.material.chip.Chip$b r0 = r8.f3134p0
            android.view.accessibility.AccessibilityManager r1 = r0.f15375h
            boolean r1 = r1.isEnabled()
            if (r1 == 0) goto L_0x00a3
            android.view.accessibility.AccessibilityManager r1 = r0.f15375h
            boolean r1 = r1.isTouchExplorationEnabled()
            if (r1 != 0) goto L_0x0067
            goto L_0x00a3
        L_0x0067:
            int r1 = r9.getAction()
            r6 = 7
            if (r1 == r6) goto L_0x007d
            r6 = 9
            if (r1 == r6) goto L_0x007d
            if (r1 == r3) goto L_0x0075
            goto L_0x00a3
        L_0x0075:
            int r1 = r0.f15380m
            if (r1 == r2) goto L_0x00a3
            r0.mo11552f(r2)
            goto L_0x00a1
        L_0x007d:
            float r1 = r9.getX()
            float r3 = r9.getY()
            com.google.android.material.chip.Chip r6 = com.google.android.material.chip.Chip.this
            boolean r6 = r6.mo3499b()
            if (r6 == 0) goto L_0x009b
            com.google.android.material.chip.Chip r6 = com.google.android.material.chip.Chip.this
            android.graphics.RectF r6 = r6.getCloseIconTouchBounds()
            boolean r1 = r6.contains(r1, r3)
            if (r1 == 0) goto L_0x009b
            r1 = 1
            goto L_0x009c
        L_0x009b:
            r1 = 0
        L_0x009c:
            r0.mo11552f(r1)
            if (r1 == r2) goto L_0x00a3
        L_0x00a1:
            r0 = 1
            goto L_0x00a4
        L_0x00a3:
            r0 = 0
        L_0x00a4:
            if (r0 != 0) goto L_0x00ac
            boolean r9 = super.dispatchHoverEvent(r9)
            if (r9 == 0) goto L_0x00ad
        L_0x00ac:
            r4 = 1
        L_0x00ad:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.chip.Chip.dispatchHoverEvent(android.view.MotionEvent):boolean");
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (!this.f3134p0.mo11547a(keyEvent) || this.f3134p0.f15379l == Integer.MIN_VALUE) {
            return super.dispatchKeyEvent(keyEvent);
        }
        return true;
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        q43 q43 = this.f3122d0;
        int i = 0;
        if (q43 != null && q43.m11454f(q43.f12832H0)) {
            q43 q432 = this.f3122d0;
            int isEnabled = isEnabled();
            if (this.f3130l0) {
                isEnabled++;
            }
            if (this.f3129k0) {
                isEnabled++;
            }
            if (this.f3128j0) {
                isEnabled++;
            }
            if (isChecked()) {
                isEnabled++;
            }
            int[] iArr = new int[isEnabled];
            if (isEnabled()) {
                iArr[0] = 16842910;
                i = 1;
            }
            if (this.f3130l0) {
                iArr[i] = 16842908;
                i++;
            }
            if (this.f3129k0) {
                iArr[i] = 16843623;
                i++;
            }
            if (this.f3128j0) {
                iArr[i] = 16842919;
                i++;
            }
            if (isChecked()) {
                iArr[i] = 16842913;
            }
            i = q432.mo10200b(iArr);
        }
        if (i != 0) {
            invalidate();
        }
    }

    /* renamed from: e */
    public boolean mo3505e() {
        boolean z = false;
        playSoundEffect(0);
        View.OnClickListener onClickListener = this.f3125g0;
        if (onClickListener != null) {
            onClickListener.onClick(this);
            z = true;
        }
        this.f3134p0.mo11545a(1, 1);
        return z;
    }

    /* renamed from: f */
    public final void mo3506f() {
        if (this.f3123e0 != null) {
            this.f3123e0 = null;
            setMinWidth(0);
            setMinHeight((int) getChipMinHeight());
            mo3539i();
        }
    }

    /* renamed from: g */
    public boolean mo3507g() {
        return this.f3131m0;
    }

    public Drawable getBackgroundDrawable() {
        InsetDrawable insetDrawable = this.f3123e0;
        return insetDrawable == null ? this.f3122d0 : insetDrawable;
    }

    public Drawable getCheckedIcon() {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            return q43.f12839O0;
        }
        return null;
    }

    public ColorStateList getChipBackgroundColor() {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            return q43.f12872u0;
        }
        return null;
    }

    public float getChipCornerRadius() {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            return q43.mo10232o();
        }
        return 0.0f;
    }

    public Drawable getChipDrawable() {
        return this.f3122d0;
    }

    public float getChipEndPadding() {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            return q43.f12849Y0;
        }
        return 0.0f;
    }

    public Drawable getChipIcon() {
        Drawable drawable;
        q43 q43 = this.f3122d0;
        if (q43 == null || (drawable = q43.f12827C0) == null) {
            return null;
        }
        return C0815h0.m5855d(drawable);
    }

    public float getChipIconSize() {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            return q43.f12829E0;
        }
        return 0.0f;
    }

    public ColorStateList getChipIconTint() {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            return q43.f12828D0;
        }
        return null;
    }

    public float getChipMinHeight() {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            return q43.f12874v0;
        }
        return 0.0f;
    }

    public float getChipStartPadding() {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            return q43.f12842R0;
        }
        return 0.0f;
    }

    public ColorStateList getChipStrokeColor() {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            return q43.f12878x0;
        }
        return null;
    }

    public float getChipStrokeWidth() {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            return q43.f12880y0;
        }
        return 0.0f;
    }

    @Deprecated
    public CharSequence getChipText() {
        return getText();
    }

    public Drawable getCloseIcon() {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            return q43.mo10236p();
        }
        return null;
    }

    public CharSequence getCloseIconContentDescription() {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            return q43.f12836L0;
        }
        return null;
    }

    public float getCloseIconEndPadding() {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            return q43.f12848X0;
        }
        return 0.0f;
    }

    public float getCloseIconSize() {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            return q43.f12835K0;
        }
        return 0.0f;
    }

    public float getCloseIconStartPadding() {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            return q43.f12847W0;
        }
        return 0.0f;
    }

    public ColorStateList getCloseIconTint() {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            return q43.f12834J0;
        }
        return null;
    }

    public TextUtils.TruncateAt getEllipsize() {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            return q43.f12881y1;
        }
        return null;
    }

    public void getFocusedRect(Rect rect) {
        C0436b bVar = this.f3134p0;
        if (bVar.f15379l == 1 || bVar.f15378k == 1) {
            rect.set(getCloseIconTouchBoundsInt());
        } else {
            super.getFocusedRect(rect);
        }
    }

    public s33 getHideMotionSpec() {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            return q43.f12841Q0;
        }
        return null;
    }

    public float getIconEndPadding() {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            return q43.f12844T0;
        }
        return 0.0f;
    }

    public float getIconStartPadding() {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            return q43.f12843S0;
        }
        return 0.0f;
    }

    public ColorStateList getRippleColor() {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            return q43.f12882z0;
        }
        return null;
    }

    public j73 getShapeAppearanceModel() {
        return this.f3122d0.f5079X.f5101a;
    }

    public s33 getShowMotionSpec() {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            return q43.f12840P0;
        }
        return null;
    }

    public float getTextEndPadding() {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            return q43.f12846V0;
        }
        return 0.0f;
    }

    public float getTextStartPadding() {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            return q43.f12845U0;
        }
        return 0.0f;
    }

    /* renamed from: h */
    public final void mo3538h() {
        if (Build.VERSION.SDK_INT < 24) {
            C2189w7.m14988a((View) this, (C0757g7) (!mo3499b() || !mo3501d()) ? null : this.f3134p0);
        }
    }

    /* renamed from: i */
    public final void mo3539i() {
        if (w63.f16569a) {
            mo3540j();
            return;
        }
        this.f3122d0.mo10213e(true);
        C2189w7.m14987a((View) this, getBackgroundDrawable());
        if (getBackgroundDrawable() == this.f3123e0 && this.f3122d0.getCallback() == null) {
            this.f3122d0.setCallback(this.f3123e0);
        }
    }

    /* renamed from: j */
    public final void mo3540j() {
        this.f3124f0 = new RippleDrawable(w63.m14963a(this.f3122d0.f12882z0), getBackgroundDrawable(), (Drawable) null);
        this.f3122d0.mo10213e(false);
        C2189w7.m14987a((View) this, (Drawable) this.f3124f0);
    }

    /* renamed from: k */
    public final void mo3541k() {
        q43 q43;
        if (!TextUtils.isEmpty(getText()) && (q43 = this.f3122d0) != null) {
            float f = q43.f12849Y0;
            float n = q43.mo10230n();
            q43 q432 = this.f3122d0;
            float f2 = q432.f12842R0;
            C2189w7.m14983a(this, (int) (q432.mo10228m() + q432.f12845U0 + f2), getPaddingTop(), (int) (n + q43.f12846V0 + f), getPaddingBottom());
        }
    }

    /* renamed from: l */
    public final void mo3542l() {
        TextPaint paint = getPaint();
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            paint.drawableState = q43.getState();
        }
        s63 textAppearance = getTextAppearance();
        if (textAppearance != null) {
            textAppearance.mo10873a(getContext(), paint, this.f3137s0);
        }
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        t53.m13106a((View) this, (f73) this.f3122d0);
    }

    public int[] onCreateDrawableState(int i) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i + 2);
        if (isChecked()) {
            CheckBox.mergeDrawableStates(onCreateDrawableState, f3120u0);
        }
        if (mo3500c()) {
            CheckBox.mergeDrawableStates(onCreateDrawableState, f3121v0);
        }
        return onCreateDrawableState;
    }

    public void onFocusChanged(boolean z, int i, Rect rect) {
        super.onFocusChanged(z, i, rect);
        C0436b bVar = this.f3134p0;
        int i2 = bVar.f15379l;
        if (i2 != Integer.MIN_VALUE) {
            bVar.mo11548b(i2);
        }
        if (z) {
            bVar.mo11546a(i, rect);
        }
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        boolean z;
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked != 7) {
            if (actionMasked == 10) {
                z = false;
            }
            return super.onHoverEvent(motionEvent);
        }
        z = getCloseIconTouchBounds().contains(motionEvent.getX(), motionEvent.getY());
        setCloseIconHovered(z);
        return super.onHoverEvent(motionEvent);
    }

    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName((mo3500c() || isClickable()) ? mo3500c() ? "android.widget.CompoundButton" : "android.widget.Button" : "android.view.View");
        accessibilityNodeInfo.setCheckable(mo3500c());
        accessibilityNodeInfo.setClickable(isClickable());
    }

    @TargetApi(24)
    public PointerIcon onResolvePointerIcon(MotionEvent motionEvent, int i) {
        if (!getCloseIconTouchBounds().contains(motionEvent.getX(), motionEvent.getY()) || !isEnabled()) {
            return null;
        }
        return PointerIcon.getSystemIcon(getContext(), 1002);
    }

    @TargetApi(17)
    public void onRtlPropertiesChanged(int i) {
        super.onRtlPropertiesChanged(i);
        if (this.f3132n0 != i) {
            this.f3132n0 = i;
            mo3541k();
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:6:0x001e, code lost:
        if (r0 != 3) goto L_0x0040;
     */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x0049 A[ORIG_RETURN, RETURN, SYNTHETIC] */
    /* JADX WARNING: Removed duplicated region for block: B:24:? A[RETURN, SYNTHETIC] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean onTouchEvent(android.view.MotionEvent r6) {
        /*
            r5 = this;
            int r0 = r6.getActionMasked()
            android.graphics.RectF r1 = r5.getCloseIconTouchBounds()
            float r2 = r6.getX()
            float r3 = r6.getY()
            boolean r1 = r1.contains(r2, r3)
            r2 = 0
            r3 = 1
            if (r0 == 0) goto L_0x0039
            if (r0 == r3) goto L_0x002b
            r4 = 2
            if (r0 == r4) goto L_0x0021
            r1 = 3
            if (r0 == r1) goto L_0x0034
            goto L_0x0040
        L_0x0021:
            boolean r0 = r5.f3128j0
            if (r0 == 0) goto L_0x0040
            if (r1 != 0) goto L_0x003e
            r5.setCloseIconPressed(r2)
            goto L_0x003e
        L_0x002b:
            boolean r0 = r5.f3128j0
            if (r0 == 0) goto L_0x0034
            r5.mo3505e()
            r0 = 1
            goto L_0x0035
        L_0x0034:
            r0 = 0
        L_0x0035:
            r5.setCloseIconPressed(r2)
            goto L_0x0041
        L_0x0039:
            if (r1 == 0) goto L_0x0040
            r5.setCloseIconPressed(r3)
        L_0x003e:
            r0 = 1
            goto L_0x0041
        L_0x0040:
            r0 = 0
        L_0x0041:
            if (r0 != 0) goto L_0x0049
            boolean r6 = super.onTouchEvent(r6)
            if (r6 == 0) goto L_0x004a
        L_0x0049:
            r2 = 1
        L_0x004a:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.chip.Chip.onTouchEvent(android.view.MotionEvent):boolean");
    }

    public void setBackground(Drawable drawable) {
        if (drawable == getBackgroundDrawable() || drawable == this.f3124f0) {
            super.setBackground(drawable);
        } else {
            Log.w("Chip", "Do not set the background; Chip manages its own background drawable.");
        }
    }

    public void setBackgroundColor(int i) {
        Log.w("Chip", "Do not set the background color; Chip manages its own background drawable.");
    }

    public void setBackgroundDrawable(Drawable drawable) {
        if (drawable == getBackgroundDrawable() || drawable == this.f3124f0) {
            super.setBackgroundDrawable(drawable);
        } else {
            Log.w("Chip", "Do not set the background drawable; Chip manages its own background drawable.");
        }
    }

    public void setBackgroundResource(int i) {
        Log.w("Chip", "Do not set the background resource; Chip manages its own background drawable.");
    }

    public void setBackgroundTintList(ColorStateList colorStateList) {
        Log.w("Chip", "Do not set the background tint list; Chip manages its own background drawable.");
    }

    public void setBackgroundTintMode(PorterDuff.Mode mode) {
        Log.w("Chip", "Do not set the background tint mode; Chip manages its own background drawable.");
    }

    public void setCheckable(boolean z) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10195a(z);
        }
    }

    public void setCheckableResource(int i) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10195a(q43.f12850Z0.getResources().getBoolean(i));
        }
    }

    public void setChecked(boolean z) {
        CompoundButton.OnCheckedChangeListener onCheckedChangeListener;
        q43 q43 = this.f3122d0;
        if (q43 == null) {
            this.f3127i0 = z;
        } else if (q43.f12837M0) {
            boolean isChecked = isChecked();
            super.setChecked(z);
            if (isChecked != z && (onCheckedChangeListener = this.f3126h0) != null) {
                onCheckedChangeListener.onCheckedChanged(this, z);
            }
        }
    }

    public void setCheckedIcon(Drawable drawable) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10198b(drawable);
        }
    }

    @Deprecated
    public void setCheckedIconEnabled(boolean z) {
        setCheckedIconVisible(z);
    }

    @Deprecated
    public void setCheckedIconEnabledResource(int i) {
        setCheckedIconVisible(i);
    }

    public void setCheckedIconResource(int i) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10198b(C1206l0.m8461c(q43.f12850Z0, i));
        }
    }

    public void setCheckedIconVisible(int i) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10199b(q43.f12850Z0.getResources().getBoolean(i));
        }
    }

    public void setCheckedIconVisible(boolean z) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10199b(z);
        }
    }

    public void setChipBackgroundColor(ColorStateList colorStateList) {
        q43 q43 = this.f3122d0;
        if (q43 != null && q43.f12872u0 != colorStateList) {
            q43.f12872u0 = colorStateList;
            q43.onStateChange(q43.getState());
        }
    }

    public void setChipBackgroundColorResource(int i) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10202c(C1206l0.m8460b(q43.f12850Z0, i));
        }
    }

    @Deprecated
    public void setChipCornerRadius(float f) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10201c(f);
        }
    }

    @Deprecated
    public void setChipCornerRadiusResource(int i) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10201c(q43.f12850Z0.getResources().getDimension(i));
        }
    }

    public void setChipDrawable(q43 q43) {
        q43 q432 = this.f3122d0;
        if (q432 != q43) {
            if (q432 != null) {
                q432.mo10193a((q43.C1667a) null);
            }
            this.f3122d0 = q43;
            q43 q433 = this.f3122d0;
            q433.f12883z1 = false;
            q433.mo10193a((q43.C1667a) this);
            mo3498a(this.f3133o0);
            mo3539i();
        }
    }

    public void setChipEndPadding(float f) {
        q43 q43 = this.f3122d0;
        if (q43 != null && q43.f12849Y0 != f) {
            q43.f12849Y0 = f;
            q43.invalidateSelf();
            q43.mo10238r();
        }
    }

    public void setChipEndPaddingResource(int i) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10206d(q43.f12850Z0.getResources().getDimension(i));
        }
    }

    public void setChipIcon(Drawable drawable) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10204c(drawable);
        }
    }

    @Deprecated
    public void setChipIconEnabled(boolean z) {
        setChipIconVisible(z);
    }

    @Deprecated
    public void setChipIconEnabledResource(int i) {
        setChipIconVisible(i);
    }

    public void setChipIconResource(int i) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10204c(C1206l0.m8461c(q43.f12850Z0, i));
        }
    }

    public void setChipIconSize(float f) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10210e(f);
        }
    }

    public void setChipIconSizeResource(int i) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10210e(q43.f12850Z0.getResources().getDimension(i));
        }
    }

    public void setChipIconTint(ColorStateList colorStateList) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10207d(colorStateList);
        }
    }

    public void setChipIconTintResource(int i) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10207d(C1206l0.m8460b(q43.f12850Z0, i));
        }
    }

    public void setChipIconVisible(int i) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10205c(q43.f12850Z0.getResources().getBoolean(i));
        }
    }

    public void setChipIconVisible(boolean z) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10205c(z);
        }
    }

    public void setChipMinHeight(float f) {
        q43 q43 = this.f3122d0;
        if (q43 != null && q43.f12874v0 != f) {
            q43.f12874v0 = f;
            q43.invalidateSelf();
            q43.mo10238r();
        }
    }

    public void setChipMinHeightResource(int i) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10214f(q43.f12850Z0.getResources().getDimension(i));
        }
    }

    public void setChipStartPadding(float f) {
        q43 q43 = this.f3122d0;
        if (q43 != null && q43.f12842R0 != f) {
            q43.f12842R0 = f;
            q43.invalidateSelf();
            q43.mo10238r();
        }
    }

    public void setChipStartPaddingResource(int i) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10216g(q43.f12850Z0.getResources().getDimension(i));
        }
    }

    public void setChipStrokeColor(ColorStateList colorStateList) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10211e(colorStateList);
        }
    }

    public void setChipStrokeColorResource(int i) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10211e(C1206l0.m8460b(q43.f12850Z0, i));
        }
    }

    public void setChipStrokeWidth(float f) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10222h(f);
        }
    }

    public void setChipStrokeWidthResource(int i) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10222h(q43.f12850Z0.getResources().getDimension(i));
        }
    }

    @Deprecated
    public void setChipText(CharSequence charSequence) {
        setText(charSequence);
    }

    @Deprecated
    public void setChipTextResource(int i) {
        setText(getResources().getString(i));
    }

    public void setCloseIcon(Drawable drawable) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10208d(drawable);
        }
        mo3538h();
    }

    public void setCloseIconContentDescription(CharSequence charSequence) {
        SpannableStringBuilder spannableStringBuilder;
        q43 q43 = this.f3122d0;
        if (q43 != null && q43.f12836L0 != charSequence) {
            C2256x6 a = C2256x6.m15525a();
            C2404z6 z6Var = a.f17034c;
            if (charSequence == null) {
                spannableStringBuilder = null;
            } else {
                boolean a2 = ((C0045a7.C0049d) z6Var).mo248a(charSequence, 0, charSequence.length());
                SpannableStringBuilder spannableStringBuilder2 = new SpannableStringBuilder();
                String str = "";
                if ((a.f17033b & 2) != 0) {
                    boolean a3 = ((C0045a7.C0049d) (a2 ? C0045a7.f225b : C0045a7.f224a)).mo248a(charSequence, 0, charSequence.length());
                    spannableStringBuilder2.append((a.f17032a || (!a3 && C2256x6.m15524a(charSequence) != 1)) ? (!a.f17032a || (a3 && C2256x6.m15524a(charSequence) != -1)) ? str : C2256x6.f17029f : C2256x6.f17028e);
                }
                if (a2 != a.f17032a) {
                    spannableStringBuilder2.append(a2 ? (char) 8235 : 8234);
                    spannableStringBuilder2.append(charSequence);
                    spannableStringBuilder2.append(8236);
                } else {
                    spannableStringBuilder2.append(charSequence);
                }
                boolean a4 = ((C0045a7.C0049d) (a2 ? C0045a7.f225b : C0045a7.f224a)).mo248a(charSequence, 0, charSequence.length());
                if (!a.f17032a && (a4 || C2256x6.m15527b(charSequence) == 1)) {
                    str = C2256x6.f17028e;
                } else if (a.f17032a && (!a4 || C2256x6.m15527b(charSequence) == -1)) {
                    str = C2256x6.f17029f;
                }
                spannableStringBuilder2.append(str);
                spannableStringBuilder = spannableStringBuilder2;
            }
            q43.f12836L0 = spannableStringBuilder;
            q43.invalidateSelf();
        }
    }

    @Deprecated
    public void setCloseIconEnabled(boolean z) {
        setCloseIconVisible(z);
    }

    @Deprecated
    public void setCloseIconEnabledResource(int i) {
        setCloseIconVisible(i);
    }

    public void setCloseIconEndPadding(float f) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10223i(f);
        }
    }

    public void setCloseIconEndPaddingResource(int i) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10223i(q43.f12850Z0.getResources().getDimension(i));
        }
    }

    public void setCloseIconResource(int i) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10208d(C1206l0.m8461c(q43.f12850Z0, i));
        }
        mo3538h();
    }

    public void setCloseIconSize(float f) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10225j(f);
        }
    }

    public void setCloseIconSizeResource(int i) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10225j(q43.f12850Z0.getResources().getDimension(i));
        }
    }

    public void setCloseIconStartPadding(float f) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10226k(f);
        }
    }

    public void setCloseIconStartPaddingResource(int i) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10226k(q43.f12850Z0.getResources().getDimension(i));
        }
    }

    public void setCloseIconTint(ColorStateList colorStateList) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10215f(colorStateList);
        }
    }

    public void setCloseIconTintResource(int i) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10215f(C1206l0.m8460b(q43.f12850Z0, i));
        }
    }

    public void setCloseIconVisible(int i) {
        setCloseIconVisible(getResources().getBoolean(i));
    }

    public void setCloseIconVisible(boolean z) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10209d(z);
        }
        mo3538h();
    }

    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        if (drawable != null) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        } else if (drawable3 == null) {
            super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        } else {
            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
        }
    }

    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        if (drawable != null) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        } else if (drawable3 == null) {
            super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        } else {
            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
        }
    }

    public void setCompoundDrawablesRelativeWithIntrinsicBounds(int i, int i2, int i3, int i4) {
        if (i != 0) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        } else if (i3 == 0) {
            super.setCompoundDrawablesRelativeWithIntrinsicBounds(i, i2, i3, i4);
        } else {
            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
        }
    }

    public void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        if (drawable != null) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        } else if (drawable3 == null) {
            super.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        } else {
            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
        }
    }

    public void setCompoundDrawablesWithIntrinsicBounds(int i, int i2, int i3, int i4) {
        if (i != 0) {
            throw new UnsupportedOperationException("Please set start drawable using R.attr#chipIcon.");
        } else if (i3 == 0) {
            super.setCompoundDrawablesWithIntrinsicBounds(i, i2, i3, i4);
        } else {
            throw new UnsupportedOperationException("Please set end drawable using R.attr#closeIcon.");
        }
    }

    public void setCompoundDrawablesWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        if (drawable != null) {
            throw new UnsupportedOperationException("Please set left drawable using R.attr#chipIcon.");
        } else if (drawable3 == null) {
            super.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        } else {
            throw new UnsupportedOperationException("Please set right drawable using R.attr#closeIcon.");
        }
    }

    public void setElevation(float f) {
        super.setElevation(f);
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            f73.C0668b bVar = q43.f5079X;
            if (bVar.f5115o != f) {
                bVar.f5115o = f;
                q43.mo5496l();
            }
        }
    }

    public void setEllipsize(TextUtils.TruncateAt truncateAt) {
        if (this.f3122d0 != null) {
            if (truncateAt != TextUtils.TruncateAt.MARQUEE) {
                super.setEllipsize(truncateAt);
                q43 q43 = this.f3122d0;
                if (q43 != null) {
                    q43.f12881y1 = truncateAt;
                    return;
                }
                return;
            }
            throw new UnsupportedOperationException("Text within a chip are not allowed to scroll.");
        }
    }

    public void setEnsureMinTouchTargetSize(boolean z) {
        this.f3131m0 = z;
        mo3498a(this.f3133o0);
    }

    public void setGravity(int i) {
        if (i != 8388627) {
            Log.w("Chip", "Chip text must be vertically center and start aligned");
        } else {
            super.setGravity(i);
        }
    }

    public void setHideMotionSpec(s33 s33) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.f12841Q0 = s33;
        }
    }

    public void setHideMotionSpecResource(int i) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.f12841Q0 = s33.m12445a(q43.f12850Z0, i);
        }
    }

    public void setIconEndPadding(float f) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10227l(f);
        }
    }

    public void setIconEndPaddingResource(int i) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10227l(q43.f12850Z0.getResources().getDimension(i));
        }
    }

    public void setIconStartPadding(float f) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10229m(f);
        }
    }

    public void setIconStartPaddingResource(int i) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10229m(q43.f12850Z0.getResources().getDimension(i));
        }
    }

    public void setLayoutDirection(int i) {
        if (this.f3122d0 != null) {
            int i2 = Build.VERSION.SDK_INT;
            super.setLayoutDirection(i);
        }
    }

    public void setLines(int i) {
        if (i <= 1) {
            super.setLines(i);
            return;
        }
        throw new UnsupportedOperationException("Chip does not support multi-line text");
    }

    public void setMaxLines(int i) {
        if (i <= 1) {
            super.setMaxLines(i);
            return;
        }
        throw new UnsupportedOperationException("Chip does not support multi-line text");
    }

    public void setMaxWidth(int i) {
        super.setMaxWidth(i);
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.f12824A1 = i;
        }
    }

    public void setMinLines(int i) {
        if (i <= 1) {
            super.setMinLines(i);
            return;
        }
        throw new UnsupportedOperationException("Chip does not support multi-line text");
    }

    public void setOnCheckedChangeListenerInternal(CompoundButton.OnCheckedChangeListener onCheckedChangeListener) {
        this.f3126h0 = onCheckedChangeListener;
    }

    public void setOnCloseIconClickListener(View.OnClickListener onClickListener) {
        this.f3125g0 = onClickListener;
    }

    public void setRippleColor(ColorStateList colorStateList) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10217g(colorStateList);
        }
        if (!this.f3122d0.f12875v1) {
            mo3540j();
        }
    }

    public void setRippleColorResource(int i) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10217g(C1206l0.m8460b(q43.f12850Z0, i));
            if (!this.f3122d0.f12875v1) {
                mo3540j();
            }
        }
    }

    public void setShapeAppearanceModel(j73 j73) {
        q43 q43 = this.f3122d0;
        q43.f5079X.f5101a = j73;
        q43.invalidateSelf();
    }

    public void setShowMotionSpec(s33 s33) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.f12840P0 = s33;
        }
    }

    public void setShowMotionSpecResource(int i) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.f12840P0 = s33.m12445a(q43.f12850Z0, i);
        }
    }

    public void setSingleLine(boolean z) {
        if (z) {
            super.setSingleLine(z);
            return;
        }
        throw new UnsupportedOperationException("Chip does not support multi-line text");
    }

    public void setText(CharSequence charSequence, TextView.BufferType bufferType) {
        if (this.f3122d0 != null) {
            if (charSequence == null) {
                charSequence = "";
            }
            super.setText(this.f3122d0.f12883z1 ? null : charSequence, bufferType);
            q43 q43 = this.f3122d0;
            if (q43 != null) {
                q43.mo10192a(charSequence);
            }
        }
    }

    public void setTextAppearance(int i) {
        super.setTextAppearance(i);
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.f12857g1.mo9115a(new s63(q43.f12850Z0, i), q43.f12850Z0);
        }
        mo3542l();
    }

    public void setTextAppearanceResource(int i) {
        setTextAppearance(getContext(), i);
    }

    public void setTextEndPadding(float f) {
        q43 q43 = this.f3122d0;
        if (q43 != null && q43.f12846V0 != f) {
            q43.f12846V0 = f;
            q43.invalidateSelf();
            q43.mo10238r();
        }
    }

    public void setTextEndPaddingResource(int i) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10231n(q43.f12850Z0.getResources().getDimension(i));
        }
    }

    public void setTextStartPadding(float f) {
        q43 q43 = this.f3122d0;
        if (q43 != null && q43.f12845U0 != f) {
            q43.f12845U0 = f;
            q43.invalidateSelf();
            q43.mo10238r();
        }
    }

    public void setTextStartPaddingResource(int i) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.mo10233o(q43.f12850Z0.getResources().getDimension(i));
        }
    }

    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.f12857g1.mo9115a(new s63(q43.f12850Z0, i), q43.f12850Z0);
        }
        mo3542l();
    }

    public void setTextAppearance(s63 s63) {
        q43 q43 = this.f3122d0;
        if (q43 != null) {
            q43.f12857g1.mo9115a(s63, q43.f12850Z0);
        }
        mo3542l();
    }
}
