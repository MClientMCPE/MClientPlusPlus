package com.google.android.material.chip;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;

public class ChipGroup extends k63 {

    /* renamed from: d0 */
    public int f3140d0;

    /* renamed from: e0 */
    public int f3141e0;

    /* renamed from: f0 */
    public boolean f3142f0;

    /* renamed from: g0 */
    public final C0438b f3143g0;

    /* renamed from: h0 */
    public C0441e f3144h0;

    /* renamed from: i0 */
    public int f3145i0;

    /* renamed from: j0 */
    public boolean f3146j0;

    /* renamed from: com.google.android.material.chip.ChipGroup$b */
    public class C0438b implements CompoundButton.OnCheckedChangeListener {
        public /* synthetic */ C0438b(C0437a aVar) {
        }

        public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
            if (!ChipGroup.this.f3146j0) {
                int id = compoundButton.getId();
                if (z) {
                    ChipGroup chipGroup = ChipGroup.this;
                    int i = chipGroup.f3145i0;
                    if (!(i == -1 || i == id || !chipGroup.f3142f0)) {
                        chipGroup.mo3650a(i, false);
                    }
                    ChipGroup.this.setCheckedId(id);
                    return;
                }
                ChipGroup chipGroup2 = ChipGroup.this;
                if (chipGroup2.f3145i0 == id) {
                    chipGroup2.setCheckedId(-1);
                }
            }
        }
    }

    /* renamed from: com.google.android.material.chip.ChipGroup$c */
    public static class C0439c extends ViewGroup.MarginLayoutParams {
        public C0439c(int i, int i2) {
            super(i, i2);
        }

        public C0439c(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public C0439c(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }
    }

    /* renamed from: com.google.android.material.chip.ChipGroup$d */
    public interface C0440d {
    }

    /* renamed from: com.google.android.material.chip.ChipGroup$e */
    public class C0441e implements ViewGroup.OnHierarchyChangeListener {

        /* renamed from: X */
        public ViewGroup.OnHierarchyChangeListener f3148X;

        public /* synthetic */ C0441e(C0437a aVar) {
        }

        public void onChildViewAdded(View view, View view2) {
            if (view == ChipGroup.this && (view2 instanceof Chip)) {
                if (view2.getId() == -1) {
                    int i = Build.VERSION.SDK_INT;
                    view2.setId(View.generateViewId());
                }
                ((Chip) view2).setOnCheckedChangeListenerInternal(ChipGroup.this.f3143g0);
            }
            ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = this.f3148X;
            if (onHierarchyChangeListener != null) {
                onHierarchyChangeListener.onChildViewAdded(view, view2);
            }
        }

        public void onChildViewRemoved(View view, View view2) {
            if (view == ChipGroup.this && (view2 instanceof Chip)) {
                ((Chip) view2).setOnCheckedChangeListenerInternal((CompoundButton.OnCheckedChangeListener) null);
            }
            ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener = this.f3148X;
            if (onHierarchyChangeListener != null) {
                onHierarchyChangeListener.onChildViewRemoved(view, view2);
            }
        }
    }

    public ChipGroup(Context context) {
        this(context, (AttributeSet) null);
    }

    public ChipGroup(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, b33.chipGroupStyle);
    }

    public ChipGroup(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f3143g0 = new C0438b((C0437a) null);
        this.f3144h0 = new C0441e((C0437a) null);
        this.f3145i0 = -1;
        this.f3146j0 = false;
        TypedArray b = o63.m10328b(context, attributeSet, l33.ChipGroup, i, k33.Widget_MaterialComponents_ChipGroup, new int[0]);
        int dimensionPixelOffset = b.getDimensionPixelOffset(l33.ChipGroup_chipSpacing, 0);
        setChipSpacingHorizontal(b.getDimensionPixelOffset(l33.ChipGroup_chipSpacingHorizontal, dimensionPixelOffset));
        setChipSpacingVertical(b.getDimensionPixelOffset(l33.ChipGroup_chipSpacingVertical, dimensionPixelOffset));
        setSingleLine(b.getBoolean(l33.ChipGroup_singleLine, false));
        setSingleSelection(b.getBoolean(l33.ChipGroup_singleSelection, false));
        int resourceId = b.getResourceId(l33.ChipGroup_checkedChip, -1);
        if (resourceId != -1) {
            this.f3145i0 = resourceId;
        }
        b.recycle();
        super.setOnHierarchyChangeListener(this.f3144h0);
    }

    /* access modifiers changed from: private */
    public void setCheckedId(int i) {
        this.f3145i0 = i;
    }

    /* renamed from: a */
    public final void mo3650a(int i, boolean z) {
        View findViewById = findViewById(i);
        if (findViewById instanceof Chip) {
            this.f3146j0 = true;
            ((Chip) findViewById).setChecked(z);
            this.f3146j0 = false;
        }
    }

    /* renamed from: a */
    public boolean mo3651a() {
        return super.mo3651a();
    }

    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        if (view instanceof Chip) {
            Chip chip = (Chip) view;
            if (chip.isChecked()) {
                int i2 = this.f3145i0;
                if (i2 != -1 && this.f3142f0) {
                    mo3650a(i2, false);
                }
                setCheckedId(chip.getId());
            }
        }
        super.addView(view, i, layoutParams);
    }

    /* renamed from: b */
    public void mo3653b() {
        this.f3146j0 = true;
        for (int i = 0; i < getChildCount(); i++) {
            View childAt = getChildAt(i);
            if (childAt instanceof Chip) {
                ((Chip) childAt).setChecked(false);
            }
        }
        this.f3146j0 = false;
        setCheckedId(-1);
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof C0439c);
    }

    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return new C0439c(-2, -2);
    }

    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new C0439c(getContext(), attributeSet);
    }

    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return new C0439c(layoutParams);
    }

    public int getCheckedChipId() {
        if (this.f3142f0) {
            return this.f3145i0;
        }
        return -1;
    }

    public int getChipSpacingHorizontal() {
        return this.f3140d0;
    }

    public int getChipSpacingVertical() {
        return this.f3141e0;
    }

    public void onFinishInflate() {
        super.onFinishInflate();
        int i = this.f3145i0;
        if (i != -1) {
            mo3650a(i, true);
            setCheckedId(this.f3145i0);
        }
    }

    public void setChipSpacing(int i) {
        setChipSpacingHorizontal(i);
        setChipSpacingVertical(i);
    }

    public void setChipSpacingHorizontal(int i) {
        if (this.f3140d0 != i) {
            this.f3140d0 = i;
            setItemSpacing(i);
            requestLayout();
        }
    }

    public void setChipSpacingHorizontalResource(int i) {
        setChipSpacingHorizontal(getResources().getDimensionPixelOffset(i));
    }

    public void setChipSpacingResource(int i) {
        setChipSpacing(getResources().getDimensionPixelOffset(i));
    }

    public void setChipSpacingVertical(int i) {
        if (this.f3141e0 != i) {
            this.f3141e0 = i;
            setLineSpacing(i);
            requestLayout();
        }
    }

    public void setChipSpacingVerticalResource(int i) {
        setChipSpacingVertical(getResources().getDimensionPixelOffset(i));
    }

    @Deprecated
    public void setDividerDrawableHorizontal(Drawable drawable) {
        throw new UnsupportedOperationException("Changing divider drawables have no effect. ChipGroup do not use divider drawables as spacing.");
    }

    @Deprecated
    public void setDividerDrawableVertical(Drawable drawable) {
        throw new UnsupportedOperationException("Changing divider drawables have no effect. ChipGroup do not use divider drawables as spacing.");
    }

    @Deprecated
    public void setFlexWrap(int i) {
        throw new UnsupportedOperationException("Changing flex wrap not allowed. ChipGroup exposes a singleLine attribute instead.");
    }

    public void setOnCheckedChangeListener(C0440d dVar) {
    }

    public void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener onHierarchyChangeListener) {
        this.f3144h0.f3148X = onHierarchyChangeListener;
    }

    @Deprecated
    public void setShowDividerHorizontal(int i) {
        throw new UnsupportedOperationException("Changing divider modes has no effect. ChipGroup do not use divider drawables as spacing.");
    }

    @Deprecated
    public void setShowDividerVertical(int i) {
        throw new UnsupportedOperationException("Changing divider modes has no effect. ChipGroup do not use divider drawables as spacing.");
    }

    public void setSingleLine(int i) {
        setSingleLine(getResources().getBoolean(i));
    }

    public void setSingleLine(boolean z) {
        super.setSingleLine(z);
    }

    public void setSingleSelection(int i) {
        setSingleSelection(getResources().getBoolean(i));
    }

    public void setSingleSelection(boolean z) {
        if (this.f3142f0 != z) {
            this.f3142f0 = z;
            mo3653b();
        }
    }
}
