package com.google.android.material.datepicker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.widget.GridView;
import android.widget.ListAdapter;
import java.util.Calendar;

public final class MaterialCalendarGridView extends GridView {

    /* renamed from: a0 */
    public final Calendar f3150a0;

    /* renamed from: com.google.android.material.datepicker.MaterialCalendarGridView$a */
    public class C0442a extends C0757g7 {
        public C0442a(MaterialCalendarGridView materialCalendarGridView) {
            super(C0757g7.f6013c);
        }

        /* renamed from: a */
        public void mo1378a(View view, C0759g8 g8Var) {
            this.f6014a.onInitializeAccessibilityNodeInfo(view, g8Var.f6028a);
            g8Var.mo6038a((Object) null);
        }
    }

    public MaterialCalendarGridView(Context context) {
        this(context, (AttributeSet) null);
    }

    public MaterialCalendarGridView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public MaterialCalendarGridView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f3150a0 = t53.m13134c();
        if (l53.m8539a(getContext())) {
            setNextFocusLeftId(f33.cancel_button);
            setNextFocusRightId(f33.confirm_button);
        }
        C2189w7.m14988a((View) this, (C0757g7) new C0442a(this));
    }

    public n53 getAdapter() {
        return (n53) super.getAdapter();
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        getAdapter().notifyDataSetChanged();
    }

    public final void onDraw(Canvas canvas) {
        int i;
        int i2;
        int i3;
        int i4;
        MaterialCalendarGridView materialCalendarGridView = this;
        super.onDraw(canvas);
        n53 adapter = getAdapter();
        c53<?> c53 = adapter.f10906Y;
        b53 b53 = adapter.f10907Z;
        Long item = adapter.getItem(adapter.mo9089a());
        Long item2 = adapter.getItem(adapter.mo9090b());
        for (C0520d7 next : c53.mo2802n()) {
            F f = next.f3748a;
            if (f != null) {
                if (next.f3749b == null) {
                    continue;
                } else {
                    long longValue = ((Long) f).longValue();
                    long longValue2 = ((Long) next.f3749b).longValue();
                    Long valueOf = Long.valueOf(longValue);
                    Long valueOf2 = Long.valueOf(longValue2);
                    int i5 = 1;
                    if (!(item == null || item2 == null || valueOf == null || valueOf2 == null || valueOf.longValue() > item2.longValue() || valueOf2.longValue() < item.longValue())) {
                        if (longValue < item.longValue()) {
                            i2 = adapter.mo9089a();
                            if (i2 % adapter.f10905X.f10022b0 == 0) {
                                i = 0;
                            } else {
                                i = materialCalendarGridView.getChildAt(i2 - 1).getRight();
                            }
                        } else {
                            materialCalendarGridView.f3150a0.setTimeInMillis(longValue);
                            i2 = (materialCalendarGridView.f3150a0.get(5) - 1) + adapter.mo9089a();
                            View childAt = materialCalendarGridView.getChildAt(i2);
                            i = (childAt.getWidth() / 2) + childAt.getLeft();
                        }
                        if (longValue2 > item2.longValue()) {
                            i4 = adapter.mo9090b();
                            i3 = (i4 + 1) % adapter.f10905X.f10022b0 == 0 ? getWidth() : materialCalendarGridView.getChildAt(i4).getRight();
                        } else {
                            materialCalendarGridView.f3150a0.setTimeInMillis(longValue2);
                            i4 = (materialCalendarGridView.f3150a0.get(5) - 1) + adapter.mo9089a();
                            View childAt2 = materialCalendarGridView.getChildAt(i4);
                            i3 = (childAt2.getWidth() / 2) + childAt2.getLeft();
                        }
                        int itemId = (int) adapter.getItemId(i2);
                        int itemId2 = (int) adapter.getItemId(i4);
                        while (itemId <= itemId2) {
                            int numColumns = getNumColumns() * itemId;
                            int numColumns2 = (getNumColumns() + numColumns) - i5;
                            View childAt3 = materialCalendarGridView.getChildAt(numColumns);
                            canvas.drawRect((float) (numColumns > i2 ? 0 : i), (float) (b53.f1727a.f193a.top + childAt3.getTop()), (float) (i4 > numColumns2 ? getWidth() : i3), (float) (childAt3.getBottom() - b53.f1727a.f193a.bottom), b53.f1734h);
                            itemId++;
                            i5 = 1;
                            materialCalendarGridView = this;
                        }
                    } else {
                        return;
                    }
                }
            }
            materialCalendarGridView = this;
        }
    }

    public void onFocusChanged(boolean z, int i, Rect rect) {
        int i2;
        if (z) {
            if (i == 33) {
                i2 = getAdapter().mo9090b();
            } else if (i == 130) {
                i2 = getAdapter().mo9089a();
            } else {
                super.onFocusChanged(true, i, rect);
                return;
            }
            setSelection(i2);
            return;
        }
        super.onFocusChanged(false, i, rect);
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (!super.onKeyDown(i, keyEvent)) {
            return false;
        }
        if (getSelectedItemPosition() == -1 || getSelectedItemPosition() >= getAdapter().mo9089a()) {
            return true;
        }
        if (19 != i) {
            return false;
        }
        setSelection(getAdapter().mo9089a());
        return true;
    }

    public final void setAdapter(ListAdapter listAdapter) {
        if (listAdapter instanceof n53) {
            super.setAdapter(listAdapter);
        } else {
            throw new IllegalArgumentException(String.format("%1$s must have its Adapter set to a %2$s", new Object[]{MaterialCalendarGridView.class.getCanonicalName(), n53.class.getCanonicalName()}));
        }
    }

    public void setSelection(int i) {
        if (i < getAdapter().mo9089a()) {
            i = getAdapter().mo9089a();
        }
        super.setSelection(i);
    }
}
