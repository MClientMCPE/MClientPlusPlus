package com.google.android.material.floatingactionbutton;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import p000.c63;

@CoordinatorLayout.C0175d(Behavior.class)
public class FloatingActionButton extends p63 implements C2097v7, C1596p8, x53, m73 {

    /* renamed from: b0 */
    public ColorStateList f3161b0;

    /* renamed from: c0 */
    public PorterDuff.Mode f3162c0;

    /* renamed from: d0 */
    public ColorStateList f3163d0;

    /* renamed from: e0 */
    public PorterDuff.Mode f3164e0;

    /* renamed from: f0 */
    public ColorStateList f3165f0;

    /* renamed from: g0 */
    public int f3166g0;

    /* renamed from: h0 */
    public int f3167h0;

    /* renamed from: i0 */
    public int f3168i0;

    /* renamed from: j0 */
    public int f3169j0;

    /* renamed from: k0 */
    public boolean f3170k0;

    /* renamed from: l0 */
    public final Rect f3171l0;

    /* renamed from: m0 */
    public final Rect f3172m0;

    /* renamed from: n0 */
    public final C1117k2 f3173n0;

    /* renamed from: o0 */
    public c63 f3174o0;

    public static class Behavior extends BaseBehavior<FloatingActionButton> {
        public Behavior() {
        }

        public Behavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }
    }

    /* renamed from: com.google.android.material.floatingactionbutton.FloatingActionButton$a */
    public static abstract class C0445a {
        /* renamed from: a */
        public void mo3797a(FloatingActionButton floatingActionButton) {
        }

        /* renamed from: b */
        public void mo3798b(FloatingActionButton floatingActionButton) {
        }
    }

    /* renamed from: com.google.android.material.floatingactionbutton.FloatingActionButton$b */
    public class C0446b implements y63 {
        public C0446b() {
        }

        /* renamed from: a */
        public void mo3799a(Drawable drawable) {
            if (drawable != null) {
                FloatingActionButton.super.setBackgroundDrawable(drawable);
            }
        }
    }

    /* renamed from: com.google.android.material.floatingactionbutton.FloatingActionButton$c */
    public class C0447c<T extends FloatingActionButton> implements c63.C0345e {

        /* renamed from: a */
        public final v33<T> f3179a;

        /* renamed from: b */
        public final /* synthetic */ FloatingActionButton f3180b;

        /* JADX WARNING: type inference failed for: r1v0, types: [v33<T>, com.google.android.material.floatingactionbutton.FloatingActionButton] */
        /* JADX WARNING: Unknown variable types count: 1 */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public C0447c(p000.v33<T> r1) {
            /*
                r0 = this;
                r0.f3180b = r1
                r0.<init>()
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.floatingactionbutton.FloatingActionButton.C0447c.<init>(com.google.android.material.floatingactionbutton.FloatingActionButton):void");
        }

        /* renamed from: a */
        public void mo3800a() {
            throw null;
        }

        /* renamed from: b */
        public void mo3801b() {
            throw null;
        }

        public boolean equals(Object obj) {
            return (obj instanceof C0447c) && ((C0447c) obj).f3179a.equals((Object) null);
        }

        public int hashCode() {
            throw null;
        }
    }

    /* renamed from: a */
    public static int m3040a(int i, int i2) {
        int mode = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i2);
        if (mode == Integer.MIN_VALUE) {
            return Math.min(i, size);
        }
        if (mode == 0) {
            return i;
        }
        if (mode == 1073741824) {
            return size;
        }
        throw new IllegalArgumentException();
    }

    private c63 getImpl() {
        if (this.f3174o0 == null) {
            this.f3174o0 = Build.VERSION.SDK_INT >= 21 ? new f63(this, new C0446b()) : new c63(this, new C0446b());
        }
        return this.f3174o0;
    }

    /* renamed from: a */
    public final int mo3716a(int i) {
        int i2 = this.f3167h0;
        if (i2 != 0) {
            return i2;
        }
        Resources resources = getResources();
        if (i == -1) {
            return Math.max(resources.getConfiguration().screenWidthDp, resources.getConfiguration().screenHeightDp) < 470 ? mo3716a(1) : mo3716a(0);
        }
        return resources.getDimensionPixelSize(i != 1 ? d33.design_fab_size_normal : d33.design_fab_size_mini);
    }

    /* renamed from: a */
    public void mo3717a(Animator.AnimatorListener animatorListener) {
        c63 impl = getImpl();
        if (impl.f2551v == null) {
            impl.f2551v = new ArrayList<>();
        }
        impl.f2551v.add(animatorListener);
    }

    /* renamed from: a */
    public void mo3718a(C0445a aVar) {
        mo3719a(aVar, true);
    }

    /* renamed from: a */
    public boolean mo3721a() {
        throw null;
    }

    @Deprecated
    /* renamed from: a */
    public boolean mo3722a(Rect rect) {
        if (!C2189w7.m15031z(this)) {
            return false;
        }
        rect.set(0, 0, getWidth(), getHeight());
        mo3728c(rect);
        return true;
    }

    /* renamed from: b */
    public void mo3723b(Animator.AnimatorListener animatorListener) {
        c63 impl = getImpl();
        if (impl.f2550u == null) {
            impl.f2550u = new ArrayList<>();
        }
        impl.f2550u.add(animatorListener);
    }

    /* renamed from: b */
    public void mo3724b(Rect rect) {
        rect.set(0, 0, getMeasuredWidth(), getMeasuredHeight());
        mo3728c(rect);
    }

    /* renamed from: b */
    public void mo3725b(C0445a aVar) {
        mo3726b(aVar, true);
    }

    /* renamed from: b */
    public boolean mo3727b() {
        return getImpl().mo2816b();
    }

    /* renamed from: c */
    public final void mo3728c(Rect rect) {
        int i = rect.left;
        Rect rect2 = this.f3171l0;
        rect.left = i + rect2.left;
        rect.top += rect2.top;
        rect.right -= rect2.right;
        rect.bottom -= rect2.bottom;
    }

    /* renamed from: c */
    public boolean mo3729c() {
        return getImpl().mo2817c();
    }

    /* renamed from: d */
    public final void mo3730d() {
        Drawable drawable = getDrawable();
        if (drawable != null) {
            ColorStateList colorStateList = this.f3163d0;
            if (colorStateList == null) {
                C0815h0.m5799a(drawable);
                return;
            }
            int colorForState = colorStateList.getColorForState(getDrawableState(), 0);
            PorterDuff.Mode mode = this.f3164e0;
            if (mode == null) {
                mode = PorterDuff.Mode.SRC_IN;
            }
            drawable.mutate().setColorFilter(C0820h2.m5928a(colorForState, mode));
        }
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        getImpl().mo2814a(getDrawableState());
    }

    public ColorStateList getBackgroundTintList() {
        return this.f3161b0;
    }

    public PorterDuff.Mode getBackgroundTintMode() {
        return this.f3162c0;
    }

    public float getCompatElevation() {
        return getImpl().mo2806a();
    }

    public float getCompatHoveredFocusedTranslationZ() {
        return getImpl().f2537h;
    }

    public float getCompatPressedTranslationZ() {
        return getImpl().f2538i;
    }

    public Drawable getContentBackground() {
        return getImpl().f2533d;
    }

    public int getCustomSize() {
        return this.f3167h0;
    }

    public int getExpandedComponentIdHint() {
        throw null;
    }

    public s33 getHideMotionSpec() {
        return getImpl().f2545p;
    }

    @Deprecated
    public int getRippleColor() {
        ColorStateList colorStateList = this.f3165f0;
        if (colorStateList != null) {
            return colorStateList.getDefaultColor();
        }
        return 0;
    }

    public ColorStateList getRippleColorStateList() {
        return this.f3165f0;
    }

    public j73 getShapeAppearanceModel() {
        j73 j73 = getImpl().f2530a;
        C0815h0.m5789a(j73);
        return j73;
    }

    public s33 getShowMotionSpec() {
        return getImpl().f2544o;
    }

    public int getSize() {
        return this.f3166g0;
    }

    public int getSizeDimension() {
        return mo3716a(this.f3166g0);
    }

    public ColorStateList getSupportBackgroundTintList() {
        return getBackgroundTintList();
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        return getBackgroundTintMode();
    }

    public ColorStateList getSupportImageTintList() {
        return this.f3163d0;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        return this.f3164e0;
    }

    public boolean getUseCompatPadding() {
        return this.f3170k0;
    }

    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        getImpl().mo2818d();
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        c63 impl = getImpl();
        f73 f73 = impl.f2531b;
        if (f73 != null) {
            t53.m13106a((View) impl.f2553x, f73);
        }
        if (impl.mo2822h()) {
            ViewTreeObserver viewTreeObserver = impl.f2553x.getViewTreeObserver();
            if (impl.f2529D == null) {
                impl.f2529D = new e63(impl);
            }
            viewTreeObserver.addOnPreDrawListener(impl.f2529D);
        }
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        c63 impl = getImpl();
        ViewTreeObserver viewTreeObserver = impl.f2553x.getViewTreeObserver();
        ViewTreeObserver.OnPreDrawListener onPreDrawListener = impl.f2529D;
        if (onPreDrawListener != null) {
            viewTreeObserver.removeOnPreDrawListener(onPreDrawListener);
            impl.f2529D = null;
        }
    }

    public void onMeasure(int i, int i2) {
        int sizeDimension = getSizeDimension();
        this.f3168i0 = (sizeDimension - this.f3169j0) / 2;
        getImpl().mo2827m();
        int min = Math.min(m3040a(sizeDimension, i), m3040a(sizeDimension, i2));
        Rect rect = this.f3171l0;
        setMeasuredDimension(rect.left + min + rect.right, min + rect.top + rect.bottom);
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof t73)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        t73 t73 = (t73) parcelable;
        super.onRestoreInstanceState(t73.f14707X);
        Bundle orDefault = t73.f14704Z.getOrDefault("expandableWidgetHelper", null);
        C0815h0.m5789a(orDefault);
        Bundle bundle = orDefault;
        throw null;
    }

    public Parcelable onSaveInstanceState() {
        Parcelable onSaveInstanceState = super.onSaveInstanceState();
        if (onSaveInstanceState == null) {
            onSaveInstanceState = new Bundle();
        }
        C0754g5<String, Bundle> g5Var = new t73(onSaveInstanceState).f14704Z;
        throw null;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (motionEvent.getAction() != 0 || !mo3722a(this.f3172m0) || this.f3172m0.contains((int) motionEvent.getX(), (int) motionEvent.getY())) {
            return super.onTouchEvent(motionEvent);
        }
        return false;
    }

    public void setBackgroundColor(int i) {
        Log.i("FloatingActionButton", "Setting a custom background is not supported.");
    }

    public void setBackgroundDrawable(Drawable drawable) {
        Log.i("FloatingActionButton", "Setting a custom background is not supported.");
    }

    public void setBackgroundResource(int i) {
        Log.i("FloatingActionButton", "Setting a custom background is not supported.");
    }

    public void setBackgroundTintList(ColorStateList colorStateList) {
        if (this.f3161b0 != colorStateList) {
            this.f3161b0 = colorStateList;
            f73 f73 = getImpl().f2531b;
            if (f73 != null) {
                f73.setTintList(colorStateList);
            }
        }
    }

    public void setBackgroundTintMode(PorterDuff.Mode mode) {
        if (this.f3162c0 != mode) {
            this.f3162c0 = mode;
            f73 f73 = getImpl().f2531b;
            if (f73 != null) {
                f73.setTintMode(mode);
            }
        }
    }

    public void setCompatElevation(float f) {
        c63 impl = getImpl();
        if (impl.f2536g != f) {
            impl.f2536g = f;
            impl.mo2810a(impl.f2536g, impl.f2537h, impl.f2538i);
        }
    }

    public void setCompatElevationResource(int i) {
        setCompatElevation(getResources().getDimension(i));
    }

    public void setCompatHoveredFocusedTranslationZ(float f) {
        c63 impl = getImpl();
        if (impl.f2537h != f) {
            impl.f2537h = f;
            impl.mo2810a(impl.f2536g, impl.f2537h, impl.f2538i);
        }
    }

    public void setCompatHoveredFocusedTranslationZResource(int i) {
        setCompatHoveredFocusedTranslationZ(getResources().getDimension(i));
    }

    public void setCompatPressedTranslationZ(float f) {
        c63 impl = getImpl();
        if (impl.f2538i != f) {
            impl.f2538i = f;
            impl.mo2810a(impl.f2536g, impl.f2537h, impl.f2538i);
        }
    }

    public void setCompatPressedTranslationZResource(int i) {
        setCompatPressedTranslationZ(getResources().getDimension(i));
    }

    public void setCustomSize(int i) {
        if (i < 0) {
            throw new IllegalArgumentException("Custom size must be non-negative");
        } else if (i != this.f3167h0) {
            this.f3167h0 = i;
            requestLayout();
        }
    }

    public void setElevation(float f) {
        super.setElevation(f);
        getImpl().mo2815b(f);
    }

    public void setEnsureMinTouchTargetSize(boolean z) {
        if (z != getImpl().f2534e) {
            getImpl().f2534e = z;
            requestLayout();
        }
    }

    public void setExpandedComponentIdHint(int i) {
        throw null;
    }

    public void setHideMotionSpec(s33 s33) {
        getImpl().f2545p = s33;
    }

    public void setHideMotionSpecResource(int i) {
        setHideMotionSpec(s33.m12445a(getContext(), i));
    }

    public void setImageDrawable(Drawable drawable) {
        if (getDrawable() != drawable) {
            super.setImageDrawable(drawable);
            c63 impl = getImpl();
            impl.mo2809a(impl.f2547r);
            if (this.f3163d0 != null) {
                mo3730d();
            }
        }
    }

    public void setImageResource(int i) {
        this.f3173n0.mo7835a(i);
        mo3730d();
    }

    public void setRippleColor(int i) {
        setRippleColor(ColorStateList.valueOf(i));
    }

    public void setRippleColor(ColorStateList colorStateList) {
        if (this.f3165f0 != colorStateList) {
            this.f3165f0 = colorStateList;
            getImpl().mo2812a(this.f3165f0);
        }
    }

    public void setScaleX(float f) {
        super.setScaleX(f);
        getImpl().mo2820f();
    }

    public void setScaleY(float f) {
        super.setScaleY(f);
        getImpl().mo2820f();
    }

    public void setShadowPaddingEnabled(boolean z) {
        c63 impl = getImpl();
        impl.f2535f = z;
        impl.mo2827m();
    }

    public void setShapeAppearanceModel(j73 j73) {
        c63 impl = getImpl();
        impl.f2530a = j73;
        f73 f73 = impl.f2531b;
        if (f73 != null) {
            f73.f5079X.f5101a = j73;
            f73.invalidateSelf();
        }
        Drawable drawable = impl.f2532c;
        if (drawable instanceof m73) {
            ((m73) drawable).setShapeAppearanceModel(j73);
        }
    }

    public void setShowMotionSpec(s33 s33) {
        getImpl().f2544o = s33;
    }

    public void setShowMotionSpecResource(int i) {
        setShowMotionSpec(s33.m12445a(getContext(), i));
    }

    public void setSize(int i) {
        this.f3167h0 = 0;
        if (i != this.f3166g0) {
            this.f3166g0 = i;
            requestLayout();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        setBackgroundTintList(colorStateList);
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        setBackgroundTintMode(mode);
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        if (this.f3163d0 != colorStateList) {
            this.f3163d0 = colorStateList;
            mo3730d();
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        if (this.f3164e0 != mode) {
            this.f3164e0 = mode;
            mo3730d();
        }
    }

    public void setTranslationX(float f) {
        super.setTranslationX(f);
        getImpl().mo2821g();
    }

    public void setTranslationY(float f) {
        super.setTranslationY(f);
        getImpl().mo2821g();
    }

    public void setTranslationZ(float f) {
        super.setTranslationZ(f);
        getImpl().mo2821g();
    }

    public void setUseCompatPadding(boolean z) {
        if (this.f3170k0 != z) {
            this.f3170k0 = z;
            getImpl().mo2819e();
        }
    }

    public void setVisibility(int i) {
        super.setVisibility(i);
    }

    /* renamed from: a */
    public void mo3720a(v33<? extends FloatingActionButton> v33) {
        c63 impl = getImpl();
        C0447c cVar = new C0447c(this);
        if (impl.f2552w == null) {
            impl.f2552w = new ArrayList<>();
        }
        impl.f2552w.add(cVar);
    }

    /* renamed from: b */
    public void mo3726b(C0445a aVar, boolean z) {
        c63 impl = getImpl();
        z53 z53 = aVar == null ? null : new z53(this, aVar);
        if (!impl.mo2817c()) {
            Animator animator = impl.f2543n;
            if (animator != null) {
                animator.cancel();
            }
            if (impl.mo2824j()) {
                if (impl.f2553x.getVisibility() != 0) {
                    impl.f2553x.setAlpha(0.0f);
                    impl.f2553x.setScaleY(0.0f);
                    impl.f2553x.setScaleX(0.0f);
                    impl.mo2809a(0.0f);
                }
                s33 s33 = impl.f2544o;
                if (s33 == null) {
                    if (impl.f2541l == null) {
                        impl.f2541l = s33.m12445a(impl.f2553x.getContext(), a33.design_fab_show_motion_spec);
                    }
                    s33 = impl.f2541l;
                    C0815h0.m5789a(s33);
                }
                AnimatorSet a = impl.mo2807a(s33, 1.0f, 1.0f, 1.0f);
                a.addListener(new b63(impl, z, z53));
                ArrayList<Animator.AnimatorListener> arrayList = impl.f2550u;
                if (arrayList != null) {
                    Iterator<Animator.AnimatorListener> it = arrayList.iterator();
                    while (it.hasNext()) {
                        a.addListener(it.next());
                    }
                }
                a.start();
                return;
            }
            impl.f2553x.mo9898a(0, z);
            impl.f2553x.setAlpha(1.0f);
            impl.f2553x.setScaleY(1.0f);
            impl.f2553x.setScaleX(1.0f);
            impl.mo2809a(1.0f);
            if (z53 != null) {
                z53.f18191a.mo3798b(z53.f18192b);
            }
        }
    }

    /* renamed from: a */
    public void mo3719a(C0445a aVar, boolean z) {
        c63 impl = getImpl();
        z53 z53 = aVar == null ? null : new z53(this, aVar);
        if (!impl.mo2816b()) {
            Animator animator = impl.f2543n;
            if (animator != null) {
                animator.cancel();
            }
            if (impl.mo2824j()) {
                s33 s33 = impl.f2545p;
                if (s33 == null) {
                    if (impl.f2542m == null) {
                        impl.f2542m = s33.m12445a(impl.f2553x.getContext(), a33.design_fab_hide_motion_spec);
                    }
                    s33 = impl.f2542m;
                    C0815h0.m5789a(s33);
                }
                AnimatorSet a = impl.mo2807a(s33, 0.0f, 0.0f, 0.0f);
                a.addListener(new a63(impl, z, z53));
                ArrayList<Animator.AnimatorListener> arrayList = impl.f2551v;
                if (arrayList != null) {
                    Iterator<Animator.AnimatorListener> it = arrayList.iterator();
                    while (it.hasNext()) {
                        a.addListener(it.next());
                    }
                }
                a.start();
                return;
            }
            impl.f2553x.mo9898a(z ? 8 : 4, z);
            if (z53 != null) {
                z53.f18191a.mo3797a(z53.f18192b);
            }
        }
    }

    public static class BaseBehavior<T extends FloatingActionButton> extends CoordinatorLayout.C0174c<T> {

        /* renamed from: a */
        public Rect f3175a;

        /* renamed from: b */
        public C0445a f3176b;

        /* renamed from: c */
        public boolean f3177c;

        public BaseBehavior() {
            this.f3177c = true;
        }

        public BaseBehavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, l33.FloatingActionButton_Behavior_Layout);
            this.f3177c = obtainStyledAttributes.getBoolean(l33.FloatingActionButton_Behavior_Layout_behavior_autoHide, true);
            obtainStyledAttributes.recycle();
        }

        /* renamed from: a */
        public void mo1254a(CoordinatorLayout.C0177f fVar) {
            if (fVar.f1045h == 0) {
                fVar.f1045h = 80;
            }
        }

        /* renamed from: a */
        public /* bridge */ /* synthetic */ boolean mo1264a(CoordinatorLayout coordinatorLayout, View view, Rect rect) {
            return mo3795a((FloatingActionButton) view, rect);
        }

        /* renamed from: a */
        public final boolean mo3792a(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, FloatingActionButton floatingActionButton) {
            if (!mo3791a((View) appBarLayout, floatingActionButton)) {
                return false;
            }
            if (this.f3175a == null) {
                this.f3175a = new Rect();
            }
            Rect rect = this.f3175a;
            j63.m7343a((ViewGroup) coordinatorLayout, (View) appBarLayout, rect);
            if (rect.bottom <= appBarLayout.getMinimumHeightForVisibleOverlappingContent()) {
                floatingActionButton.mo3719a(this.f3176b, false);
                return true;
            }
            floatingActionButton.mo3726b(this.f3176b, false);
            return true;
        }

        /* renamed from: a */
        public boolean mo1273b(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, View view) {
            if (view instanceof AppBarLayout) {
                mo3792a(coordinatorLayout, (AppBarLayout) view, floatingActionButton);
            } else {
                ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
                if (layoutParams instanceof CoordinatorLayout.C0177f ? ((CoordinatorLayout.C0177f) layoutParams).f1038a instanceof BottomSheetBehavior : false) {
                    mo3796b(view, floatingActionButton);
                }
            }
            return false;
        }

        /* renamed from: a */
        public boolean mo3795a(FloatingActionButton floatingActionButton, Rect rect) {
            Rect rect2 = floatingActionButton.f3171l0;
            rect.set(floatingActionButton.getLeft() + rect2.left, floatingActionButton.getTop() + rect2.top, floatingActionButton.getRight() - rect2.right, floatingActionButton.getBottom() - rect2.bottom);
            return true;
        }

        /* renamed from: b */
        public final boolean mo3796b(View view, FloatingActionButton floatingActionButton) {
            if (!mo3791a(view, floatingActionButton)) {
                return false;
            }
            if (view.getTop() < (floatingActionButton.getHeight() / 2) + ((CoordinatorLayout.C0177f) floatingActionButton.getLayoutParams()).topMargin) {
                floatingActionButton.mo3719a(this.f3176b, false);
                return true;
            }
            floatingActionButton.mo3726b(this.f3176b, false);
            return true;
        }

        /* renamed from: a */
        public boolean mo203a(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, int i) {
            List<View> b = coordinatorLayout.mo1206b((View) floatingActionButton);
            int size = b.size();
            int i2 = 0;
            for (int i3 = 0; i3 < size; i3++) {
                View view = b.get(i3);
                if (!(view instanceof AppBarLayout)) {
                    ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
                    if ((layoutParams instanceof CoordinatorLayout.C0177f ? ((CoordinatorLayout.C0177f) layoutParams).f1038a instanceof BottomSheetBehavior : false) && mo3796b(view, floatingActionButton)) {
                        break;
                    }
                } else if (mo3792a(coordinatorLayout, (AppBarLayout) view, floatingActionButton)) {
                    break;
                }
            }
            coordinatorLayout.mo1213c((View) floatingActionButton, i);
            Rect rect = floatingActionButton.f3171l0;
            if (rect == null || rect.centerX() <= 0 || rect.centerY() <= 0) {
                return true;
            }
            CoordinatorLayout.C0177f fVar = (CoordinatorLayout.C0177f) floatingActionButton.getLayoutParams();
            int i4 = floatingActionButton.getRight() >= coordinatorLayout.getWidth() - fVar.rightMargin ? rect.right : floatingActionButton.getLeft() <= fVar.leftMargin ? -rect.left : 0;
            if (floatingActionButton.getBottom() >= coordinatorLayout.getHeight() - fVar.bottomMargin) {
                i2 = rect.bottom;
            } else if (floatingActionButton.getTop() <= fVar.topMargin) {
                i2 = -rect.top;
            }
            if (i2 != 0) {
                C2189w7.m15007e(floatingActionButton, i2);
            }
            if (i4 == 0) {
                return true;
            }
            C2189w7.m15005d(floatingActionButton, i4);
            return true;
        }

        /* renamed from: a */
        public final boolean mo3791a(View view, FloatingActionButton floatingActionButton) {
            CoordinatorLayout.C0177f fVar = (CoordinatorLayout.C0177f) floatingActionButton.getLayoutParams();
            if (this.f3177c && fVar.f1043f == view.getId() && floatingActionButton.getUserSetVisibility() == 0) {
                return true;
            }
            return false;
        }
    }
}
