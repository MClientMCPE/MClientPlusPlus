package com.google.android.material.floatingactionbutton;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Property;
import android.view.View;
import android.view.ViewGroup;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.button.MaterialButton;
import java.util.List;

public class ExtendedFloatingActionButton extends MaterialButton implements CoordinatorLayout.C0173b {

    /* renamed from: q0 */
    public final Rect f3151q0;

    /* renamed from: r0 */
    public final g63 f3152r0;

    /* renamed from: s0 */
    public final g63 f3153s0;

    /* renamed from: t0 */
    public final g63 f3154t0;

    /* renamed from: u0 */
    public final g63 f3155u0;

    /* renamed from: v0 */
    public final CoordinatorLayout.C0174c<ExtendedFloatingActionButton> f3156v0;

    /* renamed from: w0 */
    public boolean f3157w0;

    /* renamed from: com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton$a */
    public static class C0443a extends Property<View, Float> {
        public C0443a(Class cls, String str) {
            super(cls, str);
        }

        public Object get(Object obj) {
            return Float.valueOf((float) ((View) obj).getLayoutParams().width);
        }

        public void set(Object obj, Object obj2) {
            View view = (View) obj;
            view.getLayoutParams().width = ((Float) obj2).intValue();
            view.requestLayout();
        }
    }

    /* renamed from: com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton$b */
    public static class C0444b extends Property<View, Float> {
        public C0444b(Class cls, String str) {
            super(cls, str);
        }

        public Object get(Object obj) {
            return Float.valueOf((float) ((View) obj).getLayoutParams().height);
        }

        public void set(Object obj, Object obj2) {
            View view = (View) obj;
            view.getLayoutParams().height = ((Float) obj2).intValue();
            view.requestLayout();
        }
    }

    static {
        new C0443a(Float.class, "width");
        new C0444b(Float.class, "height");
    }

    /* renamed from: a */
    public static /* synthetic */ void m3027a(ExtendedFloatingActionButton extendedFloatingActionButton) {
        throw null;
    }

    public CoordinatorLayout.C0174c<ExtendedFloatingActionButton> getBehavior() {
        return this.f3156v0;
    }

    public int getCollapsedSize() {
        return getIconSize() + (Math.min(C2189w7.m15023r(this), C2189w7.m15022q(this)) * 2);
    }

    public s33 getExtendMotionSpec() {
        throw null;
    }

    public s33 getHideMotionSpec() {
        throw null;
    }

    public s33 getShowMotionSpec() {
        throw null;
    }

    public s33 getShrinkMotionSpec() {
        throw null;
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.f3157w0 && TextUtils.isEmpty(getText()) && getIcon() != null) {
            this.f3157w0 = false;
            throw null;
        }
    }

    public void setExtendMotionSpec(s33 s33) {
        throw null;
    }

    public void setExtendMotionSpecResource(int i) {
        setExtendMotionSpec(s33.m12445a(getContext(), i));
    }

    public void setExtended(boolean z) {
        if (this.f3157w0 != z) {
            g63 g63 = null;
            if (!g63.mo6012b()) {
                g63.mo6011a();
            }
        }
    }

    public void setHideMotionSpec(s33 s33) {
        throw null;
    }

    public void setHideMotionSpecResource(int i) {
        setHideMotionSpec(s33.m12445a(getContext(), i));
    }

    public void setShowMotionSpec(s33 s33) {
        throw null;
    }

    public void setShowMotionSpecResource(int i) {
        setShowMotionSpec(s33.m12445a(getContext(), i));
    }

    public void setShrinkMotionSpec(s33 s33) {
        throw null;
    }

    public void setShrinkMotionSpecResource(int i) {
        setShrinkMotionSpec(s33.m12445a(getContext(), i));
    }

    public static class ExtendedFloatingActionButtonBehavior<T extends ExtendedFloatingActionButton> extends CoordinatorLayout.C0174c<T> {

        /* renamed from: a */
        public Rect f3158a;

        /* renamed from: b */
        public boolean f3159b;

        /* renamed from: c */
        public boolean f3160c;

        public ExtendedFloatingActionButtonBehavior() {
            this.f3159b = false;
            this.f3160c = true;
        }

        public ExtendedFloatingActionButtonBehavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, l33.ExtendedFloatingActionButton_Behavior_Layout);
            this.f3159b = obtainStyledAttributes.getBoolean(l33.ExtendedFloatingActionButton_Behavior_Layout_behavior_autoHide, false);
            this.f3160c = obtainStyledAttributes.getBoolean(l33.ExtendedFloatingActionButton_Behavior_Layout_behavior_autoShrink, true);
            obtainStyledAttributes.recycle();
        }

        /* renamed from: a */
        public void mo1254a(CoordinatorLayout.C0177f fVar) {
            if (fVar.f1045h == 0) {
                fVar.f1045h = 80;
            }
        }

        /* renamed from: a */
        public void mo3704a(ExtendedFloatingActionButton extendedFloatingActionButton) {
            boolean z = this.f3160c;
            if (this.f3160c) {
                g63 g63 = extendedFloatingActionButton.f3153s0;
            } else {
                g63 g632 = extendedFloatingActionButton.f3154t0;
            }
            ExtendedFloatingActionButton.m3027a(extendedFloatingActionButton);
            throw null;
        }

        /* renamed from: a */
        public /* bridge */ /* synthetic */ boolean mo1264a(CoordinatorLayout coordinatorLayout, View view, Rect rect) {
            return mo3709a((ExtendedFloatingActionButton) view, rect);
        }

        /* renamed from: a */
        public final boolean mo3706a(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, ExtendedFloatingActionButton extendedFloatingActionButton) {
            if (!mo3705a((View) appBarLayout, extendedFloatingActionButton)) {
                return false;
            }
            if (this.f3158a == null) {
                this.f3158a = new Rect();
            }
            Rect rect = this.f3158a;
            j63.m7343a((ViewGroup) coordinatorLayout, (View) appBarLayout, rect);
            if (rect.bottom <= appBarLayout.getMinimumHeightForVisibleOverlappingContent()) {
                mo3710b(extendedFloatingActionButton);
                return true;
            }
            mo3704a(extendedFloatingActionButton);
            return true;
        }

        /* renamed from: b */
        public void mo3710b(ExtendedFloatingActionButton extendedFloatingActionButton) {
            boolean z = this.f3160c;
            if (this.f3160c) {
                g63 g63 = extendedFloatingActionButton.f3152r0;
            } else {
                g63 g632 = extendedFloatingActionButton.f3155u0;
            }
            ExtendedFloatingActionButton.m3027a(extendedFloatingActionButton);
            throw null;
        }

        /* renamed from: b */
        public final boolean mo3711b(View view, ExtendedFloatingActionButton extendedFloatingActionButton) {
            if (!mo3705a(view, extendedFloatingActionButton)) {
                return false;
            }
            if (view.getTop() < (extendedFloatingActionButton.getHeight() / 2) + ((CoordinatorLayout.C0177f) extendedFloatingActionButton.getLayoutParams()).topMargin) {
                mo3710b(extendedFloatingActionButton);
                return true;
            }
            mo3704a(extendedFloatingActionButton);
            return true;
        }

        /* renamed from: a */
        public boolean mo3709a(ExtendedFloatingActionButton extendedFloatingActionButton, Rect rect) {
            Rect rect2 = extendedFloatingActionButton.f3151q0;
            rect.set(extendedFloatingActionButton.getLeft() + rect2.left, extendedFloatingActionButton.getTop() + rect2.top, extendedFloatingActionButton.getRight() - rect2.right, extendedFloatingActionButton.getBottom() - rect2.bottom);
            return true;
        }

        /* renamed from: a */
        public boolean mo1273b(CoordinatorLayout coordinatorLayout, ExtendedFloatingActionButton extendedFloatingActionButton, View view) {
            if (view instanceof AppBarLayout) {
                mo3706a(coordinatorLayout, (AppBarLayout) view, extendedFloatingActionButton);
            } else {
                ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
                if (layoutParams instanceof CoordinatorLayout.C0177f ? ((CoordinatorLayout.C0177f) layoutParams).f1038a instanceof BottomSheetBehavior : false) {
                    mo3711b(view, extendedFloatingActionButton);
                }
            }
            return false;
        }

        /* renamed from: a */
        public boolean mo203a(CoordinatorLayout coordinatorLayout, ExtendedFloatingActionButton extendedFloatingActionButton, int i) {
            List<View> b = coordinatorLayout.mo1206b((View) extendedFloatingActionButton);
            int size = b.size();
            int i2 = 0;
            for (int i3 = 0; i3 < size; i3++) {
                View view = b.get(i3);
                if (!(view instanceof AppBarLayout)) {
                    ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
                    if ((layoutParams instanceof CoordinatorLayout.C0177f ? ((CoordinatorLayout.C0177f) layoutParams).f1038a instanceof BottomSheetBehavior : false) && mo3711b(view, extendedFloatingActionButton)) {
                        break;
                    }
                } else if (mo3706a(coordinatorLayout, (AppBarLayout) view, extendedFloatingActionButton)) {
                    break;
                }
            }
            coordinatorLayout.mo1213c((View) extendedFloatingActionButton, i);
            Rect rect = extendedFloatingActionButton.f3151q0;
            if (rect == null || rect.centerX() <= 0 || rect.centerY() <= 0) {
                return true;
            }
            CoordinatorLayout.C0177f fVar = (CoordinatorLayout.C0177f) extendedFloatingActionButton.getLayoutParams();
            int i4 = extendedFloatingActionButton.getRight() >= coordinatorLayout.getWidth() - fVar.rightMargin ? rect.right : extendedFloatingActionButton.getLeft() <= fVar.leftMargin ? -rect.left : 0;
            if (extendedFloatingActionButton.getBottom() >= coordinatorLayout.getHeight() - fVar.bottomMargin) {
                i2 = rect.bottom;
            } else if (extendedFloatingActionButton.getTop() <= fVar.topMargin) {
                i2 = -rect.top;
            }
            if (i2 != 0) {
                C2189w7.m15007e(extendedFloatingActionButton, i2);
            }
            if (i4 == 0) {
                return true;
            }
            C2189w7.m15005d(extendedFloatingActionButton, i4);
            return true;
        }

        /* renamed from: a */
        public final boolean mo3705a(View view, ExtendedFloatingActionButton extendedFloatingActionButton) {
            CoordinatorLayout.C0177f fVar = (CoordinatorLayout.C0177f) extendedFloatingActionButton.getLayoutParams();
            if ((this.f3159b || this.f3160c) && fVar.f1043f == view.getId()) {
                return true;
            }
            return false;
        }
    }
}
