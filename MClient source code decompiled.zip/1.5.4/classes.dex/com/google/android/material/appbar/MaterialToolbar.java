package com.google.android.material.appbar;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;
import androidx.appcompat.widget.Toolbar;

public class MaterialToolbar extends Toolbar {

    /* renamed from: P0 */
    public static final int f3010P0 = k33.Widget_MaterialComponents_Toolbar;

    public MaterialToolbar(Context context) {
        this(context, (AttributeSet) null);
    }

    public MaterialToolbar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, b33.toolbarStyle);
    }

    public MaterialToolbar(Context context, AttributeSet attributeSet, int i) {
        super(o63.m10327b(context, attributeSet, i, f3010P0), attributeSet, i);
        Context context2 = getContext();
        Drawable background = getBackground();
        if (background == null || (background instanceof ColorDrawable)) {
            f73 f73 = new f73();
            f73.mo5471a(ColorStateList.valueOf(background != null ? ((ColorDrawable) background).getColor() : 0));
            f73.f5079X.f5102b = new w53(context2);
            f73.mo5496l();
            f73.mo5467a(C2189w7.m15014i(this));
            int i2 = Build.VERSION.SDK_INT;
            setBackground(f73);
        }
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        Drawable background = getBackground();
        if (background instanceof f73) {
            t53.m13106a((View) this, (f73) background);
        }
    }

    public void setElevation(float f) {
        super.setElevation(f);
        t53.m13105a((View) this, f);
    }
}
