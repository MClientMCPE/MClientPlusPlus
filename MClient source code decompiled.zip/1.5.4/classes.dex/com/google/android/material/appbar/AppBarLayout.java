package com.google.android.material.appbar;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.AbsSavedState;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import java.lang.ref.WeakReference;
import java.util.List;

@CoordinatorLayout.C0175d(Behavior.class)
public class AppBarLayout extends LinearLayout {

    /* renamed from: a0 */
    public int f2981a0;

    /* renamed from: b0 */
    public int f2982b0;

    /* renamed from: c0 */
    public int f2983c0;

    /* renamed from: d0 */
    public int f2984d0;

    /* renamed from: e0 */
    public boolean f2985e0;

    /* renamed from: f0 */
    public int f2986f0;

    /* renamed from: g0 */
    public C0592e8 f2987g0;

    /* renamed from: h0 */
    public List<C0415a> f2988h0;

    /* renamed from: i0 */
    public boolean f2989i0;

    /* renamed from: j0 */
    public boolean f2990j0;

    /* renamed from: k0 */
    public boolean f2991k0;

    /* renamed from: l0 */
    public boolean f2992l0;

    /* renamed from: m0 */
    public int f2993m0;

    /* renamed from: n0 */
    public WeakReference<View> f2994n0;

    /* renamed from: o0 */
    public ValueAnimator f2995o0;

    /* renamed from: p0 */
    public int[] f2996p0;

    /* renamed from: q0 */
    public Drawable f2997q0;

    public static class BaseBehavior<T extends AppBarLayout> extends y33<T> {

        /* renamed from: k */
        public int f2998k;

        /* renamed from: l */
        public int f2999l;

        /* renamed from: m */
        public ValueAnimator f3000m;

        /* renamed from: n */
        public int f3001n = -1;

        /* renamed from: o */
        public boolean f3002o;

        /* renamed from: p */
        public float f3003p;

        /* renamed from: q */
        public WeakReference<View> f3004q;

        /* renamed from: com.google.android.material.appbar.AppBarLayout$BaseBehavior$a */
        public static class C0413a extends C1904t8 {
            public static final Parcelable.Creator<C0413a> CREATOR = new C0414a();

            /* renamed from: Z */
            public int f3005Z;

            /* renamed from: a0 */
            public float f3006a0;

            /* renamed from: b0 */
            public boolean f3007b0;

            /* renamed from: com.google.android.material.appbar.AppBarLayout$BaseBehavior$a$a */
            public static class C0414a implements Parcelable.ClassLoaderCreator<C0413a> {
                public Object createFromParcel(Parcel parcel) {
                    return new C0413a(parcel, (ClassLoader) null);
                }

                public Object[] newArray(int i) {
                    return new C0413a[i];
                }

                public Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                    return new C0413a(parcel, classLoader);
                }
            }

            public C0413a(Parcel parcel, ClassLoader classLoader) {
                super(parcel, classLoader);
                this.f3005Z = parcel.readInt();
                this.f3006a0 = parcel.readFloat();
                this.f3007b0 = parcel.readByte() != 0;
            }

            public C0413a(Parcelable parcelable) {
                super(parcelable);
            }

            public void writeToParcel(Parcel parcel, int i) {
                parcel.writeParcelable(this.f14707X, i);
                parcel.writeInt(this.f3005Z);
                parcel.writeFloat(this.f3006a0);
                parcel.writeByte(this.f3007b0 ? (byte) 1 : 0);
            }
        }

        public BaseBehavior() {
        }

        public BaseBehavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        /* renamed from: a */
        public static boolean m2857a(int i, int i2) {
            return (i & i2) == i2;
        }

        /* renamed from: a */
        public final View mo3318a(CoordinatorLayout coordinatorLayout) {
            int childCount = coordinatorLayout.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = coordinatorLayout.getChildAt(i);
                if ((childAt instanceof C1222l7) || (childAt instanceof ListView) || (childAt instanceof ScrollView)) {
                    return childAt;
                }
            }
            return null;
        }

        /* renamed from: a */
        public /* bridge */ /* synthetic */ void mo1259a(CoordinatorLayout coordinatorLayout, View view, View view2, int i, int i2, int i3, int i4, int i5, int[] iArr) {
            mo3322a(coordinatorLayout, (AppBarLayout) view, i4, iArr);
        }

        /* renamed from: a */
        public /* bridge */ /* synthetic */ void mo1260a(CoordinatorLayout coordinatorLayout, View view, View view2, int i, int i2, int[] iArr, int i3) {
            mo3325a(coordinatorLayout, (AppBarLayout) view, view2, i2, iArr);
        }

        /* renamed from: a */
        public void mo3337c(CoordinatorLayout coordinatorLayout, T t) {
            mo3338c(coordinatorLayout, t);
            if (t.mo3281c()) {
                t.mo3279a(t.mo3278a(mo3318a(coordinatorLayout)));
            }
        }

        /* renamed from: a */
        public final void mo3320a(CoordinatorLayout coordinatorLayout, T t, int i, float f) {
            int abs = Math.abs(mo3339j() - i);
            float abs2 = Math.abs(f);
            int round = abs2 > 0.0f ? Math.round((((float) abs) / abs2) * 1000.0f) * 3 : (int) (((((float) abs) / ((float) t.getHeight())) + 1.0f) * 150.0f);
            int j = mo3339j();
            if (j == i) {
                ValueAnimator valueAnimator = this.f3000m;
                if (valueAnimator != null && valueAnimator.isRunning()) {
                    this.f3000m.cancel();
                    return;
                }
                return;
            }
            ValueAnimator valueAnimator2 = this.f3000m;
            if (valueAnimator2 == null) {
                this.f3000m = new ValueAnimator();
                this.f3000m.setInterpolator(m33.f9978e);
                this.f3000m.addUpdateListener(new x33(this, coordinatorLayout, t));
            } else {
                valueAnimator2.cancel();
            }
            this.f3000m.setDuration((long) Math.min(round, 600));
            this.f3000m.setIntValues(new int[]{j, i});
            this.f3000m.start();
        }

        /* renamed from: a */
        public void mo3322a(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, int i, int[] iArr) {
            if (i < 0) {
                iArr[1] = mo12747a(coordinatorLayout, appBarLayout, i, -appBarLayout.getDownNestedScrollRange(), 0);
            }
        }

        /* renamed from: a */
        public void mo1256a(CoordinatorLayout coordinatorLayout, T t, View view, int i) {
            if (this.f2999l == 0 || i == 1) {
                mo3338c(coordinatorLayout, t);
                if (t.mo3281c()) {
                    t.mo3279a(t.mo3278a(view));
                }
            }
            this.f3004q = new WeakReference<>(view);
        }

        /* renamed from: a */
        public void mo3325a(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, View view, int i, int[] iArr) {
            int i2;
            int i3;
            if (i != 0) {
                if (i < 0) {
                    int i4 = -appBarLayout.getTotalScrollRange();
                    i3 = i4;
                    i2 = appBarLayout.getDownNestedPreScrollRange() + i4;
                } else {
                    i3 = -appBarLayout.getUpNestedPreScrollRange();
                    i2 = 0;
                }
                if (i3 != i2) {
                    iArr[1] = mo12747a(coordinatorLayout, appBarLayout, i, i3, i2);
                }
            }
            if (appBarLayout.mo3281c()) {
                appBarLayout.mo3279a(appBarLayout.mo3278a(view));
            }
        }

        /* renamed from: a */
        public boolean mo203a(CoordinatorLayout coordinatorLayout, T t, int i) {
            super.mo203a(coordinatorLayout, t, i);
            int pendingAction = t.getPendingAction();
            int i2 = this.f3001n;
            if (i2 >= 0 && (pendingAction & 8) == 0) {
                View childAt = t.getChildAt(i2);
                int i3 = -childAt.getBottom();
                mo12749c(coordinatorLayout, t, this.f3002o ? t.getTopInset() + C2189w7.m15019n(childAt) + i3 : Math.round(((float) childAt.getHeight()) * this.f3003p) + i3);
            } else if (pendingAction != 0) {
                boolean z = (pendingAction & 4) != 0;
                if ((pendingAction & 2) != 0) {
                    int i4 = -t.getUpNestedPreScrollRange();
                    if (z) {
                        mo3320a(coordinatorLayout, t, i4, 0.0f);
                    } else {
                        mo12749c(coordinatorLayout, t, i4);
                    }
                } else if ((pendingAction & 1) != 0) {
                    if (z) {
                        mo3320a(coordinatorLayout, t, 0, 0.0f);
                    } else {
                        mo12749c(coordinatorLayout, t, 0);
                    }
                }
            }
            t.mo3283d();
            this.f3001n = -1;
            mo202a(C0815h0.m5771a(mo205i(), -t.getTotalScrollRange(), 0));
            mo3321a(coordinatorLayout, t, mo205i(), 0, true);
            t.mo3275a(mo205i());
            return true;
        }

        /* renamed from: a */
        public boolean mo1263a(CoordinatorLayout coordinatorLayout, T t, int i, int i2, int i3, int i4) {
            if (((CoordinatorLayout.C0177f) t.getLayoutParams()).height == -2) {
                coordinatorLayout.mo1197a((View) t, i, i2, View.MeasureSpec.makeMeasureSpec(0, 0), i4);
                return true;
            }
            super.mo1263a(coordinatorLayout, t, i, i2, i3, i4);
            return false;
        }

        /* renamed from: a */
        public boolean mo3326a(T t) {
            WeakReference<View> weakReference = this.f3004q;
            if (weakReference == null) {
                return true;
            }
            View view = (View) weakReference.get();
            return view != null && view.isShown() && !view.canScrollVertically(-1);
        }

        /* renamed from: b */
        public int mo3331b(T t) {
            return -t.getDownNestedScrollRange();
        }

        /* renamed from: b */
        public Parcelable mo1271b(CoordinatorLayout coordinatorLayout, T t) {
            AbsSavedState absSavedState = View.BaseSavedState.EMPTY_STATE;
            int i = mo205i();
            int childCount = t.getChildCount();
            boolean z = false;
            int i2 = 0;
            while (i2 < childCount) {
                View childAt = t.getChildAt(i2);
                int bottom = childAt.getBottom() + i;
                if (childAt.getTop() + i > 0 || bottom < 0) {
                    i2++;
                } else {
                    C0413a aVar = new C0413a(absSavedState);
                    aVar.f3005Z = i2;
                    if (bottom == t.getTopInset() + C2189w7.m15019n(childAt)) {
                        z = true;
                    }
                    aVar.f3007b0 = z;
                    aVar.f3006a0 = ((float) bottom) / ((float) childAt.getHeight());
                    return aVar;
                }
            }
            return absSavedState;
        }

        /* renamed from: b */
        public /* bridge */ /* synthetic */ boolean mo1274b(CoordinatorLayout coordinatorLayout, View view, View view2, View view3, int i, int i2) {
            return mo3329a(coordinatorLayout, (AppBarLayout) view, view2, i, i2);
        }

        /* renamed from: c */
        public int mo3335c(T t) {
            return t.getTotalScrollRange();
        }

        /* renamed from: c */
        public final void mo3338c(CoordinatorLayout coordinatorLayout, T t) {
            int j = mo3339j();
            int childCount = t.getChildCount();
            int i = 0;
            while (true) {
                if (i >= childCount) {
                    i = -1;
                    break;
                }
                View childAt = t.getChildAt(i);
                int top = childAt.getTop();
                int bottom = childAt.getBottom();
                C0416b bVar = (C0416b) childAt.getLayoutParams();
                if (m2857a(bVar.f3008a, 32)) {
                    top -= bVar.topMargin;
                    bottom += bVar.bottomMargin;
                }
                int i2 = -j;
                if (top <= i2 && bottom >= i2) {
                    break;
                }
                i++;
            }
            if (i >= 0) {
                View childAt2 = t.getChildAt(i);
                C0416b bVar2 = (C0416b) childAt2.getLayoutParams();
                int i3 = bVar2.f3008a;
                if ((i3 & 17) == 17) {
                    int i4 = -childAt2.getTop();
                    int i5 = -childAt2.getBottom();
                    if (i == t.getChildCount() - 1) {
                        i5 += t.getTopInset();
                    }
                    if (m2857a(i3, 2)) {
                        i5 += C2189w7.m15019n(childAt2);
                    } else if (m2857a(i3, 5)) {
                        int n = C2189w7.m15019n(childAt2) + i5;
                        if (j < n) {
                            i4 = n;
                        } else {
                            i5 = n;
                        }
                    }
                    if (m2857a(i3, 32)) {
                        i4 += bVar2.topMargin;
                        i5 -= bVar2.bottomMargin;
                    }
                    if (j < (i5 + i4) / 2) {
                        i4 = i5;
                    }
                    mo3320a(coordinatorLayout, t, C0815h0.m5771a(i4, -t.getTotalScrollRange(), 0), 0.0f);
                }
            }
        }

        /* renamed from: j */
        public int mo3339j() {
            return mo205i() + this.f2998k;
        }

        /* renamed from: a */
        public void mo1255a(CoordinatorLayout coordinatorLayout, T t, Parcelable parcelable) {
            if (parcelable instanceof C0413a) {
                C0413a aVar = (C0413a) parcelable;
                Parcelable parcelable2 = aVar.f14707X;
                this.f3001n = aVar.f3005Z;
                this.f3003p = aVar.f3006a0;
                this.f3002o = aVar.f3007b0;
                return;
            }
            this.f3001n = -1;
        }

        /* JADX WARNING: Code restructure failed: missing block: B:10:0x0024, code lost:
            if ((r4.mo3280b() && r3.getHeight() - r5.getHeight() <= r4.getHeight()) != false) goto L_0x0028;
         */
        /* renamed from: a */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public boolean mo3329a(androidx.coordinatorlayout.widget.CoordinatorLayout r3, com.google.android.material.appbar.AppBarLayout r4, android.view.View r5, int r6, int r7) {
            /*
                r2 = this;
                r6 = r6 & 2
                r0 = 1
                r1 = 0
                if (r6 == 0) goto L_0x0027
                boolean r6 = r4.mo3281c()
                if (r6 != 0) goto L_0x0028
                boolean r6 = r4.mo3280b()
                if (r6 == 0) goto L_0x0023
                int r3 = r3.getHeight()
                int r5 = r5.getHeight()
                int r3 = r3 - r5
                int r4 = r4.getHeight()
                if (r3 > r4) goto L_0x0023
                r3 = 1
                goto L_0x0024
            L_0x0023:
                r3 = 0
            L_0x0024:
                if (r3 == 0) goto L_0x0027
                goto L_0x0028
            L_0x0027:
                r0 = 0
            L_0x0028:
                if (r0 == 0) goto L_0x0031
                android.animation.ValueAnimator r3 = r2.f3000m
                if (r3 == 0) goto L_0x0031
                r3.cancel()
            L_0x0031:
                r3 = 0
                r2.f3004q = r3
                r2.f2999l = r7
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.appbar.AppBarLayout.BaseBehavior.mo3329a(androidx.coordinatorlayout.widget.CoordinatorLayout, com.google.android.material.appbar.AppBarLayout, android.view.View, int, int):boolean");
        }

        /* JADX WARNING: Removed duplicated region for block: B:34:0x00a5  */
        /* JADX WARNING: Removed duplicated region for block: B:35:0x00a8  */
        /* renamed from: a */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public int mo3332b(androidx.coordinatorlayout.widget.CoordinatorLayout r9, T r10, int r11, int r12, int r13) {
            /*
                r8 = this;
                int r0 = r8.mo3339j()
                r1 = 0
                if (r12 == 0) goto L_0x00b2
                if (r0 < r12) goto L_0x00b2
                if (r0 > r13) goto L_0x00b2
                int r5 = p000.C0815h0.m5771a((int) r11, (int) r12, (int) r13)
                if (r0 == r5) goto L_0x00b4
                boolean r11 = r10.mo3277a()
                if (r11 == 0) goto L_0x0086
                int r11 = java.lang.Math.abs(r5)
                int r12 = r10.getChildCount()
                r13 = 0
            L_0x0020:
                if (r13 >= r12) goto L_0x0086
                android.view.View r2 = r10.getChildAt(r13)
                android.view.ViewGroup$LayoutParams r3 = r2.getLayoutParams()
                com.google.android.material.appbar.AppBarLayout$b r3 = (com.google.android.material.appbar.AppBarLayout.C0416b) r3
                android.view.animation.Interpolator r4 = r3.mo3347a()
                int r6 = r2.getTop()
                if (r11 < r6) goto L_0x0083
                int r6 = r2.getBottom()
                if (r11 > r6) goto L_0x0083
                if (r4 == 0) goto L_0x0086
                int r12 = r3.f3008a
                r13 = r12 & 1
                if (r13 == 0) goto L_0x0058
                int r13 = r2.getHeight()
                int r6 = r3.topMargin
                int r13 = r13 + r6
                int r3 = r3.bottomMargin
                int r13 = r13 + r3
                int r1 = r1 + r13
                r12 = r12 & 2
                if (r12 == 0) goto L_0x0058
                int r12 = p000.C2189w7.m15019n(r2)
                int r1 = r1 - r12
            L_0x0058:
                boolean r12 = p000.C2189w7.m15015j(r2)
                if (r12 == 0) goto L_0x0063
                int r12 = r10.getTopInset()
                int r1 = r1 - r12
            L_0x0063:
                if (r1 <= 0) goto L_0x0086
                int r12 = r2.getTop()
                int r11 = r11 - r12
                float r12 = (float) r1
                float r11 = (float) r11
                float r11 = r11 / r12
                float r11 = r4.getInterpolation(r11)
                float r11 = r11 * r12
                int r11 = java.lang.Math.round(r11)
                int r12 = java.lang.Integer.signum(r5)
                int r13 = r2.getTop()
                int r13 = r13 + r11
                int r13 = r13 * r12
                goto L_0x0087
            L_0x0083:
                int r13 = r13 + 1
                goto L_0x0020
            L_0x0086:
                r13 = r5
            L_0x0087:
                boolean r11 = r8.mo202a(r13)
                int r1 = r0 - r5
                int r12 = r5 - r13
                r8.f2998k = r12
                if (r11 != 0) goto L_0x009c
                boolean r11 = r10.mo3277a()
                if (r11 == 0) goto L_0x009c
                r9.mo1196a((android.view.View) r10)
            L_0x009c:
                int r11 = r8.mo205i()
                r10.mo3275a((int) r11)
                if (r5 >= r0) goto L_0x00a8
                r11 = -1
                r6 = -1
                goto L_0x00aa
            L_0x00a8:
                r11 = 1
                r6 = 1
            L_0x00aa:
                r7 = 0
                r2 = r8
                r3 = r9
                r4 = r10
                r2.mo3321a((androidx.coordinatorlayout.widget.CoordinatorLayout) r3, r4, (int) r5, (int) r6, (boolean) r7)
                goto L_0x00b4
            L_0x00b2:
                r8.f2998k = r1
            L_0x00b4:
                return r1
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.appbar.AppBarLayout.BaseBehavior.mo3332b(androidx.coordinatorlayout.widget.CoordinatorLayout, com.google.android.material.appbar.AppBarLayout, int, int, int):int");
        }

        /* JADX WARNING: Removed duplicated region for block: B:25:0x0062  */
        /* JADX WARNING: Removed duplicated region for block: B:28:0x0070  */
        /* renamed from: a */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final void mo3321a(androidx.coordinatorlayout.widget.CoordinatorLayout r7, T r8, int r9, int r10, boolean r11) {
            /*
                r6 = this;
                int r0 = java.lang.Math.abs(r9)
                int r1 = r8.getChildCount()
                r2 = 0
                r3 = 0
            L_0x000a:
                if (r3 >= r1) goto L_0x0020
                android.view.View r4 = r8.getChildAt(r3)
                int r5 = r4.getTop()
                if (r0 < r5) goto L_0x001d
                int r5 = r4.getBottom()
                if (r0 > r5) goto L_0x001d
                goto L_0x0021
            L_0x001d:
                int r3 = r3 + 1
                goto L_0x000a
            L_0x0020:
                r4 = 0
            L_0x0021:
                if (r4 == 0) goto L_0x00a1
                android.view.ViewGroup$LayoutParams r0 = r4.getLayoutParams()
                com.google.android.material.appbar.AppBarLayout$b r0 = (com.google.android.material.appbar.AppBarLayout.C0416b) r0
                int r0 = r0.f3008a
                r1 = r0 & 1
                r3 = 1
                if (r1 == 0) goto L_0x005b
                int r1 = p000.C2189w7.m15019n(r4)
                if (r10 <= 0) goto L_0x0049
                r10 = r0 & 12
                if (r10 == 0) goto L_0x0049
                int r9 = -r9
                int r10 = r4.getBottom()
                int r10 = r10 - r1
                int r0 = r8.getTopInset()
                int r10 = r10 - r0
                if (r9 < r10) goto L_0x005b
            L_0x0047:
                r9 = 1
                goto L_0x005c
            L_0x0049:
                r10 = r0 & 2
                if (r10 == 0) goto L_0x005b
                int r9 = -r9
                int r10 = r4.getBottom()
                int r10 = r10 - r1
                int r0 = r8.getTopInset()
                int r10 = r10 - r0
                if (r9 < r10) goto L_0x005b
                goto L_0x0047
            L_0x005b:
                r9 = 0
            L_0x005c:
                boolean r10 = r8.mo3281c()
                if (r10 == 0) goto L_0x006a
                android.view.View r9 = r6.mo3318a((androidx.coordinatorlayout.widget.CoordinatorLayout) r7)
                boolean r9 = r8.mo3278a((android.view.View) r9)
            L_0x006a:
                boolean r9 = r8.mo3279a((boolean) r9)
                if (r11 != 0) goto L_0x009e
                if (r9 == 0) goto L_0x00a1
                java.util.List r7 = r7.mo1211c((android.view.View) r8)
                int r9 = r7.size()
                r10 = 0
            L_0x007b:
                if (r10 >= r9) goto L_0x009c
                java.lang.Object r11 = r7.get(r10)
                android.view.View r11 = (android.view.View) r11
                android.view.ViewGroup$LayoutParams r11 = r11.getLayoutParams()
                androidx.coordinatorlayout.widget.CoordinatorLayout$f r11 = (androidx.coordinatorlayout.widget.CoordinatorLayout.C0177f) r11
                androidx.coordinatorlayout.widget.CoordinatorLayout$c r11 = r11.f1038a
                boolean r0 = r11 instanceof com.google.android.material.appbar.AppBarLayout.ScrollingViewBehavior
                if (r0 == 0) goto L_0x0099
                com.google.android.material.appbar.AppBarLayout$ScrollingViewBehavior r11 = (com.google.android.material.appbar.AppBarLayout.ScrollingViewBehavior) r11
                int r7 = r11.mo13071j()
                if (r7 == 0) goto L_0x009c
                r2 = 1
                goto L_0x009c
            L_0x0099:
                int r10 = r10 + 1
                goto L_0x007b
            L_0x009c:
                if (r2 == 0) goto L_0x00a1
            L_0x009e:
                r8.jumpDrawablesToCurrentState()
            L_0x00a1:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.appbar.AppBarLayout.BaseBehavior.mo3321a(androidx.coordinatorlayout.widget.CoordinatorLayout, com.google.android.material.appbar.AppBarLayout, int, int, boolean):void");
        }
    }

    public static class Behavior extends BaseBehavior<AppBarLayout> {
        public Behavior() {
        }

        public Behavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }
    }

    /* renamed from: com.google.android.material.appbar.AppBarLayout$a */
    public interface C0415a<T extends AppBarLayout> {
        /* renamed from: a */
        void mo3346a(T t, int i);
    }

    /* renamed from: com.google.android.material.appbar.AppBarLayout$b */
    public static class C0416b extends LinearLayout.LayoutParams {

        /* renamed from: a */
        public int f3008a = 1;

        /* renamed from: b */
        public Interpolator f3009b;

        public C0416b(int i, int i2) {
            super(i, i2);
        }

        public C0416b(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, l33.AppBarLayout_Layout);
            this.f3008a = obtainStyledAttributes.getInt(l33.AppBarLayout_Layout_layout_scrollFlags, 0);
            if (obtainStyledAttributes.hasValue(l33.AppBarLayout_Layout_layout_scrollInterpolator)) {
                this.f3009b = AnimationUtils.loadInterpolator(context, obtainStyledAttributes.getResourceId(l33.AppBarLayout_Layout_layout_scrollInterpolator, 0));
            }
            obtainStyledAttributes.recycle();
        }

        public C0416b(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public C0416b(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        public C0416b(LinearLayout.LayoutParams layoutParams) {
            super(layoutParams);
        }

        /* renamed from: a */
        public Interpolator mo3347a() {
            return this.f3009b;
        }
    }

    /* renamed from: a */
    public void mo3275a(int i) {
        this.f2981a0 = i;
        if (!willNotDraw()) {
            C2189w7.m14972D(this);
        }
        List<C0415a> list = this.f2988h0;
        if (list != null) {
            int size = list.size();
            for (int i2 = 0; i2 < size; i2++) {
                C0415a aVar = this.f2988h0.get(i2);
                if (aVar != null) {
                    aVar.mo3346a(this, i);
                }
            }
        }
    }

    /* renamed from: a */
    public void mo3276a(boolean z, boolean z2) {
        this.f2986f0 = (z ? 1 : 2) | (z2 ? 4 : 0) | 8;
        requestLayout();
    }

    /* renamed from: a */
    public boolean mo3277a() {
        return this.f2985e0;
    }

    /* renamed from: b */
    public boolean mo3280b() {
        return getTotalScrollRange() != 0;
    }

    /* renamed from: c */
    public boolean mo3281c() {
        return this.f2992l0;
    }

    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0416b;
    }

    /* renamed from: d */
    public void mo3283d() {
        this.f2986f0 = 0;
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (this.f2997q0 != null && getTopInset() > 0) {
            int save = canvas.save();
            canvas.translate(0.0f, (float) (-this.f2981a0));
            this.f2997q0.draw(canvas);
            canvas.restoreToCount(save);
        }
    }

    public void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        Drawable drawable = this.f2997q0;
        if (drawable != null && drawable.isStateful() && drawable.setState(drawableState)) {
            invalidateDrawable(drawable);
        }
    }

    /* renamed from: e */
    public final boolean mo3286e() {
        return this.f2997q0 != null && getTopInset() > 0;
    }

    /* renamed from: f */
    public final boolean mo3287f() {
        if (getChildCount() <= 0) {
            return false;
        }
        View childAt = getChildAt(0);
        return childAt.getVisibility() != 8 && !C2189w7.m15015j(childAt);
    }

    public C0416b generateDefaultLayoutParams() {
        return new C0416b(-1, -2);
    }

    public C0416b generateLayoutParams(AttributeSet attributeSet) {
        return new C0416b(getContext(), attributeSet);
    }

    public C0416b generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        int i = Build.VERSION.SDK_INT;
        return layoutParams instanceof LinearLayout.LayoutParams ? new C0416b((LinearLayout.LayoutParams) layoutParams) : layoutParams instanceof ViewGroup.MarginLayoutParams ? new C0416b((ViewGroup.MarginLayoutParams) layoutParams) : new C0416b(layoutParams);
    }

    public int getDownNestedPreScrollRange() {
        int i;
        int n;
        int i2 = this.f2983c0;
        if (i2 != -1) {
            return i2;
        }
        int i3 = 0;
        for (int childCount = getChildCount() - 1; childCount >= 0; childCount--) {
            View childAt = getChildAt(childCount);
            C0416b bVar = (C0416b) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int i4 = bVar.f3008a;
            if ((i4 & 5) == 5) {
                int i5 = bVar.topMargin + bVar.bottomMargin;
                if ((i4 & 8) != 0) {
                    n = C2189w7.m15019n(childAt);
                } else if ((i4 & 2) != 0) {
                    n = measuredHeight - C2189w7.m15019n(childAt);
                } else {
                    i = i5 + measuredHeight;
                    if (childCount == 0 && C2189w7.m15015j(childAt)) {
                        i = Math.min(i, measuredHeight - getTopInset());
                    }
                    i3 += i;
                }
                i = n + i5;
                i = Math.min(i, measuredHeight - getTopInset());
                i3 += i;
            } else if (i3 > 0) {
                break;
            }
        }
        int max = Math.max(0, i3);
        this.f2983c0 = max;
        return max;
    }

    public int getDownNestedScrollRange() {
        int i = this.f2984d0;
        if (i != -1) {
            return i;
        }
        int childCount = getChildCount();
        int i2 = 0;
        int i3 = 0;
        while (true) {
            if (i2 >= childCount) {
                break;
            }
            View childAt = getChildAt(i2);
            C0416b bVar = (C0416b) childAt.getLayoutParams();
            int measuredHeight = bVar.topMargin + bVar.bottomMargin + childAt.getMeasuredHeight();
            int i4 = bVar.f3008a;
            if ((i4 & 1) == 0) {
                break;
            }
            i3 += measuredHeight;
            if ((i4 & 2) != 0) {
                i3 -= C2189w7.m15019n(childAt);
                break;
            }
            i2++;
        }
        int max = Math.max(0, i3);
        this.f2984d0 = max;
        return max;
    }

    public int getLiftOnScrollTargetViewId() {
        return this.f2993m0;
    }

    public final int getMinimumHeightForVisibleOverlappingContent() {
        int topInset = getTopInset();
        int n = C2189w7.m15019n(this);
        if (n == 0) {
            int childCount = getChildCount();
            n = childCount >= 1 ? C2189w7.m15019n(getChildAt(childCount - 1)) : 0;
            if (n == 0) {
                return getHeight() / 3;
            }
        }
        return (n * 2) + topInset;
    }

    public int getPendingAction() {
        return this.f2986f0;
    }

    public Drawable getStatusBarForeground() {
        return this.f2997q0;
    }

    @Deprecated
    public float getTargetElevation() {
        return 0.0f;
    }

    public final int getTopInset() {
        C0592e8 e8Var = this.f2987g0;
        if (e8Var != null) {
            return e8Var.mo5057d();
        }
        return 0;
    }

    public final int getTotalScrollRange() {
        int i = this.f2982b0;
        if (i != -1) {
            return i;
        }
        int childCount = getChildCount();
        int i2 = 0;
        int i3 = 0;
        while (true) {
            if (i2 >= childCount) {
                break;
            }
            View childAt = getChildAt(i2);
            C0416b bVar = (C0416b) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int i4 = bVar.f3008a;
            if ((i4 & 1) == 0) {
                break;
            }
            int i5 = measuredHeight + bVar.topMargin + bVar.bottomMargin + i3;
            if (i2 == 0 && C2189w7.m15015j(childAt)) {
                i5 -= getTopInset();
            }
            i3 = i5;
            if ((i4 & 2) != 0) {
                i3 -= C2189w7.m15019n(childAt);
                break;
            }
            i2++;
        }
        int max = Math.max(0, i3);
        this.f2982b0 = max;
        return max;
    }

    public int getUpNestedPreScrollRange() {
        return getTotalScrollRange();
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        Drawable background = getBackground();
        if (background instanceof f73) {
            t53.m13106a((View) this, (f73) background);
        }
    }

    public int[] onCreateDrawableState(int i) {
        if (this.f2996p0 == null) {
            this.f2996p0 = new int[4];
        }
        int[] iArr = this.f2996p0;
        int[] onCreateDrawableState = super.onCreateDrawableState(i + iArr.length);
        iArr[0] = this.f2990j0 ? b33.state_liftable : -b33.state_liftable;
        iArr[1] = (!this.f2990j0 || !this.f2991k0) ? -b33.state_lifted : b33.state_lifted;
        iArr[2] = this.f2990j0 ? b33.state_collapsible : -b33.state_collapsible;
        iArr[3] = (!this.f2990j0 || !this.f2991k0) ? -b33.state_collapsed : b33.state_collapsed;
        return LinearLayout.mergeDrawableStates(onCreateDrawableState, iArr);
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        WeakReference<View> weakReference = this.f2994n0;
        if (weakReference != null) {
            weakReference.clear();
        }
        this.f2994n0 = null;
    }

    /* JADX WARNING: Code restructure failed: missing block: B:32:0x0087, code lost:
        if (r4 != false) goto L_0x0089;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onLayout(boolean r2, int r3, int r4, int r5, int r6) {
        /*
            r1 = this;
            super.onLayout(r2, r3, r4, r5, r6)
            boolean r2 = p000.C2189w7.m15015j(r1)
            r3 = 1
            if (r2 == 0) goto L_0x0025
            boolean r2 = r1.mo3287f()
            if (r2 == 0) goto L_0x0025
            int r2 = r1.getTopInset()
            int r4 = r1.getChildCount()
            int r4 = r4 - r3
        L_0x0019:
            if (r4 < 0) goto L_0x0025
            android.view.View r5 = r1.getChildAt(r4)
            p000.C2189w7.m15007e(r5, r2)
            int r4 = r4 + -1
            goto L_0x0019
        L_0x0025:
            r2 = -1
            r1.f2982b0 = r2
            r1.f2983c0 = r2
            r1.f2984d0 = r2
            r2 = 0
            r1.f2985e0 = r2
            int r4 = r1.getChildCount()
            r5 = 0
        L_0x0034:
            if (r5 >= r4) goto L_0x004a
            android.view.View r6 = r1.getChildAt(r5)
            android.view.ViewGroup$LayoutParams r6 = r6.getLayoutParams()
            com.google.android.material.appbar.AppBarLayout$b r6 = (com.google.android.material.appbar.AppBarLayout.C0416b) r6
            android.view.animation.Interpolator r6 = r6.f3009b
            if (r6 == 0) goto L_0x0047
            r1.f2985e0 = r3
            goto L_0x004a
        L_0x0047:
            int r5 = r5 + 1
            goto L_0x0034
        L_0x004a:
            android.graphics.drawable.Drawable r4 = r1.f2997q0
            if (r4 == 0) goto L_0x0059
            int r5 = r1.getWidth()
            int r6 = r1.getTopInset()
            r4.setBounds(r2, r2, r5, r6)
        L_0x0059:
            boolean r4 = r1.f2989i0
            if (r4 != 0) goto L_0x0093
            boolean r4 = r1.f2992l0
            if (r4 != 0) goto L_0x0089
            int r4 = r1.getChildCount()
            r5 = 0
        L_0x0066:
            if (r5 >= r4) goto L_0x0086
            android.view.View r6 = r1.getChildAt(r5)
            android.view.ViewGroup$LayoutParams r6 = r6.getLayoutParams()
            com.google.android.material.appbar.AppBarLayout$b r6 = (com.google.android.material.appbar.AppBarLayout.C0416b) r6
            int r6 = r6.f3008a
            r0 = r6 & 1
            if (r0 != r3) goto L_0x007e
            r6 = r6 & 10
            if (r6 == 0) goto L_0x007e
            r6 = 1
            goto L_0x007f
        L_0x007e:
            r6 = 0
        L_0x007f:
            if (r6 == 0) goto L_0x0083
            r4 = 1
            goto L_0x0087
        L_0x0083:
            int r5 = r5 + 1
            goto L_0x0066
        L_0x0086:
            r4 = 0
        L_0x0087:
            if (r4 == 0) goto L_0x008a
        L_0x0089:
            r2 = 1
        L_0x008a:
            boolean r3 = r1.f2990j0
            if (r3 == r2) goto L_0x0093
            r1.f2990j0 = r2
            r1.refreshDrawableState()
        L_0x0093:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.material.appbar.AppBarLayout.onLayout(boolean, int, int, int, int):void");
    }

    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        int mode = View.MeasureSpec.getMode(i2);
        if (mode != 1073741824 && C2189w7.m15015j(this) && mo3287f()) {
            int measuredHeight = getMeasuredHeight();
            if (mode == Integer.MIN_VALUE) {
                measuredHeight = C0815h0.m5771a(getTopInset() + getMeasuredHeight(), 0, View.MeasureSpec.getSize(i2));
            } else if (mode == 0) {
                measuredHeight += getTopInset();
            }
            setMeasuredDimension(getMeasuredWidth(), measuredHeight);
        }
        this.f2982b0 = -1;
        this.f2983c0 = -1;
        this.f2984d0 = -1;
    }

    public void setElevation(float f) {
        super.setElevation(f);
        t53.m13105a((View) this, f);
    }

    public void setExpanded(boolean z) {
        mo3276a(z, C2189w7.m15031z(this));
    }

    public void setLiftOnScroll(boolean z) {
        this.f2992l0 = z;
    }

    public void setLiftOnScrollTargetViewId(int i) {
        this.f2993m0 = i;
        WeakReference<View> weakReference = this.f2994n0;
        if (weakReference != null) {
            weakReference.clear();
        }
        this.f2994n0 = null;
    }

    public void setOrientation(int i) {
        if (i == 1) {
            super.setOrientation(i);
            return;
        }
        throw new IllegalArgumentException("AppBarLayout is always vertical and does not support horizontal orientation");
    }

    public void setStatusBarForeground(Drawable drawable) {
        Drawable drawable2 = this.f2997q0;
        if (drawable2 != drawable) {
            Drawable drawable3 = null;
            if (drawable2 != null) {
                drawable2.setCallback((Drawable.Callback) null);
            }
            if (drawable != null) {
                drawable3 = drawable.mutate();
            }
            this.f2997q0 = drawable3;
            Drawable drawable4 = this.f2997q0;
            if (drawable4 != null) {
                if (drawable4.isStateful()) {
                    this.f2997q0.setState(getDrawableState());
                }
                C0815h0.m5824a(this.f2997q0, C2189w7.m15018m(this));
                this.f2997q0.setVisible(getVisibility() == 0, false);
                this.f2997q0.setCallback(this);
            }
            setWillNotDraw(!mo3286e());
            C2189w7.m14972D(this);
        }
    }

    public void setStatusBarForegroundColor(int i) {
        setStatusBarForeground(new ColorDrawable(i));
    }

    public void setStatusBarForegroundResource(int i) {
        setStatusBarForeground(C1206l0.m8461c(getContext(), i));
    }

    @Deprecated
    public void setTargetElevation(float f) {
        if (Build.VERSION.SDK_INT >= 21) {
            c43.m2287a(this, f);
        }
    }

    public void setVisibility(int i) {
        super.setVisibility(i);
        boolean z = i == 0;
        Drawable drawable = this.f2997q0;
        if (drawable != null) {
            drawable.setVisible(z, false);
        }
    }

    public boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f2997q0;
    }

    /* renamed from: a */
    public boolean mo3279a(boolean z) {
        if (this.f2991k0 == z) {
            return false;
        }
        this.f2991k0 = z;
        refreshDrawableState();
        if (this.f2992l0 && (getBackground() instanceof f73)) {
            f73 f73 = (f73) getBackground();
            float dimension = getResources().getDimension(d33.design_appbar_elevation);
            float f = z ? 0.0f : dimension;
            if (!z) {
                dimension = 0.0f;
            }
            ValueAnimator valueAnimator = this.f2995o0;
            if (valueAnimator != null) {
                valueAnimator.cancel();
            }
            this.f2995o0 = ValueAnimator.ofFloat(new float[]{f, dimension});
            this.f2995o0.setDuration((long) getResources().getInteger(g33.app_bar_elevation_anim_duration));
            this.f2995o0.setInterpolator(m33.f9974a);
            this.f2995o0.addUpdateListener(new w33(this, f73));
            this.f2995o0.start();
        }
        return true;
    }

    public static class ScrollingViewBehavior extends z33 {
        public ScrollingViewBehavior() {
        }

        public ScrollingViewBehavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, l33.ScrollingViewBehavior_Layout);
            mo13070b(obtainStyledAttributes.getDimensionPixelSize(l33.ScrollingViewBehavior_Layout_behavior_overlapTop, 0));
            obtainStyledAttributes.recycle();
        }

        /* renamed from: a */
        public AppBarLayout m2890a(List<View> list) {
            int size = list.size();
            for (int i = 0; i < size; i++) {
                View view = list.get(i);
                if (view instanceof AppBarLayout) {
                    return (AppBarLayout) view;
                }
            }
            return null;
        }

        /* renamed from: a */
        public boolean mo1265a(CoordinatorLayout coordinatorLayout, View view, Rect rect, boolean z) {
            AppBarLayout a = mo3343a((List) coordinatorLayout.mo1206b(view));
            if (a != null) {
                rect.offset(view.getLeft(), view.getTop());
                Rect rect2 = this.f18167d;
                rect2.set(0, 0, coordinatorLayout.getWidth(), coordinatorLayout.getHeight());
                if (!rect2.contains(rect)) {
                    a.mo3276a(false, !z);
                    return true;
                }
            }
            return false;
        }

        /* renamed from: a */
        public boolean mo1267a(CoordinatorLayout coordinatorLayout, View view, View view2) {
            return view2 instanceof AppBarLayout;
        }

        /* renamed from: b */
        public float mo3344b(View view) {
            int i;
            if (view instanceof AppBarLayout) {
                AppBarLayout appBarLayout = (AppBarLayout) view;
                int totalScrollRange = appBarLayout.getTotalScrollRange();
                int downNestedPreScrollRange = appBarLayout.getDownNestedPreScrollRange();
                CoordinatorLayout.C0174c cVar = ((CoordinatorLayout.C0177f) appBarLayout.getLayoutParams()).f1038a;
                int j = cVar instanceof BaseBehavior ? ((BaseBehavior) cVar).mo3339j() : 0;
                if ((downNestedPreScrollRange == 0 || totalScrollRange + j > downNestedPreScrollRange) && (i = totalScrollRange - downNestedPreScrollRange) != 0) {
                    return (((float) j) / ((float) i)) + 1.0f;
                }
            }
            return 0.0f;
        }

        /* renamed from: c */
        public int mo3345c(View view) {
            return view instanceof AppBarLayout ? ((AppBarLayout) view).getTotalScrollRange() : super.mo3345c(view);
        }

        /* renamed from: b */
        public boolean mo1273b(CoordinatorLayout coordinatorLayout, View view, View view2) {
            CoordinatorLayout.C0174c cVar = ((CoordinatorLayout.C0177f) view2.getLayoutParams()).f1038a;
            if (cVar instanceof BaseBehavior) {
                C2189w7.m15007e(view, (mo13072k() + ((view2.getBottom() - view.getTop()) + ((BaseBehavior) cVar).f2998k)) - mo13069a(view2));
            }
            if (!(view2 instanceof AppBarLayout)) {
                return false;
            }
            AppBarLayout appBarLayout = (AppBarLayout) view2;
            if (!appBarLayout.mo3281c()) {
                return false;
            }
            appBarLayout.mo3279a(appBarLayout.mo3278a(view));
            return false;
        }
    }

    /* renamed from: a */
    public boolean mo3278a(View view) {
        int i;
        if (this.f2994n0 == null && (i = this.f2993m0) != -1) {
            View findViewById = view != null ? view.findViewById(i) : null;
            if (findViewById == null && (getParent() instanceof ViewGroup)) {
                findViewById = ((ViewGroup) getParent()).findViewById(this.f2993m0);
            }
            if (findViewById != null) {
                this.f2994n0 = new WeakReference<>(findViewById);
            }
        }
        WeakReference<View> weakReference = this.f2994n0;
        View view2 = weakReference != null ? (View) weakReference.get() : null;
        if (view2 != null) {
            view = view2;
        }
        return view != null && (view.canScrollVertically(-1) || view.getScrollY() > 0);
    }
}
