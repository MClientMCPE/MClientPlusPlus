package com.xbox.httpclient;

import java.io.IOException;

public final class HttpClientResponse {
    public long handle;
    public final r14 response;

    public class NativeOutputStream {
        public NativeOutputStream() {
        }

        public native int nativeWrite(long j, byte[] bArr, long j2, long j3);
    }

    public HttpClientResponse(r14 r14, long j) {
        this.response = r14;
        this.handle = j;
    }

    public String getHeaderNameAtIndex(int i) {
        return this.response.f13340c0.f6530a[i * 2];
    }

    public String getHeaderValueAtIndex(int i) {
        return this.response.f13340c0.f6530a[(i * 2) + 1];
    }

    public int getNumHeaders() {
        return this.response.f13340c0.mo6340b();
    }

    public void getResponseBodyBytes() {
        NativeOutputStream nativeOutputStream = new NativeOutputStream();
        i44 e = this.response.f13341d0.mo5741e();
        byte[] bArr = new byte[16384];
        while (true) {
            try {
                int read = e.read(bArr);
                if (read == -1) {
                    break;
                }
                long j = (long) read;
                nativeOutputStream.nativeWrite(this.handle, bArr, 0, j);
            } catch (IOException unused) {
            }
        }
        this.response.close();
    }

    public byte[] getResponseBodyBytesLegacy() {
        try {
            return this.response.f13341d0.mo11112a();
        } catch (IOException unused) {
            return null;
        }
    }

    public int getResponseCode() {
        return this.response.f13337Z;
    }
}
