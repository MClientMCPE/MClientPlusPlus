package com.xbox.httpclient;

import java.io.IOException;

public class HttpClientRequestBody extends q14 {
    public long contentLength;
    public k14 contentType;
    public long handle;

    public class NativeInputStream {
        public NativeInputStream() {
        }

        public native int nativeRead(long j, long j2, byte[] bArr, long j3, long j4);
    }

    public HttpClientRequestBody(long j, k14 k14, long j2) {
        this.handle = j;
        this.contentType = k14;
        this.contentLength = j2;
    }

    public long contentLength() {
        return this.contentLength;
    }

    public k14 contentType() {
        return this.contentType;
    }

    public void writeTo(h44 h44) {
        NativeInputStream nativeInputStream = new NativeInputStream();
        byte[] bArr = new byte[((int) Math.min(this.contentLength, 16384))];
        long j = 0;
        while (true) {
            long j2 = this.contentLength;
            if (j < j2) {
                int nativeRead = nativeInputStream.nativeRead(this.handle, j, bArr, 0, Math.min(j2 - j, (long) bArr.length));
                if (nativeRead != -1) {
                    h44.write(bArr, 0, nativeRead);
                    j += (long) nativeRead;
                } else {
                    throw new IOException("Failed to read from native buffer");
                }
            } else {
                return;
            }
        }
    }
}
