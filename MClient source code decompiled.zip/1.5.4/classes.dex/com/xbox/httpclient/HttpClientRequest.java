package com.xbox.httpclient;

import android.content.Context;
import android.net.ConnectivityManager;
import java.io.IOException;
import p000.a44;
import p000.m14;
import p000.p14;

public final class HttpClientRequest {
    public static final m14 SHARED_CLIENT;
    public final p14.C1583a request = new p14.C1583a();

    static {
        m14.C1303b bVar = new m14.C1303b();
        a44 a44 = new a44();
        a44.C0039a aVar = a44.C0039a.NONE;
        if (aVar != null) {
            a44.f180b = aVar;
            bVar.f9941e.add(a44);
            bVar.f9959w = false;
            SHARED_CLIENT = new m14(bVar);
            return;
        }
        throw new NullPointerException("level == null. Use Level.NONE instead.");
    }

    /* access modifiers changed from: private */
    public native void OnRequestCompleted(long j, HttpClientResponse httpClientResponse);

    /* access modifiers changed from: private */
    public native void OnRequestFailed(long j, String str);

    public static boolean isNetworkAvailable(Context context) {
        ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService("connectivity");
        return connectivityManager.getActiveNetworkInfo() != null && connectivityManager.getActiveNetworkInfo().isConnected();
    }

    public void doRequestAsync(final long j) {
        ((o14) SHARED_CLIENT.mo8546a(this.request.mo9848a())).mo9423a(new t04() {
            public void onFailure(s04 s04, IOException iOException) {
                HttpClientRequest.this.OnRequestFailed(j, iOException.getClass().getCanonicalName());
            }

            public void onResponse(s04 s04, r14 r14) {
                HttpClientRequest httpClientRequest = HttpClientRequest.this;
                long j = j;
                httpClientRequest.OnRequestCompleted(j, new HttpClientResponse(r14, j));
            }
        });
    }

    public void setHttpHeader(String str, String str2) {
        this.request.f12202c.mo6346a(str, str2);
    }

    public void setHttpMethodAndBody(String str, long j, String str2, long j2) {
        k14 k14 = null;
        if (j2 != 0) {
            p14.C1583a aVar = this.request;
            if (str2 != null) {
                k14 = k14.m7979b(str2);
            }
            aVar.mo9847a(str, (q14) new HttpClientRequestBody(j, k14, j2));
        } else if (str.equals("POST") || str.equals("PUT")) {
            this.request.mo9847a(str, q14.create((k14) null, new byte[0]));
        } else {
            this.request.mo9847a(str, (q14) null);
        }
    }

    public void setHttpMethodAndBody(String str, String str2, byte[] bArr) {
        p14.C1583a aVar;
        if (bArr == null || bArr.length <= 0) {
            q14 q14 = null;
            if (str.equals("POST") || str.equals("PUT")) {
                aVar = this.request;
                q14 = q14.create((k14) null, new byte[0]);
            } else {
                aVar = this.request;
            }
            aVar.mo9847a(str, q14);
            return;
        }
        this.request.mo9847a(str, q14.create(k14.m7979b(str2), bArr));
    }

    public void setHttpUrl(String str) {
        this.request.mo9846a(str);
    }
}
