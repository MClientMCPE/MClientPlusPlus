package com.adcolony.sdk;

import android.os.Bundle;
import android.view.ViewGroup;
import android.view.ViewParent;

public class AdColonyAdViewActivity extends C2351yf {

    /* renamed from: g0 */
    public C1247lf f2831g0;

    public AdColonyAdViewActivity() {
        this.f2831g0 = !C0680fe.m4833c() ? null : C0680fe.m4730a().f16048m;
    }

    /* renamed from: b */
    public void mo2995b() {
        ViewParent parent = this.f17770X.getParent();
        if (parent != null) {
            ((ViewGroup) parent).removeView(this.f17770X);
        }
        this.f2831g0.mo8386a();
        C0680fe.m4730a().f16048m = null;
        finish();
    }

    /* renamed from: c */
    public void mo2996c() {
        this.f2831g0.mo8387b();
    }

    public void onBackPressed() {
        mo2995b();
    }

    public void onCreate(Bundle bundle) {
        C1247lf lfVar;
        if (!C0680fe.m4833c() || (lfVar = this.f2831g0) == null) {
            C0680fe.m4730a().f16048m = null;
            finish();
            return;
        }
        this.f17771Y = lfVar.getOrientation();
        super.onCreate(bundle);
        this.f2831g0.mo8387b();
        C1330mf listener = this.f2831g0.getListener();
        if (listener != null) {
            listener.mo8706g();
        }
    }
}
