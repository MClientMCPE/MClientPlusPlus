package com.adcolony.sdk;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONArray;
import org.json.JSONObject;

public class AdColonyInterstitialActivity extends C2351yf {

    /* renamed from: g0 */
    public C1757rf f2832g0;

    /* renamed from: h0 */
    public C2017ug f2833h0;

    public AdColonyInterstitialActivity() {
        this.f2832g0 = !C0680fe.m4833c() ? null : C0680fe.m4730a().f16049n;
    }

    /* renamed from: a */
    public void mo2999a(C1249lg lgVar) {
        C1860sf sfVar;
        super.mo2999a(lgVar);
        C1422ng f = C0680fe.m4730a().mo11965f();
        JSONObject d = C0680fe.m4839d(lgVar.f9623b, "v4iap");
        JSONArray b = C0680fe.m4803b(d, "product_ids");
        C1757rf rfVar = this.f2832g0;
        if (!(rfVar == null || rfVar.f13517a == null || b.length() <= 0)) {
            C1860sf sfVar2 = this.f2832g0.f13517a;
            b.optString(0);
            d.optInt("engagement_type");
            sfVar2.mo10968c();
        }
        f.mo9248a(this.f17770X);
        C1757rf rfVar2 = this.f2832g0;
        if (rfVar2 != null) {
            f.f11072b.remove(rfVar2.f13521e);
        }
        C1757rf rfVar3 = this.f2832g0;
        if (!(rfVar3 == null || (sfVar = rfVar3.f13517a) == null)) {
            sfVar.mo4781a(rfVar3);
            C1757rf rfVar4 = this.f2832g0;
            rfVar4.f13518b = null;
            rfVar4.f13517a = null;
            this.f2832g0 = null;
        }
        C2017ug ugVar = this.f2833h0;
        if (ugVar != null) {
            Context context = C0680fe.f5238a;
            if (context != null) {
                context.getApplicationContext().getContentResolver().unregisterContentObserver(ugVar);
            }
            ugVar.f15495b = null;
            ugVar.f15494a = null;
            this.f2833h0 = null;
        }
    }

    public void onCreate(Bundle bundle) {
        C1757rf rfVar;
        C1757rf rfVar2 = this.f2832g0;
        this.f17771Y = rfVar2 == null ? -1 : rfVar2.f13520d;
        super.onCreate(bundle);
        if (C0680fe.m4833c() && (rfVar = this.f2832g0) != null) {
            C0302bh bhVar = rfVar.f13519c;
            if (bhVar != null) {
                bhVar.mo2533a(this.f17770X);
            }
            this.f2833h0 = new C2017ug(new Handler(Looper.getMainLooper()), this.f2832g0);
            C1860sf sfVar = this.f2832g0.f13517a;
        }
    }
}
